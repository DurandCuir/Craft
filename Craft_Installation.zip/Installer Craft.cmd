@echo off
rem Craft (edition partagee) : lance l'installateur avec le Python livre a cote, rien d'autre a installer.
if not exist "%~dp0Fichiers\Python\pythonw.exe" goto extraire
if not exist "%~dp0Fichiers\installer_craft.pyw" goto extraire
start "" "%~dp0Fichiers\Python\pythonw.exe" -E "%~dp0Fichiers\installer_craft.pyw"
exit /b 0
:extraire
echo.
echo Craft ne peut pas s'installer depuis le fichier ZIP ouvert.
echo Faites d'abord un clic droit sur Craft_Installation.zip, puis "Extraire tout...",
echo puis double-cliquez sur "Installer Craft" dans le dossier extrait.
echo.
pause
exit /b 1
