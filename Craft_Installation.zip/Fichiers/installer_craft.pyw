"""Installer Craft — l'édition partagée (0.19.15, pour ses amis : « qu'ils puissent installer via internet »).

Lancé par « Installer Craft.cmd » avec le Python livré à côté (Fichiers\\Python) : rien d'autre à installer, aucun
droit d'administrateur. Copie ce Python et Craft dans %LOCALAPPDATA%\\Craft (comme la version personnelle), avec la
même vérification que toute mise à jour (updater.read_bundle, apply_update), prépare les modules, puis met un
raccourci Craft dans le menu Démarrer (et sur le Bureau, à cocher) et une ligne dans « Applications installées »
(désinstallation : Desinstaller.ps1). Un Craft déjà là d'une autre édition (sa version personnelle) n'est jamais
remplacé ; une édition partagée plus ancienne est mise à jour, ses patrons, réglages et licence gardés."""
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import traceback
from pathlib import Path

ICI = Path(__file__).resolve().parent          # the folder « Fichiers » of Craft_Installation.zip
JOURNAL = Path(tempfile.gettempdir()) / 'Craft-installation.log'
UNINSTALL_KEY = r'Software\Microsoft\Windows\CurrentVersion\Uninstall\Craft'
PS_LIENS = r"""$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$data=([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('PAYLOAD'))|ConvertFrom-Json)
$shell=New-Object -ComObject WScript.Shell
$dossiers=@((Join-Path ([Environment]::GetFolderPath('Programs')) 'Craft'))
if($data.bureau){$dossiers+=[Environment]::GetFolderPath('Desktop')}
$faits=@()
foreach($dossier in $dossiers){
 New-Item -ItemType Directory -Path $dossier -Force | Out-Null
 $chemin=Join-Path $dossier 'Craft.lnk'
 $lien=$shell.CreateShortcut($chemin)
 $lien.TargetPath=$data.cible;$lien.Arguments=$data.arguments;$lien.WorkingDirectory=$data.dossier
 $lien.IconLocation=$data.icone;$lien.Description=$data.description
 $lien.Save();$faits+=$chemin
}
ConvertTo-Json -InputObject @($faits) -Compress
"""


def journal(texte):
    try:
        with open(JOURNAL, 'a', encoding='utf-8') as flux:
            flux.write(texte.rstrip() + '\n')
    except OSError:
        pass


def paquet(dossier=None):
    """The shared edition's update ZIP beside this script (the same as the one published for the updates)."""
    dossier = Path(dossier or ICI)
    trouves = sorted(Path(dossier).glob('Craft_Partage_v*.zip'))
    if len(trouves) != 1 or not (Path(dossier) / 'Python' / 'pythonw.exe').is_file():
        raise ValueError('Fichiers d’installation incomplets : téléchargez de nouveau Craft_Installation.zip, '
                         'puis « Extraire tout… » avant de lancer « Installer Craft ».')
    return trouves[0]


def cible():
    base = os.environ.get('LOCALAPPDATA')
    if not base:
        raise ValueError('Dossier des programmes de l’utilisateur introuvable (LOCALAPPDATA).')
    return Path(base) / 'Craft'


MARQUES = ('craft_distribution.py', 'licence_cle.py', 'Python')   # only the shared edition puts these there


def complete(target):
    target = Path(target)
    return all((target / n).is_file() for n in ('Lancer.pyw', 'workspace_ui.py', 'installed_version.json', 'craft_distribution.py'))


def deja(target):
    """('rien' | 'partagee' | 'autre', installed version or None). « partagee »: a mark of the shared edition (its
    link, its licence module, its own Python), even when half removed (version None: to repair); « autre »: his own
    Craft, never replaced."""
    import updater
    target = Path(target)
    partagee = any((target / n).exists() for n in MARQUES)
    present = (target / 'Lancer.pyw').is_file() or (target / 'installed_version.json').is_file()
    if not partagee:
        return ('autre', updater.current_version(target)) if present else ('rien', None)
    if not complete(target):
        return 'partagee', None
    version = updater.current_version(target)
    try:
        updater.version_tuple(version)
    except ValueError:   # its version mark damaged: repaired as well
        return 'partagee', None
    return 'partagee', version


def copier_python(source, destination):
    """The Python runtime (its own copy, never the PC's), file by file: an older one is replaced in place."""
    source, destination = Path(source), Path(destination)
    for p in sorted(source.rglob('*')):
        if p.is_symlink() or '__pycache__' in p.parts:
            continue
        q = destination / p.relative_to(source)
        if p.is_dir():
            q.mkdir(parents=True, exist_ok=True)
        else:
            q.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, q)


def compiler(dossier, informer=lambda texte: None):
    """Python's modules compiled ahead (its standard library, then Craft's): the first start does not wait."""
    import py_compile
    fichiers = [p for p in sorted(Path(dossier).rglob('*.py')) if '__pycache__' not in p.parts]
    for n, p in enumerate(fichiers):
        if n % 50 == 0:
            informer('Préparation… %d %%' % (100 * n // max(1, len(fichiers))))
        try:
            py_compile.compile(str(p), doraise=True)
        except Exception:
            continue


def installer(target, zip_path, python_source, informer=lambda texte: None, reparer=False):
    """The installation itself (also run by the tests, without Windows). Returns the version installed.
    ``reparer`` (« Réinstaller »): the same version written again from scratch (a module damaged or removed)."""
    import updater
    target = Path(target)
    manifest, payload = updater.read_bundle(zip_path)
    if not {'licence_cle.py', 'craft_distribution.py'} <= set(payload):
        raise ValueError('Ce paquet n’est pas l’édition partagée de Craft.')
    genre, version = deja(target)
    if genre == 'autre':
        raise ValueError('Un autre Craft est déjà installé sur ce PC (%s) : il n’est pas remplacé.' % target)
    if genre == 'partagee':
        updater.ensure_closed(target)
        if reparer and version is not None and updater.version_tuple(manifest['version']) == updater.version_tuple(version):
            version = None
    informer('Copie de Python…')
    copier_python(python_source, target / 'Python')
    informer('Installation de Craft…')
    if version is None:
        # A first installation, or one cut short / half removed: installed again from scratch. The version marks
        # left would make apply_update take it for « déjà installée » (never the user's files).
        for nom in ('installed_version.json', 'craft_version.py'):
            try:
                (target / nom).unlink()
            except FileNotFoundError:
                pass
        updater.apply_update(target, manifest, payload, first_install=True)
    elif updater.version_tuple(manifest['version']) > updater.version_tuple(version):
        updater.apply_update(target, manifest, payload)
    compiler(target / 'Python' / 'Lib', informer)
    updater.precompile(target)
    return updater.current_version(target)


def inscrire(target, version, icone):
    """Windows: the line in « Applications installées » (this user only); its Désinstaller runs Desinstaller.ps1."""
    import winreg
    target = Path(target)
    taille = 0
    for p in target.rglob('*'):
        try:
            taille += p.stat().st_size if p.is_file() else 0
        except OSError:
            continue
    commande = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%s"' % (target / 'Desinstaller.ps1')
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY) as key:
        for nom, valeur in (('DisplayName', 'Craft'), ('DisplayVersion', version), ('Publisher', 'Craft'),
                            ('DisplayIcon', str(icone)), ('InstallLocation', str(target)), ('UninstallString', commande)):
            winreg.SetValueEx(key, nom, 0, winreg.REG_SZ, valeur)
        for nom, valeur in (('NoModify', 1), ('NoRepair', 1), ('EstimatedSize', taille // 1024)):
            winreg.SetValueEx(key, nom, 0, winreg.REG_DWORD, valeur)


def integrer(target, version, bureau=True):
    """Windows: shortcuts (menu Démarrer, Bureau if asked) with Craft's icon and identity, then « Applications
    installées ». The .crft association is made by Craft itself at its start. Returns the shortcuts made."""
    if os.name != 'nt':
        return []
    import base64
    import json
    target = Path(target)
    if str(target) not in sys.path:
        sys.path.insert(0, str(target))
    icone = target / 'Python' / 'pythonw.exe'
    try:
        from craft_brand import ensure_icon
        icone = ensure_icon(target)
    except Exception:
        journal(traceback.format_exc())
    # « Applications installées » first: a shortcut refused (an antivirus, PowerShell) never leaves Craft without it.
    try:
        inscrire(target, version, icone)
    except Exception:
        journal(traceback.format_exc())
    faits = []
    try:
        from craft_brand import _powershell
        donnees = dict(bureau=bool(bureau), cible=str(target / 'Python' / 'pythonw.exe'),
                       arguments='-E "%s"' % (target / 'Lancer.pyw'), dossier=str(target), icone=str(icone) + ',0',
                       description='Patronage de maroquinerie')
        # The paths go in as data (base64 JSON), never as PowerShell code (as craft_brand.refresh_shortcuts).
        code = base64.b64encode(json.dumps(donnees).encode('utf-8')).decode('ascii')
        faits = _powershell(PS_LIENS.replace('PAYLOAD', code))
        faits = faits if isinstance(faits, list) else []
    except Exception:
        journal(traceback.format_exc())
    try:
        from craft_version import APP_ID
        from windows_identity import set_shortcut_identity
        for chemin in faits:
            try:
                set_shortcut_identity(chemin, APP_ID, icone)
            except OSError as exc:
                journal('Identité du raccourci : %s : %s' % (chemin, exc))
    except Exception:
        journal(traceback.format_exc())
    return faits


def lancer(target):
    target = Path(target)
    flags = 0x00000008 | 0x00000200 if os.name == 'nt' else 0   # detached, own process group
    subprocess.Popen([str(target / 'Python' / 'pythonw.exe'), '-E', str(target / 'Lancer.pyw')], cwd=str(target),
                     close_fds=True, creationflags=flags)


class Fenetre:
    """The installer's small window: what will happen, Installer, the progress, then Ouvrir Craft."""
    FOND, ENCRE, DOUX, VERT = '#f6f4f1', '#22262b', '#5d646c', '#2f7d4f'

    def __init__(self, root=None):
        import tkinter as tk
        self.tk = tk
        self.root = root or tk.Tk()
        self.root.title('Installer Craft')
        self.root.configure(bg=self.FOND)
        self.root.resizable(False, False)
        self.file = queue.Queue()
        self.target = None
        self.zip = None
        self.version = None
        self.etat = None
        cadre = tk.Frame(self.root, bg=self.FOND, padx=26, pady=22)
        cadre.pack(fill='both', expand=True)
        self.titre = tk.Label(cadre, text='Craft', bg=self.FOND, fg=self.VERT, font=('Segoe UI', 18, 'bold'))
        self.titre.pack(anchor='w')
        tk.Label(cadre, text='Patronage de maroquinerie', bg=self.FOND, fg=self.DOUX, font=('Segoe UI', 10)).pack(anchor='w')
        self.texte = tk.Label(cadre, text='', bg=self.FOND, fg=self.ENCRE, justify='left', wraplength=440, font=('Segoe UI', 10))
        self.texte.pack(anchor='w', pady=(16, 10))
        self.bureau = tk.BooleanVar(value=True)
        self.case = tk.Checkbutton(cadre, text='Mettre aussi un raccourci sur le Bureau', variable=self.bureau, bg=self.FOND,
                                   fg=self.ENCRE, activebackground=self.FOND, selectcolor='white', font=('Segoe UI', 10))
        self.case.pack(anchor='w')
        self.progres = tk.Label(cadre, text='', bg=self.FOND, fg=self.DOUX, font=('Segoe UI', 9))
        self.progres.pack(anchor='w', pady=(8, 0))
        self.boutons = tk.Frame(cadre, bg=self.FOND)
        self.boutons.pack(fill='x', pady=(16, 0))
        self.root.bind('<Escape>', lambda e: self.fermer())
        self.root.protocol('WM_DELETE_WINDOW', self.fermer)   # not while installing (fermer waits)
        self.en_cours = False
        self.preparer()

    def bouton(self, texte, commande, principal=False):
        tk = self.tk
        b = tk.Button(self.boutons, text=texte, command=commande, font=('Segoe UI', 10, 'bold' if principal else 'normal'),
                      padx=14, pady=4, relief='flat', cursor='hand2',
                      bg=self.VERT if principal else '#e3dfd9', fg='white' if principal else self.ENCRE,
                      activebackground='#276b43' if principal else '#d6d1ca', activeforeground='white' if principal else self.ENCRE)
        b.pack(side='right', padx=(8, 0))
        return b

    def vider(self):
        for w in self.boutons.winfo_children():
            w.destroy()

    def preparer(self):
        """What is there already decides the text and the buttons."""
        self.vider()
        try:
            self.zip = paquet()
            import updater
            self.version = updater.read_bundle(self.zip)[0]['version']
            self.target = cible()
            genre, installee = deja(self.target)
        except Exception as exc:
            journal(traceback.format_exc())
            self.texte.configure(text=str(exc))
            self.case.pack_forget()
            self.bouton('Fermer', self.fermer, True)
            return
        self.titre.configure(text='Craft %s' % self.version)
        self.etat = genre
        if genre == 'autre':
            self.case.pack_forget()
            self.texte.configure(text='Un autre Craft est déjà installé sur ce PC :\n%s\n\nIl n’est pas remplacé.' % self.target)
            self.bouton('Fermer', self.fermer, True)
            return
        import updater
        if genre == 'partagee' and installee is None:
            self.texte.configure(text='Une installation de Craft incomplète a été trouvée :\n%s\n\nElle sera réparée. Vos patrons, '
                                      'vos réglages et votre licence sont gardés.' % self.target)
            self.bouton('Annuler', self.fermer)
            self.bouton('Réparer', self.lancer_installation, True)
            return
        if genre == 'partagee' and updater.version_tuple(installee) > updater.version_tuple(self.version):
            self.case.pack_forget()   # never an older Craft over a newer one (its own updates went further)
            self.texte.configure(text='Craft %s est déjà installé sur ce PC : il est plus récent que cet installateur.' % installee)
            self.bouton('Fermer', self.fermer)
            self.bouton('Ouvrir Craft', self.ouvrir, True)
            return
        if genre == 'partagee' and updater.version_tuple(installee) == updater.version_tuple(self.version):
            self.texte.configure(text='Craft %s est déjà installé sur ce PC.\n\n« Réinstaller » remet Craft et ses raccourcis en '
                                      'place ; vos patrons, vos réglages et votre licence sont gardés.' % installee)
            self.bouton('Fermer', self.fermer)
            self.bouton('Réinstaller', lambda: self.lancer_installation(reparer=True))
            self.bouton('Ouvrir Craft', self.ouvrir, True)
            return
        if genre == 'partagee':
            self.texte.configure(text='Craft %s sera remplacé par Craft %s.\nVos patrons, vos réglages et votre licence sont gardés.'
                                 % (installee, self.version))
            self.bouton('Annuler', self.fermer)
            self.bouton('Mettre à jour', self.lancer_installation, True)
            return
        self.texte.configure(text='Craft s’installe pour vous seul, dans :\n%s\n\nRien d’autre à installer, aucun droit '
                                  'd’administrateur. Craft cherchera ensuite ses mises à jour tout seul.' % self.target)
        self.bouton('Annuler', self.fermer)
        self.bouton('Installer', self.lancer_installation, True)

    def lancer_installation(self, reparer=False):
        self.vider()
        self.case.configure(state='disabled')
        self.progres.configure(text='Installation…')
        self.en_cours = True   # the window stays until the end: an installation cut short is never left behind
        bureau = self.bureau.get()
        threading.Thread(target=self._travail, args=(bureau, reparer)).start()
        self.root.after(150, self._relever)

    def _travail(self, bureau, reparer=False):
        try:
            version = installer(self.target, self.zip, ICI / 'Python', informer=lambda t: self.file.put(('info', t)),
                                reparer=reparer)
            self.file.put(('info', 'Raccourcis…'))
            liens = integrer(self.target, version, bureau)
            self.file.put(('fini', version, liens))
        except Exception as exc:
            journal(traceback.format_exc())
            self.file.put(('erreur', str(exc)))

    def _relever(self):
        try:
            while True:
                quoi = self.file.get_nowait()
                if quoi[0] == 'info':
                    self.progres.configure(text=quoi[1])
                    continue
                self.en_cours = False
                if quoi[0] == 'fini':
                    self.fini(quoi[1], quoi[2])
                else:
                    self.progres.configure(text='')
                    self.texte.configure(text='Installation impossible : %s\n\nDétails : %s' % (quoi[1], JOURNAL))
                    self.bouton('Fermer', self.fermer, True)
                return
        except queue.Empty:
            self.root.after(150, self._relever)

    def fini(self, version, liens=None):
        self.etat = 'fait'
        self.progres.configure(text='')
        self.case.pack_forget()
        note = ''
        if os.name == 'nt' and not liens:
            note = '\n\nLes raccourcis n’ont pas pu être créés : relancez « Installer Craft » pour réessayer.'
        self.texte.configure(text='Craft %s est installé.\n\nPour activer votre licence : dans Craft, menu Aide › Activer une '
                                  'licence…, collez la clé reçue, puis Activer.\n\nCe dossier d’installation peut être supprimé.%s'
                                  % (version, note))
        self.bouton('Fermer', self.fermer)
        self.bouton('Ouvrir Craft', self.ouvrir, True)

    def ouvrir(self):
        try:
            lancer(self.target)
        except Exception as exc:
            journal(traceback.format_exc())
            self.texte.configure(text='Craft ne s’ouvre pas : %s' % exc)
            return
        self.fermer()

    def fermer(self):
        if self.__dict__.get('en_cours'):
            return
        try:
            self.root.destroy()
        except Exception:
            pass


def main():
    journal('Installer Craft — %s' % ' '.join(sys.argv))
    try:
        fenetre = Fenetre()
    except Exception:
        # No window at all (pythonw shows nothing): Windows' own message, and the details in the log.
        journal(traceback.format_exc())
        if os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, 'Craft ne peut pas s’installer.\n\nDétails : %s' % JOURNAL, 'Installer Craft', 16)
        return 1
    fenetre.root.mainloop()
    return 0


if __name__ == '__main__':
    sys.exit(main())
