"""0.19.8 « Exporter › DWG Mozart » (« vas-y, je vais pouvoir tester sur Mozart demain »): the pattern written
the way Mozart (on AutoCAD) writes its own, so that Mozart takes the pieces for its own pieces.

What Mozart puts in its files (read from his DIFORME files, the same that Craft opens: mozart_import):
- each piece: its outline on the layer PIT_DIS_AREA (inner cuts: PIT_DIS_TA_CONT_INT) and, inside it, the
  blocks PITNUM (the model), PITRIFNA, PITDATIT (the piece's name) and PITDATIM (its material, how many,
  the refente), whose invisible attributes carry the data;
- a cran: the block PitTacCT at its foot, turned like the cran (12 mm, scaled to its depth: 18 mm = 1,5);
- a drill: the block Moz_Fust (Ø 1 scaled to the drill) on PIT_DIS_MDT_FUST, its label ETI (the diameter,
  « P » for a pointé);
- a preparation: a solid hatch on its own layer (MOZ_PREP_P_01_REMBORD, …_P_03_TEINTE…) with the extended
  data MOZ_PREP (length, thickness, layers…) and its text;
- the base: lines and titles on the layer « Présentation »; the model sheet: the block MOZ_INFO and its
  extended data;
- 0.19.14 a cote: AutoCAD's DIMENSION in Mozart's style ISO-25 and its block *Dn (in a DXF; a DWG keeps its lines
  and text: DWG_DIMENSIONS).
The empty drawing with Mozart's layers and blocks is mozart_base.dxf (tools/make_mozart_base.py); the
entities are added here as in exchange.export_dxf (no library needed); the DWG is written by LibreDWG."""
import math
import re
from pathlib import Path
from geometry import path, validate, bounds
from cad import column_types
import piece_sheet

TEMPLATE = 'mozart_base.dxf'
CRAN_DEPTH = 12.   # the PitTacCT block
PREFIX = {'Cuir': 'A-', 'Tissu': 'F-', 'Renfort': 'I-'}   # Mozart's materials: A-MOUTON, F-TOILE, I-CARTON…
COLUMN_PREFIX = {2: 'A-', 3: 'F-', 4: 'I-'}   # the base column of the piece, when the material is not known
PREP_COLOURS = {'01': 204, '03': 30, '07': 1, '09': 3}
INFO_FIELDS = 21   # the MOZ_INFO data: modèle, description, atelier, date, créateur… (see info_data)


def _num(value):
    return f'{value:.12g}' if isinstance(value, float) else str(value)


def _fmt(value):
    """7.0 → '7', 0.85 → '0.85' (Mozart writes its numbers with a point)."""
    if value in (None, ''):
        return ''
    try:
        return f'{float(value):.6g}'
    except (TypeError, ValueError):
        return ''


def _clean(text, size=250):
    """Text for a DXF value (one line, no control character)."""
    return re.sub(r'[\x00-\x1f]', ' ', str(text or '')).strip()[:size]


class _Writer:
    """The template's text, the entities added after its own handles, new layers added to its table."""

    def __init__(self, text):
        self.template = text
        lines = text.splitlines()
        pairs = [(lines[i].strip(), lines[i + 1].strip()) for i in range(0, len(lines) - 1, 2)]
        handles, self.layers, self.model, self.plot_style = [], set(), None, None
        self.block_table, self.block_names = None, set()
        record, fields = None, {}
        for code, value in pairs + [('0', 'EOF')]:
            if code == '0':
                if record == 'LAYER' and '2' in fields:
                    self.layers.add(fields['2'].upper())
                    self.plot_style = self.plot_style or fields.get('390')
                elif record == 'BLOCK_RECORD':
                    self.model = self.model or (fields.get('5') if fields.get('2') == '*Model_Space' else None)
                    self.block_names.add(fields.get('2', '').upper())
                elif record == 'TABLE' and fields.get('2') == 'BLOCK_RECORD':
                    self.block_table = fields.get('5')
                record, fields = value, {}
            else:
                fields.setdefault(code, value)
                if code in ('5', '105'):
                    try:
                        handles.append(int(value, 16))
                    except ValueError:
                        pass
        if not self.model or not handles:
            raise ValueError('Gabarit Mozart invalide.')
        # The drawing's entities from 0x1000, as Craft's own DXF: LibreDWG gives the objects it adds for the DWG
        # (its APPID, the VX table of the 2000 format) the handles that follow the template's. They follow each
        # other without a gap: from a DXF, LibreDWG writes the link of an entity to the next one as implicit
        # (its handle + 1), so the attributes of the blocks, their ends and the new layers come after all of
        # them (numbered in ``document``), or they were read as entities of the drawing.
        self.base = max(max(handles) + 1, 0x1000)
        self.entities = 0
        self.subs = 0
        self.new_layers = []
        self.out = []
        self.points = []
        self.dim_blocks = []   # 0.19.14: (BLOCK_RECORD, BLOCK … ENDBLK) of each dimension

    def handle(self, sub=False):
        """A mark replaced by the handle in ``document`` (entities first, then the rest)."""
        if sub:
            self.subs += 1
            return f'\x03{self.subs - 1}\x04'
        self.entities += 1
        return f'\x01{self.entities - 1}\x02'

    @staticmethod
    def pairs(values):
        return ''.join(f'{code}\n{_num(value)}\n' for code, value in values)

    def layer(self, name, colour=7):
        if name.upper() not in self.layers:
            self.layers.add(name.upper())
            self.new_layers.append((name, colour))
        return name

    def entity(self, kind, layer, subclass, values, colour=None, owner=None, extra=(), xdata=(), handle=None):
        h = handle or self.handle()
        head = [(0, kind), (5, h), (330, owner or self.model), (100, 'AcDbEntity'), (8, layer)]
        if colour is not None:
            head.append((62, colour))
        self.out.append(self.pairs(head + ([(100, subclass)] if subclass else []) + list(values) + list(extra) + list(xdata)))
        return h

    def seen(self, *pts):
        self.points.extend(pts)

    # --- geometry (DXF: x right, y up; Craft's y goes down)
    def polyline(self, pts, bulges, closed, layer, colour=None):
        values = [(90, len(pts)), (70, (1 if closed else 0) | 128), (43, 0.)]   # 128: as Mozart's (PLINEGEN)
        for (x, y), b in zip(pts, bulges):
            values += [(10, float(x)), (20, float(-y))] + ([(42, float(-b))] if b else [])
        self.seen(*[(x, -y) for x, y in pts])
        return self.entity('LWPOLYLINE', layer, 'AcDbPolyline', values, colour)

    def line(self, a, b, layer, colour=None):
        self.seen((a[0], -a[1]), (b[0], -b[1]))
        return self.entity('LINE', layer, 'AcDbLine', [(10, float(a[0])), (20, float(-a[1])), (30, 0.), (11, float(b[0])), (21, float(-b[1])), (31, 0.)], colour)

    def circle(self, c, r, layer, colour=None):
        self.seen((c[0] - r, -c[1] - r), (c[0] + r, -c[1] + r))
        return self.entity('CIRCLE', layer, 'AcDbCircle', [(10, float(c[0])), (20, float(-c[1])), (30, 0.), (40, float(r))], colour)

    def text(self, p, height, value, layer, angle=0., style='Standard', centre=False, colour=None):
        """A TEXT; ``p`` in DXF coordinates; ``centre``: p is its middle."""
        values = [(10, float(p[0])), (20, float(p[1])), (30, 0.), (40, float(height)), (1, _clean(value)), (50, float(angle)), (7, style)]
        if centre:
            values += [(72, 1), (11, float(p[0])), (21, float(p[1])), (31, 0.)]
        values += [(100, 'AcDbText')] + ([(73, 2)] if centre else [])
        self.seen(p)
        return self.entity('TEXT', layer, 'AcDbText', values, colour)

    def mtext(self, p, height, value, layer, width=0.):
        self.seen(p)
        return self.entity('MTEXT', layer, 'AcDbMText', [(10, float(p[0])), (20, float(p[1])), (30, 0.), (40, float(height)), (41, float(width)),
                                                          (71, 1), (72, 5), (1, value), (7, 'Standard')])

    def insert(self, block, p, scale=1., angle=0., layer='0', attribs=(), colour=None, xdata=(), columns=None):
        """An INSERT (``p`` in DXF coordinates) and its attributes: (tag, value, (dx, dy) in the block, height
        in the block, colour, centred); ``columns``: Mozart's MOZ_INFO, a MINSERT of two at the same place."""
        values = [(66, 1)] if attribs else []
        values += [(2, block), (10, float(p[0])), (20, float(p[1])), (30, 0.)]
        if scale != 1:
            values += [(41, float(scale)), (42, float(scale)), (43, float(scale))]
        if angle:
            values += [(50, float(angle))]
        if columns:
            values += [(70, columns), (71, 1), (44, 1e-07), (45, 0.)]
        h = self.entity('INSERT', layer, 'AcDbMInsertBlock' if columns else 'AcDbBlockReference', values, colour, xdata=xdata)
        self.seen(p)
        a = math.radians(angle)
        c, s = math.cos(a), math.sin(a)
        for tag, value, (dx, dy), height, tint, centred in attribs:
            x, y = p[0] + scale * (dx * c - dy * s), p[1] + scale * (dx * s + dy * c)
            body = [(10, x), (20, y), (30, 0.), (40, float(height * scale)), (1, _clean(value)), (50, float(angle)), (7, 'Standard')]
            if centred:
                body += [(72, 4), (11, x), (21, y), (31, 0.)]
            body += [(100, 'AcDbAttribute'), (2, tag), (70, 1)]   # invisible, as Mozart's
            self.entity('ATTRIB', '0', 'AcDbText', body, tint, owner=h, handle=self.handle(sub=True))
        if attribs:
            self.entity('SEQEND', '0', None, [], owner=h, handle=self.handle(sub=True))
        return h

    def hatch(self, loops, layer, seed, xdata=()):
        """A solid hatch (not associative) of polyline loops [(points, bulges)] in Craft coordinates."""
        values = [(10, 0.), (20, 0.), (30, 0.), (210, 0.), (220, 0.), (230, 1.), (2, 'SOLID'), (70, 1), (71, 0), (91, len(loops))]
        for k, (pts, bulges) in enumerate(loops):
            curved = any(bulges)
            values += [(92, 3 if k == 0 else 2), (72, 1 if curved else 0), (73, 1), (93, len(pts))]
            for (x, y), b in zip(pts, bulges):
                values += [(10, float(x)), (20, float(-y))] + ([(42, float(-b))] if curved else [])
            values += [(97, 0)]
            self.seen(*[(x, -y) for x, y in pts])
        values += [(75, 1), (76, 1), (98, 1), (10, float(seed[0])), (20, float(-seed[1]))]
        return self.entity('HATCH', layer, 'AcDbHatch', values, xdata=xdata)

    def dimension(self, d, members, layer='CRAFT_DIMENSION'):
        """0.19.14: a cote as AutoCAD's DIMENSION (``d``: cote_dimension) and its anonymous block *Dn, made as AutoCAD
        makes it: the cote drawn as Craft draws it (its lines and arcs, its arrows as solids, its text), by block, and the
        definition points on Defpoints. The block, its record and its end are numbered after the drawing's entities
        (as the attributes); the entities of the block follow each other."""
        n = len(self.dim_blocks) + 1
        while f'*D{n}' in self.block_names:
            n += 1
        name = f'*D{n}'
        self.block_names.add(name)
        record, begin, end = self.handle(sub=True), self.handle(sub=True), self.handle(sub=True)
        body = []

        def put(kind, subclass, values, on='0', weight=False):
            head = [(0, kind), (5, self.handle(sub=True)), (330, record), (100, 'AcDbEntity'), (8, on), (62, 0)] + ([(370, -2)] if weight else [])
            body.append(self.pairs(head + [(100, subclass)] + values))
        from precision_geometry import primitives
        for s in members:
            if s.get('annotation'):
                cx, cy = s['x'] + s['text_offset'][0], s['y'] + s['text_offset'][1]
                put('TEXT', 'AcDbText', [(10, float(cx)), (20, float(-cy)), (30, 0.), (40, float(s.get('text_height', 3))), (1, _clean(s.get('label'))),
                                         (50, float(-s.get('text_angle', 0.))), (7, 'Standard'), (72, 1), (11, float(cx)), (21, float(-cy)), (31, 0.),
                                         (100, 'AcDbText'), (73, 2)])
            elif s.get('filled'):
                tip, p, q = path(s)[0][:3]
                put('SOLID', 'AcDbTrace', [(10 + k, float(x)) if j == 0 else (20 + k, float(-x)) if j == 1 else (30 + k, 0.)
                                           for k, pt in enumerate((p, q, tip, tip)) for j, x in enumerate((pt[0], pt[1], 0.))])
            else:
                for g in primitives(s):
                    if g['sweep']:
                        a0, a1 = -g['start'], -g['start'] - g['sweep']
                        a0, a1 = (a0, a1) if a1 >= a0 else (a1, a0)
                        put('ARC', 'AcDbCircle', [(10, float(g['c'][0])), (20, float(-g['c'][1])), (30, 0.), (40, float(g['r'])), (100, 'AcDbArc'),
                                                  (50, math.degrees(a0) % 360), (51, math.degrees(a1) % 360)], weight=True)
                    else:
                        put('LINE', 'AcDbLine', [(10, float(g['a'][0])), (20, float(-g['a'][1])), (30, 0.), (11, float(g['b'][0])), (21, float(-g['b'][1])), (31, 0.)], weight=True)
        for code in (13, 14, 15, 10):
            if code in d['points']:
                x, y = d['points'][code]
                put('POINT', 'AcDbPoint', [(10, float(x)), (20, float(-y)), (30, 0.)], on='Defpoints')
        self.dim_blocks.append((self.pairs([(0, 'BLOCK_RECORD'), (5, record), (330, self.block_table), (100, 'AcDbSymbolTableRecord'), (100, 'AcDbBlockTableRecord'),
                                            (2, name), (340, 0)]),
                                self.pairs([(0, 'BLOCK'), (5, begin), (330, record), (100, 'AcDbEntity'), (8, '0'), (100, 'AcDbBlockBegin'), (2, name), (70, 1),
                                            (10, 0.), (20, 0.), (30, 0.), (3, name), (1, '')]) + ''.join(body)
                                + self.pairs([(0, 'ENDBLK'), (5, end), (330, record), (100, 'AcDbEntity'), (8, '0'), (100, 'AcDbBlockEnd')])))
        P = {code: (float(x), float(-y)) for code, (x, y) in d['points'].items()}
        self.seen(*P.values())
        values = [(2, name), (10, P[10][0]), (20, P[10][1]), (30, 0.), (11, P[11][0]), (21, P[11][1]), (31, 0.),
                  (70, d['type'] | 32 | (128 if d.get('placed') else 0)), (71, 5), (72, 1), (41, 1.), (42, float(d['value']))]
        values += [(1, d['text'].replace('\\', '\\\\'))] if d.get('text') else []
        values += [(3, DIMSTYLE)]
        if d['type'] in (0, 1):
            values += [(100, 'AcDbAlignedDimension'), (13, P[13][0]), (23, P[13][1]), (33, 0.), (14, P[14][0]), (24, P[14][1]), (34, 0.)]
            values += [(50, float(-d['angle']) % 180), (100, 'AcDbRotatedDimension')] if d['type'] == 0 else []
        elif d['type'] in (3, 4):
            values += [(100, 'AcDbDiametricDimension' if d['type'] == 3 else 'AcDbRadialDimension'), (15, P[15][0]), (25, P[15][1]), (35, 0.), (40, 0.)]
        else:
            values += [(100, 'AcDb3PointAngularDimension')] + [(c + k * 10, P[c][k] if k < 2 else 0.) for c in (13, 14, 15) for k in range(3)]
        # its look in AutoCAD's own overrides (DSTYLE): arrows, text, extension lines from the points to the line, gap
        style = [(1070, 41), (1040, float(d['arrow'])), (1070, 140), (1040, float(d['height'])), (1070, 42), (1040, 0.), (1070, 44), (1040, 0.),
                 (1070, 147), (1040, float(d['gap']))]
        return self.entity('DIMENSION', layer, 'AcDbDimension', values, xdata=[(1001, 'ACAD'), (1000, 'DSTYLE'), (1002, '{')] + style + [(1002, '}')])

    def document(self):
        content, n = re.subn(r'(0\s*\nSECTION\s*\n\s*2\s*\nENTITIES\s*\n).*?(?=\s*0\s*\nENDSEC)', lambda m: m[1] + ''.join(self.out), self.template, count=1, flags=re.S)
        if n != 1:
            raise ValueError('Gabarit Mozart invalide.')
        if self.new_layers:
            m = re.search(r'(\s*0\nTABLE\n\s*2\nLAYER\n\s*5\n)([0-9A-Fa-f]+)\n', content)
            if not m:
                raise ValueError('Table des calques absente du gabarit Mozart.')
            table = m[2]
            records = ''.join(self.pairs([(0, 'LAYER'), (5, self.handle(sub=True)), (330, table), (100, 'AcDbSymbolTableRecord'), (100, 'AcDbLayerTableRecord'),
                                          (2, name), (70, 0), (62, colour), (6, 'Continuous'), (370, -3)] + ([(390, self.plot_style)] if self.plot_style else []))
                              for name, colour in self.new_layers)
            end = content.index('ENDTAB', m.end())
            end = content.rindex('\n', 0, content.rindex('\n', 0, end)) + 1   # before « 0 / ENDTAB »
            content = content[:end] + records + content[end:]
            content = re.sub(r'(\s*0\nTABLE\n\s*2\nLAYER\n\s*5\n[0-9A-Fa-f]+\n\s*330\n[0-9A-Fa-f]+\n\s*100\nAcDbSymbolTable\n\s*70\n)\s*(\d+)\n',
                             lambda m: m[1] + str(int(m[2]) + len(self.new_layers)) + '\n', content, count=1)
        if self.dim_blocks:
            # 0.19.14: the dimensions' blocks: their records at the end of the block table (counted), their drawing at the
            # end of the BLOCKS section
            m = re.search(r'\n[ \t]*0\nTABLE\n[ \t]*2\nBLOCK_RECORD\n[ \t]*5\n[0-9A-Fa-f]+\n[ \t]*330\n[0-9A-Fa-f]+\n[ \t]*100\nAcDbSymbolTable\n[ \t]*70\n[ \t]*(\d+)\n', content)
            table_end = m and re.compile(r'\n[ \t]*0\nENDTAB\n').search(content, m.end())
            if not table_end or not self.block_table:
                raise ValueError('Table des blocs absente du gabarit Mozart.')
            end = table_end.start() + 1   # before « 0 / ENDTAB »
            content = content[:m.start(1)] + str(int(m[1]) + len(self.dim_blocks)) + content[m.end(1):end] + ''.join(r for r, _ in self.dim_blocks) + content[end:]
            blocks = re.search(r'\n[ \t]*0\nSECTION\n[ \t]*2\nBLOCKS\n', content)
            section_end = blocks and re.compile(r'\n[ \t]*0\nENDSEC\n').search(content, blocks.end())
            if not section_end:
                raise ValueError('Section des blocs absente du gabarit Mozart.')
            end = section_end.start() + 1   # before « 0 / ENDSEC »
            content = content[:end] + ''.join(b for _, b in self.dim_blocks) + content[end:]
        first_sub = self.base + self.entities
        content = re.sub('\x01(\\d+)\x02', lambda m: format(self.base + int(m[1]), 'X'), content)
        content = re.sub('\x03(\\d+)\x04', lambda m: format(first_sub + int(m[1]), 'X'), content)
        content = re.sub(r'(\$HANDSEED\s*\n\s*5\s*\n)[0-9A-Fa-f]+', lambda m: m[1] + format(first_sub + self.subs, 'X'), content, count=1)
        if self.points:
            xs = [p[0] for p in self.points]
            ys = [p[1] for p in self.points]
            for key, xyz in (('EXTMIN', (min(xs), min(ys), 0.)), ('EXTMAX', (max(xs), max(ys), 0.))):
                content = re.sub(r'(\$' + key + r'\s*\n\s*10\s*\n)[^\n]+\n(\s*20\s*\n)[^\n]+\n(\s*30\s*\n)[^\n]+\n',
                                 lambda m: m[1] + _num(float(xyz[0])) + '\n' + m[2] + _num(float(xyz[1])) + '\n' + m[3] + _num(float(xyz[2])) + '\n', content, count=1)
        return content


# --- reading Craft's drawing ------------------------------------------------------------------------

def _role(s):
    from craft_tools import style
    return style(s)['role']


def _outline(s):
    """(points, bulges, closed) of a shape as one polyline (Craft coordinates; a circle: two half arcs; a
    curve: its points)."""
    if s['kind'] == 'circle':
        c, r = (s['x'] + s['w'] / 2, s['y'] + s['h'] / 2), s['w'] / 2
        return [(c[0] + r, c[1]), (c[0] - r, c[1])], [1., 1.], True
    if s['kind'] == 'rect' and s.get('r'):
        x, y, w, h, r = (s[k] for k in ('x', 'y', 'w', 'h', 'r'))
        b = math.tan(math.pi / 8)
        pts = [(x + r, y), (x + w - r, y), (x + w, y + r), (x + w, y + h - r), (x + w - r, y + h), (x + r, y + h), (x, y + h - r), (x, y + r)]
        return pts, [0., b, 0., b, 0., b, 0., b], True
    if s['kind'] == 'poly' and any(s.get('bulges') or ()) and not s.get('spline') and not s.get('ellipse'):
        pts = [(s['x'] + a, s['y'] + b) for a, b in s['points']]
        bulges = (list(s['bulges']) + [0.] * len(pts))[:len(pts)]
        return pts, bulges, bool(s.get('closed'))
    pts, closed = path(s)
    if closed and len(pts) > 1 and math.dist(pts[0], pts[-1]) < 1e-9:
        pts = pts[:-1]
    return pts, [0.] * len(pts), closed


def _inside(pts, p):
    x, y = p
    r = False
    for (ax, ay), (bx, by) in zip(pts, pts[1:] + pts[:1]):
        if (ay > y) != (by > y) and x < (bx - ax) * (y - ay) / (by - ay) + ax:
            r = not r
    return r


def _clearance(pts, p):
    best = float('inf')
    for a, b in zip(pts, pts[1:] + pts[:1]):
        ux, uy = b[0] - a[0], b[1] - a[1]
        n = ux * ux + uy * uy
        t = 0 if n < 1e-18 else max(0, min(1, ((p[0] - a[0]) * ux + (p[1] - a[1]) * uy) / n))
        best = min(best, math.dist(p, (a[0] + ux * t, a[1] + uy * t)))
    return best


def inner_point(s, prefer=(.25, .25)):
    """A point well inside the closed shape ``s`` (Craft coordinates), near its upper left (where Mozart
    puts a piece's data) when there is room, else its most inner point found. 0.19.8: a thin band (a surcoupe ring)
    where no point of the grid falls: points just inside its sides; the search on at most 1500 of its points (a
    band of 60 000 points), the point chosen checked on all of them."""
    pts, closed = path(s)
    x0, y0, x1, y1 = bounds([s])
    w, h = x1 - x0, y1 - y0
    coarse = pts[::max(1, len(pts) // 1500)]
    candidates = [(x0 + prefer[0] * w, y0 + prefer[1] * h)]
    n = 12
    candidates += [(x0 + w * (i + .5) / n, y0 + h * (j + .5) / n) for j in range(n) for i in range(n)]
    found = []
    for k, p in enumerate(candidates):
        if not _inside(coarse, p):
            continue
        room = _clearance(coarse, p)
        if k == 0 and room >= min(25., .2 * min(w, h)) and _inside(pts, p):
            return p
        found.append((room, p))
    if not found and len(coarse) >= 3:
        m = len(coarse)
        for k in range(0, m, max(1, m // 48)):
            a, b = coarse[k], coarse[(k + 1) % m]
            length = math.dist(a, b)
            if length < 1e-9:
                continue
            nx, ny = -(b[1] - a[1]) / length, (b[0] - a[0]) / length
            mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
            for d in (.05, .2, .5, 1.5, 4.):
                for sign in (1, -1):
                    p = (mid[0] + sign * nx * d, mid[1] + sign * ny * d)
                    if _inside(coarse, p):
                        found.append((_clearance(coarse, p), p))
    for room, p in sorted(found, key=lambda f: -f[0]):
        if coarse is pts or _inside(pts, p):
            return p
    return ((x0 + x1) / 2, (y0 + y1) / 2)


def _labels(items):
    """The piece labels of Craft (identification texts), by piece id and kind."""
    out = {}
    for s in items:
        ident = s.get('identification')
        if s.get('annotation') and ident and s.get('owner_id'):
            out.setdefault(s['owner_id'], {}).setdefault(ident.get('kind'), s)
    return out


def _column(workspace, x):
    if not workspace:
        return None
    edge = workspace.get('origin_x', 0.)
    for i, width in enumerate(workspace['widths']):
        if edge <= x < edge + width:
            return i
        edge += width
    return None


def _material_code(name, archives, column):
    import materials
    kind = materials.info(archives, name)['type'] if name else 'Autre'
    prefix = PREFIX.get(kind) or (COLUMN_PREFIX.get(column, '') if kind == 'Autre' else '')
    if kind == 'Autre' and isinstance(column, tuple):   # 0.19.13: (index, the types its column holds)
        prefix = PREFIX.get(column[1][0], '') if column[1] else ''
    return prefix + name.upper() if name else ''


def info_data(infos, model):
    """The 21 MOZ_INFO values: modèle, matière(s), atelier, date, créateur, indice, saison at the places
    Mozart had them in DIFORME (« Diforme », « Cuir de vachette », « Salle 36 », « 11/09/24 », « DURAND
    Alexis »…, « 1 », « Automne/Hiver 24/25 »)."""
    infos = infos or {}
    values = [''] * INFO_FIELDS
    # 0.19.13: the model sheet of the Mozart file it was opened from, where Craft has nothing in its place
    raw = infos.get('mozart_info')
    if isinstance(raw, list):
        for index, value in enumerate(raw[:INFO_FIELDS]):
            values[index] = _clean(value, 200)
    date = str(infos.get('cree_le') or '')
    m = re.fullmatch(r'(\d{1,2})/(\d{1,2})/(\d{2})?(\d{2})', date)
    if m:
        date = f'{int(m[1]):02d}/{int(m[2]):02d}/{m[4]}'
    # 0.19.14: the 3rd value is the materials; the créateur where Mozart had it (« AD » only at the 15th on TILTED),
    # at both places for a model made in Craft (as DIFORME)
    creator = _clean(infos.get('createur'), 200)
    had = [k for k in (9, 14) if values[k].strip()]
    if not (had and creator == next(values[k].strip() for k in had)):
        for k in had or (9, 14):
            values[k] = creator
    for index, value in ((0, infos.get('modele') or model), (2, infos.get('matieres')), (6, infos.get('atelier')), (8, date),
                         (17, infos.get('indice')), (19, infos.get('saison'))):
        values[index] = _clean(value, 200)
    return values


def _layer_word(text, size=60):
    """Text a layer name can carry: one line, the characters of the DXF's code page, none of those AutoCAD refuses
    in a name (<>/\\":;?*|=`,), spaces collapsed."""
    text = _clean(text).upper().encode('cp1252', 'replace').decode('cp1252')
    return re.sub(r'\s+', ' ', re.sub(r'[<>/\\":;?*|=`,]', ' ', text)).strip()[:size].strip()


def _prep_layer(prep):
    kind = prep.get('kind')
    typ = _layer_word(prep.get('type'))
    if kind == 'parage':
        if typ == 'REMBORD':
            return 'MOZ_PREP_P_01_REMBORD', '01'
        if typ == 'PINCE':
            return 'MOZ_PREP_P_01_PARAGE EN PINCE', '01'
        return 'MOZ_PREP_P_01_PARAGE' + (' ' + typ if typ and typ != 'PARAGE' else ''), '01'
    if kind == 'teinte':
        return 'MOZ_PREP_P_03_TEINTE', '03'
    if kind == 'surcoupe':
        return 'MOZ_PREP_P_07_SURCOUPE', '07'
    return 'MOZ_PREP_P_09_' + (_layer_word(prep.get('label') or prep.get('type')) or 'AUTRE'), '09'


def _surcoupe_loops(zone, items):
    """0.19.13 (aller-retour Craft ↔ Mozart): a Surcoupe zone written as Mozart writes it: the précoupe's contour, the
    pieces to recut as its holes (Craft's band, one outline with a slit, came back from Mozart without its pieces to
    recut). None when its précoupe or its pieces to recut are not found."""
    owner = zone.get('owner_id')
    host = next((q for q in items if owner and q.get('piece_id') == owner and _role(q) == 'external' and path(q)[1]), None)
    recut = [q for q in items if owner and q.get('owner_id') == owner and _role(q) == 'surcoupe' and path(q)[1]]
    if host is None or not recut:
        return None
    loops = []
    for q in [host] + recut:
        pts, bulges, closed = _outline(q)
        if closed and len(pts) > 1 and math.dist(pts[0], pts[-1]) < 1e-9:
            pts, bulges = pts[:-1], bulges[:-1]
        if len(pts) < 2:
            return None
        loops.append((pts, bulges))
    return loops


def _prep_label(prep):
    label = _clean(prep.get('label'), 120)
    if label:
        return label.upper()
    words = {'rembord': 'REMBORD', 'pince': 'PARAGE EN PINCE'}.get(prep.get('type'), (prep.get('type') or prep.get('kind') or '').upper())
    length = _fmt(prep.get('length'))
    return (words + (' ' + length.replace('.', ',') if length and prep.get('kind') == 'parage' else '')).strip()


# --- 0.19.14 the cotes as AutoCAD's dimensions --------------------------------------------------------------

DIMSTYLE = 'ISO-25'   # the style of Mozart's own cotes (TILTED), in the template


def cote_number(value):
    """A cote's value as Craft's cote tools write it (in mm): 180.28, 100."""
    return f'{float(f"{value:.6g}"):.2f}'.rstrip('0').rstrip('.')


def _arc_under(items, tip, label):
    """(centre, radius) of the circle or arc of the drawing a radius cote points at: through its tip, its radius the
    cote's value when there are several; None when it is no longer there."""
    from precision_geometry import primitives
    from curves import parts
    from entity_rules import geometry_entity
    from geometry import near_box
    found = []
    for s in items:
        if not geometry_entity(s) or s.get('spline') or s.get('ellipse') or not near_box(s, tip, 1e-3):
            continue
        for q in parts(s) if s.get('components') else [s]:
            if q['kind'] == 'circle':
                arcs = [dict(c=(q['x'] + q['w'] / 2, q['y'] + q['h'] / 2), r=q['w'] / 2, sweep=0.)]
            elif q['kind'] == 'line':
                continue
            else:
                arcs = [g for g in primitives(q) if g['sweep']]
            for g in arcs:
                off = abs(math.dist(tip, g['c']) - g['r'])
                if off <= 1e-5 * max(1., g['r']):
                    inside = not g['sweep'] or ((math.atan2(tip[1] - g['c'][1], tip[0] - g['c'][0]) - g['start']) * (1 if g['sweep'] > 0 else -1)) % (2 * math.pi) <= abs(g['sweep']) + 1e-9
                    found.append((label != 'R' + cote_number(g['r']), not inside, off, g['c'], g['r']))
    return min(found, key=lambda f: f[:3])[3:] if found else None


def cote_dimension(members, items):
    """0.19.14: AutoCAD's dimension of one Craft cote (its members, as Craft's cote tools make them), as dict(type: 0 rotated
    (horizontal, vertical), 1 aligned, 3 diameter, 4 radius, 5 angle; points: AutoCAD's definition points by group code
    (Craft coordinates: 10, 13, 14, 15; 11 the middle of the text); angle: of a rotated one (degrees, Craft); value: the
    measurement (an angle in radians); text: the cote's text when it is not that measurement; placed: a text placed by
    hand (radius, diameter); arrow, height, gap: its look). None: a cote AutoCAD 2000 has no dimension for (longueur
    d'arc) or no longer whole."""
    from craft_tools import linear_cote, COTE_ARROW, COTE_GAP
    labels = [s for s in members if s.get('annotation')]
    if len(labels) != 1 or 'text_offset' not in labels[0]:
        return None
    label = labels[0]
    text = _clean(label.get('label'), 200)
    height = float(label.get('text_height', 3.))
    middle = (label['x'] + label['text_offset'][0], label['y'] + label['text_offset'][1])
    arrows = [s for s in members if s.get('filled')]
    strokes = [s for s in members if not s.get('filled') and not s.get('annotation')]
    if any(len(path(s)[0]) < 3 for s in arrows):
        return None

    def arrow_size(s):
        tip, p, q = path(s)[0][:3]
        return math.dist(tip, ((p[0] + q[0]) / 2, (p[1] + q[1]) / 2))
    d = dict(points={11: middle}, height=height, arrow=arrow_size(arrows[0]) if arrows else COTE_ARROW, gap=max(0., COTE_GAP - height / 2), text='')
    parts = linear_cote(members)
    if parts:
        line = path(members[parts['line']])[0]
        A, B = line[0], line[-1]
        P1, P2 = path(members[parts['ext'][0]])[0][0], path(members[parts['ext'][1]])[0][0]
        length = math.dist(A, B)
        if length < 1e-6:
            return None
        u = ((B[0] - A[0]) / length, (B[1] - A[1]) / length)
        dx, dy = P2[0] - P1[0], P2[1] - P1[1]
        value = abs(dx * u[0] + dy * u[1])
        # the text this far from the dimension line (its gap: from the line to the text)
        d['gap'] = max(0., abs((middle[0] - A[0]) * -u[1] + (middle[1] - A[1]) * u[0]) - height / 2)
        if abs(u[1]) <= 1e-9 or abs(u[0]) <= 1e-9:
            d.update(type=0, angle=0. if abs(u[1]) <= 1e-9 else 90.)   # horizontal, vertical: AutoCAD's « rotated »
        elif abs(dx * u[1] - dy * u[0]) <= 1e-9 * max(1., math.hypot(dx, dy)):
            d.update(type=1)   # aligned on its two points
        else:
            d.update(type=0, angle=math.degrees(math.atan2(u[1], u[0])))   # measured along its line only
        d['points'].update({13: P1, 14: P2, 10: B})
        d.update(value=value, text='' if text == cote_number(value) else text)
        return d
    lines = [s for s in strokes if s['kind'] == 'line']
    if len(members) == 3 and len(lines) == 1 and len(arrows) == 1 and (lines[0].get('name') == 'Rayon' or text.startswith('R')):
        a, b = path(lines[0])[0][0], path(lines[0])[0][-1]
        tip = path(arrows[0])[0][0]
        T, P = (a, b) if math.dist(a, tip) <= math.dist(b, tip) else (b, a)
        found = _arc_under(items, T, text)
        if found is None or math.dist(T, tip) > 1e-6:
            return None
        C, r = found
        d.update(type=4, value=r, placed=True, text='' if text == 'R' + cote_number(r) else text)
        d['points'].update({10: C, 15: T})
        return d
    if len(members) == 4 and len(lines) == 1 and len(arrows) == 2 and (lines[0].get('name') == 'Diamètre' or text.startswith('Ø')):
        a, b = path(lines[0])[0][0], path(lines[0])[0][-1]
        near, far = (b, a) if math.dist(b, middle) <= math.dist(a, middle) else (a, b)
        value = math.dist(a, b)
        if value < 1e-6:
            return None
        d.update(type=3, value=value, placed=True, text='' if text == 'Ø' + cote_number(value) else text)
        d['points'].update({10: far, 15: near})
        return d
    if len(members) == 4 and len(strokes) == 1 and len(arrows) == 2 and strokes[0]['kind'] == 'poly' and (strokes[0].get('name') == 'Cote d’angle' or text.endswith('°')):
        from precision_geometry import primitives
        g = primitives(strokes[0])
        if not g or not all(q['sweep'] for q in g) or any(math.dist(q['c'], g[0]['c']) > 1e-6 or abs(q['r'] - g[0]['r']) > 1e-6 for q in g):
            return None
        sweep = sum(q['sweep'] for q in g)
        C, r, start = g[0]['c'], g[0]['r'], g[0]['start']
        if not 1e-9 < abs(sweep) < 2 * math.pi - 1e-9:
            return None
        mid = start + sweep / 2
        d.update(type=5, value=abs(sweep), text='' if text == f'{math.degrees(abs(sweep)):.1f}°' else text)
        # AutoCAD measures from 13 to 14 counterclockwise (y up): Craft's arc turning the other way (y down) starts at 14
        first, last = (g[-1]['b'], g[0]['a']) if sweep > 0 else (g[0]['a'], g[-1]['b'])
        d['points'].update({13: first, 14: last, 15: C, 10: (C[0] + r * math.cos(mid), C[1] + r * math.sin(mid))})
        return d
    return None


# --- the export ------------------------------------------------------------------------------------

def mozart_dxf(items, workspace=None, infos=None, archives=None, model='', dimensions=True):
    """The text of the DXF (R2000, mm) of the drawing written like a Mozart pattern; 0.19.14 ``dimensions``: the cotes
    as AutoCAD's dimensions (else their lines and texts, as before)."""
    if not items:
        raise ValueError('Le dessin est vide.')
    validate(items)
    from craft_tools import cran_form, at_distance, annotation_baseline
    from curves import parts, cubics
    from editing import annotation_parts
    from stitching import hole_shapes
    from cad import guide_segments, LABELS
    w = _Writer(Path(__file__).with_name(TEMPLATE).read_text(encoding='cp1252'))
    labels = _labels(items)
    model = _clean((infos or {}).get('modele') or model, 120)
    pieces = []

    def crans_of(s):
        for mark in s.get('notches', []):
            try:
                p, n = at_distance(s, mark['distance'])
            except (ValueError, ZeroDivisionError, KeyError):
                continue
            u = tuple(mark['direction']) if mark.get('direction') else (n[0] * mark.get('side', 1), n[1] * mark.get('side', 1))
            yield p, u, mark.get('depth', 3.)

    def cran(p, u, depth):
        if depth <= 0:
            return
        w.insert('PitTacCT', (p[0], -p[1]), depth / CRAN_DEPTH, math.degrees(math.atan2(-u[1], u[0])) % 360)

    def annotation_text(s):
        for part in annotation_parts(s) if s.get('annotation') else [s]:
            if part.get('annotation'):
                tx, ty = annotation_baseline(part)
                w.text((tx, -ty), part.get('text_height', 3), part.get('label', ''), 'CRAFT_DIMENSION' if s.get('dimension_group') else '0',
                       -part.get('text_angle', 0.), centre='text_offset' in part)   # centred like Craft's DXF (cotes)
            else:
                pts, bulges, closed = _outline(part)
                w.polyline(pts, bulges, closed, 'CRAFT_DIMENSION')

    labelled = []
    cotes = {}
    for s in items:
        if s.get('dimension_group'):
            cotes.setdefault(s['dimension_group'], []).append(s)
    written = set()

    for s in items:
        group = s.get('dimension_group')
        if group and dimensions:
            # 0.19.14: each cote once, as AutoCAD's dimension when AutoCAD 2000 has one for it
            if group in written:
                continue
            written.add(group)
            found = cote_dimension(cotes[group], items)
            if found is not None:
                w.dimension(found, cotes[group])
            else:
                for q in cotes[group]:
                    annotation_text(q)
            continue
        role = _role(s)
        if s.get('is_notch'):
            form = cran_form(parts(s) if s.get('components') else [s])
            if form:
                cran(form['foot'], form['direction'], form['depth'])
            continue
        if s.get('drill'):
            c = (s['x'] + s['w'] / 2, s['y'] + s['h'] / 2)
            d = s.get('drill_diameter') or 0
            point = s.get('drill_point') or not d
            size = 2. if point else float(d)
            w.insert('Moz_Fust', (c[0], -c[1]), size, layer='PIT_DIS_MDT_FUST',
                     attribs=[('ETI', 'P' if point else _fmt(d), (1, -.5), 1.5, 0, False)])
            continue
        if s.get('preparation'):
            prep = s['preparation']
            layer, family = _prep_layer(prep)
            w.layer(layer, PREP_COLOURS[family])
            pts, bulges, _ = _outline(s)
            seed = inner_point(s)
            loops = [(pts, bulges)]
            if prep.get('kind') == 'surcoupe':
                loops = _surcoupe_loops(s, items) or loops
            data = [_fmt(prep.get('length')), _fmt(prep.get('thickness')), str(prep.get('couches') or 1) if prep.get('kind') == 'teinte' else '1', '', '', '']
            w.hatch(loops, layer, seed, xdata=[(1001, 'MOZ_PREP'), (1002, '{')] + [(1000, v) for v in data] + [(1002, '}')])
            label = _prep_label(prep)
            if label:
                w.text((seed[0], -seed[1]), 3., label, layer, centre=True)
            continue
        if s.get('piece_badge'):
            continue   # Craft's ID unique (Mozart numbers its pieces itself)
        if s.get('annotation') or s.get('dimension_group'):
            if s.get('identification') and s.get('owner_id'):
                labelled.append(s)   # a piece label: its data go in the piece's blocks (written as a text if it has no piece)
                continue
            annotation_text(s)
            continue
        for p, u, depth in crans_of(s):
            cran(p, u, depth)
        for hole in hole_shapes(s):
            w.circle((hole['x'] + hole['w'] / 2, hole['y'] + hole['h'] / 2), hole['w'] / 2, 'CRAFT_SEAM')
        shapes = parts(s) if s.get('components') else [s]
        if role in ('external', 'internal'):
            layer = 'PIT_DIS_AREA' if role == 'external' else 'PIT_DIS_TA_CONT_INT'
            pts, bulges, closed = _outline(s) if not s.get('components') else (path(s)[0], [0.] * len(path(s)[0]), path(s)[1])
            if closed and len(pts) > 1 and math.dist(pts[0], pts[-1]) < 1e-9:
                pts, bulges = pts[:-1], bulges[:-1]
            if len(pts) >= 2:
                w.polyline(pts, bulges, closed, layer)
                if role == 'external' and closed and (len(pts) >= 3 or any(bulges)):   # a round piece: 2 half arcs
                    pieces.append(s)
            continue
        layer = {'seam': 'CRAFT_SEAM', 'guide': 'CRAFT_GUIDE', 'dimension': 'CRAFT_DIMENSION'}.get(role, '0')
        for q in shapes:
            if q.get('spline'):
                for control in cubics(q):
                    values = [(70, 8), (71, 3), (72, 8), (73, 4), (74, 0)] + [(40, float(k)) for k in (0, 0, 0, 0, 1, 1, 1, 1)]
                    for a, b in control:
                        values += [(10, float(a)), (20, float(-b)), (30, 0.)]
                    w.seen(*[(a, -b) for a, b in control])
                    w.entity('SPLINE', layer, 'AcDbSpline', values)
            elif q['kind'] == 'line':
                w.line((q['x'], q['y']), (q['x'] + q['w'], q['y'] + q['h']), layer)
            elif q['kind'] == 'circle' and not q.get('ellipse'):
                w.circle((q['x'] + q['w'] / 2, q['y'] + q['h'] / 2), q['w'] / 2, layer)
            else:
                pts, bulges, closed = _outline(q)
                if len(pts) >= 2:
                    w.polyline(pts, bulges, closed, layer)

    owners = {s.get('piece_id') for s in pieces}
    for s in labelled:
        if s['owner_id'] not in owners or labels.get(s['owner_id'], {}).get(s['identification'].get('kind')) is not s:
            annotation_text(s)   # its piece is not a closed Coupe externe, or a 2nd label of the same kind: a text
    # Each piece: its data blocks inside it, at its labels (Craft's name and material texts) or near its upper left.
    for s in pieces:
        info = s.get('piece_info') or {}
        mine = labels.get(s.get('piece_id'), {})
        name_info = info.get('part_name') or (mine.get('part_name') or {}).get('identification') or {}
        material_info = info.get('material') or (mine.get('material') or {}).get('identification') or {}
        values = list(name_info.get('values') or [])[:3]
        values += [''] * (3 - len(values))
        if not any(values):
            values = ['', _clean(s.get('name'), 120) if s.get('name') not in (None, '', 'Pièce', 'Contour') else '', '']
        full = ' '.join(v for v in values if v)
        piece_model = _clean(name_info.get('model') or model, 120)
        x0, y0, x1, y1 = bounds([s])
        column = _column(workspace, (x0 + x1) / 2)
        # where: the name label's baseline (as mozart_import reads it back), else inside the piece
        label = mine.get('part_name')
        if label is not None:
            h = float(name_info.get('height') or label.get('text_height') or 2.)
            th = math.radians(label.get('text_angle', 0.))
            spot = (label['x'] - 2.8 * h * math.sin(th), label['y'] + 2.8 * h * math.cos(th))
            angle = -label.get('text_angle', 0.)
        else:
            h, angle = 2., 0.
            spot = inner_point(s)
        a = math.radians(angle)
        c, sn = math.cos(a), math.sin(a)
        base = (spot[0], -spot[1])

        def at(dx, dy):
            return (base[0] + dx * c - dy * sn, base[1] + dx * sn + dy * c)
        w.insert('PITNUM', at(6, 8.5), .25, angle, colour=2, attribs=[('NUMEROARTICOLO', piece_model, (0, 0), 8, 0, True)])
        w.insert('PITRIFNA', at(6, 8.5), .25, angle, colour=2)
        w.insert('PITDATIT', base, 1., angle, attribs=[
            ('TIPOLOGIA', values[1] or full, (-48.528, -16.428), 4, None, False), ('TESTO1', full, (0, 0), h, 0, False),
            ('IDFISSO', 'M7', (19.312, -16.604), 4, None, False), ('CODICE', '', (50.343, -16.604), 4, None, False),
            ('NU1', values[0], (80.429, -16.604), 4, None, False), ('NU2', values[2], (96.299, -16.604), 4, None, False),
            ('NU4', '', (-32, -26), 4, None, False), ('NU3', '', (-48, -26), 4, None, False), ('NU5', '', (-13, -26), 4, None, False),
            ('NU6', '', (3, -26), 4, None, False), ('NU7', '', (20, -26), 4, None, False)])
        names = list(material_info.get('values') or [])
        material = _clean(names[0] if names else '', 120)
        try:
            quantity = max(1, min(999, int(float(str(material_info.get('quantity') or 1).replace(',', '.')))))
        except ValueError:
            quantity = 1
        mlabel = mine.get('material')
        if mlabel is not None:
            mh = float(material_info.get('height') or mlabel.get('text_height') or 2.)
            th = math.radians(mlabel.get('text_angle', 0.))
            mspot = (mlabel['x'] - mh * math.sin(th), mlabel['y'] + mh * math.cos(th))
            mbase, mangle = (mspot[0], -mspot[1]), -mlabel.get('text_angle', 0.)
        else:
            mh, mbase, mangle = h, at(0, -8), angle
        # 0.19.13: the fiche de pièce (piece_sheet): Mozart's attributes from Craft's fields, the others as Mozart wrote
        # them; all the fields in Craft's data of the block too
        sheet = piece_sheet.mozart_attributes(material_info, quantity, material_info.get('refente') or '')

        def att(tag, default=''):
            return sheet.get(tag) if sheet.get(tag) not in (None, '') else default
        w.insert('PITDATIM', mbase, 1., mangle, attribs=[
            ('NUM14', att('NUM14'), (-23, -47), 4, None, False), ('NUM8', att('NUM8'), (-23, -40), 4, None, False), ('NUM7', att('NUM7'), (-23.124, -32.730), 4, None, False),
            ('TESTO1', f'{quantity} {material}' if material else '', (0, 0), mh, 0, False),
            ('MATERIALE', _material_code(material, archives, (column, column_types(workspace, column))), (-50, -17), 4, None, False),
            ('AREANETTA', att('AREANETTA', str(quantity)), (-78, -25), 4, None, False), ('NUM6', att('NUM6'), (-42, -40), 4, None, False),
            ('NUM4', att('NUM4', '0'), (-61, -40), 4, None, False), ('NUM2', att('NUM2', '0'), (-78, -40), 4, None, False), ('NUM12', att('NUM12'), (-61, -47), 4, None, False),
            ('NUM11', att('NUM11', '0'), (-78, -47), 4, None, False), ('NUM13', att('NUM13'), (-42, -47), 4, None, False), ('NUM3', att('NUM3', '1'), (-60.905, -33.018), 4, None, False),
            ('NUM1', att('NUM1', '0'), (-77.989, -32.709), 4, None, False), ('NUM5', att('NUM5', '0'), (-42.830, -32.730), 4, None, False),
            ('NPEZZI', str(quantity), (-78, -17), 4, None, False), ('IDFISSO', att('IDFISSO', '1'), (41.145, -24), 4, None, False),
            ('TESTO6', att('TESTO6'), (0, -25), 4, 0, False), ('NUM10', att('NUM10'), (-4, -40), 4, None, False), ('NUM15', att('NUM15'), (-4, -47), 4, None, False),
            ('NUM9', att('NUM9', '0'), (-4.204, -32.730), 4, None, False), ('TIPOLOGIA', att('TIPOLOGIA', '1'), (41, -32), 4, None, False),
            ('TESTO2', att('TESTO2'), (0, -3.3), 1, 0, False), ('TESTO5', att('TESTO5'), (0, -13.2), 1, 0, False), ('TESTO4', att('TESTO4'), (0, -9.9), 1, 0, False),
            ('TESTO3', att('TESTO3'), (0, -6.6), 1, 0, False), ('SFRIDOGEO', att('SFRIDOGEO', '0'), (41, -17), 4, None, False)],
            xdata=piece_sheet.xdata(material_info))

    # The base on « Présentation » (its rule, the lines between the columns, the titles), the model sheet.
    if workspace and workspace.get('visible', True):
        for a, b in guide_segments(workspace):
            w.line(a, b, 'Présentation')
        x = workspace.get('origin_x', 0.)
        header = workspace['header']
        from cad import column_labels, title_suffix
        labels, suffix = column_labels(workspace), title_suffix(workspace)   # 0.19.13: the base's own names
        for i, width in enumerate(workspace['widths']):
            title = labels[i] + (r'\H0.7x; ' + suffix if i == 1 and suffix else '')
            if not title.strip():
                x += width
                continue
            # 0.19.11: the width of the title's box given, as Mozart's (0 made AutoCAD « repair » the 6 titles)
            w.mtext((x + .1 * width, -.09 * header), .47 * header, '{\\fArial|b1|i0|c0|p34;' + title + '}', 'Présentation', .8 * width)
            x += width
        sheet = (workspace.get('origin_x', 0.) + .8 * workspace['widths'][0], -(header + 190.))
    else:
        x0, y0, x1, y1 = bounds(items)
        sheet = (x0 - 160., -(y0 + 160.))
    import model_info   # 0.19.13: Craft's fields Mozart has no known place for, in Craft's data of the sheet
    craft = model_info.craft_data(infos)
    w.insert('MOZ_INFO', sheet, columns=2, xdata=[(1001, 'MOZ_INFO'), (1002, '{')] + [(1000, v) for v in info_data(infos, model)] + [(1002, '}')]
             + ([(1001, piece_sheet.APP), (1002, '{')] + [(1000, _clean(v, 250)) for v in craft] + [(1002, '}')] if craft else []))
    return w.document()


# 0.19.14: the cotes of a DWG stay lines and texts: LibreDWG's dxf2dwg (0.13.3, shipped) loses the link of each
# DIMENSION to its block (it resolves no « block » name), and every version keeps the angle of a vertical one as its
# oblique angle and gives its block a scale of 0 (AutoCAD would have to rebuild or repair them).
DWG_DIMENSIONS = False


def export_mozart(file, items, workspace=None, infos=None, archives=None, model=''):
    """The drawing as a Mozart pattern: a DXF, or a DWG (2000) written from it by LibreDWG; an existing file is
    replaced only once the new one is complete. 0.19.14: the cotes of a DXF are AutoCAD's dimensions."""
    import os
    import shutil
    import tempfile
    from exchange import dxf_to_dwg
    target = Path(file)
    text = mozart_dxf(items, workspace, infos, archives, model or target.stem, dimensions=DWG_DIMENSIONS or target.suffix.lower() == '.dxf')
    with tempfile.TemporaryDirectory(prefix='Craft-Mozart-') as tmp:
        dxf = Path(tmp) / 'Mozart.dxf'
        dxf.write_text(text, encoding='cp1252', errors='replace')
        made = dxf if target.suffix.lower() == '.dxf' else dxf_to_dwg(dxf, Path(tmp) / 'Mozart.dwg')
        fd, name = tempfile.mkstemp(prefix='.Craft-', suffix=target.suffix, dir=target.parent)
        os.close(fd)
        temp_target = Path(name)
        try:
            shutil.copyfile(made, temp_target)
            temp_target.replace(target)
        finally:
            temp_target.unlink(missing_ok=True)
    return target


# --- 0.19.10 Exporter › DXF de coupe (AAMA-Teseo) ----------------------------------------------------------

AAMA_TEMPLATE = 'aama_base.dxf'   # tools/make_aama_base.py: a cutting DXF of Mozart, its pieces removed


def _anticlockwise(pts, bulges):
    """The outline turning anticlockwise (DXF axes), as Mozart writes its cutting pieces."""
    n = len(pts)
    area = sum(pts[k][0] * pts[(k + 1) % n][1] - pts[(k + 1) % n][0] * pts[k][1] for k in range(n))
    if abs(area) < 1e-9:
        area = sum(bulges)
    if area >= 0:
        return pts, bulges
    return [pts[0]] + pts[:0:-1], [-b for b in reversed(bulges)]


def _extent(pts, bulges):
    """(x0, y0, x1, y1) of a closed outline, its arcs included (Craft axes)."""
    xs, ys, n = [p[0] for p in pts], [p[1] for p in pts], len(pts)
    for k, b in enumerate(bulges):
        p, q = pts[k], pts[(k + 1) % n]
        dx, dy = q[0] - p[0], q[1] - p[1]
        length = math.hypot(dx, dy)
        if not b or length < 1e-12:
            continue
        off = length * (1 - b * b) / (4 * b)
        c = ((p[0] + q[0]) / 2 - dy / length * off, (p[1] + q[1]) / 2 + dx / length * off)
        r, a0, sweep = math.dist(c, p), math.atan2(p[1] - c[1], p[0] - c[0]), 4 * math.atan(b)
        for j in range(4):
            a = j * math.pi / 2
            delta = (a - a0) % (2 * math.pi) if sweep > 0 else (a0 - a) % (2 * math.pi)
            if delta <= abs(sweep):
                xs.append(c[0] + r * math.cos(a))
                ys.append(c[1] + r * math.sin(a))
    return min(xs), min(ys), max(xs), max(ys)


def cut_files(items, model='', when=None):
    """0.19.10 « Exporter › DXF de coupe (AAMA-Teseo) »: ({material: text of its DXF}, pieces left out), written
    like Mozart's cutting files (configuration « Mozart-AAMA-Teseo »), that its cutting software turns into MDX:
    one file per material; each piece (a closed Coupe extérieure with a material) is a block from its lower left
    corner: its outline (POLYLINE, layer 1, anticlockwise), its crans (POINT, layer 4: the foot, the depth, the
    angle into the piece), its pointés and mèches (POINT, layer 13), its texts (layer 19: model, name, quantity
    and material; layer 77: the AAMA fields); the block is inserted where the piece is; the file's texts below
    (layer 1). A piece without a material is left out (counted)."""
    import datetime
    from craft_version import VERSION
    from craft_tools import cran_form, at_distance
    from curves import parts
    if not items:
        raise ValueError('Le dessin est vide.')
    validate(items)
    when = when or datetime.datetime.now()
    labels = _labels(items)
    model = _clean(model, 120)
    notches = [s for s in items if s.get('is_notch')]
    drills = [s for s in items if s.get('drill')]
    groups, missing = {}, 0
    for s in items:
        if s.get('is_notch') or s.get('drill') or s.get('preparation') or s.get('piece_badge') or s.get('annotation') or s.get('dimension_group'):
            continue
        if _role(s) != 'external':
            continue
        if s.get('components'):
            pts, closed = path(s)
            bulges = [0.] * len(pts)
        else:
            pts, bulges, closed = _outline(s)
        if closed and len(pts) > 1 and math.dist(pts[0], pts[-1]) < 1e-9:
            pts, bulges = pts[:-1], bulges[:-1]
        if not closed or not (len(pts) >= 3 or any(bulges)):
            continue
        info = s.get('piece_info') or {}
        mine = labels.get(s.get('piece_id'), {})
        name_info = info.get('part_name') or (mine.get('part_name') or {}).get('identification') or {}
        material_info = info.get('material') or (mine.get('material') or {}).get('identification') or {}
        names = list(material_info.get('values') or [])
        material = _clean(names[0] if names else '', 120)
        if not material:
            missing += 1
            continue
        values = (list(name_info.get('values') or [])[:3] + ['', '', ''])[:3]
        if not any(values):
            values = ['', _clean(s.get('name'), 120) if s.get('name') not in (None, '', 'Pièce', 'Contour') else '', '']
        try:
            quantity = max(1, min(999, int(float(str(material_info.get('quantity') or 1).replace(',', '.')))))
        except ValueError:
            quantity = 1
        groups.setdefault(material, []).append(dict(shape=s, pts=pts, bulges=bulges, name=' '.join(v for v in values if v),
                                                     model=_clean(name_info.get('model') or model, 120), quantity=quantity))
    template = Path(__file__).with_name(AAMA_TEMPLATE).read_text(encoding='cp1252')
    lines = template.split('\n')
    if lines and lines[-1] == '':
        lines.pop()
    base = list(zip(lines[0::2], lines[1::2]))
    handles, table, model_space, kind, fields = [], None, None, None, {}
    for c, v in base + [('0', 'EOF')]:
        if c.strip() == '0':
            if kind == 'TABLE' and fields.get('2') == 'BLOCK_RECORD':
                table = fields.get('5')
            if kind == 'BLOCK_RECORD' and fields.get('2') == '*Model_Space':
                model_space = fields.get('5')
            kind, fields = v.strip(), {}
        else:
            fields.setdefault(c.strip(), v.strip())
            if c.strip() in ('5', '105'):
                handles.append(int(v.strip(), 16))
    if not (table and model_space and handles):
        raise ValueError('Gabarit DXF de coupe invalide.')
    stamp = when.strftime('PITBT%Y%m%d-%H%M%S')
    head = [('Style Name: ' + model, 0), ('Creation Date: ' + when.strftime('%d/%m/%Y'), 1), ('Creation Time: ' + when.strftime('%Hh%M.%S'), 2),
            ('Author: Craft ' + VERSION, 3), ('Config: AAMA-Teseo', 4), ('Sample Size: Base', 6), ('Grade Rule Table:', 7), ('Units: METRIC', 8)]
    files = {}
    for material, pieces in groups.items():
        counter = [max(handles)]

        def h():
            counter[0] += 1
            return format(counter[0], 'X')

        def n(value):
            return _num(round(float(value), 4) + 0.)

        records, blocks, entities, seen = [], [], [], []
        for k, piece in enumerate(pieces):
            s, name = piece['shape'], stamp + ('' if k == 0 else str(k - 1))
            x0, y0, x1, y1 = _extent(piece['pts'], piece['bulges'])

            def local(p):
                return (p[0] - x0, y1 - p[1])
            pts, bulges = _anticlockwise([local(p) for p in piece['pts']], [-b for b in piece['bulges']])
            record, insert, block, poly = h(), h(), h(), h()
            records += [('0', 'BLOCK_RECORD'), ('5', record), ('330', table), ('100', 'AcDbSymbolTableRecord'), ('100', 'AcDbBlockTableRecord'), ('2', name),
                        ('340', '0'), ('102', '{BLKREFS'), ('331', insert), ('102', '}'), ('1001', 'ACAD'), ('1000', 'DesignCenter Data'),
                        ('1002', '{'), ('1070', '1'), ('1070', '4'), ('1002', '}')]
            blocks += [('0', 'BLOCK'), ('5', block), ('330', record), ('100', 'AcDbEntity'), ('8', '0'), ('100', 'AcDbBlockBegin'), ('2', name), ('70', '0'),
                       ('10', '0.0'), ('20', '0.0'), ('30', '0.0'), ('3', name), ('1', ''),
                       ('0', 'POLYLINE'), ('5', poly), ('330', record), ('100', 'AcDbEntity'), ('8', '1'), ('100', 'AcDb2dPolyline'), ('66', '1'),
                       ('10', '0.0'), ('20', '0.0'), ('30', '0.0'), ('70', '1')]
            for (x, y), b in zip(pts, bulges):
                blocks += [('0', 'VERTEX'), ('5', h()), ('330', poly), ('100', 'AcDbEntity'), ('8', '1'), ('100', 'AcDbVertex'), ('100', 'AcDb2dVertex'),
                           ('10', n(x)), ('20', n(y)), ('30', '0.0')] + ([('42', n(b))] if round(b, 4) else [])
            blocks += [('0', 'SEQEND'), ('5', h()), ('330', poly), ('100', 'AcDbEntity'), ('8', '1')]
            # its crans: marks on the piece, Cran shapes of the piece (or on its outline when they have none)
            crans = []
            for mark in s.get('notches', []):
                try:
                    p, normal = at_distance(s, mark['distance'])
                except (ValueError, ZeroDivisionError, KeyError):
                    continue
                u = tuple(mark['direction']) if mark.get('direction') else (normal[0] * mark.get('side', 1), normal[1] * mark.get('side', 1))
                crans.append((p, u, mark.get('depth', 3.)))
            for c in notches:
                if c.get('owner_id') not in (None, s.get('piece_id')):
                    continue
                form = cran_form(parts(c) if c.get('components') else [c])
                if not form:
                    continue
                if c.get('owner_id') is None and not (x0 - .5 <= form['foot'][0] <= x1 + .5 and y0 - .5 <= form['foot'][1] <= y1 + .5):
                    continue
                crans.append((form['foot'], form['direction'], form['depth']))
            flat = [tuple(q) for q in path(s)[0]]
            for p, u, depth in crans:
                if depth <= 0:
                    continue
                # the angle into the piece (Mozart's crans read back are drawn outwards)
                size = math.hypot(*u) or 1.
                u = (u[0] / size, u[1] / size)
                step = min(.5, depth / 2)
                if not _inside(flat, (p[0] + u[0] * step, p[1] + u[1] * step)) and _inside(flat, (p[0] - u[0] * step, p[1] - u[1] * step)):
                    u = (-u[0], -u[1])
                x, y = local(p)
                blocks += [('0', 'POINT'), ('5', h()), ('330', record), ('100', 'AcDbEntity'), ('8', '4'), ('100', 'AcDbPoint'), ('10', n(x)), ('20', n(y)),
                           ('30', n(depth)), ('39', n(depth)), ('50', n(math.degrees(math.atan2(-u[1], u[0])) % 360))]
            for d in drills:
                c = (d['x'] + d['w'] / 2, d['y'] + d['h'] / 2)
                if d.get('owner_id') is not None and d.get('owner_id') != s.get('piece_id'):
                    continue
                if d.get('owner_id') is None and not _inside(flat, c):
                    continue
                x, y = local(c)
                blocks += [('0', 'POINT'), ('5', h()), ('330', record), ('100', 'AcDbEntity'), ('8', '13'), ('62', '7'), ('100', 'AcDbPoint'),
                           ('10', n(x)), ('20', n(y)), ('30', '0.0')]
            # its texts: inside it (layer 19), the AAMA fields under it (layer 77)
            ix, iy = local(inner_point(s))
            for row, (text, height) in enumerate(((piece['model'], 2.), (piece['name'], 2.), (f"{piece['quantity']} {material}", 2.))):
                if text:
                    blocks += [('0', 'TEXT'), ('5', h()), ('330', record), ('100', 'AcDbEntity'), ('8', '19'), ('100', 'AcDbText'),
                               ('10', n(ix)), ('20', n(iy + 4 - 4 * row)), ('30', '0.0'), ('40', n(height)), ('1', text), ('100', 'AcDbText')]
            fields77 = ('Piece Name: ' + piece['name'], 'Size: Base', 'Annotation: ' + piece['name'], f"Quantity: {piece['quantity']}", 'Category:',
                        'Fabric: ' + material, 'Material: ' + material)
            for row, text in enumerate(fields77):
                blocks += [('0', 'TEXT'), ('5', h()), ('330', record), ('100', 'AcDbEntity'), ('8', '77'), ('100', 'AcDbText'),
                           ('10', '0.0'), ('20', n(-3 * (row + 1))), ('30', '0.0'), ('40', '1.0'), ('1', text), ('100', 'AcDbText')]
            blocks += [('0', 'ENDBLK'), ('5', h()), ('330', record), ('100', 'AcDbEntity'), ('8', '0'), ('100', 'AcDbBlockEnd')]
            entities += [('0', 'INSERT'), ('5', insert), ('330', model_space), ('100', 'AcDbEntity'), ('8', '1'), ('100', 'AcDbBlockReference'),
                         ('2', name), ('10', n(x0)), ('20', n(-y1)), ('30', '0.0')]
            seen += [(x0, -y1), (x1, -y0)]
        left, low = min(p[0] for p in seen), min(p[1] for p in seen)
        for text, row in head:
            entities += [('0', 'TEXT'), ('5', h()), ('330', model_space), ('100', 'AcDbEntity'), ('8', '1'), ('100', 'AcDbText'),
                         ('10', n(left)), ('20', n(low - 20 - 3 * row)), ('30', '0.0'), ('40', '1.0'), ('1', text), ('100', 'AcDbText')]
        out, section, table_name, previous = [], None, None, None
        for c, v in base:
            code, value = c.strip(), v.strip()
            if code == '0' and value == 'ENDTAB' and table_name == 'BLOCK_RECORD':
                out += records
            if code == '0' and value == 'ENDSEC' and section == 'BLOCKS':
                out += blocks
            if code == '0' and value == 'ENDSEC' and section == 'ENTITIES':
                out += entities
            if previous == ('0', 'SECTION') and code == '2':
                section = value
            if previous == ('0', 'TABLE') and code == '2':
                table_name = value
            if code == '0' and value == 'ENDTAB':
                table_name = None
            out.append((c, v))
            previous = (code, value)
        xs, ys = [p[0] for p in seen], [p[1] for p in seen]
        for k, (c, v) in enumerate(out[:-1]):
            if c.strip() == '9' and v.strip() == '$HANDSEED':
                out[k + 1] = (out[k + 1][0], format(counter[0] + 1, 'X'))
            for key, (x, y) in (('$EXTMIN', (min(xs), min(ys))), ('$EXTMAX', (max(xs), max(ys)))):
                if c.strip() == '9' and v.strip() == key:
                    out[k + 1], out[k + 2] = (out[k + 1][0], n(x)), (out[k + 2][0], n(y))
        files[material] = '\n'.join(x for p in out for x in p) + '\n'
    return files, missing


def unnamed(items):
    """0.19.11 Imprimer / PDF: [(piece, name, material)] of the closed Coupe extérieure pieces without a name or without a
    material, when at least one piece of the drawing has one (a drawing whose pieces are never named says nothing)."""
    labels = _labels(items)
    pieces, named = [], False
    for s in items:
        if s.get('is_notch') or s.get('drill') or s.get('preparation') or s.get('piece_badge') or s.get('annotation') or s.get('dimension_group'):
            continue
        if _role(s) != 'external':
            continue
        pts, closed = path(s)
        if not closed or len(pts) < 3:
            continue
        info = s.get('piece_info') or {}
        mine = labels.get(s.get('piece_id'), {})
        name_info = info.get('part_name') or (mine.get('part_name') or {}).get('identification') or {}
        material_info = info.get('material') or (mine.get('material') or {}).get('identification') or {}
        name = ' '.join(v for v in (name_info.get('values') or []) if v) or (s.get('name') if s.get('name') not in (None, '', 'Pièce', 'Contour') else '')
        material = ' '.join(v for v in (material_info.get('values') or []) if v)
        named = named or bool(name_info.get('values') and any(name_info['values'])) or bool(material)
        if not name or not material:
            pieces.append((s, _clean(name, 60), _clean(material, 60)))
    return pieces if named else []
