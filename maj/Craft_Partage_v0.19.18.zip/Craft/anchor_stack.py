"""0.18.5: anchors stacked under the pointer (a circle's centre on a line's end, two close corners…).

Tab goes from one to the next; a click on a stack asks which one is meant (a small menu at the mouse).
Same point and same kind from several objects (two sides meeting, two lines ending together) is one
entry: nothing to choose there. The grips of the selection are handled the same way."""
import math
from cad import object_anchors, bounds

KIND = {'endpoint': 'Extrémité', 'midpoint': 'Milieu', 'quarter': 'Quart', 'center': 'Centre',
        'quadrant': 'Quadrant', 'centroid': 'Centre géométrique', 'node': 'Nœud'}   # 0.19.13
GRIP = {'move': 'Centre', 'endpoint': 'Extrémité', 'vertex': 'Sommet', 'pvertex': 'Sommet', 'edge': 'Milieu du côté',
        'corner': 'Coin', 'circle_axis': 'Quadrant', 'ellipse_axis': 'Quadrant', 'arc': 'Arc',
        'spline_fit': 'Point', 'spline_tangent': 'Tangente', 'spline_control': 'Point de contrôle'}


def object_word(s):
    if s.get('drill'):
        return 'du pointé' if s.get('drill_point') else 'de la mèche'
    if s.get('ellipse'):
        return 'de l’ovale'
    if s.get('spline'):
        return 'de la spline'
    if s.get('stitch'):
        return 'de la piqûre'
    kind = s.get('kind')
    if kind == 'circle':
        return 'du cercle'
    if kind == 'line':
        return 'de la ligne'
    if kind == 'rect':
        return 'du rectangle'
    if kind == 'poly' and len(s.get('points', [])) == 2 and not s.get('closed') and any(s.get('bulges', [])):
        return 'de l’arc'
    return 'de la polyligne'


def candidates(raw, items, indices, modes, tol):
    out = []
    for i in indices:
        s = items[i]
        try:
            b = bounds([s])
        except (ValueError, KeyError, TypeError):
            continue
        if not (b[0] - tol <= raw[0] <= b[2] + tol and b[1] - tol <= raw[1] <= b[3] + tol):
            continue
        if s.get('drill'):
            c = (s['x'] + s['w'] / 2, s['y'] + s['h'] / 2)
            if 'center' in modes and math.dist(c, raw) <= tol:
                out.append((c, 'center', i))
            continue
        try:
            anchors = object_anchors(s)
        except (ValueError, KeyError, TypeError, IndexError):
            continue
        out += [(q, typ, i) for q, typ in anchors if typ in modes and typ in KIND and math.dist(q, raw) <= tol]
    return out


def distinct(entries, raw, near):
    """Entries within `near` of the closest one, one per (point, kind)."""
    if len(entries) < 2:
        return []
    best = min(entries, key=lambda c: math.dist(c[0], raw))
    out = []
    for q, typ, i in sorted(entries, key=lambda c: math.dist(c[0], raw)):
        if math.dist(q, best[0]) > near:
            continue
        if any(t == typ and math.dist(q, p) < 1e-6 for p, t, _ in out):
            continue
        out.append((q, typ, i))
    return out if len(out) >= 2 else []


def stack(raw, items, indices, modes, tol, near):
    return distinct(candidates(raw, items, indices, modes, tol), raw, near)


def canon(entry):
    q, typ, i = entry
    return (round(q[0], 6), round(q[1], 6), str(typ), -1 if i is None else i)


def key(entries):
    """The same stack whatever the order of the distances to the pointer (a small move keeps a choice)."""
    return tuple(sorted(canon(e) for e in entries))


def ordered(entries):
    return sorted(entries, key=canon)


def chosen(entries, pick):
    """The entry chosen with Tab or the question for this very stack, or None."""
    if not entries or not pick or pick[0] != key(entries):
        return None
    return next((e for e in entries if canon(e) == pick[1]), None)


def next_pick(entries, pick):
    """Tab: the next entry in a fixed order (the closest one first when nothing was chosen yet)."""
    order = ordered(entries)
    current = chosen(entries, pick) or entries[0]
    k = [canon(e) for e in order].index(canon(current))
    return (key(entries), canon(order[(k + 1) % len(order)]))


def pick_of(entries, entry):
    return (key(entries), canon(entry))


def label_of(entries, items, entry, grips=False):
    order = ordered(entries)
    names = labels(order, items, grips)
    return names[[canon(e) for e in order].index(canon(entry))]


def labels(entries, items, grips=False):
    names = []
    for q, typ, i in entries:
        if grips:
            word = GRIP.get(typ[0] if isinstance(typ, tuple) else typ, 'Poignée')
        else:
            word = KIND.get(typ, typ)
        names.append(f'{word} {object_word(items[i])}' if i is not None and i < len(items) else word)
    # Two identical names (two close ends of two lines): numbered.
    for name in set(names):
        if names.count(name) > 1:
            k = 0
            for j, n in enumerate(names):
                if n == name:
                    k += 1
                    names[j] = f'{n} ({k})'
    return names
