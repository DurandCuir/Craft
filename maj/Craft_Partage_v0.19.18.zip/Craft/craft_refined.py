"""Compact Craft interface, document tabs and directional multi-selection."""
import tkinter as tk
from tkinter import ttk,messagebox,filedialog,colorchooser
import copy,math,uuid,time
from pathlib import Path
from refined_icons import draw
from selection import select as window_select,overlay_pixel
import base64
from cad import default_workspace,read_document
from ui_widgets import contrast_color

def shade(color,delta):
    return '#'+''.join(f'{max(0,min(255,int(color[i:i+2],16)+delta)):02x}' for i in (1,3,5))


def box_minus(a,b):
    """0.19.7: the rectangle a (x0, y0, x1, y1) less b, in at most 4 rectangles: the bands above and
    below b (as wide as a), then the parts beside it."""
    ax0,ay0,ax1,ay1=a;bx0,by0,bx1,by1=b
    if ax1<=ax0 or ay1<=ay0:return []
    if bx0>=ax1 or bx1<=ax0 or by0>=ay1 or by1<=ay0 or bx1<=bx0 or by1<=by0:return [a]
    out=[];top,bottom=max(ay0,by0),min(ay1,by1)
    if by0>ay0:out.append((ax0,ay0,ax1,by0))
    if by1<ay1:out.append((ax0,by1,ax1,ay1))
    if bx0>ax0:out.append((ax0,top,bx0,bottom))
    if bx1<ax1:out.append((bx1,top,ax1,bottom))
    return [r for r in out if r[2]>r[0] and r[3]>r[1]]


def refine(Base):
    class Refined(Base):
        def __init__(self):
            self.documents=[];self.current_doc=0;self.document_sections=[{'id':'plan','title':'Plan'}];self.active_section='plan';self.selected_set=set();self.box_start=None;self.popup=None
            self.line_types={'Plein':[], 'Pointillés':[.5,1.5], 'Tirets':[4,2], 'Mixte':[6,2,1,2]};self.line_type='Plein';self._palette_entries=[];self._inside_plan=False
            self._tabs_busy=False;self._skip_current_guard=False;self._last_pointer=(100,100);self.doc_key=uuid.uuid4().hex
            super().__init__();self.documents=[self.capture_doc()];self.refresh()
        def build(self):
            super().build()
            # No persistent instructional text, placeholder layouts, or bottom input slab.
            self.command_frame.pack_forget();self.header.pack_forget()
            self.unit_label=self.label(self.footer,text=self.units.get());self.unit_label.pack(side='left',padx=8)
            self.command_entry=tk.Entry(self.canvas,textvariable=self.command_value,bg='white',fg='black',insertbackground='black',relief='solid',bd=1,width=10,font=('Segoe UI',10))
            self.command_entry.bind('<Return>',self.enter_dimension)
            self.command_entry.bind('<KP_Enter>',self.enter_dimension)
            self.command_entry.bind('<Escape>',lambda e:self.escape())
            self.command_entry.place_forget();self.command_entry._modern_keep=True   # 0.19.0: the input bubble stays plain (white)
            darker=shade(self.p['panel'],-10 if contrast_color(self.p['panel'])=='#ffffff' else -7)
            self.history.configure(bg=darker,fg=contrast_color(darker),height=2)
            from workspace_ui import VERSION
            self.icon(self.footer,'info',self.about,'Craft · version '+VERSION,side='right')
            self.tabbar=tk.Frame(self.root_frame,bg=self.p['panel'],height=32)
            self.tabbar.pack_propagate(False)
            self.tabbar.pack(fill='x',before=self.topdock)
            self.body.pack_propagate(False) # Reserve room for the lower Plan row on smaller windows.
            self.section_tabs=tk.Frame(self.footer,bg=self.p['panel'],height=28);self.section_tabs.pack_propagate(False)
            self.section_tabs.pack(side='left',fill='x',expand=True,before=self.unit_label);self.unit_label.pack_forget();self.rebuild_tabs()
            # Caption data only: no additional row below the menu.
            self.caption_row=tk.Frame(self.root_frame,bg=self.p['panel'])
            self.window_caption=tk.Label(self.caption_row,bg=self.p['panel'],fg=self.p['ui_ink'],font=('Segoe UI',9),anchor='center');# Native titlebar controller draws this text on Windows.
            self.update_window_title()
            self.canvas.bind('<Enter>',self.enter_plan);self.canvas.bind('<Leave>',self.leave_plan)
            for w in self.topdock.winfo_children():w.bind('<Button-3>',self.category_menu)
        def read_custom(self):
            super().read_custom()
            self.profiles[self.active_profile]['dash']=copy.deepcopy(self.line_types[self.line_type])
        def icon_color(self,name):
            dark=contrast_color(self.p['panel'])=='#ffffff'
            # 0.18.5: one colour per family, the colour of what the tool puts on the plan (every cote blue,
            # crans and mèches purple, piqûre green…); drawing and editing tools stay in the ink colour.
            cote='#79bad6' if dark else '#387993';purple='#c696cf' if dark else '#8a4e99'
            colors={'external':'#ed5555' if dark else '#c52d35','internal':'#7294e0' if dark else '#192d72',
                    'open':'#e1b558' if dark else '#9b7018','save':'#70a7e8' if dark else '#315eaa',
                    'undo':'#74bac8' if dark else '#30798c','redo':'#74bac8' if dark else '#30798c',
                    'measure':'#e0be68' if dark else '#94701d',
                    'dimension':cote,'dimension_aligned':cote,'radius':cote,'diameter':cote,'arc_length':cote,'angle_dimension':cote,
                    'material':'#dba275' if dark else '#97643a','part_name':'#8fbedc' if dark else '#447894','piece_id':'#4fbf6a' if dark else '#2a8a45',
                    'notch':purple,'copy_notch':purple,'drill':purple,'belt_holes':purple,'buckle_slot':purple,
                    'stitch':'#5cc98a' if dark else '#2f8a55','stitch_part':'#5cc98a' if dark else '#2f8a55',
                    'surcoupe':'#a9b4ff' if dark else '#4f5bb5','surcoupe_simple':'#a9b4ff' if dark else '#4f5bb5',
                    'preparation':'#ff8cc6' if dark else '#c2457f','prep_layer':'#ff8cc6' if dark else '#c2457f',
                    'precut_layer':'#a9b4ff' if dark else '#4f5bb5','recut_layer':'#a9b4ff' if dark else '#4f5bb5'}
            return colors.get(name,contrast_color(self.p['panel']))
        def build_line_picker(self,parent):
            custom=self.prefs.get('line_types',{})
            if custom:self.line_types=copy.deepcopy(custom)
            self.line_type=self.prefs.get('line_type','Plein')
            if self.line_type not in self.line_types:self.line_type=next(iter(self.line_types))
            self.line_preview=tk.Canvas(parent,width=170,height=26,bg=self.p['panel'],highlightthickness=0,cursor='arrow')   # 0.19.0: a rounded field
            self.line_preview.pack(side='left',padx=4,pady=3);self.line_preview.bind('<Button-1>',self.line_menu);self.profiles[self.active_profile]['dash']=copy.deepcopy(self.line_types[self.line_type]);self.paint_line_picker()
        def paint_line_picker(self):
            if not getattr(self,'line_preview',None) or not self.line_preview.winfo_exists():return
            c=self.line_preview;c.delete('all');ink=contrast_color(self.field_background())
            c.create_line(12,12,133,12,fill=ink,width=1.4,dash=tuple(max(1,round(v*3)) for v in self.line_types[self.line_type]))
            c.create_polygon(150,10,158,10,154,14,fill=ink,outline='')
        def line_menu(self,e):
            self.close_palette();w=tk.Toplevel(self);self.popup=w;w.overrideredirect(True)
            t=__import__('modern_style').tokens_for(self.p)   # 0.19.0: the list in the colours of the menus
            w.configure(bg=t['menu'],highlightthickness=1,highlightbackground=t['field_border'])
            w.geometry(f'+{self.line_preview.winfo_rootx()}+{self.line_preview.winfo_rooty()+self.line_preview.winfo_height()}')
            for name,dash in self.line_types.items():
                c=tk.Canvas(w,width=245,height=30,bg=t['menu'],highlightthickness=0,cursor='arrow');c.pack()
                c.create_line(10,15,132,15,fill=t['text'],width=1.4,dash=tuple(max(1,round(v*3)) for v in dash))
                c.create_text(145,15,text=name,anchor='w',fill=t['text'],font=__import__('modern_style').font(10))
                c.bind('<Button-1>',lambda e,n=name:(self.set_line_type(n),self.close_palette()))
                c.bind('<Enter>',lambda e,c=c:c.configure(bg=t['accent_soft']));c.bind('<Leave>',lambda e,c=c:c.configure(bg=t['menu']))
            w.bind('<Escape>',lambda e:self.close_palette());w.bind('<FocusOut>',lambda e:self.close_palette());w.focus_set()
        def set_line_type(self,name):
            if name not in self.line_types:return
            self.line_type=name;self.profiles[self.active_profile]['dash']=copy.deepcopy(self.line_types[name])
            ids=self.selected_set or ({self.selected} if self.selected is not None else set())
            if ids:
                from craft_tools import style
                self.snapshot()
                for i in ids:
                    if self.items[i].get('is_notch'):continue
                    st=style(self.items[i]);st['dash']=copy.deepcopy(self.line_types[name]);self.items[i]['style']=st
            self.persist_preferences();self.paint_line_picker();self.refresh()
        def edit_line_types(self):
            win=self.dialog('Types de lignes');selected=tk.StringVar(value=self.line_type)
            ttk.Combobox(win,textvariable=selected,values=list(self.line_types),state='readonly').pack(padx=16,pady=10)
            name=tk.StringVar(value=self.line_type);dash=tk.StringVar(value=' '.join(map(str,self.line_types[self.line_type])))
            width=tk.StringVar(value=str(self.profiles[self.active_profile]['width']))
            for label,var in [('Nom',name),('Tirets / espaces (mm)',dash),('Épaisseur (mm)',width)]:
                self.label(win,label).pack(anchor='w',padx=16);self.entry(win,var,30).pack(padx=16,pady=5)
            def load(*args):name.set(selected.get());dash.set(' '.join(map(str,self.line_types[selected.get()])))
            selected.trace_add('write',load)
            def save():
                try:
                    n=name.get().strip();d=[float(v.replace(',','.')) for v in dash.get().split()];th=float(width.get().replace(',','.'))
                    if not n or len(d)%2 or len(d)>12 or any(not .05<=v<=100 for v in d) or not .01<=th<=5:raise ValueError('Motif ou épaisseur invalide.')
                    self.line_types[n]=d;self.profiles[self.active_profile]['width']=th;self.set_line_type(n);win.destroy()
                except ValueError as exc:messagebox.showerror('Types de lignes',str(exc),parent=win)
            self.button(win,'Valider',save).pack(anchor='e',padx=16,pady=12)
        def persist_preferences(self):
            self.prefs.update(line_types=copy.deepcopy(self.line_types),line_type=self.line_type)
            super().persist_preferences()
        # 0.19.9: what belongs to this PC or this session, not a work preference: never in a profile, never put back by
        # « Charger ce profil » (a profile saved before kept them: recent files, last folder, printer… came back).
        NOT_IN_PROFILE=('interface_profiles','interface_profile','recent_files','last_folder','printer','oda_converter',
                        'pdf_print_test_offered','pdf_square_test_offered','fiche_choice')
        def interface_profile_dialog(self):
            win=self.dialog('Mon profil d’interface');profiles=self.prefs.setdefault('interface_profiles',{})
            name=tk.StringVar(value=self.prefs.get('interface_profile','Mon profil'))
            ttk.Combobox(win,textvariable=name,values=list(profiles),width=28).pack(padx=18,pady=14)
            def save():
                n=name.get().strip()
                if not n:return
                self.persist_preferences();data={k:v for k,v in copy.deepcopy(self.prefs).items() if k not in self.NOT_IN_PROFILE}
                profiles[n]=data;self.prefs['interface_profile']=n;self.persist_preferences();win.destroy()
            def restore():
                n=name.get()
                if n not in profiles:return
                self.prefs.update({k:v for k,v in copy.deepcopy(profiles[n]).items() if k not in self.NOT_IN_PROFILE});self.prefs['interface_profile']=n
                from ui_widgets import auto_palette
                self.p=auto_palette(self.prefs);self.layout=copy.deepcopy(self.prefs.get('toolbar_layout',{}));self.variants=copy.deepcopy(self.prefs.get('tool_variants',{}))
                self.profiles=copy.deepcopy(self.prefs.get('profiles',self.profiles));self.line_types=copy.deepcopy(self.prefs.get('line_types',self.line_types));self.line_type=self.prefs.get('line_type','Plein')
                self.grid.set(self.prefs.get('grid',False));self.ortho.set(self.prefs.get('ortho',False))
                for k,v in self.snap_vars.items():v.set(k in self.prefs.get('snaps',[]))
                unit=self.prefs.get('units','mm');win.destroy()
                # 0.19.9: another unit through unit_change() (the panel's fields converted, last_unit kept right; it saves
                # the preferences and rebuilds the window)
                if unit in ('mm','cm') and unit!=self.units.get():self.units.set(unit);self.unit_change();return
                self.persist_preferences();self.rebuild_ui()
            self.button(win,'Enregistrer le profil actuel',save).pack(fill='x',padx=18,pady=4)
            self.button(win,'Charger ce profil',restore).pack(fill='x',padx=18,pady=(4,14))
        def crosshair_dialog(self):
            win=self.dialog('Curseur');variables={}
            for key,title,default in [('cross_size','Longueur des bras (px, 0 = tout le plan)',90),('cross_width','Épaisseur (px)',1),('cross_box','Carré central (px)',6)]:
                self.label(win,title).pack(anchor='w',padx=16,pady=3);variables[key]=tk.StringVar(value=str(self.prefs.get(key,default)));self.entry(win,variables[key],30).pack(padx=16,pady=3)
            color=tk.StringVar(value=self.prefs.get('cross_color','auto'))
            def choose():
                c=colorchooser.askcolor(parent=win)[1]
                if c:color.set(c)
            self.button(win,'Couleur…',choose).pack(side='left',padx=16,pady=14)
            self.button(win,'Automatique',lambda:color.set('auto')).pack(side='left')
            def save():
                try:
                    values={k:float(v.get().replace(',','.')) for k,v in variables.items()}
                    if not 0<=values['cross_size']<=3000 or not .5<=values['cross_width']<=5 or not 0<=values['cross_box']<=40:raise ValueError('Dimensions hors limites.')
                    self.prefs.update(values,cross_color=color.get());self.persist_preferences();win.destroy();self.draw_crosshair()
                except ValueError as exc:messagebox.showerror('Curseur',str(exc),parent=win)
            self.button(win,'Valider',save).pack(side='right',padx=16,pady=14)
        def enter_plan(self,e):self._inside_plan=True;self.cursor_screen=(e.x,e.y);self.draw_crosshair()
        def leave_plan(self,e=None):self._inside_plan=False;self.canvas.delete('crosshair')
        def pointer_cursor(self,name):
            # 0.16.26: configuring the canvas makes Tk redraw ALL of it; doing that on every
            # mouse move was the main pointer latency. Only change a different cursor.
            try:
                if self.canvas.cget('cursor')!=name:self.canvas.configure(cursor=name)
            except tk.TclError:pass
        def draw_crosshair(self):
            if not hasattr(self,'canvas'):return
            self.pointer_cursor('none')
            if not self._inside_plan:self.canvas.delete('crosshair');return
            x,y=self.cursor_screen;size=self.prefs.get('cross_size',90);size=size or max(self.canvas.winfo_width(),self.canvas.winfo_height())
            box=self.prefs.get('cross_box',6)/2;ink=self.prefs.get('cross_color','auto');ink=self.p['ink'] if ink=='auto' else ink
            width=self.prefs.get('cross_width',1)
            shapes=[(x-size,y,x-box,y),(x+box,y,x+size,y),(x,y-size,x,y-box),(x,y+box,x,y+size)]+([(x-box,y-box,x+box,y+box)] if box else [])
            # Move the existing crosshair instead of deleting and re-creating it on every motion.
            ids=tuple(self.canvas.find_withtag('crosshair') or ());style=(ink,width,len(shapes))
            if len(ids)==len(shapes) and self.__dict__.get('_crosshair_style')==style:
                for item,xy in zip(ids,shapes):self.canvas.coords(item,*xy)
                self.canvas.tag_raise('crosshair');return
            self.canvas.delete('crosshair');self._crosshair_style=style
            opts=dict(fill=ink,width=width,tags='crosshair')
            for xy in shapes[:4]:self.canvas.create_line(*xy,**opts)
            if box:self.canvas.create_rectangle(*shapes[4],outline=ink,width=width,tags='crosshair')
        def point(self,e):
            p=super().point(e);t=self.tool.get();a=None
            pts=getattr(self,'extra_points',[])
            if t in ('measure','dimension','move_anchor','offset_part') and pts:
                if t!='dimension' or len(pts)==1:a=pts[0]
            elif t=='radius' and self.extra_item is not None:a=self.extra_item[0]
            elif t in ('circle_radius','circle_diameter','circle_2p') and self.start is not None:a=self.start
            if a is not None and self.ortho.get():
                p=(p[0],a[1]) if abs(p[0]-a[0])>=abs(p[1]-a[1]) else (a[0],p[1]);self.snap_marker=None
            return p
        def measure_label(self,a,b,text):
            A=self.to_screen(a);B=self.to_screen(b);angle=-math.degrees(math.atan2(B[1]-A[1],B[0]-A[0]))
            if angle>90:angle-=180
            if angle< -90:angle+=180
            x,y=(A[0]+B[0])/2,(A[1]+B[1])/2
            theta=math.radians(angle)
            self.canvas.create_text(x-math.sin(theta)*12,y-math.cos(theta)*12,text=text,angle=angle,fill=self.p['ink'],font=('Segoe UI',12),tags='preview')
        def redraw(self):
            super().redraw();self.draw_crosshair()
        def toggle_ortho(self,e=None):
            result=super().toggle_ortho(e)
            if self.tool.get() in ('measure','dimension','move_anchor','radius'):
                from types import SimpleNamespace
                x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))
            return result
        def about(self):
            from workspace_ui import VERSION
            messagebox.showinfo('À propos de Craft','Craft\nVersion '+VERSION+'\nPatronage de maroquinerie',parent=self)
        def icon(self,parent,name,fn,tip,dropdown=False,side='left'):
            c=self.small_icon(parent,name,fn,tip);c.pack(side=side,padx=2,pady=1);return c
        def small_icon(self,parent,icon,fn,tip):
            n=self.p['icon_size'];c=tk.Canvas(parent,width=n+8,height=n+8,bg=self.p['panel'],highlightthickness=0,cursor='arrow')
            color=self.icon_color(icon)
            draw(c,icon,n,color)
            from display_render import paint
            paint(c,icons=True)
            timer={}
            def show(e):
                def display():
                    w=tk.Toplevel(c);w.configure(bd=1,relief='raised',bg=self.field_border());w.overrideredirect(True);w.geometry(f'+{e.x_root+12}+{e.y_root+18}')
                    tk.Label(w,text=tip,bg=self.p['panel'],fg=contrast_color(self.p['panel']),padx=6,pady=3,font=('Segoe UI',9)).pack();timer['window']=w
                timer['id']=self.after(350,display)
            def hide(e=None):
                if timer.get('id'):self.after_cancel(timer.pop('id'))
                if timer.get('window'):timer.pop('window').destroy()
            c.bind('<Button-1>',lambda e:(hide(),fn()));c.bind('<Enter>',show);c.bind('<Leave>',hide);c.bind('<Destroy>',hide)
            c.hide_tip=hide
            return c
        def rebuild_tools(self):
            if not hasattr(self,'toolgroups'):return
            self.close_palette();self.line_preview=None
            for w in self.floats:
                try:w.destroy()
                except tk.TclError:pass
            self.floats=[]
            for parent in (self.topdock,self.leftdock):
                for w in parent.winfo_children():
                    if getattr(w,'tool_family',False) is True or getattr(w,'tool_lane',False) is True:w.destroy()
                parent.bind('<Button-3>',self.category_menu)
            self.category_frames={};self.tool_buttons=[];self._dock_lanes={'top':{},'left':{}}
            locations={n:self.layout.get(n,{}).get('dock','top' if n in ('Fichiers','Édition','Traits','Types de lignes','Préparations') else 'left') for n in self.toolgroups}
            ms=__import__('modern_style');t=ms.tokens_for(self.p)
            for where,parent in [('top',self.topdock),('left',self.leftdock)]:
                lanes=sorted({int(self.layout.get(n,{}).get('lane',0)) for n in self.toolgroups if locations[n]==where})
                for index,lane in enumerate(lanes):
                    f=tk.Frame(parent,bg=self.p['panel']);f.tool_lane=True;f.pack(side='top' if where=='top' else 'left',anchor='nw')
                    f.bind('<Button-3>',self.category_menu);self._dock_lanes[where][index]=f
                    for n in self.toolgroups:
                        if locations[n]==where and int(self.layout.get(n,{}).get('lane',0))==lane:self.layout.setdefault(n,{})['lane']=index
            ordered=sorted(self.toolgroups,key=lambda n:self.layout.get(n,{}).get('order',list(self.toolgroups).index(n)))
            for name in ordered:
                buttons=self.toolgroups[name];info=self.layout.get(name,{});where=locations[name]
                if where=='hidden':continue
                parent=self.root_frame if where=='float' else self._dock_lanes[where][info.get('lane',0)]
                # 0.19.2: every category in a fine rounded outline (like before 0.19.0), docked or floating
                # (a floating one on the colour of the plan round its corners).
                f=ms.make_round(parent,fill=self.p['panel'],edge=t['outline'],radius=5,back=self.p['canvas'] if where=='float' else None)
                f.tool_family=True;self.category_frames[name]=(f,where)
                if where!='float':f.pack(side='left' if where=='top' else 'top',anchor='nw',padx=2,pady=2)
                horizontal=where=='top' or (where=='float' and info.get('orientation','vertical')=='horizontal')
                handle=tk.Canvas(f,width=9 if horizontal else 24,height=24 if horizontal else 9,bg=self.p['panel'],highlightthickness=0,cursor='fleur')
                handle.pack(side='left' if horizontal else 'top',fill='y' if horizontal else 'x',padx=(3,0) if horizontal else 3,pady=3 if horizontal else (3,0));f.drag_handle=handle
                for i in range(2):
                    for j in range(4):
                        x,y=(2+i*3,5+j*4) if horizontal else (5+j*4,2+i*3)
                        handle.create_oval(x,y,x+1,y+1,fill=__import__('modern_style').tokens_for(self.p)['faint'],outline='')
                drag={}
                def press_handle(e,st=drag,h=handle):
                    st.update(x=e.x_root,y=e.y_root,ghost=None,orientation=None);h.grab_set()
                def drag_handle(e,n=name,st=drag):
                    if not st or abs(e.x_root-st['x'])+abs(e.y_root-st['y'])<4:return
                    where,lane=self.dock_target(e);horizontal=where=='top' if where!='float' else self.layout.get(n,{}).get('orientation','vertical')=='horizontal'
                    if st.get('ghost') is None or st['orientation']!=horizontal:
                        if st.get('ghost') is not None:st['ghost'].destroy()
                        st['ghost']=self.category_ghost(n,horizontal);st['orientation']=horizontal
                    st['ghost'].geometry(f'+{e.x_root+9}+{e.y_root+9}');st['ghost'].lift()
                def release_handle(e,n=name,st=drag,h=handle):
                    h.grab_release()
                    if st.get('ghost') is not None:st['ghost'].destroy();self.drop_category(e,n)
                    st.clear()
                handle.bind('<ButtonPress-1>',press_handle);handle.bind('<B1-Motion>',drag_handle);handle.bind('<ButtonRelease-1>',release_handle);handle.bind('<Button-3>',self.category_menu)
                # 0.19.3: the name of the category over its grip dots (to tell the zones apart).
                tip={}
                def tip_hide(e=None,st=tip):
                    if st.get('id'):
                        try:self.after_cancel(st.pop('id'))
                        except (tk.TclError,ValueError):pass
                    w=st.pop('window',None)
                    if w is not None:
                        try:w.destroy()
                        except tk.TclError:pass
                def tip_show(e,n=name,st=tip,h=handle):
                    tip_hide(st=st)
                    def display():
                        st.pop('id',None)
                        if h.winfo_exists():st['window']=ms.tooltip(h,f'{n} · glisser pour déplacer',e.x_root+12,e.y_root+18)
                    st['id']=self.after(450,display)
                handle.bind('<Enter>',tip_show,add='+');handle.bind('<Leave>',tip_hide,add='+');handle.bind('<ButtonPress-1>',tip_hide,add='+');handle.bind('<Destroy>',tip_hide,add='+')
                handle.category_name=name
                group=tk.Frame(f,bg=self.p['panel']);group.pack(side='left' if horizontal else 'top',padx=(0,3) if horizontal else 3,pady=3 if horizontal else (0,3))
                group.bind('<Button-3>',self.category_menu);f.bind('<Button-3>',self.category_menu)
                if where=='float':
                    self.floats.append(f)
                    def place_float(frame=f,inf=info,tries=[0]):
                        if not frame.winfo_exists():return
                        frame.update_idletasks()
                        if not frame.winfo_exists():return
                        if (not self.root_frame.winfo_ismapped() or self.root_frame.winfo_width()<=1) and tries[0]<100:
                            tries[0]+=1;self.after(50,place_float);return   # 0.19.5: the window is not laid out yet (built once at start)
                        W=max(300,self.root_frame.winfo_width());H=max(250,self.root_frame.winfo_height());x=inf.get('x',self.root_frame.winfo_rootx()+100)-self.root_frame.winfo_rootx();y=inf.get('y',self.root_frame.winfo_rooty()+120)-self.root_frame.winfo_rooty()
                        frame.place(x=max(4,min(x,W-frame.winfo_reqwidth()-8)),y=max(4,min(y,H-frame.winfo_reqheight()-8)));frame.lift()
                    self.after_idle(place_float)
                for i,(icon,variants) in enumerate(buttons):
                    if icon=='__line_types__':
                        self.build_line_picker(group,horizontal=horizontal);continue
                    chosen=next((v for v in variants if v[0]==self.variants.get(icon)),variants[0])
                    graphic=chosen[0] if chosen[0] not in ('move_anchor',) else 'move'
                    c=self.small_icon(group,graphic,lambda:None,chosen[1]);c.grid(row=0 if horizontal else i,column=i if horizontal else 0,padx=0,pady=0)
                    self.tool_buttons.append((c,chosen[0]));state={};c.variant_key=icon
                    def call(vs=variants,key=icon):
                        v=next((v for v in vs if v[0]==self.variants.get(key)),vs[0])
                        # 0.18.5: a click on the icon of the tool already in use leaves it, like Échap (what
                        # is being drawn is dropped, back to the Sélection).
                        target='paint_'+v[0] if v[0] in ('white','external','internal') else v[0]
                        if target!='select' and self.tool.get()==target:self.escape();return
                        if v[2]:v[2]()
                        else:self.set_tool(v[0])
                    def popup(vs=variants,key=icon,st=state,source=c,h=horizontal):
                        if len(vs)<2:return
                        st['long']=True;self.variant_palette(vs,key,source,h)
                    def press(e,st=state,pop=popup,c=c):
                        c.hide_tip();st['long']=False;st['timer']=self.after(430,pop)
                    def release(e,st=state,invoke=call):
                        if st.get('timer'):self.after_cancel(st['timer'])
                        if st.get('long'):self.release_palette(e)
                        else:invoke()
                    c.bind('<ButtonPress-1>',press);c.bind('<B1-Motion>',self.hover_palette);c.bind('<ButtonRelease-1>',release);c.bind('<Button-3>',lambda e,pop=popup:pop())
        def close_palette(self):
            self.hide_palette_tip()
            if self.popup:
                try:self.popup.destroy()
                except tk.TclError:pass
            self.popup=None;self._palette_entries=[]
        def hide_palette_tip(self):
            self.__dict__.pop('_variant_tip_entry',None)   # 0.19.9: the entry the bubble is for (hover_palette)
            tip=self.__dict__.pop('_variant_tip',None)
            if tip:
                try:tip.destroy()
                except tk.TclError:pass
        def palette_tip(self,text,e):
            self.hide_palette_tip();w=tk.Toplevel(self);self._variant_tip=w;w.overrideredirect(True)
            w.geometry(f'+{e.x_root+16}+{e.y_root+20}')
            t=__import__('modern_style').tokens_for(self.p);w.configure(bg=t['field_border'])   # 0.19.0: the modern bubble
            tk.Label(w,text=text,bg=t['tip'],fg=t['text'],padx=9,pady=4,font=__import__('modern_style').font(9)).pack(padx=1,pady=1)
        def variant_palette(self,variants,key,source=None,horizontal=False):
            if source is not None:source.update_idletasks()
            self.close_palette();w=tk.Toplevel(self);self.popup=w;self._palette_key=key
            w.overrideredirect(True);w.configure(bg=self.p['panel'],bd=0,relief='flat',highlightthickness=1,highlightbackground=self.field_border())
            x=source.winfo_rootx() if source is not None else self.winfo_pointerx()
            y=source.winfo_rooty() if source is not None else self.winfo_pointery()
            if source is not None:
                x+=0 if horizontal else source.winfo_width();y+=source.winfo_height() if horizontal else 0
            w.geometry(f'+{x}+{y}')
            row=tk.Frame(w,bg=self.p['panel']);row.pack()
            for v in variants:
                c=self.small_icon(row,v[0],lambda:None,v[1]);c.pack(side='left',padx=2,pady=2)
                self._palette_entries.append((c,v))
                c.bind('<Enter>',lambda e:self.hover_palette(e),add='+')
                c.bind('<ButtonRelease-1>',self.release_palette)
            w.bind('<Escape>',lambda e:self.close_palette())
        def hover_palette(self,e):
            if not self.popup:return
            for c,v in self._palette_entries:
                inside=c.winfo_rootx()<=e.x_root<c.winfo_rootx()+c.winfo_width() and c.winfo_rooty()<=e.y_root<c.winfo_rooty()+c.winfo_height()
                __import__('modern_style').tile(c,'hover' if inside else None)   # 0.19.0: rounded tile under the mouse
                if inside:
                    # 0.19.9: the same entry: its bubble only follows the pointer (it was destroyed and made again at
                    # each move); made again when the entry changes
                    tip=self.__dict__.get('_variant_tip')
                    if tip is not None and self.__dict__.get('_variant_tip_entry') is c:
                        try:tip.geometry(f'+{e.x_root+16}+{e.y_root+20}');continue
                        except tk.TclError:pass
                    self.palette_tip(v[1],e);self._variant_tip_entry=c
            if not any(c.winfo_rootx()<=e.x_root<c.winfo_rootx()+c.winfo_width() and c.winfo_rooty()<=e.y_root<c.winfo_rooty()+c.winfo_height() for c,v in self._palette_entries):self.hide_palette_tip()
        def release_palette(self,e):
            chosen=None
            for c,v in self._palette_entries:
                if c.winfo_rootx()<=e.x_root<c.winfo_rootx()+c.winfo_width() and c.winfo_rooty()<=e.y_root<c.winfo_rooty()+c.winfo_height():chosen=v
            key=getattr(self,'_palette_key',None);self.close_palette()
            if chosen:
                self.variants[key]=chosen[0];self.persist_preferences()
                if chosen[2]:chosen[2]()
                else:self.set_tool(chosen[0])
                self.swap_variant_icon(key,chosen)
        def swap_variant_icon(self,key,chosen):
            """0.16.20: redraw only the button that changed; the toolbars stay where they are."""
            for k,(c,_) in enumerate(getattr(self,'tool_buttons',[])):
                if getattr(c,'variant_key',None)!=key:continue
                graphic=chosen[0] if chosen[0]!='move_anchor' else 'move'
                try:
                    c.delete('all');draw(c,graphic,self.p['icon_size'],self.icon_color(graphic));c.tip_text=chosen[1];c.craft_icon=graphic
                    __import__('display_render').paint(c,icons=True)
                except tk.TclError:return self.rebuild_tools()
                self.tool_buttons[k]=(c,chosen[0])
            self.highlight_tools()
        def category_ghost(self,name,horizontal):
            """The category carried by the mouse. 0.19.2: a window of its own, moved by Windows over the
            plan (a frame placed on the plan left white trails there under Windows)."""
            w=tk.Toplevel(self);w.withdraw();w.overrideredirect(True)
            try:w.attributes('-topmost',True)
            except tk.TclError:pass
            f=tk.Frame(w,bg=self.field_background(),highlightthickness=1,highlightbackground=self.p['accent']);f.pack()
            w.deiconify()
            h=tk.Canvas(f,width=9 if horizontal else 24,height=24 if horizontal else 9,bg=self.field_background(),highlightthickness=0);h.pack(side='left' if horizontal else 'top')
            for i in range(2):
                for j in range(4):
                    x,y=(2+i*3,5+j*4) if horizontal else (5+j*4,2+i*3);h.create_oval(x,y,x+1,y+1,fill=self.field_border(),outline='')
            for icon,variants in self.toolgroups[name]:
                if icon=='__line_types__':
                    c=tk.Canvas(f,width=150 if horizontal else 90,height=24,bg=self.field_background(),highlightthickness=0);c.create_line(8,12,65,12,fill=self.p['ui_ink']);c.pack(side='left' if horizontal else 'top');continue
                chosen=next((v for v in variants if v[0]==self.variants.get(icon)),variants[0]);n=self.p['icon_size'];c=tk.Canvas(f,width=n+8,height=n+8,bg=self.field_background(),highlightthickness=0);draw(c,chosen[0],n,self.icon_color(chosen[0]));c.pack(side='left' if horizontal else 'top')
            return w
        def dock_target(self,e):
            for where,widget in [('top',self.topdock),('left',self.leftdock)]:
                x,y=widget.winfo_rootx(),widget.winfo_rooty();W,H=widget.winfo_width(),widget.winfo_height()
                hit=(x-8<=e.x_root<=x+W+24 and y-10<=e.y_root<=y+H+54) if where=='top' else (x-8<=e.x_root<=x+W+72 and self.body.winfo_rooty()<=e.y_root<=y+H)
                if not hit:continue
                lanes=self._dock_lanes[where];coord=e.y_root if where=='top' else e.x_root
                for i,f in lanes.items():
                    end=(f.winfo_rooty()+f.winfo_height()) if where=='top' else (f.winfo_rootx()+f.winfo_width())
                    if coord<=end+3:return where,i
                return where,len(lanes)
            return 'float',0
        def drop_category(self,e,name):
            where,lane=self.dock_target(e);old=self.layout.get(name,{});orient='horizontal' if where=='top' else 'vertical' if where=='left' else old.get('orientation','vertical')
            self.layout[name]=dict(old,dock=where,lane=lane,x=e.x_root-4,y=e.y_root-4,orientation=orient)
            siblings=[(n,f) for n,(f,d) in self.category_frames.items() if d==where and n!=name and self.layout.get(n,{}).get('lane',0)==lane]
            siblings.sort(key=lambda pair:pair[1].winfo_rootx() if where=='top' else pair[1].winfo_rooty())
            coord=e.x_root if where=='top' else e.y_root;names=[n for n,f in siblings];index=sum(coord>((f.winfo_rootx()+f.winfo_width()/2) if where=='top' else (f.winfo_rooty()+f.winfo_height()/2)) for n,f in siblings);names.insert(index,name)
            for i,n in enumerate(names):self.layout.setdefault(n,{})['order']=i
            self.persist_preferences();self.rebuild_tools()
        def category_menu(self,e):
            self.update_idletasks();m=self.menu();self.category_vars=[]
            for name in self.toolgroups:
                f=self.category_frames.get(name,(None,None))[0];visible=bool(f is not None and f.winfo_exists() and f.winfo_ismapped());var=tk.BooleanVar(value=visible);self.category_vars.append(var)
                m.add_checkbutton(label=name,variable=var,command=lambda n=name,v=var:self.toggle_category(n,v.get()))
            try:m.tk_popup(e.x_root,e.y_root)
            finally:m.grab_release()
        def toggle_category(self,name,visible):
            old=self.layout.get(name,{});n=sum(d=='float' for f,d in self.category_frames.values())
            self.layout[name]=dict(old,dock='float' if visible else 'hidden',lane=0,x=self.root_frame.winfo_rootx()+100+n*24,y=self.root_frame.winfo_rooty()+100+n*24,orientation=old.get('orientation','vertical'))
            self.persist_preferences();self.rebuild_tools()
        def draw_input_bubble(self):
            if not hasattr(self,'command_entry') or not hasattr(self,'canvas'):return
            self.canvas.delete('input_bubble')
            if self.start is None or self.tool.get() in ('select','delete'):
                self.command_entry.place_forget();return
            x,y=getattr(self,'cursor_screen',(100,100));W=self.canvas.winfo_width();H=self.canvas.winfo_height()
            self.command_entry.place(x=max(2,min(W-100,x+18)),y=max(2,min(H-28,y+18)),width=90,height=24)
        def draw_guides(self):
            w=self.workspace
            if not w or not w.get('visible',True):return
            from cad import guide_segments,column_labels,title_suffix
            for a,b in guide_segments(w):self.canvas.create_line(*self.to_screen(a),*self.to_screen(b),fill=self.p['guides'],width=1,tags='guides')
            x=w.get('origin_x',0);labels=column_labels(w);suffix=title_suffix(w)
            title_font=('Segoe UI',max(9,min(18,round(min(w['widths'])*self.scale*.052))))
            for i,width in enumerate(w['widths']):
                label=labels[i].capitalize()
                if i==1 and suffix:label+=' · '+suffix
                sx,sy=self.to_screen((x+width*.05,w['header']*.58))
                self.canvas.create_text(sx,sy,text=label,anchor='w',fill=self.p['guides'],font=title_font,tags='guides');x+=width
        def refresh(self):
            super().refresh();self.update_window_title()
            self.rebuild_tabs()
        def capture_doc(self):
            return dict(items=self.items,workspace=self.workspace,filename=self.filename,clean=self.clean,clean_workspace=self.clean_workspace,
                        background=self.__dict__.get('background'),clean_background=self.__dict__.get('clean_background'),
                        infos=self.__dict__.get('infos'),clean_infos=self.__dict__.get('clean_infos'),
                        undo_stack=self.undo_stack,redo_stack=self.redo_stack,selected=self.selected,selected_set=set(self.selected_set),
                        scale=self.scale,ox=self.ox,oy=self.oy,project_model=self.project_model,log_messages=self.log_messages,
                        document_sections=copy.deepcopy(self.document_sections),active_section=self.active_section,doc_key=self.__dict__.get('doc_key'),display_name=self.__dict__.get('display_name'),
                        mozart_source=self.__dict__.get('mozart_source'))   # 0.19.13: the DWG Mozart it was opened from
        def stash_doc(self):
            if self.documents:self.documents[self.current_doc]=self.capture_doc()
        def switch_doc(self,index):
            if self._tabs_busy or not 0<=index<len(self.documents):return
            self.stash_doc();self.current_doc=index;doc=self.documents[index]
            self.cancel()
            for k,v in doc.items():setattr(self,k,v)
            self.sync_fields();self.refresh();self.log_status()
        def update_window_title(self):
            model=Path(self.filename).stem if self.filename else self.__dict__.get('display_name') or 'Nouveau modèle'   # 0.19.13: an opened Mozart pattern by its name
            customer=self.__dict__.get('license_customer')
            licence=self.__dict__.get('licence_label') or ('Licence '+customer if customer else 'Version personnelle')
            text='Craft 2026 — '+licence+' — '+model+(' *' if self.dirty() else '')
            if hasattr(self,'window_caption'):self.window_caption.configure(text=text)
            controller=self.__dict__.get('_caption_controller')
            if controller:controller.set(text)
            else:self.title(text)
        def select_section(self,key):
            if not any(section['id']==key for section in self.document_sections):return
            self.active_section=key;self.rebuild_sections();self.stash_doc()
            # Future file-specific sheets attach their view here; no sheets are created now.
            self.event_generate('<<CraftSectionChanged>>',when='tail')
        def rebuild_sections(self):
            if 'section_tabs' not in self.__dict__:return
            signature=(self.current_doc,self.active_section,self.p['panel'],self.p['ui_ink'],tuple((v['id'],v['title']) for v in self.document_sections))
            if signature==self.__dict__.get('_section_signature') and self.section_tabs.winfo_children():return
            self._section_signature=signature
            for child in self.section_tabs.winfo_children():child.destroy()
            for section in self.document_sections:
                button=self.button(self.section_tabs,section['title'],lambda key=section['id']:self.select_section(key));button.pack(side='left',padx=1,pady=1)
                if section['id']==self.active_section:button.configure(bg=shade(self.p['panel'],18))
        def rebuild_tabs(self):
            if not hasattr(self,'tabbar') or self._tabs_busy:return
            self.rebuild_sections()
            self._tabs_busy=True
            try:
                if self.documents:self.documents[self.current_doc]=self.capture_doc()
                for w in self.tabbar.winfo_children():w.destroy()
                for i,d in enumerate(self.documents):
                    title=Path(d['filename']).stem if d['filename'] else d.get('display_name') or 'Nouveau'   # 0.17.0: an imported Mozart pattern keeps its name
                    if __import__('doc_files').document_dirty(d):title+=' *'
                    f=tk.Frame(self.tabbar,bg=self.p['panel'],highlightthickness=1,highlightbackground=shade(self.p['panel'],25));f.pack(side='left',padx=1,pady=1)
                    b=self.button(f,title,lambda j=i:self.switch_doc(j));b.pack(side='left')
                    if i==self.current_doc:b.configure(bg=shade(self.p['panel'],18))
                    self.button(f,'×',lambda j=i:self.close_doc(j)).pack(side='left')
                self.button(self.tabbar,'+',self.new_doc).pack(side='left')
            finally:self._tabs_busy=False
        def add_doc(self,items,workspace,filename=None,background=None,infos=None):
            with self.held_redraw():self.add_doc_held(items,workspace,filename,background,infos)   # 0.18.7: one drawing, at the end
        def add_doc_held(self,items,workspace,filename=None,background=None,infos=None):
            self.stash_doc();self.cancel();self.selected_set=set();self.box_start=None;self.doc_key=uuid.uuid4().hex;self.display_name=None;self.mozart_source=None   # 0.16.30: safety copies
            self.items=items;self.workspace=workspace;self.filename=filename;self.clean=__import__('geometry').clone(items);self.clean_workspace=copy.deepcopy(workspace)
            self.background=background;self.clean_background=dict(background) if background else None   # 0.18.0 image de fond
            self.infos=copy.deepcopy(infos) if infos else None;self.clean_infos=copy.deepcopy(self.infos)   # 0.18.1 Infos du modèle
            self.document_sections=[{'id':'plan','title':'Plan'}];self.active_section='plan'
            self.undo_stack=[];self.redo_stack=[];self.selected=None;self.project_model=next((s.get('model') for s in items if s.get('model')),None);self.log_messages=[]
            self.documents.append(self.capture_doc());self.current_doc=len(self.documents)-1
            self.refresh();self.fit_workspace()   # 0.17.0: base scale, never a zoom on the pieces
        def new_doc(self):self.add_doc([],__import__('base_profiles').workspace_for(self.prefs,__import__('base_profiles').default_name(self.prefs)))   # 0.19.13: the profile of Nouveau
        def new_base(self,kind):self.add_doc([],default_workspace(kind) if kind else None)
        def open_doc(self):
            # 0.17.1: a Mozart pattern (DXF or DWG) opens like any pattern; 0.18.0: .crft, classic file types.
            import doc_files
            options=dict(filetypes=doc_files.OPEN_TYPES);folder=doc_files.initial_dir(self.prefs)
            if folder:options['initialdir']=folder
            file=filedialog.askopenfilename(**options)
            if not file:return
            return self.open_path(file)
        def open_path(self,file,remember=True):
            """0.18.0: one way in for « Ouvrir… », « Récents », a double-click and the launcher:
            .crft, an old .patron (never written), a Mozart DXF or DWG. 0.18.1: the crans of any
            pattern are drawn like Mozart's."""
            import doc_files
            target=Path(file)
            if not target.is_file():
                doc_files.forget(self.prefs,file);self.persist_preferences();self.rebuild_recent_menu()
                messagebox.showerror('Ouvrir','Fichier introuvable :\n'+str(file),parent=self);return None
            if remember:doc_files.remember(self.prefs,file);self.persist_preferences();self.rebuild_recent_menu()
            suffix=target.suffix.lower()
            if suffix in ('.dxf','.dwg') and hasattr(self,'open_mozart'):return self.open_mozart(file)
            resolved=target.resolve()
            for i,d in enumerate(self.documents):
                if d['filename'] and Path(d['filename']).resolve()==resolved:self.switch_doc(i);return None
            try:items,w,background,infos,meta=read_document(file,meta=True)
            except (OSError,ValueError,TypeError) as exc:messagebox.showerror('Ouvrir',target.name+' : '+str(exc),parent=self);return None
            # 0.18.1: crans of a file written before are drawn like Mozart's (once: a file written
            # by 0.18.1 keeps them as they are, Mozart's included).
            if meta.get('crans')!='mozart':items=doc_files.current_crans(items)
            items=doc_files.current_zones(items)
            self.reset_doc(items,w,str(file),background,infos);return None
        def rebuild_recent_menu(self):
            menu=self.__dict__.get('recent_menu')
            if menu is None:return
            import doc_files
            menu.delete(0,'end');files=doc_files.recent(self.prefs)
            for label,f in zip(doc_files.recent_labels(files),files):menu.add_command(label=label,command=lambda f=f:self.open_path(f))
            if not files:menu.add_command(label='Aucun fichier récent',state='disabled')
        def reset_doc(self,items,workspace,filename=None,background=None,infos=None):
            # The launcher reopens a document into a tab rather than replacing another.
            if len(self.documents)==1 and not self.items and not self.filename and not self.dirty():self.documents=[];self.current_doc=0
            self.add_doc(items,workspace,filename,background,infos)
        def close_doc(self,index):
            # 0.19.9: another tab closed: the one in use stays shown (its index shifted when it came after); it went to
            # the closed tab's neighbour. The closed tab is shown only for the question, Annuler comes back too.
            current=self.current_doc
            self.switch_doc(index)
            if not self.guard():
                if current!=index:self.switch_doc(current)
                return
            self.documents.pop(index)
            if not self.documents:
                self.current_doc=0;self.add_doc([],default_workspace('maro'));return
            self.current_doc=current-(current>index) if current!=index else min(index,len(self.documents)-1);doc=self.documents[self.current_doc]
            for k,v in doc.items():setattr(self,k,v)
            self.cancel();self.sync_fields();self.refresh()
        def guard_all(self):
            original=self.current_doc
            for i in range(len(self.documents)):
                self.switch_doc(i)
                if not self.guard():return False
                self.stash_doc()
            self.switch_doc(original);return True
        def close(self):
            if self.guard_all():self.destroy()
        def guard(self):
            if getattr(self,'_skip_current_guard',False):return True
            return super().guard()
        def update_from_zip(self,file=None):
            if not self.guard_all():return
            self._skip_current_guard=True
            try:super().update_from_zip(file)   # 0.19.15: ``file``, an update downloaded (online_update)
            finally:self._skip_current_guard=False
        def choose(self,i):
            self.selected_set={i} if i is not None else set();super().choose(i)
        def attach_moved_zones(self,ids):
            """0.18.1: zones without piece moved onto a piece are attached to it."""
            try:
                import preparation_ui
                n=preparation_ui.attach_loose(self.items,list(ids))
            except (ImportError,ValueError,TypeError):n=0
            if n:self.status.set('Zone de préparation rattachée à sa pièce.' if n==1 else f'{n} zones de préparation rattachées à leur pièce.')
            return n
        def complete_command(self,name,action=False):
            # 0.18.0: nothing stays selected once an action is over (a recalled command starts by
            # choosing again); Dupliquer keeps its copies selected to place them.
            if name!='duplicate':self.selected_set=set();self.selected=None
            super().complete_command(name,action)
        def down(self,e):
            if self.tool.get()=='move_anchor' and len(self.selected_set)>1:
                p=self.point(e);self.extra_points.append(p)
                if len(self.extra_points)==2:
                    a,b=self.extra_points;self.snapshot()
                    for i in self.selected_set:self.items[i]['x']+=b[0]-a[0];self.items[i]['y']+=b[1]-a[1]
                    self.complete_command('move_anchor');self.refresh()
                return
            if self.tool.get()!='select':return super().down(e)
            self.canvas.focus_set();p=self.raw(e);i=self.pick(p)
            self.box_start=(e.x,e.y,p,i);self.drag=None;self._contour_drag=None
            # 0.18.0, like AutoCAD: a click adds to the selection (no Ctrl); dragging moves what is
            # selected. 0.18.5: a click in the void (without dragging) empties it (see up).
            if i is not None:self.selected_set=set(self.selected_set)|{i};self.selected=i
            if i is not None:
                from entity_rules import linked_selection
                from geometry import clone   # 0.19.9: one fast deep copy of the whole selection at the press
                self._contour_drag=dict(original=clone({j:self.items[j] for j in linked_selection(self.items,self.selected_set)}),changed=False)
            self.sync_fields();self.refresh()
        def motion(self,e):
            self.cursor_screen=(e.x,e.y);self._inside_plan=True
            if self.tool.get()!='select' or self.box_start is None:
                super().motion(e)
                if self.tool.get()=='measure' and self.extra_points:
                    a=self.extra_points[0];b=self.point(e);a,b=__import__('craft_tools').measure_points(a,b,self.ortho.get());self.canvas.delete('ruler_value');self.measure_label(a,b,self.format_length(math.dist(a,b))+' '+self.units.get())
                self.draw_crosshair();return
            x,y,a,i=self.box_start
            if math.hypot(e.x-x,e.y-y)<4 and not (self._contour_drag and self._contour_drag['changed']):return
            if i is not None and self._contour_drag:
                state=self._contour_drag;p=self.point(e);first=not state['changed']
                if first:self.snapshot();state['changed']=True
                # 0.19.9: each object moved is a plain copy of the one copied at the press, x / y moved (the same
                # numbers); a deep copy of every dragged object at each move cost 41-48 ms with DIFORME all selected.
                dx,dy=p[0]-a[0],p[1]-a[1]
                for j,original in state['original'].items():
                    moved=dict(original);moved['x']=original['x']+dx;moved['y']=original['y']+dy;self.items[j]=moved
                state['offset']=(dx,dy);self.sync_fields()
                # 0.16.15: after the first redraw only the dragged shapes are shifted on screen.
                fast=getattr(self,'fast_translate',None)
                if first or not fast or not fast(state['offset']):self.refresh()
                self.draw_crosshair();return
            self.draw_selection_box(x,y,e.x,e.y,'selection_box')   # 0.18.5: drawn again in place
        def draw_selection_box(self,x,y,ex,ey,tag):
            """The selection rectangle, the same in every command (0.18.0): blue from left to right
            (objects entirely inside), green and dashed from right to left (objects crossed).
            0.18.5: drawn again in place at each move: its four sides follow the mouse at once (Tk
            shows again only thin strips). 0.19.7 (« ça doit suivre tout le temps »): its tint follows
            at once too (box_tint: only the strips that change are painted)."""
            c=self.canvas;color='#52b779' if ex<x else '#528fe0';dash=(4,2) if ex<x else ()
            x0,y0,x1,y1=min(x,ex),min(y,ey),max(x,ex),max(y,ey)
            try:
                tint=c.find_withtag(tag+':tint');edges=c.find_withtag(tag+':edge')
                fresh=not tint or len(edges)!=4
                if fresh:   # a new box
                    c.delete(tag);edges=[c.create_line(0,0,1,1,width=1,tags=(tag,tag+':edge')) for _ in range(4)]
                for item,xy in zip(edges,((x0,y0,x1,y0),(x1,y0,x1,y1),(x1,y1,x0,y1),(x0,y1,x0,y0))):
                    if tuple(c.coords(item))!=tuple(float(v) for v in xy):
                        c.coords(item,*xy)
                        if not fresh:c.update_idletasks()   # Tk shows again one thin strip at a time (one box around all the sides would hold the whole tint)
                if c.itemcget(edges[0],'fill')!=color:
                    for item in edges:c.itemconfigure(item,fill=color,dash=dash)
                self.box_tint(tag,color,(x0,y0,x1,y1),edges[0],fresh)
            except tk.TclError:
                c.delete(tag);c.create_rectangle(x,y,ex,ey,fill=color,stipple='gray25',outline=color,width=1,tags=tag)
        def box_tint(self,tag,color,box,below,fresh):
            """0.19.7: the box's tint in ONE picture as large as the plan (transparent, made once): at each
            move only the strips between the last box and this one are painted (tint) or cleared, the
            strips across, then the strips along (Tk would redraw one box around both: the whole tint).
            0.18.5 made a picture of the box's size again a few times a second: it lagged behind the frame."""
            c=self.canvas;W,H=max(1,c.winfo_width()),max(1,c.winfo_height())
            st=self.__dict__.get('_box_tint')
            if st is None or st['size']!=(W,H):
                if st and st['owner']:c.delete(st['owner']+':tint')   # the plan resized during the drag: made again at its size
                st=self._box_tint=dict(size=(W,H),photo=tk.PhotoImage(master=c,width=W,height=H),shown=None,owner=None,tiles={})
            photo=st['photo'];tiles=st['tiles']
            def tile(key):
                if key not in tiles:
                    if key=='clear':tiles[key]=tk.PhotoImage(master=c,width=32,height=32)
                    else:tiles[key]=tk.PhotoImage(master=c,data=base64.b64encode(overlay_pixel(key)).decode()).zoom(32,32)
                return tiles[key]
            if fresh or st['owner']!=tag:
                if st['owner'] not in (None,tag):c.delete(st['owner']+':tint')
                if st['shown']:photo.blank()
                st['shown']=None;st['owner']=tag
                item=c.create_image(0,0,anchor='nw',image=photo,tags=(tag,tag+':tint'));c.tag_lower(item,below)
            x0,y0,x1,y1=box;new=(max(0,min(W,round(x0))),max(0,min(H,round(y0))),max(0,min(W,round(x1))),max(0,min(H,round(y1))))
            shown=st['shown'];old=shown[1] if shown else None
            def paint(key,r):
                if r[2]>r[0] and r[3]>r[1]:c.tk.call(photo,'copy',tile(key),'-to',*r,'-compositingrule','set')
            if shown is None or shown[0]!=color:
                if old:
                    for r in box_minus(old,new):paint('clear',r)
                paint(color,new)
            elif old!=new:
                gone,came=box_minus(old,new),box_minus(new,old)
                across=[('clear',r) for r in gone if r[2]-r[0]==old[2]-old[0]]+[(color,r) for r in came if r[2]-r[0]==new[2]-new[0]]
                along=[('clear',r) for r in gone if r[2]-r[0]!=old[2]-old[0]]+[(color,r) for r in came if r[2]-r[0]!=new[2]-new[0]]
                for key,r in across:paint(key,r)
                if across and along:c.update_idletasks()
                for key,r in along:paint(key,r)
            st['shown']=(color,new)
        def up(self,e):
            if self.tool.get()!='select' or self.box_start is None:return super().up(e)
            x,y,a,i=self.box_start;self.box_start=None;self.canvas.delete('selection_box')
            if i is not None:
                changed=bool(getattr(self,'_contour_drag',None) and self._contour_drag['changed'])
                if changed:self.last_command=('tool','select');self.attach_moved_zones(self._contour_drag['original'])
                self._contour_drag=None;self.sync_fields()
                if changed:self.refresh()   # 0.17.0: a plain click was already drawn when pressed
                return
            from selection import combined,shift_held
            if math.hypot(e.x-x,e.y-y)>=4:
                self.selected_set=combined(self.selected_set,window_select(self.items,a,self.raw(e)),shift_held(e))
            elif not shift_held(e):self.selected_set=set()   # 0.18.5: a click in the void deselects everything
            self.selected=min(self.selected_set) if self.selected_set else None;self.sync_fields();self.refresh()
        def draw_shape(self,s,color,width,tags=()):
            old=self.selected
            index=None if tags else self.selection_index()   # 0.19.9: the selection looked up once per drawing of the plan
            if index is not None:
                k=index.get(id(s))
                if k is not None and k in self.selected_set and self.items[k] is s:self.selected=k
            elif not tags:
                for i in self.selected_set:
                    if i<len(self.items) and self.items[i] is s:self.selected=i;break
            try:super().draw_shape(s,color,width,tags)
            finally:self.selected=old
        def delete(self):
            if not self.selected_set:return super().delete()
            self.snapshot();self.items=[s for i,s in enumerate(self.items) if i not in self.selected_set]
            self.selected_set=set();self.selected=None;self.complete_command('delete',True);self.refresh()
        def duplicate(self):
            from entity_rules import linked_selection,fresh_copy_ids
            ids=linked_selection(self.items,self.selected_set or ({self.selected} if self.selected is not None else set()))
            if len(ids)<=1 and not any(self.items[i].get('piece_id') for i in ids):return super().duplicate()
            if not ids:return
            self.snapshot();copies=fresh_copy_ids([copy.deepcopy(self.items[i]) for i in ids])
            start=len(self.items)
            import uuid
            groups={}
            for s in copies:
                s['x']+=10;s['y']+=10
                if s.get('dimension_group'):s['dimension_group']=groups.setdefault(s['dimension_group'],uuid.uuid4().hex)
            self.items.extend(copies);self.selected_set=set(range(start,len(self.items)));self.selected=start;self.complete_command('duplicate',True);self.refresh()
        def apply_profile(self,name):
            if name not in self.profiles:return
            self.active_profile=name
            self.profiles[name]['dash']=copy.deepcopy(self.line_types[self.line_type])
            ids=self.selected_set or ({self.selected} if self.selected is not None else set())
            if ids:
                self.snapshot()
                from craft_tools import style
                for i in ids:
                    if self.items[i].get('is_notch'):continue
                    old=style(self.items[i]);old.update(color=self.profiles[name]['color'],role=self.profiles[name]['role'])
                    self.items[i]['style']=old;self.items[i]['profile']=name
                    for child in self.items[i].get('components',[]):
                        child['style']=dict(style(child),color=old['color'],role=old['role']);child['profile']=name
                self.refresh()
        def export_items(self):
            from export_preview import fabrication_ids
            ids=None
            selection=sorted(self.selected_set or ({self.selected} if self.selected is not None else set()))
            if selection:
                answer=messagebox.askyesnocancel('Exporter','Exporter uniquement la sélection ?')
                if answer is None:return None
                if answer:ids=selection
            from export_check import ready
            if not ready(self,'machine',ids):return None   # 0.17.0: valid pieces, 30 mm apart
            return [self.items[i] for i in fabrication_ids(self.items,ids)]
        def restore(self,state):
            self.selected_set=set();self.box_start=None;super().restore(state)
        def cancel(self):
            self.close_palette()
            self.box_start=None;self._contour_drag=None
            return super().cancel()
    return Refined
