"""0.19.13 Contrôle des contours (proposed on 04/11: « les bouts non joints des pièces montrés d'un coup par des ronds
rouges, ceux de moins de 0,1 mm fermés en un clic » ; as Mozart's PitChiudiPoliTa / PitEviPoliTaChi: close the open
cut lines at once, show the closed pieces).

Exporter › Contrôle des contours… (and the Contrôle avant export window when it lists open cut lines): every open
end of a cut line (Coupe extérieure or intérieure) in a red ring, every closed piece outlined in green; the cut lines
whose two ends are less than 0,1 mm apart are closed in one click (« Fermer les écarts de moins de 0,1 mm »,
Annuler brings them back).
0.19.14: and each piece surcoupée inside its précoupe, the écart kept all round (an orange ring where it is not)."""
import math

LIMIT = .1
RED, GREEN, ORANGE = '#ff3b30', '#34c759', '#ff9500'


def _cut(s):
    from craft_tools import style
    return style(s)['role'] in ('external', 'internal') and not s.get('preparation') and not s.get('annotation')


def open_lines(items):
    """[(index, first point, last point, gap between them)] of the open cut lines."""
    from geometry import path
    out = []
    for i, s in enumerate(items):
        if not _cut(s) or s.get('is_notch') or s.get('drill') or s.get('stitch'):
            continue
        try:
            pts, closed = path(s)
        except (ValueError, KeyError, TypeError):
            continue
        if closed or len(pts) < 2:
            continue
        out.append((i, pts[0], pts[-1], math.dist(pts[0], pts[-1])))
    return out


def closed_pieces(items):
    from entity_rules import closed_piece
    return [i for i, s in enumerate(items) if _cut(s) and closed_piece(s)]


def precut_problems(items, tolerance=.1):
    """0.19.14: [(précoupe, piece inside or None, the point to show, its distance to the précoupe's edge, outside)] for
    the pieces surcoupées that cross their précoupe, lie out of it or nearer its edge than its écart, and the précoupes
    left without a piece. The edges are looked up in a grid (a précoupe of 100 pieces: a fraction of a second)."""
    import surcoupe
    from precision_geometry import inside
    out = []
    for k, s in enumerate(items):
        if not surcoupe.is_precut(s):
            continue
        try:
            gap = float((s.get('surcoupe') or {}).get('gap') or 0)
            Q, _ = surcoupe._ring(s)
        except (TypeError, ValueError, KeyError):
            continue
        if len(Q) < 3:
            continue
        inners = surcoupe.inner_contours(items, k)
        if not inners:
            out.append((k, None, Q[0], 0., False))
            continue
        cell = max(gap, 1.)
        grid_q = surcoupe.SegmentGrid([Q], cell)
        for j in inners:
            try:
                P, _ = surcoupe._ring(items[j])
            except (TypeError, ValueError, KeyError):
                continue
            if len(P) < 2:
                continue
            grid_p = surcoupe.SegmentGrid([P], cell)
            crossing = next((a for a, b in zip(Q, Q[1:] + Q[:1]) if grid_p.crosses(a, b)), None)
            if crossing is not None:
                out.append((k, j, crossing, 0., True))
                continue
            if not inside(s, P[0]):
                out.append((k, j, P[0], 0., True))
                continue
            if gap <= 0:
                continue
            x0, y0 = min(p[0] for p in P) - gap, min(p[1] for p in P) - gap
            x1, y1 = max(p[0] for p in P) + gap, max(p[1] for p in P) + gap
            worst = min(((grid_q.distance(p, gap), p) for p in P), key=lambda w: w[0])
            near = [q for q in Q if x0 <= q[0] <= x1 and y0 <= q[1] <= y1]
            if near:
                worst = min(worst, min(((grid_p.distance(q, gap), q) for q in near), key=lambda w: w[0]), key=lambda w: w[0])
            if worst[0] < gap - tolerance:
                out.append((k, j, worst[1], worst[0], False))
    return out


def closable(items, limit=LIMIT):
    """The open polylines whose ends are less than ``limit`` mm apart (and that have at least 3 points)."""
    out = []
    for i, a, b, gap in open_lines(items):
        s = items[i]
        if gap < limit and s.get('kind') == 'poly' and not s.get('spline') and len(s.get('points', [])) >= 4:
            out.append(i)
    return out


def closed_copy(s):
    """The polyline closed: its last point (on the first one) dropped, its last segment going back to the first."""
    import copy
    q = copy.deepcopy(s)
    pts = q['points'][:-1]
    q['points'] = pts
    q['closed'] = True
    if q.get('bulges'):
        q['bulges'] = list(q['bulges'][:len(pts)])
        while len(q['bulges']) < len(pts):
            q['bulges'].append(0.)
    xs = [q['x'] + x for x, y in pts]
    ys = [q['y'] + y for x, y in pts]
    q['w'], q['h'] = max(xs) - min(xs), max(ys) - min(ys)
    return q


def close_small(app, limit=LIMIT):
    """Closes them (one step of Annuler); returns how many."""
    ids = closable(app.items, limit)
    if not ids:
        return 0
    app.snapshot()
    for i in ids:
        app.items[i] = closed_copy(app.items[i])
    app.refresh()
    return len(ids)


def draw(app, problems=None):
    """The red rings on the open ends, the closed pieces in green (tag contours_check); 0.19.14: the précoupes'
    problems in orange (``problems``: found already)."""
    from geometry import path
    c = app.canvas
    c.delete('contours_check')
    for i in closed_pieces(app.items):
        try:
            pts = path(app.items[i])[0]
        except (ValueError, KeyError, TypeError):
            continue
        if len(pts) > 1:
            c.create_line(*[v for p in pts + pts[:1] for v in app.to_screen(p)], fill=GREEN, width=2, tags='contours_check')
    for i, a, b, gap in open_lines(app.items):
        for p in (a, b):
            x, y = app.to_screen(p)
            c.create_oval(x - 7, y - 7, x + 7, y + 7, outline=RED, width=2.5, tags='contours_check')
    for k, j, p, d, out in (precut_problems(app.items) if problems is None else problems):
        x, y = app.to_screen(p)
        c.create_oval(x - 9, y - 9, x + 9, y + 9, outline=ORANGE, width=2.5, tags='contours_check')
    c.tag_raise('contours_check')


def clear(app):
    try:
        app.canvas.delete('contours_check')
    except Exception:
        pass


def summary(items, problems=None):
    open_ = open_lines(items)
    small = len(closable(items))
    pieces = len(closed_pieces(items))
    text = f'{pieces} pièce{"s" if pieces > 1 else ""} fermée{"s" if pieces > 1 else ""} · '   # « 0 pièce fermée »
    text += f'{len(open_)} contour{"s" if len(open_) > 1 else ""} ouvert{"s" if len(open_) > 1 else ""}'
    if small:
        text += f' (dont {small} à moins de 0,1 mm)'
    bad = precut_problems(items) if problems is None else problems
    empty = sum(1 for b in bad if b[1] is None)
    wrong = [b for b in bad if b[1] is not None]
    if wrong:
        out = sum(1 for b in wrong if b[4])
        text += f' · {len(wrong)} surcoupe{"s" if len(wrong) > 1 else ""} ' + ('hors de sa précoupe ou trop près du bord' if len(wrong) == 1 else 'hors de leur précoupe ou trop près du bord')
        if out:
            text += f' (dont {out} dehors)'
    if empty:
        text += f' · {empty} précoupe{"s" if empty > 1 else ""} sans pièce'
    return text + '.'


def show(app):
    """Exporter › Contrôle des contours…: the marks, a small window to close the small gaps."""
    import tkinter as tk
    problems = precut_problems(app.items)   # 0.19.14: found once for the marks and the text
    draw(app, problems)
    old = app.__dict__.get('_contours_window')
    if old is not None and old.winfo_exists():
        old.destroy()
    win = app.dialog('Contrôle des contours')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    app._contours_window = win
    text = tk.StringVar(value=summary(app.items, problems))
    app.label(win, 'Bouts non joints : ronds rouges. Pièces fermées : en vert. Surcoupe hors de sa précoupe, trop près ou précoupe vide : rond orange.').pack(anchor='w', padx=14, pady=(12, 2))
    tk.Label(win, textvariable=text, bg=app.p['panel'], fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 10, 'bold')).pack(anchor='w', padx=14, pady=2)
    row = tk.Frame(win, bg=app.p['panel'])
    row.pack(fill='x', padx=14, pady=(8, 12))

    def close_them():
        n = close_small(app)
        problems = precut_problems(app.items)
        text.set(summary(app.items, problems))
        draw(app, problems)
        app.status.set(f'{n} contour{"s" if n > 1 else ""} fermé{"s" if n > 1 else ""} (écart de moins de 0,1 mm).' if n else 'Aucun écart de moins de 0,1 mm.')

    def done():
        clear(app)
        win.destroy()
    app.button(row, 'Fermer les écarts de moins de 0,1 mm', close_them).pack(side='left')
    app.button(row, 'Fermer', done).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win._close_them = close_them
    win._text = text
    return win
