"""Physical A4 nesting, grouped by workspace zone; source drawings stay unchanged.
0.18.1: the paper can be A4, A3, A2, A1 or A0 (portrait), chosen in the PDF window.
0.18.5: the pieces are packed on their real shape (outline, crans, texts + the gap), turned by
quarters, small ones in the hollows of the others; several orders tried within BUDGET seconds and
the best kept (fewest pages, then the most compact); a final check that no piece comes nearer
another than the gap. Every piece stays INSET mm inside the dashed frame and the content clip is
larger than the area by half the widest line (stroke_reach): a line is never cut at the frame.
« Classer : tout ensemble / par type de pièce » (together): one packing for every zone, or the
pages of each zone of the base (a piece outside the base: the zone of its material's type).
0.18.7: the packing can also be run a small step at a time (plan_steps, a generator: the PDF window
packs behind, between the events of the interface); the same steps in the same order, so the same
pages; organized_plan runs them at once."""
import copy
import math
import time
from geometry import path,bounds,export_entities

W,H=190.,277.
GAP=5.
A4=(210.,297.)
MARGIN=5.        # 0.16.29: default page margin (was 10 mm); the pattern always stays at 100 %
HEAD=6.          # band for the page title, inside the frame
PRINTABLE=4.5    # the title never goes nearer the paper edge: printers cannot print there
OVERLAP=5.       # overlap between the tiles of a piece larger than a page
INSET=1.         # 0.18.5: a piece is never nearer the dashed frame than this (its line is never cut)
BUDGET=2.        # 0.18.5: seconds spent at most trying packing orders (the first one is always done)
PAPERS={'A4':(210.,297.),'A3':(297.,420.),'A2':(420.,594.),'A1':(594.,841.),'A0':(841.,1189.)}


def complete(steps):
    """0.18.7: runs a generator of steps to its end; what it returns."""
    while True:
        try:next(steps)
        except StopIteration as stop:return stop.value


def paper_name(paper):
    return paper if paper in PAPERS else 'A4'


def paper_size(paper='A4'):
    """Width and height (portrait) of a paper in mm; A4 for an unknown name."""
    return PAPERS[paper_name(paper)]


def page_area(margin=MARGIN,paper='A4'):
    """Content area of a page for a margin in mm: left, top (from the top edge), width,
    height. The dashed frame is at the margin; the title sits inside it, above the content."""
    m=min(30.,max(0.,float(margin)));top=max(m,PRINTABLE)+HEAD;pw,ph=paper_size(paper)
    return (m,top,pw-2*m,ph-m-top)


def zone_at(point,workspace):
    if not workspace:return 'Dessin'
    from cad import column_labels
    x=workspace.get('origin_x',0)
    for k,(label,width) in enumerate(zip(column_labels(workspace),workspace['widths'])):   # 0.19.13: the base's own names
        if x<=point[0]<x+width:return label.capitalize() or f'Colonne {k+1}'
        x+=width
    return 'Hors zones'


def type_zone(members,archives,workspace=None):
    """0.18.5: for a piece outside the zones of the base, the zone of its material's type (Cuir →
    Dessus, Tissu → Doublures, Renfort → Renforts, Gabarit → Aides); None when it is not known.
    0.19.13: the first column of the base that holds that type."""
    import re
    import materials
    from cad import column_labels,column_types,default_workspace
    from entity_rules import identification_kind
    base=workspace or default_workspace('maro');labels=column_labels(base)
    for s in members:
        if identification_kind(s)!='material':continue
        name=str(((s.get('identification') or {}).get('values') or [''])[0] or '').strip()
        if not name and s.get('text_runs'):m=re.match(r'^\d+\s+(.*)$',s['text_runs'][0].get('text',''));name=m[1].strip() if m else ''
        kind=materials.info(archives,name)['type'] if name else None
        for col in range(len(labels)):
            kinds=column_types(base,col)
            if kinds and kinds[0]==kind:return labels[col].capitalize() or f'Colonne {col+1}'
    return None


def groups(items,workspace,archives=None):
    """Keep a finished outline, its inner marks, labels and nearby crans together.
    0.18.5: ``archives``: a piece outside the zones of the base takes the zone of its material's type."""
    return complete(_group_steps(items,workspace,archives))


def _group_steps(items,workspace,archives=None):
    """0.18.7: groups() an object at a time (a generator returning the groups)."""
    import materials
    from cad import LABELS
    from cad import column_labels,column_types
    typed={(label.capitalize() or f'Colonne {col+1}') for col,label in enumerate(column_labels(workspace)) if column_types(workspace,col)} if workspace else set()
    from precision_geometry import contour_location
    from craft_tools import style
    boxes=[bounds([s]) for s in items]
    # 0.18.0: a closed stitch (Piqûre) is not a piece either: it goes with the piece around it.
    roots=[i for i,s in enumerate(items) if path(s)[1] and not(s.get('annotation') or s.get('drill') or s.get('filled') or s.get('is_notch') or s.get('stitch')) and style(s)['role'] not in ('internal','seam')]
    membership={i:[i] for i in roots};used=set(roots)
    for i,s in enumerate(items):
        if i in used:continue
        x,y,X,Y=boxes[i];center=((x+X)/2,(y+Y)/2);candidates=[]
        for j in roots:
            a,b,A,B=boxes[j]
            contained=a-1<=x and b-1<=y and X<=A+1 and Y<=B+1
            if not contained and (X<a-35 or x>A+35 or Y<b-35 or y>B+35):continue
            near=math.dist(contour_location(items[j],center)[1],center)
            if contained or ((s.get('is_notch') or s.get('annotation') or s.get('dimension_group')) and near<=35):
                candidates.append((0 if contained else 1,near,(A-a)*(B-b),j))
        if candidates:membership[min(candidates)[-1]].append(i);used.add(i)
        yield
    # Unjoined connected paths form one print group, without changing the document.
    remaining=[i for i in range(len(items)) if i not in used];parent={i:i for i in remaining}
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    by_dimension={}
    for i in remaining:
        group=items[i].get('dimension_group')
        if group:
            if group in by_dimension:parent[find(i)]=find(by_dimension[group])
            by_dimension[group]=i
    for i in remaining:
        if not items[i].get('is_notch'):continue
        origin=path(export_entities([items[i]])[0])[0][0]
        hosts=[(math.dist(contour_location(items[j],origin)[1],origin),j) for j in remaining if j!=i and not items[j].get('is_notch') and not items[j].get('annotation')]
        if hosts and min(hosts)[0]<.02:parent[find(i)]=find(min(hosts)[1])
        yield
    ends={}
    for i in remaining:
        pts,_=path(items[i])
        for p in (pts[0],pts[-1]):
            key=(round(p[0]/.02),round(p[1]/.02))
            if key in ends:parent[find(i)]=find(ends[key])
            ends[key]=i
    for i in remaining:membership.setdefault(find(i),[]).append(i)
    result=[]
    for indices in membership.values():
        entities=export_entities([items[i] for i in indices],pdf=True);box=bounds(entities);x,y,X,Y=box
        zone=zone_at(((x+X)/2,(y+Y)/2),workspace)
        if zone not in typed:zone=type_zone([items[i] for i in indices],archives,workspace) or zone
        result.append(dict(entities=entities,box=box,zone=zone))
        yield
    return result


def rotate(entities):
    from advanced_edit import mirror
    return [mirror(mirror(s,(0,0),(1,0)),(0,0),(1,1)) for s in entities]


def moved(entities,dx,dy):
    from geometry import clone
    result=clone(entities)            # 0.18.5: marshal copy, ten times faster than deepcopy
    for s in result:s['x']+=dx;s['y']+=dy
    return result


def split_free(rectangles,used):
    x,y,w,h=used;out=[]
    for a,b,c,d in rectangles:
        if x>=a+c or x+w<=a or y>=b+d or y+h<=b:out.append((a,b,c,d));continue
        if x>a:out.append((a,b,x-a,d))
        if x+w<a+c:out.append((x+w,b,a+c-x-w,d))
        if y>b:out.append((a,b,c,y-b))
        if y+h<b+d:out.append((a,y+h,c,b+d-y-h))
    out=[r for r in out if min(r[2:])>.01]
    return [r for i,r in enumerate(out) if not any(i!=j and q[0]<=r[0]+1e-8 and q[1]<=r[1]+1e-8 and q[0]+q[2]>=r[0]+r[2]-1e-8 and q[1]+q[3]>=r[1]+r[3]-1e-8 and (q!=r or j<i) for j,q in enumerate(out))]


def page_has_ink(entities,origin,size=(W,H)):
    from export_preview import clip_segment
    ox,oy=origin;box=(ox,oy,ox+size[0],oy+size[1])
    for s in entities:
        x,y,X,Y=bounds([s])
        if x>box[2] or X<box[0] or y>box[3] or Y<box[1]:continue           # 0.18.5: away from the page
        if s.get('annotation'):
            if x<box[2] and X>box[0] and y<box[3] and Y>box[1]:return True
        elif box[0]<=x and X<=box[2] and box[1]<=y and Y<=box[3]:return True
        else:
            pts,closed=path(s);pts=pts+pts[:1] if closed else pts
            if any(clip_segment(a,b,box) for a,b in zip(pts,pts[1:])):return True
    return False


def zone_pages(section,zone,W,H,GAP):
    """The 0.17 packing of one zone: pieces placed page by page; a piece larger than a page gets
    its own tiles, whose free margins take smaller pieces of the same zone.
    0.18.5: zone_pages / sheet_pages (by rectangles, flush with the frame) are no longer used by
    organized_plan: kept as the reference of the former packing (tests compare with it)."""
    SX,SY=W-OVERLAP,H-OVERLAP;pages=[]
    bins=[]
    for group in sorted(section,key=lambda g:max(g['box'][2]-g['box'][0],g['box'][3]-g['box'][1]),reverse=True):
        original=group['entities'];options=[(original,group['box'])]
        turned=rotate(original);options.append((turned,bounds(turned)))
        fit=[]
        for index,bin in enumerate(bins):
            for option,(entities,(x,y,X,Y)) in enumerate(options):
                w,h=max(.01,X-x),max(.01,Y-y)
                for a,b,c,d in bin['free']:
                    if w<=c+1e-6 and h<=d+1e-6:fit.append((min(c-w,d-h),max(c-w,d-h),index,option,a,b,w,h))
        if not fit:
            eligible=[(i,box) for i,(_,box) in enumerate(options) if box[2]-box[0]<=W+1e-6 and box[3]-box[1]<=H+1e-6]
            if eligible:
                index=len(bins);bins.append(dict(items=[],free=[(0.,0.,W,H)],zone=zone,placements=[]))
                option,box=min(eligible,key=lambda v:max(v[1][2]-v[1][0],v[1][3]-v[1][1]));x,y,X,Y=box
                fit=[(0,0,index,option,0.,0.,max(.01,X-x),max(.01,Y-y))]
            else:
                # Only pieces too large for one A4 are tiled, with 5 mm overlap.
                def tile_count(option):
                    x,y,X,Y=option[1];return max(1,math.ceil(max(0,X-x-OVERLAP)/SX))*max(1,math.ceil(max(0,Y-y-OVERLAP)/SY))
                entities,box=min(options,key=tile_count);x,y,X,Y=box;entities=moved(entities,-x,-y)
                nx=max(1,math.ceil(max(0,X-x-OVERLAP)/SX));ny=max(1,math.ceil(max(0,Y-y-OVERLAP)/SY))
                if nx*ny>400:raise ValueError('Plus de 400 pages : pièce trop grande.')
                for row in range(ny):
                    for col in range(nx):
                        origin=(col*SX,row*SY)
                        if page_has_ink(entities,origin,(W,H)):
                            # Keep the tile's registration coordinates while offering its
                            # unused margins to smaller pieces from the same zone.
                            ox,oy=origin
                            a=max(0.,-ox);b=max(0.,-oy);A=min(W,X-x-ox);B=min(H,Y-y-oy)
                            occupied=(a,b,max(0.,A-a),max(0.,B-b))
                            free=split_free([(0.,0.,W,H)],(max(0.,a-GAP),max(0.,b-GAP),min(W,A+GAP)-max(0.,a-GAP),min(H,B+GAP)-max(0.,b-GAP)))
                            bins.append(dict(items=copy.deepcopy(entities),origin=origin,zone=zone,col=col,row=row,columns=nx,rows=ny,free=free,placements=[occupied],zones=[group['zone']]))
                continue
        _,_,index,option,a,b,w,h=min(fit,key=lambda f:(f[2],f[0],f[1],f[5],f[4]));entities,box=options[option];x,y,X,Y=box;bin=bins[index]
        if group['zone'] not in bin.setdefault('zones',[]):bin['zones'].append(group['zone'])
        ox,oy=bin.get('origin',(0.,0.));placed=moved(entities,a-x+ox,b-y+oy);bin['items'].extend(placed);bin['placements'].append((a,b,w,h))
        bin['free']=split_free(bin['free'],(a,b,min(W-a,w+GAP),min(H-b,h+GAP)))
    for bin in bins:
        if bin['items']:pages.append(dict(items=bin['items'],origin=bin.get('origin',(0.,0.)),zone=zone or ' + '.join(bin.get('zones') or ['Pièces']),col=bin.get('col',0),row=bin.get('row',0),columns=bin.get('columns',1),rows=bin.get('rows',1),placements=bin['placements']))
    return pages


def _tiles(box,SX,SY,W,H,eps=1e-6):
    """The tiles (column, row) of a sheet that a rectangle (x, y, w, h) reaches."""
    x,y,w,h=box
    c0=max(0,math.floor((x+eps-W)/SX)+1);c1=math.ceil((x+w-eps)/SX)-1
    r0=max(0,math.floor((y+eps-H)/SY)+1);r1=math.ceil((y+h-eps)/SY)-1
    return {(c,r) for c in range(c0,c1+1) for r in range(r0,r1+1)}


def _place_large(large,k,W,H,GAP,order):
    """The large pieces on a sheet k tiles wide: each where it reaches the fewest new tiles
    (then the highest, then the leftmost). [(group, entities, (x, y, w, h))] or None."""
    SX,SY=W-OVERLAP,H-OVERLAP;SW=k*SX+OVERLAP;BIG=1e7
    free=[(0.,0.,SW+GAP,BIG)];used=set();out=[]
    for g in order(large):
        best=None;turned=rotate(g['entities'])
        for entities,(x,y,X,Y) in ((g['entities'],g['box']),(turned,bounds(turned))):
            w,h=X-x,Y-y
            if w>SW+1e-6:continue
            for a,b,c,d in free:
                if w+GAP>c+1e-6 or h+GAP>d+1e-6:continue
                xs={a,a+c-w-GAP};ys={b}
                for n in range(int(a//SX),int((a+c)//SX)+2):xs.update((n*SX,n*SX+W-w))
                for n in range(int(b//SY),int(b//SY)+3):ys.update((n*SY,n*SY+H-h))
                for px in xs:
                    if not(a-1e-6<=px<=a+c-w-GAP+1e-6) or px<-1e-6 or px+w>SW+1e-6:continue
                    for py in ys:
                        if not(b-1e-6<=py<=b+d-h-GAP+1e-6):continue
                        tiles=_tiles((px,py,w,h),SX,SY,W,H);score=(len(tiles-used),round(py+h,3),round(px,3),entities is not g['entities'])
                        if best is None or score<best[0]:best=(score,entities,(px,py,w,h),tiles,(x,y))
        if best is None:return None
        _,entities,box,tiles,(x,y)=best;px,py,w,h=box
        out.append((g,moved(entities,px-x,py-y),box));used|=tiles
        free=split_free(free,(px,py,w+GAP,h+GAP))
    return out


def sheet_pages(section,zone,W,H,GAP):
    """0.18.0: the pieces larger than a page laid out together on one sheet of A4 tiles (5 mm
    overlap) so that they share their pages with each other and with the smaller pieces; a piece
    that fits a page is never cut: it goes whole into the free part of a tile already printed,
    else onto a new page. None when the zone has no piece larger than a page."""
    SX,SY=W-OVERLAP,H-OVERLAP
    def size(g):x,y,X,Y=g['box'];return X-x,Y-y
    fits=lambda w,h:(w<=W+1e-6 and h<=H+1e-6) or (h<=W+1e-6 and w<=H+1e-6)
    large=[g for g in section if not fits(*size(g))];small=[g for g in section if fits(*size(g))]
    if not large:return None
    need=max(math.ceil(max(0.,min(size(g))-OVERLAP)/SX) for g in large)
    orders=[lambda gs:sorted(gs,key=lambda g:size(g)[0]*size(g)[1],reverse=True),
            lambda gs:sorted(gs,key=lambda g:max(size(g)),reverse=True),
            lambda gs:sorted(gs,key=lambda g:min(size(g)),reverse=True)]
    best=None
    for k in range(max(1,need),max(1,need)+4):
        for order in orders:
            placed=_place_large(large,k,W,H,GAP,order)
            if placed is None:continue
            pages=_complete(placed,small,k,zone,W,H,GAP)
            turned=sum(1 for g,entities,box in placed if abs(box[2]-(g['box'][2]-g['box'][0]))>1e-6)
            key=(len(pages),turned,k)
            if best is None or key<best[0]:best=(key,pages)
    return best[1] if best else None


def _complete(placed,small,k,zone,W,H,GAP):
    """Pages of a sheet: the printed tiles (the small pieces whole in their free part), then new
    pages for the small pieces left."""
    SX,SY=W-OVERLAP,H-OVERLAP
    sheet=[e for _,entities,_ in placed for e in entities]
    boxes=[box for _,_,box in placed]
    reach=set().union(*(_tiles(b,SX,SY,W,H) for b in boxes))
    printed=sorted((t for t in reach if page_has_ink(sheet,(t[0]*SX,t[1]*SY),(W,H))),key=lambda t:(t[1],t[0]))
    rows=max(r for _,r in reach)+1
    tiles={}
    for c,r in printed:
        # A small piece stays inside the tile's own part (not in the strips shared with the
        # next tiles): it is printed whole, once.
        left=c*SX+(OVERLAP if c>0 else 0.);top=r*SY+(OVERLAP if r>0 else 0.);right=c*SX+(W if c==k-1 else SX);bottom=r*SY+SY
        free=[(left,top,right-left,bottom-top)]
        for x,y,w,h in boxes:free=split_free(free,(x-GAP,y-GAP,w+2*GAP,h+2*GAP))
        tiles[(c,r)]=dict(free=free,items=[],placements=[])
    rest=[]
    for g in sorted(small,key=lambda g:(g['box'][2]-g['box'][0])*(g['box'][3]-g['box'][1]),reverse=True):
        options=[(g['entities'],g['box'])];turned=rotate(g['entities']);options.append((turned,bounds(turned)))
        fit=None
        for t,tile in tiles.items():
            for entities,(x,y,X,Y) in options:
                w,h=X-x,Y-y
                for a,b,c,d in tile['free']:
                    if w<=c+1e-6 and h<=d+1e-6:
                        score=(t[1],t[0],min(c-w,d-h),max(c-w,d-h))   # the first tile where it fits, then the best fit
                        if fit is None or score<fit[0]:fit=(score,t,entities,(x,y),(a,b,w,h))
        if fit is None:rest.append(g);continue
        _,t,entities,(x,y),(a,b,w,h)=fit;tile=tiles[t]
        tile['items']+=moved(entities,a-x,b-y);tile['placements'].append((a-t[0]*SX,b-t[1]*SY,w,h))
        tile['free']=split_free(tile['free'],(a,b,w+GAP,h+GAP))
    pages=[]
    for (c,r) in printed:
        ox,oy=c*SX,r*SY;tile=tiles[(c,r)]
        mine=[e for (g,entities,box) in placed if _tiles(box,SX,SY,W,H)&{(c,r)} for e in entities]
        cut=[(max(0.,x-ox),max(0.,y-oy),min(W,x+w-ox)-max(0.,x-ox),min(H,y+h-oy)-max(0.,y-oy)) for x,y,w,h in boxes if (c,r) in _tiles((x,y,w,h),SX,SY,W,H)]
        pages.append(dict(items=mine+tile['items'],origin=(ox,oy),zone=zone or ' + '.join(sorted({g['zone'] for g,_,_ in placed})) or 'Pièces',
                          col=c,row=r,columns=k,rows=rows,placements=cut+tile['placements']))
    if rest:pages+=zone_pages(rest,zone,W,H,GAP)
    return pages


# ----------------------------------------------------------------------------------------------
# 0.18.5 packing on the real shape of the pieces. A page is a grid of square cells (1 mm on A4);
# a piece is the set of cells it touches (outline filled, every line, text boxes: never smaller
# than the piece), grown by the gap for the pieces already placed. A whole page is one Python
# integer (bit y*S+x = cell x of row y), so one shift tests a run of cells at every position of
# the page at once: the first free position (top, then left) of a piece is a few hundred integer
# operations. Two pieces whose cells do not meet are at least the gap apart (cells never smaller
# than what they hold, growth by the nearest distance between two cells).

def stroke_reach(items):
    """0.18.5: half the widest line of a page (mm): the content clip of the PDF, of the preview and
    of the direct printing is that much larger than the area, so no line is cut at the frame."""
    from craft_tools import style
    return max([float(style(s).get('width',.2)) for s in items] or [0.])/2


def cell_size(W,H):
    """Side of a packing cell (mm): 1 mm up to A3, coarser on A2 to A0 (bounded time)."""
    return max(1.,math.sqrt(W*H/120000.))


def _ones(n):return (1<<n)-1 if n>0 else 0


def _raster(entities,x0,y0,c,nx,ny):
    """Rows of bits (bit i = column i) of the cells of side ``c`` from (x0, y0) that the entities
    touch: closed outlines filled, every line and text box. The grid is the entities' own box: a
    point on its far side (cell nx or ny) belongs to the last cell."""
    return complete(_raster_steps(entities,x0,y0,c,nx,ny))


def _raster_steps(entities,x0,y0,c,nx,ny):
    """0.18.7: _raster() a line at a time."""
    rows=[0]*ny;floor=math.floor;X,Y=nx-1,ny-1
    def mark(i0,i1,j0,j1):
        i0=0 if i0<0 else X if i0>X else i0;i1=0 if i1<0 else X if i1>X else i1;j0=0 if j0<0 else Y if j0>Y else j0;j1=0 if j1<0 else Y if j1>Y else j1
        bits=_ones(i1-i0+1)<<i0
        for j in range(j0,j1+1):rows[j]|=bits
    def fill(pts):
        cross={};n=len(pts)
        for k in range(n):
            (ax,ay),(bx,by)=pts[k],pts[(k+1)%n]
            if ay==by:continue
            if ay>by:ax,ay,bx,by=bx,by,ax,ay
            for j in range(max(0,math.ceil((ay-y0)/c-.5)),min(ny-1,math.ceil((by-y0)/c-.5)-1)+1):
                yc=y0+(j+.5)*c;cross.setdefault(j,[]).append(ax+(yc-ay)*(bx-ax)/(by-ay))
        for j,xs in cross.items():
            xs.sort()
            for xa,xb in zip(xs[::2],xs[1::2]):
                i0=max(0,math.ceil((xa-x0)/c-.5));i1=min(nx-1,floor((xb-x0)/c-.5))
                if i0<=i1:rows[j]|=_ones(i1-i0+1)<<i0
    for s in entities:
        if s.get('annotation'):
            ax,ay,bx,by=bounds([s]);i0=floor((ax-x0)/c+1e-7);j0=floor((ay-y0)/c+1e-7)
            mark(i0,max(i0,math.ceil((bx-x0)/c-1e-7)-1),j0,max(j0,math.ceil((by-y0)/c-1e-7)-1));continue
        pts,closed=path(s)
        if not pts:continue
        if closed and len(pts)>2:fill(pts);yield
        # A line: the cells of its points and, between two points, every cell of their box (a
        # long side is cut so that its pieces go from a cell to a neighbouring one).
        pi=pj=px=py=None
        for x,y in (pts+pts[:1] if closed else pts):
            i=floor((x-x0)/c+1e-7);j=floor((y-y0)/c+1e-7)
            if pi is None:mark(i,i,j,j)
            elif i!=pi or j!=pj:
                n=max(abs(i-pi),abs(j-pj))
                if n==1:mark(min(i,pi),max(i,pi),min(j,pj),max(j,pj))
                else:
                    qi,qj=pi,pj
                    for k in range(1,n+1):
                        ri=floor((px+(x-px)*k/n-x0)/c+1e-7);rj=floor((py+(y-py)*k/n-y0)/c+1e-7)
                        mark(min(ri,qi),max(ri,qi),min(rj,qj),max(rj,qj));qi,qj=ri,rj
            pi,pj,px,py=i,j,x,y
        yield
    return rows


def _reach(gap,c):
    """Growth of a piece by the gap, row by row: [columns reached at 0, 1, 2… rows away]. A cell
    is reached when the nearest points of the two cells are less than the gap apart."""
    R=max(0,math.ceil(gap/c-1e-9))
    return [math.ceil(math.sqrt(max(0.,gap*gap-(max(0,d-1)*c)**2))/c-1e-9) for d in range(R+1)]


def _grow(rows,reach):
    """The rows grown by the gap: R more rows and columns on each side (R = len(reach)-1)."""
    R=len(reach)-1;out=[0]*(len(rows)+2*R)
    for j,row in enumerate(rows):
        if not row:continue
        spread={}
        for d in range(-R,R+1):
            r=reach[abs(d)]
            if r not in spread:spread[r]=_spread_up(row<<(R-r),2*r+1)
            out[j+d+R]|=spread[r]
    return out


def _spread_up(v,n):
    """OR of v << k for k < n."""
    k=1
    while 2*k<=n:v|=v<<k;k*=2
    if k<n:v|=v<<(n-k)
    return v


def _spread_down(v,n,step=1):
    """OR of v >> (k*step) for k < n."""
    k=1
    while 2*k<=n:v|=v>>(k*step);k*=2
    if k<n:v|=v>>((n-k)*step)
    return v


def _runs(v):
    """(left, width) of the runs of set bits of v."""
    out=[];i=0
    while v:
        low=(v&-v).bit_length()-1;v>>=low;i+=low;n=(v^(v+1)).bit_length()-1;out.append((i,n));v>>=n;i+=n
    return out


class _Shape:
    """A print group turned ``turn`` quarters, as cells: size (pw, ph), area, runs (row, left,
    width, rows) for the fit test, ``grown``: its rows grown by the gap (R rows / columns more)."""
    def __init__(self,entities,turn,c,reach):complete(self.build(entities,turn,c,reach))
    def build(self,entities,turn,c,reach):
        """0.18.7: the shape made in steps (its cells line by line, then their growth)."""
        self.entities=entities;self.turn=turn;self.box=bounds(entities);x,y,X,Y=self.box
        self.pw=max(1,math.ceil((X-x)/c-1e-7));self.ph=max(1,math.ceil((Y-y)/c-1e-7))
        self.rows=yield from _raster_steps(entities,x,y,c,self.pw,self.ph)
        # Lines without any closed outline (not a finished piece): their whole box, nothing inside.
        if not any(path(s)[1] and len(path(s)[0])>2 for s in entities if not s.get('annotation')):self.rows=[_ones(self.pw)]*self.ph
        self.area=sum(r.bit_count() for r in self.rows)
        self.runs=[];j=0
        while j<self.ph:
            m=1
            while j+m<self.ph and self.rows[j+m]==self.rows[j]:m+=1
            self.runs+=[(j,l,w,m) for l,w in _runs(self.rows[j])];j+=m
        self.runs.sort(key=lambda r:-r[2]*r[3])          # the widest first: a refused fit stops sooner
        yield
        self.grown=_grow(self.rows,reach);self.blocks={}
        self.side=(sum(1 for v in self.rows if v&1),sum(1 for v in self.rows if v>>(self.pw-1)&1),self.rows[0].bit_count(),self.rows[-1].bit_count())
        self.border=max(1,self.pw+self.ph)
    def ring(self,S):
        """The cells around the shape (one cell more, the shape left out), rows S bits apart, from
        one row above and one column left of it."""
        key=('ring',S);r=self.blocks.get(key)
        if r is None:
            rows=[0]+self.rows+[0];r=0
            for k,v in enumerate(rows):
                v<<=1;near=v|v<<1|v>>1
                if k:near|=rows[k-1]<<1
                if k+1<len(rows):near|=rows[k+1]<<1
                r|=(near&~v)<<(k*S)
            self.blocks[key]=r
        return r
    def block(self,S):
        """The grown rows as one integer of rows S bits apart."""
        b=self.blocks.get(S)
        if b is None:
            b=0
            for k,row in enumerate(self.grown):b|=row<<(k*S)
            self.blocks[S]=b
        return b


class _Grid:
    """The cells of a page's usable area: Wc × Hc cells of side c from (x0, y0) (page mm), rows
    S = Wc + R bits apart (R spare columns: the growth of a piece never spills on the next row)."""
    def __init__(self,W,H,c,inset,reach):
        self.c=c;self.x0=self.y0=inset;self.Wc=max(1,math.floor((W-2*inset)/c+1e-7));self.Hc=max(1,math.floor((H-2*inset)/c+1e-7))
        self.R=len(reach)-1;self.S=self.Wc+max(1,self.R);self.reach=reach;self.masks={}
        self.column=_ones(self.S*self.Hc)//_ones(self.S);self.area=self.column*_ones(self.Wc)     # bit 0 of each row; every usable cell
    def positions(self,pw,ph):
        """Every allowed position (bit y*S+x) of a piece of pw × ph cells."""
        key=(pw,ph);m=self.masks.get(key)
        if m is None:
            n=self.Hc-ph+1;k=self.Wc-pw+1
            m=(_ones(self.S*n)//_ones(self.S))*_ones(k) if n>0 and k>0 else 0;self.masks[key]=m
        return m


class _Bin:
    """One page being filled: occupied cells (grown by the gap), what is printed on it."""
    def __init__(self,grid,origin=(0.,0.),**spec):
        self.g=grid;self.occ=0;self.free=grid.Wc*grid.Hc;self.cache={};self.powers=[0];self.placements=[];self.zones=[];self.parts=[];self.failed=set()
        self.origin=origin;self.spec=spec;self.bottom=0.
    def copy(self):
        out=copy.copy(self);out.cache=dict(self.cache);out.powers=list(self.powers);out.placements=list(self.placements);out.zones=list(self.zones);out.parts=list(self.parts);out.failed=set(self.failed);return out
    def changed(self):self.cache={};self.powers=[self.occ]
    def window(self,w,m):
        """Bit p set when a cell of the w × m cells from p (right, down) is occupied."""
        key=(w,m);v=self.cache.get(key)
        if v is None:
            if m>1:v=_spread_down(self.window(w,1),m,self.g.S)
            else:
                p=self.powers;k=w.bit_length()-1
                while len(p)<=k:q=p[-1];p.append(q|q>>(1<<(len(p)-1)))
                v=p[k] if w==1<<k else p[k]|p[k]>>(w-(1<<k))
            self.cache[key]=v
        return v
    def fit(self,shape):
        """The free positions (y, x) of the shape worth trying: the highest (then leftmost) and the
        leftmost (then highest); [] when it does not fit."""
        g=self.g;S=g.S
        if shape.area>self.free:return []
        valid=g.positions(shape.pw,shape.ph)
        if not valid:return []
        if self.occ:
            for j,l,w,m in shape.runs:
                valid&=~(self.window(w,m)>>(j*S+l))
                if not valid:return []
        out=[divmod((valid&-valid).bit_length()-1,S)]
        column=_spread_down(valid,g.Hc,S)&_ones(S);x=(column&-column).bit_length()-1
        v=(valid>>x)&g.column;y=((v&-v).bit_length()-1)//S
        if (y,x)!=out[0]:out.append((y,x))
        return out
    def contact(self,shape,x,y):
        """How much of the shape's border touches the pieces already there (at the gap) or the
        frame, by length of its border: a snug position scores high."""
        g=self.g;S=g.S;s=(y-1)*S+(x-1);r=shape.ring(S);r=r<<s if s>=0 else r>>-s
        n=(self.occ&g.area&r).bit_count()
        if x==0:n+=shape.side[0]
        if x+shape.pw==g.Wc:n+=shape.side[1]
        if y==0:n+=shape.side[2]
        if y+shape.ph==g.Hc:n+=shape.side[3]
        return n/shape.border
    def put(self,shape,x,y,gi,zone):
        g=self.g;S=g.S;R=g.R;shift=(y-R)*S+(x-R);b=shape.block(S)
        self.occ|=b<<shift if shift>=0 else b>>-shift
        self.changed();self.free-=shape.area
        px,py=g.x0+x*g.c,g.y0+y*g.c;bx,by,BX,BY=shape.box;ox,oy=self.origin
        self.parts.append((shape,px-bx+ox,py-by+oy));self.placements.append((px,py,BX-bx,BY-by))
        self.bottom=max(self.bottom,py+BY-by)
        if zone not in self.zones:self.zones.append(zone)
    def stamp(self,shape,px,py):
        """A piece already placed at (px, py) (page mm, its box corner, anywhere): its grown cells
        that fall on the grid, on both cells when the position is between two cells."""
        g=self.g;S=g.S;R=g.R;fx=(px-g.x0)/g.c;fy=(py-g.y0)/g.c;ix=math.floor(fx+1e-7);iy=math.floor(fy+1e-7)
        row=_ones(g.Wc)
        for x in {ix,ix+(fx-ix>1e-7)}:
            for y in {iy,iy+(fy-iy>1e-7)}:
                for k in range(max(0,R-y),min(len(shape.grown),R-y+g.Hc)):
                    r=y-R+k;v=shape.grown[k]
                    if v:
                        s=x-R;v=(v<<s if s>=0 else v>>-s)&row
                        if v:self.occ|=v<<(r*S)
        self.changed();self.free=g.Wc*g.Hc-self.occ.bit_count()
    def block_outside(self,left,top,right,bottom):
        """Only the cells inside this rectangle (page mm) stay usable."""
        g=self.g;S=g.S;i0=max(0,math.ceil((left-g.x0)/g.c-1e-7));i1=min(g.Wc,math.floor((right-g.x0)/g.c+1e-7))
        j0=max(0,math.ceil((top-g.y0)/g.c-1e-7));j1=min(g.Hc,math.floor((bottom-g.y0)/g.c+1e-7))
        keep=_ones(i1-i0)<<i0 if i1>i0 else 0;full=_ones(g.Wc)
        for r in range(g.Hc):
            v=full&~keep if j0<=r<j1 else full
            if v:self.occ|=v<<(r*S)
        self.changed();self.free=g.Wc*g.Hc-self.occ.bit_count()


def _turns(group,c,reach,count=4):
    """The shapes of a group turned 0, 1, 2 and 3 quarters (a turn giving the same cells as an
    earlier one is left out: a rectangle has 2); ``count``: only the first turns."""
    return complete(_turn_steps(group,c,reach,count))


def _turn_steps(group,c,reach,count=4):
    """0.18.7: _turns() a turn at a time."""
    out=[];entities=group['entities'];seen=set()
    texts=any(s.get('annotation') for s in entities)
    for turn in range(count):
        if turn:entities=rotate(entities);yield
        if turn==2 and texts:continue   # a half turn would print its name and texts upside down
        shape=_Shape.__new__(_Shape);yield from shape.build(entities,turn,c,reach);key=(shape.pw,shape.ph,tuple(shape.rows))
        if key not in seen:seen.add(key);out.append(shape)
        yield
    return out


def _large_layouts(large,squeezed,W,H,GAP,inset):
    """The arrangements of the pieces larger than a page: each on its own tiles (0.17), or all on
    one sheet k tiles wide (0.18.0), kept INSET mm inside the outer frame of their tiles. A sheet:
    dict(columns, placed=[(group index, shape, (x, y, w, h) on the sheet)]). The pieces that only
    fit a page without the inset are centred alone on a page."""
    return complete(_layout_steps(large,squeezed,W,H,GAP,inset))


def _layout_steps(large,squeezed,W,H,GAP,inset):
    """0.18.7: _large_layouts() a sheet at a time."""
    SX,SY=W-OVERLAP,H-OVERLAP;layouts=[];own=[]
    for gi,shapes in squeezed:
        shape=min(shapes[:2],key=lambda s:(s.box[2]-s.box[0]>W+1e-6 or s.box[3]-s.box[1]>H+1e-6,s.turn));x,y,X,Y=shape.box
        own.append(dict(columns=1,alone=True,placed=[(gi,shape,((W-(X-x))/2,(H-(Y-y))/2,X-x,Y-y))]))
    def count(shape):
        x,y,X,Y=shape.box;return max(1,math.ceil(max(0,X-x+2*inset-OVERLAP)/SX))*max(1,math.ceil(max(0,Y-y+2*inset-OVERLAP)/SY))
    separate=[]
    for gi,shapes in large:
        shape=min([s for s in shapes if s.turn<2],key=count);x,y,X,Y=shape.box
        if count(shape)>400:raise ValueError('Plus de 400 pages : pièce trop grande.')
        separate.append(dict(columns=max(1,math.ceil(max(0,X-x+2*inset-OVERLAP)/SX)),placed=[(gi,shape,(inset,inset,X-x,Y-y))]))
    layouts.append(own+separate)
    if len(large)>1:
        size=lambda s:(s.box[2]-s.box[0],s.box[3]-s.box[1])
        need=max(math.ceil(max(0.,min(size(shapes[0]))+2*inset-OVERLAP)/SX) for _,shapes in large)
        orders=[lambda v:sorted(v,key=lambda e:size(e[1][0])[0]*size(e[1][0])[1],reverse=True),lambda v:sorted(v,key=lambda e:max(size(e[1][0])),reverse=True),lambda v:sorted(v,key=lambda e:min(size(e[1][0])),reverse=True)]
        seen=set()
        for k in range(max(1,need),max(1,need)+4):
            for order in orders:
                placed=_sheet(order(large),k,W,H,GAP,inset);yield
                if placed is None:continue
                key=tuple(sorted((gi,s.turn,round(b[0],3),round(b[1],3)) for gi,s,b in placed))
                if key not in seen:seen.add(key);layouts.append(own+[dict(columns=k,placed=placed)])
    return layouts


def _sheet(large,k,W,H,GAP,inset):
    """0.18.0 _place_large on shapes, INSET mm inside the outer frame of the sheet: each piece
    where it reaches the fewest new tiles (then the highest, then the leftmost)."""
    SX,SY=W-OVERLAP,H-OVERLAP;SW=k*SX+OVERLAP;BIG=1e7
    free=[(inset,inset,SW-2*inset+GAP,BIG)];used=set();out=[]
    for gi,shapes in large:
        best=None
        for shape in shapes:
            if shape.turn>1:continue
            x,y,X,Y=shape.box;w,h=X-x,Y-y
            if w>SW-2*inset+1e-6:continue
            for a,b,c,d in free:
                if w+GAP>c+1e-6 or h+GAP>d+1e-6:continue
                xs={a,a+c-w-GAP};ys={b}
                for n in range(int(a//SX),int((a+c)//SX)+2):xs.update((n*SX+inset,n*SX+W-w-inset))
                for n in range(int(b//SY),int(b//SY)+3):ys.update((n*SY+inset,n*SY+H-h-inset))
                for px in xs:
                    if not(a-1e-6<=px<=a+c-w-GAP+1e-6) or px<inset-1e-6 or px+w>SW-inset+1e-6:continue
                    for py in ys:
                        if not(b-1e-6<=py<=b+d-h-GAP+1e-6):continue
                        tiles=_tiles((px,py,w,h),SX,SY,W,H);score=(len(tiles-used),round(py+h,3),round(px,3),shape.turn)
                        if best is None or score<best[0]:best=(score,shape,(px,py,w,h),tiles)
        if best is None:return None
        _,shape,box,tiles=best;px,py,w,h=box;out.append((gi,shape,box));used|=tiles
        free=split_free(free,(px,py,w+GAP,h+GAP))
    return out


def _tile_bins(layout,grid,W,H,zones,inset,cache=None):
    """The printed tiles of the large pieces of a layout, as bins: their pieces stamped, the strips
    shared with a printed neighbour left out (a small piece is printed whole, once). ``cache``: the
    bins of a sheet already made for another layout."""
    return complete(_tile_steps(layout,grid,W,H,zones,inset,cache))


def _tile_steps(layout,grid,W,H,zones,inset,cache=None):
    """0.18.7: _tile_bins() a tile at a time."""
    SX,SY=W-OVERLAP,H-OVERLAP;bins=[];cache={} if cache is None else cache
    for sheet in layout:
        k=sheet['columns'];placed=sheet['placed']
        key=(k,tuple((gi,shape.turn,round(box[0],6),round(box[1],6)) for gi,shape,box in placed))
        if key in cache:bins+=cache[key];continue
        reach={(0,0)} if sheet.get('alone') else set().union(*(_tiles(box,SX,SY,W,H) for _,_,box in placed))
        def inked(t):
            ox,oy=t[0]*SX,t[1]*SY
            return any(page_has_ink(shape.entities,(ox-box[0]+shape.box[0],oy-box[1]+shape.box[1]),(W,H)) for gi,shape,box in placed if t in _tiles(box,SX,SY,W,H))
        if sheet.get('alone'):printed=[(0,0)]     # one page: a piece that only fits it without the inset
        else:
            printed=[]                # 0.18.7: a tile at a time, in the same order once sorted
            for t in reach:
                if inked(t):printed.append(t)
                yield
            printed.sort(key=lambda t:(t[1],t[0]))
        first=len(bins)
        rows=max(r for _,r in reach)+1;columns=max(k,max(c for c,_ in reach)+1);on=set(printed)
        for c,r in printed:
            ox,oy=c*SX,r*SY;b=_Bin(grid,(ox,oy),col=c,row=r,columns=columns,rows=rows)
            left=OVERLAP if (c-1,r) in on else inset;right=SX if (c+1,r) in on else W-inset
            top=OVERLAP if (c,r-1) in on else inset;bottom=SY if (c,r+1) in on else H-inset
            b.block_outside(left,top,right,bottom)
            for gi,shape,box in placed:
                x,y,w,h=box
                if not sheet.get('alone') and (c,r) not in _tiles(box,SX,SY,W,H):continue
                b.parts.append((shape,x-shape.box[0],y-shape.box[1]));b.stamp(shape,x-ox,y-oy)
                b.placements.append((max(0.,x-ox),max(0.,y-oy),min(W,x+w-ox)-max(0.,x-ox),min(H,y+h-oy)-max(0.,y-oy)))
                if zones[gi] not in b.zones:b.zones.append(zones[gi])
            bins.append(b)
            yield
        cache[key]=bins[first:]
    return bins


MODES=('contact','top','low')


def _fill(bins,small,order,grid,zones,mode='contact'):
    """Small pieces, in ``order``, each in the first page where one of its turns fits, else on a new
    page. In the page, the position and turn that touch the most (``contact``: in the hollows, along
    the others), or the highest (``top``), or whose bottom is highest (``low``)."""
    return complete(_fill_steps(bins,small,order,grid,zones,mode))


def _fill_steps(bins,small,order,grid,zones,mode='contact'):
    """0.18.7: _fill() a page tried at a time."""
    bins=[b.copy() for b in bins]
    for gi in order:
        shapes=small[gi];done=False
        for b in bins+[None]:
            if b is None:b=_Bin(grid);bins.append(b)
            best=None
            for shape in shapes:
                if (gi,shape.turn) in b.failed:continue
                spots=b.fit(shape)
                if not spots:b.failed.add((gi,shape.turn));continue
                for y,x in spots if mode=='contact' else spots[:1]:
                    key=(-b.contact(shape,x,y),y,x) if mode=='contact' else (y+shape.ph,x,y) if mode=='low' else (y,x,shape.ph)
                    if best is None or key<best[0]:best=(key,shape,x,y)
            if best:b.put(best[1],best[2],best[3],gi,zones[gi]);done=True;break
            yield
        if not done:return None
        yield
    return [b for b in bins if b.parts]


def _score(bins):
    """Fewest pages, then the most compact (the pages filled from the top)."""
    return (len(bins),round(sum(b.bottom for b in bins),3))


def _segments(entities):
    out=[]
    for s in entities:
        if s.get('annotation'):x,y,X,Y=bounds([s]);pts=[(x,y),(X,y),(X,Y),(x,Y)];closed=True
        else:pts,closed=path(s)
        seq=pts+pts[:1] if closed and len(pts)>2 else pts
        out+=list(zip(seq,seq[1:])) if len(seq)>1 else [(seq[0],seq[0])] if seq else []
    return out


def _seg_distance(a,b,p,q):
    from geometry import distance
    def side(o,u,v):return (u[0]-o[0])*(v[1]-o[1])-(u[1]-o[1])*(v[0]-o[0])
    d1,d2,d3,d4=side(p,q,a),side(p,q,b),side(a,b,p),side(a,b,q)
    if ((d1>0)!=(d2>0)) and ((d3>0)!=(d4>0)) and d1 and d2 and d3 and d4:return 0.
    return min(distance(a,p,q),distance(b,p,q),distance(p,a,b),distance(q,a,b))


def _inside(p,pts):
    hit=False
    for (ax,ay),(bx,by) in zip(pts,pts[1:]+pts[:1]):
        if (ay>p[1])!=(by>p[1]) and p[0]<ax+(p[1]-ay)*(bx-ax)/(by-ay):hit=not hit
    return hit


def apart(page_groups,gap):
    """0.18.5 final check: the groups of a page (lists of entities, page or sheet mm) never come
    nearer each other than the gap (0.01 mm tolerance), lines and text boxes, and none is inside
    another. True when the page is right."""
    return complete(_apart_steps(page_groups,gap))


def _apart_steps(page_groups,gap):
    """0.18.7: apart() a few lines at a time."""
    gap=max(0.,gap-.01);cell=max(gap,2.);data=[]
    for entities in page_groups:
        segs=_segments(entities)
        if not segs:continue
        x,y,X,Y=bounds(entities);outlines=[path(s)[0] for s in entities if not s.get('annotation') and path(s)[1] and len(path(s)[0])>2]
        data.append(((x,y,X,Y),segs,outlines))
        yield
    for n,(box,segs,outlines) in enumerate(data):
        for box2,segs2,outlines2 in data[n+1:]:
            if box[0]-gap>box2[2] or box2[0]-gap>box[2] or box[1]-gap>box2[3] or box2[1]-gap>box[3]:continue
            buckets={}
            for k,(a,b) in enumerate(segs):
                for i in range(math.floor((min(a[0],b[0])-gap)/cell),math.floor((max(a[0],b[0])+gap)/cell)+1):
                    for j in range(math.floor((min(a[1],b[1])-gap)/cell),math.floor((max(a[1],b[1])+gap)/cell)+1):buckets.setdefault((i,j),[]).append((a,b))
                if k%64==63:yield     # 0.18.7: a large piece has thousands of lines
            for k,(p,q) in enumerate(segs2):
                if k%64==63:yield
                seen=set()
                for i in range(math.floor(min(p[0],q[0])/cell),math.floor(max(p[0],q[0])/cell)+1):
                    for j in range(math.floor(min(p[1],q[1])/cell),math.floor(max(p[1],q[1])/cell)+1):
                        for a,b in buckets.get((i,j),()):
                            if (a,b) in seen:continue
                            seen.add((a,b))
                            if _seg_distance(a,b,p,q)<gap:return False
            if any(_inside(segs2[0][0],o) for o in outlines) or any(_inside(segs[0][0],o) for o in outlines2):return False
            yield
    return True


def _checked(bins,gap):
    """True when no page of these bins has two groups nearer than the gap."""
    return complete(_check_steps(bins,gap))


def _check_steps(bins,gap):
    """0.18.7: _checked() in small steps."""
    for b in bins:
        if len(b.parts)<2:continue
        page=[]
        for shape,dx,dy in b.parts:page.append(moved(shape.entities,dx,dy));yield
        if not (yield from _apart_steps(page,gap)):return False
    return True


class _Search:
    """The packing of one section (a zone, or every zone): the large pieces' layouts × orders and
    ways of placing the small pieces. ``step()`` tries one more packing: first every layout with
    the first order, then the other orders and ways on the two best layouts (``planned``), then
    small changes of the best order found; ``pages()``: the best packing whose final check is
    right (no two pieces nearer than the gap).
    0.18.7: ``prepare()``, ``step()`` and ``pages()`` are generators (complete() runs one at once)."""
    def __init__(self,section,zone,W,H,GAP,inset,tick=None):
        self.args=(section,zone,W,H,GAP,inset,tick)     # 0.18.7: the work is done by prepare()
    def prepare(self):
        """The shapes of the pieces, the layouts of the large ones and the orders to try."""
        import random
        section,zone,W,H,GAP,inset,tick=self.args
        c=cell_size(W,H);reach=_reach(GAP,c);self.grid=grid=_Grid(W,H,c,inset,reach);self.zone=zone;self.GAP=GAP
        self.zones=zones=[g['zone'] for g in section];self.small=small={};large=[];squeezed=[];SX,SY=W-OVERLAP,H-OVERLAP
        for gi,g in enumerate(section):
            x,y,X,Y=g['box'];w,h=X-x,Y-y
            if min(math.ceil(max(0,a+2*inset-OVERLAP)/SX)*math.ceil(max(0,b+2*inset-OVERLAP)/SY) for a,b in ((w,h),(h,w)))>400:raise ValueError('Plus de 400 pages : pièce trop grande.')
            # A piece that cannot fit a page turned by a quarter is tiled: only its first two turns.
            tiled=max(max(w,h)-c*grid.Hc,min(w,h)-c*grid.Wc)>c
            turns=yield from _turn_steps(g,c,reach,2 if tiled else 4);fits=[s for s in turns if s.pw<=grid.Wc and s.ph<=grid.Hc]
            if tick:tick()
            if fits:small[gi]=fits;continue
            if (w<=W+1e-6 and h<=H+1e-6) or (h<=W+1e-6 and w<=H+1e-6):squeezed.append((gi,turns))
            else:large.append((gi,turns))
        layouts=(yield from _layout_steps(large,squeezed,W,H,GAP,inset)) if large or squeezed else [[]]
        sheets={};self.starts=starts=[]
        for layout in layouts:starts.append((yield from _tile_steps(layout,grid,W,H,zones,inset,sheets)))
        first=lambda gi:small[gi][0]
        self.orders=[sorted(small,key=lambda gi:(-first(gi).area,gi)),sorted(small,key=lambda gi:(-max(first(gi).pw,first(gi).ph),-first(gi).area,gi)),
                     sorted(small,key=lambda gi:(-min(first(gi).pw,first(gi).ph),-first(gi).area,gi)),sorted(small,key=lambda gi:(-first(gi).pw*first(gi).ph,gi))]
        # No layout can do with fewer pages than its tiles and the cells of the small pieces need.
        cells=sum(first(gi).area for gi in small);page=grid.Wc*grid.Hc
        self.bound=min(len(start)+max(0,math.ceil((cells-sum(b.free for b in start))/page)) for start in starts)
        self.queue=[(n,0,MODES[0]) for n in range(len(starts))];self.found=[];self.firsts={};self.done=0;self.stall=0;self.rng=random.Random(7);self.ranked=False
    def best(self):return self.found[0] if self.found else None
    def planned(self):return bool(self.queue)
    def more(self):
        """Something left worth trying."""
        if self.queue:return True
        best=self.best()
        return len(self.small)>1 and best is not None and best[0][0]>self.bound and self.stall<60
    def attempt(self,n,order,mode):
        bins=yield from _fill_steps(self.starts[n],self.small,order,self.grid,self.zones,mode);self.done+=1
        if bins is None:return
        for b in bins:b.cache={};b.powers=[]           # only the pages are kept: little memory
        score=_score(bins);self.firsts[n]=min(self.firsts.get(n,score),score)
        self.found.append((score,self.done,n,order,mode,bins));self.found.sort(key=lambda v:v[:2]);del self.found[6:]
    def step(self):
        if self.queue:
            n,o,mode=self.queue.pop(0);yield from self.attempt(n,self.orders[o],mode)
            if not self.queue and not self.ranked:
                firsts=self.firsts;self.ranked=True
                top=sorted(firsts,key=lambda n:(firsts[n],n))[:2] if len(self.small)>1 else []
                self.queue=[(n,o,mode) for mode in MODES for o in range(len(self.orders)) for n in top if (o,mode)!=(0,MODES[0])]
            return
        if not self.more():return
        best=self.best();_,_,n,order,mode,_=best;order=list(order);rng=self.rng
        for _ in range(rng.randint(1,3)):a=rng.randrange(len(order));b=min(len(order)-1,a+rng.randint(1,4));order[a],order[b]=order[b],order[a]
        yield from self.attempt(n,order,mode if rng.random()<.7 else rng.choice(MODES))
        self.stall=0 if self.best() is not best else self.stall+1
    def pages(self):
        for *_,bins in self.found:
            if (yield from _check_steps(bins,self.GAP)):return _pages(bins,self.zone)
        # Never reached unless the cells were wrong: one small piece per page is always right.
        bins=[b.copy() for b in self.starts[0]]
        for gi in sorted(self.small):b=_Bin(self.grid);b.put(self.small[gi][0],0,0,gi,self.zones[gi]);bins.append(b)
        return _pages(bins,self.zone)


def _pages(bins,zone):
    return [dict(items=[e for shape,dx,dy in b.parts for e in moved(shape.entities,dx,dy)],origin=b.origin,zone=zone or ' + '.join(b.zones) or 'Pièces',col=b.spec.get('col',0),row=b.spec.get('row',0),
                 columns=b.spec.get('columns',1),rows=b.spec.get('rows',1),placements=b.placements) for b in bins]


def organized_plan(items,workspace=None,margin=MARGIN,gap=None,paper='A4',together=None,archives=None,budget=BUDGET,progress=None,tries=None,clock=time.monotonic):
    """Pages by base zone (« par type de pièce »), or every zone sharing the pages (``together``,
    0.17.0 « au plus serré »; by default when a ``gap`` is given); ``gap`` mm between the pieces
    (5 by default, 1 mm minimum). 0.18.5: packing on the real shapes within ``budget`` seconds
    (``tries``: at most that many packings per section, for repeatable tests); ``progress(f)``
    is told the share done (0…1). 0.18.7: ``clock`` measures the budget."""
    return complete(plan_steps(items,workspace,margin,gap,paper,together,archives,budget,progress,tries,clock))


def plan_steps(items,workspace=None,margin=MARGIN,gap=None,paper='A4',together=None,archives=None,budget=BUDGET,progress=None,tries=None,clock=time.monotonic):
    """0.18.7: organized_plan() a small step at a time: a generator (each step a few milliseconds)
    whose return value is the plan. Run between the events of the PDF window with a ``clock`` that
    counts only the time spent in the steps: the budget gives the same pages as a packing at once."""
    if not items:raise ValueError('Le dessin est vide.')
    paper=paper_name(paper);area=page_area(margin,paper);W,H=area[2],area[3]
    together=gap is not None if together is None else bool(together)
    GAP=globals()['GAP'] if gap is None else max(1.,float(gap))
    grouped=yield from _group_steps(items,workspace,archives);zones={}
    for group in grouped:zones.setdefault('' if together else group['zone'],[]).append(group)
    # Every section does its planned packings first (over the budget only for a very large plan:
    # the window shows the share done), then they share the time left for small changes.
    # 0.18.7: ``clock`` (time.monotonic at once; in the window, the time spent in the steps only).
    start=clock();deadline=start+budget;tick=lambda:progress and progress(min(1.,(clock()-start)/max(budget,1e-3)))
    searches=[_Search(section,zone,W,H,GAP,INSET,tick) for zone,section in zones.items()]
    for search in searches:yield from search.prepare()
    for search in searches:
        while search.planned() and (search.done<len(search.starts) or ((tries is None or search.done<tries) and clock()<start+1.5*budget)):yield from search.step();tick()
    while clock()<deadline:
        active=[s for s in searches if s.more() and (tries is None or s.done<tries)]
        if not active:break
        for search in active:yield from search.step();tick()
    pages=[]
    for search in searches:pages+=yield from search.pages()
    if progress:progress(1.)
    if not pages:raise ValueError('Aucun tracé imprimable.')
    if len(pages)>400:raise ValueError('Plus de 400 pages : trop de pièces.')
    return dict(page_specs=pages,pages=len(pages),items=[s for page in pages for s in page['items']],origin=(0.,0.),columns=1,rows=len(pages),margin=float(margin),area=area,paper=paper,size=paper_size(paper),
                together=together,gap=GAP)
