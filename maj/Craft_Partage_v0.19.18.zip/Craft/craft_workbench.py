"""Craft workbench: compact controls, fabrication tools and direct editing."""
import tkinter as tk
from tkinter import ttk,messagebox
from tkinter import font as tkfont
import math,copy,json,uuid
from pathlib import Path
from types import SimpleNamespace
from geometry import path,bounds,validate,distance
from cad import shape,polygon,guide_segments,LABELS,circle_data
from craft_tools import dimensions,style,locate,at_distance,notch_shapes,new_cran
from craft_refined import shade
from editing import join_shapes,explode_shape,extend_line,corner_lines,corner_poly,offset_vertex,drill_mark
from ui_widgets import contrast_color,zoom_tag

NEW={'join':'Joindre en polyligne','explode':'Décomposer','trim':'Couper','extend':'Rallonger','strap_round':'Bout rond','strap_point':'Bout pointu','strap_belt':'Bout de ceinture','toron':'Poignée toron','passant':'Passant','assembly':'Contrôle d’assemblage','array':'Réseau','stretch':'Étirer','break_point':'Couper au point','strap_piece':'Sangle entière','belt_holes':'Trous de ceinture','buckle_slot':'Fente d’ardillon',
     'corner':'Angle droit','chamfer':'Chanfrein','fillet':'Arrondi','offset_vertex':'Décaler sommet','drill':'Pointés et mèches','preparation':'Préparation'}
OWN=set(NEW)|{'notch','part_name','material','dimension','radius'}
SERIES={'trim','extend','notch','paint_white','paint_external','paint_internal'}
PAINT={'paint_white':'Dessin','paint_external':'Coupe extérieure','paint_internal':'Coupe intérieure'}
# Line colour list (0.16.18): coloured lines only, no names.
LINE_COLORS=('auto','#ff0000','#000080','#f28c28','#267552','#bd7ccc')
# 0.19.9: Arrondi, Chanfrein, Bout rond, Bout pointu: their value kept in the preferences (as « Piqûre : pas »).
TOOL_VALUES=('fillet_radius','angle_value','round_depth','point_length')

def enhance(Base):
    class Workbench(Base):
        def __init__(self):
            self._action=None;self.dimension_axis=None;self._tool_dialogs=[]
            self.uses_line_category=True;self.grip_drag=None;self.pending_bundle=None;self.pending_text_origin=None;self.pending_identification=None;self.trim_stroke=None;self.notch_pending=None;self.corner_first=None
            self.drill_diameter=3.;self.angle_value=3.;self.fillet_radius=1.;self.point_length=0.;self.round_depth=0.;self.radius_target=None;self._label_preview=None
            super().__init__()
            for name in TOOL_VALUES:   # 0.19.9: the values set last (they were back to 1 / 3 / 0 / 0 at each start)
                if isinstance(self.prefs.get(name),(int,float)):setattr(self,name,float(self.prefs[name]))
        def keep_tool_value(self,name,value):
            """0.19.9: a value of Arrondi, Chanfrein, Bout rond or Bout pointu set (Réglages, clic droit, « arrondi 5 »):
            used now and kept in the preferences for the next start."""
            setattr(self,name,value)
            if name in TOOL_VALUES:
                self.prefs[name]=value
                try:self.persist_preferences()
                except OSError:pass
        def build(self):
            super().build();self.canvas.bind('<Button-3>',self.canvas_context);self.canvas.bind('<B3-Motion>',lambda e:'break')
            self.canvas.bind('<ButtonRelease-2>',lambda e:setattr(self,'pan',None));self.command_entry.configure(font=('Segoe UI',10))
            __import__('ui_widgets').bind_own(self,'<Configure>',self.window_moved);self.highlight_tools()   # 0.19.3: the window's own moves only
        def window_moved(self,e):
            if e.widget is self and self.popup:self.close_palette()
        def configure_toolgroups(self):
            groups=self.toolgroups
            groups['Édition']=groups['Édition'][:2]
            groups['Géométrie']=[(icon,variants) for icon,variants in groups['Géométrie'] if icon!='select']
            for icon,vs in groups['Géométrie']:
                if icon=='circle':vs[0]=('circle_radius','Cercle (rayon)',None)
            groups['Mesures'][0][1][0]=('measure','Règle',None)
            groups['Mesures'][1][1][0]=('dimension','Cote',None)
            for i,(key,label) in enumerate([('white','Dessin'),('external','Coupe externe'),('internal','Coupe interne')]):
                groups['Traits'][i]=(key,[(key,label,lambda k=key:self.set_tool('paint_'+k))])
            groups['Modifications']=[('move',[('move_anchor','Déplacer',None)]),('rotate',[('rotate','Rotation',None)]),('scale',[('scale','Échelle',None)]),
                ('offset',[('offset_all','Décaler',None),('offset_vertex','Décaler sommet',None),('offset_part','Décaler partie de polyligne',None)]),
                ('join',[('join','Joindre en polyligne',self.join_selected)]),('explode',[('explode','Décomposer',self.explode_selected)]),
                ('trim',[('trim','Couper',None)]),('extend',[('extend','Rallonger',None)]),
                ('corner',[('corner','Angle droit',None),('chamfer','Chanfrein',None),('fillet','Arrondi',None)])]
            groups['Assemblage'].append(('drill',[('drill','Pointés et mèches',None)]))
            groups['Types de lignes']=[('__line_types__',[])]
        def rebuild_tools(self):
            super().rebuild_tools();self.highlight_tools()
            # 0.19.13: the left bar on two columns by itself when its single column is higher than the window
            if not getattr(self,'_fit_bound',False):
                self._fit_bound=True;self.bind('<Configure>',lambda e:self.schedule_fit() if e.widget is self else None,add='+')
            self.schedule_fit()
        def schedule_fit(self):
            if getattr(self,'_fit_job',None):
                try:self.after_cancel(self._fit_job)
                except tk.TclError:pass
            self._fit_job=self.after(200,self.fit_left_dock)
        def fit_left_dock(self):
            """A single column of categories on the left higher than the room: the ones that do not fit go to a
            second column (a bar arranged by hand, on two columns or more, is left as it is)."""
            self._fit_job=None
            try:
                lanes=(getattr(self,'_dock_lanes',None) or {}).get('left') or {}
                names=[n for n,(f,d) in getattr(self,'category_frames',{}).items() if d=='left']
                if len(lanes)!=1 or len(names)<2:return False
                self.update_idletasks()
                room=self.leftdock.winfo_height()
                if room<80 or lanes[0].winfo_reqheight()<=room+2:return False
                ordered=sorted(names,key=lambda n:self.layout.get(n,{}).get('order',list(self.toolgroups).index(n)))
                total,moved=0,False
                for n in ordered:
                    total+=self.category_frames[n][0].winfo_reqheight()+4
                    if total>room and n!=ordered[0]:self.layout.setdefault(n,{})['lane']=1;moved=True
                if moved:self.rebuild_tools()
                return moved
            except tk.TclError:return False
        def highlight_tools(self):
            active=self.tool.get() if hasattr(self,'tool') else 'select'
            for c,key in getattr(self,'tool_buttons',[]):
                key='move_anchor' if key=='move' else key
                if key in ('white','external','internal'):key='paint_'+key
                if key in ('prep_layer','precut_layer','recut_layer'):continue   # 0.19.0: its tile shows the layer (show_layer_button), not a tool
                try:
                    # 0.19.0: the tool in use on a rounded tile in the accent colour, inside the button
                    # (the toolbar and the plan never move).
                    __import__('modern_style').tile(c,'active' if key==active else None)
                except tk.TclError:pass
        def build_line_picker(self,parent,horizontal=True):
            super().build_line_picker(parent)
            self.line_types.setdefault('Plein',[]);self.line_types['Plein']=[];self.line_type='Plein'
            self.line_preview.configure(width=150 if horizontal else 90,height=26,cursor='arrow')
            self._line_horizontal=horizontal;self.paint_line_picker()
            self.color_preview=tk.Canvas(parent,width=68,height=26,bg=self.p['panel'],highlightthickness=0,cursor='arrow')   # 0.19.0: a rounded field
            self.color_preview.pack(side='left' if horizontal else 'top',padx=3,pady=2)
            self.color_preview.bind('<Button-1>',self.color_menu);self.paint_color_picker()
        def paint_color_picker(self):
            c=getattr(self,'color_preview',None)
            if not c or not c.winfo_exists():return
            c.delete('all');colors=[]
            def collect(s):
                if s.get('components'):
                    from curves import parts
                    for child in parts(s):collect(child)
                else:
                    color=style(s)['color'];color=self.p['ink'] if color=='auto' else color
                    if color not in colors:colors.append(color)
            ids=[i for i in self.selected_ids() if __import__('entity_rules').geometry_entity(self.items[i])]
            for i in ids:collect(self.items[i])
            if not colors:
                color=getattr(self,'drawing_color','auto');colors=[self.p['ink'] if color=='auto' else color]
            __import__('modern_style').field_back(c)
            for i,color in enumerate(colors):c.create_line(9+37*i/len(colors),13,9+37*(i+1)/len(colors),13,fill=color,width=2)
            c.create_polygon(54,11,62,11,58,15,fill=__import__('modern_style').tokens_for(self.p)['muted'],outline='')
        def color_menu(self,e):
            # 0.16.16: same list as the line format, opened under its field, colours as lines.
            from tkinter import colorchooser
            self.close_palette();w=tk.Toplevel(self);self.popup=w;w.overrideredirect(True)
            t=__import__('modern_style').tokens_for(self.p)   # 0.19.0: the list in the colours of the menus
            w.configure(bg=t['menu'],highlightthickness=1,highlightbackground=t['field_border'])
            def choose(color):self.close_palette();self.set_line_color(color)
            width=max(110,self.color_preview.winfo_width())
            for color in LINE_COLORS:
                ink=self.p['ink'] if color=='auto' else color
                c=tk.Canvas(w,width=width,height=24,bg=t['menu'],highlightthickness=0,cursor='arrow');c.pack()
                c.create_line(10,12,width-10,12,fill=ink,width=2.4)
                c.bind('<Button-1>',lambda e,value=color:choose(value))
                c.bind('<Enter>',lambda e,c=c:c.configure(bg=t['accent_soft']));c.bind('<Leave>',lambda e,c=c:c.configure(bg=t['menu']))
            def custom():
                self.close_palette();value=colorchooser.askcolor(parent=self,title='Couleur ligne')[1]
                if value:self.set_line_color(value)
            self.button(w,'Personnaliser…',custom).pack(fill='x',padx=5,pady=5)
            field=self.color_preview
            if getattr(self,'_line_horizontal',True):x,y=field.winfo_rootx(),field.winfo_rooty()+field.winfo_height()
            else:x,y=field.winfo_rootx()+field.winfo_width(),field.winfo_rooty()
            w.update_idletasks();x=max(0,min(x,self.winfo_screenwidth()-w.winfo_reqwidth()));y=max(0,min(y,self.winfo_screenheight()-w.winfo_reqheight()))
            w.geometry(f'+{x}+{y}');w.bind('<Escape>',lambda e:self.close_palette());w.focus_set()
            w.bind('<FocusOut>',lambda e:self.after_idle(lambda:self.close_palette() if self.popup is w and not str(self.focus_get()).startswith(str(w)) else None))
        def set_line_color(self,color):
            ids=[i for i in self.selected_ids() if __import__('entity_rules').geometry_entity(self.items[i])]
            if ids:
                self.snapshot()
                for i in ids:
                    __import__('entity_rules').update_style(self.items[i],color=color)
            else:self.drawing_color=color
            self.refresh();self.paint_color_picker()
        def paint_line_picker(self):
            if not getattr(self,'line_preview',None) or not self.line_preview.winfo_exists():return
            c=self.line_preview;c.delete('all');w=150 if getattr(self,'_line_horizontal',True) else 90;t=__import__('modern_style').tokens_for(self.p);ink=t['text']
            __import__('modern_style').field_back(c)   # 0.19.0: a rounded field
            c.create_line(10,13,w-26,13,fill=ink,width=1.2,dash=tuple(max(1,round(v*3)) for v in self.line_types[self.line_type]))
            c.create_polygon(w-18,11,w-10,11,w-14,15,fill=t['muted'],outline='')
        def line_menu(self,e):
            super().line_menu(e)
            self.button(self.popup,'Archives…',lambda:(self.close_palette(),self.edit_line_types())).pack(fill='x',padx=5,pady=5)
            if not self._line_horizontal:self.popup.geometry(f'+{self.line_preview.winfo_rootx()+self.line_preview.winfo_width()}+{self.line_preview.winfo_rooty()}')
        def set_line_type(self,name):
            if name not in self.line_types:return
            ids=self.selected_ids()
            if ids:
                self.snapshot()
                widths=self.prefs.get('line_type_widths',{})
                for i in ids:
                    if self.items[i].get('is_notch'):continue
                    st=style(self.items[i]);st['dash']=copy.deepcopy(self.line_types[name])
                    if name in widths:st['width']=widths[name]
                    __import__('entity_rules').update_style(self.items[i],**st)
            self.line_type=name;self.persist_preferences();self.paint_line_picker();self.refresh()
        def edit_line_types(self):
            win=self.dialog('Archives des profils de ligne');win.resizable(False,False)
            row=tk.Frame(win,bg=self.p['panel']);row.pack(padx=14,pady=12)
            box=tk.Listbox(row,height=6,width=19,exportselection=False,bg=self.field_background(),fg=self.p['ui_ink'],relief='solid',bd=1)
            box.pack(side='left',fill='y',padx=(0,14));form=tk.Frame(row,bg=self.p['panel']);form.pack(side='left')
            variables={key:tk.StringVar(value=value) for key,value in [('name',''),('width','0.25'),('dash','')]}
            for key,label in [('name','Nom'),('width','Épaisseur (mm)'),('dash','Tirets / espaces (mm)')]:
                self.label(form,label).pack(anchor='w');self.entry(form,variables[key],28).pack(fill='x',pady=(2,7))
            preview=tk.Canvas(form,width=240,height=32,bg=self.field_background(),highlightthickness=1,highlightbackground=self.field_border());preview.pack()
            widths=self.prefs.setdefault('line_type_widths',{})
            def paint(*args):
                preview.delete('all')
                try:
                    ds=[float(v.replace(',','.')) for v in variables['dash'].get().split()]
                    if len(ds)%2 or len(ds)>12 or any(not .05<=v<=100 for v in ds):return
                    preview.create_line(10,16,230,16,fill=self.p['ui_ink'],width=max(1,min(5,float(variables['width'].get().replace(',','.'))*4)),dash=tuple(max(1,round(v*3)) for v in ds))
                except (ValueError,tk.TclError):pass
            def reload(name=None):
                from ui_widgets import refill_list   # 0.18.5: the list keeps its scrolling (the chosen name stays chosen)
                names=list(self.line_types);refill_list(box,names,names.index(name) if name in names else None)
            def load(e=None):
                if not box.curselection():return
                n=box.get(box.curselection()[0]);variables['name'].set(n);variables['dash'].set(' '.join(map(str,self.line_types[n])));variables['width'].set(str(widths.get(n,.25)))
            box.bind('<<ListboxSelect>>',load)
            for var in variables.values():var.trace_add('write',paint)
            def save():
                try:
                    n=variables['name'].get().strip();w=float(variables['width'].get().replace(',','.'));d=[float(v.replace(',','.')) for v in variables['dash'].get().split()]
                    if not n or len(n)>80 or not .01<=w<=5 or len(d)%2 or len(d)>12 or any(not .05<=v<=100 for v in d):raise ValueError('Vérifiez le nom, l’épaisseur et les paires tiret / espace.')
                    if n=='Plein' and d:raise ValueError('Le profil Plein doit rester continu.')
                    self.line_types[n]=d;widths[n]=w;self.persist_preferences();reload(n);self.paint_line_picker()
                except ValueError as exc:messagebox.showerror('Profils',str(exc),parent=win)
            def remove():
                if not box.curselection():return
                n=box.get(box.curselection()[0])
                if n=='Plein':return
                self.line_types.pop(n,None);widths.pop(n,None)
                # 0.19.9: the type shown deleted: back to Plein first, then saved and painted (KeyError, kept saved as current)
                if self.line_type not in self.line_types:self.line_type='Plein' if 'Plein' in self.line_types else next(iter(self.line_types))
                self.persist_preferences();reload(None);self.paint_line_picker()   # nothing chosen after a deletion
            buttons=tk.Frame(win,bg=self.p['panel']);buttons.pack(fill='x',padx=14,pady=(0,12))
            self.button(buttons,'Nouveau',lambda:[v.set('0.25' if k=='width' else '') for k,v in variables.items()]).pack(side='left')
            self.button(buttons,'Enregistrer',save).pack(side='left',padx=5);self.button(buttons,'Supprimer',remove).pack(side='left')
            self.button(buttons,'Fermer',win.destroy).pack(side='right',padx=(15,0));reload();box.selection_set(0);load()
        def edit_archive(self,values,parent,on_save):
            win=self.dialog('Archives');self.label(win,'Nom').pack(anchor='w',padx=14,pady=(12,3))
            value=tk.StringVar();entry=self.entry(win,value,32);entry.pack(padx=14,pady=(0,8));entry.focus_set()
            area=tk.Frame(win,bg=self.p['panel']);area.pack(fill='both',padx=14)
            box=tk.Listbox(area,height=min(6,max(2,len(values))),width=32,bg=self.field_background(),fg=self.p['ui_ink'],selectbackground=self.p['accent'],selectforeground=contrast_color(self.p['accent']),exportselection=False,relief='solid',bd=1,font=('Segoe UI',10))
            scroll=ttk.Scrollbar(area,orient='vertical',command=box.yview);scroll.pack(side='right',fill='y');box.configure(yscrollcommand=scroll.set);box.pack(side='left',fill='both',expand=True)
            from materials import sorted_names
            def reload():
                from ui_widgets import refill_list   # 0.18.5: the list keeps its scrolling
                refill_list(box,sorted_names(values))
                box.configure(height=min(6,max(2,len(values))))
            reload()
            def upper(*args):
                text=value.get()
                if text!=text.upper():value.set(text.upper())
            value.trace_add('write',upper)
            def pool(archives):
                # 0.19.9: this list (a column of names or the materials) in the archives read again from the file
                if values is self.archives.get('materials'):return archives.setdefault('materials',[])
                k=next((k for k,column in enumerate(self.archives.get('names',[])) if column is values),None)
                if k is None:raise ValueError('Liste d’archives introuvable.')
                return archives['names'][k]
            def persist(change):
                # 0.19.9: only this change, made on archives.json read again and written whole (change_archives)
                if not self.change_archives(lambda archives:change(pool(archives)),win):return False
                on_save(values);return True
            def save(e=None):
                text=value.get().strip().upper()
                if not text or len(text)>200:return 'break'
                if persist(lambda names:None if text in names else names.append(text)):value.set('');reload()
                entry.focus_set();return 'break'
            def remove():
                if not box.curselection():return
                name=box.get(box.curselection()[0])
                if persist(lambda names:names.remove(name) if name in names else None):reload()
            def close():win.destroy();parent.grab_set()
            buttons=tk.Frame(win,bg=self.p['panel']);buttons.pack(fill='x',padx=14,pady=10)
            self.button(buttons,'Ajouter',save).pack(side='left');self.button(buttons,'Supprimer',remove).pack(side='left',padx=6);self.button(buttons,'Fermer',close).pack(side='right')
            entry.bind('<Return>',save);win.protocol('WM_DELETE_WINDOW',close)
            __import__('materials').bind_letter_jump(box)
        def edit_material_archive(self,parent,on_save,kinds=()):
            """0.17.0: the materials archive by type, with épaisseur (/10e), prix au m² and taux de
            chute (15 % by default); a line chosen in the list is edited (renamed included)."""
            import materials as mat
            win=self.dialog('Archives · Matières');panel=self.p['panel'];current=[None]
            grid=tk.Frame(win,bg=panel);grid.pack(fill='x',padx=14,pady=(12,4))
            name=tk.StringVar();kind=tk.StringVar(value=next(iter(kinds)) if len(kinds)==1 else 'Cuir');thick=tk.StringVar();price=tk.StringVar();waste=tk.StringVar(value=mat.fmt(mat.WASTE));color=tk.StringVar()
            self.label(grid,'Nom').grid(row=0,column=0,sticky='w');entry=self.entry(grid,name,28);entry.grid(row=0,column=1,columnspan=3,sticky='we',padx=6,pady=2)
            self.label(grid,'Type').grid(row=1,column=0,sticky='w');ttk.Combobox(grid,textvariable=kind,values=list(mat.TYPES),state='readonly',width=12).grid(row=1,column=1,sticky='w',padx=6,pady=2)
            self.label(grid,'Épaisseur (/10e)').grid(row=2,column=0,sticky='w');self.entry(grid,thick,6).grid(row=2,column=1,sticky='w',padx=6,pady=2)
            self.label(grid,'Prix au m² (€)').grid(row=3,column=0,sticky='w');self.entry(grid,price,8).grid(row=3,column=1,sticky='w',padx=6,pady=2)
            self.label(grid,'Chute (%)').grid(row=4,column=0,sticky='w');self.entry(grid,waste,6).grid(row=4,column=1,sticky='w',padx=6,pady=2)
            # 0.18.1: couleur / référence, shown on the fiches (« 2024 », « BLANCHE »…).
            self.label(grid,'Couleur / réf.').grid(row=5,column=0,sticky='w');self.entry(grid,color,20).grid(row=5,column=1,columnspan=3,sticky='w',padx=6,pady=2)
            # 0.19.13: « cachée » as in Mozart: left out of the Matière list unless « Cachées » is ticked there
            hidden=tk.BooleanVar(value=False)
            __import__('modern_style').make_check(grid,text='Cachée (montrée seulement avec « Cachées »)',variable=hidden,bg=panel,fg=self.p['ui_ink'],selectcolor=self.field_background(),activebackground=panel,font=('Segoe UI',10)).grid(row=6,column=0,columnspan=4,sticky='w',pady=2)
            self.label(grid,'Épaisseur, prix et couleur facultatifs.').grid(row=7,column=0,columnspan=4,sticky='w',pady=(2,0))
            area=tk.Frame(win,bg=panel);area.pack(fill='both',expand=True,padx=14,pady=6)
            box=tk.Listbox(area,height=10,width=58,bg=self.field_background(),fg=self.p['ui_ink'],selectbackground=self.p['accent'],selectforeground=contrast_color(self.p['accent']),exportselection=False,relief='solid',bd=1,font=('Segoe UI',10))
            scroll=ttk.Scrollbar(area,orient='vertical',command=box.yview);scroll.pack(side='right',fill='y');box.configure(yscrollcommand=scroll.set);box.pack(side='left',fill='both',expand=True)
            order=[]
            def reload(select=None):
                from ui_widgets import refill_list   # 0.18.5: the list keeps its scrolling
                order[:]=mat.sorted_names(self.archives.get('materials',[]))
                refill_list(box,[f'{n}   ({mat.describe(self.archives,n)})' for n in order],order.index(select) if select in order else None)
            def upper(*args):
                text=name.get()
                if text!=text.upper():name.set(text.upper())
            name.trace_add('write',upper)
            def load(e=None):
                if not box.curselection():return
                n=order[box.curselection()[0]];d=mat.info(self.archives,n);current[0]=n
                name.set(n);kind.set(d['type']);thick.set(mat.fmt(d['thickness']));price.set(mat.fmt(d['price']));waste.set(mat.fmt(d['waste']));color.set(d['color']);hidden.set(d['hidden'])
            def fresh():
                current[0]=None;box.selection_clear(0,'end');name.set('');thick.set('');price.set('');waste.set(mat.fmt(mat.WASTE));color.set('');hidden.set(False);entry.focus_set()
            def persist(change):
                # 0.19.9: only this change, made on archives.json read again and written whole (change_archives)
                if not self.change_archives(change,win):return False
                on_save(None);return True
            def save(e=None):
                try:
                    text=name.get().strip().upper()
                    if not text or len(text)>200:raise ValueError('Nom : 1 à 200 caractères.')
                    w=mat.number(waste.get(),0,100,'Chute')
                    values=(text,kind.get(),mat.number(thick.get(),.1,99,'Épaisseur'),mat.number(price.get(),0,100000,'Prix au m²'),mat.WASTE if w is None else w,current[0],color.get(),hidden.get())
                    if not persist(lambda archives:mat.store(archives,*values)):return 'break'
                except ValueError as exc:messagebox.showerror('Archives',str(exc),parent=win);return 'break'
                reload(text);current[0]=text;return 'break'
            def remove():
                if not box.curselection():return
                gone=order[box.curselection()[0]]
                if persist(lambda archives:mat.remove(archives,gone)):reload();fresh()
            def close():win.destroy();parent.grab_set()
            box.bind('<<ListboxSelect>>',load);mat.bind_letter_jump(box)
            buttons=tk.Frame(win,bg=panel);buttons.pack(fill='x',padx=14,pady=(4,12))
            self.button(buttons,'Nouveau',fresh).pack(side='left');self.button(buttons,'Enregistrer',save).pack(side='left',padx=6);self.button(buttons,'Supprimer',remove).pack(side='left')
            self.button(buttons,'Fermer',close).pack(side='right')
            entry.bind('<Return>',save);win.protocol('WM_DELETE_WINDOW',close);reload();entry.focus_set()
            return win
        def draw_input_bubble(self):
            if not hasattr(self,'command_entry'):return
            text=self.command_value.get().strip()
            if not text or self.start is None or self.tool.get() in OWN or self.tool.get() in ('select','delete'):
                self.command_entry.place_forget();return
            x,y=self.cursor_screen;w=max(44,min(120,14+len(text)*7));h=20
            self.command_entry.place(x=max(2,min(self.canvas.winfo_width()-w-2,x+15)),y=max(2,min(self.canvas.winfo_height()-h-2,y+15)),width=w,height=h)
        def key_input(self,e):
            if not e.state&4 and self.focus_get() is self.canvas and e.char and e.char in '0123456789.,;-+xX*' and self.tool.get() not in OWN|{'select','delete'}:
                self.command_entry.insert('end',e.char);self.draw_input_bubble();self.command_entry.focus_set();return 'break'
            return super().key_input(e)
        def draw_guides(self):
            w=self.workspace
            if not w or not w.get('visible',True):return
            # 0.16.25: the columns stop at the base height (open at the bottom, 0.16.26).
            # 0.16.26: same thickness as the drawing lines, at every zoom.
            width=self.line_px() if hasattr(self,'line_px') else 1.8
            framed=self.column_bottom(w) if hasattr(self,'column_bottom') else None  # 0.16.27: down to the screen bottom when framed
            for a,b in guide_segments(w):
                if framed and abs(a[0]-b[0])<1e-9 and framed>b[1]:b=(b[0],framed)
                self.canvas.create_line(*self.to_screen(a),*self.to_screen(b),fill=self.p['guides'],width=width,tags='guides')
            # One common size; fit the longest composed heading and every column. 0.19.13: the base's own names.
            from cad import column_labels,title_suffix,rows_of
            sizes=[];labels=column_labels(w);suffix=title_suffix(w)
            for i,(label,width) in enumerate(zip(labels,w['widths'])):
                text=label+(' '+suffix if i==1 and suffix else '')
                sizes.append((width*self.scale*.85)/max(1,len(text)*.68))
            px=max(1,min(round(min(sizes)*1.35),round(w['header']*self.scale*.40)))
            world=min(min(sizes)*1.35,w['header']*self.scale*.40)/max(1e-12,self.scale)   # 0.18.3: the same size at every zoom, in mm
            bold=tkfont.Font(family='Segoe UI',size=-px,weight='bold');normal=tkfont.Font(family='Segoe UI',size=-px)
            # 0.18.3: the texts get plain font descriptions (the named fonts above only measure): the
            # wheel zoom resizes them at each notch like the other texts of the plan.
            bold_font,normal_font=('Segoe UI',-px,'bold'),('Segoe UI',-px)
            x=w.get('origin_x',0)
            for i,width in enumerate(w['widths']):
                cx,cy=self.to_screen((x+width/2,w['header']*.54));label=labels[i]
                if not label.strip():x+=width;continue
                if i==1 and suffix:
                    left=bold.measure(label+' ');right=normal.measure(suffix);start=cx-(left+right)/2
                    self.canvas.create_text(start,cy,text=label+' ',anchor='w',font=bold_font,fill=self.p['guides'],tags=zoom_tag('guides','t',world))
                    self.canvas.create_text(start+left,cy,text=suffix,anchor='w',font=normal_font,fill=self.p['guides'],tags=zoom_tag('guides','t',world))
                else:self.canvas.create_text(cx,cy,text=label,font=bold_font,fill=self.p['guides'],tags=zoom_tag('guides','t',world))
                x+=width
            # 0.19.13: the names of the rows (rangées), at the left under their rule
            small=max(1,round(px*.7));left=w.get('origin_x',0)+min(w['widths'][0]*.03,30.)
            for name,top,_ in rows_of(w):
                if not name.strip():continue
                sx,sy=self.to_screen((left,top+world*.35))
                self.canvas.create_text(sx,sy,text=name,anchor='nw',font=('Segoe UI',-small,'bold'),fill=self.p['guides'],tags=zoom_tag('guides','t',world*.7))
        def set_tool(self,t):
            if t in ('line','poly','rect','rect_center','rect_round','rect_rot','para','circle_radius','circle_diameter','circle_2p','circle_3p'):
                self.line_type='Plein';self.paint_line_picker()
            if t in PAINT:
                self.cancel();self.tool.set(t);self.last_command=('tool',t);self.canvas.focus_set();self.begin_action(t)
                ids=self.selected_ids()
                # 0.17.0: one selection per call (no more series): the selection is painted and the
                # tool ends; Espace recalls it for the next selection.
                if ids:return self.paint_done(ids)
                self.highlight_tools();self.status.set('Sélectionner ligne');return
            if t not in OWN:
                super().set_tool(t)
                if t in SERIES:self.begin_action(t)
                self.highlight_tools();return
            self.cancel();self.tool.set(t);self.last_command=('tool',t);self.canvas.focus_set();self.highlight_tools()
            self.status.set({'notch':'Choisir un point d’ancrage pour le cran.','dimension':'Choisir le premier point de cote.','radius':'Choisir l’arc à coter.'}.get(t,NEW.get(t,t)+' : sélectionner un tracé.'))
            if t in ('part_name','material'):self.pending_piece=None;self.status.set('Sélectionner pièce')
            elif t=='drill':self.drill_dialog()
            if t in SERIES:self.begin_action(t)
        def begin_action(self,t):
            self._action=dict(tool=t,state=self.state(),undo=list(self.undo_stack),redo=list(self.redo_stack))
            self.series_hint()
        def series_hint(self):
            t=self.tool.get()
            text={'trim':'Sélectionner la portion à supprimer.','extend':'Sélectionner le tracé à rallonger.','notch':'Placer les crans.'}.get(t,'Sélectionner les tracés.')
            if t=='notch':
                if getattr(self,'notch_host',None) is None:text='Sélectionner le contour support.'
                elif self.notch_pending:text='Choisir intérieur ou extérieur.'
            self.status.set(text);self.hint.set(text)
        def finish_action(self):
            action=self._action;self._action=None
            if action:
                changed=self.state()!=action['state'];self.undo_stack=action['undo'];self.redo_stack=[] if changed else action['redo']
                if changed:self.undo_stack=(self.undo_stack+[action['state']])[-100:]
                if changed:self.selected=None;self.selected_set=set()   # 0.18.0: nothing stays selected after an action
            self.cancel();self.refresh();return 'break'
        def enter_dimension(self,e=None):
            if self.tool.get() in ('part_name','material') and self.pending_bundle and not self.command_value.get().strip():
                # Entrée validates the label like the second click; it never drops it.
                if self.pending_text_origin is None:self.status.set('Placer le premier point du texte, puis choisir son orientation.');return 'break'
                try:self.place_pending_text(self.pointer_world or self.pending_text_origin)
                except ValueError as exc:
                    x,y=self.cursor_screen;self.invalid_at(SimpleNamespace(x=x,y=y),str(exc))
                return 'break'
            if self._action and not self.command_value.get().strip():return self.finish_action()
            return super().enter_dimension(e)
        def stash_doc(self):
            if self._action:self.cancel()
            return super().stash_doc()
        def save_doc(self):
            if self._action:self.finish_action()
            return super().save_doc()
        def undo(self):
            if self._action:self.cancel();return
            return super().undo()
        def paint_done(self,ids):
            label={'paint_white':'Dessin','paint_external':'Coupe externe','paint_internal':'Coupe interne'}[self.tool.get()]
            self.paint_items(ids);self.selected=None;self.selected_set=set();self.finish_action();self.highlight_tools()
            self.status.set(label+' : '+str(len(ids))+(' tracé.' if len(ids)==1 else ' tracés.'))
        def paint_items(self,ids):
            profile=PAINT[self.tool.get()];self.snapshot()
            for i in ids:
                if self.items[i].get('is_notch'):continue
                st=style(self.items[i]);st.update(color=self.profiles[profile]['color'],role=self.profiles[profile]['role'])
                __import__('entity_rules').update_style(self.items[i],color=st['color'],role=st['role']);self.items[i]['profile']=profile
            self.series_hint()
        def commit_current(self,p):
            self.active_profile='Dessin';self.profiles['Dessin']['dash']=[]
            return super().commit_current(p)
        def finish_poly(self,closed):
            self.active_profile='Dessin';self.profiles['Dessin']['dash']=[]
            return super().finish_poly(closed)
        def complete_command(self,name,action=False):
            self.extra_points=[];self.notch_pending=None;self.corner_first=None;self.radius_target=None;self.pending_bundle=None;self.pending_text_origin=None;self.pending_identification=None;self.pending_piece=None;self.grip_drag=None
            if self._action and self._action['tool']==name:
                self.start=None;self.pending=[];self.stage_points=[];self.numeric_width=None;self.mouse_started=False;self.snap_marker=None;self.command_value.set('');self.extra_item=None
                self.selected=None;self.selected_set=set();self.canvas.delete('preview');self.canvas.delete('trim_path');self.series_hint()
            else:super().complete_command(name,action)
            self.dimension_axis=None;self.highlight_tools();self.draw_input_bubble()
        def repeat_last(self,e=None):
            if self.last_command and self.last_command[1] in ('join','explode'):
                {'join':self.join_selected,'explode':self.explode_selected}[self.last_command[1]]();return 'break'
            return super().repeat_last(e)
        def cancel(self):
            action=self._action;self._action=None
            if action:
                self.items=copy.deepcopy(action['state']['items']);self.workspace=copy.deepcopy(action['state']['workspace'])
                self.undo_stack=action['undo'];self.redo_stack=action['redo'];self.selected=None;self.selected_set=set()
            self.dimension_axis=None
            for win in self._tool_dialogs:
                try:win.destroy()
                except tk.TclError:pass
            self._tool_dialogs=[]
            if self.grip_drag and self.grip_drag.get('changed'):
                self.items[self.grip_drag['index']]=self.grip_drag['original']
                for i,original in self.grip_drag.get('linked',{}).items():self.items[i]=original
                if self.undo_stack:self.undo_stack.pop()
                self.redo_stack=self.grip_drag.get('redo',[])
            self.grip_drag=None;self.pending_bundle=None;self.pending_text_origin=None;self.pending_identification=None;self.pending_piece=None;self.notch_pending=None;self.corner_first=None;self.trim_stroke=None;self.radius_target=None
            result=super().cancel();self.highlight_tools();return result
        def dialog(self,title):
            win=super().dialog(title)
            if self.tool.get()!='select':
                self._tool_dialogs=[w for w in self._tool_dialogs if w.winfo_exists()]
                self._tool_dialogs.append(win)
                win.bind('<Escape>',lambda e:self.escape())
            return win
        def canvas_context(self,e):
            self.close_palette();m=self.menu()
            history=self.history_state() if hasattr(self,'history_state') else (True,True)   # 0.19.8: greyed when there is nothing to undo / redo
            for label,fn,on in [('Répéter la dernière commande',self.repeat_last,True),('Terminer / annuler',self.cancel,True),('Annuler',self.undo,history[0]),('Rétablir',self.redo,history[1])]:m.add_command(label=label,command=fn,state='normal' if on else 'disabled')
            if self.selected_set:
                m.add_separator()
                for label,fn in [('Déplacer',lambda:self.set_tool('move_anchor')),('Dupliquer',self.duplicate),('Supprimer',self.delete),('Joindre en polyligne',self.join_selected),('Décomposer',self.explode_selected)]:m.add_command(label=label,command=fn)
            if any(self.items[i].get('spline') for i in self.selected_set if i<len(self.items)):
                m.add_command(label='Lisser la spline',command=self.smooth_selected)   # 0.19.13
            m.add_separator()
            for label,fn in [('Cadrer le dessin',self.fit),('Cadrer la base',self.fit_workspace),('Options d’affichage…',self.preferences_dialog),('Aide',self.help)]:m.add_command(label=label,command=fn)
            try:m.tk_popup(e.x_root,e.y_root)
            finally:m.grab_release()
            return 'break'
        def selected_ids(self):return sorted(self.selected_set or ({self.selected} if self.selected is not None else set()))
        def smooth_selected(self):
            """0.19.13 « Lisser »: the splines selected made again through their points with the smooth curve of 0.19.7
            (one Annuler)."""
            import edit_tools
            ids=[i for i in self.selected_ids() if self.items[i].get('spline')]
            if not ids:self.status.set('Sélectionner une spline.');return
            try:new={i:edit_tools.smoothed(self.items[i]) for i in ids}
            except (ValueError,ZeroDivisionError) as exc:self.status.set('Lisser : '+str(exc));return
            self.snapshot()
            for i,q in new.items():self.items[i]=q
            self.refresh();self.status.set(f'Spline lissée ({len(ids)}).' if len(ids)>1 else 'Spline lissée.')
        def replace_items(self,indices,new,command):
            from editing import tidy_arcs
            new=[tidy_arcs(s) for s in new]   # 0.18.0: no « mini-arc » left at a quadrant
            validate(new);self.snapshot();ids=set(indices);self.items=[s for i,s in enumerate(self.items) if i not in ids];start=len(self.items);self.items.extend(new)
            self.selected_set=set(range(start,len(self.items)));self.selected=start if new else None
            self.complete_command(command);self.refresh()   # 0.18.0: nothing stays selected
        def join_selected(self):
            ids=self.selected_ids()
            if len(ids)<2:self.cancel();self.status.set('Sélectionner plusieurs lignes avec un rectangle, puis Joindre.');return
            try:self.replace_items(ids,[join_shapes([self.items[i] for i in ids])],'join')
            except ValueError as exc:self.status.set(str(exc))
        def explode_selected(self):
            ids=[i for i in self.selected_ids() if __import__('entity_rules').geometry_entity(self.items[i])]
            if not ids:self.selected=None;self.selected_set=set();self.set_tool('explode');return
            try:self.replace_items(ids,[part for i in ids for part in explode_shape(self.items[i])],'explode')
            except ValueError as exc:self.status.set(str(exc))
        def invalid_at(self,e,text):
            self.status.set(text);self.canvas.delete('invalid');x,y=e.x,e.y
            for sign in (-1,1):self.canvas.create_line(x-4,y-sign*4,x+4,y+sign*4,fill='#ee6666',width=1.3,tags='invalid')
            self.after(650,lambda:self.canvas.delete('invalid'))
        def down(self,e):
            t=self.tool.get();self.cursor_screen=(e.x,e.y);self.canvas.focus_set()
            if t in PAINT:
                i=self.pick(self.raw(e))
                if i is not None:self.paint_done([i])
                return
            if t=='trim':
                self.trim_stroke=dict(points=[self.raw(e)]);return
            if t=='select':
                if self.grip_drag and self.grip_drag.get('latched'):
                    self.move_grip(e);changed=self.grip_drag['changed'];moved=[self.grip_drag['index']]+list(self.grip_drag.get('linked',{}));self.grip_drag=None
                    if changed:
                        self.last_command=('tool','select')
                        if hasattr(self,'attach_moved_zones'):self.attach_moved_zones(moved)   # 0.18.1: a loose zone placed on a piece
                    self.refresh();return
                if getattr(e,'state',0)&1:
                    # 0.18.0, like AutoCAD: Maj+clic removes the object from the selection (even on
                    # a grip); Maj on an empty place starts a rectangle that removes.
                    i=self.pick(self.raw(e))
                    if i is not None:
                        self.selected_set.discard(i);self.selected=min(self.selected_set) if self.selected_set else None;self.refresh()
                        self.box_start=None;return
                    return super().down(e)
                grip=self.hit_grip(self.raw(e))
                if grip is None and self.grips_shown():   # 0.19.0: no line end taken either beyond GRIP_LIMIT objects selected
                    candidate=self.pick(self.raw(e))
                    if candidate is not None and self.items[candidate]['kind']=='line' and not self.items[candidate].get('dimension_group'):
                        a,b=path(self.items[candidate])[0]
                        for anchor,fixed in ((a,b),(b,a)):
                            if math.dist(anchor,self.raw(e))<=7/self.scale:
                                self.selected=candidate;self.selected_set={candidate};grip=(candidate,'endpoint',anchor,fixed);break
                if grip:
                    i,mode,anchor,fixed=grip;self.grip_drag=dict(index=i,mode=mode,anchor=anchor,fixed=fixed,original=copy.deepcopy(self.items[i]),changed=False,redo=list(self.redo_stack),linked={j:copy.deepcopy(self.items[j]) for j in __import__('entity_rules').linked_selection(self.items,[i]) if j!=i});self.box_start=None;return
            if t not in OWN:return super().down(e)
            p=self.raw(e) if t=='extend' else self.point(e)
            try:
                if t in ('part_name','material'):
                    if getattr(self,'pending_piece',None) is None:
                        from entity_rules import closed_piece
                        i=self.pick(p)
                        if i is None or not closed_piece(self.items[i]):raise ValueError('Sélectionner pièce fermée en polyligne')
                        self.pending_piece=i;self.selected=i;self.selected_set={i};self.refresh();self.identify_dialog(t);return
                    if self.pending_bundle:
                        if self.pending_text_origin is None:
                            from precision_geometry import inside
                            if not inside(self.items[self.pending_piece],p):raise ValueError('Placer texte dans pièce')
                            self.pending_text_origin=p;self.status.set('Point placé : orienter le texte avec la souris, puis cliquer · Ortho disponible.');return
                        if math.dist(self.pending_text_origin,p)<1e-6:raise ValueError('Choisissez un second point pour orienter le texte.')
                        self.place_pending_text(p)
                    return
                if t=='drill':self.add_items([drill_mark(p,self.drill_diameter)],t);return
                if t=='notch':
                    if self.notch_pending is None:
                        i=self.pick(p)
                        if i is None:raise ValueError('Choisissez un point sur le contour.')
                        self.notch_pending=(i,locate(self.items[i],p)[0]);self.status.set('Choisir l’orientation du cran : diriger la souris, puis cliquer.');return
                    i,d=self.notch_pending;point,n=at_distance(self.items[i],d);side=1 if (p[0]-point[0])*n[0]+(p[1]-point[1])*n[1]>=0 else -1
                    self.snapshot();self.items[i].setdefault('notches',[]).append(new_cran(d,side));self.complete_command('notch');self.refresh();return
                if t=='dimension':
                    if len(self.extra_points)<2:
                        self.extra_points.append(p);self.status.set('Choisir le deuxième point.' if len(self.extra_points)==1 else 'Placer la cote.')
                    else:
                        a,b,c=self.dimension_points(p);self.add_items(self.dimension_entities(a,b,c),'dimension')
                    return
                if t=='radius':return self.radius_click(p)
                if t=='offset_vertex' and self.extra_points:
                    origin=self.extra_points[0];q=offset_vertex(self.items[self.extra_item],origin,(p[0]-origin[0],p[1]-origin[1]));self.replace_items([self.extra_item],[q],t);return
                i=self.pick(p)
                if i is None:raise ValueError('Cliquez sur un tracé.')
                if t=='join':self.cancel();self.status.set('Sélectionnez les tracés avec un rectangle, puis Joindre.');return
                if t=='explode':self.replace_items([i],explode_shape(self.items[i]),'explode');return
                if t=='extend':
                    new=extend_line(self.items[i],[s for j,s in enumerate(self.items) if j!=i],p,15/self.scale)   # 0.18.0: up to a side stopping just short
                    if new is None:self.invalid_at(e,'Aucune intersection pour rallonger cette ligne.')
                    else:self.replace_items([i],[new],'extend')
                    return
                if t=='offset_vertex':
                    if not self.extra_points:self.extra_points=[p];self.extra_item=i;self.status.set('Choisir la nouvelle position du sommet.');return
                    origin=self.extra_points[0];q=offset_vertex(self.items[self.extra_item],origin,(p[0]-origin[0],p[1]-origin[1]));self.replace_items([self.extra_item],[q],t);return
                if t in ('corner','chamfer','fillet'):
                    if self.corner_first is None:self.corner_first=(i,p);self.status.set('Choisir le deuxième côté.');return
                    j,q=self.corner_first;value=0
                    if t!='corner':value=self.fillet_radius if t=='fillet' else self.angle_value
                    new=corner_poly(self.items[i],q,p,t,value) if i==j else corner_lines(self.items[j],self.items[i],q,p,t,value)
                    self.replace_items({i,j},[new],t);return
            except (ValueError,IndexError) as exc:self.invalid_at(e,str(exc))
        def up(self,e):
            if self.grip_drag:
                # 0.16.20: no hold-and-drag. Click a grip, the point follows the mouse, a second click places it.
                if not self.grip_drag.get('latched'):
                    self.grip_drag['latched']=True
                    if not self.grip_drag.get('lengthen'):self.status.set('Placer le point.')   # 0.19.9: Allonger keeps its instruction
                return
            if self.trim_stroke is not None:
                points=self.trim_stroke['points'];self.trim_stroke=None;self.canvas.delete('trim_path')
                points.append(self.raw(e));self.apply_trim_stroke(points,e)
                return
            # Drawing is click-to-click. Releasing after tiny hand movement is never a second point.
            self.mouse_started=False
            if self.tool.get() in PAINT:return
            if self.tool.get() in OWN:return
            return super().up(e)
        def trim_replacements(self,points):
            from cad import intersections
            from curves import trim,trim_stops
            from precision_geometry import contour_location,primitives
            original=list(self.items);hits={};moved=sum(math.dist(a,b) for a,b in zip(points,points[1:]))*self.scale>=4
            if not moved:
                i=self.pick(points[0])
                if i is not None:hits[i]=[contour_location(original[i],points[0])[1]]
            else:
                for a,b in zip(points,points[1:]):
                    if math.dist(a,b)<1e-8:continue
                    sweep=shape('line','Passage',*a,b[0]-a[0],b[1]-a[1])
                    for i,s in enumerate(original):
                        if not __import__('entity_rules').geometry_entity(s):continue
                        found=intersections(sweep,s)
                        if found:hits.setdefault(i,[]).extend(found)
            replacements={}
            for i,locations in hits.items():
                others=[q for k,q in enumerate(original) if k!=i and __import__('entity_rules').geometry_entity(q)];fragments=[original[i]]
                # A fence through an isolated smooth loop supplies its own two boundaries.
                # 0.18.5 (n° 32): only when Couper finds no stop on it (one piece, no crossing, no
                # raccord touching it); a polyline of several pieces is cut piece by piece.
                smooth=original[i].get('ellipse') or original[i].get('spline') or original[i]['kind']=='circle' or (any(original[i].get('bulges',[])) and all(q['sweep'] for q in primitives(original[i])))
                if moved and smooth and not trim_stops(original[i],others):
                    fragments=trim(original[i],others,locations[0],fence=locations)
                else:
                    for p in locations:
                        for j,s in enumerate(fragments):
                            if math.dist(contour_location(s,p)[1],p)>.012:continue
                            try:new=trim(s,others,p,vertices=True)
                            except ValueError:continue
                            if new is not None:fragments[j:j+1]=new
                            break
                if fragments!=[original[i]]:replacements[i]=fragments
            return replacements
        def apply_trim_stroke(self,points,e):
            original=list(self.items);replacements=self.trim_replacements(points)
            if replacements:
                from editing import tidy_arcs
                replacements={i:[tidy_arcs(q) for q in new] for i,new in replacements.items()}   # 0.18.0: no mini-arc
                self.snapshot();self.items=[q for i,s in enumerate(original) for q in replacements.get(i,[s])]
                self.complete_command('trim');self.refresh()
            else:self.series_hint()
        def motion(self,e):
            self.cursor_screen=(e.x,e.y);self._inside_plan=True;t=self.tool.get()
            if self.grip_drag:
                self.move_grip(e);return
            if self.trim_stroke is not None:
                st=self.trim_stroke;st['points'].append(self.raw(e))
                self.canvas.delete('trim_path');self.canvas.create_line(*[v for q in st['points'] for v in self.to_screen(q)],fill=self.p['accent'],tags='trim_path',**self.guide_style());self.draw_crosshair();return
            if t in OWN:
                p=self.point(e);self.pointer_world=p;self.canvas.delete('preview');self.canvas.delete('snap')
                if t in ('part_name','material') and self.pending_bundle:
                    a=self.pending_text_origin;angle=math.degrees(math.atan2(p[1]-a[1],p[0]-a[0])) if a else 0
                    s=self.bundle_at(a or p,self.pending_bundle,angle);self.draw_shape(s,self.p['ink'],1,('preview',))
                    # 0.16.28: no red warning; only the first point must be in the piece.
                elif t=='drill':self.draw_shape(drill_mark(p,self.drill_diameter),self.p['ink'],1,('preview',))
                elif t=='notch':
                    if self.notch_pending:
                        i,d=self.notch_pending;pt,n=at_distance(self.items[i],d);side=1 if (p[0]-pt[0])*n[0]+(p[1]-pt[1])*n[1]>=0 else -1
                        host=copy.deepcopy(self.items[i]);host['notches']=[new_cran(d,side)]
                        for s in notch_shapes(host):self.draw_shape(s,self.p['accent'],1,('preview',))
                    elif self.snap_marker:self.draw_snap_point(*self.snap_marker)
                elif t=='dimension' and self.extra_points:
                    try:
                        a,b,c=self.dimension_points(p)
                        for s in self.dimension_entities(a,b,c):self.draw_shape(s,self.p['ink'],1,('preview',))
                    except ValueError:pass
                elif t=='radius' and self.radius_target:
                    for s in self.radius_entities(p):self.draw_shape(s,self.p['ink'],1,('preview',))
                elif t=='offset_vertex' and self.extra_points:
                    a=self.extra_points[0]
                    try:self.draw_shape(offset_vertex(self.items[self.extra_item],a,(p[0]-a[0],p[1]-a[1])),self.p['accent'],1,('preview',))
                    except ValueError:pass
                if self.snap_marker:self.draw_snap_point(*self.snap_marker)
                self.draw_crosshair();return
            if t=='measure':
                p=self.point(e);self.pointer_world=p;self.canvas.delete('preview')
                if self.extra_points:self.draw_ruler(self.extra_points[0],p)
                self.draw_crosshair();return
            if t in PAINT:self.draw_crosshair();return
            super().motion(e)
            if self._action:self.series_hint()
        def dimension_points(self,p):
            a=self.extra_points[0];b=self.extra_points[1] if len(self.extra_points)>1 else p
            return a,b,p
        def dimension_entities(self,a,b,p):
            return dimensions(a,b,p,self.cote_value(math.dist(a,b)))
        def measure_points(self,a,b):
            return __import__('craft_tools').measure_points(a,b,self.ortho.get())
        def draw_ruler(self,a,b):
            original=b;a,b=self.measure_points(a,b)
            A,B=self.to_screen(a),self.to_screen(b);length=math.dist(a,b)
            if length<1e-8:return
            self.canvas.create_line(*A,*B,fill=self.p['ink'],width=1.4,tags='preview')
            if math.dist(original,b)>1e-6:self.canvas.create_line(*self.to_screen(original),*B,fill='#8d9298',tags='preview',**self.guide_style())
            for origin,toward in ((a,b),(b,a)):self.draw_shape(self.arrow(origin,toward,min(2.2,length*.2)),self.p['ink'],1,('preview',))
            self.measure_label(a,b,self.cote_value(length))
        def hit_grip(self,p):
            for i in self.selected_ids():
                s=self.items[i];pts,closed=path(s)
                if s['kind']=='line':
                    a,b=pts;mid=((a[0]+b[0])/2,(a[1]+b[1])/2)
                    for pt,mode,fixed in [(mid,'move',mid),(a,'endpoint',b),(b,'endpoint',a)]:
                        if math.dist(pt,p)<=7/self.scale:return i,mode,pt,fixed
                else:
                    x,y,X,Y=bounds([s]);mid=((x+X)/2,(y+Y)/2)
                    if not __import__('native_edit').circular_edges(s) and math.dist(mid,p)<=7/self.scale:return i,'move',mid,mid
                    if s['kind']=='poly' and not s.get('annotation') and not any(s.get('bulges',[])) and not s.get('notches'):
                        for j,pt in enumerate(pts):
                            if math.dist(pt,p)<=7/self.scale:return i,('vertex',j),pt,pt
            return None
        def move_grip(self,e):
            g=self.grip_drag;p=self.point(e);s=copy.deepcopy(g['original']);mode=g['mode']
            if not g['changed']:
                if math.dist(p,g['anchor'])<.1/self.scale:return
                self.snapshot();g['changed']=True
            if mode=='endpoint':
                fixed=g['fixed']
                if math.dist(p,fixed)<.001:return
                start=(s['x'],s['y']);moving_start=math.dist(start,g['anchor'])<1e-6
                A,B=(p,fixed) if moving_start else (fixed,p)
                if s.get('notches'):
                    old_length=math.hypot(s['w'],s['h']);new_length=math.dist(A,B);delta=new_length-old_length if moving_start else 0
                    marks=[dict(copy.deepcopy(m),distance=m['distance']+delta) for m in s['notches']]
                    if any(m['distance']<0 or m['distance']>new_length for m in marks):self.invalid_at(e,'La ligne devient trop courte pour ses crans.');return
                    s['notches']=marks
                s.update(x=A[0],y=A[1],w=B[0]-A[0],h=B[1]-A[1])
            elif isinstance(mode,tuple):
                j=mode[1];pts,_=path(s);pts[j]=p;new=polygon(pts,s['name'],s.get('closed'));new.update({k:v for k,v in s.items() if k not in ('kind','x','y','w','h','r','points','closed')});s=new
            else:
                dx,dy=p[0]-g['anchor'][0],p[1]-g['anchor'][1];s['x']+=dx;s['y']+=dy
                for i,original in g.get('linked',{}).items():
                    self.items[i]=copy.deepcopy(original);self.items[i]['x']+=dx;self.items[i]['y']+=dy
            self.items[g['index']]=s
            # 0.19.9: the whole refresh (title, tabs, list…) at the first change only, then the plan drawn again (redraw()
            # draws the cross, the grip guide and its length too); the drag's end (placed, Échap, Ctrl+Z) refreshes.
            if g.get('refreshed'):self.redraw()
            else:g['refreshed']=True;self.refresh();self.draw_crosshair()
        def draw_shape(self,s,color,width,tags=()):
            index=None if tags else self.selection_index()   # 0.19.9: the selection looked up once per drawing of the plan
            if index is None:selected=any(i<len(self.items) and self.items[i] is s for i in self.selected_ids()) if not tags else False
            else:k=index.get(id(s));ids=self.selected_set;selected=k is not None and self.items[k] is s and (k in ids if ids else k==self.selected)
            ink=self.p['accent'] if selected else self.p['ink']
            if s.get('text_runs'):
                for part in self.text_parts(s):self.draw_shape(part,color,width,tags or ('label',))
            elif s.get('drill'):
                cx,cy=self.to_screen((s['x']+s['w']/2,s['y']+s['h']/2));r=s['w']/2*self.scale;v=ink if selected else '#c65adf'
                self.canvas.create_oval(cx-r,cy-r,cx+r,cy+r,outline=v,width=1,tags=tags)
                h=r*1.35/math.sqrt(2)
                for sign in (-1,1):self.canvas.create_line(cx-h,cy-sign*h,cx+h,cy+sign*h,fill=v,width=1,tags=tags)
                if not s.get('drill_point'):self.canvas.create_text(cx+r+1.2*self.scale,cy-r-self.scale,text=f'{s["drill_diameter"]:g}',anchor='sw',fill=v,font=('Segoe UI',-max(1,round(2.5*self.scale))),tags=zoom_tag(tags,'t',2.5))
            elif s.get('annotation'):
                st=style(s);v=color if 'hover' in tags else ink if selected or st['color']=='auto' else st['color'];off=s.get('text_offset',[0,0]);cote=bool(s.get('dimension_group'))
                px=max(1,round(s.get('text_height',3)*self.scale))
                self.canvas.create_text(*self.to_screen((s['x']+off[0],s['y']+off[1])),text=s['label'],anchor='center' if 'text_offset' in s else 'nw',angle=-s.get('text_angle',0),fill=v,font=('Segoe UI',-px,s.get('text_weight','normal'),'underline') if s.get('text_underline') else ('Segoe UI',-px,s.get('text_weight','normal')),tags=zoom_tag(tags,'t',s.get('text_height',3)))
            elif s.get('filled'):
                pts,_=path(s);screen=[self.to_screen(p) for p in pts]
                self.canvas.create_polygon(*[v for p in screen for v in p],fill=ink,outline='',tags=tags)
            else:super().draw_shape(s,color,width,tags)
            if selected and not s.get('dimension_group') and self.grips_shown():  # a dimension is one object: no grips on its parts
                x,y,X,Y=bounds([s]);center=((x+X)/2,(y+Y)/2)
                points=[] if __import__('native_edit').circular_edges(s) else [center]
                if s['kind']=='line':points=path(s)[0]+[center]
                elif s['kind']=='poly' and not s.get('annotation') and not any(s.get('bulges',[])) and not s.get('notches'):points+=path(s)[0]
                for p in points:
                    x,y=self.to_screen(p);self.canvas.create_rectangle(x-2,y-2,x+2,y+2,outline=self.prefs.get('anchor_color','#efcf4b'),fill=self.prefs.get('anchor_color','#efcf4b'),width=1,tags='grips')
        def cote_value(self,n):return f'{float(self.format_length(n)):.2f}'.rstrip('0').rstrip('.')
        def measure_label(self,a,b,text):
            A=self.to_screen(a);B=self.to_screen(b);angle=-math.degrees(math.atan2(B[1]-A[1],B[0]-A[0]))
            if angle>90:angle-=180
            if angle< -90:angle+=180
            theta=math.radians(angle)
            self.canvas.create_text((A[0]+B[0])/2-math.sin(theta)*12,(A[1]+B[1])/2-math.cos(theta)*12,text=self.cote_value(math.dist(a,b)),angle=angle,fill=self.p['ink'],font=('Segoe UI',-12),tags=('preview','ruler_value'))
        def radius_click(self,p):
            if self.radius_target is None:
                i=self.pick(p)
                if i is None:raise ValueError('Choisissez un arc ou un cercle.')
                s=self.items[i];target=None
                if s['kind']=='circle':target=circle_data(s)
                elif s['kind']=='rect' and s.get('r',0):
                    r=s['r'];x,y,w,h=[s[k] for k in ('x','y','w','h')]
                    centers=[(x+r,y+r),(x+w-r,y+r),(x+w-r,y+h-r),(x+r,y+h-r)];target=(min(centers,key=lambda c:math.dist(p,c)),r)
                elif s['kind']=='poly' and any(s.get('bulges',[])):
                    pts=[(s['x']+a,s['y']+b) for a,b in s['points']];choices=[]
                    for j,bulge in enumerate(s['bulges'][:len(pts) if s.get('closed') else -1]):
                        if not bulge:continue
                        a,b=pts[j],pts[(j+1)%len(pts)];c=((a[0]+b[0])/2-(b[1]-a[1])*(1-bulge*bulge)/(4*bulge),(a[1]+b[1])/2+(b[0]-a[0])*(1-bulge*bulge)/(4*bulge));choices.append((distance(p,a,b),c,math.dist(a,c)))
                    if choices:_,c,r=min(choices);target=(c,r)
                if target is None:raise ValueError('Ce contour ne possède pas de rayon.')
                self.radius_target=(target[0],target[1],p);self.status.set('Placer la cote de rayon.');return
            self.add_items(self.radius_entities(p),'radius')
        def radius_entities(self,p):
            c,r,clicked=self.radius_target;d=math.dist(c,clicked) or 1;tip=(c[0]+(clicked[0]-c[0])*r/d,c[1]+(clicked[1]-c[1])*r/d)
            line=shape('line','Rayon',*tip,p[0]-tip[0],p[1]-tip[1]);angle=math.degrees(math.atan2(p[1]-tip[1],p[0]-tip[0]));group=uuid.uuid4().hex
            from craft_tools import cote_label,COTE_ARROW
            label=cote_label('R'+self.cote_value(r),p,angle);out=[line,self.arrow(tip,p,COTE_ARROW),label]
            for s in out:s['dimension_group']=group;s['style']=dict(color='auto',width=.12,dash=[],role='dimension')
            return out
        def arrow(self,tip,toward,size):
            dx,dy=toward[0]-tip[0],toward[1]-tip[1];n=math.hypot(dx,dy) or 1;u=(dx/n,dy/n);v=(-u[1],u[0]);s=polygon([tip,(tip[0]+u[0]*size+v[0]*size*.45,tip[1]+u[1]*size+v[1]*size*.45),(tip[0]+u[0]*size-v[0]*size*.45,tip[1]+u[1]*size-v[1]*size*.45)],'Flèche cote',True);s['filled']=True;return s
        def drill_dialog(self):
            """0.18.0: a pointé, a mèche of 1 to 10 mm or another size (the cutting machine may use
            its nearest mèche). A click chooses and the placing starts at once: no « Valider »."""
            win=self.dialog('Pointés et mèches');panel=self.p['panel'];self._drill_window=win
            grid=tk.Frame(win,bg=panel);grid.pack(padx=14,pady=(12,4))
            def choose(size):
                self.drill_diameter=float(size);win.destroy();self.canvas.focus_set();self.status.set('Placer le pointé ou la mèche.')
            sizes=[0.]+[float(k) for k in range(1,11)]
            for k,size in enumerate(sizes):
                b=self.button(grid,'Pointé' if not size else f'{size:g} mm',lambda size=size:choose(size))
                b.grid(row=0 if not size else 1+(k-1)//5,column=0 if not size else (k-1)%5,columnspan=5 if not size else 1,sticky='ew',padx=3,pady=3)
                if abs(size-self.drill_diameter)<1e-9:b.configure(bg=self.p['accent'],fg=contrast_color(self.p['accent']))
            row=tk.Frame(win,bg=panel);row.pack(fill='x',padx=17,pady=(6,14))
            other=tk.StringVar(value='' if self.drill_diameter in sizes else f'{self.drill_diameter:g}'.replace('.',','))
            self.label(row,'Autre taille').pack(side='left');field=self.entry(row,other,7);field.pack(side='left',padx=8);self.label(row,'mm').pack(side='left')
            def typed(e=None):
                try:
                    d=float(other.get().strip().replace(',','.'))
                    if not 0<d<=30:raise ValueError
                except ValueError:messagebox.showerror('Pointés et mèches','Taille de mèche : de 0,1 à 30 mm.',parent=win);return 'break'
                choose(d);return 'break'
            def validate(e=None):
                # 0.18.5 « Valider » (or Entrée): the size typed in « Autre taille », else the highlighted one.
                if other.get().strip():return typed()
                choose(self.drill_diameter);return 'break'
            field.bind('<Return>',typed);field.bind('<KP_Enter>',typed);win.bind('<Return>',validate);win.bind('<KP_Enter>',validate)
            foot=tk.Frame(win,bg=panel);foot.pack(fill='x',padx=17,pady=(0,14))
            self.button(foot,'Valider',validate).pack(side='right')
            win.protocol('WM_DELETE_WINDOW',lambda:(win.destroy(),self.cancel()))
        def text_parts(self,s):
            from editing import annotation_parts
            return annotation_parts(s)
        def place_pending_text(self,p):
            """Second click or Entrée (0.16.16): the label is placed at its first point,
            turned toward p. 0.16.28: always accepted, even if it goes a little outside the
            piece; it stays attached to its piece (owner_id) for the exports."""
            t=self.tool.get();a=self.pending_text_origin
            angle=math.degrees(math.atan2(p[1]-a[1],p[0]-a[0])) if math.dist(a,p)>=1e-6 else 0
            s=self.bundle_at(a,self.pending_bundle,angle)
            from entity_rules import ensure_piece_id,piece_labels
            host=self.items[self.pending_piece];old=set(piece_labels(self.items,self.pending_piece).get(t,[]))
            # Ownership is part of the same undo transaction as the label.
            self.snapshot();s['owner_id']=ensure_piece_id(host);host.setdefault('piece_info',{})[t]=copy.deepcopy(self.pending_identification)
            if old:
                # 0.16.29: the new text replaces the piece's previous one of the same kind.
                self.items=[q for k,q in enumerate(self.items) if k not in old];self.selected=next((k for k,q in enumerate(self.items) if q is host),None);self.selected_set={self.selected} if self.selected is not None else set()
            self.items.append(s);self.complete_command(t);self.refresh()
        def bundle_at(self,p,runs,angle=0,identification=None):
            from craft_tools import text_bundle
            return text_bundle(p,runs,angle,identification if identification is not None else self.pending_identification)
        def identify_dialog(self,kind,item_index=None):
            existing=self.items[item_index] if item_index is not None else None
            # 0.16.29: a piece that already has this text opens it filled in; the text placed
            # next replaces it.
            prefill=existing
            if existing is None and getattr(self,'pending_piece',None) is not None and self.pending_piece<len(self.items):
                from entity_rules import piece_labels
                found=piece_labels(self.items,self.pending_piece).get(kind)
                if found:prefill=self.items[found[0]]
            data=copy.deepcopy(prefill.get('identification',{})) if prefill else {}
            if prefill and not data:
                runs=prefill.get('text_runs',[])
                if kind=='part_name':data=dict(model=runs[0]['text'] if runs else '',values=[runs[1]['text'] if len(runs)>1 else prefill.get('label','')],height=runs[1]['height'] if len(runs)>1 else prefill.get('text_height',3))
                else:
                    import re
                    match=re.match(r'^(\d+)\s+(.*)$',runs[0]['text'] if runs else prefill.get('label',''))
                    data=dict(quantity=match[1] if match else '1',values=[match[2] if match else prefill.get('label','')],height=prefill.get('text_height',3),details=runs[1]['text'] if len(runs)>1 else '')
            win=self.dialog('Nom de pièce' if kind=='part_name' else 'Matière');fields=[]
            model=tk.StringVar(value=data.get('model',self.project_model or (Path(self.filename).stem if self.filename else 'Modèle')))
            if kind=='part_name':
                self.label(win,'Modèle').pack(anchor='w',padx=16,pady=(12,2));self.entry(win,model,48).pack(fill='x',padx=16,pady=(0,10))
            pools=self.archives['names'] if kind=='part_name' else [self.archives.setdefault('materials',[])]
            import materials as mat
            panel=self.p['panel'];kinds={};hidden_on=tk.BooleanVar(value=False);search=tk.StringVar();order=tk.StringVar(value='Nom')
            if kind=='material':
                # 0.17.0: types to show, ticked from the base column of the piece (Dessus → Cuir,
                # Doublures → Tissu and Cuir, Renforts → Renfort, Aides → Gabarit, elsewhere all).
                owner=existing.get('owner_id') if existing is not None else None
                host=next((q for q in self.items if owner and q.get('piece_id')==owner),None) if owner else (self.items[self.pending_piece] if getattr(self,'pending_piece',None) is not None and self.pending_piece<len(self.items) else None)
                try:
                    from geometry import bounds
                    x0,_,x1,_=bounds([host]);centre=(x0+x1)/2
                except (TypeError,ValueError,KeyError,IndexError):centre=None
                ticked=mat.default_kinds(self.workspace,centre);row=tk.Frame(win,bg=panel);row.pack(fill='x',padx=14,pady=(12,0))
                options=dict(bg=panel,fg=self.p['ui_ink'],selectcolor=self.field_background(),activebackground=panel,font=('Segoe UI',10))
                for t in mat.TYPES:
                    kinds[t]=tk.BooleanVar(value=t in ticked);__import__('modern_style').make_check(row,text=t,variable=kinds[t],command=lambda:refills[0](None),**options).pack(side='left',padx=(0,6))
                # 0.19.13: as Mozart's list: the « cachées » on demand, a search, sorted by name, type or code
                hidden_on.set(False);__import__('modern_style').make_check(row,text='Cachées',variable=hidden_on,command=lambda:refills[0](None),**options).pack(side='left',padx=(6,0))
            def shown(pool):
                if kind!='material':return mat.sorted_names(pool)
                return mat.filtered(self.archives,{t for t,v in kinds.items() if v.get()},hidden_on.get(),search.get(),order.get())
            refills=[];refente_row=[];sheet_ui={}
            def show_refente(*args):
                # 0.18.0: a Tissu has no Refente.
                if not refente_row:return
                wanted=mat.has_refente(self.archives,fields[0].get().strip())
                for w in refente_row:
                    if wanted and not w.winfo_ismapped():w.grid()
                    elif not wanted:w.grid_remove()
            columns=tk.Frame(win,bg=panel);columns.pack(padx=10,pady=4,fill='both',expand=True)
            for i,pool in enumerate(pools):
                col=tk.Frame(columns,bg=panel);col.grid(row=0,column=i,sticky='nsew',padx=6);columns.columnconfigure(i,weight=1)
                if kind=='material':self.label(col,'Matière').pack(anchor='w',pady=(0,4))
                var=tk.StringVar(value=(data.get('values',[])+['']*len(pools))[i]);fields.append(var)
                self.entry(col,var,24).pack(fill='x',pady=(0,4))
                if kind=='material':
                    var.trace_add('write',show_refente)
                    tools=tk.Frame(col,bg=panel);tools.pack(fill='x',pady=(0,4))
                    self.label(tools,'Rechercher').pack(side='left');self.entry(tools,search,12).pack(side='left',padx=(4,10))
                    self.label(tools,'Trier par').pack(side='left');ttk.Combobox(tools,textvariable=order,values=list(mat.ORDERS),state='readonly',width=7).pack(side='left',padx=4)
                    search.trace_add('write',lambda *a:refills[0](None));order.trace_add('write',lambda *a:refills[0](None))
                area=tk.Frame(col,bg=panel);area.pack(fill='both',expand=True)
                box=tk.Listbox(area,height=9,width=24,bg=self.field_background(),fg=self.p['ui_ink'],selectbackground=self.p['accent'],selectforeground=contrast_color(self.p['accent']),relief='solid',bd=1,exportselection=False,font=('Segoe UI',10))
                scroll=ttk.Scrollbar(area,orient='vertical',command=box.yview);scroll.pack(side='right',fill='y');box.configure(yscrollcommand=scroll.set);box.pack(side='left',fill='both',expand=True)
                about=tk.StringVar()
                if kind=='material':tk.Label(col,textvariable=about,bg=panel,fg=self.p['ui_ink'],font=('Segoe UI',9),anchor='w').pack(fill='x',pady=(3,0))
                def refill(values,b=box,v=var,pool=pool,about=about):
                    from ui_widgets import refill_list   # 0.18.5: the list keeps its scrolling
                    names=shown(pool);refill_list(b,names,names.index(v.get()) if v.get() in names else None)   # the current name, already chosen
                    about.set(mat.describe(self.archives,v.get()) if kind=='material' and v.get() in self.archives.get('materials',[]) else '')
                def picked(e,b=box,v=var,about=about):
                    if not b.curselection():return
                    v.set(b.get(b.curselection()[0]))
                    if kind=='material':about.set(mat.describe(self.archives,v.get()))
                box.bind('<<ListboxSelect>>',picked);mat.bind_letter_jump(box);refill(None);refills.append(refill)
                def typed(*args,b=box,v=var):
                    # 0.17.0: what is typed in the field shows the first name of the list starting with it.
                    key=mat.sort_key(v.get().strip())
                    if not key:return
                    names=list(b.get(0,'end'));hit=next((k for k,n in enumerate(names) if mat.sort_key(n).startswith(key)),None)
                    if hit is not None and b.curselection()!=(hit,):b.selection_clear(0,'end');b.selection_set(hit);b.see(hit)
                var.trace_add('write',typed)
                if kind=='material':self.button(col,'Archives…',lambda fn=refill:self.edit_material_archive(win,fn,{t for t,v in kinds.items() if v.get()})).pack(anchor='w',pady=7)
                else:self.button(col,'Archives…',lambda p=pool,fn=refill:self.edit_archive(p,win,fn)).pack(anchor='w',pady=7)
            bottom=tk.Frame(win,bg=panel);bottom.pack(fill='x',padx=16,pady=10)
            sizekey='annotation_name_size' if kind=='part_name' else 'annotation_material_size';size=tk.StringVar(value=str(data.get('height',self.prefs.get(sizekey,3))))
            self.label(bottom,'Taille du texte (mm)').grid(row=0,column=0,sticky='w');ttk.Combobox(bottom,textvariable=size,values=[str(i) for i in range(1,11)],state='readonly',width=6).grid(row=0,column=1,padx=8)
            quantity=tk.StringVar(value=str(data.get('quantity','1')));details=tk.StringVar(value=data.get('details',''));refente=tk.StringVar(value=str(data.get('refente','')))
            if kind=='material':
                self.label(bottom,'Quantité').grid(row=1,column=0,sticky='w',pady=5);__import__('tkinter.ttk',fromlist=['Combobox']).Combobox(bottom,textvariable=quantity,values=list(range(1,101)),width=5).grid(row=1,column=1,padx=8,sticky='w')
                # 0.17.0: Refente replaces Précisions (« 7 » → « refente 7/10 »); an old text keeps
                # its Précisions field so nothing written before is lost. 0.18.0: a list from 4 to
                # 20 (another value may be typed), « /10 » after the box; none for a Tissu.
                refente_row[:]=[self.label(bottom,'Refente'),ttk.Combobox(bottom,textvariable=refente,values=mat.REFENTES,width=5),self.label(bottom,'/10')]
                for k,w in enumerate(refente_row):w.grid(row=2,column=k,sticky='w',padx=(8,0) if k==1 else (4,0) if k==2 else 0)
                # 0.19.13: the fiche de pièce as Mozart's (piece_sheet)
                import piece_sheet
                frame=tk.Frame(win,bg=panel);frame.pack(fill='x',padx=16,pady=(0,4))
                sheet_ui.update(piece_sheet.build(self,frame,data,quantity));refente_row.extend(sheet_ui['refentes'])
                show_refente()
                if details.get().strip():self.label(bottom,'Précisions').grid(row=3,column=0,sticky='w',pady=5);self.entry(bottom,details,26).grid(row=3,column=1,padx=8)
            def valid():
                try:
                    height=float(size.get().replace(',','.'))
                    if not .5<=height<=30:raise ValueError('Taille : 0,5 à 30 mm.')
                    values=[v.get().strip() for v in fields if v.get().strip()]
                    if not values:raise ValueError('Choisissez ou saisissez une indication.')
                    if any(len(v)>200 for v in values):raise ValueError('Nom trop long.')
                    runs=[]
                    if kind=='part_name':
                        self.project_model=model.get().strip();runs.append(dict(text=self.project_model,height=max(.5,height*.85),dy=0,color=self.p['guides'],weight='bold',underline=True))
                        runs.append(dict(text='  '.join(values),height=height,dy=height*1.8,color='auto',weight='normal'))
                    else:
                        try:count=int(quantity.get())
                        except ValueError:raise ValueError('Quantité : 1 à 999.') from None
                        if not 1<=count<=999:raise ValueError('Quantité : 1 à 999.')
                        if not mat.has_refente(self.archives,values[0]):refente.set('')
                        split=mat.number(refente.get(),.1,99,'Refente');refente.set(mat.fmt(split) if split else '')
                        # 0.18.0: written like the piece name, not in bold.
                        runs=[dict(text=mat.label_text(count,values[0],refente.get()),height=height,dy=0,color='auto',weight='normal')]
                        if details.get().strip():runs.append(dict(text=details.get().strip(),height=height*.65,dy=height*1.5,color='auto',weight='normal'))
                    metadata=dict(kind=kind,model=model.get().strip(),values=[v.get().strip() for v in fields],height=height,quantity=quantity.get(),details=details.get())
                    if kind=='material':
                        metadata['refente']=refente.get()
                        import piece_sheet
                        typed=sheet_ui['read']() if sheet_ui else {}
                        if not mat.has_refente(self.archives,values[0]):typed.update({k:'' for k in piece_sheet.KEYS if k.startswith(('refente','tolerance'))})
                        metadata.update(piece_sheet.check(typed,count))
                        if data.get('mozart'):metadata['mozart']=copy.deepcopy(data['mozart'])   # what Mozart's file had besides
                    self.prefs[sizekey]=height;self.persist_preferences()
                    if existing is not None:
                        replacement=self.bundle_at((existing['x'],existing['y']),runs,existing.get('text_angle',0),metadata)
                        if 'style' in existing:replacement['style']=copy.deepcopy(existing['style'])
                        owner=existing.get('owner_id');host=next((s for s in self.items if owner and s.get('piece_id')==owner),None)
                        if host is not None:replacement['owner_id']=owner   # 0.16.28: valid even if it goes outside
                        self.snapshot();self.items[item_index]=replacement
                        if host is not None:host.setdefault('piece_info',{})[kind]=metadata
                        self.refresh()
                    else:self.pending_bundle=runs;self.pending_text_origin=None;self.pending_identification=metadata
                    win.destroy();self.canvas.focus_set();self.status.set('Texte modifié.' if existing is not None else 'Placer le premier point du texte, puis choisir son orientation.')
                except ValueError as exc:messagebox.showerror('Identification',str(exc),parent=win)
            self.button(win,'Valider',valid).pack(anchor='e',padx=16,pady=(2,12));win.protocol('WM_DELETE_WINDOW',lambda:(win.destroy(),self.cancel()))
    from precision_ui import enhance_precision
    return enhance_precision(Workbench)
