"""Reversible path editing, endpoint grips and fabrication markers, in mm."""
import copy,math
from geometry import path,bounds,number,distance,clone
from cad import shape,polygon,intersections,segment_intersection,project
from craft_tools import locate,at_distance,perimeter,annotation,style
EPS=1e-6

def inherit(q,s):
    for k in ('style','profile','model','part_names','material','is_notch','piece_id','piece_info','owner_id'):
        if k in s:q[k]=clone(s[k])   # 0.19.18: fast copies (every tool that makes a shape from another)
    return q

def slice_path(s,start,end):
    """Extract an arclength interval. Curved paths use the 0.005 mm display tolerance."""
    pts,closed=path(s);pts=pts+pts[:1] if closed else pts
    out=[];travel=0
    for a,b in zip(pts,pts[1:]):
        length=math.dist(a,b)
        if length<EPS:continue
        lo,hi=max(0,(start-travel)/length),min(1,(end-travel)/length)
        if hi>lo+1e-10:
            A=(a[0]+(b[0]-a[0])*lo,a[1]+(b[1]-a[1])*lo);B=(a[0]+(b[0]-a[0])*hi,a[1]+(b[1]-a[1])*hi)
            if not out or math.dist(out[-1],A)>EPS:out.append(A)
            out.append(B)
        travel+=length
    if len(out)<2:raise ValueError('Portion trop courte.')
    q=shape('line',s['name'],*out[0],out[1][0]-out[0][0],out[1][1]-out[0][1]) if len(out)==2 else polygon(out,s['name'],False)
    inherit(q,s)
    marks=[dict(copy.deepcopy(m),distance=m['distance']-start) for m in s.get('notches',[]) if start-EPS<=m['distance']<=end+EPS]
    if marks:q['notches']=marks
    return q

def join_shapes(items,tolerance=.02):
    items=[s for s in items if __import__('entity_rules').geometry_entity(s)]
    if any(s.get('spline') or s.get('ellipse') or s.get('components') or any(s.get('bulges',[])) for s in items):
        from curves import join
        return join(items,tolerance)
    if len(items)<2:raise ValueError('Sélectionnez au moins deux lignes ou polylignes ouvertes.')
    chains=[]
    for s in items:
        pts,closed=path(s)
        if closed or s.get('annotation') or s.get('drill'):raise ValueError('Joindre demande des contours ouverts.')
        if s.get('notches'):raise ValueError('Joignez les contours avant de poser les crans.')
        chains.append(list(pts))
    # Refuse branches instead of arbitrarily consuming a T-junction.
    ends=[p for chain in chains for p in (chain[0],chain[-1])]
    if any(sum(math.dist(p,q)<=tolerance for q in ends)>2 for p in ends):raise ValueError('Jonction ambiguë : plus de deux extrémités au même point.')
    chain=chains.pop(0)
    while chains:
        found=False
        for i,other in enumerate(chains):
            if math.dist(chain[-1],other[0])<=tolerance:chain.extend(other[1:])
            elif math.dist(chain[-1],other[-1])<=tolerance:chain.extend(other[-2::-1])
            elif math.dist(chain[0],other[-1])<=tolerance:chain=other[:-1]+chain
            elif math.dist(chain[0],other[0])<=tolerance:chain=other[:0:-1]+chain
            else:continue
            chains.pop(i);found=True;break
        if not found:raise ValueError('Les extrémités ne sont pas raccordées (tolérance 0,02 mm).')
    closed=math.dist(chain[0],chain[-1])<=tolerance
    if closed:chain.pop()
    if len(chain)<2:raise ValueError('Contour dégénéré.')
    return inherit(polygon(chain,items[0]['name'],closed),items[0])

def drawn_pieces(s):
    """0.18.5: the pieces ``s`` is drawn with, in its travel order: consecutive arcs of one circle
    (same centre, radius and turn) are ONE arc, consecutive aligned sides ONE line (also across
    the first point of a closed shape); a spline, an oval or a nested part of a compound stays as
    it is. [(piece, start distance along s, length)]; a closed shape that is round all along gives
    one circle (start None)."""
    from curves import parts
    from precision_geometry import primitives,piece_runs,contour_length,without_micro,MICRO
    s=without_micro(s);closed=bool(path(s)[1]);edges=[]   # (primitive or None, source, length, child)
    if s.get('components'):
        for k,q in enumerate(parts(s)):
            n=contour_length(q)
            if n<=MICRO:continue
            if q.get('spline') or q.get('ellipse') or q.get('components'):edges.append((None,q,n,k))
            else:edges+=[(e,q,e['length'],k) for e in primitives(without_micro(q))]
    else:edges=[(e,s,e['length'],None) for e in primitives(s)]
    if not edges:return []
    starts=[0.]
    for e in edges:starts.append(starts[-1]+e[2])
    runs=piece_runs([e[0] for e in edges],closed)
    if closed and len(runs)==1 and edges[0][0] is not None and edges[0][0]['sweep']:
        e=edges[0][0];c,r=e['c'],e['r']
        return [(inherit(shape('circle',s['name'],c[0]-r,c[1]-r,2*r,2*r),s),None,starts[-1])]
    out=[]
    for run in runs:
        first,source,_,child=edges[run[0]];last=edges[run[-1]][0];length=sum(edges[k][2] for k in run)
        whole=child is not None and all(edges[k][3]==child for k in run) and sum(e[3]==child for e in edges)==len(run)
        if first is None or whole and s.get('components'):q=copy.deepcopy(parts(s)[child]) if child is not None else copy.deepcopy(source)
        elif not first['sweep']:a,b=first['a'],last['b'];q=inherit(shape('line',s['name'],*a,b[0]-a[0],b[1]-a[1]),source)
        else:
            q=inherit(polygon([edges[k][0]['a'] for k in run]+[last['b']],s['name'],False),source)
            q['bulges']=[math.tan(edges[k][0]['sweep']/4) for k in run]+[0.]
        q.pop('notches',None);out.append((q,starts[run[0]],length))
    return out

def explode_shape(s):
    """0.18.5 Décomposer (n° 25): a shape gives back the pieces it was drawn with (drawn_pieces):
    one arc per round, one line per straight side; a circle stays whole, a shape round all along
    becomes its circle again. Crans follow their piece (distances measured again); styles and
    profiles are kept. Ovals and splines are cut as before. (Raccord and Couper still use
    curves.decompose.)"""
    from curves import decompose,marks_on
    if not __import__('entity_rules').geometry_entity(s):raise ValueError('Sélectionner ligne/polyligne')
    if s['kind']=='circle':return [copy.deepcopy(s)]
    if s.get('spline') or s.get('ellipse'):return decompose(s)
    if s['kind']=='line':return [copy.deepcopy(s)]
    pieces=drawn_pieces(s)
    if not pieces:return decompose(s)
    out=[q for q,_,_ in pieces]
    # 0.19.9: each cran on the piece through its point, on the one it is drawn the same way on (curves.marks_on): one
    # at a corner went on the next side, its stem turned a quarter.
    if s.get('notches'):marks_on(s,out)
    return out

def trim_shape(s,others,p,vertices=False):
    if not __import__('entity_rules').geometry_entity(s):raise ValueError('Sélectionner ligne/polyligne')
    total=perimeter(s);at=locate(s,p)[0];cuts=[]
    for other in others:
        if not __import__('entity_rules').geometry_entity(other):continue
        for q in intersections(s,other):
            d=locate(s,q)[0]
            if not any(abs(d-v)<EPS for v in cuts):cuts.append(d)
    pts,closed=path(s)
    if vertices:
        # Real corners are stopping points; sampled arcs are not thousands of tiny sides.
        travel=0
        for i,pt in enumerate(pts):
            if i:travel+=math.dist(pts[i-1],pt)
            if (closed or 0<i<len(pts)-1) and len(pts)>2:
                a=pts[i-1];b=pts[(i+1)%len(pts)];u=(pt[0]-a[0],pt[1]-a[1]);v=(b[0]-pt[0],b[1]-pt[1]);n=math.hypot(*u)*math.hypot(*v)
                if n>EPS and (u[0]*v[0]+u[1]*v[1])/n<.98 and not any(abs(travel-c)<EPS for c in cuts):cuts.append(travel)
    cuts.sort()
    if not cuts:return [] if vertices and not closed else None
    if closed:
        if len(cuts)<2:return None
        lo=max((v for v in cuts if v<=at+EPS),default=cuts[-1]-total)
        hi=min((v for v in cuts if v>=at-EPS),default=cuts[0]+total)
        if hi-lo<EPS:
            i=min(range(len(cuts)),key=lambda i:abs(cuts[i]-at));lo=cuts[i];hi=cuts[(i+1)%len(cuts)]+(total if i==len(cuts)-1 else 0)
        start=hi%total;end=lo%total
        if start<end:return [slice_path(s,start,end)]
        first=slice_path(s,start,total) if total-start>EPS else None
        second=slice_path(s,0,end) if end>EPS else None
        if first and second:return [join_shapes([first,second])]
        return [q for q in (first,second) if q]
    cuts=[0]+[v for v in cuts if EPS<v<total-EPS]+[total]
    if len(cuts)<3:return []
    lo=max(v for v in cuts if v<=at+EPS);hi=min((v for v in cuts if v>at+EPS),default=total)
    return ([slice_path(s,0,lo)] if lo>EPS else [])+([slice_path(s,hi,total)] if hi<total-EPS else [])

def implied_hits(start,u,others,tol):
    """0.18.0 Rallonger: where the ray start+t·u meets the PROLONGATION of a straight side that stops
    at most ``tol`` short of it (« la ligne d'en face s'arrête juste avant »): the end lands exactly
    on that side's line."""
    from precision_geometry import primitives,canonical
    from curves import parts
    from entity_rules import geometry_entity
    out=[]
    for other in others:
        if not geometry_entity(other) or other.get('spline') or other.get('ellipse'):continue
        for piece in (parts(other) if other.get('components') else [other]):
            try:edges=primitives(canonical(piece))
            except (KeyError,ValueError,TypeError,ZeroDivisionError):continue
            for e in edges:
                if e['sweep']:continue
                a,b=e['a'],e['b'];d=(b[0]-a[0],b[1]-a[1]);L=math.hypot(*d)
                den=u[0]*d[1]-u[1]*d[0]
                if L<EPS or abs(den)<1e-9*L:continue
                w=(a[0]-start[0],a[1]-start[1]);t=(w[0]*d[1]-w[1]*d[0])/den;k=(w[0]*u[1]-w[1]*u[0])/den
                beyond=max(-k,k-1)*L
                if t>EPS and 0<beyond<=tol:out.append((start[0]+t*u[0],start[1]+t*u[1]))
    return out


def _ray_reaches(start,u,box,margin):
    """0.19.9: whether the half-line start + t·u (t >= 0) passes within margin of box (x0, y0, x1, y1)."""
    lo,hi=0.,math.inf
    for k in (0,1):
        a,b=box[k]-margin,box[k+2]+margin
        if abs(u[k])<1e-12:
            if not a<=start[k]<=b:return False
            continue
        t,T=(a-start[k])/u[k],(b-start[k])/u[k]
        lo,hi=max(lo,min(t,T)),min(hi,max(t,T))
        if lo>hi:return False
    return True


def extend_line(s,others,p,tol=0.):
    if not __import__('entity_rules').geometry_entity(s):raise ValueError('Sélectionner ligne/polyligne')
    if s['kind']!='line':return extend_curve(s,others,p,tol)
    a,b=path(s)[0];end=b if math.dist(p,b)<=math.dist(p,a) else a;fixed=a if end==b else b
    dx,dy=end[0]-fixed[0],end[1]-fixed[1];n=math.hypot(dx,dy)
    if n<EPS:return None
    far=(end[0]+dx/n*200000,end[1]+dy/n*200000);candidates=[]
    ray=shape('line','Rayon',*end,far[0]-end[0],far[1]-end[1])
    # 0.19.9: only the objects whose box the ray reaches (within tol + 1 mm, for implied_hits too): the 200 m ray
    # passed every box test, so every object was searched (48 ms on 520 objects). The ray itself is unchanged.
    others=[o for o in others if __import__('entity_rules').geometry_entity(o) and _ray_reaches(end,(dx/n,dy/n),bounds([o]),tol+1)]
    for other in others:
        for q in intersections(ray,other):
            if math.dist(q,end)>EPS:candidates.append(q)
    if tol>0:candidates+=[q for q in implied_hits(end,(dx/n,dy/n),others,tol) if math.dist(q,end)>EPS]
    if not candidates:return None
    q=min(candidates,key=lambda q:math.dist(q,end));new=inherit(shape('line',s['name'],*fixed,q[0]-fixed[0],q[1]-fixed[1]),s)
    # Keep original travel direction and attached marks.
    if end==a:
        new=inherit(shape('line',s['name'],*q,b[0]-q[0],b[1]-q[1]),s)
        marks=[dict(copy.deepcopy(m),distance=m['distance']+math.dist(q,a)) for m in s.get('notches',[])]
    else:marks=copy.deepcopy(s.get('notches',[]))
    if marks:new['notches']=marks
    return new

def extend_curve(s,others,p,tol=0.):
    """Extend one open end, preserving native lines, arcs and spline controls."""
    from curves import decompose,compound,arc,parts,cubics,from_cubics
    from precision_geometry import primitives,without_micro
    s=without_micro(s)
    pts,closed=path(s)
    if closed:
        # 0.19.9: the crans are kept (all were lost): each at the nearest point of the new contour (in place on the sides
        # that do not change, measured again), same side; turned over where the contour now runs the other way.
        def kept(q):
            if s.get('notches'):
                q['notches']=[]
                for mark in s['notches']:
                    pt,n0=at_distance(s,mark['distance']);d,foot=locate(q,pt);n1=at_distance(q,d)[1];m=dict(copy.deepcopy(mark),distance=d)
                    if math.dist(foot,pt)<.01 and n0[0]*n1[0]+n0[1]*n1[1]<0:m['side']=-mark.get('side',1)
                    q['notches'].append(m)
            return q
        if s.get('components'):
            from precision_geometry import contour_location
            children=parts(s);index=min(range(len(children)),key=lambda k:math.dist(contour_location(children[k],p)[1],p))
            new=extend_line(children[index],others,p,tol)
            if new is None:return None
            children[index]=new
            # The other sides stay in place; an extension can open the original joint.
            return kept(inherit(compound(children,s['name'],False),s))   # 0.19.9: crans kept
        if s.get('spline') or s.get('ellipse') or s['kind']=='circle':return None
        from precision_geometry import canonical,at_primitive
        # Extend the chosen edge; adjacent edges remain connected to its new end.
        q=canonical(s);es=primitives(q)
        index=min(range(len(es)),key=lambda k:min(math.dist(p,at_primitive(es[k],v/16)) for v in range(17)))
        e=es[index];terminal=arc(e['c'],e['r'],e['start'],e['sweep']) if e['sweep'] else shape('line','',*e['a'],e['b'][0]-e['a'][0],e['b'][1]-e['a'][1])
        extension=extend_curve(terminal,others,p,tol) if e['sweep'] else extend_line(terminal,others,p,tol)
        if extension is None:return None
        nes=primitives(extension)
        if extension.get('closed') or sum(abs(v['sweep']) for v in nes)>=2*math.pi-EPS:
            children=decompose(s);children[index]=extension
            return kept(inherit(compound(children,s['name'],False),s))   # 0.19.9: crans kept
        points=[(q['x']+x,q['y']+y) for x,y in q['points']];bs=list(q.get('bulges',[0]*len(points)))
        # 0.19.9: primitives() skips zero-length sides (a rounded rectangle whose radius is half its width):
        # the chosen edge number is turned back into its point number.
        index=[k for k,v in enumerate(points) if math.dist(v,points[(k+1)%len(points)])>=1e-10][index]
        points[index]=nes[0]['a'];points[(index+1)%len(points)]=nes[-1]['b']
        if e['sweep']:bs[index]=math.tan(sum(v['sweep'] for v in nes)/4)
        out=inherit(polygon(points,s['name'],True),s);out['bulges']=bs;return kept(out)   # 0.19.9: crans kept
    at_start=math.dist(p,pts[0])<math.dist(p,pts[-1])
    # 0.19.9: the crans stay in place: their distances grow by the length added before the start (as
    # extend_line does for a line); on a contour the lengthening closed (an arc grown into its circle, an
    # oval into its ellipse) they are measured again.
    def carried(q):
        if s.get('notches'):
            closes=path(q)[1];gain=perimeter(q)-perimeter(s) if at_start and not closes else 0.;q['notches']=[]
            for mark in s['notches']:
                m=dict(copy.deepcopy(mark),distance=mark['distance']+gain)
                if closes:
                    pt,n0=at_distance(s,mark['distance']);m['distance']=locate(q,pt)[0];n1=at_distance(q,m['distance'])[1]
                    if n0[0]*n1[0]+n0[1]*n1[1]<0:m['side']=-mark.get('side',1)
                q['notches'].append(m)
        return q
    if s.get('ellipse'):
        e=s['ellipse'];tau=2*math.pi;reverse=bool(s.get('reversed'));before=at_start!=reverse
        angle=e['start'] if before else e['start']+e['sweep'];direction=-1 if before else 1
        full=copy.deepcopy(s);full['ellipse'].update(start=0,sweep=tau);full['closed']=True;hits=[]
        co,si=math.cos(e['angle']),math.sin(e['angle'])
        for other in others:
            if not __import__('entity_rules').geometry_entity(other):continue
            for x,y in intersections(full,other):
                dx,dy=x-s['x'],y-s['y'];theta=math.atan2((-dx*si+dy*co)/e['ry'],(dx*co+dy*si)/e['rx'])
                delta=((theta-angle)*direction)%tau
                if delta>1e-6 and delta+e['sweep']<tau-1e-6:hits.append(delta)
        extra=min(hits) if hits else tau-e['sweep'];new=copy.deepcopy(s);new['ellipse']['sweep']+=extra
        if abs(new['ellipse']['sweep']-tau)<EPS:new['closed']=True
        if before:new['ellipse']['start']-=extra
        return carried(new)   # 0.19.9: crans shifted when the start grows
    if s.get('spline'):
        cs=cubics(s);c=cs[0] if at_start else cs[-1];end=c[0] if at_start else c[3];control=c[1] if at_start else c[2]
        dx,dy=end[0]-control[0],end[1]-control[1];length=math.hypot(dx,dy)
        if length<EPS:raise ValueError('La tangente de cette extrémité est nulle.')
        ray=shape('line','',*end,dx/length*1e-4,dy/length*1e-4);extended=extend_line(ray,others,(ray['x']+ray['w'],ray['y']+ray['h']),tol)
        if extended is None:return None
        target=path(extended)[0][-1]
        a,b=(target,end) if at_start else (end,target)
        addition=[a,(a[0]+(b[0]-a[0])/3,a[1]+(b[1]-a[1])/3),(a[0]+2*(b[0]-a[0])/3,a[1]+2*(b[1]-a[1])/3),b]
        return carried(inherit(from_cubics(([addition]+cs) if at_start else (cs+[addition]),False,s['name']),s))   # 0.19.9: crans kept
    # 0.18.5: the end piece is the whole last line or arc of the drawing (an arc stored in several
    # parts is lengthened as one arc), as Couper stops between pieces (n° 32).
    pieces=drawn_pieces(s)
    children=[q for q,_,_ in pieces] if pieces and pieces[0][1] is not None else parts(s) if s.get('components') else decompose(s)
    index=0 if at_start else len(children)-1;terminal=children[index]
    # 0.17.0: the other sides of the same polyline are limits too (e.g. a cut side lengthened
    # back up to the top of the piece).
    others=list(others)+[c for k,c in enumerate(children) if k!=index]
    if terminal.get('spline') or terminal.get('ellipse'):new=extend_curve(terminal,others,p,tol)
    else:
        from precision_geometry import same_piece
        es=primitives(terminal)
        if not es or any(not same_piece(f,g) for f,g in zip(es,es[1:])):raise ValueError('Choisir une extrémité ouverte.')
        e=dict(es[0],b=es[-1]['b'],sweep=sum(f['sweep'] for f in es)) if es[0]['sweep'] else es[0]
        if not e['sweep']:new=extend_line(terminal,others,p,tol)
        else:
            c,r=e['c'],e['r'];direction=(1 if e['sweep']>0 else -1)*(-1 if at_start else 1)
            angle=e['start']+(0 if at_start else e['sweep']);circle=shape('circle','',c[0]-r,c[1]-r,2*r,2*r);hits=[]
            for other in others:
                if not __import__('entity_rules').geometry_entity(other):continue
                for point in intersections(circle,other):
                    delta=((math.atan2(point[1]-c[1],point[0]-c[0])-angle)*direction)%(2*math.pi)
                    if delta>1e-6 and delta+abs(e['sweep'])<2*math.pi-1e-6:hits.append(delta)
            if not hits:
                new=inherit(circle,terminal);new['name']=s['name']
            else:
                extra=min(hits);new=inherit(arc(c,r,e['start'] if not at_start else e['start']+direction*extra,e['sweep']+(1 if e['sweep']>0 else -1)*extra,s['name']),terminal)
    if new is None:return None
    children[index]=new
    if len(children)==1:return carried(inherit(new,s))   # 0.19.9: crans kept
    # The lengthened end reaching the other end closes the polyline.
    closing=math.dist(path(children[0])[0][0],path(children[-1])[0][-1])<=.02
    return carried(chain_polyline(children,s,closing) or inherit(compound(children,s['name'],closing),s))   # 0.19.9: crans kept


def chain_polyline(children,source,closed=False):
    """0.17.0: lines and arcs end to end as ONE polyline with bulges (not a compound), so that
    every tool keeps working on it; None when a child is a spline, an ellipse or a compound."""
    from precision_geometry import primitives
    es=[]
    for c in children:
        if c.get('spline') or c.get('ellipse') or c.get('components'):return None
        es+=primitives(c)
    if not es:return None
    pts=[e['a'] for e in es]+([] if closed else [es[-1]['b']]);bs=[math.tan(e['sweep']/4) for e in es]+([] if closed else [0])
    out=inherit(polygon(pts,source['name'],closed),source)
    if any(bs):out['bulges']=bs
    return out


def line_intersection(a,b,c,d):
    u=(b[0]-a[0],b[1]-a[1]);v=(d[0]-c[0],d[1]-c[1]);den=u[0]*v[1]-u[1]*v[0]
    if abs(den)<EPS:raise ValueError('Les côtés sont parallèles.')
    t=((c[0]-a[0])*v[1]-(c[1]-a[1])*v[0])/den
    return a[0]+t*u[0],a[1]+t*u[1]

def corner_points(a,I,b,mode,value):
    U,V=math.dist(a,I),math.dist(b,I)
    if min(U,V)<EPS:raise ValueError('Côté trop court.')
    u=((a[0]-I[0])/U,(a[1]-I[1])/U);v=((b[0]-I[0])/V,(b[1]-I[1])/V)
    angle=math.acos(max(-1,min(1,u[0]*v[0]+u[1]*v[1])))
    if angle<EPS or abs(angle-math.pi)<EPS:raise ValueError('Angle dégénéré.')
    if mode=='corner':return [a,I,b],[0,0,0]
    d=value/math.tan(angle/2) if mode=='fillet' else value
    if d<=0 or d>=min(U,V)-EPS:raise ValueError('Rayon ou distance trop grand pour les côtés.')
    A=(I[0]+u[0]*d,I[1]+u[1]*d);B=(I[0]+v[0]*d,I[1]+v[1]*d)
    bulge=0
    if mode=='fillet':
        z=math.hypot(u[0]+v[0],u[1]+v[1]);C=(I[0]+(u[0]+v[0])/z*value/math.sin(angle/2),I[1]+(u[1]+v[1])/z*value/math.sin(angle/2))
        sweep=math.atan2((A[0]-C[0])*(B[1]-C[1])-(A[1]-C[1])*(B[0]-C[0]),(A[0]-C[0])*(B[0]-C[0])+(A[1]-C[1])*(B[1]-C[1]))
        bulge=math.tan(sweep/4)
    return [a,A,B,b],[0,bulge,0,0]

def straight_ends(s):
    """0.19.2: the two ends of a plain straight side (a line, or a cut line: an open two-point
    polyline without curve), None for anything else or a side carrying crans."""
    if s.get('notches') or s.get('spline') or s.get('ellipse') or s.get('components') or s.get('annotation'):return None
    if s['kind']=='line':pts=path(s)[0]
    elif s['kind']=='poly' and not s.get('closed') and len(s.get('points',()))==2 and not any(s.get('bulges') or ()):pts=path(s)[0]
    else:return None
    return (pts[0],pts[-1]) if len(pts)>=2 and math.dist(pts[0],pts[-1])>EPS else None

def parallel(a,b,c,d):
    """0.19.2: the sides ab and cd are parallel (or so close to it that their crossing is more than a
    thousand gaps away: no usable corner there)."""
    u=(b[0]-a[0],b[1]-a[1]);v=(d[0]-c[0],d[1]-c[1]);lu,lv=math.hypot(*u),math.hypot(*v)
    return lu>EPS and lv>EPS and abs(u[0]*v[1]-u[1]*v[0])<1e-3*lu*lv

def parallel_corner(s,t,p,q,mode,value=0):
    """0.19.2: Arrondi / Angle droit / Chanfrein between two parallel straight sides. From the end of
    the first side next to its click, on along it, to the second side: a quarter round whose radius is
    the gap (Arrondi: it leaves the first side along it and reaches the second at a right angle), a
    perpendicular (Angle droit) or a 45° side (Chanfrein). The second side is cut where it is reached
    (lengthened up to there if it stops before) and keeps its clicked part. One open polyline: first
    side, link, second side. 0.19.6 (« au rayon réglé »): a radius (a chamfer) smaller than the gap: the
    quarter round (the 45° side) that size, then a straight side to the second at a right angle."""
    a,b=straight_ends(s);c,d=straight_ends(t)
    E,far=(a,b) if math.dist(p,a)<=math.dist(p,b) else (b,a)
    L=math.dist(E,far);u=((E[0]-far[0])/L,(E[1]-far[1])/L)
    lv=math.dist(c,d);v=((d[0]-c[0])/lv,(d[1]-c[1])/lv)
    k=(E[0]-c[0])*v[0]+(E[1]-c[1])*v[1];F=(c[0]+k*v[0],c[1]+k*v[1]);g=math.dist(E,F)
    if g<1e-4:raise ValueError('Les deux côtés sont alignés.')
    n=((F[0]-E[0])/g,(F[1]-E[1])/g)   # toward the second side
    r=value if mode!='corner' and value and 0<value<g-1e-9 else g
    X=None if mode=='corner' or r>=g else (E[0]+r*u[0]+r*n[0],E[1]+r*u[1]+r*n[1])   # the end of the round (of the 45° side)
    B=F if mode=='corner' else (F[0]+r*u[0],F[1]+r*u[1])
    # The second side keeps the end on its clicked side of B (the farther one if both are there); 0.19.6:
    # that side judged where a round as large as the gap would reach it (the same part kept at any radius).
    at=lambda X:(X[0]-c[0])*v[0]+(X[1]-c[1])*v[1]
    tB=at(B);tq=at(q);tG=tB if mode=='corner' else at((F[0]+g*u[0],F[1]+g*u[1]))
    ends=[(0.,c),(lv,d)];side=[e for e in ends if (e[0]-tB)*(tq-tG)>0]
    keep=max(side or ends,key=lambda e:abs(e[0]-tB))[1]
    pts=[far,E]+([X] if X else [])+[B]+([keep] if math.dist(keep,B)>1e-4 else [])
    bulge=0
    if mode=='fillet':
        cross=u[0]*n[1]-u[1]*n[0]
        bulge=math.tan(math.copysign(math.pi/2,cross)/4)   # a quarter turn (round E+r·n)
    out=inherit(polygon(pts,s['name'],False),s);out['bulges']=[0,bulge]+[0]*(len(pts)-2)
    return out

STRAP=('strap_round','strap_point','strap_belt')   # 0.19.3: Bout rond, Bout pointu; 0.19.6: Bout de ceinture
BELT_END=dict(taper=45.,tip=27.,round=1.5)   # 0.19.6: Bout de ceinture (mm): length of the taper, width of the tip, rounds

def _open_points(s):
    """The absolute points and bulges of an open polyline."""
    pts=[(s['x']+a,s['y']+b) for a,b in s.get('points',())];bs=list(s.get('bulges') or [0.]*len(pts))
    return pts,(bs+[0.]*len(pts))[:len(pts)]


def _reversed(pts,bs):
    return pts[::-1],[-bs[len(bs)-2-i] if i<len(bs)-1 else 0. for i in range(len(bs))]


def open_end_side(s,p):
    """0.19.5: the straight side of an open polyline next to the click ``p`` when it ends the polyline:
    (its inner end, its free end, 'start' or 'end'); None otherwise (a side between two others, an arc,
    a closed contour; a line or a cut line: straight_ends)."""
    if s['kind']!='poly' or s.get('closed') or s.get('notches') or s.get('spline') or s.get('ellipse') or s.get('components') or s.get('annotation'):return None
    pts,bs=_open_points(s)
    if len(pts)<3:return None
    k=min(range(len(pts)-1),key=lambda k:distance(p,pts[k],pts[k+1]))
    if k not in (0,len(pts)-2) or abs(bs[k])>1e-12 or math.dist(pts[k],pts[k+1])<=EPS:return None
    return (pts[1],pts[0],'start') if k==0 else (pts[-2],pts[-1],'end')


def side_of(s,p):
    """0.19.5: the straight side of ``s`` picked by ``p`` for a raccord between parallel sides:
    ((end, end), None) for a line or a cut line, ((inner end, free end), 'start' / 'end') for the end side
    of an open polyline; None for anything else."""
    ends=straight_ends(s)
    if ends:return ends,None
    side=open_end_side(s,p)
    return ((side[0],side[1]),side[2]) if side else None


def moved_end(s,which,B):
    """0.19.5: the open polyline ``s`` with its free end ``which`` moved to B along its straight end side
    (that side dropped when B is its other end)."""
    pts,bs=_open_points(s)
    if which=='start':pts,bs=_reversed(pts,bs)
    if math.dist(B,pts[-2])<=1e-4:pts,bs=pts[:-1],bs[:-1];bs[-1]=0.
    else:pts[-1]=tuple(B)
    if which=='start':pts,bs=_reversed(pts,bs)
    out=inherit(polygon(pts,s['name'],False),s);out['bulges']=bs;return out


def _side_line(ends,s):
    (a,b)=ends;return inherit(shape('line',s['name'],a[0],a[1],b[0]-a[0],b[1]-a[1]),s)


def landing(R,c,d):
    """0.19.6: the index of the point where a raccord made by parallel_corner / strap_lines (its points R)
    reaches the second side's line cd: the nearest to that line of the points after the first side's end
    (a tolerance would miss it on sides parallel within 1/1000 only)."""
    L=math.dist(c,d);off=lambda X:abs((d[0]-c[0])*(X[1]-c[1])-(d[1]-c[1])*(X[0]-c[0]))/L
    tol=max(1e-6,3e-3*off(R[1]))   # sides parallel within 1/1000: the raccord lands that close to the line
    return next((k for k in range(2,len(R)) if off(R[k])<=tol),min(range(2,len(R)),key=lambda k:off(R[k])))


def parallel_sides(s,t,p,q,mode,value=0,extent=()):
    """0.19.5: Arrondi / Angle droit / Chanfrein / Bout rond / pointu between two parallel straight sides
    of which one or both end an open polyline: made on those sides as between two lines, the polyline's
    free end at the corner. A first polyline stays whole; a second one has its free end moved to the
    raccord. Pieces: [first side, the raccord's pieces…, second side]; None when it does not apply."""
    from curves import decompose
    S,T=side_of(s,p),side_of(t,q)
    if not S or not T or (S[1] is None and T[1] is None) or not parallel(*S[0],*T[0]):return None
    (a,b),ws=S;(c,d),wt=T
    if ws and math.dist(p,b)>math.dist(p,a):return None   # clicked near its inner end: that is not a corner of the polyline
    first,second=_side_line((a,b),s),_side_line((c,d),t)
    pp=b if ws else p   # the free end of a polyline is the corner
    qq=c if wt else q   # a polyline keeps its body
    if wt:
        u=(b[0]-a[0],b[1]-a[1]) if ws else None
        if u is None:
            E,far=(a,b) if math.dist(p,a)<=math.dist(p,b) else (b,a);u=(E[0]-far[0],E[1]-far[1])
        if (d[0]-c[0])*u[0]+(d[1]-c[1])*u[1]<=0 and mode in STRAP:raise ValueError('Le bout libre de la polyligne n’est pas de ce côté.')
    joined=strap_lines(first,second,pp,qq,mode,value,extent) if mode in STRAP else parallel_corner(first,second,pp,qq,mode,value)
    if not wt:
        pieces=decompose(joined)
        if ws:pieces[0]=moved_end(s,ws,path(pieces[0])[0][-1])   # 0.19.6: an end made inside moves the free end back
        return pieces
    # A second polyline: its free end goes where the raccord reaches its line, which must be on its free
    # side of its inner end (or that end itself: the end side goes).
    R=[(joined['x']+x,joined['y']+y) for x,y in joined['points']];RB=(list(joined.get('bulges') or [])+[0.]*len(R))[:len(R)]
    k=landing(R,c,d);B=R[k]
    if math.dist(B,c)>1e-4 and (B[0]-c[0])*(d[0]-c[0])+(B[1]-c[1])*(d[1]-c[1])<=0:raise ValueError('Le raccord tombe au-delà du coin de la polyligne.')
    link=inherit(polygon(R[1:k+1],s['name'],False),s);link['bulges']=RB[1:k]+[0.]
    head=moved_end(s,ws,R[1]) if ws else inherit(shape('line',s['name'],R[0][0],R[0][1],R[1][0]-R[0][0],R[1][1]-R[0][1]),s)
    return [head]+decompose(link)+[moved_end(t,wt,B)]


def close_open_end(s,p,q,mode,value=0):
    """0.19.5: the two parallel end sides of one open polyline (a strap drawn as a U), clicked near its
    open end: the raccord closes the polyline there (from the end of the side clicked first); None when
    it does not apply."""
    A,B=open_end_side(s,p),open_end_side(s,q)
    if not A or not B or A[2]==B[2] or not parallel(A[0],A[1],B[0],B[1]):return None
    if math.dist(p,A[1])>math.dist(p,A[0]):return None   # clicked near the inner end: not this open end
    if (A[1][0]-A[0][0])*(B[1][0]-B[0][0])+(A[1][1]-A[0][1])*(B[1][1]-B[0][1])<=0:return None   # a Z, not a U: no open end between them
    pts,bs=_open_points(s)
    if A[2]=='start':pts,bs=_reversed(pts,bs)   # the side clicked first ends the polyline
    first,second=_side_line((pts[-2],pts[-1]),s),_side_line((pts[1],pts[0]),s)
    joined=strap_lines(first,second,pts[-1],pts[1],mode,value) if mode in STRAP else parallel_corner(first,second,pts[-1],pts[1],mode,value)
    R=[(joined['x']+x,joined['y']+y) for x,y in joined['points']];RB=list(joined.get('bulges') or [0.]*len(R))
    if math.dist(R[-1],pts[1])>1e-4:raise ValueError('Le raccord tombe au-delà du coin de la polyligne.')   # it must come back along the first side
    cycle=pts[1:-1]+R[1:];bulges=bs[1:-1]+RB[1:]
    if math.dist(cycle[-1],pts[1])<=1e-4:cycle,bulges=cycle[:-1],bulges[:-1]
    end=cycle[-1]
    if (end[0]-pts[1][0])*(pts[0][0]-pts[1][0])+(end[1]-pts[1][1])*(pts[0][1]-pts[1][1])<=-1e-9:raise ValueError('Le raccord tombe au-delà du coin de la polyligne.')
    bulges[-1]=0.
    out=inherit(polygon(cycle,s['name'],True),s);out['bulges']=bulges;return out


def rounded_chain(V,r):
    """0.19.6: the corners V[1..-2] of a chain of straight sides rounded at the radius r (V[0] and V[-1]: a
    point on the side before the first corner and on the side after the last). The points from the first
    round to the last, and the bulges of their sides; ValueError when a side is too short for its rounds."""
    corners=[]
    for k in range(1,len(V)-1):
        a,I,b=V[k-1],V[k],V[k+1];U,W=math.dist(a,I),math.dist(b,I)
        if U<EPS or W<EPS:raise ValueError('Côté trop court pour ce bout.')
        u=((a[0]-I[0])/U,(a[1]-I[1])/U);v=((b[0]-I[0])/W,(b[1]-I[1])/W)
        angle=math.acos(max(-1.,min(1.,u[0]*v[0]+u[1]*v[1])))   # between the two sides
        if r<=0 or angle>math.pi-1e-9:corners.append((I,I,0.,0.));continue
        d=r/math.tan(angle/2);cross=u[0]*v[1]-u[1]*v[0]
        corners.append(((I[0]+u[0]*d,I[1]+u[1]*d),(I[0]+v[0]*d,I[1]+v[1]*d),math.tan(math.copysign(math.pi-angle,-cross)/4),d))
    for k in range(len(corners)-1):
        if corners[k][3]+corners[k+1][3]>math.dist(V[k+1],V[k+2])+1e-9:raise ValueError('Côté trop court pour ces arrondis.')
    pts,bs=[],[]
    for A,B,bulge,d in corners:
        if d:pts+=[A,B];bs+=[bulge,0.]
        else:pts.append(A);bs.append(0.)
    return pts,bs


def strap_link(P,u,Q,mode,value=0):
    """0.19.3: the end of a strap between its two facing corners P and Q (the strap going out along u).
    0.19.6 (« ça ne rallonge pas, garde la même longueur de bande »): made INSIDE the strap, its tip on PQ:
    Bout rond: one arc across the whole width from ``value`` mm back from the end (half the width, the
    most and by default: a half round) through the middle of PQ; Bout pointu: a point ``value`` mm long
    (half the width by default: 45°); Bout de ceinture: ``value`` = (taper, tip, round): the edges come in
    straight over ``taper`` mm to a straight tip ``tip`` mm wide on PQ, the four corners rounded at
    ``round`` mm. Its points from the first edge to the second and the bulges of their sides."""
    M=((P[0]+Q[0])/2,(P[1]+Q[1])/2);h=math.dist(P,Q)/2
    back=lambda X,d:(X[0]-d*u[0],X[1]-d*u[1])
    if mode=='strap_belt':
        taper,tip,r=value if isinstance(value,(tuple,list)) else (BELT_END['taper'],BELT_END['tip'],BELT_END['round'])
        if not taper>0:raise ValueError('Bout de ceinture : longueur de l’affinement positive.')
        if not 0<tip<2*h-1e-6:raise ValueError('Bout de ceinture : largeur du bout plus petite que la sangle ('+f'{2*h:.1f}'.replace('.',',')+' mm).')
        w=((P[0]-M[0])/h,(P[1]-M[1])/h)   # from the middle toward P
        B=(M[0]+w[0]*tip/2,M[1]+w[1]*tip/2);C=(M[0]-w[0]*tip/2,M[1]-w[1]*tip/2)
        return rounded_chain([back(P,taper+1),back(P,taper),B,C,back(Q,taper),back(Q,taper+1)],r)
    if mode=='strap_point':
        L=value if value and value>0 else h
        return [back(P,L),M,back(Q,L)],[0,0,0]
    d=min(value,h) if value and value>0 else h
    cross=(P[0]-M[0])*u[1]-(P[1]-M[1])*u[0]
    return [back(P,d),back(Q,d)],[(1 if cross>0 else -1)*d/h,0]   # bulge = sagitta / half chord (1: a half round)

def strap_lines(s,t,p,q,mode,length=0,extent=()):
    """0.19.3: Bout rond / Bout pointu on two parallel edges (lines or cut lines): the end of the strap at
    the end of the first edge next to its click, across to the second edge (0.19.6: made inside, the tip
    where the first edge ended); the second edge goes on from there back along the strap (cut or
    lengthened up to it). One open polyline: first edge, end, second edge."""
    a,b=straight_ends(s);c,d=straight_ends(t)
    E,far=(a,b) if math.dist(p,a)<=math.dist(p,b) else (b,a)
    L=math.dist(E,far);u=((E[0]-far[0])/L,(E[1]-far[1])/L)
    lv=math.dist(c,d);v=((d[0]-c[0])/lv,(d[1]-c[1])/lv)
    k=(E[0]-c[0])*v[0]+(E[1]-c[1])*v[1];F=(c[0]+k*v[0],c[1]+k*v[1])
    if math.dist(E,F)<1e-4:raise ValueError('Les deux bords sont alignés.')
    behind=lambda X:(X[0]-F[0])*u[0]+(X[1]-F[1])*u[1]
    keep=min((c,d),key=behind)
    if behind(keep)>-1e-4:raise ValueError('Les deux bords ne se font pas face : le 2e est tout entier au-delà du bout.')
    # 0.19.6: an end done there before (``extent``: its pieces): the new one has its tip where that one had it
    # (made inside, an end done again would shorten the strap each time).
    out_by=max(0.,reach(extent,E,u)[1]) if extent else 0.
    P,Q=(E[0]+out_by*u[0],E[1]+out_by*u[1]),(F[0]+out_by*u[0],F[1]+out_by*u[1])
    pts,bs=strap_link(P,u,Q,mode,length)
    if (pts[0][0]-far[0])*u[0]+(pts[0][1]-far[1])*u[1]<=1e-4 or behind(keep)>=behind(pts[-1])-1e-4:raise ValueError('Côté trop court pour ce bout.')
    out=inherit(polygon([far]+pts+[keep],s['name'],False),s);out['bulges']=[0]+bs[:-1]+[0,0]
    return out

def straight_side_at(s,p):
    """0.19.6: the straight side of any line or contour (a line, a polyline, a rectangle, a closed piece) next
    to the click ``p``: its two ends; None when that side is a curve (or the shape has no sides)."""
    if s.get('spline') or s.get('ellipse') or s.get('components') or s.get('annotation') or s.get('drill') or s.get('is_notch'):return None
    if s['kind']=='line':
        pts=path(s)[0];return (pts[0],pts[-1]) if math.dist(pts[0],pts[-1])>EPS else None
    if s['kind'] not in ('rect','poly'):return None
    from precision_geometry import canonical,primitives,at_primitive
    es=primitives(canonical(s))
    if not es:return None
    def gap(e):
        if not e['sweep']:return distance(p,e['a'],e['b'])
        return min(math.dist(p,at_primitive(e,k/32)) for k in range(33))   # the arc itself, not its ends
    e=min(es,key=gap)
    return None if e['sweep'] or math.dist(e['a'],e['b'])<=EPS else (e['a'],e['b'])


def open_at_corner(s,p,I):
    """0.19.6 (« ça ne doit pas décomposer le rectangle de base »): a piece (rectangle, closed polyline)
    opened at the end of its side clicked at ``p`` that the raccord at I moves (the end on the other side of
    I from the click: the clicked part is kept): an open polyline whose end side is that side (the piece's
    other sides stay one contour); ``s`` itself otherwise. An open polyline clicked on a side between two
    others is cut at that end: (the part ending with that side, the rest) — see opened_at."""
    return opened_at(s,p,I)[0]


def opened_at(s,p,I):
    """0.19.6: (the polyline whose end side is the side clicked, its free end the one the raccord at I
    moves; the rest of an open polyline cut there, or None). ``s`` unchanged (and None) when it does not
    apply (a line, a curve, a side already at an end)."""
    if s['kind'] not in ('rect','poly') or s.get('notches') or s.get('spline') or s.get('ellipse') or s.get('components'):return s,None
    from precision_geometry import canonical,without_micro
    q=canonical(without_micro(s));n=len(q['points']);closed=bool(q.get('closed'))
    V=[(q['x']+x,q['y']+y) for x,y in q['points']];B=(list(q.get('bulges') or [])+[0.]*n)[:n]
    sides=n if closed else n-1
    k=min((j for j in range(sides) if abs(B[j])<1e-12),key=lambda j:distance(p,V[j],V[(j+1)%n]),default=None)
    if k is None:return s,None
    a,b=V[k],V[(k+1)%n]
    toward=lambda E:(E[0]-I[0])*(p[0]-I[0])+(E[1]-I[1])*(p[1]-I[1])
    free_b=toward(b)<=toward(a)   # the end moved: on the other side of I from the click (the nearer one beyond)
    keep={key:copy.deepcopy(val) for key,val in s.items() if key not in ('kind','x','y','w','h','r','points','closed','bulges','name')}
    def made(order,bs):
        out=polygon([V[j] for j in order],s['name'],False);out.update(copy.deepcopy(keep))
        if any(bs):out['bulges']=bs
        return out
    if closed:
        if free_b:order=[(k+1+m)%n for m in range(n)]+[(k+1)%n]   # starts after the corner b, ends with the side a→b
        else:order=[(k+m)%n for m in range(n)]+[k]   # starts with the side a→b at the corner a
        return made(order,[B[j] for j in order[:-1]]+[0.]),None
    if free_b and k==n-2 or not free_b and k==0:return s,None   # already the end side, its free end there
    if free_b:   # cut at b: the part ending with a→b, then the rest from b
        return made(list(range(k+2)),B[:k+1]+[0.]),(made(list(range(k+1,n)),B[k+1:n-1]+[0.]) if k+1<n-1 else None)
    return made(list(range(k,n)),B[k:n-1]+[0.]),(made(list(range(k+1)),B[:k]+[0.]) if k>0 else None)   # cut at a


def chained(pieces,source=None,tol=.02):
    """0.19.6 (« les côtés doivent toujours être attachés même si je fais des raccords »): the open pieces
    of a raccord that meet end to end become one polyline each (closed when the chain closes on itself);
    a point where more than two ends meet is not joined; closed shapes, curves that are not arcs (spline,
    oval), crans, texts and mèches stay as they are. ``source``: the shape the joined polylines inherit
    from (its name, profile, style), the first piece of each chain otherwise."""
    from curves import reverse
    from precision_geometry import primitives
    def contour_points(chain):return sum(len(primitives(c)) for c in chain)
    def belongs(c,src):
        return all(c.get(k)==src.get(k) for k in ('piece_id','owner_id','profile')) and c.get('style',{}).get('color')==src.get('style',{}).get('color')
    def chainable(s):
        return (s['kind'] in ('line','poly') and not path(s)[1] and not (s.get('spline') or s.get('ellipse') or s.get('components') or s.get('notches')
                or s.get('annotation') or s.get('drill') or s.get('is_notch') or s.get('stitch') or s.get('dimension_group')))
    keep=[s for s in pieces if not chainable(s)];free=[s for s in pieces if chainable(s)]
    if not free:return pieces
    ends=[e for s in free for e in (path(s)[0][0],path(s)[0][-1])]
    crowded=lambda X:sum(math.dist(X,e)<=tol for e in ends)>2
    out=[];left=list(free)
    while left:
        chain=[left.pop(0)]
        grown=True
        while grown:
            grown=False
            head,tail=path(chain[0])[0][0],path(chain[-1])[0][-1]
            if math.dist(head,tail)<=tol and len(chain)>1:break   # closed on itself
            for k,s in enumerate(left):
                a,b=path(s)[0][0],path(s)[0][-1]
                if not crowded(tail) and math.dist(tail,a)<=tol:chain.append(s)
                elif not crowded(tail) and math.dist(tail,b)<=tol:chain.append(reverse(s))
                elif not crowded(head) and math.dist(head,b)<=tol:chain.insert(0,s)
                elif not crowded(head) and math.dist(head,a)<=tol:chain.insert(0,reverse(s))
                else:continue
                left.pop(k);grown=True;break
        closing=math.dist(path(chain[0])[0][0],path(chain[-1])[0][-1])<=tol and contour_points(chain)>2
        if len(chain)==1 and not closing:out.append(chain[0]);continue   # (one piece whose ends meet: closed again)
        es=[]
        for c in chain:es+=primitives(c)
        pts=[e['a'] for e in es]+([] if closing else [es[-1]['b']]);bs=[math.tan(e['sweep']/4) for e in es]+([] if closing else [0.])
        # the shape's name and identity only to a chain made with one of its sides (not to a line raccordée to it)
        own=source if source is not None and any(belongs(c,source) for c in chain) else chain[0]
        joined=inherit(polygon(pts,own['name'],closing),own)
        joined.pop('notches',None)
        if any(bs):joined['bulges']=bs
        out.append(joined)
    return keep+out


def strap_sides(s):
    """0.19.5: the two long sides of a strap drawn as one piece (rectangle, closed or open polyline): the
    two parallel straight sides facing each other over the greatest length; None when it has none."""
    if s['kind'] not in ('rect','poly') or s.get('spline') or s.get('ellipse') or s.get('components') or s.get('annotation') or s.get('drill'):return None
    from precision_geometry import canonical,primitives
    q=canonical(s)
    if q['kind']!='poly':return None
    edges=[(e['a'],e['b']) for e in primitives(q) if not e['sweep'] and math.dist(e['a'],e['b'])>1e-4]
    best=None
    for i,A in enumerate(edges):
        L=math.dist(*A);u=((A[1][0]-A[0][0])/L,(A[1][1]-A[0][1])/L)
        for B in edges[i+1:]:
            if not parallel(*A,*B):continue
            gap=abs((B[0][0]-A[0][0])*u[1]-(B[0][1]-A[0][1])*u[0])
            ta=sorted(((X[0]-A[0][0])*u[0]+(X[1]-A[0][1])*u[1]) for X in A);tb=sorted(((X[0]-A[0][0])*u[0]+(X[1]-A[0][1])*u[1]) for X in B)
            common=min(ta[1],tb[1])-max(ta[0],tb[0])
            if gap>1e-4 and common>gap and (best is None or common>best[0]+1e-9):best=(common,A,B)   # longer than wide (not the two ends)
    return (best[1],best[2]) if best else None


def reach(shapes,M,u):
    """0.19.5: the lowest and highest positions along the unit direction u (from M) that the contours of
    ``shapes`` reach, arcs exactly (their apex, not their cut)."""
    from precision_geometry import primitives
    along=lambda X:(X[0]-M[0])*u[0]+(X[1]-M[1])*u[1];ts=[]
    for s in shapes:
        for e in primitives(s):
            ts+=[along(e['a']),along(e['b'])]
            if e['sweep']:
                for sign in (1,-1):
                    angle=math.atan2(sign*u[1],sign*u[0])
                    turn=(angle-e['start'])%(2*math.pi) if e['sweep']>0 else (e['start']-angle)%(2*math.pi)
                    if turn<=abs(e['sweep'])+1e-12:ts.append(along((e['c'][0]+e['r']*math.cos(angle),e['c'][1]+e['r']*math.sin(angle))))
    return min(ts),max(ts)


def strap_end(sides,shapes,p):
    """0.19.6: the end of a strap next to ``p`` (``sides``: its two long sides, ``shapes``: its contours):
    its tip on the middle line (the farthest point of the strap that way), the unit direction from there
    into the strap, the strap's length and width."""
    (a,b),(c,d)=sides
    L=math.dist(a,b);u=((b[0]-a[0])/L,(b[1]-a[1])/L);n=(-u[1],u[0])
    h=(c[0]-a[0])*n[0]+(c[1]-a[1])*n[1];M=(a[0]+n[0]*h/2,a[1]+n[1]*h/2)
    lo,hi=reach(shapes,M,u)
    if (p[0]-M[0])*u[0]+(p[1]-M[1])*u[1]>=(lo+hi)/2:t,w=hi,(-u[0],-u[1])
    else:t,w=lo,u
    return (M[0]+t*u[0],M[1]+t*u[1]),w,hi-lo,abs(h)


def belt_hole_centres(sides,shapes,p,count,spacing,offset,diameter):
    """0.19.5: Trous de ceinture: the centres of ``count`` holes on the middle line of a strap whose long
    sides are ``sides`` (``shapes``: its contours), from its end next to ``p``: the first ``offset`` mm
    from the tip (the farthest point of the strap that way), then every ``spacing`` mm toward the other
    end. ValueError when they do not fit in the strap."""
    tip,w,length,width=strap_end(sides,shapes,p)
    if diameter>=width-1e-9:raise ValueError('Mèche aussi large que la sangle.')
    r=diameter/2;spots=[offset+k*spacing for k in range(count)]
    if any(t<r-1e-9 or t>length-r+1e-9 for t in spots):raise ValueError('Sangle trop courte pour ces trous.')
    return [(tip[0]+t*w[0],tip[1]+t*w[1]) for t in spots]


SLOT=dict(length=20.,width=4.,distance=35.,method='machine')   # 0.19.6: Fente d'ardillon (mm)
SLOT_METHODS=(('machine','Machine (coupe intérieure)'),('trous','2 trous + 2 coupes'),('mortaise','Mortaise'))


def styled(s,profile):
    """0.19.6: ``s`` with a profile of craft_tools (its colour and role)."""
    from craft_tools import PROFILES
    s['profile']=profile;s['style']=dict(PROFILES[profile]);return s


def slot_shapes(c,w,length,width,method='machine'):
    """0.19.6: Fente d'ardillon: the slot for the buckle's tongue, its middle at c, its length along the unit
    direction w: « machine »: its oblong outline in Coupe intérieure; « trous »: a mèche of its width at each
    end and the two straight cuts between them; « mortaise »: the oblong outline of the punch of that size,
    marked like the mèches."""
    if not width>0 or not length>=width-1e-9:raise ValueError('Fente : longueur au moins égale à la largeur.')
    r=width/2;e=(length-width)/2;n=(-w[1],w[0])
    c1=(c[0]-e*w[0],c[1]-e*w[1]);c2=(c[0]+e*w[0],c[1]+e*w[1])
    side=lambda X,k:(X[0]+k*r*n[0],X[1]+k*r*n[1])
    name=f'{length:g} × {width:g}'.replace('.',',')
    if method=='trous':
        cuts=[styled(polygon([side(c1,k),side(c2,k)],'Fente '+name,False),'Coupe intérieure') for k in (1,-1)] if e>1e-9 else []
        return [drill_mark(c1,width)]+([drill_mark(c2,width)] if e>1e-9 else [])+cuts
    if e<=1e-9:
        oblong=shape('circle','',c[0]-r,c[1]-r,width,width)
    else:
        oblong=polygon([side(c1,1),side(c2,1),side(c2,-1),side(c1,-1)],'',True);oblong['bulges']=[0.,-1.,0.,-1.]
    if method=='mortaise':   # inside the piece like a mèche (its purple), for the punch
        oblong['name']='Mortaise '+name;oblong['profile']='Coupe intérieure';oblong['style']=dict(color='#c65adf',width=.15,dash=[],role='internal')
        return [oblong]
    oblong['name']='Fente '+name;return [styled(oblong,'Coupe intérieure')]


def slot_spot(sides,shapes,p,length,width,distance):
    """0.19.6: where the slot goes: its middle on the strap's middle line, ``distance`` mm from the tip of
    the end next to ``p``; (middle, direction into the strap). ValueError when it does not fit."""
    tip,w,L,W=strap_end(sides,shapes,p)
    if width>=W-1e-9:raise ValueError('Fente aussi large que la sangle.')
    if distance-length/2<-1e-9 or distance+length/2>L+1e-9:raise ValueError('La fente sort de la sangle : distance du bout trop courte ou trop longue.')
    return (tip[0]+distance*w[0],tip[1]+distance*w[1]),w


STRAP_PIECE=dict(length=1100.,width=35.,start='straight',end='strap_point',holes=True,slot=True,   # 0.19.6: Sangle entière
                 fold=0.,fold_holes=2,fold_hole=3.)   # 0.19.13: the fold round the buckle (its flap's length; 0 = none), its screw / rivet holes
STRAP_ENDS=(('straight','Droit'),('strap_round','Rond'),('strap_point','Pointu'),('strap_belt','Ceinture'))


def strap_piece(A,w,length,width,start,end,values=None):
    """0.19.6: Sangle entière: a strap ``length`` mm long (from tip to tip) and ``width`` mm wide, from A
    along the unit direction w; its ends ``start`` (at A, the buckle's side) and ``end`` (the far one):
    'straight' or a mode of STRAP made with ``values`` [mode] (as the tools). One closed polyline."""
    values=values or {};h=width/2;n=(-w[1],w[0])
    if not width>0 or not length>0:raise ValueError('Longueur et largeur positives.')
    B=(A[0]+length*w[0],A[1]+length*w[1])
    at=lambda X,k:(X[0]+k*h*n[0],X[1]+k*h*n[1])
    def end_of(P,u,Q,mode):
        if mode=='straight':return [P,Q],[0.,0.]
        return strap_link(P,u,Q,mode,values.get(mode,0))
    far,fb=end_of(at(B,-1),w,at(B,1),end)            # the far end, from one edge to the other
    near,nb=end_of(at(A,1),(-w[0],-w[1]),at(A,-1),start)
    along=lambda X:(X[0]-A[0])*w[0]+(X[1]-A[1])*w[1]
    if along(far[0])<=along(near[-1])+1e-4 or along(far[-1])<=along(near[0])+1e-4:raise ValueError('Sangle trop courte pour ces bouts.')
    pts=far+near;bs=fb[:-1]+[0.]+nb[:-1]+[0.]
    out=polygon(pts,'Sangle',True)
    if any(bs):out['bulges']=bs
    return out


def strap_shape(s,p,mode,length=0):
    """0.19.3: Bout rond / Bout pointu in one click on a piece (rectangle, polyline): the straight side
    clicked, between two parallel straight sides, becomes a half round or a point (0.19.6: inside the strap,
    its tip where the side was); the corner next to the click stays, the other one comes square onto its
    side. 0.19.6: a closed strap whose end is already shaped, clicked near it: that end made again, its tip
    where it was (strap_end_again). None when the click is not on such a side (the tool then waits for a
    second edge)."""
    done=_strap_side(s,p,mode,length)
    if done is None and s['kind'] in ('rect','poly'):done=strap_end_again(s,p,mode,length)
    return done


def strap_end_again(s,p,mode,value=0):
    """0.19.6: Bout rond / pointu / de ceinture on a strap whose end is already shaped (a round, a point, a
    belt end…: a closed piece, or an open polyline whose end is between its two long sides), clicked near
    that end: the end made again between the two long sides, its tip where the old one reached (the strap
    keeps its length). None when it does not apply (an open end: two edges wanted)."""
    if s.get('notches') or s.get('spline') or s.get('ellipse') or s.get('components') or s.get('annotation'):return None
    from precision_geometry import canonical,without_micro
    s=without_micro(s);sides=strap_sides(s)   # (the same sides as the polygon below)
    if sides is None:return None
    q=canonical(s)
    if q['kind']!='poly':return None
    n=len(q['points']);V=[(q['x']+x,q['y']+y) for x,y in q['points']];B=(list(q.get('bulges') or [])+[0.]*n)[:n]
    closed=bool(q.get('closed'));sides_n=n if closed else n-1
    def index(edge):
        return next((j for j in range(sides_n) if abs(B[j])<1e-12 and math.dist(V[j],edge[0])<1e-9 and math.dist(V[(j+1)%n],edge[1])<1e-9),None)
    ia,ib=index(sides[0]),index(sides[1])
    if ia is None or ib is None:return None
    tip,w,L,W=strap_end(sides,[s],p);u=(-w[0],-w[1])   # out of the strap at this end
    goes=lambda j:(V[(j+1)%n][0]-V[j][0])*u[0]+(V[(j+1)%n][1]-V[j][1])*u[1]
    i_in,i_out=(ia,ib) if goes(ia)>0 else (ib,ia)
    if not goes(i_in)>0 or not goes(i_out)<0:return None
    if not closed and i_out<=i_in:return None   # an open polyline whose end there is open
    # the click near that end: on its shape or along the sides within a width of it
    inward=lambda X:(X[0]-tip[0])*w[0]+(X[1]-tip[1])*w[1]
    depth=max(inward(V[(i_in+m)%n]) for m in range(1,(i_out-i_in)%n+1))
    if inward(p)>depth+W+1e-9:return None
    at=lambda X:(X[0]+((tip[0]-X[0])*u[0]+(tip[1]-X[1])*u[1])*u[0],X[1]+((tip[0]-X[0])*u[0]+(tip[1]-X[1])*u[1])*u[1])
    P,Q=at(V[i_in]),at(V[(i_out+1)%n])
    pts,bs=strap_link(P,u,Q,mode,value)
    ahead=lambda X,Y:(X[0]-Y[0])*u[0]+(X[1]-Y[1])*u[1]
    if ahead(pts[0],V[i_in])<=1e-4 or ahead(pts[-1],V[(i_out+1)%n])<=1e-4:raise ValueError('Côté trop court pour ce bout.')
    if closed:
        start=(i_out+1)%n;count=(i_in-start)%n+1   # from the end of the outgoing side to the start of the incoming one
        body=[V[(start+m)%n] for m in range(count)];bb=[B[(start+m)%n] for m in range(count-1)]
        W_=body+pts;BB=bb+[0.]+bs[:-1]+[0.]
    else:
        W_=V[:i_in+1]+pts+V[i_out+1:];BB=B[:i_in]+[0.]+bs[:-1]+[0.]+B[i_out+1:]
    out=polygon(W_,s['name'],closed)
    out.update({key:copy.deepcopy(val) for key,val in s.items() if key not in ('kind','x','y','w','h','r','points','closed','bulges','name')})
    if any(BB):out['bulges']=(BB+[0.]*len(W_))[:len(W_)]
    return out


def _strap_side(s,p,mode,length=0):
    """The straight end side clicked (strap_shape)."""
    if s['kind'] not in ('rect','poly') or s.get('notches') or s.get('spline') or s.get('ellipse') or s.get('components') or s.get('annotation'):return None
    from precision_geometry import canonical,without_micro
    q=canonical(without_micro(s))
    if q['kind']!='poly':return None
    V=[(q['x']+x,q['y']+y) for x,y in q['points']];n=len(V);closed=bool(q.get('closed'))
    B=(list(q.get('bulges') or [])+[0]*n)[:n]
    sides=n if closed else n-1
    if n<4:return None   # a side before, the end side, a side after
    k=min(range(sides),key=lambda j:distance(p,V[j],V[(j+1)%n]) if abs(B[j])<1e-12 else 1e20)
    if abs(B[k])>1e-12 or not closed and k in (0,sides-1):return None
    if closed:   # the clicked side second: V[0]..V[3] = the side before, the two corners, the side after
        V=V[k-1:]+V[:k-1];B=B[k-1:]+B[:k-1];k=1
    if abs(B[k-1])>1e-12 or abs(B[k+1])>1e-12 or not parallel(V[k-1],V[k],V[k+1],V[k+2]):return None
    L=math.dist(V[k-1],V[k]);u=((V[k][0]-V[k-1][0])/L,(V[k][1]-V[k-1][1])/L)
    if (V[k+2][0]-V[k+1][0])*u[0]+(V[k+2][1]-V[k+1][1])*u[1]>=0:return None   # the sides do not both come to this end
    def foot(X,A,C):
        w=(C[0]-A[0],C[1]-A[1]);lw=math.hypot(*w);t=((X[0]-A[0])*w[0]+(X[1]-A[1])*w[1])/lw/lw;return (A[0]+t*w[0],A[1]+t*w[1])
    if math.dist(p,V[k])<=math.dist(p,V[k+1]):
        P,Q=V[k],foot(V[k],V[k+1],V[k+2]);back=V[k+2]   # the second corner comes square onto its side
    else:
        P,Q=foot(V[k+1],V[k-1],V[k]),V[k+1];back=V[k-1]
    if math.dist(P,Q)<1e-4:return None
    # the moved corner must stay before the far end of its side
    moved=Q if P is V[k] else P
    if ((back[0]-moved[0])*u[0]+(back[1]-moved[1])*u[1])>=-1e-4:raise ValueError('Côté trop court pour ce bout.')
    pts,bs=strap_link(P,u,Q,mode,length)
    # 0.19.6: the end made inside the strap: both sides reach back past it
    if (pts[0][0]-V[k-1][0])*u[0]+(pts[0][1]-V[k-1][1])*u[1]<=1e-4 or (pts[-1][0]-V[k+2][0])*u[0]+(pts[-1][1]-V[k+2][1])*u[1]<=1e-4:
        raise ValueError('Côté trop court pour ce bout.')
    W=V[:k]+pts+V[k+2:];BB=B[:k]+bs[:-1]+B[k+1:]
    out=polygon(W,s['name'],closed)
    out.update({key:copy.deepcopy(val) for key,val in s.items() if key not in ('kind','x','y','w','h','r','points','closed','bulges','name')})
    if any(BB):out['bulges']=(BB+[0]*len(W))[:len(W)]
    return out

def corner_lines(s,t,p,q,mode,value=0):
    if s['kind']!='line' or t['kind']!='line':raise ValueError('Sélectionnez deux lignes droites ou deux côtés voisins d’une polyligne.')
    if s.get('notches') or t.get('notches'):raise ValueError('Modifiez les angles avant de poser les crans.')
    a,b=path(s)[0];c,d=path(t)[0]
    if parallel(a,b,c,d):return parallel_corner(s,t,p,q,mode,value)
    I=line_intersection(a,b,c,d)
    # Keep the endpoint on the clicked side of the intersection.
    def endpoint(x,y,click):
        vx,vy=click[0]-I[0],click[1]-I[1]
        return max((x,y),key=lambda z:(z[0]-I[0])*vx+(z[1]-I[1])*vy)
    pts,bulges=corner_points(endpoint(a,b,p),I,endpoint(c,d,q),mode,value)
    out=inherit(polygon(pts,s['name'],False),s);out['bulges']=bulges;return out

def corner_poly(s,p,q,mode,value):
    if s.get('notches') or s.get('ellipse') or s.get('spline'):raise ValueError('Choisir deux côtés droits.')
    from precision_geometry import canonical,primitives,without_micro
    s=without_micro(s)
    native=canonical(s);closed=bool(native.get('closed'))
    if s.get('components'):
        from curves import parts
        children=parts(s)
        if any(c.get('spline') or c.get('ellipse') for c in children):raise ValueError('Choisir des côtés droits ou circulaires.')
        edges=[e for child in children for e in primitives(child)]
    else:edges=primitives(native)
    def pick(point):
        return min(range(len(edges)),key=lambda k:distance(point,edges[k]['a'],edges[k]['b']) if not edges[k]['sweep'] else 1e20)
    i,j=pick(p),pick(q)
    if i==j:raise ValueError('Choisir le deuxième côté.')
    last=len(edges)-1
    if not closed and last>=2 and {i,j}=={0,last}:
        # 0.17.0: the two ends of an open polyline (after Couper) meet at their corner and the
        # polyline is closed again.
        first,end=edges[0],edges[last];I=line_intersection(end['a'],end['b'],first['a'],first['b'])
        for kept,free in ((end['a'],end['b']),(first['b'],first['a'])):
            if (I[0]-kept[0])*(free[0]-kept[0])+(I[1]-kept[1])*(free[1]-kept[1])<=EPS:raise ValueError('Côté trop court pour cet angle.')
        pts,bs=corner_points(end['a'],I,first['b'],mode,value)
        ordered=[dict(a=A,b=B,bulge=bs[k]) for k,(A,B) in enumerate(zip(pts,pts[1:]))]
        ordered+=[dict(a=edges[k]['a'],b=edges[k]['b'],bulge=math.tan(edges[k]['sweep']/4)) for k in range(1,last)]
        out=inherit(polygon([e['a'] for e in ordered],s['name'],True),s);out['bulges']=[e['bulge'] for e in ordered]
        return tidy_corner(out,I) if mode=='corner' else out
    # Neighbouring straight sides may have one existing circular raccord between.
    def gap(a,b):return (b-a)%len(edges) if closed else b-a
    if gap(i,j) not in (1,2):i,j=j,i
    n=gap(i,j)
    if n not in (1,2) or n==2 and not edges[(i+1)%len(edges)]['sweep']:raise ValueError('Choisir les deux côtés du même angle.')
    a,b=edges[i]['a'],edges[j]['b'];I=line_intersection(edges[i]['a'],edges[i]['b'],edges[j]['a'],edges[j]['b'])
    pts,bs=corner_points(a,I,b,mode,value)
    replacement=[dict(a=A,b=B,bulge=bs[k]) for k,(A,B) in enumerate(zip(pts,pts[1:]))]
    def edge(k):return dict(a=edges[k]['a'],b=edges[k]['b'],bulge=math.tan(edges[k]['sweep']/4))
    if closed:
        ordered=replacement+[edge((j+step)%len(edges)) for step in range(1,len(edges)-n)]
    else:ordered=[edge(k) for k in range(i)]+replacement+[edge(k) for k in range(j+1,len(edges))]
    if closed:
        first=edges[0]['a'];k=min(range(len(ordered)),key=lambda k:math.dist(ordered[k]['a'],first));ordered=ordered[k:]+ordered[:k]
    vertices=[e['a'] for e in ordered]+([] if closed else [ordered[-1]['b']])
    out=inherit(polygon(vertices,s['name'],closed),s);out['bulges']=[e['bulge'] for e in ordered]+([] if closed else [0])
    return tidy_corner(out,I) if mode=='corner' else out

def offset_vertex(s,p,delta):
    # 0.19.9: a spline, an oval or a joined shape is refused like an arc (it became a dense polyline with a spike).
    if s.get('notches') or s.get('annotation') or any(s.get('bulges',[])) or s.get('r',0) or s.get('spline') or s.get('ellipse') or s.get('components'):raise ValueError('Décaler sommet : choisissez un contour droit sans crans.')
    pts,closed=path(s)
    if s['kind']=='circle':raise ValueError('Un cercle ne possède pas de sommet.')
    i=min(range(len(pts)),key=lambda i:math.dist(pts[i],p));pts[i]=(pts[i][0]+delta[0],pts[i][1]+delta[1])
    if any(math.dist(a,b)<EPS for a,b in zip(pts,pts[1:])):raise ValueError('Deux sommets se confondent.')
    return inherit(polygon(pts,s['name'],closed),s)

def drill_mark(p,diameter):
    d=diameter or 2.;s=shape('circle','Pointé' if not diameter else 'Mèche '+str(diameter),p[0]-d/2,p[1]-d/2,d,d)
    s.update(drill=True,drill_point=not diameter,drill_diameter=diameter,style=dict(color='#c65adf',width=.15,dash=[],role='guide' if not diameter else 'internal'));return s

def drill_decorations(s):
    if not s.get('drill'):return []
    x,y=s['x']+s['w']/2,s['y']+s['h']/2;r=s['w']/2;ext=r*1.35/math.sqrt(2);out=[]
    for sign in (-1,1):out.append(shape('line','Repère mèche',x-ext,y-sign*ext,2*ext,sign*2*ext))
    if not s.get('drill_point'):out.append(annotation(f'{s["drill_diameter"]:g}',(x+r*1.2,y-r*2),2.5))
    for q in out:q['style']=dict(color='#c65adf',width=.15,dash=[],role='guide')
    return out


def pdf_drill_parts(s):
    """0.17.0 PDF (hand cutting): a mèche is its true circle with a small centre dot, a pointé a
    small cross; no big cross and no number."""
    x,y=s['x']+s['w']/2,s['y']+s['h']/2;ink=dict(color='#c65adf',width=.15,dash=[],role='guide')
    if s.get('drill_point'):out=[shape('line','Pointé',x-1,y,2,0),shape('line','Pointé',x,y-1,0,2)]
    else:
        dot=shape('circle','Centre mèche',x-.3,y-.3,.6,.6);dot['filled']=True;out=[copy.deepcopy(s),dot]
    for q in out:q['style']=dict(ink)
    return out


def annotation_parts(s):
    if not s.get('text_runs'):return [s]
    out=[];theta=math.radians(s.get('text_angle',0));c,sn=math.cos(theta),math.sin(theta)
    for run in s['text_runs']:
        dx,dy=run.get('dx',0),run['dy'];p=(s['x']+dx*c-dy*sn,s['y']+dx*sn+dy*c)
        q=annotation(run['text'],p,run['height']);q['text_angle']=s.get('text_angle',0)
        w=len(run['text'])*run['height']*.6;h=run['height']
        q['points']=[[0,0],[w*c,w*sn],[w*c-h*sn,w*sn+h*c],[-h*sn,h*c]]
        # 0.18.0: the material text (the only bold line without underline) is written like the piece name.
        bold=run.get('weight')=='bold' and run.get('underline',False)
        q['text_weight']='bold' if bold else 'normal';q['text_underline']=run.get('underline',False);q['style']=dict(color=run.get('color','auto'),width=.15,dash=[],role='guide');out.append(q)
    return out


def _rebuilt(s,V,B,closed):
    q=polygon(V,s['name'],closed)
    q.update({k:copy.deepcopy(v) for k,v in s.items() if k not in ('kind','x','y','w','h','r','points','closed','name','bulges')})
    if any(B):q['bulges']=list(B)
    return q


def tidy_arcs(s):
    """0.18.0: consecutive arcs of ONE circle (same centre, radius and turn) become one arc, cut in
    equal parts of at most 180°: a raccord or a cut never leaves a « mini-arc » at a quadrant.
    The curve itself is exactly the same."""
    if s.get('kind')!='poly' or s.get('components') or not any(s.get('bulges') or []):return s
    from precision_geometry import primitives
    V=[(s['x']+x,s['y']+y) for x,y in s['points']];closed=bool(s.get('closed'))
    es=primitives(s)
    if len(es)!=(len(V) if closed else len(V)-1):return s   # a zero-length side: left as it is
    def same(e,f):
        if not e['sweep'] or not f['sweep'] or e['sweep']*f['sweep']<=0:return False
        tol=1e-6*max(1.,e['r'])
        return math.dist(e['c'],f['c'])<tol and abs(e['r']-f['r'])<tol
    groups=[[es[0]]]
    for e in es[1:]:
        if same(groups[-1][-1],e):groups[-1].append(e)
        else:groups.append([e])
    # A closed shape keeps its first point (crans are measured from it): no merge across it.
    if all(len(g)==1 for g in groups):return s
    NV=[];NB=[]
    for g in groups:
        if not g[0]['sweep']:NV.append(g[0]['a']);NB.append(0.);continue
        total=sum(e['sweep'] for e in g)
        if abs(abs(total)-2*math.pi)<1e-9:return s   # a whole circle stays as drawn
        m=max(1,math.ceil(abs(total)/math.pi-1e-9));c,r,start=g[0]['c'],g[0]['r'],g[0]['start']
        for k in range(m):
            angle=start+total*k/m
            NV.append(g[0]['a'] if k==0 else (c[0]+r*math.cos(angle),c[1]+r*math.sin(angle)));NB.append(math.tan(total/m/4))
    if not closed:NV.append(es[-1]['b']);NB.append(0.)
    out=_rebuilt(s,NV,NB,closed)
    if s.get('notches'):   # 0.19.9: its crans at their point (the arc is drawn with other steps: one at the end went past it)
        from curves import marks_on
        marks_on(s,[out])
    return out


def tidy_corner(s,corner):
    """0.18.0 Angle droit: the side reaching the new corner is ONE side; a vertex next to the corner
    lying straight on that side (the end of the old side) is removed: no « mini-ligne »."""
    if s.get('kind')!='poly' or s.get('components'):return s
    V=[(s['x']+x,s['y']+y) for x,y in s['points']];n=len(V);closed=bool(s.get('closed'))
    B=(list(s.get('bulges') or [])+[0]*n)[:n]
    k=next((i for i,v in enumerate(V) if math.dist(v,corner)<1e-6),None)
    if k is None or n<3:return s
    remove=set()
    for m in ((k-1)%n,(k+1)%n) if closed else (k-1,k+1):
        if not 0<=m<n or not closed and m in (0,n-1) or m==k:continue
        a,b,c=V[(m-1)%n],V[m],V[(m+1)%n]
        if B[(m-1)%n] or B[m]:continue
        u=(b[0]-a[0],b[1]-a[1]);v=(c[0]-b[0],c[1]-b[1]);lu,lv=math.hypot(*u),math.hypot(*v)
        if lu<EPS or lv<EPS:continue
        if abs(u[0]*v[1]-u[1]*v[0])/(lu*lv)<1e-7 and u[0]*v[0]+u[1]*v[1]>0:remove.add(m)
    if not remove or n-len(remove)<(3 if closed else 2):return s
    keep=[i for i in range(n) if i not in remove]
    return _rebuilt(s,[V[i] for i in keep],[B[i] for i in keep],closed)
