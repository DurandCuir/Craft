"""0.17.0: Rotation and Échelle tools (Modifications, after Déplacer).

Selection (or the objects already selected), then the fixed point (pivot / point fixe), then the
mouse turns or scales the selection; a typed value + Entrée gives it exactly: degrees for Rotation
(0.18.0: 90 = a quarter turn clockwise, -90 anticlockwise), a percentage for Échelle (120 = +20 %)."""
import math
from types import SimpleNamespace
from transform import transform,selection_reach
from geometry import bounds

LABELS={'rotate':'Rotation','scale':'Échelle'}


def start(app,t):
    from entity_rules import linked_selection
    ids=linked_selection(app.items,app.selected_ids())
    app.finish_action();app.cancel();app.tool.set(t);app.last_command=('tool',t)
    app.xform=dict(kind=t,phase='base' if ids else 'selection',ids=sorted(ids),box=None,base=None,value=None)
    app.selected_set=set(ids);app.selected=min(ids) if ids else None
    app.highlight_tools();app.refresh();prompt(app)


# 0.18.0: the same words in the status line and beside the cursor (no « Entrée » reminder).
STEPS={'rotate':{'selection':'Sélectionner ligne','base':'Choisir centre de rotation','value':'Tourner à la souris · angle au clavier'},
       'scale':{'selection':'Sélectionner ligne','base':'Choisir point fixe','value':'Glisser à la souris · % au clavier'}}


def prompt(app):
    st=app.xform;t=st['kind']
    text=STEPS[t][st['phase']]
    app.status.set(text)


def click(app,e):
    st=app.xform
    if st['phase']=='selection':st['box']=(e.x,e.y,app.raw(e));return
    if st['phase']=='base':
        p=app.point(e);st.update(base=p,phase='value',reach=selection_reach([app.items[i] for i in st['ids']],p) or 1.)
        try:st['extent']=bounds([app.items[i] for i in st['ids'] if i<len(app.items)])   # 0.19.9: for the limits of a typed Échelle
        except (ValueError,KeyError,TypeError):pass
        if app.command_value.get():app.command_value.set('')
        prompt(app);motion(app,e);return
    # 0.19.9: a typed value is the one shown: the click applies it (the mouse's only without one)
    value=typed(app)
    if value is None:value=current(app,app.point(e))
    if value is None:raise ValueError('Éloignez le curseur du point choisi.')
    apply(app,value)


def release(app,e):
    st=app.xform;x,y,a=st['box'];st['box']=None;app._advanced_press=False;app.canvas.delete('xform')
    ids=set(st['ids'])
    from selection import select,combined,shift_held
    if math.hypot(e.x-x,e.y-y)>=4:ids=combined(ids,select(app.items,a,app.raw(e)),shift_held(e))
    else:
        i=app.pick(app.raw(e))
        if i is not None:ids=combined(ids,{i},shift_held(e))
    from entity_rules import linked_selection
    ids=set(linked_selection(app.items,ids)) if ids else set()
    st['ids']=sorted(ids);app.selected_set=set(ids);app.selected=min(ids) if ids else None;app.refresh()
    app.status.set(f'{LABELS[st["kind"]]} : {len(ids)} ligne(s) sélectionnée(s)' if ids else STEPS[st['kind']]['selection'])


def current(app,p):
    """Angle in degrees (rotation) or factor (scale) given by the pointer p."""
    st=app.xform;b=st['base'];dx,dy=p[0]-b[0],p[1]-b[1]
    if math.hypot(dx,dy)<1e-9:return None
    if st['kind']=='rotate':
        angle=math.degrees(math.atan2(dy,dx))   # 0.18.0: clockwise on screen (Craft's y axis points down)
        if app.ortho.get():angle=90*round(angle/90)
        return angle
    return math.hypot(dx,dy)/st['reach']


def typed(app):
    """0.19.9: read like Craft's other typed values (« 90/2 », « 45° », « 120 % », « 1,5 »): None when nothing is
    typed; ValueError when it cannot be used (still being typed, zero, the drawing beyond ±100 m…)."""
    text=app.command_value.get().strip()
    if not text:return None
    from command_catalog import length_expression
    st=app.xform;rotate=st['kind']=='rotate'
    try:value=length_expression(text[:-1] if text.endswith('°' if rotate else '%') else text)
    except ValueError as exc:
        if rotate and 'hors limites' in str(exc):raise ValueError('Angle hors limites.') from None   # not « ±100 m »
        raise
    if rotate:return value
    if value<=0:raise ValueError('Le pourcentage doit être positif.')
    factor=value/100;b=st.get('base');box=st.get('extent')
    if b and box and max(abs(b[k%2]+(box[k]-b[k%2])*factor) for k in range(4))>100000:raise ValueError('Échelle hors limites (±100 m).')
    if b and st.get('reach',1)*factor<.001:raise ValueError('Échelle trop petite.')
    return factor


def label(app,value):
    if app.xform['kind']=='rotate':return f'{value:.1f}'.rstrip('0').rstrip('.')+'°'
    return f'{value*100:.1f}'.rstrip('0').rstrip('.')+' %'


def motion(app,e):
    app.cursor_screen=(e.x,e.y);app._inside_plan=True;st=app.xform
    if st['phase']=='selection':
        box=st['box']
        # 0.18.0: blue / green as everywhere; 0.18.5: drawn again in place (follows the mouse at once).
        if box and math.hypot(e.x-box[0],e.y-box[1])>=4:app.draw_selection_box(box[0],box[1],e.x,e.y,'xform')
        else:app.canvas.delete('xform')
        app.draw_crosshair();return
    app.canvas.delete('xform')
    p=app.point(e)
    if st['phase']=='value':
        try:value=typed(app)
        except ValueError:value=None
        if value is None:value=current(app,p)
        if value is not None:
            st['value']=value;b=st['base']
            app.canvas.create_line(*app.to_screen(b),*app.to_screen(p),fill=app.p['accent'],tags='xform',**app.guide_style())
            draw_preview(app,value)
            x,y=app.to_screen(p);app.canvas.create_text(x+14,y-14,text=label(app,value),anchor='sw',fill=app.p['ink'],font=('Segoe UI',10),tags='xform')
    app.draw_crosshair();app.draw_input_bubble()


def draw_preview(app,value):
    st=app.xform;deg,factor=(-value,1.) if st['kind']=='rotate' else (0.,value)   # value: clockwise degrees
    for i in st['ids']:
        if i<len(app.items):
            try:app.draw_shape(transform(app.items[i],st['base'],deg,factor),'#a3a8aa',1,('xform',))
            except (ValueError,KeyError,TypeError,ZeroDivisionError):pass


def enter(app):
    st=app.xform
    if st['phase']=='selection':
        if not st['ids']:app.status.set('Sélectionnez au moins un objet.');return 'break'
        st['phase']='base';prompt(app);return 'break'
    if st['phase']=='base':app.status.set('Choisir d’abord le point.');return 'break'
    try:value=typed(app)
    except ValueError as exc:app.status.set(str(exc) if str(exc) else 'Valeur invalide.');return 'break'
    if value is None:value=st.get('value')
    if value is None:app.status.set('Bougez la souris ou tapez une valeur.');return 'break'
    # 0.19.9: a result the drawing cannot take (beyond ±100 m…) is said in the status line, not in an error window
    try:apply(app,value)
    except ValueError as exc:app.status.set(str(exc) or 'Valeur invalide.')
    return 'break'


def apply(app,value):
    st=app.xform;deg,factor=(-value,1.) if st['kind']=='rotate' else (0.,value)   # value: clockwise degrees
    if st['kind']=='scale' and factor<=0:raise ValueError('Le pourcentage doit être positif.')
    new={i:transform(app.items[i],st['base'],deg,factor) for i in st['ids'] if i<len(app.items)}
    from geometry import validate
    validate(list(new.values()))
    app.snapshot()
    for i,s in new.items():app.items[i]=s
    kind=st['kind'];text=label(app,value);ids=sorted(new)
    app.xform=None;app.canvas.delete('xform')
    if app.command_value.get():app.command_value.set('')
    if 'command_entry' in app.__dict__:app.command_entry.place_forget()
    app.complete_command(kind)   # 0.18.0: nothing stays selected after the action
    app.status.set(f'{LABELS[kind]} : {text}.');app.refresh()


def cancel(app):
    app.xform=None
    try:app.canvas.delete('xform')
    except Exception:pass
