"""0.19.13 Réseau, Étirer, Couper au point (as his AutoCAD; proposed on 05/11, « go » on 07/11).

Réseau: the selection (with what belongs to its pieces: crans, texts, stitches, zones) copied in columns and rows
(the step between two copies, in mm) or round a centre clicked (a number of copies over an angle, turned or not).
Étirer: a window drawn by two corners; the points of the lines and polylines inside it move by the displacement
given by two more clicks (or a value typed, ORTHO); an object entirely inside moves whole.
Couper au point: a click on a line, a polyline or an arc cuts it there in two (a closed outline is opened there)."""
import copy
import math
import uuid


# --- Réseau ---------------------------------------------------------------------------------------------------------

def _copies(items, ids):
    """The objects ``ids`` and what belongs to their pieces, copied with new ids (their links kept between them)."""
    from entity_rules import linked_selection, fresh_copy_ids
    group = linked_selection(items, ids)
    out = fresh_copy_ids([copy.deepcopy(items[i]) for i in group])
    groups = {}
    for s in out:
        if s.get('dimension_group'):
            s['dimension_group'] = groups.setdefault(s['dimension_group'], uuid.uuid4().hex)
    return group, out


def rectangular(items, ids, columns, rows, dx, dy):
    """The new objects of a rectangular array (the original stays at column 1, row 1)."""
    from transform import moved
    columns, rows = int(columns), int(rows)
    if columns < 1 or rows < 1 or columns * rows < 2 or columns * rows > 500:
        raise ValueError('Réseau : de 2 à 500 exemplaires (colonnes × rangées).')
    out = []
    for r in range(rows):
        for c in range(columns):
            if r == 0 and c == 0:
                continue
            group, copies = _copies(items, ids)
            out += [moved(s, c * dx, r * dy) for s in copies]
    return out


def polar(items, ids, centre, count, angle=360., turn=True):
    """The new objects of a polar array: ``count`` copies in all (the original included) over ``angle`` degrees
    (360: evenly round a whole turn), turned with the array or only moved."""
    from transform import transform, moved, affine
    from geometry import bounds
    count = int(count)
    if not 2 <= count <= 500:
        raise ValueError('Réseau polaire : de 2 à 500 exemplaires.')
    if not 0 < abs(angle) <= 360:
        raise ValueError('Angle : de 1 à 360°.')
    step = angle / count if abs(angle) >= 360 - 1e-9 else angle / (count - 1)
    out = []
    for k in range(1, count):
        group, copies = _copies(items, ids)
        a = step * k
        if turn:
            out += [transform(s, centre, a) for s in copies]
        else:
            x, y, X, Y = bounds([items[i] for i in group])
            c = ((x + X) / 2, (y + Y) / 2)
            q = affine(centre, a)(c)
            out += [moved(s, q[0] - c[0], q[1] - c[1]) for s in copies]
    return out


# --- Étirer ---------------------------------------------------------------------------------------------------------

def _inside(p, box):
    x0, y0, x1, y1 = box
    return min(x0, x1) - 1e-9 <= p[0] <= max(x0, x1) + 1e-9 and min(y0, y1) - 1e-9 <= p[1] <= max(y0, y1) + 1e-9


def stretched(s, box, dx, dy):
    """``s`` with its points inside ``box`` moved by (dx, dy); None when nothing of it is inside."""
    from geometry import bounds, path
    from transform import moved
    from cad import polygon
    try:
        x, y, X, Y = bounds([s])
    except (ValueError, KeyError, TypeError):
        return None
    if _inside((x, y), box) and _inside((X, Y), box):
        return moved(s, dx, dy)
    if s.get('annotation') or s.get('drill') or s.get('is_notch') or s.get('components'):
        ref = (s['x'] + s['w'] / 2, s['y'] + s['h'] / 2) if s.get('drill') else (s.get('x', 0), s.get('y', 0))
        return moved(s, dx, dy) if _inside(ref, box) else None
    if s.get('kind') == 'line':
        a, b = (s['x'], s['y']), (s['x'] + s['w'], s['y'] + s['h'])
        a2 = (a[0] + dx, a[1] + dy) if _inside(a, box) else a
        b2 = (b[0] + dx, b[1] + dy) if _inside(b, box) else b
        if (a2, b2) == (a, b):
            return None
        q = copy.deepcopy(s)
        q.update(x=a2[0], y=a2[1], w=b2[0] - a2[0], h=b2[1] - a2[1])
        return q
    if s.get('spline') or s.get('ellipse') or s.get('kind') == 'circle':
        return None   # (a curve only moves when it is entirely inside)
    if s.get('kind') == 'rect':
        from precision_geometry import canonical
        s = canonical(s)
    if s.get('kind') != 'poly':
        return None
    pts = [(s['x'] + px, s['y'] + py) for px, py in s['points']]
    moved_any = False
    out = []
    for p in pts:
        if _inside(p, box):
            out.append((p[0] + dx, p[1] + dy))
            moved_any = True
        else:
            out.append(p)
    if not moved_any:
        return None
    q = polygon(out, s.get('name', ''), bool(s.get('closed')))
    for key, value in s.items():
        if key not in q and key not in ('points',):
            q[key] = copy.deepcopy(value)
    if s.get('bulges'):
        q['bulges'] = list(s['bulges'])
    return q


def stretch(items, box, dx, dy):
    """[(index, new object)] of what the window ``box`` stretches."""
    out = []
    for i, s in enumerate(items):
        q = stretched(s, box, dx, dy)
        if q is not None:
            out.append((i, q))
    return out


# --- Couper au point ----------------------------------------------------------------------------------------------

def _split_bulge(q, p):
    """The two bulges of the arc ``q`` (precision_geometry.primitives) cut at ``p``."""
    a = math.atan2(p[1] - q['c'][1], p[0] - q['c'][0])
    d = (a - q['start']) % (2 * math.pi) if q['sweep'] > 0 else -((q['start'] - a) % (2 * math.pi))
    d = max(min(d, q['sweep']), 0.) if q['sweep'] > 0 else min(max(d, q['sweep']), 0.)
    return math.tan(d / 4), math.tan((q['sweep'] - d) / 4)


def cut_at(s, p):
    """``s`` cut at its point nearest ``p``: [two objects] (an open line or polyline, an arc) or [one] (a closed outline
    opened there). ValueError: what cannot be cut."""
    from cad import polygon
    from precision_geometry import canonical, primitives
    if s.get('spline') or s.get('ellipse') or s.get('kind') == 'circle' or s.get('annotation') or s.get('drill') or s.get('is_notch'):
        raise ValueError('Couper au point : une ligne, une polyligne ou un arc.')
    if s.get('kind') == 'line':
        a, b = (s['x'], s['y']), (s['x'] + s['w'], s['y'] + s['h'])
        L = math.dist(a, b)
        t = max(0., min(1., ((p[0] - a[0]) * (b[0] - a[0]) + (p[1] - a[1]) * (b[1] - a[1])) / (L * L))) if L else 0.
        m = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        if min(math.dist(m, a), math.dist(m, b)) < 1e-6:
            raise ValueError('Couper au point : pas sur un bout.')
        one, two = copy.deepcopy(s), copy.deepcopy(s)
        one.update(w=m[0] - a[0], h=m[1] - a[1])
        two.update(x=m[0], y=m[1], w=b[0] - m[0], h=b[1] - m[1])
        return [one, two]
    s = canonical(s)
    if s.get('kind') != 'poly':
        raise ValueError('Couper au point : une ligne, une polyligne ou un arc.')
    prims = primitives(s)
    best = None
    for k, q in enumerate(prims):
        if not q['sweep']:
            a, b = q['a'], q['b']
            L2 = (b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2
            t = max(0., min(1., ((p[0] - a[0]) * (b[0] - a[0]) + (p[1] - a[1]) * (b[1] - a[1])) / L2)) if L2 else 0.
            m = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        else:
            ang = math.atan2(p[1] - q['c'][1], p[0] - q['c'][0])
            m = (q['c'][0] + q['r'] * math.cos(ang), q['c'][1] + q['r'] * math.sin(ang))
            d = (ang - q['start']) % (2 * math.pi) if q['sweep'] > 0 else (q['start'] - ang) % (2 * math.pi)
            if d > abs(q['sweep']):
                m = q['a'] if min(d - abs(q['sweep']), 2 * math.pi - d) == 2 * math.pi - d else q['b']
        dist = math.dist(m, p)
        if best is None or dist < best[0]:
            best = (dist, k, m)
    if best is None:
        raise ValueError('Couper au point : tracé vide.')
    _, k, m = best
    pts = [(s['x'] + x, s['y'] + y) for x, y in s['points']]
    bulges = list(s.get('bulges') or [0.] * len(prims))
    q = prims[k]
    b1, b2 = _split_bulge(q, m) if q['sweep'] else (0., 0.)
    keep = {key: copy.deepcopy(v) for key, v in s.items() if key not in ('points', 'bulges', 'closed', 'x', 'y', 'w', 'h', 'kind', 'notches', 'piece_id', 'piece_info')}
    at_vertex = math.dist(m, q['a']) < 1e-6 or math.dist(m, q['b']) < 1e-6
    if s.get('closed'):
        # opened at m: from m round the whole outline back to m
        n = len(pts)
        order = [(k + 1 + j) % n for j in range(n)]
        if math.dist(m, q['b']) < 1e-6:   # on a corner: the outline starts there
            seq = [pts[i] for i in order]
            bs = [bulges[(k + 1 + j) % n] for j in range(n)]
            seq.append(seq[0])
        elif math.dist(m, q['a']) < 1e-6:
            order = [(k + j) % n for j in range(n)]
            seq = [pts[i] for i in order] + [pts[k]]
            bs = [bulges[(k + j) % n] for j in range(n)]
        else:
            seq = [m] + [pts[i] for i in order] + [m]
            bs = [b2] + [bulges[(k + 1 + j) % n] for j in range(n - 1)] + [b1]
        out = polygon(seq, s.get('name', ''), False)
        out.update(keep)
        if any(bs):
            out['bulges'] = bs[:len(seq) - 1]
        return [out]
    if at_vertex and (k == 0 and math.dist(m, q['a']) < 1e-6 or k == len(prims) - 1 and math.dist(m, q['b']) < 1e-6):
        raise ValueError('Couper au point : pas sur un bout.')
    first = pts[:k + 1] + ([m] if math.dist(m, pts[k]) > 1e-6 else [])
    second = ([m] if math.dist(m, pts[k + 1]) > 1e-6 else []) + pts[k + 1:]
    b_first = bulges[:k] + ([b1] if math.dist(m, pts[k]) > 1e-6 else [])
    b_second = ([b2] if math.dist(m, pts[k + 1]) > 1e-6 else []) + bulges[k + 1:]
    if len(first) < 2 or len(second) < 2:
        raise ValueError('Couper au point : pas sur un bout.')
    one, two = polygon(first, s.get('name', ''), False), polygon(second, s.get('name', ''), False)
    for piece, bs in ((one, b_first), (two, b_second)):
        piece.update(keep)
        if any(bs):
            piece['bulges'] = bs
    return [one, two]


# --- the tools ------------------------------------------------------------------------------------------------------

def array_start(app):
    """Réseau: the selection, then the window."""
    ids = sorted(app.selected_set or ({app.selected} if app.selected is not None else set()))
    if not ids:
        app.status.set('Réseau : sélectionner d’abord ce qu’il faut copier.')
        app.set_tool('select')
        return None
    return array_dialog(app, ids)


def array_dialog(app, ids):
    import strap_ui
    st = dict(dict(kind='rect', columns=3, rows=1, dx=20., dy=20., count=6, angle=360., turn=True), **(app.prefs.get('array') or {}))
    kinds = [('rect', 'Rectangulaire'), ('polar', 'Polaire (centre au clic)')]

    def read(v):
        out = dict(kind=v['kind'])
        try:
            out['columns'] = int(v['columns'])
            out['rows'] = int(v['rows'])
            out['count'] = int(v['count'])
        except ValueError:
            raise ValueError('Colonnes, rangées, nombre : des nombres entiers.')
        out['dx'] = strap_ui._number(v['dx'])
        out['dy'] = strap_ui._number(v['dy'])
        out['angle'] = strap_ui._number(v['angle'])
        out['turn'] = bool(v['turn'])
        return out

    def done(chosen):
        if chosen['kind'] == 'rect':
            try:
                new = rectangular(app.items, ids, chosen['columns'], chosen['rows'], chosen['dx'], chosen['dy'])
            except ValueError as exc:
                app.status.set(str(exc))
                return
            _add(app, new, f'Réseau : {chosen["columns"]} × {chosen["rows"]}.')
        else:
            app.tool.set('array_centre')
            app.array_state = dict(ids=ids, settings=chosen)
            app.highlight_tools()
            app.status.set('Réseau polaire : cliquer le centre.')
    return strap_ui.form(app, 'Réseau', [('choice', 'Type', 'kind', kinds, st['kind']),
                                         ('entry', 'Colonnes', 'columns', str(st['columns'])), ('entry', 'Rangées', 'rows', str(st['rows'])),
                                         ('entry', 'Pas entre colonnes (mm)', 'dx', strap_ui.mm(st['dx'])),
                                         ('entry', 'Pas entre rangées (mm)', 'dy', strap_ui.mm(st['dy'])),
                                         ('entry', 'Polaire : nombre d’exemplaires', 'count', str(st['count'])),
                                         ('entry', 'Polaire : angle total (°)', 'angle', strap_ui.mm(st['angle'])),
                                         ('check', 'Polaire : tourner les copies', 'turn', st['turn'])], read, 'array', done)


def _add(app, new, message):
    if not new:
        return
    app.snapshot()
    start = len(app.items)
    app.items.extend(new)
    app.selected_set = set(range(start, len(app.items)))
    app.selected = start
    app.tool.set('select')
    app.highlight_tools()
    app.refresh()
    app.status.set(message)


def array_centre_click(app, e):
    st = app.__dict__.get('array_state')
    if not st:
        return None
    c = app.point(e)
    s = st['settings']
    try:
        new = polar(app.items, st['ids'], c, s['count'], s['angle'], s['turn'])
    except ValueError as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    app.array_state = None
    _add(app, new, f'Réseau polaire : {s["count"]} exemplaires.')
    return 'break'


def stretch_start(app):
    app.finish_action()
    app.cancel()
    app.tool.set('stretch')
    app.last_command = ('tool', 'stretch')
    app.stretch_state = dict(corners=[], base=None)
    app.highlight_tools()
    app.status.set('Étirer : premier coin de la fenêtre (ce qui est dedans bouge).')


def stretch_click(app, e):
    st = app.__dict__.get('stretch_state')
    if st is None:
        return None
    p = app.point(e)
    if len(st['corners']) < 2:
        st['corners'].append(p)
        app.status.set('Étirer : coin opposé.' if len(st['corners']) == 1 else 'Étirer : point de base.')
        return 'break'
    if st['base'] is None:
        st['base'] = p
        app.status.set('Étirer : point d’arrivée (ou une distance tapée + Entrée).')
        return 'break'
    return stretch_finish(app, p[0] - st['base'][0], p[1] - st['base'][1])


def stretch_finish(app, dx, dy):
    st = app.stretch_state
    box = (*st['corners'][0], *st['corners'][1])
    changes = stretch(app.items, box, dx, dy)
    if not changes:
        app.status.set('Étirer : rien dans la fenêtre.')
    else:
        app.snapshot()
        for i, q in changes:
            app.items[i] = q
        app.status.set(f'Étirer : {len(changes)} objet{"s" if len(changes) > 1 else ""}.')
    app.stretch_state = dict(corners=[], base=None)
    app.canvas.delete('stretch_preview')
    app.refresh()
    return 'break'


def stretch_preview(app, e):
    st = app.__dict__.get('stretch_state')
    c = app.canvas
    c.delete('stretch_preview')
    if not st or not st['corners']:
        return
    p = app.point(e)
    a = st['corners'][0]
    b = st['corners'][1] if len(st['corners']) > 1 else p
    (x0, y0), (x1, y1) = app.to_screen(a), app.to_screen(b)
    c.create_rectangle(x0, y0, x1, y1, outline=app.p.get('accent', '#61c9ee'), dash=(6, 4), width=1.5, tags=('stretch_preview',))
    if st['base'] is not None:
        dx, dy = p[0] - st['base'][0], p[1] - st['base'][1]
        box = (*st['corners'][0], *st['corners'][1])
        for i, q in stretch(app.items, box, dx, dy):
            app.draw_shape(q, app.p['accent'], 1, ('stretch_preview',))


def break_start(app):
    app.finish_action()
    app.cancel()
    app.tool.set('break_point')
    app.last_command = ('tool', 'break_point')
    app.highlight_tools()
    app.status.set('Couper au point : cliquer sur la ligne, la polyligne ou l’arc, là où la couper.')


def break_click(app, e):
    raw = app.raw(e)
    i = app.pick(raw)
    if i is None:
        app.invalid_at(e, 'Cliquer sur une ligne, une polyligne ou un arc.')
        return 'break'
    p = app.point(e)
    try:
        parts = cut_at(app.items[i], p)
    except (ValueError, ZeroDivisionError) as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    app.snapshot()
    app.items[i:i + 1] = parts
    app.status.set('Coupé en deux.' if len(parts) == 2 else 'Contour ouvert à ce point.')
    app.refresh()
    return 'break'


# --- Lisser --------------------------------------------------------------------------------------------------------

def smoothed(s):
    """0.19.13 « Lisser » (proposed on 03/11: « elle passe d'un coup à la spline lisse de la 0.19.7, ses points
    gardés »): the spline made again through its points (its fit points, else the ends of its pieces) with a
    continuous curvature; its start / end tangents and everything else it carries kept."""
    from curves import spline, cubics
    sp = s.get('spline') or {}
    if not sp:
        raise ValueError('pas une spline.')
    closed = bool(s.get('closed'))
    if sp.get('fit'):
        pts = [(s['x'] + x, s['y'] + y) for x, y in sp['fit']]
    else:
        cs = cubics(s)
        pts = [tuple(c[0]) for c in cs] + ([tuple(cs[-1][3])] if cs and not closed else [])
    if closed and len(pts) > 2 and math.dist(pts[0], pts[-1]) < 1e-6:
        pts = pts[:-1]
    clean = [p for k, p in enumerate(pts) if k == 0 or math.dist(p, pts[k - 1]) > 1e-6]
    q = spline(clean, closed, s.get('name', 'Spline'), tangents=None if closed else sp.get('tangents'))
    for key, value in s.items():
        if key not in q and key not in ('points', 'bulges', 'spline', 'closed', 'kind', 'x', 'y', 'w', 'h'):
            q[key] = copy.deepcopy(value)
    return q
