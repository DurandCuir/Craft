"""0.19.5 « Trous de ceinture » (with Pointés et mèches): a row of mèches on the middle line of a strap,
from its end: number, spacing, distance of the first one from the tip, mèche (remembered). A click near
the end of a strap drawn as one piece (rectangle, polyline, its end straight, round or pointed); two
clicks (its two edges, near the end) when it is drawn with lines. The holes show under the mouse before
the click; the tool stays for the next strap (Échap or a click on its icon ends it)."""
import math
import tkinter as tk
from tkinter import messagebox

DEFAULTS = dict(count=5, spacing=25., offset=30., diameter=4.)


def settings(app):
    saved = app.prefs.get('belt_holes') or {}
    out = dict(DEFAULTS)
    out.update({k: v for k, v in saved.items() if k in DEFAULTS})
    return out


def prompt(app, more=''):
    st = settings(app)
    app.status.set(f'{st["count"]} trous · écart {st["spacing"]:g} mm · le 1er à {st["offset"]:g} mm du bout · mèche {st["diameter"]:g} mm · '
                   'clic droit pour régler · cliquer le bout de la sangle.' + more)


def resume(app, more=''):
    """The tool ready for a strap (after the window, an Annuler, a row of holes)."""
    app.tool.set('belt_holes')
    app.last_command = ('tool', 'belt_holes')
    app.belt_state = dict(first=None)
    app.canvas.delete('belt_preview')
    app.highlight_tools()
    prompt(app, more)


def start(app):
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    resume(app)
    app.refresh()
    dialog(app)


def cancel(app):
    app.belt_state = None
    try:
        app.canvas.delete('belt_preview')
    except (AttributeError, tk.TclError):
        pass


def dialog(app):
    st = settings(app)
    win = app.dialog('Trous de ceinture')
    panel = app.p['panel']
    form = tk.Frame(win, bg=panel)
    form.pack(fill='x', padx=16, pady=(14, 4))
    values = [('Nombre de trous', 'count', f'{st["count"]:d}'), ('Écart entre les trous (mm)', 'spacing', f'{st["spacing"]:g}'),
              ('Distance du bout au 1er trou (mm)', 'offset', f'{st["offset"]:g}'), ('Mèche (mm)', 'diameter', f'{st["diameter"]:g}')]
    variables = {}
    fields = []
    for r, (label, key, text) in enumerate(values):
        app.label(form, label).grid(row=r, column=0, sticky='w', pady=3)
        variables[key] = tk.StringVar(value=text.replace('.', ','))
        field = app.entry(form, variables[key], 8)
        field.grid(row=r, column=1, sticky='w', padx=8, pady=3)
        fields.append(field)

    def read():
        number = lambda key: float(variables[key].get().strip().replace(',', '.'))
        try:
            count = int(variables['count'].get().strip())
            spacing, offset, diameter = number('spacing'), number('offset'), number('diameter')
            if not all(math.isfinite(v) for v in (spacing, offset, diameter)):
                raise ValueError
        except (ValueError, OverflowError):
            raise ValueError('Nombre entier de trous ; écart, distance et mèche en mm.')
        if not 1 <= count <= 50:
            raise ValueError('De 1 à 50 trous.')
        if count > 1 and not spacing > 0:
            raise ValueError('L’écart doit être positif.')
        if not 0 <= offset <= 100000 or not 0 <= spacing <= 100000:
            raise ValueError('Écart et distance du bout : positifs.')
        if not 0 < diameter <= 30:
            raise ValueError('Mèche : de 0,1 à 30 mm.')
        return dict(count=count, spacing=spacing, offset=offset, diameter=diameter)

    def valid(e=None):
        try:
            chosen = read()
        except ValueError as exc:
            messagebox.showerror('Trous de ceinture', str(exc), parent=win)
            return 'break'
        win.destroy()
        app.prefs['belt_holes'] = chosen
        try:
            app.persist_preferences()
        except OSError:
            pass
        if app.tool.get() == 'belt_holes':
            prompt(app)
        app.canvas.focus_set()
        return 'break'
    for field in fields:
        field.bind('<Return>', valid)
        field.bind('<KP_Enter>', valid)
    win.bind('<Return>', valid)
    win.bind('<KP_Enter>', valid)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(8, 14))
    app.button(foot, 'Valider', valid).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', lambda: (win.destroy(), app.canvas.focus_set()))
    fields[0].focus_set()
    fields[0].select_range(0, 'end')
    return win


def centres(app, i, p):
    """The centres of the holes for a click ``p`` on item ``i`` (the first edge already chosen counts);
    None when a second edge is needed. ValueError when the click is not on a strap."""
    from editing import strap_sides, belt_hole_centres, side_of, parallel
    st = settings(app)
    first = (app.__dict__.get('belt_state') or {}).get('first')
    s = app.items[i]
    if first is None:
        sides = strap_sides(s)
        if sides is not None:
            return belt_hole_centres(sides, [s], p, st['count'], st['spacing'], st['offset'], st['diameter'])
        if side_of(s, p) is not None:
            return None
        raise ValueError('Cliquer le bout d’une sangle (deux bords parallèles).')
    j, q = first
    if i == j:
        raise ValueError('Choisir l’autre bord de la sangle.')
    A, B = side_of(app.items[j], q), side_of(s, p)
    if A is None or B is None or not parallel(*A[0], *B[0]):
        raise ValueError('Choisir l’autre bord, parallèle au premier.')
    from advanced_edit import corner_links
    shapes = [app.items[j], s]
    shapes += [app.items[k] for k in corner_links(app.items, {i, j}, app.items[j], s, q, p)]
    return belt_hole_centres((A[0], B[0]), shapes, q, st['count'], st['spacing'], st['offset'], st['diameter'])


def strap_at(app, p):
    """The item clicked: a contour within reach, else the smallest closed contour around ``p`` (a click
    inside the strap, near its end)."""
    i = app.pick(p)
    if i is not None and not app.items[i].get('stitch'):   # (a Piqûre inside the strap is not its edge)
        return i
    from geometry import bounds, path
    from precision_geometry import inside
    from entity_rules import geometry_entity
    best = None
    for k, s in enumerate(app.items):
        if not geometry_entity(s) or s.get('stitch'):
            continue
        x, y, X, Y = bounds([s])
        if not (x <= p[0] <= X and y <= p[1] <= Y) or not path(s)[1] or not inside(s, p):
            continue
        area = (X - x) * (Y - y)
        if best is None or area < best[0]:
            best = (area, k)
    return None if best is None else best[1]


def holes(app, points):
    """The mèches for ``points``, without those already there (same centre, same mèche)."""
    from editing import drill_mark
    d = settings(app)['diameter']
    there = [((s['x'] + s['w'] / 2, s['y'] + s['h'] / 2), s.get('drill_diameter')) for s in app.items if s.get('drill')]
    return [drill_mark(c, d) for c in points if not any(math.dist(c, x) < .01 and abs((k or 0) - d) < 1e-9 for x, k in there)]


def click(app, e):
    st = app.__dict__.get('belt_state')
    if st is None:
        return None
    p = app.raw(e)
    i = strap_at(app, p)
    if i is None:
        app.invalid_at(e, 'Cliquer le bout de la sangle.')
        return 'break'
    try:
        found = centres(app, i, p)
    except ValueError as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    if found is None:
        st['first'] = (i, p)
        app.status.set('Choisir l’autre bord de la sangle.')
        return 'break'
    new = holes(app, found)
    if not new:
        app.status.set('Ces trous sont déjà là.')
        return 'break'
    app.snapshot()
    app.items.extend(new)
    app.selected = None
    app.selected_set = set()
    resume(app, ' Échap pour finir.')
    app.refresh()
    return 'break'


def preview(app, e):
    """The holes under the mouse before the click."""
    app.canvas.delete('belt_preview')
    if app.__dict__.get('belt_state') is None:
        return
    p = app.raw(e)
    i = strap_at(app, p)
    if i is None:
        return
    try:
        found = centres(app, i, p)
    except (ValueError, IndexError, ZeroDivisionError):
        return
    if not found:
        return
    from editing import drill_mark
    d = settings(app)['diameter']
    try:
        for c in found:
            app.draw_shape(drill_mark(c, d), app.p['accent'], 1, ('belt_preview',))
    except (tk.TclError, ValueError, OverflowError):
        app.canvas.delete('belt_preview')
