"""0.18.0 Piqûre: a line stitched by machine (a dashed line) or by hand (holes every « pas » mm).

A stitch is an ordinary line or polyline marked ``stitch=dict(kind='machine'|'hand', pitch=mm)``
with the « Couture » style (role ``seam``: DXF layer CRAFT_SEAM). Made from a piece's contour it
belongs to that piece (``owner_id``) and follows it. By hand, the holes are spread evenly between
the corners, with a hole on each corner and at both ends, at the pitch nearest the one chosen
(a pricking iron of 3,85 mm gives holes 3,85 mm apart on a side of 3,85 × n mm). They are drawn,
printed (dots) and exported to DXF (circles of 1 mm on CRAFT_SEAM)."""
import copy
import math
from geometry import path

COLOR='#5cc98a'
# By hand the line is darker, so that its holes (in COLOR) stand out.
STYLES={'machine':dict(color=COLOR,width=.2,dash=[3,2],role='seam'),
        'hand':dict(color='#357a55',width=.12,dash=[],role='seam')}
HOLE=1.            # mm: diameter of a hand-stitch hole as drawn, printed and exported
CORNER=30.         # degrees: a sharper turn of the line is a corner, where a hole is placed
PITCHES=('2,7','3','3,38','3,85','4','5','6')
# 0.19.13 (07/11 « demande nb de points par cm pas le pas, on calcule tjrs au cm »): every window asks the points per
# cm; a stitch keeps its pitch in mm (10 / points per cm). « En général on pique 3 points par cm, et la distance de
# piqûre du bord sur les produits est de 2.5 ».
POINTS=('2','2,5','2,6','3','3,5','4','5')
POINTS_PER_CM=3.
DISTANCE=2.5


def points_per_cm(pitch):
    """3.333… mm → 3 ; 3.85 mm → 2.6 (rounded to the hundredth, as shown)."""
    return round(10/float(pitch),2)


def pitch_of(points):
    """The pitch in mm of ``points`` per cm (0,5 to 20 points: 0.5 to 20 mm)."""
    points=float(points)
    if not .5<=points<=20:raise ValueError('Points par cm : de 0,5 à 20.')
    return 10/points
LABELS={'machine':'Piqûre machine','hand':'Piqûre main'}
DROPPED=('piece_id','piece_info','part_names','material','model','notches','is_notch','owner_id','preparation',
         'drill','drill_point','drill_diameter','filled','annotation','profile','dimension_group')


def kind(s):
    """'machine', 'hand' or None."""
    st=s.get('stitch') if isinstance(s,dict) else None
    return st.get('kind') if isinstance(st,dict) and st.get('kind') in STYLES else None


def stitched(s,how,pitch,owner=None):
    """A copy of the line ``s`` made a stitch (it loses what made it a piece: id, crans, labels)."""
    if how not in STYLES:raise ValueError('Piqûre : machine ou main.')
    pitch=float(pitch)
    if how=='hand' and not .5<=pitch<=30:raise ValueError('Points par cm : de 0,5 à 20.')
    q=copy.deepcopy(s)
    for key in DROPPED:q.pop(key,None)
    q.update(profile='Couture',style=dict(STYLES[how]),stitch=dict(kind=how,pitch=pitch),name=LABELS[how])
    if owner:q['owner_id']=owner
    return q


def _runs(points,closed):
    """The line cut at its corners: lists of points, each run from one corner (or end) to the next."""
    pts=[p for k,p in enumerate(points) if k==0 or math.dist(p,points[k-1])>1e-9]
    if closed and len(pts)>2 and math.dist(pts[0],pts[-1])<=1e-9:pts=pts[:-1]
    if len(pts)<2:return []
    def turn(a,b,c):
        u=(b[0]-a[0],b[1]-a[1]);v=(c[0]-b[0],c[1]-b[1]);nu,nv=math.hypot(*u),math.hypot(*v)
        if nu<1e-12 or nv<1e-12:return 0.
        cos=max(-1.,min(1.,(u[0]*v[0]+u[1]*v[1])/(nu*nv)));return math.degrees(math.acos(cos))
    n=len(pts)
    if closed:
        corners=[k for k in range(n) if turn(pts[k-1],pts[k],pts[(k+1)%n])>CORNER]
        if not corners:return [pts+pts[:1]]
        runs=[]
        for a,b in zip(corners,corners[1:]+corners[:1]):
            run=[pts[a]];k=a
            while True:
                k=(k+1)%n;run.append(pts[k])
                if k==b:break
            runs.append(run)
        return runs
    corners=[k for k in range(1,n-1) if turn(pts[k-1],pts[k],pts[k+1])>CORNER]
    cuts=[0]+corners+[n-1]
    return [pts[a:b+1] for a,b in zip(cuts,cuts[1:])]


def _along(run,distance):
    travel=0.
    for a,b in zip(run,run[1:]):
        length=math.dist(a,b)
        if travel+length>=distance-1e-12 and length>1e-12:
            t=max(0.,min(1.,(distance-travel)/length));return (a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t)
        travel+=length
    return run[-1]


def holes(s):
    """Centres of the holes of a hand stitch (none for a machine stitch)."""
    if kind(s)!='hand':return []
    pitch=float(s['stitch'].get('pitch') or 0)
    if pitch<=0:return []
    try:points,closed=path(s)
    except (ValueError,KeyError,TypeError):return []
    out=[]
    for run in _runs(points,closed):
        length=sum(math.dist(a,b) for a,b in zip(run,run[1:]))
        if length<1e-9:continue
        n=max(1,round(length/pitch))
        for k in range(n+1):
            p=_along(run,length*k/n)
            if not out or math.dist(out[-1],p)>1e-6:out.append(p)
    if closed and len(out)>1 and math.dist(out[0],out[-1])<=1e-6:out.pop()
    return out


def real_pitch(s):
    """The pitch the holes really have on the longest side (for the message after placing)."""
    if kind(s)!='hand':return None
    try:points,closed=path(s)
    except (ValueError,KeyError,TypeError):return None
    best=None
    for run in _runs(points,closed):
        length=sum(math.dist(a,b) for a,b in zip(run,run[1:]))
        if length>1e-9 and (best is None or length>best[0]):best=(length,length/max(1,round(length/float(s['stitch']['pitch']))))
    return best[1] if best else None


def hole_shapes(s,filled=False):
    """The holes as small circles (style of the stitch): drawn, printed and exported."""
    from cad import shape
    out=[]
    for x,y in holes(s):
        q=shape('circle','Trou de piqûre',x-HOLE/2,y-HOLE/2,HOLE,HOLE);q['style']=dict(color=COLOR,width=.1,dash=[],role='seam');q['stitch_hole']=True
        if filled:q['filled']=True
        out.append(q)
    return out
