"""Craft precision workflow: two-stage snaps, live moves and contour references."""
import tkinter as tk
from tkinter import simpledialog,ttk
import copy,math,unicodedata
from pathlib import Path
from types import SimpleNamespace
from geometry import path,distance,pointer_frame
from cad import shape,snap_point,object_anchors,polygon
from craft_tools import locate,at_distance,style
from precision_geometry import ellipse,is_contour,routes,contour_location,shifted,inside
from refined_icons import draw
from ui_widgets import contrast_color,zoom_tag
import modern_style

OVALS={'ellipse_center':'Ovale (centre)','ellipse_box':'Ovale (rectangle)','ellipse_axis':'Ovale (grand axe)'}
CUSTOM=set(OVALS)|{'rect_path'}

def normalized(s):return ''.join(c for c in unicodedata.normalize('NFD',s.casefold()) if not unicodedata.combining(c))

def enhance_precision(Base):
 class Precision(Base):
    def __init__(self):
        self.move_state=None;self.offset_state=None;self.route_state=None;self.rect_reference=None;self.oval_points=[];self.anchor_candidate=None;self.search_frame=None;self.search_results=[];self.command_history=[];self._route_marks=[]
        super().__init__();self.snap.set(self.prefs.get('snap_enabled',True));self.update_toggle_labels()
    def configure_toolgroups(self):
        super().configure_toolgroups()
        self.toolgroups['Géométrie'].append(('ellipse',[(k,v,None) for k,v in OVALS.items()]))
    def build(self):
        super().build()
        self.unit_label.pack_forget()
        for w in self.footer.winfo_children():
            if isinstance(w,tk.Button) and w.cget('text')=='▾':w.destroy()
        self.bottom_buttons['snap'].destroy()
        self.snap_group=tk.Frame(self.footer,bg=self.p['panel']);self.snap_group.pack(side='right',padx=3)
        c=self.small_icon(self.snap_group,'snap',self.toggle_snap,'Ancrages : activer / désactiver · F3');c.pack(side='left');self.bottom_buttons['snap']=c
        self.snap_drop=modern_style.make_button(self.snap_group,text='▾',command=self.snap_menu,kind='ghost',padx=3,pady=2,cursor='arrow');self.snap_drop.pack(side='left',fill='y')
        self.icon(self.footer,'recenter',self.fit_workspace,'Recentrer la vue',side='right')
        for w in self.root_frame.winfo_children():
            for child in w.winfo_children():
                if isinstance(child,tk.Button) and child.cget('text')=='Objet':
                    child.destroy();w.configure(bg=self.field_background(),highlightthickness=1,highlightbackground=self.field_border())
                    self.object_parent=tk.Label(w,text='',bg=self.field_background(),fg=self.p['ui_ink'],font=('Segoe UI',8));self.object_parent.pack(side='left',padx=(9,7))
                    tab=tk.Frame(w,bg=self.p['panel'],highlightthickness=1,highlightbackground=self.field_border());tab.pack(side='left',pady=(2,0))
                    tk.Label(tab,text='Objet',bg=self.p['panel'],fg=self.p['ui_ink'],font=('Segoe UI',10),padx=12,pady=3).pack()
        t=modern_style.tokens_for(self.p)   # 0.19.0: the suggestions list in the colours of the menus
        self.search_frame=tk.Frame(self.canvas,bg=t['menu'],highlightthickness=1,highlightbackground=t['field_border']);self.search_frame._modern_keep=True
        self.search_value=tk.StringVar();self.search_entry=tk.Entry(self.search_frame,textvariable=self.search_value,bg=t['field'],fg=t['text'],insertbackground=t['text'],font=modern_style.font(10),relief='flat',width=42)
        self.search_entry.pack(fill='x',padx=3,pady=3)
        self.search_list=tk.Listbox(self.search_frame,height=5,width=43,bg=t['menu'],fg=t['text'],selectbackground=t['accent_soft'],selectforeground=t['text'],font=modern_style.font(10),relief='flat',bd=0,highlightthickness=0,activestyle='none',exportselection=False)
        self.search_list.pack(fill='both');self.search_value.trace_add('write',lambda *a:self.search_update())
        for w in (self.search_entry,self.search_list):
            w.bind('<Return>',lambda e:self.search_accept());w.bind('<Escape>',lambda e:self.search_close());w.bind('<Down>',lambda e:self.search_step(1));w.bind('<Up>',lambda e:self.search_step(-1))
        self.search_hint=tk.StringVar(value='Commande ou alias · Tab : compléter')
        tk.Label(self.search_frame,textvariable=self.search_hint,bg=t['menu'],fg=t['muted'],wraplength=320,justify='left',font=modern_style.font(9)).pack(fill='x',padx=8,pady=6)
        self.search_entry.bind('<Tab>',lambda e:self.search_complete())
        self.bind('<Control-k>',lambda e:self.open_commands());self.bind('<Control-K>',lambda e:self.open_commands())
        self.search_list.bind('<ButtonRelease-1>',lambda e:self.search_accept());self.update_toggle_labels();self.refresh_object_parent()
        menu=self.nametowidget(self.cget('menu'))
        for i in range(menu.index('end')+1):
            if menu.type(i)=='cascade' and menu.entrycget(i,'label')=='Aide':
                helpmenu=self.nametowidget(menu.entrycget(i,'menu'));helpmenu.add_command(label='Commandes et raccourcis · Ctrl+K…',command=self.command_guide)
                # 0.16.14: the version line stays the last entry of Aide, under its separator.
                for j in range(helpmenu.index('end')+1):
                    if helpmenu.type(j)=='command' and helpmenu.entrycget(j,'label').startswith('Version '):
                        label=helpmenu.entrycget(j,'label');helpmenu.delete(j)
                        if j>0 and helpmenu.type(j-1)=='separator':helpmenu.delete(j-1)
                        helpmenu.add_separator();helpmenu.add_command(label=label,state='disabled');break
    def refresh_object_parent(self):
        w=self.__dict__.get('object_parent')
        if w and w.winfo_exists():w.pack_forget()
    def refresh(self):
        super().refresh();self.refresh_object_parent()
        ids=self.selected_ids();dash=style(self.items[ids[0]])['dash'] if ids else []
        self.line_type=next((name for name,pattern in self.line_types.items() if pattern==dash),'Plein')
        self.paint_line_picker();self.paint_color_picker()
    def rebuild_tabs(self):
        if not hasattr(self,'tabbar') or self._tabs_busy:return
        self.rebuild_sections()
        if self.documents:self.documents[self.current_doc]=self.capture_doc()
        dirty=__import__('doc_files').document_dirty
        signature=(self.current_doc,self.p['panel'],self.field_background(),self.p['ui_ink'],tuple((d['filename'],d.get('display_name'),dirty(d)) for d in self.documents))
        if signature==getattr(self,'_tab_signature',None) and self.tabbar.winfo_children():return
        self._tab_signature=signature;self._tabs_busy=True
        try:
            for w in self.tabbar.winfo_children():w.destroy()
            for i,doc in enumerate(self.documents):
                title=Path(doc['filename']).stem if doc['filename'] else doc.get('display_name') or 'Nouveau'
                if dirty(doc):title+=' *'
                # 0.19.0: rounded tabs: the open document raised, the others in the panel, lit under the mouse.
                t=modern_style.tokens_for(self.p);chosen=i==self.current_doc;fill=t['raised'] if chosen else self.p['panel']
                f=modern_style.make_round(self.tabbar,fill=fill,edge=t['outline']);f.pack(side='left',padx=(4 if i==0 else 0,3),pady=(3,1));f.tab_chosen=chosen   # 0.19.2: every tab outlined
                b=modern_style.make_button(f,text=title,command=lambda j=i:self.switch_doc(j),kind='flat',fg=t['text'] if chosen else t['muted'],padx=10,pady=3,font=modern_style.font(10),cursor='arrow');b.pack(side='left',padx=(2,0),pady=2)   # 0.19.2: inside the outline
                close=tk.Canvas(f,width=18,height=20,bg=fill,highlightthickness=0,cursor='arrow');close.pack(side='left',padx=(0,4),pady=2)
                for sign in (-1,1):close.create_line(6.5,10-sign*3,11.5,10+sign*3,fill=t['text'] if chosen else t['muted'],width=1.3)
                close.bind('<Button-1>',lambda e,j=i:self.close_doc(j))
                self.tab_hover(f,(b,close))
            modern_style.make_button(self.tabbar,text='+',command=self.new_doc,kind='ghost',padx=6,pady=2,cursor='arrow').pack(side='left',pady=(3,1))
        finally:
            self._tabs_busy=False
            from ui_widgets import action_feedback
            for frame in self.tabbar.winfo_children():
                for widget in frame.winfo_children():
                    if widget.winfo_class()=='Canvas':action_feedback(widget,self.p['accent'])
    def redraw_icon(self,c):
        """0.19.0: an icon drawn again (its soft fills on the colour of its tile); its tile is kept.
        The Préparations layer button draws itself (grey when hidden)."""
        icon=getattr(c,'craft_icon',None)
        if not icon or icon in ('prep_layer','precut_layer','recut_layer'):return False
        keep=set(c.find_withtag(modern_style.TILE))
        for item in c.find_all():
            if item not in keep:c.delete(item)
        draw(c,icon,self.p['icon_size'],self.icon_color(icon));return True
    def tab_hover(self,frame,inside):
        """0.19.0: a tab lights up while the mouse is over it (its title or its ×), the open one stays raised."""
        t=modern_style.tokens_for(self.p)
        def paint(lit):
            if getattr(frame,'tab_chosen',False) or not frame.winfo_exists():return
            fill=t['hover'] if lit else self.p['panel']
            try:
                frame.look(fill=fill)
                for w in inside:
                    if w.winfo_class()=='Canvas':w.configure(bg=fill)
                    else:getattr(w,'_render',lambda:None)()
            except (tk.TclError,AttributeError):pass
        def leave(e):
            def check():
                try:
                    x,y=frame.winfo_pointerxy();under=frame.winfo_containing(x,y)
                    paint(under is not None and str(under).startswith(str(frame)))
                except (tk.TclError,KeyError):paint(False)
            frame.after(15,check)
        for w in (frame,)+tuple(inside):
            w.bind('<Enter>',lambda e:paint(True),add='+');w.bind('<Leave>',leave,add='+')
    def small_icon(self,parent,icon,fn,tip):
        n=self.p['icon_size'];c=tk.Canvas(parent,width=n+8,height=n+8,bg=self.p['panel'],highlightthickness=0,cursor='arrow');draw(c,icon,n,self.icon_color(icon));timer={}
        __import__('display_render').paint(c,icons=True)   # 0.18.0: round icons smoothed (GDI+ on Windows)
        c.craft_icon=icon;c._modern_redraw=lambda c=c:self.redraw_icon(c)   # 0.19.0: drawn again on its tile colour
        def hide(e=None):
            if timer.get('id'):self.after_cancel(timer.pop('id'))
            if timer.get('window'):
                try:timer.pop('window').destroy()
                except tk.TclError:pass
        def show(e):
            hide()
            def display():
                w=tk.Toplevel(c);timer['window']=w;w.overrideredirect(True)
                t=modern_style.tokens_for(self.p);w.configure(bg=t['field_border'])   # 0.19.0: the modern bubble (fine edge)
                tk.Label(w,text=getattr(c,'tip_text',tip),bg=t['tip'],fg=t['text'],padx=9,pady=4,font=modern_style.font(9)).pack(padx=1,pady=1);w.update_idletasks()
                above=str(parent).startswith(str(self.__dict__.get('footer','NO_FOOTER'))) or e.y_root+w.winfo_reqheight()+24>self.winfo_screenheight()
                x=max(5,min(e.x_root+12,self.winfo_screenwidth()-w.winfo_reqwidth()-8));y=c.winfo_rooty()-w.winfo_reqheight()-7 if above else e.y_root+18
                w.geometry(f'+{x}+{max(5,y)}')
            timer['id']=self.after(350,display)
        c.bind('<Button-1>',lambda e:(hide(),fn()));c.bind('<Enter>',show);c.bind('<Leave>',hide);c.bind('<Destroy>',hide);c.hide_tip=hide
        from ui_widgets import action_feedback
        action_feedback(c,self.p['accent'])
        return c
    def popup_above(self,m,anchor):
        m.update_idletasks();x=max(4,min(anchor.winfo_rootx(),self.winfo_screenwidth()-m.winfo_reqwidth()-8));y=max(4,anchor.winfo_rooty()-m.winfo_reqheight()-7)
        try:m.tk_popup(x,y)
        finally:m.grab_release()
    def display_menu(self):
        m=self.menu();kind=self.workspace['kind'] if self.workspace else None
        for key,label in [('maro','Base maro'),('petite','Base petite maroquinerie')]:m.add_command(label=('✓  ' if key==kind else '    ')+label,command=lambda k=key:self.change_workspace(k))
        import base_profiles as bp   # 0.19.13: one's own base profiles
        current=(self.workspace or {}).get('profile')
        for name in [n for n in bp.names(self.prefs) if n not in bp.LYCEE]:m.add_command(label=('✓  ' if name==current else '    ')+name,command=lambda n=name:self.change_profile(n))
        m.add_separator();m.add_command(label='Afficher / masquer les colonnes',command=self.toggle_guides);m.add_command(label='Régler les colonnes…',command=self.workspace_dialog);m.add_command(label='Recentrer la vue',command=self.fit_workspace)
        self.popup_above(m,self.footer)
    def change_profile(self,name):
        """0.19.13: the base of a profile for this drawing (Annuler brings the other back). 0.19.14: the profile already
        there changes nothing; another one keeps the place of the base it replaces."""
        import base_profiles as bp
        w=self.workspace;new=bp.workspace_for(self.prefs,name)
        if w and (w.get('profile')==name or name in bp.LYCEE and w.get('kind')==new.get('kind') and 'labels' not in w and not w.get('profile')):self.status.set('Base déjà choisie.');return
        if w:new['origin_x']=w.get('origin_x',0.)   # (shown: one sees the base one chooses)
        self.snapshot();self.workspace=new;self.cancel();self.refresh();self.fit_workspace()
    def persist_preferences(self):
        self.prefs['snap_enabled']=self.snap.get();return super().persist_preferences()
    def toggle_snap(self,e=None):
        self.snap.set(not self.snap.get());self.snap_change();return 'break'
    def snap_change(self):
        self.anchor_candidate=None;self.snap_marker=None;self.persist_preferences();self.update_toggle_labels()
        if hasattr(self,'canvas'):
            x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))
    def constraint_origin(self):
        """The current directional step supplies one origin to the shared Ortho rule."""
        t=self.tool.get()
        if self.grip_drag:return self.grip_drag['fixed'] if self.grip_drag['mode']=='endpoint' or isinstance(self.grip_drag['mode'],tuple) and self.grip_drag['mode'][0]=='spline_tangent' else self.grip_drag['anchor']
        if self.move_state:return self.move_state['anchor']
        box=getattr(self,'box_start',None)
        if t=='select' and box and box[3] is not None:return box[2]
        if t in ('part_name','material') and getattr(self,'pending_text_origin',None) is not None:return self.pending_text_origin
        if t=='mirror' and getattr(self,'mirror_axis',None):return self.mirror_axis[0]
        if t=='copy' and getattr(self,'copy_state',None) and self.copy_state.get('anchor') is not None:return self.copy_state['anchor']
        curve=getattr(self,'curve_points',[])
        if curve:return None if t=='arc_radius' and len(curve)>=2 else curve[0] if t=='arc_center' else curve[-1]   # the bulge follows the mouse freely
        if t=='notch' and self.notch_pending:return at_distance(self.items[self.notch_pending[0]],self.notch_pending[1])[0]
        if t in ('dimension','dimension_aligned') and len(self.extra_points)>=2:return None   # 0.19.9: the Cote line is placed freely (ORTHO laid it on its points)
        if t in ('measure','dimension','dimension_aligned','angle_dimension','offset_vertex') and self.extra_points:return self.extra_points[-1]
        cotes=getattr(self,'new_cote',[])
        if cotes and not isinstance(cotes[-1],dict):return cotes[-1]
        if t=='angle_dimension' and len(cotes)==2:
            from editing import line_intersection
            try:return line_intersection(*path(cotes[0])[0],*path(cotes[1])[0])
            except ValueError:return None
        host=getattr(self,'cote_host',None)
        if t=='diameter' and host:return host['center']
        if t=='arc_length' and getattr(self,'cote_origin',None) is not None:return self.cote_origin
        tangent=getattr(self,'spline_edit',None)
        if tangent:
            s=tangent['original'];fit=s['spline']['fit'];q=fit[0] if tangent['end']=='start' else fit[-1]
            return (s['x']+q[0],s['y']+q[1])
        # 0.18.5: ORTHO for every point after the first one: the 2nd and 3rd points of Cercle (3 points),
        # the 3rd point of the rectangle orienté / parallélogramme (from the previous point).
        if t in ('rect_rot','para','circle_3p') and self.stage_points:return self.stage_points[-1]
        if t in ('line','poly','rect_rot','para','circle_radius','circle_diameter','circle_2p') and self.start is not None and len(self.stage_points)<2:return self.start
        if t=='radius' and self.radius_target:
            c,r,clicked=self.radius_target;d=math.dist(c,clicked) or 1
            return (c[0]+(clicked[0]-c[0])*r/d,c[1]+(clicked[1]-c[1])*r/d)
        if t in ('ellipse_axis','ellipse_center') and len(self.oval_points)==1:return self.oval_points[0]   # 0.19.9: not the width point (held on the axis: width 0)
        if t in ('strap_piece','toron') and (self.__dict__.get('strap_state') or {}).get('start') is not None:return self.strap_state['start']   # 0.19.6 Sangle entière
        return None
    def point(self,e):
        raw=self.raw(e);p=raw;kind=None;self.anchor_candidate=None;excluded=set();self._anchor_stack=[]
        # 0.18.5: while the repère is being chosen the selection has not moved yet: it snaps like any line.
        if self.move_state:excluded=set(self.move_state['ids']) if self.move_state.get('anchor') is not None else set()
        elif self.grip_drag:excluded={self.grip_drag['index']}|{j[0] for j in self.grip_drag.get('joint',())}|set(self.grip_drag.get('linked',()))   # 0.19.9: and what moves with it (its Piqûre…: it went by jumps); 0.19.7: all the objects held by a common point
        elif getattr(self,'_contour_drag',None):excluded=set(self._contour_drag['original'])
        excluded=excluded|__import__('preparation_ui').hidden_ids(self)   # 0.19.14: précoupes / surcoupes hidden
        items=[s for i,s in enumerate(self.items) if i not in excluded and __import__('entity_rules').geometry_entity(s)]
        if self.tool.get()=='notch' and self.notch_pending is None and getattr(self,'notch_host',None) is not None:items=[self.items[self.notch_host]]
        if self.tool.get()=='poly' and len(getattr(self,'pending',()))>=2:
            # 0.16.29: the polyline being drawn snaps to its own points (close it on the first one, align).
            items=items+[polygon(list(self.pending),'',False)]
        if self.snap.get():
            modes={k for k,v in self.snap_vars.items() if v.get()}
            if self.tool.get()=='measure':modes.add('intersection')
            base=self.constraint_origin()   # 0.19.13: Perpendiculaire, Tangente, Parallèle from the point the drawing comes from
            reach=40 if self.tool.get()=='drill' else 10   # 0.19.13: pointés and mèches go to an anchor within 40 px
            with pointer_frame():   # 0.19.9: the crossings searched once for both snaps, during a drag or a click too
                near,typ=snap_point(raw,items,modes-{'nearest','guides'},max(18,reach)/self.scale,None,base=base)
                if typ:self.anchor_candidate=(near,typ)
                p,kind=snap_point(raw,items,modes,reach/self.scale,self.workspace,base=base)  # 0.16.28: stronger snap (10 px, was 6)
            host=getattr(self,'notch_host',None)
            if self.tool.get()=='notch' and self.notch_pending is None and host is not None and host<len(self.items) and not getattr(e,'state',0)&4:
                # 0.19.13 (07/11 « le logiciel détecte l'ancrage le plus proche de la souris et l'affiche, et si je clique
                # ça pose le cran sur ce point d'ancrage »): the nearest anchor of the piece on its contour, however far
                # (Ctrl held: anywhere on the contour)
                on_contour=(modes|{'endpoint','midpoint'})&{'endpoint','midpoint','quarter','quadrant','intersection'}
                q,k=snap_point(raw,[self.items[host]],on_contour,1e9,None)
                if k:p,kind=q,k;self.anchor_candidate=(q,k)
            if 'node' in modes:
                nodes=[(s['x']+s['w']/2,s['y']+s['h']/2) for i,s in enumerate(self.items) if i not in excluded and s.get('drill')]
                if nodes:
                    c=min(nodes,key=lambda c:math.dist(c,raw))
                    if math.dist(c,raw)<=reach/self.scale and (not kind or kind in ('nearest','guides','extension','parallel') or math.dist(c,raw)<math.dist(p,raw)):p,kind=c,'node'
            if 'center' in modes:
                # 0.18.5: the centre of a mèche / pointé is a « centre » anchor (its circle is not a line:
                # no quadrant nor intersection on it).
                centres=[(s['x']+s['w']/2,s['y']+s['h']/2) for i,s in enumerate(self.items) if i not in excluded and s.get('drill')]
                if centres:
                    c=min(centres,key=lambda c:math.dist(c,raw));d=math.dist(c,raw)
                    if d<=18/self.scale and (not typ or d<math.dist(near,raw)):self.anchor_candidate=(c,'center')
                    if d<=10/self.scale and (not kind or kind in ('nearest','guides') or d<math.dist(p,raw)):p,kind=c,'center'
            if kind and kind not in ('nearest','guides'):
                # 0.18.5: anchors stacked under the pointer (circle centre on a line end…): Tab / a click choose.
                import anchor_stack
                from entity_rules import geometry_entity
                host=getattr(self,'notch_host',None) if self.tool.get()=='notch' and self.notch_pending is None else None
                idx=[host] if host is not None and host<len(self.items) else [i for i,s in enumerate(self.items) if i not in excluded and (s.get('drill') or geometry_entity(s))]
                stack=anchor_stack.stack(raw,self.items,idx,modes,10/self.scale,4/self.scale)
                self._anchor_stack=stack
                chosen=anchor_stack.chosen(stack,self.__dict__.get('_stack_pick'))
                if chosen:p,kind,_=chosen
        if not kind and self.grid.get():
            try:g=float(self.spacing.get());assert g>0;p=tuple(round(v/g)*g for v in p)
            except (ValueError,AssertionError):pass
        a=self.constraint_origin()
        if a is not None:
            dx,dy=p[0]-a[0],p[1]-a[1];dominant=max(abs(dx),abs(dy))
            near_axis=dominant>0 and min(abs(dx),abs(dy))<=dominant*math.tan(math.radians(5))
            # 0.17.0: an arc length or an angle dimension is placed freely around its curve / vertex.
            # 0.19.6 (« même en ortho je dois pouvoir rejoindre un ancrage ») : an anchor of the drawing (end,
            # middle, centre, crossing, quadrant…) wins over ORTHO: the point goes on it. A point only projected
            # on a line (Point le plus proche, Repères de base) stays held horizontal or vertical.
            anchored=bool(kind) and kind not in ('nearest','guides') and self.tool.get() not in ('dimension','dimension_aligned')   # a Cote stays horizontal / vertical
            if self.tool.get() not in ('measure','arc_length','angle_dimension') and (self.ortho.get() and not anchored or (self.move_state and near_axis and not kind)):
                constrained=(p[0],a[1]) if abs(dx)>=abs(dy) else (a[0],p[1])
                if math.dist(constrained,p)>1e-7:kind=None;self.anchor_candidate=None
                p=constrained
        g=self.grip_drag
        if g and isinstance(g['mode'],tuple) and g['mode'][0]=='pvertex' and self.snap.get():
            # 0.18.0: a vertex dragged by its grip is offered the other points of its own polyline
            # (the other end closes the piece); the two sides it moves are not anchors.
            base=g.get('polyline') or (self.as_polyline(g['original']) if hasattr(self,'as_polyline') else None)
            if base:
                k=g['mode'][1];V=[(base['x']+x,base['y']+y) for x,y in base['points']];n=len(V);closed=bool(base.get('closed'))
                near=[v for m,v in enumerate(V) if m!=k and not (closed and m in ((k-1)%n,(k+1)%n)) and not (not closed and abs(m-k)==1)]
                if near:
                    v=min(near,key=lambda v:math.dist(v,raw))
                    if math.dist(v,raw)<=10/self.scale and (kind is None or math.dist(v,raw)<math.dist(p,raw)):
                        p=v;kind='endpoint';self.anchor_candidate=(p,kind)
        if self.grip_drag and self.grip_drag['mode']=='endpoint' and self.snap.get() and self.snap_vars['intersection'].get() and kind not in ('endpoint','midpoint','center','quadrant'):
            from cad import intersections
            fixed=self.grip_drag['fixed'];length=math.dist(fixed,p);tol=10/self.scale
            if length>1e-6:
                u=((p[0]-fixed[0])/length,(p[1]-fixed[1])/length)
                support=shape('line','',*fixed,u[0]*(length+tol),u[1]*(length+tol));hits=[]
                for target in items:
                    if target.get('drill'):continue
                    hits.extend(q for q in intersections(support,target) if math.dist(q,p)<=tol and math.dist(q,fixed)>1e-6)
                if hits:p=min(hits,key=lambda q:math.dist(q,p));kind='intersection';self.anchor_candidate=(p,kind)
        self.snap_marker=(p,kind) if kind else None
        if self.tool.get()=='spline_fit' and self.snap.get() and self.curve_points:
            near=min(self.curve_points,key=lambda q:math.dist(q,raw))
            if math.dist(near,raw)<=8/self.scale:p=near;self.snap_marker=(p,'endpoint');self.anchor_candidate=self.snap_marker
        if self.grip_drag:self.grip_drag['pointer']=p
        self._point_stamp=self.pointer_stamp(e)
        return p
    def pointer_stamp(self,e):
        # Everything point() and draw_crosshair() read within one mouse event.
        return (e.x,e.y,getattr(self,'_redraws',0),id(self.items),len(self.items),self.tool.get(),self.scale,self.ox,self.oy,
                self.snap.get(),self.grid.get(),self.ortho.get(),self.move_state is None,self.grip_drag is None,getattr(self,'box_start',None),
                self.selected,frozenset(getattr(self,'selected_set',())),getattr(self,'_contour_drag',None) is None,
                self.__dict__.get('_stack_pick'),self.__dict__.get('_grip_pick'))
    def grip_cursor_point(self):
        g=self.grip_drag;p=g.get('pointer',g['anchor']);mode=g['mode']
        if isinstance(mode,tuple) and mode[0]=='edge':
            pts=path(g['original'])[0];a=pts[mode[1]];b=pts[(mode[1]+1)%len(pts)]
            length=math.dist(a,b)
            if length<1e-9:return p   # 0.19.9: a side of zero length has no direction (ZeroDivisionError at each move)
            nx,ny=-(b[1]-a[1])/length,(b[0]-a[0])/length
            origin=g['anchor'];d=(p[0]-origin[0])*nx+(p[1]-origin[1])*ny
            return (origin[0]+d*nx,origin[1]+d*ny)
        if isinstance(mode,tuple) and mode[0] in ('circle_axis','ellipse_axis'):
            for candidate,point in self.deformation_grips(self.items[g['index']]):
                if candidate==mode:return point
        return p
    def crosshair_screen(self):
        """0.18.5: where the crosshair stands: the held grip, Déplacer's moved repère, the snapped point, else the mouse.
        The tool icon and the step hint are placed from this point so they stay on the anchored point."""
        if self.grip_drag:return self.to_screen(self.grip_cursor_point())
        if self.move_state and self.move_state['anchor'] is not None:
            a=self.move_state['anchor'];dx,dy=self.move_state['delta'];return self.to_screen((a[0]+dx,a[1]+dy))
        if self.snap_marker:return self.to_screen(self.snap_marker[0])
        return self.cursor_screen
    def draw_crosshair(self):
        actual=self.cursor_screen;self.cursor_screen=self.crosshair_screen()
        try:super().draw_crosshair()
        finally:self.cursor_screen=actual
        self.canvas.delete('grip_guide')
        if self.grip_drag:
            self.canvas.create_line(*self.to_screen(self.grip_drag['anchor']),*self.to_screen(self.grip_cursor_point()),fill=self.p['ink'],tags='grip_guide',**self.guide_style())
        self.canvas.delete('anchor_hint')
        self.draw_tool_cursor()
        if not self._inside_plan or not self.snap.get():return
        candidate=self.snap_marker or self.anchor_candidate
        if candidate:
            x,y=self.to_screen(candidate[0]);color=self.p['accent'] if self.snap_marker else '#efd350'
            if self.snap_marker:
                self.canvas.create_rectangle(x-4,y-4,x+4,y+4,outline=color,fill=color,width=1.4,tags='anchor_hint')
                stack=self.__dict__.get('_anchor_stack') or []
                if len(stack)>=2 and getattr(self,'stack_matters',lambda s:True)(stack):
                    # 0.18.5: several anchors here: which one is taken, and Tab for the next one (0.18.6: only when it changes something).
                    import anchor_stack
                    current=anchor_stack.chosen(stack,self.__dict__.get('_stack_pick')) or stack[0]
                    self.canvas.create_line(x-7,y-7,x+7,y-7,x+7,y+7,x-7,y+7,x-7,y-7,fill=color,width=1,tags='anchor_hint')
                    self.canvas.create_text(x+12,y-12,text=anchor_stack.label_of(stack,self.items,current)+' · Tab',anchor='sw',fill=color,font=('Segoe UI',-11),tags='anchor_hint')
            else:
                self.canvas.create_line(x-6,y,x+6,y,fill=color,width=1.3,tags='anchor_hint');self.canvas.create_line(x,y-6,x,y+6,fill=color,width=1.3,tags='anchor_hint')
    def highlight_tools(self):
        super().highlight_tools()
        if hasattr(self,'canvas'):self.draw_tool_cursor()
    def draw_tool_cursor(self):
        c=self.canvas;t=self.tool.get()
        if not self._inside_plan or t=='select':c.delete('tool_cursor');return
        graphic={'move_anchor':'move','paint_white':'white','paint_external':'external','paint_internal':'internal','rect_path':'rect','circle_radius':'circle_radius'}.get(t,t)
        x,y=self.crosshair_screen()
        color={'notch':'#bd7ccc','drill':'#cf5be5','paint_external':'#e65b65','paint_internal':'#748fe0'}.get(t,self.p['accent'])
        # 0.19.9: same tool and colour: the icon kept, placed from its shape at 0, 0 as the cross is (drawn again at each
        # move it took 0.1-0.6 ms; moved by differences, its half-pixel strokes could drift 1 px), above what the move drew
        kept=c.__dict__.get('_tool_cursor')   # (graphic, colour, [(item, its coordinates at 0, 0)…])
        if kept and kept[:2]==(graphic,color) and c.type(kept[2][0][0]):
            for item,xy in kept[2]:c.coords(item,*[v+(y+12 if k%2 else x+10) for k,v in enumerate(xy)])
            c.tag_raise('tool_cursor');return
        c.delete('tool_cursor');c._tool_cursor=None
        # Tag at creation: no scan of every canvas item on each pointer move.
        from ui_widgets import tag_created
        with tag_created(c,'tool_cursor'):draw(c,graphic,14,color)
        made=c.find_withtag('tool_cursor')
        if made:c._tool_cursor=(graphic,color,[(item,c.coords(item)) for item in made])
        c.move('tool_cursor',x+10,y+12)
    def leave_plan(self,e=None):
        result=super().leave_plan(e);self.canvas.delete('tool_cursor');self.canvas.delete('anchor_hint');return result
    def set_tool(self,t):
        if self._action:self.finish_action()
        if t=='move_anchor':
            from entity_rules import linked_selection
            ids=linked_selection(self.items,self.selected_ids());self.cancel()
            self.tool.set(t);self.last_command=('tool',t);self.move_state=dict(ids=ids,original={i:copy.deepcopy(self.items[i]) for i in ids},anchor=None,delta=(0,0));self.status.set('Choisir le repère' if ids else 'Sélectionner ligne/polyligne');self.canvas.focus_set();self.highlight_tools();return
        if t in ('offset_all','offset_part'):
            self.cancel();self.tool.set(t);self.last_command=('tool',t);self.highlight_tools()
            d=getattr(self,'_offset_distance',5)
            self._offset_distance=d;self.offset_state=dict(distance=d,host=None,choices={},sign=1)
            if t=='offset_part':self.route_state=dict(mode='offset',host=None,points=[],choices=[],hover=0)
            self.status.set('Sélectionner la polyligne.' if t=='offset_part' else 'Sélectionner le contour à décaler.');self.canvas.focus_set();return
        if t in OVALS:
            self.cancel();self.line_type='Plein';self.paint_line_picker();self.tool.set(t);self.last_command=('tool',t);self.status.set(OVALS[t]+' : choisir le premier point.');self.canvas.focus_set();self.highlight_tools();return
        return super().set_tool(t)
    def cancel(self):
        self.search_close(focus=False);self.move_state=None;self.offset_state=None;self.route_state=None;self.rect_reference=None;self.oval_points=[];self._route_marks=[];self.anchor_candidate=None
        return super().cancel()
    def escape(self):
        if self._action:return self.finish_action()
        if self.grip_drag:self.grip_drag=None
        with self.held_redraw():self.selected=None;self.selected_set=set();result=self.cancel();self.refresh()
        return result
    def stash_doc(self):
        if self._action:self.finish_action()
        return super().stash_doc()
    def complete_command(self,name,action=False):
        self.move_state=None;self.offset_state=None;self.route_state=None;self.rect_reference=None;self.oval_points=[];self._route_marks=[]
        return super().complete_command(name,action)
    def parse_length(self,text):
        from command_catalog import length_expression
        return length_expression(text,self.units.get())
    def down(self,e):
        t=self.tool.get();self.cursor_screen=(e.x,e.y);self.canvas.focus_set();self._inside_plan=True
        try:
            if self.move_state:
                if not self.move_state['ids']:
                    from entity_rules import linked_selection
                    i=self.pick(self.raw(e))
                    if i is None:raise ValueError('Sélectionner ligne/polyligne')
                    ids=linked_selection(self.items,[i]);self.move_state.update(ids=ids,original={i:copy.deepcopy(self.items[i]) for i in ids});self.selected=i;self.selected_set=set(ids);self.refresh();self.status.set('Choisir le repère');return
                p=self.point(e)
                if self.move_state['anchor'] is None:self.move_state['anchor']=p;self.status.set('Choisir l’arrivée ou saisir une distance.');return
                self.move_state['delta']=(p[0]-self.move_state['anchor'][0],p[1]-self.move_state['anchor'][1]);self.move_state['direction']=self.move_state['delta'];self.preview_move_distance();self.commit_move();return
            if self.route_state:return self.route_click(e)
            if self.offset_state:
                if self.offset_state['host'] is None:
                    i=self.pick(self.raw(e))
                    if i is None:raise ValueError('Sélectionnez un contour.')
                    if self.items[i].get('annotation') or self.items[i].get('drill'):raise ValueError('Choisissez un tracé.')
                    self.prepare_offset(self.items[i]);return
                self.offset_side(self.raw(e));q=self.offset_state['choices'].get(self.offset_state['sign'])
                if q is None:raise ValueError('Ce côté ne permet pas ce décalage. Réduisez la distance.')
                self.add_items([copy.deepcopy(q)],t);return
            if self.rect_reference:
                self.commit_reference_rect(self.point(e));return
            if t in OVALS:
                p=self.point(e)
                # 0.19.9: a refused point is not kept (the points piled up: stuck until Échap); an axis of zero length is refused at once.
                if t!='ellipse_box' and len(self.oval_points)==1 and math.dist(self.oval_points[0],p)/(1 if t=='ellipse_center' else 2)<1e-6:raise ValueError('Le nouveau point se confond avec le précédent.')
                self.oval_points.append(p)
                if len(self.oval_points)==(2 if t=='ellipse_box' else 3):
                    try:q=self.oval_shape(p,complete=True)
                    except ValueError:self.oval_points.pop();raise
                    self.add_items([q],t)
                return
            return super().down(e)
        except (ValueError,IndexError) as exc:self.invalid_at(e,str(exc))
    def up(self,e):
        if self.move_state or self.offset_state or self.route_state or self.rect_reference or self.tool.get() in CUSTOM:return
        return super().up(e)
    def commit_move(self):
        state=self.move_state;dx,dy=state['delta'];self.snapshot()
        for i,s in state['original'].items():self.items[i]=copy.deepcopy(s);self.items[i]['x']+=dx;self.items[i]['y']+=dy
        attached=self.attach_moved_zones(state['original']) if hasattr(self,'attach_moved_zones') else 0   # 0.18.1
        self.complete_command('move_anchor');self.refresh()
        if attached:self.status.set('Zone de préparation rattachée à sa pièce.' if attached==1 else f'{attached} zones de préparation rattachées à leur pièce.')
    def moving_items(self):
        if not self.move_state or self.move_state['anchor'] is None:return self.items
        result=list(self.items);dx,dy=self.move_state['delta']
        for i,s in self.move_state['original'].items():q=copy.deepcopy(s);q['x']+=dx;q['y']+=dy;result[i]=q
        return result
    def redraw(self):
        self._redraws=getattr(self,'_redraws',0)+1
        original=self.items;moving=self.translating_ids()
        try:
            self.items=self.moving_items()
            if moving:self._capture_ids={id(self.items[i]):i for i in moving if i<len(self.items)};self._captured=set()
            super().redraw()
        finally:
            self.items=original;self.__dict__.pop('_capture_ids',None);captured=self.__dict__.pop('_captured',set())
        self.draw_move_guide()
        # 0.16.15: remember how the translated shapes were drawn; the next pointer
        # moves shift those canvas items instead of redrawing the whole plan.
        self._translation_drawn=dict(ids=frozenset(moving),ok=set(moving)<=captured,view=(self.scale,self.ox,self.oy),redraws=self._redraws,offset=self.translation_offset()) if moving else None
    def translating_ids(self):
        """Shapes moved as a whole by the current gesture (indices), else none."""
        if self.move_state and self.move_state['anchor'] is not None:return tuple(self.move_state['original'])
        drag=self.__dict__.get('_contour_drag')
        if drag and drag.get('changed') and 'offset' in drag:return tuple(drag['original'])
        return ()
    def translation_offset(self):
        if self.move_state and self.move_state['anchor'] is not None:return self.move_state['delta']
        drag=self.__dict__.get('_contour_drag')
        return drag['offset'] if drag and 'offset' in drag else (0,0)
    def fast_translate(self,offset):
        """Shift the tagged canvas items to `offset` (world units); False when a
        full redraw is required (zoom, other redraw, shape hidden off-screen)."""
        d=self.__dict__.get('_translation_drawn')
        if not d or not d['ok'] or d['redraws']!=getattr(self,'_redraws',0) or d['view']!=(self.scale,self.ox,self.oy) or d['ids']!=frozenset(self.translating_ids()):return False
        dx,dy=offset;px,py=d['offset']
        if (dx,dy)!=(px,py):self.canvas.move('moving',(dx-px)*self.scale,(dy-py)*self.scale)
        d['offset']=(dx,dy);return True
    def move_label_position(self):
        """Screen point beside the middle of the Déplacer guide: live value and typed value."""
        a=self.move_state['anchor'];dx,dy=self.move_state['delta'];A=self.to_screen(a);B=self.to_screen((a[0]+dx,a[1]+dy));n=math.dist(A,B)
        nx,ny=((A[1]-B[1])/n,(B[0]-A[0])/n) if n>1e-9 else (0,-1)
        if ny>0:nx,ny=-nx,-ny
        return ((A[0]+B[0])/2+nx*14,(A[1]+B[1])/2+ny*14)
    def draw_move_guide(self):
        self.canvas.delete('move_guide')
        if self.move_state and self.move_state['anchor'] is not None:
            a=self.move_state['anchor'];dx,dy=self.move_state['delta'];b=(a[0]+dx,a[1]+dy);ax,ay=self.to_screen(a)
            # 0.16.16: small cross on the start point; the distance is written beside the dotted guide,
            # and a typed value is entered at that same place.
            for sign in (-1,1):self.canvas.create_line(ax-5,ay-sign*5,ax+5,ay+sign*5,fill=self.p['ink'],width=1.4,tags='move_guide')
            self.canvas.create_line(ax,ay,*self.to_screen(b),fill=self.p['ink'],tags='move_guide',**self.guide_style())
            text=self.command_value.get().strip();x,y=self.move_label_position()
            self.canvas.create_text(x,y,text=text or self.format_length(round(math.hypot(dx,dy),1)),fill=self.p['ink'],font=('Segoe UI',10),tags='move_guide')
            if text:self.draw_input_bubble()
    def preview_move_distance(self):
        if not self.move_state or self.move_state['anchor'] is None:return
        st=self.move_state;dx,dy=st.get('direction',st['delta']);n=math.hypot(dx,dy);text=self.command_value.get().strip()
        if text and n>1e-9:
            try:
                value=self.parse_length(text)
                if value>0:st['delta']=(dx/n*value,dy/n*value)
            except ValueError:pass
        elif not text:st['delta']=(dx,dy)
    def command_preview(self):
        super().command_preview()
        if self.move_state and self.move_state['anchor'] is not None:
            self.preview_move_distance();self.redraw()
        if self.offset_state and self.command_value.get().strip():
            try:
                value=self.parse_length(self.command_value.get())
                if value<=0:return
                self.offset_state['distance']=value
                if self.offset_state['host'] is not None:self.prepare_offset(self.offset_state['host'])
                if self.route_state:self.draw_route(self.pointer_world)
                else:
                    x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))
            except ValueError:pass
    def motion(self,e):
        self.cursor_screen=(e.x,e.y);self._inside_plan=True;t=self.tool.get()
        if self.move_state:
            p=self.point(e);self.pointer_world=p
            if self.move_state['anchor'] is not None:
                a=self.move_state['anchor'];self.move_state['delta']=(p[0]-a[0],p[1]-a[1]);self.move_state['direction']=self.move_state['delta'];self.preview_move_distance()
                if self.fast_translate(self.move_state['delta']):self.preview();self.draw_move_guide()
                else:self.redraw()
            self.draw_crosshair();return
        if self.route_state:
            self.point(e);self.draw_route(self.raw(e));self.draw_crosshair();return
        if self.offset_state:
            self.point(e);self.canvas.delete('preview')
            # 0.16.29: no offset shown while its value is being asked; it appears after Entrée.
            if self.offset_state['host'] is not None and not self.offset_state.get('asking'):
                self.offset_side(self.raw(e));q=self.offset_state['choices'].get(self.offset_state['sign'])
                if q:
                    self.draw_shape(q,'#a3a8aa',1,('preview',))
                    for item in self.canvas.find_withtag('preview'):
                        if self.canvas.type(item)=='line':self.canvas.itemconfigure(item,fill='#a3a8aa',stipple='gray50')
                else:self.status.set('Décalage impossible de ce côté : réduire la distance.')
            self.draw_route_marks();self.draw_crosshair();self.draw_input_bubble();return
        if self.rect_reference:
            p=self.point(e);self.pointer_world=p;self.canvas.delete('preview');s=self.reference_rect(p)
            if self.rect_reference['phase']=='place':
                self.canvas.create_line(*self.to_screen(p),*self.to_screen((p[0]+self.rect_reference['length'],p[1])),fill=self.p['ink'],tags='preview')
            elif s['h']>1e-6:self.draw_shape(s,self.p['ink'],1,('preview',))
            self.draw_crosshair();self.draw_input_bubble();return
        if t in OVALS:
            p=self.point(e);self.pointer_world=p;self.canvas.delete('preview')
            try:
                if self.oval_points:
                    s=self.oval_shape(p)
                    if s:self.draw_shape(s,self.p['ink'],1,('preview',))
            except ValueError:pass
            self.draw_crosshair();self.draw_input_bubble();return
        super().motion(e)
        # The lower layers already snapped and drew the cursor for this very
        # event; repeat only if something they depend on changed meanwhile.
        if t=='select' and not self.box_start and not self.grip_drag and getattr(self,'_point_stamp',None)!=self.pointer_stamp(e):self.point(e);self.draw_crosshair()
    def prepare_offset(self,host):
        self.offset_state['host']=copy.deepcopy(host);self.offset_state['choices']={}
        for sign in (-1,1):
            try:self.offset_state['choices'][sign]=shifted(host,sign*self.offset_state['distance'])
            except ValueError:pass
        if not self.offset_state.get('asking'):self.status.set('Choisir intérieur / extérieur avec la souris, puis cliquer.')
    def offset_side(self,p):
        st=self.offset_state;s=st['host']
        if path(s)[1]:st['sign']=-1 if inside(s,p) else 1
        else:
            d,q=locate(s,p);pt,n=at_distance(s,d);st['sign']=1 if (p[0]-q[0])*n[0]+(p[1]-q[1])*n[1]>=0 else -1
    def canvas_context(self,e):
        if self.tool.get() in ('rect','rect_center','rect_round','rect_rot'):
            m=self.menu();m.add_command(label='Mesurer sur polyligne',command=self.start_reference_measure);m.add_separator();m.add_command(label='Annuler',command=self.cancel)
            try:m.tk_popup(e.x_root,e.y_root)
            finally:m.grab_release()
            return 'break'
        return super().canvas_context(e)
    def start_reference_measure(self):
        self.cancel();self.tool.set('rect_path');self.last_command=('tool','rect')
        self.route_state=dict(mode='measure',host=None,points=[],choices=[],hover=0);self.status.set('Sélectionner la polyligne à mesurer.');self.canvas.focus_set()
    def route_click(self,e):
        st=self.route_state;p=self.point(e)
        if st['host'] is None:
            i=self.pick(self.raw(e))
            if i is None:raise ValueError('Sélectionnez une polyligne.')
            if not is_contour(self.items[i]):raise ValueError('Cet objet n’est pas une polyligne. Sélectionnez une polyligne.')
            st['host']=copy.deepcopy(self.items[i]);self.status.set('Choisir le premier point de la portion.');return
        if len(st['points'])<2:
            d,q=contour_location(st['host'],p)
            if math.dist(p,q)*self.scale>18:raise ValueError('Choisissez un point sur le contour.')
            st['points'].append(q);self._route_marks=list(st['points'])
            if len(st['points'])==2:
                try:st['choices']=routes(st['host'],*st['points'])
                except ValueError:st['points'].pop();self._route_marks=list(st['points']);raise
                if len(st['choices'])==1:self.accept_route();return
                self.status.set('Survoler le parcours voulu, puis cliquer pour le choisir.')
            else:self.status.set('Choisir le deuxième point de la portion.')
            self.draw_route(self.raw(e));return
        self.draw_route(self.raw(e));self.accept_route()
    def draw_route_marks(self):
        self.canvas.delete('route_marks')
        for p in self._route_marks:
            x,y=self.to_screen(p)
            for sign in (-1,1):self.canvas.create_line(x-5,y-sign*5,x+5,y+sign*5,fill='#ffe251',width=1.5,tags='route_marks')
    def draw_route(self,p):
        self.canvas.delete('preview');st=self.route_state
        if st and st['choices']:
            def score(choice):
                pts,closed=path(choice[0]);return min(distance(p,a,b) for a,b in zip(pts,pts[1:]+pts[:1] if closed else pts[1:]))
            st['hover']=min(range(len(st['choices'])),key=lambda i:score(st['choices'][i]));q,n=st['choices'][st['hover']]
            self.draw_shape(q,'#ffe251',2,('preview',));self.status.set('Parcours : '+self.format_length(n)+' '+self.units.get()+' · cliquer pour choisir.')
        self.draw_route_marks()
    def accept_route(self):
        st=self.route_state;q,length=st['choices'][st['hover']];mode=st['mode'];self.route_state=None;self.canvas.delete('preview')
        if mode=='offset':self.prepare_offset(q)
        else:
            self._route_marks=[];self.canvas.delete('route_marks');self.rect_reference=dict(length=length,origin=None,phase='place',height=None);self.status.set('Placer la base, puis saisir la hauteur.')
    def reference_rect(self,p,height=None):
        ref=self.rect_reference
        if ref['phase']=='place':
            a=p
            if height is None:height=ref['height']
            if height is None:
                height=0.
            h=max(1e-6,height);y=a[1]
        else:
            a=ref['origin'];h=abs(p[1]-a[1]) if height is None else height;y=a[1]-h if p[1]<a[1] else a[1]
        return shape('rect','Cavour',a[0],y,ref['length'],h)
    def commit_reference_rect(self,p,height=None):
        ref=self.rect_reference
        if height is not None and height<=0:raise ValueError('La hauteur doit être positive.')
        if ref['phase']=='place':
            if height is not None:
                ref['height']=height;self.command_value.set('');self.canvas.focus_set()
                self.status.set('Hauteur enregistrée : '+self.format_length(height)+' '+self.units.get()+' · cliquer où poser le rectangle.');return
            if ref['height'] is None:
                ref.update(origin=p,phase='height');self.status.set('Emplacement choisi : définir la hauteur à la souris ou au clavier.');return
        q=self.reference_rect(p,height)
        if q['h']<1e-6:raise ValueError('La hauteur doit être positive.')
        self.add_items([q],'rect')
    def oval_shape(self,p,complete=False):
        pts=self.oval_points if complete else self.oval_points+[p];t=self.tool.get();a=pts[0]
        if len(pts)<2:return None
        b=pts[1]
        if t=='ellipse_box':return ellipse(((a[0]+b[0])/2,(a[1]+b[1])/2),abs(b[0]-a[0])/2,abs(b[1]-a[1])/2)
        if len(pts)<3:return shape('line','Axe',*a,b[0]-a[0],b[1]-a[1])
        c=pts[2];angle=math.atan2(b[1]-a[1],b[0]-a[0]);center=a if t=='ellipse_center' else ((a[0]+b[0])/2,(a[1]+b[1])/2);rx=math.dist(a,b)/(1 if t=='ellipse_center' else 2);ry=abs((c[0]-center[0])*(-math.sin(angle))+(c[1]-center[1])*math.cos(angle))
        return ellipse(center,rx,ry,angle)
    def draw_input_bubble(self):
        text=self.command_value.get().strip()
        if self.tool.get() in ('line','poly') and (text.startswith(('@','#')) or '..' in text):
            x,y=self.cursor_screen;w=max(90,min(240,14+len(text)*7))
            self.command_entry.place(x=max(2,min(self.canvas.winfo_width()-w-3,x+16)),y=max(2,min(self.canvas.winfo_height()-23,y+16)),width=w,height=21);return
        if self.move_state and self.move_state['anchor'] is not None and text and hasattr(self,'command_entry'):
            # Déplacer: the typed value replaces the live value beside the guide.
            x,y=self.move_label_position()
            if hasattr(self,'place_value_bubble'):self.place_value_bubble(x,y,center=True);return
            w=max(54,min(145,len(text)*7+16));h=21
            self.command_entry.place(x=max(2,min(self.canvas.winfo_width()-w-3,x-w/2)),y=max(2,min(self.canvas.winfo_height()-h-2,y-h/2)),width=w,height=h);return
        custom=self.offset_state or self.move_state and self.move_state['anchor'] is not None or self.rect_reference or self.tool.get() in OVALS and self.oval_points
        if custom and hasattr(self,'command_entry'):
            text=self.command_value.get().strip()
            if not text:self.command_entry.place_forget();return
            x,y=self.cursor_screen;w=max(54,min(145,len(text)*7+16));self.command_entry.place(x=max(2,min(self.canvas.winfo_width()-w-3,x+16)),y=max(2,min(self.canvas.winfo_height()-23,y+16)),width=w,height=21);return
        return super().draw_input_bubble()
    def key_input(self,e):
        if e.state&4:return
        if self.focus_get() is self.canvas:
            if self.tool.get() in ('line','poly') and e.char in ('@','#'):
                self.command_entry.insert('end',e.char);self.draw_input_bubble();self.command_entry.focus_set();return 'break'
            if e.char and e.char.isalpha():self.search_open(e.char);return 'break'
            if e.char and e.char in '0123456789.,;+-' and (self.offset_state or self.move_state or self.rect_reference or self.tool.get() in OVALS):
                self.command_entry.insert('end',e.char);self.draw_input_bubble();self.command_entry.focus_set();return 'break'
        return super().key_input(e)
    def enter_dimension(self,e=None):
        text=self.command_value.get().strip()
        try:
            if self.offset_state and text:
                value=self.parse_length(text)
                if value<=0:raise ValueError('La distance doit être positive.')
                self._offset_distance=value;self.offset_state['distance']=value
                if self.offset_state['host'] is not None:self.prepare_offset(self.offset_state['host'])
                self.command_value.set('');self.command_entry.place_forget();self.canvas.focus_set();return 'break'
            if self.move_state:
                a=self.move_state['anchor']
                if a is None:self.status.set('Choisir d’abord le repère.');return 'break'
                dx,dy=self.move_state['delta'];n=math.hypot(dx,dy)
                if text:
                    value=self.parse_length(text)
                    if value<=0:raise ValueError('La distance doit être positive.')
                    if n<1e-9:raise ValueError('Donnez d’abord une direction avec la souris.')
                    self.move_state['delta']=(dx/n*value,dy/n*value)
                self.commit_move();return 'break'
            if self.rect_reference:
                self.commit_reference_rect(self.pointer_world,self.parse_length(text) if text else None);return 'break'
            if self.tool.get() in OVALS and text:
                values=[self.parse_length(v) for v in text.split(';')];pts=self.oval_points;t=self.tool.get()
                if not pts:raise ValueError('Choisir le premier point.')
                a=pts[0]
                if len(pts)==1 and len(values)==2:
                    rx,ry=values;center=a;angle=0;p=self.pointer_world
                    # 0.19.9: the oval clicked with these sizes, toward the mouse (like Rectangle): Ovale (rectangle) « largeur;hauteur »
                    # in the mouse's quarter; Ovale (grand axe) « longueur;largeur » from its start (it was centred there, twice as long).
                    if t=='ellipse_box':center=(a[0]+rx/2*(-1 if p[0]<a[0] else 1),a[1]+ry/2*(-1 if p[1]<a[1] else 1));rx/=2;ry/=2
                    if t=='ellipse_axis':
                        if math.dist(a,p)>1e-9:angle=math.atan2(p[1]-a[1],p[0]-a[0])
                        rx/=2;center=(a[0]+rx*math.cos(angle),a[1]+rx*math.sin(angle))
                    self.add_items([ellipse(center,rx,ry,angle)],t)
                elif len(pts)==2 and len(values)==1:
                    b=pts[1];angle=math.atan2(b[1]-a[1],b[0]-a[0]);c=a if t=='ellipse_center' else ((a[0]+b[0])/2,(a[1]+b[1])/2);rx=math.dist(a,b)/(1 if t=='ellipse_center' else 2);self.add_items([ellipse(c,rx,values[0],angle)],t)
                else:raise ValueError('Saisir deux dimensions séparées par ; ou la demi-largeur après l’axe.')
                return 'break'
        except ValueError as exc:self.status.set(str(exc));return 'break'
        return super().enter_dimension(e)
    def commands(self):
        result=[]
        for group,buttons in self.toolgroups.items():
            for icon,variants in buttons:
                for key,label,fn in variants:
                    if key=='move_anchor':label='Déplacer'
                    result.append((label,fn or (lambda k=key:self.set_tool(k))))
        result.extend([('Supprimer',self.delete),('Dupliquer',self.duplicate),('Recentrer',self.fit_workspace),('Mesurer sur polyligne',self.start_reference_measure)])
        return result
    def search_open(self,char):
        if not self.search_frame:return
        self.search_value.set(char);x,y=self.cursor_screen;self.search_frame.update_idletasks();w=self.search_frame.winfo_reqwidth();h=self.search_frame.winfo_reqheight()
        self.search_frame.place(x=max(3,min(x+14,self.canvas.winfo_width()-w-4)),y=max(3,min(y+16,self.canvas.winfo_height()-h-4)));self.search_frame.lift();self.search_entry.focus_set();self.search_entry.icursor('end')
    def open_commands(self):
        if self.modal_active():return 'break'
        self.search_open('');return 'break'
    def run_named_command(self,text):
        from command_catalog import resolve,length_expression
        found=resolve(text)
        if not found:raise ValueError('Commande inconnue. Utilisez la recherche ou le guide des commandes.')
        command,argument=found;value=None
        if argument:
            value=length_expression(argument,self.units.get())
            if command.parameter in ('point_length','round_depth'):
                if value<0:raise ValueError('La longueur doit être positive (0 : pointe à 45° ou demi-cercle).')   # 0.19.5, 0.19.6
            elif command.parameter!='calculation' and value<=0:raise ValueError('La dimension doit être positive.')
        if command.action=='!calc':
            if value is None:raise ValueError('Exemple : calcul (80 + 2*5)/2 mm.')
            message=f'Calcul : {self.format_length(value)} {self.units.get()} · saisir cette valeur dans une dimension.'
        elif command.action=='!close':
            if self.tool.get()!='poly' or len(self.pending)<3:raise ValueError('Tracez au moins trois points de polyligne avant de fermer.')
            self.finish_poly(True);message='Contour fermé.'
        elif command.action=='!back':
            if self.tool.get()!='poly' or not self.pending:raise ValueError('Aucun sommet de polyligne à retirer.')
            self.pending.pop();self.start=self.pending[-1] if self.pending else None;self.command_value.set('');self.redraw();message='Dernier sommet retiré ; continuer la polyligne.'
        elif command.action.startswith('!'):
            actions=dict(duplicate=self.duplicate,ortho=self.toggle_ortho,snap=self.toggle_snap,fit=self.fit,undo=self.undo,redo=self.redo,pdf=self.pdf,dxf=self.dxf,help=self.command_guide,regen=getattr(self,'regen',self.refresh),settings=lambda:__import__('settings_ui').open_settings(self))
            actions[command.action[1:]]();message=None
        else:
            self.set_tool(command.action)
            if value is not None:self.keep_tool_value(command.parameter,value)   # 0.19.9: kept for the next start (« arrondi 5 »)
            message=command.hint+(f' Valeur : {self.format_length(value)} {self.units.get()}.' if value is not None else '')
        if message:self.status.set(message)
        self.command_history=[text]+[v for v in self.command_history if v!=text];self.command_history=self.command_history[:8]
        return 'break'
    def command_guide(self):
        from command_catalog import COMMANDS
        import webbrowser
        win=self.dialog('Commandes Craft');self.label(win,'Ctrl+K ou taper un nom sur le plan',font=('Segoe UI',10,'bold')).pack(anchor='w',padx=15,pady=12)
        body=tk.Frame(win,bg=self.p['panel']);body.pack(fill='both',expand=True,padx=15)
        text=tk.Text(body,width=82,height=23,wrap='word',bg=self.field_background(),fg=self.p['ui_ink'],font=('Segoe UI',10),relief='flat',padx=10,pady=8)
        scroll=ttk.Scrollbar(body,orient='vertical',command=text.yview);scroll.pack(side='right',fill='y');text.configure(yscrollcommand=scroll.set);text.pack(side='left',fill='both',expand=True)
        text.insert('end','DIMENSIONS ET POINTS\n80+2*5 → longueur de 90 ; (80+20)/2 cm → longueur de 50 cm.\n@40;20 → depuis le dernier point : 40 à droite, 20 vers le bas.\n#100;75 → point absolu ; 40..20 → déplacement relatif au pavé numérique.\n@50<90 → 50 vers le bas. Angles de Craft : 0° à droite, 90° vers le bas.\nLes coordonnées explicites fonctionnent avec Ligne et Polyligne.\n\n')
        for command in COMMANDS:text.insert('end',command.name+' — '+', '.join(command.aliases)+'\n'+command.hint+'\n\n')
        text.configure(state='disabled')
        self.button(win,'Guide officiel LibreCAD ↗',lambda:webbrowser.open('https://docs.librecad.org/en/latest/guides/cmdline.html')).pack(side='left',padx=15,pady=12)
        self.button(win,'Fermer',win.destroy).pack(side='right',padx=15,pady=12)
    def search_update(self):
        from command_catalog import resolve,matching
        query=self.search_value.get().strip();found=resolve(query);self.search_details={}
        if found:
            command,argument=found;label=command.name+(' · '+argument if argument else '')
            self.search_results=[(label,lambda q=query:self.run_named_command(q))];self.search_details[label]=command.hint
        else:
            candidates=matching(query) if query else []
            self.search_results=[]
            if not query:
                for item in self.command_history[:5]:
                    label='Récent · '+item;self.search_results.append((label,lambda q=item:self.run_named_command(q)))
                candidates=matching('')[:6]
            for command in candidates:
                label=command.name+' · '+command.aliases[-1]
                self.search_results.append((label,lambda q=command.aliases[0]:self.run_named_command(q)));self.search_details[label]=command.hint
            known={normalized(c.name) for c in candidates}
            self.search_results.extend(c for c in self.commands() if query and normalized(query) in normalized(c[0]) and normalized(c[0]) not in known)
        self.search_results=self.search_results[:12];self.search_list.delete(0,'end')
        for label,fn in self.search_results:self.search_list.insert('end',label)
        if not self.search_results:self.search_list.insert('end','Aucune commande trouvée · aide pour le guide')
        else:self.search_list.selection_set(0)
        self.search_hint.set(self.search_details.get(self.search_results[0][0],'Tab : compléter') if self.search_results else 'Essayer ligne, arrondi 5 mm, miroir ou copier crans.')
        self.search_list.configure(height=min(7,max(1,len(self.search_results))))
    def search_complete(self):
        from command_catalog import resolve,matching
        query=self.search_value.get().strip();found=resolve(query)
        command=found[0] if found else next(iter(matching(query)),None)
        if command:
            self.search_value.set(command.aliases[0]+(' '+found[1] if found and found[1] else ' ' if command.parameter else ''));self.search_entry.icursor('end')
        return 'break'
    def search_step(self,d):
        if self.search_results:
            i=(self.search_list.curselection() or (0,))[0];i=(i+d)%len(self.search_results);self.search_list.selection_clear(0,'end');self.search_list.selection_set(i);self.search_list.see(i);self.search_hint.set(self.search_details.get(self.search_results[i][0],'Tab : compléter'))
        return 'break'
    def search_accept(self):
        if not self.search_results:return 'break'
        i=(self.search_list.curselection() or (0,))[0];fn=self.search_results[i][1]
        try:fn()
        except ValueError as exc:self.search_hint.set(str(exc));self.status.set(str(exc));return 'break'
        self.search_close(focus=not self.modal_active());return 'break'
    def search_close(self,focus=True):
        frame=self.__dict__.get('search_frame')
        if frame and frame.winfo_exists():frame.place_forget()
        if focus and hasattr(self,'canvas'):self.canvas.focus_set()
        return 'break'
    def draw_shape(self,s,color,width,tags=()):
        if s.get('drill'):
            cx,cy=self.to_screen((s['x']+s['w']/2,s['y']+s['h']/2));r=s['w']/2*self.scale;v='#cf5be5';stroke=min(self.line_px(),max(1,.15*self.scale));opts=dict(fill=v,width=stroke,tags=tags)
            self.canvas.create_oval(cx-r,cy-r,cx+r,cy+r,outline=v,width=stroke,tags=tags);h=r*1.45/math.sqrt(2)
            for sign in (-1,1):self.canvas.create_line(cx-h,cy-sign*h,cx+h,cy+sign*h,**opts)
            if not s.get('drill_point'):self.canvas.create_text(cx+r+1.2*self.scale,cy-r-1*self.scale,text=f'{s["drill_diameter"]:g}',anchor='sw',fill=v,font=('Segoe UI',-max(1,round(2.5*self.scale))),tags=zoom_tag(tags,'t',2.5))
            return
        if s.get('ellipse') and not tags:
            old=self.selected;ids=self.selected_set;selected=any(i<len(self.items) and self.items[i] is s for i in self.selected_ids());self.selected=None;self.selected_set=set()
            try:super().draw_shape(s,color,width,tags)
            finally:self.selected=old;self.selected_set=ids
            if selected and self.grips_shown():
                for p,kind in object_anchors(s):
                    if kind!='center':continue
                    x,y=self.to_screen(p);self.canvas.create_rectangle(x-2,y-2,x+2,y+2,outline=self.p['accent'],fill=self.p['canvas'],tags='grips')
            return
        if tags and self.route_state and 'preview' in tags:
            pts,closed=path(s)
            if closed:pts=pts+pts[:1]
            self.canvas.create_line(*[v for p in pts for v in self.to_screen(p)],fill='#ffe251',width=2,tags=tags);return
        return super().draw_shape(s,color,width,tags)
    def hit_grip(self,p):
        ids=self.selected_set;old=self.selected;ellipses={i for i in self.selected_ids() if self.items[i].get('ellipse')}
        for i in ellipses:
            s=self.items[i];center=(s['x'],s['y'])
            if math.dist(center,p)<=7/self.scale:return i,'move',center,center
        try:
            self.selected_set=set(self.selected_ids())-ellipses
            if old in ellipses:self.selected=None
            return super().hit_grip(p)
        finally:self.selected_set=ids;self.selected=old
 from finish_ui import finish_ui
 return finish_ui(Precision)
