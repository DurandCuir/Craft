"""0.19.6 Bout de ceinture, Fente d'ardillon, Sangle entière (« une option bout de ceinture qui recrée le
bout de mes ceintures », la fente de l'ardillon, « une sangle entière en une fois »).

Bout de ceinture (with Bout rond / Bout pointu): its window (length of the taper, width of the tip, round
of the corners: remembered), then, as the other ends, a click on the end side of a strap piece or on its
two edges near the end: the edges come in straight to a straight tip where the end was (the strap keeps
its length), the corners made rounded.

Fente d'ardillon (with Pointés et mèches): the slot for the buckle's tongue, along the strap's middle
line, its middle at the distance given from the end clicked; drawn for the cutting machine (its oblong
in Coupe intérieure), for two holes and two cuts with the cutter, or as the outline of an oblong punch
(mortaise). Shown under the mouse; one click in a strap piece near its end, or two on its edges; the
tool stays for the next strap (Échap ends it).

Sangle entière (with the strap ends): a strap in one go: its length from tip to tip, its width, its end
on the buckle's side and its far end (droit, rond, pointu, ceinture: as those tools are set), the holes
at the far end (Trous de ceinture) and the slot at the buckle's end (Fente d'ardillon). Two clicks: the
buckle's end, then the direction (ORTHO keeps it horizontal or vertical); the strap shows under the mouse."""
import math
import tkinter as tk
from tkinter import messagebox, ttk

import toron as toron_geometry


# --- Settings (remembered in the preferences) -----------------------------------------------------

def _settings(app, key, defaults):
    out = dict(defaults)
    saved = app.prefs.get(key) or {}
    out.update({k: v for k, v in saved.items() if k in defaults})
    return out


def belt_end(app):
    from editing import BELT_END
    return _settings(app, 'belt_end', BELT_END)


def slot(app):
    from editing import SLOT
    return _settings(app, 'buckle_slot', SLOT)


def piece(app):
    from editing import STRAP_PIECE
    return _settings(app, 'strap_piece', STRAP_PIECE)


def mm(v):
    return f'{v:g}'.replace('.', ',')


def _number(text):
    v = float(text.strip().replace(',', '.'))
    if not math.isfinite(v):
        raise ValueError
    return v


def form(app, title, rows, read, key, done=None):
    """A Craft window: ``rows`` = ('entry', label, name, text) / ('choice', label, name, [(value, label)],
    value) / ('check', label, name, bool, button) ; Entrée or Valider: ``read`` checks the strings and
    booleans (ValueError: a message, the window stays), the result is remembered in prefs[key], then
    ``done``."""
    win = app.dialog(title)
    panel = app.p['panel']
    box = tk.Frame(win, bg=panel)
    box.pack(fill='x', padx=16, pady=(14, 4))
    variables, fields, labels = {}, [], {}
    for r, row in enumerate(rows):
        kind, label, name = row[:3]
        if kind == 'check':
            variables[name] = tk.BooleanVar(value=bool(row[3]))
            labels[name] = tk.StringVar(value=label)
            options = dict(bg=panel, fg=app.p['ui_ink'], selectcolor=app.field_background(), activebackground=panel, font=('Segoe UI', 10))
            check = __import__('modern_style').make_check(box, textvariable=labels[name], variable=variables[name], **options)
            check.grid(row=r, column=0, columnspan=2, sticky='w', pady=3)
            if len(row) > 4 and row[4]:
                app.button(box, 'Régler…', lambda f=row[4], n=name: f(win, labels[n])).grid(row=r, column=2, sticky='e', padx=(8, 0), pady=3)
            continue
        app.label(box, label).grid(row=r, column=0, sticky='w', pady=3)
        if kind == 'choice':
            options = row[3]
            names = [text for _, text in options]
            current = next((text for value, text in options if value == row[4]), names[0])
            variables[name] = tk.StringVar(value=current)
            field = ttk.Combobox(box, textvariable=variables[name], values=names, width=24, state='readonly')
            field.grid(row=r, column=1, sticky='w', padx=8, pady=3)
            field._options = options
            fields.append(field)
        else:
            variables[name] = tk.StringVar(value=row[3])
            field = app.entry(box, variables[name], 9)
            field.grid(row=r, column=1, sticky='w', padx=8, pady=3)
            fields.append(field)

    def values():
        out = {}
        for row in rows:
            kind, _, name = row[:3]
            if kind == 'choice':
                out[name] = next((value for value, text in row[3] if text == variables[name].get()), row[3][0][0])
            else:
                out[name] = variables[name].get()
        return out

    def valid(e=None):
        try:
            chosen = read(values())
        except ValueError as exc:
            messagebox.showerror(title, str(exc), parent=win)
            return 'break'
        win.destroy()
        app.prefs[key] = chosen
        try:
            app.persist_preferences()
        except OSError:
            pass
        if done:
            done(chosen)
        app.canvas.focus_set()
        return 'break'
    for field in fields:
        field.bind('<Return>', valid)
        field.bind('<KP_Enter>', valid)
    win.bind('<Return>', valid)
    win.bind('<KP_Enter>', valid)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(8, 14))
    app.button(foot, 'Valider', valid).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', lambda: (win.destroy(), app.canvas.focus_set()))
    entries = [f for f in fields if not isinstance(f, ttk.Combobox)]
    if entries:
        entries[0].focus_set()
        entries[0].select_range(0, 'end')
    win._form = variables   # the tests fill it
    win._valid = valid
    return win


def _positive(values, name, label, low=0., high=100000., strict=True):
    try:
        v = _number(values[name])
    except (ValueError, OverflowError):
        raise ValueError(label + ' : un nombre en mm.')
    if (v <= low if strict else v < low) or v > high:
        raise ValueError(f'{label} : de {mm(low)} à {mm(high)} mm.' if not strict else f'{label} : plus de {mm(low)} mm, au plus {mm(high)} mm.')
    return v


# --- Bout de ceinture ---------------------------------------------------------------------------------

def belt_prompt(app):
    st = belt_end(app)
    return (f'Affinement {mm(st["taper"])} mm · bout {mm(st["tip"])} mm · arrondis {mm(st["round"])} mm · clic droit pour régler · '
            'cliquer le petit côté d’une pièce, ou ses deux bords près du bout.')


def belt_value(app):
    st = belt_end(app)
    return (st['taper'], st['tip'], st['round'])


def belt_dialog(app):
    st = belt_end(app)

    def read(v):
        return dict(taper=_positive(v, 'taper', 'Longueur de l’affinement', 0, 10000), tip=_positive(v, 'tip', 'Largeur du bout', 0, 1000),
                    round=_positive(v, 'round', 'Arrondi des angles', 0, 50, strict=False))

    def done(chosen):
        if app.tool.get() == 'strap_belt':
            app.status.set(belt_prompt(app))
    return form(app, 'Bout de ceinture', [('entry', 'Longueur de l’affinement (mm)', 'taper', mm(st['taper'])),
                                           ('entry', 'Largeur du bout (mm)', 'tip', mm(st['tip'])),
                                           ('entry', 'Arrondi des angles (mm)', 'round', mm(st['round']))], read, 'belt_end', done)


# --- Fente d'ardillon -------------------------------------------------------------------------------

def slot_prompt(app, more=''):
    from editing import SLOT_METHODS
    st = slot(app)
    how = dict(SLOT_METHODS).get(st['method'], '').split(' (')[0].lower()
    app.status.set(f'Fente {mm(st["length"])} × {mm(st["width"])} mm · milieu à {mm(st["distance"])} mm du bout · {how} · '
                   'clic droit pour régler · cliquer le bout de la sangle.' + more)


def slot_resume(app, more=''):
    app.tool.set('buckle_slot')
    app.last_command = ('tool', 'buckle_slot')
    app.slot_state = dict(first=None)
    app.canvas.delete('slot_preview')
    app.highlight_tools()
    slot_prompt(app, more)


def slot_start(app):
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    slot_resume(app)
    app.refresh()
    slot_dialog(app)


def slot_cancel(app):
    app.slot_state = None
    try:
        app.canvas.delete('slot_preview')
    except (AttributeError, tk.TclError):
        pass


def slot_dialog(app):
    from editing import SLOT_METHODS
    st = slot(app)

    def read(v):
        width = _positive(v, 'width', 'Largeur de la fente', 0, 30)
        length = _positive(v, 'length', 'Longueur de la fente', 0, 500)
        if length < width - 1e-9:
            raise ValueError('La fente est au moins aussi longue que large.')
        return dict(length=length, width=width, distance=_positive(v, 'distance', 'Distance du bout au milieu', 0, 100000, strict=False),
                    method=v['method'])

    def done(chosen):
        if app.tool.get() == 'buckle_slot':
            slot_prompt(app)
    return form(app, 'Fente d’ardillon', [('entry', 'Longueur de la fente (mm)', 'length', mm(st['length'])),
                                           ('entry', 'Largeur de la fente (mm)', 'width', mm(st['width'])),
                                           ('entry', 'Distance du bout au milieu de la fente (mm)', 'distance', mm(st['distance'])),
                                           ('choice', 'Tracé', 'method', SLOT_METHODS, st['method'])], read, 'buckle_slot', done)


def slot_found(app, i, p):
    """The slot's shapes for a click ``p`` on item ``i`` (the first edge already chosen counts); None
    when a second edge is needed. ValueError when the click is not on a strap."""
    from editing import strap_sides, side_of, parallel, slot_spot, slot_shapes
    st = slot(app)
    first = (app.__dict__.get('slot_state') or {}).get('first')
    s = app.items[i]
    if first is None:
        sides = strap_sides(s)
        if sides is not None:
            c, w = slot_spot(sides, [s], p, st['length'], st['width'], st['distance'])
            return slot_shapes(c, w, st['length'], st['width'], st['method'])
        if side_of(s, p) is not None:
            return None
        raise ValueError('Cliquer le bout d’une sangle (deux bords parallèles).')
    j, q = first
    if i == j:
        raise ValueError('Choisir l’autre bord de la sangle.')
    A, B = side_of(app.items[j], q), side_of(s, p)
    if A is None or B is None or not parallel(*A[0], *B[0]):
        raise ValueError('Choisir l’autre bord, parallèle au premier.')
    from advanced_edit import corner_links
    shapes = [app.items[j], s]
    shapes += [app.items[k] for k in corner_links(app.items, {i, j}, app.items[j], s, q, p)]
    c, w = slot_spot((A[0], B[0]), shapes, q, st['length'], st['width'], st['distance'])
    return slot_shapes(c, w, st['length'], st['width'], st['method'])


def same(a, b):
    """0.19.6: the same mark (name, kind, points within 0,01 mm)."""
    from geometry import path
    if a.get('name') != b.get('name') or a.get('kind') != b.get('kind'):
        return False
    pa, pb = path(a)[0], path(b)[0]
    return len(pa) == len(pb) and all(math.dist(x, y) < .01 for x, y in zip(pa, pb))


def slot_click(app, e):
    st = app.__dict__.get('slot_state')
    if st is None:
        return None
    from belt_holes_ui import strap_at
    p = app.raw(e)
    i = strap_at(app, p)
    if i is None:
        app.invalid_at(e, 'Cliquer le bout de la sangle.')
        return 'break'
    try:
        found = slot_found(app, i, p)
    except ValueError as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    if found is None:
        st['first'] = (i, p)
        app.status.set('Choisir l’autre bord de la sangle.')
        return 'break'
    if all(any(same(s, x) for x in app.items) for s in found):
        app.status.set('Cette fente est déjà là.')   # not twice (a double cut)
        return 'break'
    app.snapshot()
    app.items.extend(found)
    app.selected = None
    app.selected_set = set()
    slot_resume(app, ' Échap pour finir.')
    app.refresh()
    return 'break'


def slot_preview(app, e):
    app.canvas.delete('slot_preview')
    if app.__dict__.get('slot_state') is None:
        return
    from belt_holes_ui import strap_at
    p = app.raw(e)
    i = strap_at(app, p)
    if i is None:
        return
    try:
        found = slot_found(app, i, p)
    except (ValueError, IndexError, ZeroDivisionError):
        return
    try:
        for s in found or ():
            app.draw_shape(s, app.p['accent'], 1, ('slot_preview',))
    except (tk.TclError, ValueError, OverflowError):
        app.canvas.delete('slot_preview')


# --- Sangle entière -----------------------------------------------------------------------------------

def piece_prompt(app, more=''):
    from editing import STRAP_ENDS
    st = piece(app)
    names = dict(STRAP_ENDS)
    extra = ' + trous' * bool(st['holes']) + ' + fente' * bool(st['slot'])
    first = app.__dict__.get('strap_state') and app.strap_state.get('start')
    app.status.set(f'Sangle {mm(st["length"])} × {mm(st["width"])} mm · boucle {names[st["start"]].lower()} · bout {names[st["end"]].lower()}{extra} · '
                   + ('choisir la direction.' if first else 'clic droit pour régler · cliquer le bout côté boucle.') + more)


def piece_resume(app, more=''):
    app.tool.set('strap_piece')
    app.last_command = ('tool', 'strap_piece')
    app.strap_state = dict(start=None)
    app.canvas.delete('strap_preview')
    app.highlight_tools()
    piece_prompt(app, more)


def piece_start(app):
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    piece_resume(app)
    app.refresh()
    piece_dialog(app)


def piece_cancel(app):
    app.strap_state = None
    try:
        app.canvas.delete('strap_preview')
    except (AttributeError, tk.TclError):
        pass


def holes_text(app):
    import belt_holes_ui
    b = belt_holes_ui.settings(app)
    return f'Trous de ceinture ({b["count"]} trous, écart {mm(b["spacing"])} mm, le 1er à {mm(b["offset"])} mm)'


def slot_text(app):
    from editing import SLOT_METHODS
    st = slot(app)
    how = dict(SLOT_METHODS).get(st['method'], '').split(' (')[0].lower()
    return f'Fente d’ardillon ({mm(st["length"])} × {mm(st["width"])} mm, à {mm(st["distance"])} mm, {how})'


def piece_dialog(app):
    from editing import STRAP_ENDS
    st = piece(app)

    def tune(window, label, opener, text):
        sub = opener(app)
        window.wait_window(sub)
        if window.winfo_exists():
            window.grab_set()
            label.set(text(app))
            window.focus_force()   # Entrée validates this window again (the other one gave the plan the focus)
            first = next((w for w in window.winfo_children()[0].winfo_children() if w.winfo_class() == 'Entry'), None)
            if first is not None:
                first.focus_set()

    def read(v):
        length = _positive(v, 'length', 'Longueur totale', 0, 100000)
        width = _positive(v, 'width', 'Largeur', 0, 1000)
        fold = _positive(v, 'fold', 'Pli autour de la boucle', 0, 1000, strict=False)
        try:
            holes = int(v['fold_holes'].strip())
        except ValueError:
            raise ValueError('Pli : trous par épaisseur, de 0 à 3.')
        if not 0 <= holes <= 3:
            raise ValueError('Pli : trous par épaisseur, de 0 à 3.')
        return dict(length=length, width=width, start=v['start'], end=v['end'], holes=bool(v['holes']), slot=bool(v['slot']),
                    fold=fold, fold_holes=holes, fold_hole=_positive(v, 'fold_hole', 'Pli : diamètre des trous', 0, 30))

    def done(chosen):
        if app.tool.get() == 'strap_piece':
            piece_prompt(app)
    import belt_holes_ui
    return form(app, 'Sangle entière', [('entry', 'Longueur totale, bout à bout (mm)', 'length', mm(st['length'])),
                                         ('entry', 'Largeur (mm)', 'width', mm(st['width'])),
                                         ('choice', 'Bout côté boucle', 'start', STRAP_ENDS, st['start']),
                                         ('choice', 'Bout côté trous', 'end', STRAP_ENDS, st['end']),
                                         ('check', holes_text(app), 'holes', st['holes'], lambda w, l: tune(w, l, belt_holes_ui.dialog, holes_text)),
                                         ('check', slot_text(app), 'slot', st['slot'], lambda w, l: tune(w, l, slot_dialog, slot_text)),
                                         ('entry', 'Pli autour de la boucle : rabat (mm ; 0 = sans)', 'fold', mm(st['fold'])),
                                         ('entry', 'Pli : trous de vis / rivets par épaisseur (0 à 3)', 'fold_holes', str(int(st['fold_holes']))),
                                         ('entry', 'Pli : diamètre des trous (mm)', 'fold_hole', mm(st['fold_hole']))],
                read, 'strap_piece', done)


def piece_shapes(app, A, B):
    """The strap from A toward B (its buckle end at A), with its holes and its slot."""
    from editing import strap_piece, strap_sides, belt_hole_centres, drill_mark, slot_spot, slot_shapes
    st = piece(app)
    d = math.dist(A, B)
    if d < 1e-9:
        raise ValueError('Choisir la direction de la sangle.')
    w = ((B[0] - A[0]) / d, (B[1] - A[1]) / d)
    values = {'strap_round': app.__dict__.get('round_depth', 0.), 'strap_point': app.__dict__.get('point_length', 0.), 'strap_belt': belt_value(app)}
    fold = st.get('fold', 0.)
    # 0.19.13: the fold round the buckle: the flap added at the buckle's end (the length stays from the fold to
    # the far tip), the slot in the middle of the fold, the holes of each layer face to face once folded
    s = strap_piece(A, w, st['length'] + fold, st['width'], st['start'], st['end'], values)
    out = [s]
    sides = strap_sides(s)
    far = (A[0] + (st['length'] + fold) * w[0], A[1] + (st['length'] + fold) * w[1])
    if st['holes'] and sides:
        import belt_holes_ui
        b = belt_holes_ui.settings(app)
        out += [drill_mark(c, b['diameter']) for c in belt_hole_centres(sides, [s], far, b['count'], b['spacing'], b['offset'], b['diameter'])]
    if st['slot'] and sides:
        f = slot(app)
        c, u = slot_spot(sides, [s], A, f['length'], f['width'], fold if fold > 0 else f['distance'])
        out += slot_shapes(c, u, f['length'], f['width'], f['method'])
    if fold > 0 and st.get('fold_holes', 0) > 0 and sides:
        f = slot(app) if st['slot'] else dict(length=0.)
        lo, hi = 6. + st['fold_hole'] / 2, fold - f['length'] / 2 - 4. - st['fold_hole'] / 2
        if hi < lo:
            raise ValueError('Pli : rabat trop court pour la fente et les trous.')
        n = int(st['fold_holes'])
        spots = [(lo + hi) / 2] if n == 1 else [lo + (hi - lo) * k / (n - 1) for k in range(n)]
        for x in spots:
            for at in (x, 2 * fold - x):   # on the flap, and where it lands on the strap
                out.append(drill_mark((A[0] + at * w[0], A[1] + at * w[1]), st['fold_hole']))
    return out


def piece_aim(app, e):
    """The point of the direction: the cursor, on an anchor, or held horizontal or vertical by ORTHO
    (precision_ui.constraint_origin: from the buckle's end)."""
    return app.point(e)


def piece_click(app, e):
    st = app.__dict__.get('strap_state')
    if st is None:
        return None
    if st['start'] is None:
        st['start'] = app.point(e)
        piece_prompt(app)
        return 'break'
    try:
        shapes = piece_shapes(app, st['start'], piece_aim(app, e))
    except ValueError as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    s = shapes[0]
    s['profile'] = app.active_profile
    import copy
    s['style'] = dict(copy.deepcopy(app.profiles[app.active_profile]), color=getattr(app, 'drawing_color', 'auto'))
    app.snapshot()
    app.items.extend(shapes)
    app.selected = None
    app.selected_set = set()
    piece_resume(app, ' Échap pour finir.')
    app.refresh()
    return 'break'


def piece_preview(app, e):
    app.canvas.delete('strap_preview')
    st = app.__dict__.get('strap_state')
    if not st or st['start'] is None:
        return
    try:
        shapes = piece_shapes(app, st['start'], piece_aim(app, e))
    except (ValueError, ZeroDivisionError, IndexError):
        return
    try:
        for s in shapes:
            app.draw_shape(s, app.p['accent'], 1, ('strap_preview',))
    except (tk.TclError, ValueError, OverflowError):
        app.canvas.delete('strap_preview')


# --- 0.19.13 Passant -------------------------------------------------------------------------------------------
# « un outil Passant (la bande du passant à la bonne longueur pour la largeur et l'épaisseur de la sangle) »: the
# band goes round the strap and its end held under it (two thicknesses), its middle line ``thickness / 2`` out of
# them: 2 × width + 4 × strap thickness + 3,14 × passant thickness, the ease and the overlap of its join added.

PASSANT = dict(width=35., strap=3., thickness=1.2, band=12., ease=1., overlap=0.)


def passant(app):
    st = _settings(app, 'passant', PASSANT)
    if not app.prefs.get('passant'):
        st['width'] = piece(app)['width']   # the strap of Sangle entière
    return st


def passant_length(st):
    return 2 * st['width'] + 4 * st['strap'] + math.pi * st['thickness'] + st['ease'] + st['overlap']


def passant_shapes(app, c, st=None):
    """The passant's band, its middle at ``c`` (along x), named PASSANT, its length written."""
    st = st or passant(app)
    L, b = passant_length(st), st['band']
    piece = toron_geometry._piece([(c[0] - L / 2, c[1] - b / 2), (c[0] + L / 2, c[1] - b / 2), (c[0] + L / 2, c[1] + b / 2), (c[0] - L / 2, c[1] + b / 2)], 'Passant')
    text = toron_geometry._named(piece, 'PASSANT', 1, 2.5, _model(app), f'{mm(round(L, 1))} × {mm(b)} mm pour sangle {mm(st["width"])} × {mm(st["strap"])}')
    return [piece, text]


def passant_prompt(app, more=''):
    st = passant(app)
    app.status.set(f'Passant : {mm(round(passant_length(st), 1))} × {mm(st["band"])} mm (sangle {mm(st["width"])} × {mm(st["strap"])} mm) · '
                   'cliquer où le poser · clic droit pour régler.' + more)


def passant_resume(app, more=''):
    app.tool.set('passant')
    app.last_command = ('tool', 'passant')
    app.canvas.delete('strap_preview')
    app.highlight_tools()
    passant_prompt(app, more)


def passant_start(app):
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    passant_resume(app)
    app.refresh()
    passant_dialog(app)


def passant_dialog(app):
    st = passant(app)

    def read(v):
        return dict(width=_positive(v, 'width', 'Largeur de la sangle', 0, 1000), strap=_positive(v, 'strap', 'Épaisseur de la sangle', 0, 50),
                    thickness=_positive(v, 'thickness', 'Épaisseur du passant', 0, 20), band=_positive(v, 'band', 'Largeur du passant', 0, 200),
                    ease=_positive(v, 'ease', 'Aisance', 0, 50, strict=False), overlap=_positive(v, 'overlap', 'Recouvrement', 0, 100, strict=False))

    def done(chosen):
        if app.tool.get() == 'passant':
            passant_prompt(app)
    return form(app, 'Passant', [('entry', 'Largeur de la sangle (mm)', 'width', mm(st['width'])),
                                 ('entry', 'Épaisseur de la sangle (mm)', 'strap', mm(st['strap'])),
                                 ('entry', 'Épaisseur du cuir du passant (mm)', 'thickness', mm(st['thickness'])),
                                 ('entry', 'Largeur du passant (mm)', 'band', mm(st['band'])),
                                 ('entry', 'Aisance (mm)', 'ease', mm(st['ease'])),
                                 ('entry', 'Recouvrement de la jonction (mm ; 0 = bord à bord)', 'overlap', mm(st['overlap']))],
                read, 'passant', done)


def passant_click(app, e):
    shapes = passant_shapes(app, app.point(e))
    app.snapshot()
    app.items.extend(shapes)
    passant_resume(app, ' Échap pour finir.')
    app.refresh()
    return 'break'


def passant_preview(app, e):
    app.canvas.delete('strap_preview')
    try:
        for s in passant_shapes(app, app.point(e)):
            app.draw_shape(s, app.p['accent'], 1, ('strap_preview',))
    except (ValueError, tk.TclError):
        app.canvas.delete('strap_preview')


# --- 0.19.11 Poignée toron, 0.19.13 after the school's pattern (toron.py) -------------------------------------
# The window: the settings of the handle in two columns, its profiles (« TILTED (lycée) » first, then the ones saved
# by name: « top des profils de poignées »), the roll computed from the gap between the rings and the handle's height
# (« Longueur de poignée calculée »). Two clicks: one tip, then the direction. The preview: the handle computed once
# from its first tip, then only turned towards the mouse.

TORON = toron_geometry.TORON
PROFILE = toron_geometry.PROFILE


def _older(st, saved):
    """0.19.14: settings saved before the surcoupe piqûre: 0.19.13's TILTED (a toron of 18,6, my reading of the band of
    61,6 mm) is a toron of 5 with 21,4 a side (the same band); any other handle takes 10 mm a side."""
    if 'roll_allowance' in saved or not saved:
        return st
    if abs(float(saved.get('diameter', 18.6)) - 18.6) < 1e-6:
        st['diameter'], st['roll_allowance'] = TORON['diameter'], round(math.pi * (18.6 - TORON['diameter']) / 2, 1)
    else:
        st['roll_allowance'] = toron_geometry.ALLOWANCE
    return st


def toron(app):
    st = _older(_settings(app, 'toron', TORON), app.prefs.get('toron') or {})
    st['perfos_tip'], st['perfos_notch'] = int(st['perfos_tip']), int(st['perfos_notch'])
    return st


def toron_profiles(app):
    """{name: settings}: the school's first, then the ones saved."""
    out = {PROFILE: dict(TORON)}
    for name, saved in (app.prefs.get('toron_profiles') or {}).items():
        if name != PROFILE and isinstance(saved, dict):
            out[name] = _older(dict(TORON, **{k: v for k, v in saved.items() if k in TORON}), saved)
    return out


def _model(app):
    return (getattr(app, 'project_model', '') or '').strip()


def toron_local(app, st=None):
    """The handle's pieces in its own axes (its first tip at 0, along x)."""
    st = toron_geometry.check(dict(st or toron(app)))
    return toron_geometry.items(st, _model(app))


def _placed(shapes, A, B):
    from transform import transform, moved
    d = math.dist(A, B)
    if d < 1e-9:
        raise ValueError('Choisir la direction de la poignée.')
    angle = -math.degrees(math.atan2(B[1] - A[1], B[0] - A[0]))
    out = []
    for s in shapes:
        q = transform(s, (0., 0.), angle) if abs(angle) > 1e-12 else s
        out.append(moved(q, A[0], A[1]))
    return out


def toron_shapes(app, A, B, st=None):
    """The handle from A toward B (its first tip at A)."""
    return _placed(toron_local(app, st), A, B)


def toron_prompt(app, more=''):
    st = toron(app)
    first = app.__dict__.get('strap_state') and app.strap_state.get('start')
    total = toron_geometry.total_length(st)
    app.status.set(f'Poignée toron : toron Ø {mm(st["diameter"])}, roulé {mm(round(st["length"], 1))} mm, '
                   f'pièce {mm(round(toron_geometry.roll_width(st), 1))} × {mm(round(total, 1))} mm · '
                   + ('choisir la direction.' if first else 'clic droit pour régler · cliquer un bout.') + more)


def toron_resume(app, more=''):
    app.tool.set('toron')
    app.last_command = ('tool', 'toron')
    app.strap_state = dict(start=None)
    app.canvas.delete('strap_preview')
    app.highlight_tools()
    toron_prompt(app, more)


def toron_start(app):
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    toron_resume(app)
    app.refresh()
    toron_dialog(app)


TORON_FIELDS = [   # (column, kind, label, key, choices); 0.19.14: his words (Toron, Roulé, Pattes), the two surcoupes
    (0, 'entry', 'Toron : diamètre (mm)', 'diameter', None),
    (0, 'entry', 'Épaisseur du cuir (mm)', 'thickness', None),
    (0, 'entry', 'Roulé : longueur sur le toron, d’un arrondi à l’autre (mm)', 'length', None),
    (0, 'entry', 'ou : écart entre les anneaux (mm ; 0 = longueur tapée)', 'ring_gap', None),
    (0, 'entry', 'et hauteur de la poignée (mm)', 'height', None),
    (0, 'entry', 'Courbe : milieu au-dessus des bouts (mm ; 0 = droite)', 'bow', None),
    (0, 'entry', 'Surcoupe piqûre, par bord du roulé (mm)', 'roll_allowance', None),
    (0, 'entry', 'Surcoupe encollage, toute la pièce (mm ; 0 = sans)', 'precut', None),
    (0, 'entry', 'Renfort de la poignée : largeur (mm ; 0 = sans)', 'renfort', None),
    (1, 'choice', 'Pattes : forme', 'end', toron_geometry.ENDS),
    (1, 'entry', 'Pattes : longueur, du bout à l’arrondi (mm ; 0 = sans pattes)', 'tab_length', None),
    (1, 'entry', 'Pattes : largeur (mm)', 'tab_width', None),
    (1, 'entry', 'Arrondi roulé → patte : rayon (mm)', 'notch', None),
    (1, 'entry', 'Pointe en ogive (sur anneau) : rayon (mm)', 'tip', None),
    (1, 'entry', 'Points par cm (perfos ou piqûre)', 'points', None),
    (1, 'entry', 'Distance au bord (mm)', 'distance', None),
    (1, 'entry', 'Perfos par côté, vers le bout de la patte', 'perfos_tip', None),
    (1, 'entry', 'Perfos par côté, le long de l’arrondi', 'perfos_notch', None),
    (1, 'entry', 'Enchapes (sur anneau) : largeur (mm ; 0 = sans)', 'enchape', None),
    (1, 'entry', 'Enchapes : longueur sur le sac, du pli à la pointe (mm)', 'enchape_length', None),
    (1, 'choice', 'Enchapes : bout', 'enchape_end', toron_geometry.ENCHAPE_ENDS),
    (1, 'check', 'Enchapes : avec renfort', 'enchape_renfort', None),
    (1, 'check', 'Enchapes : avec doublure', 'enchape_doublure', None)]


def toron_read(values):
    """The settings typed in the window (ValueError: what to change)."""
    p = _positive
    st = dict(diameter=p(values, 'diameter', 'Toron : diamètre', 0, 200), thickness=p(values, 'thickness', 'Épaisseur du cuir', 0, 20),
              length=p(values, 'length', 'Roulé : longueur', 0, 5000), ring_gap=p(values, 'ring_gap', 'Écart entre les anneaux', 0, 2000, strict=False),
              height=p(values, 'height', 'Hauteur de la poignée', 0, 2000, strict=False), bow=p(values, 'bow', 'Courbe', 0, 1000, strict=False),
              roll_allowance=p(values, 'roll_allowance', 'Surcoupe piqûre', 0, 200, strict=False),
              precut=p(values, 'precut', 'Surcoupe encollage', 0, 200, strict=False), renfort=p(values, 'renfort', 'Renfort de la poignée', 0, 1000, strict=False),
              end=values['end'], tab_length=p(values, 'tab_length', 'Pattes : longueur', 0, 1000, strict=False),
              tab_width=p(values, 'tab_width', 'Pattes : largeur', 0, 500), notch=p(values, 'notch', 'Arrondi roulé → patte : rayon', 0, 1000, strict=False),
              tip=p(values, 'tip', 'Pointe en ogive : rayon', 0, 1000, strict=False), points=p(values, 'points', 'Points par cm', .5, 20, strict=False),
              distance=p(values, 'distance', 'Distance au bord', 0, 50, strict=False),
              perfos_tip=p(values, 'perfos_tip', 'Perfos vers le bout', 0, 50, strict=False),
              perfos_notch=p(values, 'perfos_notch', 'Perfos le long des encoches', 0, 50, strict=False),
              enchape=p(values, 'enchape', 'Enchapes : largeur', 0, 300, strict=False),
              enchape_length=p(values, 'enchape_length', 'Enchapes : longueur sur le sac', 0, 500), enchape_end=values['enchape_end'],
              enchape_renfort=bool(values['enchape_renfort']), enchape_doublure=bool(values['enchape_doublure']))
    if 0 < st['precut'] < .5:
        raise ValueError('Surcoupe encollage : 0 (sans) ou de 0,5 à 200 mm.')
    for key, label in (('perfos_tip', 'Perfos vers le bout'), ('perfos_notch', 'Perfos le long des encoches')):
        if st[key] != int(st[key]):
            raise ValueError(label + ' : un nombre entier.')
        st[key] = int(st[key])
    if st['ring_gap'] > 0:
        st['length'] = round(toron_geometry.length_for_rings(st, st['ring_gap'], st['height']), 1)
    return toron_geometry.check(st)


def toron_dialog(app):
    """The settings in two columns, the profiles on top (Entrée or Valider: kept, then the tool goes on)."""
    from tkinter import simpledialog
    st = toron(app)
    win = app.dialog('Poignée toron')
    panel = app.p['panel']
    top = tk.Frame(win, bg=panel)
    top.pack(fill='x', padx=16, pady=(14, 4))
    app.label(top, 'Profil').pack(side='left')
    profile = tk.StringVar(value=app.prefs.get('toron_profile') if app.prefs.get('toron_profile') in toron_profiles(app) else PROFILE)
    chooser = ttk.Combobox(top, textvariable=profile, values=list(toron_profiles(app)), width=24, state='readonly')
    chooser.pack(side='left', padx=8)
    body = tk.Frame(win, bg=panel)
    body.pack(fill='x', padx=16, pady=4)
    columns = [tk.Frame(body, bg=panel) for _ in (0, 1)]
    for k, c in enumerate(columns):
        c.grid(row=0, column=k, sticky='nw', padx=(0, 24) if k == 0 else 0)
    variables, rows, fields = {}, [0, 0], []
    for col, kind, label, key, choices in TORON_FIELDS:
        box, r = columns[col], rows[col]
        rows[col] += 1
        if kind == 'check':
            variables[key] = tk.BooleanVar(value=bool(st[key]))
            options = dict(bg=panel, fg=app.p['ui_ink'], selectcolor=app.field_background(), activebackground=panel, font=('Segoe UI', 10))
            __import__('modern_style').make_check(box, text=label, variable=variables[key], **options).grid(row=r, column=0, columnspan=2, sticky='w', pady=3)
            continue
        app.label(box, label).grid(row=r, column=0, sticky='w', pady=3)
        if kind == 'choice':
            variables[key] = tk.StringVar(value=next((text for value, text in choices if value == st[key]), choices[0][1]))
            field = ttk.Combobox(box, textvariable=variables[key], values=[text for _, text in choices], width=20, state='readonly')
        else:
            variables[key] = tk.StringVar(value=mm(st[key]))
            field = app.entry(box, variables[key], 8)
        field.grid(row=r, column=1, sticky='w', padx=8, pady=3)
        fields.append(field)

    def values():
        out = {}
        for col, kind, label, key, choices in TORON_FIELDS:
            v = variables[key].get()
            out[key] = next((value for value, text in choices if text == v), choices[0][0]) if kind == 'choice' else v
        return out

    def fill(settings):
        for col, kind, label, key, choices in TORON_FIELDS:
            if kind == 'check':
                variables[key].set(bool(settings[key]))
            elif kind == 'choice':
                variables[key].set(next((text for value, text in choices if value == settings[key]), choices[0][1]))
            else:
                variables[key].set(mm(settings[key]))

    chooser.bind('<<ComboboxSelected>>', lambda e: fill(toron_profiles(app)[profile.get()]))

    def keep():
        try:
            app.persist_preferences()
        except OSError:
            pass

    def save_as():
        try:
            chosen = toron_read(values())
        except ValueError as exc:
            messagebox.showerror('Poignée toron', str(exc), parent=win)
            return
        name = simpledialog.askstring('Profil de poignée', 'Nom du profil :', parent=win)
        name = (name or '').strip()[:40]
        if not name:
            return
        if name == PROFILE:
            messagebox.showerror('Profil de poignée', 'Ce nom est celui du profil du lycée : en choisir un autre.', parent=win)
            return
        app.prefs.setdefault('toron_profiles', {})[name] = chosen
        app.prefs['toron_profile'] = name
        keep()
        chooser.configure(values=list(toron_profiles(app)))
        profile.set(name)

    def remove():
        name = profile.get()
        if name == PROFILE or name not in (app.prefs.get('toron_profiles') or {}):
            messagebox.showinfo('Profil de poignée', 'Le profil du lycée reste toujours.', parent=win)
            return
        if not messagebox.askokcancel('Profil de poignée', f'Supprimer le profil « {name} » ?', parent=win):
            return
        app.prefs['toron_profiles'].pop(name, None)
        app.prefs['toron_profile'] = PROFILE
        keep()
        chooser.configure(values=list(toron_profiles(app)))
        profile.set(PROFILE)
        fill(toron_profiles(app)[PROFILE])

    def rename():
        # 0.19.14 (« une fois enregistré et que l'on a plusieurs profils, tu peux mettre … à côté et option renommer »)
        import base_profiles
        old = profile.get()
        own = app.prefs.get('toron_profiles') or {}
        if old == PROFILE or old not in own:
            return
        name = base_profiles.renamed(app, win, 'Profil de poignée', old, set(toron_profiles(app)))
        if not name:
            return
        app.prefs['toron_profiles'] = {(name if k == old else k): v for k, v in own.items()}
        if app.prefs.get('toron_profile') == old:
            app.prefs['toron_profile'] = name
        keep()
        chooser.configure(values=list(toron_profiles(app)))
        profile.set(name)

    def entries():
        own = profile.get() != PROFILE and profile.get() in (app.prefs.get('toron_profiles') or {})
        return [('Enregistrer sous…', save_as, True), ('Renommer…', rename, own), ('Supprimer…', remove, own)]
    __import__('base_profiles').more_menu(app, top, entries).pack(side='left')

    def valid(e=None):
        try:
            chosen = toron_read(values())
            toron_geometry.items(dict(chosen), _model(app))   # 0.19.14: a handle that cannot be made is said here, not at each mouse move
        except ValueError as exc:
            messagebox.showerror('Poignée toron', str(exc), parent=win)
            return 'break'
        win.destroy()
        app.prefs['toron'] = chosen
        app.prefs['toron_profile'] = profile.get()
        keep()
        if app.tool.get() == 'toron':
            toron_prompt(app, f' Longueur roulée calculée : {mm(chosen["length"])} mm.' if chosen['ring_gap'] > 0 else '')
        app.canvas.focus_set()
        return 'break'
    win.bind('<Return>', valid)
    win.bind('<KP_Enter>', valid)
    for field in fields:
        field.bind('<Return>', valid)
        field.bind('<KP_Enter>', valid)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(8, 14))
    app.button(foot, 'Valider', valid).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', lambda: (win.destroy(), app.canvas.focus_set()))
    win._toron = dict(variables=variables, profile=profile, chooser=chooser, valid=valid, save_as=save_as, remove=remove, fill=fill, rename=rename, entries=entries)
    entries = [f for f in fields if not isinstance(f, ttk.Combobox)]
    if entries:
        entries[0].focus_set()
        entries[0].select_range(0, 'end')
    return win


def toron_click(app, e):
    st = app.__dict__.get('strap_state')
    if st is None:
        return None
    if st['start'] is None:
        st['start'] = app.point(e)
        toron_prompt(app)
        return 'break'
    try:
        shapes = toron_shapes(app, st['start'], app.point(e))
    except ValueError as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    app.snapshot()   # 0.19.13: pieces in Coupe extérieure (the précoupe with its contour inside), named
    app.items.extend(shapes)
    app.selected = None
    app.selected_set = set()
    toron_resume(app, ' Échap pour finir.')
    app.refresh()
    return 'break'


def toron_preview(app, e):
    """The handle computed once from its first tip (the settings kept), then only turned toward the mouse. 0.19.14: a
    handle that cannot be made is computed once too (it was computed again at each mouse move: « ça devient énormément
    laggy »), its reason said once."""
    app.canvas.delete('strap_preview')
    st = app.__dict__.get('strap_state')
    if not st or st['start'] is None:
        return
    try:
        A, B = st['start'], app.point(e)
        if math.dist(A, B) < 1e-9:
            return
        settings = toron(app)
        key = (repr(sorted(settings.items())), _model(app))
        if st.get('preview_key') != key:
            st['preview_key'], st['preview_shapes'] = key, None
            try:
                st['preview_shapes'] = toron_local(app, settings)
            except ValueError as exc:
                app.status.set(f'Poignée toron impossible : {exc} (clic droit pour régler)')
        if st['preview_shapes'] is None:
            return
        for q in _placed(st['preview_shapes'], A, B):
            app.draw_shape(q, app.p['accent'], 1, ('strap_preview',))
    except (ValueError, ZeroDivisionError, IndexError, tk.TclError, OverflowError):
        app.canvas.delete('strap_preview')
