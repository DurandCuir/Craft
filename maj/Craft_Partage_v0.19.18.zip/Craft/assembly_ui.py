"""0.19.13 Contrôle d'assemblage (« assemblages en 2D », 07/11: « tu calcules par rapport à l'épaisseur qu'aura sur
les assemblages la personne, mais ça il faudrait savoir quelle pièce va où et sur quoi »).

A click on the edge of a piece takes its side (between two corners, as the stitches cut a line: a smooth round
piece is one side); Maj + click adds the next side. A click on another piece takes the edge sewn on it (Maj + click:
its next side too). The window says both lengths and their difference, the crans in front of each other (the edges
taken in the direction that puts the most crans in front), the thickness at the seam (the refentes of both pieces,
1 mm when a piece has none; it can be typed), the points of the seam (points per cm of the Piqûre) and the thread
of a lock stitch: at each point, the length of the point and the thickness, for each of the two threads, without
margin. « Écrire sur le plan » leaves it written by the first edge; Entrée starts a new check; Échap ends.

0.19.14: the bag is sewn with the pieces surcoupées, not their précoupe (« ça va être avec les surcoupes que le sac sera
assemblé »): a click on a précoupe takes the side of its piece inside. The thickness at the seam follows the parage
of the edge: biseau, the middle of the bevel (« ça tombe au milieu du biseau »: between the edge and the leather);
rembord, the flap pared and folded on the leather itself (his way: leather + pared), or pared over twice its width
(2 × pared, to tick); another parage, its thickness; the renforts and doublures of the piece (by their names: RENFORT
FACE, DBL FACE…) are offered to tick."""
import math
import tkinter as tk

COLORS = ('#ff9f1c', '#2ec4b6')
TOLERANCE = 1.   # mm: a cran in front of another one


def _pieces(app):
    """The edges that are sewn: the pieces (Coupe extérieure) but not the précoupes, and the pieces inside them."""
    from entity_rules import closed_piece
    from craft_tools import style
    import surcoupe
    out = []
    hidden = __import__('preparation_ui').hidden_ids(app) if hasattr(app, 'prefs') else set()   # 0.19.14: layers hidden
    for k, s in enumerate(app.items):
        if not closed_piece(s) or s.get('annotation') or k in hidden:
            continue
        role = style(s)['role']
        if role == 'external' and not surcoupe.is_precut(s) or role == surcoupe.ROLE and s.get('owner_id'):
            out.append(k)
    return out


def _precuts(app):
    import surcoupe
    hidden = __import__('preparation_ui').hidden_ids(app)   # 0.19.14: a hidden précoupe is not clicked
    return [k for k, s in enumerate(app.items) if surcoupe.is_precut(s) and k not in hidden]


def host(app, k):
    """The piece that carries the data of ``k`` (its précoupe for a piece inside one)."""
    s = app.items[k]
    if s.get('piece_id') or not s.get('owner_id'):
        return s
    return next((q for q in app.items if q.get('piece_id') == s['owner_id']), s)


_CACHE = {}


def sides(piece):
    """[(points, start distance along the contour, length)] between the corners, and the contour's length (kept for
    the same piece: the mouse moves over them)."""
    hit = _CACHE.get(id(piece))
    if hit is not None and hit[0] is piece:
        return hit[1]
    import stitching
    from geometry import path
    from craft_tools import locate
    pts, closed = path(piece)
    out = []
    for run in stitching._runs(pts, closed):
        length = sum(math.dist(a, b) for a, b in zip(run, run[1:]))
        if length > 1e-6:
            out.append((run, locate(piece, run[0])[0], length))
    value = (out, sum(r[2] for r in out))
    if len(_CACHE) > 500:
        _CACHE.clear()
    _CACHE[id(piece)] = (piece, value)
    return value


def _gap(p, run):
    best = 1e18
    for a, b in zip(run, run[1:]):
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = dx * dx + dy * dy
        t = 0 if L == 0 else max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L))
        best = min(best, math.dist(p, (a[0] + t * dx, a[1] + t * dy)))
    return best


def side_at(app, p, reach):
    """(piece index, side index) of the side nearest ``p`` within ``reach`` mm, or None. 0.19.14: on a précoupe, the
    nearest side of the piece inside it."""
    from geometry import bounds
    best = None
    for k in _pieces(app):
        s = app.items[k]
        x, y, X, Y = bounds([s])
        if not (x - reach <= p[0] <= X + reach and y - reach <= p[1] <= Y + reach):
            continue
        for i, (run, start, length) in enumerate(sides(s)[0]):
            d = _gap(p, run)
            if d <= reach and (best is None or d < best[0]):
                best = (d, k, i)
    if best:
        return best[1:]
    import surcoupe
    shown = set(_pieces(app))
    for k in _precuts(app):
        s = app.items[k]
        x, y, X, Y = bounds([s])
        if not (x - reach <= p[0] <= X + reach and y - reach <= p[1] <= Y + reach):
            continue
        if min(_gap(p, run) for run, _, _ in sides(s)[0]) > reach:
            continue
        for j in surcoupe.inner_contours(app.items, k):
            if j not in shown:
                continue
            for i, (run, start, length) in enumerate(sides(app.items[j])[0]):
                d = _gap(p, run)
                if best is None or d < best[0]:
                    best = (d, j, i)
    return best[1:] if best else None


def portion(app, chosen):
    """(points, start, length, total) of the sides ``chosen`` = (piece, [side indices]) taken in the contour's order."""
    k, ids = chosen
    runs, total = sides(app.items[k])
    ids = sorted(ids)
    # contiguous through the end of the contour (the last side then the first ones)
    n = len(runs)
    if len(ids) > 1 and ids[0] == 0 and ids[-1] == n - 1:
        cut = next(i for i in range(1, len(ids)) if ids[i] != ids[i - 1] + 1) if any(ids[i] != ids[i - 1] + 1 for i in range(1, len(ids))) else len(ids)
        ids = ids[cut:] + ids[:cut]
    pts, length = [], 0.
    for i in ids:
        pts += runs[i][0] if not pts else runs[i][0][1:]
        length += runs[i][2]
    return pts, runs[ids[0]][1], length, total


def adjacent(app, chosen, i):
    k, ids = chosen
    n = len(sides(app.items[k])[0])
    return any((i - j) % n in (1, n - 1) for j in ids)


def crans(app, k, start, length, total):
    """The crans of piece ``k`` on the portion: their distances from its start (0.19.14: a piece inside a précoupe, the
    crans of its précoupe on its contour)."""
    from craft_tools import cran_mark
    piece = app.items[k]
    owner = piece.get('piece_id') or piece.get('owner_id')
    out = []
    for s in app.items:
        if s.get('is_notch') and s.get('owner_id') and s.get('owner_id') == owner:
            mark = cran_mark(s, piece)
            if mark is not None:
                d = (mark['distance'] - start) % total if total else 0.
                if d <= length + .05:
                    out.append(min(d, length))
    return sorted(out)


def facing(a, la, b, lb):
    """(crans in front of each other, b reversed or not): the direction that puts the most of them in front."""
    def count(bs):
        left, n = list(bs), 0
        for x in a:
            hit = next((y for y in left if abs(x - y) <= TOLERANCE), None)
            if hit is not None:
                left.remove(hit)
                n += 1
        return n
    same, back = count(b), count([lb - y for y in b])
    return (back, True) if back > same else (same, False)


def thickness(app, k):
    """The refente of piece ``k`` in mm (« refente 10/10 » = 1 mm), None when it has none."""
    info = (host(app, k).get('piece_info') or {}).get('material') or {}
    try:
        v = float(str(info.get('refente', '')).replace(',', '.'))
    except ValueError:
        return None
    return v / 10 if v > 0 else None


def _along(pts, step=2.):
    """Points every ``step`` mm along a line."""
    out = []
    for a, b in zip(pts, pts[1:]):
        n = max(1, int(math.dist(a, b) / step))
        out += [(a[0] + (b[0] - a[0]) * j / n, a[1] + (b[1] - a[1]) * j / n) for j in range(n)]
    return out + pts[-1:]


def parage(app, k, pts):
    """The parage zone along most of the edge ``pts`` of piece ``k`` (its préparation data), or None."""
    from geometry import path
    import preparations as prep
    owners = {app.items[k].get('piece_id'), app.items[k].get('owner_id'), host(app, k).get('piece_id')} - {None}
    samples = _along(pts)
    best = None
    for s in app.items:
        data = s.get('preparation')
        if not data or data.get('kind') != 'parage' or s.get('owner_id') not in owners:
            continue
        try:
            ring = path(s)[0]
        except (ValueError, KeyError, TypeError):
            continue
        near = sum(1 for q in samples if prep.inside(ring, q) or _gap(q, ring + ring[:1]) < .3)
        if near >= len(samples) / 2 and (best is None or near > best[0]):
            best = (near, data)
    return best[1] if best else None


def edge_thickness(app, k, pts, double=False):
    """(thickness at the seam in mm, what it is made of, the refente known, a rembord found) of the edge ``pts``."""
    leather = thickness(app, k)
    e = leather if leather is not None else 1.
    data = parage(app, k, pts)
    if not data:
        return e, f'cuir {_mm(e, 2)}', leather is not None, False
    kind = str(data.get('type') or '').upper()
    try:
        t = float(data.get('thickness')) / 10
    except (TypeError, ValueError):
        t = None
    if not t or t <= 0:
        return e, f'cuir {_mm(e, 2)} (parage {kind.lower() or "sans épaisseur"} : épaisseur non donnée)', leather is not None, 'REMBORD' in kind
    if 'BISEAU' in kind:
        return (e + t) / 2, f'parage biseau à {_mm(t, 2)} : milieu du biseau {_mm((e + t) / 2, 2)}', leather is not None, False
    if 'REMBORD' in kind:
        if double:
            return 2 * t, f'rembord paré à {_mm(t, 2)}, plié : 2 × {_mm(t, 2)}', leather is not None, True
        return e + t, f'rembord paré à {_mm(t, 2)}, plié sur le cuir : {_mm(e, 2)} + {_mm(t, 2)}', leather is not None, True
    return t, f'parage {kind.lower()} à {_mm(t, 2)}', leather is not None, False


def _name(s):
    info = (s.get('piece_info') or {}).get('part_name') or {}
    values = info.get('values') or []
    return ' '.join(str(v) for v in values if v).strip().upper() or str(s.get('name') or '').strip().upper()


LAYER_WORDS = ('RENFORT', 'RFT', 'DOUBLURE', 'DBL', 'NON TISSE', 'NON TISSÉ')


def layers(app, k):
    """The renforts and doublures of piece ``k`` found by their names (« RENFORT FACE », « DBL FACE » for FACE):
    [(index, name, thickness in mm or None)]."""
    import re
    name = _name(host(app, k))
    if not name:
        return []
    word = re.compile(r'(^|\W)' + re.escape(name) + r'(\W|$)')
    out = []
    for j in _pieces(app):
        other = _name(host(app, j))
        if j == k or other == name or not word.search(other) or not any(w in other for w in LAYER_WORDS):
            continue
        if any(other == o for _, o, _ in out):
            continue
        out.append((j, other, thickness(app, j)))
    return out


def thread(length, points, thick):
    """(points, thread in mm) of a lock stitch ``length`` mm long: each of the two threads lies along each point
    (10 / points per cm) and crosses the thickness once at each point."""
    n = max(1, round(length * points / 10))
    step = 10 / points
    return n, n * 2 * (step + thick)


def result(app):
    """The numbers of the check (None while the second edge is not chosen)."""
    st = app.__dict__.get('assembly_state') or {}
    if not st.get('a') or not st.get('b'):
        return None
    pa, sa, la, ta = portion(app, st['a'])
    pb, sb, lb, tb = portion(app, st['b'])
    ca, cb = crans(app, st['a'][0], sa, la, ta), crans(app, st['b'][0], sb, lb, tb)
    front, reversed_ = facing(ca, la, cb, lb)
    double = bool(st.get('double'))
    ta_, da, ka, ra = edge_thickness(app, st['a'][0], pa, double)
    tb_, db, kb, rb = edge_thickness(app, st['b'][0], pb, double)
    found = layers(app, st['a'][0]) + [x for x in layers(app, st['b'][0]) if x[0] not in {y[0] for y in layers(app, st['a'][0])}]
    ticked = [x for x in found if x[0] in (st.get('layers') or set())]
    extra = sum(x[2] if x[2] is not None else 1. for x in ticked)
    thick = st.get('thickness') if st.get('thickness') is not None else ta_ + tb_ + extra
    points = st.get('points') or round(10 / app.prefs.get('stitch_pitch', 10 / 3), 2)
    n, fil = thread(max(la, lb), points, thick)
    return dict(la=la, lb=lb, diff=la - lb, ca=len(ca), cb=len(cb), front=front, reversed=reversed_, thickness=thick,
                known=(ka, kb), points=points, n=n, thread=fil, a=pa, b=pb, made=(da, db), rembord=ra or rb, layers=found)


def _mm(v, digits=1):
    return f'{round(v, digits):g}'.replace('.', ',')


def summary(r):
    return (f'{_mm(r["la"])} / {_mm(r["lb"])} mm (écart {_mm(abs(r["diff"]))}) · crans {r["front"]} en face sur {r["ca"]} / {r["cb"]}'
            f' · {r["n"]} points · fil ≈ {_mm(r["thread"] / 10, 0)} cm')


# --- the tool -----------------------------------------------------------------------------------------------------

def start(app):
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    app.tool.set('assembly')
    app.last_command = ('tool', 'assembly')
    app.assembly_state = dict(a=None, b=None, thickness=None, points=None)
    app.highlight_tools()
    prompt(app)
    app.refresh()


def resume(app):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return start(app)
    st.update(a=None, b=None)
    prompt(app)
    draw(app)


def prompt(app):
    st = app.assembly_state
    if not st.get('a'):
        app.status.set("Contrôle d'assemblage : cliquer le bord de la 1re pièce (Maj + clic : ajouter le côté suivant).")
    elif not st.get('b'):
        app.status.set("Cliquer le bord cousu dessus, sur l'autre pièce (Maj + clic : ajouter un côté ; Entrée : même pièce).")
    else:
        r = result(app)
        app.status.set('Assemblage : ' + summary(r) + ' · Entrée : nouveau contrôle.')


def _reach(app):
    return 8 / max(app.scale, 1e-9)


def hover(app, e):
    draw(app, side_at(app, app.raw(e), _reach(app)))


def draw(app, under=None):
    c = app.canvas
    c.delete('assembly_preview')
    st = app.__dict__.get('assembly_state') or {}
    for key, color in zip(('a', 'b'), COLORS):
        if st.get(key):
            pts = portion(app, st[key])[0]
            c.create_line(*[v for p in pts for v in app.to_screen(p)], fill=color, width=5, capstyle='round', tags=('assembly_preview',))
    if under is not None:
        run = sides(app.items[under[0]])[0][under[1]][0]
        c.create_line(*[v for p in run for v in app.to_screen(p)], fill=app.p.get('accent', '#61c9ee'), width=3, dash=(6, 4), tags=('assembly_preview',))


def click(app, e):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return None
    found = side_at(app, app.raw(e), _reach(app))
    if found is None:
        app.invalid_at(e, 'Cliquer le bord d’une pièce (Coupe extérieure).')
        return 'break'
    k, i = found
    shift = bool(getattr(e, 'state', 0) & 1)

    def grow(key):
        """Maj + click on a side of the same piece: added if it follows, removed if it was taken."""
        k0, ids = st[key]
        if i in ids:
            if len(ids) > 1:
                ids.remove(i)
        elif adjacent(app, st[key], i):
            ids.append(i)
    if not st.get('a'):
        st.update(a=(k, [i]), thickness=None)   # 0.19.14: a thickness typed is for its own check
    elif not st.get('b'):
        if k == st['a'][0] and not st.get('switched'):
            if shift:
                grow('a')
            else:
                st.update(a=(k, [i]), thickness=None)
        else:
            st.update(b=(k, [i]), thickness=None)
    elif shift and k == st['b'][0]:
        grow('b')
    elif shift and k == st['a'][0]:
        grow('a')
    else:   # a new check from this edge
        st.update(a=(k, [i]), b=None, switched=False, thickness=None)
    prompt(app)
    draw(app)
    if st.get('b'):
        window(app)
    return 'break'


def enter(app):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return 'break'
    if st.get('a') and not st.get('b'):
        st['switched'] = True   # the second edge on the same piece
        app.status.set("Cliquer le bord cousu dessus (sur la même pièce ou une autre).")
        return 'break'
    st.update(a=None, b=None, switched=False, thickness=None)
    prompt(app)
    draw(app)
    return 'break'


def write(app):
    """The check written on the plan, by the middle of the first edge."""
    from craft_tools import annotation
    r = result(app)
    if r is None:
        return None
    pts = r['a']
    half, travel, at = r['la'] / 2, 0., pts[0]
    for a, b in zip(pts, pts[1:]):
        seg = math.dist(a, b)
        if travel + seg >= half:
            t = (half - travel) / seg if seg else 0
            at = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            break
        travel += seg
    text = annotation('Assemblage : ' + summary(r), (at[0] + 2, at[1] + 2), 2.5)
    text['assembly'] = dict(la=round(r['la'], 2), lb=round(r['lb'], 2), front=r['front'], points=r['points'], thickness=r['thickness'])
    app.snapshot()
    app.items.append(text)
    app.refresh()
    draw(app)
    return text


def window(app):
    """The numbers of the check, kept up to date; the thickness and the points per cm can be typed."""
    from tkinter import messagebox
    old = app.__dict__.get('_assembly_window')
    if old is not None and old.winfo_exists():
        old._refill()
        return old
    win = app.dialog("Contrôle d'assemblage")
    try:
        win.grab_release()
    except tk.TclError:
        pass
    app._assembly_window = win
    panel = app.p['panel']
    box = tk.Frame(win, bg=panel)
    box.pack(fill='x', padx=16, pady=(14, 4))
    labels = {}
    for row, (key, text) in enumerate((('a', 'Bord 1'), ('b', 'Bord 2'), ('diff', 'Écart'), ('crans', 'Crans en face'), ('n', 'Points'), ('thread', 'Fil (2 fils, sans marge)'))):
        app.label(box, text).grid(row=row, column=0, sticky='w', pady=2)
        labels[key] = tk.StringVar()
        tk.Label(box, textvariable=labels[key], bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 10, 'bold')).grid(row=row, column=1, sticky='w', padx=10)
    thick, points = tk.StringVar(), tk.StringVar()
    app.label(box, 'Épaisseur à la couture (mm)').grid(row=6, column=0, sticky='w', pady=2)
    app.entry(box, thick, 7).grid(row=6, column=1, sticky='w', padx=10)
    app.label(box, 'Points par cm').grid(row=7, column=0, sticky='w', pady=2)
    app.entry(box, points, 7).grid(row=7, column=1, sticky='w', padx=10)
    note = tk.StringVar()
    tk.Label(win, textvariable=note, bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 9), justify='left', wraplength=330).pack(fill='x', padx=16)
    extras = tk.Frame(win, bg=panel)   # 0.19.14: the rembord's way, the renforts and doublures to add
    extras.pack(fill='x', padx=16)
    ticks = {}
    double = tk.BooleanVar(value=bool(app.assembly_state.get('double')))
    check = dict(bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), selectcolor=app.field_background(), activebackground=panel, font=('Segoe UI', 9))

    def changed():
        st = app.assembly_state
        st['double'] = double.get()
        st['layers'] = {j for j, v in ticks.items() if v.get()}
        st['thickness'] = None   # the thickness computed again
        refill()
        prompt(app)

    def build_extras(r):
        for w in extras.winfo_children():
            w.destroy()
        make = __import__('modern_style').make_check
        if r['rembord']:
            make(extras, text='Rembord paré sur 2 × sa largeur (sinon : rabat paré plié sur le cuir)', variable=double, command=changed, **check).pack(anchor='w')
        chosen = app.assembly_state.get('layers') or set()
        for j, name, t in r['layers']:
            v = ticks.setdefault(j, tk.BooleanVar(value=j in chosen))
            make(extras, text=f'+ {name} ({_mm(t, 2) + " mm" if t is not None else "1 mm compté"})', variable=v, command=changed, **check).pack(anchor='w')

    def refill():
        r = result(app)
        if r is None:
            for v in labels.values():
                v.set('—')
            return
        labels['a'].set(f'{_mm(r["la"])} mm')
        labels['b'].set(f'{_mm(r["lb"])} mm')
        labels['diff'].set(f'{_mm(abs(r["diff"]))} mm' + (' ✓' if abs(r['diff']) <= .5 else (' : bord 1 plus long' if r['diff'] > 0 else ' : bord 2 plus long')))
        labels['crans'].set(f'{r["front"]} (bord 1 : {r["ca"]}, bord 2 : {r["cb"]})' + (' · sens inverse' if r['reversed'] else ''))
        labels['n'].set(f'{r["n"]} ({_mm(r["points"], 2)} par cm)')
        labels['thread'].set(f'≈ {_mm(r["thread"] / 10, 0)} cm')
        thick.set(_mm(r['thickness'], 2))
        points.set(_mm(r['points'], 2))
        missing = [n for n, known in zip(('1', '2'), r['known']) if not known]
        note.set(f'Bord 1 : {r["made"][0]} · bord 2 : {r["made"][1]}.'
                 + (' 1 mm compté pour le cuir de la pièce ' + ' et '.join(missing) + ' (pas de refente dans sa matière).' if missing else '')
                 + ('' if r['layers'] else ' Renforts et doublures : à ajouter à l’épaisseur.'))
        key = (r['rembord'], tuple(j for j, _, _ in r['layers']))
        if win.__dict__.get('_extras_key') != key:
            win._extras_key = key
            build_extras(r)

    def typed(e=None):
        st = app.assembly_state
        try:
            t = float(thick.get().replace(',', '.'))
            p = float(points.get().replace(',', '.'))
            if not 0 < t <= 50 or not .5 <= p <= 20:
                raise ValueError
        except ValueError:
            messagebox.showerror("Contrôle d'assemblage", 'Épaisseur : 0 à 50 mm ; points par cm : 0,5 à 20.', parent=win)
            return 'break'
        st['thickness'], st['points'] = t, p
        refill()
        prompt(app)
        return 'break'
    for w in box.winfo_children():
        if isinstance(w, tk.Entry):
            w.bind('<Return>', typed)
            w.bind('<FocusOut>', lambda e: None)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(8, 14))
    app.button(foot, 'Écrire sur le plan', lambda: (typed(), write(app))).pack(side='left')
    app.button(foot, 'Fermer', win.destroy).pack(side='right')
    win._refill = refill
    refill()
    return win
