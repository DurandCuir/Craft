"""Preference defaults and validation, independent of application startup."""
import copy, json, math, re
from ui_widgets import auto_palette
from cad import SNAPS
DEFAULTS=dict(canvas='#101215',panel='#202429',ink='#f1f3f5',guides='#e3df32',accent='#61c9ee',
              icon_size=16,units='mm',grid=False,ortho=False,snaps=['endpoint','midpoint','center','intersection','extension'])   # 0.19.13: as his AutoCAD

from app_paths import settings_path


def read_preferences(file=None):
    out=copy.deepcopy(DEFAULTS)
    try:
        doc=json.loads((file or settings_path()).read_text(encoding='utf-8'))
        if not isinstance(doc,dict):return out
        if doc.get('units') in ('mm','cm'):out['units']=doc['units']
        for k in ('canvas','panel','guides','accent','anchor_color'):
            if re.fullmatch(r'#[0-9a-fA-F]{6}',str(doc.get(k,''))):out[k]=doc[k]
        if doc.get('icon_size') in (16,20,24,32,40):out['icon_size']=doc['icon_size']
        for k in ('grid','ortho','snap_enabled','pdf_print_test_offered','pdf_square_test_offered','smooth_display','cursor_hints','print_mono','pdf_tight','show_preparations','show_precuts','show_recuts'):
            if isinstance(doc.get(k),bool):out[k]=doc[k]
        for key in ('line_types','line_type_widths','interface_profiles'):
            if isinstance(doc.get(key),dict):out[key]=copy.deepcopy(doc[key])
        for key in ('line_type','interface_profile'):
            if isinstance(doc.get(key),str):out[key]=doc[key]
        if isinstance(doc.get('printer'),str) and len(doc['printer'])<=300:out['printer']=doc['printer']
        for key,low,high in [('base_line_width',.1,5),('pdf_margin',3,30),('pdf_gap',1,50),('cross_size',0,3000),('cross_width',.5,5),('cross_box',0,40),('annotation_name_size',.5,30),('annotation_material_size',.5,30),('stitch_distance',0,100),('stitch_pitch',.5,30),
                             ('fillet_radius',.001,50000),('angle_value',.001,50000),('round_depth',0,100000),('point_length',0,100000)]:   # 0.19.9: Arrondi, Chanfrein, Bout rond, Bout pointu
            value=doc.get(key)
            if isinstance(value,(int,float)) and low<=value<=high:out[key]=value
        value=doc.get('cross_color','auto')
        if value=='auto' or re.fullmatch(r'#[0-9a-fA-F]{6}',str(value)):out['cross_color']=value
        if isinstance(doc.get('oda_converter'),str):out['oda_converter']=doc['oda_converter']
        # 0.18.0: « Récents » and the last folder used by the file windows.
        if isinstance(doc.get('recent_files'),list):out['recent_files']=[f for f in doc['recent_files'] if isinstance(f,str) and 0<len(f)<=1000][:8]
        if isinstance(doc.get('last_folder'),str) and 0<len(doc['last_folder'])<=1000:out['last_folder']=doc['last_folder']
        if isinstance(doc.get('snaps'),list):out['snaps']=[v for v in doc['snaps'] if v in SNAPS]
        # 0.18.1: the PDF paper (A4…A0), the last Précoupe en série and the fiches chosen to print.
        if doc.get('pdf_paper') in ('A4','A3','A2','A1','A0'):out['pdf_paper']=doc['pdf_paper']
        if doc.get('stitch_kind') in ('machine','hand'):out['stitch_kind']=doc['stitch_kind']   # 0.18.5: the Piqûre kind used last
        precut=doc.get('precut')
        if isinstance(precut,dict):
            try:
                clean=dict(columns=int(precut.get('columns',1)),rows=int(precut.get('rows',1)),gap=float(precut.get('gap',5)),follow=bool(precut.get('follow',False)))
                if 1<=clean['columns']<=50 and 1<=clean['rows']<=50 and .5<=clean['gap']<=200:out['precut']=clean
            except (TypeError,ValueError):pass
        belt=doc.get('belt_holes')   # 0.19.5: Trous de ceinture
        if isinstance(belt,dict):
            try:
                clean=dict(count=int(belt.get('count',5)),spacing=float(belt.get('spacing',25)),offset=float(belt.get('offset',30)),diameter=float(belt.get('diameter',4)))
                if 1<=clean['count']<=50 and all(math.isfinite(clean[k]) and 0<=clean[k]<=100000 for k in ('spacing','offset')) and math.isfinite(clean['diameter']) and 0<clean['diameter']<=30:out['belt_holes']=clean
            except (TypeError,ValueError,OverflowError):pass
        # 0.19.6: Bout de ceinture, Fente d'ardillon, Sangle entière
        end=doc.get('belt_end')
        if isinstance(end,dict):
            try:
                clean=dict(taper=float(end.get('taper',45)),tip=float(end.get('tip',27)),round=float(end.get('round',1.5)))
                if all(math.isfinite(v) for v in clean.values()) and 0<clean['taper']<=10000 and 0<clean['tip']<=1000 and 0<=clean['round']<=50:out['belt_end']=clean
            except (TypeError,ValueError,OverflowError):pass
        slot=doc.get('buckle_slot')
        if isinstance(slot,dict):
            try:
                clean=dict(length=float(slot.get('length',20)),width=float(slot.get('width',4)),distance=float(slot.get('distance',35)),method=str(slot.get('method','machine')))
                if all(math.isfinite(clean[k]) for k in ('length','width','distance')) and 0<clean['width']<=30 and clean['width']<=clean['length']<=500 and 0<=clean['distance']<=100000 and clean['method'] in ('machine','trous','mortaise'):out['buckle_slot']=clean
            except (TypeError,ValueError,OverflowError):pass
        piece=doc.get('strap_piece')
        if isinstance(piece,dict):
            try:
                ends=('straight','strap_round','strap_point','strap_belt')
                clean=dict(length=float(piece.get('length',1100)),width=float(piece.get('width',35)),start=str(piece.get('start','straight')),end=str(piece.get('end','strap_point')),
                           holes=bool(piece.get('holes',True)),slot=bool(piece.get('slot',True)),
                           fold=float(piece.get('fold',0)),fold_holes=int(piece.get('fold_holes',2)),fold_hole=float(piece.get('fold_hole',3)))   # 0.19.13
                if not (0<=clean['fold']<=1000 and 0<=clean['fold_holes']<=3 and 0<clean['fold_hole']<=30):raise ValueError
                if math.isfinite(clean['length']) and math.isfinite(clean['width']) and 0<clean['length']<=100000 and 0<clean['width']<=1000 and clean['start'] in ends and clean['end'] in ends:out['strap_piece']=clean
            except (TypeError,ValueError,OverflowError):pass
        # 0.19.11 Poignée toron; 0.19.13: after the school's pattern (toron.py), its profiles by name
        def clean_toron(src):
            import toron as geometry
            out={}
            for k,default in geometry.TORON.items():
                if k not in src:continue
                v=src[k]
                if isinstance(default,bool):
                    if isinstance(v,bool):out[k]=v
                elif isinstance(default,str):
                    allowed={value for value,_ in (geometry.ENDS if k=='end' else geometry.ENCHAPE_ENDS)}
                    if v in allowed:out[k]=v
                else:
                    v=float(v)
                    if math.isfinite(v) and 0<=v<=100000:out[k]=int(v) if isinstance(default,int) else v
            return out
        toron=doc.get('toron')
        if isinstance(toron,dict):
            try:out['toron']=clean_toron(toron)
            except (TypeError,ValueError,OverflowError):pass
        if isinstance(doc.get('toron_profiles'),dict):
            kept={}
            for name,src in list(doc['toron_profiles'].items())[:50]:
                try:
                    if isinstance(name,str) and 0<len(name)<=40 and isinstance(src,dict):kept[name]=clean_toron(src)
                except (TypeError,ValueError,OverflowError):pass
            out['toron_profiles']=kept
        if isinstance(doc.get('toron_profile'),str) and len(doc['toron_profile'])<=40:out['toron_profile']=doc['toron_profile']
        passant=doc.get('passant')   # 0.19.13 Passant
        if isinstance(passant,dict):
            try:
                clean={k:float(passant[k]) for k in ('width','strap','thickness','band','ease','overlap') if k in passant}
                if all(math.isfinite(v) and 0<=v<=1000 for v in clean.values()):out['passant']=clean
            except (TypeError,ValueError,OverflowError):pass
        grid=doc.get('array')   # 0.19.13 Réseau
        if isinstance(grid,dict):
            try:
                clean=dict(kind=grid['kind'] if grid.get('kind') in ('rect','polar') else 'rect',columns=int(grid.get('columns',3)),rows=int(grid.get('rows',1)),
                           dx=float(grid.get('dx',20)),dy=float(grid.get('dy',20)),count=int(grid.get('count',6)),angle=float(grid.get('angle',360)),turn=bool(grid.get('turn',True)))
                if all(math.isfinite(clean[k]) and abs(clean[k])<=100000 for k in ('dx','dy','angle')) and 1<=clean['columns']<=500 and 1<=clean['rows']<=500 and 2<=clean['count']<=500:out['array']=clean
            except (TypeError,ValueError,OverflowError,KeyError):pass
        if isinstance(doc.get('fiche_choice'),list):out['fiche_choice']=[v for v in doc['fiche_choice'] if isinstance(v,str) and len(v)<=40][:20]
        # 0.19.13 bases libres: one's own base profiles, the one of Nouveau
        renamed={}
        if isinstance(doc.get('base_profiles'),dict):
            import base_profiles
            # 0.19.14: « Libre » is now Craft's base without columns: one's own profile of that name keeps its base
            # under « Libre (mon profil) » (never dropped)
            own={(renamed.setdefault(k,base_profiles.FREE+' (mon profil)') if k==base_profiles.FREE else k):v for k,v in doc['base_profiles'].items()}
            out['base_profiles']=base_profiles.clean(own)
        if isinstance(doc.get('base_default'),str) and len(doc['base_default'])<=40:out['base_default']=renamed.get(doc['base_default'],doc['base_default'])
    except (OSError,ValueError,TypeError):pass
    return auto_palette(out)


# 0.19.9: preferences.json and archives.json written whole or not at all (a plain write cut by a crash or a full
# disk left half a file, read as empty).
def write_atomic(file,text):
    """A temporary file in the same folder, then os.replace. Windows may hold the file a moment (antivirus,
    another Craft window reading it): a few tries."""
    import os,tempfile,time
    from pathlib import Path
    file=Path(file);file.parent.mkdir(parents=True,exist_ok=True)
    handle,temp=tempfile.mkstemp(prefix=file.name+'.',suffix='.tmp',dir=str(file.parent))
    try:
        with os.fdopen(handle,'w',encoding='utf-8') as out:   # text mode, like Path.write_text
            out.write(text);out.flush();os.fsync(out.fileno())
        for attempt in range(10):
            try:os.replace(temp,file);return
            except PermissionError:
                if attempt==9:raise
                time.sleep(.05)
    except BaseException:
        try:os.unlink(temp)
        except OSError:pass
        raise
