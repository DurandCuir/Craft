"""0.16.30: safety copies of the open drawings, kept apart; the user's .patron files are never written.

Every 2 minutes each drawing with unsaved changes is copied to
%LOCALAPPDATA%\\Craft\\Secours\\<process>\\<drawing>.patron, with a small .json beside it (the file
it comes from, the time). A drawing saved, or closed after the « Enregistrer ? » question, loses
its copy, so a normal exit leaves nothing. After a crash or a power cut the copies stay, and the
next Craft offers to recover them (Récupérer) or to delete them (Supprimer)."""
import json
import os
import time
from pathlib import Path
from app_paths import user_data_directory

PERIOD_MS = 120000
RETRY_MS = 5000
# 0.19.9: what a gesture under way leaves set in a tool (a first point placed, a side or a contour chosen, a
# spline being bent…); a tool that is only selected leaves them empty.
GESTURES = ('copy_state', 'drag', 'start', 'pending', 'stage_points', 'extra_points', 'pending_annotation', 'curve_points',
            'oval_points', 'new_cote', 'cote_host', 'spline_edit', 'rect_reference', 'rect_sized', 'corner_first', 'corner_result',
            'notch_pending', 'radius_target', 'trim_stroke', 'pending_bundle', 'pending_text_origin', 'pending_identification',
            'copy_crans', 'walk', 'mirror_axis', 'mirror_box')
# The state a tool keeps while it stays selected (Rotation, Décaler, Précoupe, Trous de ceinture, boucle,
# sangle…), and what its first click fills in.
STEPS = dict(xform=('base', 'box'), offset_state=('host',), route_state=('host', 'points'), surcoupe_state=('piece',),
             belt_state=('first',), slot_state=('first',), strap_state=('start',))


def filled(value):
    """0.19.9: a state in use: anything but None, False and an empty list / dict… (an index 0 counts)."""
    return value is not None and value is not False and not (isinstance(value, (list, tuple, dict, set, str)) and not value)


def folder():
    return user_data_directory() / 'Secours'


_SESSION = []


def session_name():
    """0.19.9: this Craft's folder in Secours: its process number and when the process started (« 4120-
    1762358400123 »). After a crash Windows may give the new Craft the number of the old one: their folders
    now differ (the old one's copies were skipped, then deleted by the new Craft's first copy)."""
    if not _SESSION:
        started = None
        try:
            import bootstrap
            age = bootstrap.process_age()   # Windows: the creation of the process
            started = time.time() - age if age is not None else bootstrap.MARKS.get('wall')
        except Exception:
            pass
        _SESSION.append(f'{os.getpid()}-{int((started or time.time()) * 1000)}')
    return _SESSION[0]


def session_pid(name):
    """The process of a folder in Secours: « 4120-1762358400123 », or « 4120 » before 0.19.9; None otherwise."""
    head, _, stamp = name.partition('-')
    if not head.isdigit() or (stamp and not stamp.isdigit()) or name.endswith('-'):
        return None
    return int(head)


def encode(items, workspace, background=None, infos=None):
    """The drawing in the .patron format (read back with cad.read_document), as it is."""
    version = 2 if any(s.get('spline') or s.get('components') for s in items) else 1
    data = dict(format='atelier-patron', version=version, units='mm', shapes=items, workspace=workspace)
    if background:
        data['background'] = background   # 0.18.0 image de fond
    if infos:
        data['infos'] = infos   # 0.18.1 Infos du modèle
    return json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')


def remove_copy(path):
    for suffix in ('.patron', '.json', '.tmp'):
        try:
            path.with_suffix(suffix).unlink()
        except OSError:
            pass


def remove_folder(path):
    """Only the copies Craft wrote there, then the folder if it is empty."""
    for p in path.glob('*'):
        if p.is_file() and not p.is_symlink() and p.suffix in ('.patron', '.json', '.tmp'):
            try:
                p.unlink()
            except OSError:
                pass
    try:
        path.rmdir()
    except OSError:
        pass


def orphans(own=None):
    """Copies left by Craft processes that are no longer running, newest first. 0.19.9: ``own`` is this
    Craft's folder name (session_name); another folder with this process number is a Craft that crashed
    (Windows gave its number to this one), one with the number of a running process is left as it is."""
    from updater import process_alive
    own = session_name() if own is None else str(own)
    base = folder()
    found = []
    if not base.is_dir() or base.is_symlink():
        return found
    for session in base.iterdir():
        pid = session_pid(session.name)
        if not session.is_dir() or session.is_symlink() or pid is None:
            continue
        if session.name == own or (pid != os.getpid() and process_alive(pid)):
            continue
        copies = [p for p in session.glob('*.patron') if p.is_file() and not p.is_symlink()]
        if not copies:
            remove_folder(session)
            continue
        for p in copies:
            meta = {}
            try:
                meta = json.loads(p.with_suffix('.json').read_text(encoding='utf-8'))
            except (OSError, ValueError):
                pass
            saved = meta.get('saved') if isinstance(meta.get('saved'), (int, float)) else p.stat().st_mtime
            original = meta.get('file') if isinstance(meta.get('file'), str) else None
            found.append(dict(copy=p, file=original, saved=saved))
    return sorted(found, key=lambda entry: -entry['saved'])


def when(seconds):
    t = time.localtime(seconds)
    today = time.localtime()
    return time.strftime('%H:%M' if t[:3] == today[:3] else '%d/%m %H:%M', t)


class Keeper:
    """The copies of one Craft window (all its drawing tabs)."""

    def __init__(self, app):
        self.app = app
        self.session = folder() / session_name()   # 0.19.9: was the process number alone
        self.written = {}   # drawing key -> bytes copied (or deliberately left unsaved)
        self.own = set()   # 0.19.9: the copies this Craft wrote itself: the only ones it deletes by itself

    def drawings(self):
        """(key, items, workspace, file, unsaved) of every tab, the current one as it is now."""
        app = self.app
        out = []
        for index, doc in enumerate(app.documents):
            if index == app.current_doc:
                if not app.__dict__.get('doc_key'):
                    import uuid
                    app.doc_key = uuid.uuid4().hex
                out.append((app.doc_key, app.items, app.workspace, app.filename, app.dirty(), app.__dict__.get('background'), app.__dict__.get('infos')))
            else:
                if not doc.get('doc_key'):
                    import uuid
                    doc['doc_key'] = uuid.uuid4().hex
                from doc_files import document_dirty
                out.append((doc['doc_key'], doc['items'], doc['workspace'], doc['filename'],
                            document_dirty(doc), doc.get('background'), doc.get('infos')))
        return out

    def busy(self):
        """0.17.0: never in the middle of an action: a line being drawn, Raccord, Déplacer…, a drag or an
        open dialog; a mere selection is not an action. 0.19.9: nor a tool only selected: Pointés / mèches,
        Trous de ceinture, Préparation, ID unique… stay selected between two uses (no copy was made then);
        only a gesture under way counts (GESTURES, STEPS)."""
        app = self.app
        try:
            tool = app.tool.get()
            dialog = app.grab_current() is not None
        except Exception:
            tool, dialog = 'select', False
        d = app.__dict__
        if (dialog or d.get('_action') or d.get('box_start') is not None or d.get('grip_drag') or d.get('move_state')
                or d.get('_contour_drag') or isinstance(d.get('bg_tool'), dict) and d['bg_tool'].get('gesture')):
            return True
        if tool == 'select':
            return False
        return (any(filled(d.get(name)) for name in GESTURES)
                or any(isinstance(d.get(name), dict) and any(filled(d[name].get(key)) for key in keys) for name, keys in STEPS.items()))

    def tick(self):
        try:
            if not self.app.winfo_exists():
                return
        except Exception:
            return
        if self.busy():
            self.app.after(RETRY_MS, self.tick)
            return
        try:
            self.save_copies()
        except Exception:
            pass   # a safety copy never interrupts the work
        self.app.after(PERIOD_MS, self.tick)

    def save_copies(self):
        live = set()
        for key, items, workspace, filename, unsaved, background, infos in self.drawings():
            live.add(key)
            if not unsaved:
                self.forget(key)
                continue
            try:
                data = encode(items, workspace, background, infos)
                if self.written.get(key) != data:
                    self.write(key, data, filename)
            except (OSError, ValueError, TypeError):
                continue   # the other drawings are still copied
        for key in list(self.written):
            if key not in live:
                self.forget(key)
        # 0.19.9: only the copies this Craft wrote (it deleted every copy of its folder that was not one of its
        # drawings: those of a Craft that crashed with the same process number).
        for key in list(self.own):
            if key not in live:
                self.forget(key)

    def write(self, key, data, filename):
        self.session.mkdir(parents=True, exist_ok=True)
        target = self.session / (key + '.patron')
        temp = target.with_suffix('.tmp')
        self.own.add(key)   # 0.19.9: from its first byte, so that what a write cut short leaves goes too
        temp.write_bytes(data)
        os.replace(temp, target)
        target.with_suffix('.json').write_text(json.dumps(dict(file=filename, saved=time.time())), encoding='utf-8')
        self.written[key] = data
        note = getattr(self.app, 'note_history', None)
        if callable(note):
            note('Copie de secours ' + time.strftime('%H:%M'))   # 0.17.0: shown in the last commands

    def forget(self, key):
        if key in self.own:   # 0.19.9: never a copy this Craft did not write
            target = self.session / (key + '.patron')
            remove_copy(target)
            if not target.exists():
                self.own.discard(key)   # (one that could not be deleted is tried again)
        self.written.pop(key, None)

    def settle_current(self):
        """The current drawing was saved, or the user chose not to save it: no copy is kept,
        and the changes left unsaved on purpose are not copied again until they change."""
        app = self.app
        key = app.__dict__.get('doc_key')
        if not key:
            return
        self.forget(key)
        try:
            if app.dirty():
                self.written[key] = encode(app.items, app.workspace, app.__dict__.get('background'), app.__dict__.get('infos'))
        except Exception:
            pass

    def finish(self):
        """Normal exit: every drawing was saved or deliberately left; an empty folder goes."""
        try:
            self.session.rmdir()
        except OSError:
            pass

    def offer(self):
        """Copies left by a Craft that closed without saving: Récupérer or Supprimer."""
        try:
            found = orphans()
        except OSError:
            return
        if not found:
            return
        app = self.app
        import tkinter as tk
        from tkinter import messagebox
        win = app.dialog('Récupération')
        app.label(win, 'Craft s’est fermé sans enregistrer :', anchor='w').pack(fill='x', padx=16, pady=(14, 4))
        for entry in found:
            name = Path(entry['file']).stem if entry['file'] else 'Nouveau modèle'
            app.label(win, '•  ' + name + '  ·  ' + when(entry['saved']), anchor='w').pack(fill='x', padx=24)
        row = tk.Frame(win, bg=app.p['panel'])
        row.pack(fill='x', padx=16, pady=(12, 14))

        def recover():
            win.destroy()
            self.recover(found)

        def delete():
            if not messagebox.askyesno('Récupération', 'Supprimer définitivement ces copies ?', parent=win):
                return
            win.destroy()
            for entry in found:
                remove_copy(entry['copy'])
            for session in {entry['copy'].parent for entry in found}:
                remove_folder(session)
        app.button(row, 'Récupérer', recover).pack(side='right')
        app.button(row, 'Supprimer', delete).pack(side='right', padx=8)
        win.bind('<Return>', lambda e: recover())
        win.protocol('WM_DELETE_WINDOW', win.destroy)   # asked again at the next start
        return win

    def recover(self, found):
        """Each copy opens in a tab, unsaved (« * »); saving it is the user's choice."""
        from cad import read_document
        app = self.app
        opened = []
        for entry in found:
            try:
                items, workspace, background, infos = read_document(entry['copy'], infos=True)
            except (OSError, ValueError):
                continue
            original = entry['file']
            clean, clean_workspace, clean_background, clean_infos = [], None, None, None
            if original:
                try:
                    newer = Path(original).stat().st_mtime > entry['saved']
                    if not newer:
                        import doc_files
                        clean, clean_workspace, clean_background, clean_infos, meta = read_document(original, meta=True)
                        # 0.18.1: compared as « Ouvrir » shows it (crans and zones of older files).
                        clean = doc_files.current_zones(clean if meta.get('crans') == 'mozart' else doc_files.current_crans(clean))
                    else:
                        original = None   # the file was saved again since: saving asks where
                except (OSError, ValueError):
                    pass
            app.reset_doc(items, workspace, original, background, infos)
            app.clean, app.clean_workspace, app.clean_background, app.clean_infos = clean, clean_workspace, clean_background, clean_infos
            app.documents[app.current_doc] = app.capture_doc()
            opened.append((entry, app.doc_key))
        app.refresh()
        try:
            self.save_copies()   # this Craft keeps them safe from now on
        except Exception:
            return
        # 0.19.9: a copy recovered goes only once this Craft holds the drawing (its own copy written, or
        # nothing left unsaved): a copy that could not be written leaves the old one for the next start.
        # (written: its copy complete on disk; own alone is set before the first byte, even when the write fails)
        held = {key for key, _, _, _, unsaved, *_ in self.drawings()
                if not unsaved or key in self.written and (self.session / (key + '.patron')).is_file()}
        for entry, key in opened:
            if key in held:
                remove_copy(entry['copy'])
        for session in {entry['copy'].parent for entry, _ in opened}:
            if not any(session.glob('*.patron')):
                remove_folder(session)
        if opened:
            app.status.set('Travail récupéré.')


def install(app):
    keeper = Keeper(app)
    app.after(PERIOD_MS, keeper.tick)
    app.after(700, keeper.offer)
    return keeper
