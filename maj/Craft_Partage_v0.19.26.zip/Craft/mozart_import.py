"""Mozart patterns (AutoCAD leather CAD) read into Craft shapes and base, standard library only.
DXF is parsed here (ASCII, AC1015 to AC1032); a DWG is first written as DXF by LibreDWG (exchange).
Craft (x, y) is DXF (x, -y), the inverse of exchange.export_dxf: arcs (bulges) change sign.
0.19.9: ELLIPSE and SPLINE are read too, and the drawing of an ordinary block (INSERT) where it lands."""
import codecs,copy,gc,math,re,uuid
from bisect import bisect_left
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from geometry import path,bounds,validate,distance as seg_distance,clone
from cad import shape,polygon,intersections,default_workspace,validate_workspace,LABELS
from craft_tools import PROFILES,text_bundle,standalone_notch,annotation,locate,at_distance,aligned_annotation
from editing import drill_mark
from precision_geometry import contour_location,inside,without_micro,ellipse,ellipse_length,TAU
from curves import arc,spline,from_cubics,cubics
from entity_rules import ensure_piece_id
import piece_sheet

PREP_COLORS=dict(parage='#f4a6c8',teinte='#9fd3f5',surcoupe='#b8c0ff',autre='#c8c8c8')
MODEL_COLOR='#e3df32'     # default « guides » colour, as identify_dialog writes the model line
TOUCH=.5                  # mm: a cran this close to a contour is on it
TINY=.5                   # mm: shorter strokes are trimming leftovers, not geometry
UNITS={1:'pouces',2:'pieds',5:'centimètres',6:'mètres',14:'décimètres'}   # $INSUNITS other than mm
DEFAULT_CRAN=(12.,'cross',4.,3.,(2/3,19/24))   # PitTacCT block: depth, kind, bar width, cap width, cut stem
GEOMETRY=('LINE','LWPOLYLINE','POLYLINE','ARC','CIRCLE','ELLIPSE','SPLINE')   # 0.19.9: ELLIPSE, SPLINE
IGNORED=('POINT','ATTDEF','VIEWPORT','SEQEND')
IDENTITY=(1.,0.,0.,1.,0.,0.)   # 0.19.9: an affine map (a, b, c, d, e, f): x' = a x + b y + e, y' = c x + d y + f


def read_mozart(file,model_color=MODEL_COLOR):
    """Items, workspace and report of a Mozart DXF or DWG. A DWG is first written as DXF by the
    converter shipped with Craft (0.18.0, LibreDWG): nothing to install."""
    p=Path(file);ext=p.suffix.lower()
    if ext=='.dxf':return read_mozart_dxf(p,model_color)
    if ext!='.dwg':raise ValueError('Choisissez un fichier Mozart DXF ou DWG.')
    # 0.18.7: the DXF written by LibreDWG is read where the converter wrote it (no second copy).
    from exchange import dwg_dxf_bytes
    return _read(dwg_dxf_bytes(p),p.stem,model_color)


def read_mozart_dxf(file,model_color=MODEL_COLOR,stem=None):
    """dict(items, workspace or None, report) of a Mozart pattern saved as ASCII DXF; ``stem`` is the
    name of the original file (a converted DWG is read from a temporary DXF)."""
    return _read(Path(file).read_bytes(),stem or Path(file).stem,model_color)


def _read(raw,stem,model_color):
    if len(raw)>100000000:raise ValueError('DXF trop volumineux.')
    with _no_gc():return _Mozart(raw,stem,model_color).run()


@contextmanager
def _no_gc():
    """0.18.7: a DXF is read into 10⁵ small tuples, lists and dicts, none of them in a cycle; the
    cyclic garbage collector ran 340 times meanwhile, twice over all of Craft's objects: a fifth
    of the import. It is put back as it was (another import may be running)."""
    was=gc.isenabled();gc.disable()
    try:yield
    finally:
        if was:gc.enable()


# ---------------------------------------------------------------- DXF reading
def _lines(raw):
    if raw.startswith(b'AutoCAD Binary DXF'):raise ValueError('DXF binaire non pris en charge : enregistrez le dessin en DXF ASCII.')
    if re.match(rb'AC10\d\d',raw[:6]):raise ValueError('Ce fichier est un DWG : choisissez-le avec l’extension .dwg.')
    try:text=raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        # Before AutoCAD 2007 the text uses the drawing code page (cp1252 in France).
        m=re.search(rb'\$DWGCODEPAGE\s+3\s+ANSI_(\d+)',raw);codec='cp'+m[1].decode() if m else 'cp1252'
        try:codecs.lookup(codec)
        except LookupError:codec='cp1252'
        text=raw.decode(codec,errors='replace')
    text=re.sub(r'\\U\+([0-9A-Fa-f]{4})',lambda m:chr(int(m[1],16)),text)
    return text.replace('\r\n','\n').replace('\r','\n').split('\n')

def _pairs_by_line(lines):
    """(code, value) up to EOF, read line by line: the message of a code that is not a number."""
    out=[]
    for i in range(0,len(lines)-1,2):
        try:code=int(lines[i])
        except ValueError:raise ValueError(f'DXF illisible à la ligne {i+1}.') from None
        value=lines[i+1].strip()
        if code==0 and value=='EOF':break
        out.append((code,value))
    if (0,'SECTION') not in out[:20]:raise ValueError('Ce fichier n’est pas un DXF.')
    return out

class _Dxf:
    """The (code, value) pairs of an ASCII DXF up to EOF, as numbered pairs. 0.18.7: every code is
    still checked, but a value is stripped and paired with its code only when read (header,
    entities, a cran block): Mozart's blocks and objects, more than half of a file, were turned
    into 10⁵ pairs for nothing."""
    def __init__(self,raw):
        lines=_lines(raw);n=len(lines)
        try:codes=list(map(int,lines[0:n-1:2]));values=lines[1:n:2]
        except ValueError:
            # A code that is not a number: the message, unless it comes after EOF.
            out=_pairs_by_line(lines);codes=[c for c,_ in out];values=[v for _,v in out]
        zeros=[];k=-1   # (pair, stripped value) of each code 0: section and entity markers
        while True:
            try:k=codes.index(0,k+1)
            except ValueError:k=len(codes);break
            v=values[k].strip()
            if v=='EOF':break
            zeros.append((k,v))
        if not any(v=='SECTION' for k,v in zeros[:20] if k<20):raise ValueError('Ce fichier n’est pas un DXF.')
        self.codes=codes;self.values=values;self.end=k;self.zeros=zeros;self.at=[k for k,_ in zeros]

    def pairs(self,a,b):return list(zip(self.codes[a:b],map(str.strip,self.values[a:b])))

    def sections(self):
        """{name: (first, end)} of the pairs of each section."""
        out={};zs=self.zeros;i=0;n=len(zs)
        while i<n:
            k,v=zs[i]
            if v=='SECTION' and k+1<self.end and self.codes[k+1]==2:
                name=self.values[k+1].strip().upper();j=i+1
                while j<n and zs[j][1]!='ENDSEC':j+=1
                out[name]=(k+2,zs[j][0] if j<n else self.end);i=j
            i+=1
        return out

    def entities(self,a,b):
        """Entities of the pairs a to b with their codes; an INSERT keeps its ATTRIBs and a
        POLYLINE its VERTEXes."""
        zs=self.zeros;lo=bisect_left(self.at,a);hi=bisect_left(self.at,b)
        flat=[(zs[i][1],zs[i][0]+1,zs[i+1][0] if i+1<hi else b) for i in range(lo,hi)]
        out=[];i=0;n=len(flat)
        while i<n:
            kind,first,end=flat[i];subs=[];i+=1
            if kind in ('INSERT','POLYLINE'):
                while i<n and flat[i][0] in ('ATTRIB','VERTEX','SEQEND'):
                    i+=1
                    if flat[i-1][0]=='SEQEND':break
                    subs.append(self.pairs(*flat[i-1][1:]))
            out.append(dict(type=kind,codes=self.pairs(first,end),subs=subs))
        return out

    def blocks(self,a,b):
        """{name: [(codes of the BLOCK entity, first, end of its entities' pairs) for each BLOCK of
        that name]} in the pairs a to b: a BLOCK's entities run to its ENDBLK (or the next BLOCK)."""
        zs=self.zeros;lo=bisect_left(self.at,a);hi=bisect_left(self.at,b);out={}
        for i in range(lo,hi):
            if zs[i][1]!='BLOCK':continue
            j=i+1
            while j<hi and zs[j][1] not in ('ENDBLK','BLOCK'):j+=1
            codes=self.pairs(zs[i][0]+1,zs[i+1][0] if i+1<hi else b)
            out.setdefault(_get(codes,2,''),[]).append((codes,zs[i][0]+1,zs[j][0] if j<hi else b))
        return out

def _get(codes,code,default=None):
    for c,v in codes:
        if c==code:return v
    return default

def _shown(codes):
    """Not in paper space (67) nor invisible (60). 0.18.7: the usual entity, without either flag,
    is recognised by two C-speed searches instead of two Python passes over all its codes."""
    return ((67,'1') not in codes or _get(codes,67)!='1') and ((60,'1') not in codes or _get(codes,60)!='1')

def _num(codes,code,default=0.):
    try:return float(_get(codes,code,default))
    except (TypeError,ValueError):return default

def _xdata(codes,app):
    out=[];on=False
    for c,v in codes:
        if c==1001:on=v.upper()==app
        elif on and c==1000:out.append(v)
    return out

def kept_base(craft):
    """0.19.25: the base Craft kept in its data of the model sheet when it did not draw it (mozart_export.kept_base:
    Exporter › DWG Mozart, Ctrl+S of a DWG Mozart); None without one or when it cannot be read."""
    code=''.join(str(v)[5:] for v in craft or () if str(v).startswith('base='))
    if not code:return None
    import base64,json
    try:return validate_workspace(json.loads(base64.b64decode(code,validate=True).decode('utf-8')))
    except (ValueError,TypeError,KeyError,AttributeError,IndexError):return None

_MTEXT_LINE=re.compile(r'\\[PN]')
_MTEXT_STACK=re.compile(r'\\S([^;]*);')
_MTEXT_STACK_SEP=re.compile(r'[\^#]')
_MTEXT_FORMAT=re.compile(r'\\[ACcFfHQTWp][^;\\]*;')
_MTEXT_SWITCH=re.compile(r'\\[LlOoKk]')
_MTEXT_SPECIALS=tuple((re.compile('%%'+code,re.I),char) for code,char in (('c','Ø'),('d','°'),('p','±')))
_MTEXT_UNDERLINE=re.compile(r'%%[uUoOkK]')
_MTEXT_MARKS=('\\','{','}','%','\0','\1','\2')

def _plain(text):
    """Text without MTEXT formatting codes nor %% special characters. 0.19.19: a text with none of them (most
    of Mozart's) is only stripped, the patterns compiled once: the same texts, the DIFORME opened faster."""
    if not any(mark in text for mark in _MTEXT_MARKS):return text.strip()
    t=text.replace('\\\\','\0').replace('\\{','\1').replace('\\}','\2')
    t=_MTEXT_LINE.sub('\n',t).replace('\\~',' ')
    t=_MTEXT_STACK.sub(lambda m:_MTEXT_STACK_SEP.sub('/',m[1]),t)
    t=_MTEXT_FORMAT.sub('',t);t=_MTEXT_SWITCH.sub('',t)
    t=t.replace('{','').replace('}','')
    for pattern,char in _MTEXT_SPECIALS:t=pattern.sub(char,t)
    t=_MTEXT_UNDERLINE.sub('',t).replace('%%%','%')
    return t.replace('\0','\\').replace('\1','{').replace('\2','}').strip()

class _Cursor:
    """Sequential reading of codes whose meaning depends on their order (HATCH paths)."""
    def __init__(self,codes):self.codes=codes;self.i=0
    def peek(self):return self.codes[self.i][0] if self.i<len(self.codes) else None
    def take(self,code,default=None):
        if self.peek()!=code:return default
        self.i+=1;return self.codes[self.i-1][1]
    def f(self,code,default=0.):
        try:return float(self.take(code,default))
        except (TypeError,ValueError):return default
    def seek(self,code):
        while self.i<len(self.codes) and self.codes[self.i][0]!=code:self.i+=1
        return self.i<len(self.codes)

def _hatch_loops(codes):
    """Boundary loops of a HATCH as (points, bulges), in its object coordinates."""
    c=_Cursor(codes);loops=[];approximated=False
    if not c.seek(91):return loops,approximated
    for _ in range(int(c.f(91))):
        if not c.seek(92):break
        flags=int(c.f(92));pts=[];bs=[]
        if flags&2:
            c.take(72);c.take(73)
            for _ in range(int(c.f(93))):
                if c.peek()!=10:break
                pts.append((c.f(10),c.f(20)));bs.append(c.f(42) if c.peek()==42 else 0.)
        else:
            edges=[]
            for _ in range(int(c.f(93))):
                kind=int(c.f(72))
                if kind==1:edges.append(((c.f(10),c.f(20)),(c.f(11),c.f(21)),0.,[]))
                elif kind==2:
                    cx,cy,r,s,e,ccw=c.f(10),c.f(20),c.f(40),c.f(50),c.f(51),c.f(73,1.)
                    # Clockwise edges store complementary angles (360 - angle).
                    span=(e-s)%360 or 360.;a0,sweep=(s,span) if ccw else (-s,-span)
                    parts=2 if abs(sweep)>180 else 1
                    for k in range(parts):
                        t0=math.radians(a0+sweep*k/parts);t1=math.radians(a0+sweep*(k+1)/parts)
                        edges.append(((cx+r*math.cos(t0),cy+r*math.sin(t0)),(cx+r*math.cos(t1),cy+r*math.sin(t1)),math.tan((t1-t0)/4),[]))
                elif kind==3:
                    cx,cy,mx,my,ratio,s,e,ccw=c.f(10),c.f(20),c.f(11),c.f(21),c.f(40,1.),c.f(50),c.f(51),c.f(73,1.)
                    span=(e-s)%360 or 360.;a0,sweep=(s,span) if ccw else (-s,-span);n=max(4,math.ceil(abs(sweep)/5))
                    at=lambda t:(cx+mx*math.cos(t)-my*ratio*math.sin(t),cy+my*math.cos(t)+mx*ratio*math.sin(t))
                    ts=[math.radians(a0+sweep*j/n) for j in range(n+1)]
                    edges.append((at(ts[0]),at(ts[-1]),0.,[at(t) for t in ts[1:-1]]))
                elif kind==4:
                    c.take(94);c.take(73);c.take(74);nk=int(c.f(95));nc=int(c.f(96))
                    for _ in range(nk):c.take(40)
                    ctrl=[]
                    for _ in range(nc):
                        ctrl.append((c.f(10),c.f(20)))
                        if c.peek()==42:c.take(42)
                    if c.peek()==97:
                        mark=c.i;count=int(c.f(97))
                        if count and c.peek()==11:
                            for _ in range(count):c.take(11);c.take(21)
                            for code in (12,22,13,23):c.take(code)
                        else:c.i=mark
                    if len(ctrl)>=2:edges.append((ctrl[0],ctrl[-1],0.,ctrl[1:-1]));approximated=True
            for a,b,bulge,inner in edges:
                # Edges follow each other; a reversed one is turned round.
                if pts and math.dist(pts[-1],a)>1e-4 and math.dist(pts[-1],b)<=1e-4:a,b,bulge,inner=b,a,-bulge,inner[::-1]
                if not pts or math.dist(pts[-1],a)>1e-4:pts.append(a);bs.append(0.)
                bs[-1]=bulge if not inner else 0.
                for q in inner:pts.append(q);bs.append(0.)
                pts.append(b);bs.append(0.)
            if len(pts)>2 and math.dist(pts[0],pts[-1])<=1e-4:pts.pop();bs.pop()
        if c.peek()==97:
            for _ in range(int(c.f(97))):c.take(330)
        if len(pts)>=3:loops.append((pts,bs))
    return loops,approximated


# ---------------------------------------------------------------- 0.19.9: ovals, splines, blocks
# « Ouvrir… » lost the ovals and splines of Craft's own DXF, and the drawing of an ordinary block.
def _apply(M,p):return (M[0]*p[0]+M[1]*p[1]+M[4],M[2]*p[0]+M[3]*p[1]+M[5])

def _turn(M,v):return (M[0]*v[0]+M[1]*v[1],M[2]*v[0]+M[3]*v[1])   # a vector: M without its move

def _compose(M,N):
    """M after N."""
    a,b,c,d,e,f=M;A,B,C,D,E,F=N
    return (a*A+b*C,a*B+b*D,c*A+d*C,c*B+d*D,a*E+b*F+e,c*E+d*F+f)

def _craft(M):return (M[0],-M[1],-M[2],M[3],M[4],-M[5])   # M (DXF, y up) moving Craft's points (y down)

def _det(M):return M[0]*M[3]-M[1]*M[2]

def _similar(M):
    """Turned, moved, mirrored or scaled alike in every direction: an arc stays an arc."""
    a,b,c,d=M[:4];n=a*a+b*b+c*c+d*d
    return abs(a*a+c*c-b*b-d*d)<=1e-9*n and abs(a*b+c*d)<=1e-9*n

def _stretch(M):
    """M's largest scale, in any direction."""
    a,b,c,d=M[:4];t=a*a+b*b+c*c+d*d
    return math.sqrt((t+math.sqrt(max(0.,t*t-4*_det(M)**2)))/2)

def _insert_matrix(codes,base,i=0,j=0):
    """An INSERT's map from its block to the drawing (DXF): base point, X and Y scales (negative: mirrored),
    rotation, column i and row j of a MINSERT (spaced along the turned axes); a normal pointing down (230 = -1)
    mirrors it, the INSERT's point being in its own coordinates then."""
    sx,sy=_num(codes,41,1.),_num(codes,42,1.);th=math.radians(_num(codes,50));co,si=math.cos(th),math.sin(th)
    ox,oy=i*_num(codes,44)-sx*base[0],j*_num(codes,45)-sy*base[1]
    M=(co*sx,-si*sy,si*sx,co*sy,_num(codes,10)+co*ox-si*oy,_num(codes,20)+si*ox+co*oy)
    return (-M[0],-M[1],M[2],M[3],-M[4],M[5]) if _num(codes,230,1.)<0 else M

def _moved_polyline(M,pts,bs,closed):
    """A polyline's points and bulges moved by M (Craft); mirrored, its arcs turn the other way; scaled
    unevenly, an arc is no longer one: its points then, with 0,005 mm of sag at most."""
    flip=-1. if _det(M)<0 else 1.
    if _similar(M) or not any(abs(v)>1e-12 for v in bs):return [list(_apply(M,p)) for p in pts],[flip*v for v in bs]
    k=_stretch(M);out=[];n=len(pts)
    for i in range(n):
        out.append(pts[i])
        if abs(bs[i])<=1e-12 or (i==n-1 and not closed) or math.dist(pts[i],pts[(i+1)%n])<1e-9:continue
        (cx,cy),r,sweep=_arc_of(pts[i],pts[(i+1)%n],bs[i]);start=math.atan2(pts[i][1]-cy,pts[i][0]-cx)
        steps=min(4000,max(2,math.ceil(abs(sweep)/(2*math.acos(max(-1.,1-min(.005/(r*k),1.)))))))
        out+=[(cx+r*math.cos(start+sweep*j/steps),cy+r*math.sin(start+sweep*j/steps)) for j in range(1,steps)]
    return [list(_apply(M,p)) for p in out],[0.]*len(out)

def _oval(c,u,v,t0,span,name):
    """Craft's oval through c + u cos t + v sin t, t from t0 over ``span`` (TAU: the whole oval); its axes are
    its longest and shortest radii. Run the other way round (mirrored), an arc is marked reversed: it still
    goes from the same start to the same end. None when flat or too large for Craft."""
    uu,vv,uv=u[0]*u[0]+u[1]*u[1],v[0]*v[0]+v[1]*v[1],u[0]*v[0]+u[1]*v[1]
    k=.5*math.atan2(2*uv,uu-vv);ck,sk=math.cos(k),math.sin(k)
    p=(u[0]*ck+v[0]*sk,u[1]*ck+v[1]*sk);q=(v[0]*ck-u[0]*sk,v[1]*ck-u[1]*sk)
    rx,ry=math.hypot(*p),math.hypot(*q)
    if min(rx,ry)<1e-6 or max(rx,ry)>50000:return None
    closed=span>=TAU;forward=p[0]*q[1]-p[1]*q[0]>=0
    start=t0-k if forward else k-t0-(0. if closed else span)
    s=ellipse(c,rx,ry,math.atan2(p[1],p[0]),start,TAU if closed else span,name)
    if not forward and not closed:s['reversed']=True
    return s

def _spline_data(codes):
    """A SPLINE's degree, flags, knots (40), weights (41), control points (10/20), fit points (11/21) and end
    tangents (12/22, 13/23), in DXF coordinates; a value that is not a number is left out."""
    out=dict(degree=int(_num(codes,71,3.)),flags=int(_num(codes,70)),knots=[],weights=[],ctrl=[],fit=[],tangents={})
    for c,v in codes:
        if c not in (10,20,11,21,12,22,13,23,40,41):continue
        try:x=float(v)
        except ValueError:continue
        if c==40:out['knots'].append(x)
        elif c==41:out['weights'].append(x)
        elif c in (10,11):out['ctrl' if c==10 else 'fit'].append([x,0.])
        elif c in (20,21):
            pts=out['ctrl' if c==20 else 'fit']
            if pts:pts[-1][1]=x
        elif c in (12,13):out['tangents'][c]=[x,0.]
        elif c-10 in out['tangents']:out['tangents'][c-10][1]=x
    return out

def _spans(p,U,P):
    """The Bézier control points of each span of a B-spline (degree p, knots U, control points P: x, y or
    homogeneous x w, y w, w), by blossoming: de Boor's steps with the span's ends as parameters."""
    out=[]
    for k in range(p,len(P)):
        a,b=U[k],U[k+1]
        if b<=a:continue
        span=[]
        for j in range(p+1):
            d=[P[i] for i in range(k-p,k+1)]
            for r in range(1,p+1):
                t=a if r<=p-j else b
                for i in range(p,r-1,-1):
                    lo,hi=U[k-p+i],U[k+1+i-r];w=(t-lo)/(hi-lo)
                    d[i]=tuple((1-w)*x+w*y for x,y in zip(d[i-1],d[i]))
            span.append(d[p])
        out.append(span)
    return out

def _sampled(spans,tol):
    """Points along rational Bézier spans (homogeneous control points), each chord within ``tol`` of the curve
    (at its middle and quarters)."""
    out=[]
    for poly in spans:
        def at(t,poly=poly):
            q=list(poly)
            for r in range(1,len(q)):q=[tuple((1-t)*x+t*y for x,y in zip(q[i],q[i+1])) for i in range(len(q)-1)]
            return (q[0][0]/q[0][2],q[0][1]/q[0][2])
        def refine(t0,a,t1,b,depth):
            m=at((t0+t1)/2)
            if depth<16 and max(seg_distance(m,a,b),seg_distance(at(t0+(t1-t0)/4),a,b),seg_distance(at(t1-(t1-t0)/4),a,b))>tol:
                refine(t0,a,(t0+t1)/2,m,depth+1);refine((t0+t1)/2,m,t1,b,depth+1)
            else:out.append(b)
        ts=[k/8 for k in range(9)];ps=[at(t) for t in ts]
        if not out:out.append(ps[0])
        for k in range(8):refine(ts[k],ps[k],ts[k+1],ps[k+1],0)
    return out

def _lone_cubic(e):
    """The four control points (DXF) of a SPLINE that is one cubic Bézier, as Craft writes each piece of a spline."""
    if e['type']!='SPLINE':return None
    d=_spline_data(e['codes']);U=d['knots'];W=d['weights']
    if d['degree']!=3 or len(d['ctrl'])!=4 or len(U)!=8 or len(set(U[:4]))!=1 or len(set(U[4:]))!=1 or not U[3]<U[4]:return None
    if W and (len(W)!=4 or max(W)-min(W)>1e-12*abs(max(W))):return None
    return d['ctrl']

def _chained(entities):
    """exchange.export_dxf writes each cubic of a spline as one SPLINE: cubics that follow one another, each
    starting where the last one ended, on the same layer with the same look, are one spline again ('chain')."""
    out=[];end=look=None
    for e in entities:
        ctrl=_lone_cubic(e)
        if ctrl is None:out.append(e);end=None;continue
        mine=tuple(_get(e['codes'],c) for c in (8,6,62,420,370))
        if end is not None and mine==look and math.dist(end,ctrl[0])<=1e-6:
            if 'chain' not in out[-1]:out[-1]=dict(out[-1],chain=[out[-1]])
            out[-1]['chain'].append(e)
        else:out.append(e)
        end,look=ctrl[3],mine
    return out

def _spline_geometry(e,tol):
    """What a SPLINE (or a chain of them) draws, in Craft coordinates: ('cubic', its cubic Béziers) when Craft's
    spline holds it exactly (degree 1 to 3, not rational: its spans raised to degree 3; degree 1: ('poly', its
    corners)), else ('poly', points within ``tol`` of it: rational, degree 4 or more); with fit points only,
    Craft's spline through them (as AutoCAD: chord lengths, free ends or the tangents given). None: no point."""
    if e.get('chain'):return 'cubic',[[(x,-y) for x,y in _lone_cubic(q)] for q in e['chain']]
    d=_spline_data(e['codes']);p=d['degree'];P=[(x,-y) for x,y in d['ctrl']];U=d['knots'];W=d['weights'];n=len(P)
    if n>=2 and 1<=p<n and len(U)==n+p+1 and all(a<=b for a,b in zip(U,U[1:])) and U[p]<U[n]:
        rational=len(W)==n and max(W)-min(W)>1e-12*abs(max(W))
        if rational and min(W)<=0:return None
        if rational or p>3:return 'poly',_sampled(_spans(p,U,[(x*w,y*w,w) for (x,y),w in zip(P,W)] if rational else [(x,y,1.) for x,y in P]),tol)
        spans=_spans(p,U,P)
        if p==1:return 'poly',[spans[0][0]]+[s[1] for s in spans]
        return 'cubic',[s if p==3 else [s[0],tuple((x+2*y)/3 for x,y in zip(s[0],s[1])),tuple((z+2*y)/3 for z,y in zip(s[2],s[1])),s[2]] for s in spans]
    fit=[]
    for x,y in d['fit']:
        if not fit or math.dist(fit[-1],(x,-y))>1e-6:fit.append((x,-y))
    closed=bool(d['flags']&1)
    if closed and len(fit)>3 and math.dist(fit[0],fit[-1])<=1e-6:fit.pop()
    closed=closed and len(fit)>2
    if len(fit)<2:return None
    tangents={key:(v[0],-v[1]) for key,v in (('start',d['tangents'].get(12)),('end',d['tangents'].get(13))) if v and math.hypot(*v)>1e-12 and not closed}
    return 'cubic',cubics(spline(fit,closed,tangents=tangents or None))

def _fitted(segments,closed,name):
    """Craft's spline of these cubics; with its fit points when Craft's own spline through the cubics' ends
    (free ends, else the end tangents) gives them back: a spline Craft wrote keeps its points to move."""
    pts=[c[0] for c in segments]+([] if closed else [segments[-1][3]]);options=[None]
    if not closed:
        a,b=segments[0],segments[-1];t0=(a[1][0]-a[0][0],a[1][1]-a[0][1]);t1=(b[3][0]-b[2][0],b[3][1]-b[2][1])
        ok0,ok1=math.hypot(*t0)>1e-9,math.hypot(*t1)>1e-9
        options+=[v for v,ok in ((dict(start=t0,end=t1),ok0 and ok1),(dict(start=t0),ok0),(dict(end=t1),ok1)) if ok]
    for tangents in options:
        try:s=spline(pts,closed,name,tangents)
        except ValueError:break
        cs=cubics(s)
        if len(cs)==len(segments) and all(math.dist(p,q)<=1e-5 for c,d in zip(cs,segments) for p,q in zip(c,d)):return s
    return from_cubics([[tuple(p) for p in c] for c in segments],closed,name)

def _moved_text(codes,M):
    """The codes of an ATTRIB of a block moved where the block lands (DXF): points, height, angle."""
    nz=-1 if _num(codes,230,1.)<0 else 1;a=math.radians(_num(codes,50))
    p=_apply(M,(nz*_num(codes,10),_num(codes,20)));d=_turn(M,(nz*math.cos(a),math.sin(a)))
    out=[(c,v) for c,v in codes if c not in (10,20,11,21,40,50,210,220,230)]
    out+=[(10,p[0]),(20,p[1]),(40,_num(codes,40,2.5)*math.sqrt(abs(_det(M)))),(50,math.degrees(math.atan2(d[1],d[0])))]
    if _get(codes,11) is not None:
        q=_apply(M,(nz*_num(codes,11),_num(codes,21)));out+=[(11,q[0]),(21,q[1])]
    return out


# ---------------------------------------------------------------- 0.19.14: AutoCAD's dimensions as Craft's cotes
DIM_SIZES={41:2.5,140:2.5,40:1.}   # DIMASZ, DIMTXT, DIMSCALE when the file has no style (AutoCAD's ISO-25, Mozart's)

def _dim_overrides(codes):
    """{DIMxxx code: value} of a DIMENSION's own overrides (AutoCAD's extended data ACAD › DSTYLE)."""
    out={};on=False;key=None
    for c,v in codes:
        if c==1001:on=v.upper()=='ACAD';key=None;continue
        if not on:continue
        if c==1000 and v.upper()=='DSTYLE':key=0
        elif key is None or c==1002:continue
        elif c==1070 and key==0:key=int(_num([(c,v)],c))
        elif key:
            try:out[key]=float(v)
            except ValueError:pass
            key=0
    return out

def _cote_value(n):
    """A cote's value as Craft's cote tools write it (in mm): 180.28, 100."""
    return f'{float(f"{n:.6g}"):.2f}'.rstrip('0').rstrip('.')

def _cote_arrow(tip,toward,size):
    """An arrow of a cote as Craft's cote tools draw it: its point on ``tip``."""
    dx,dy=toward[0]-tip[0],toward[1]-tip[1];n=math.hypot(dx,dy) or 1;u=(dx/n,dy/n);v=(-u[1],u[0])
    s=polygon([tip,(tip[0]+u[0]*size+v[0]*size*.45,tip[1]+u[1]*size+v[1]*size*.45),(tip[0]+u[0]*size-v[0]*size*.45,tip[1]+u[1]*size-v[1]*size*.45)],'Flèche cote',True)
    s['filled']=True;return s

def _sector(center,a,b,p):
    """(start, sweep > 0) of the arc from the direction a to b (Craft angles) or from b to a, the one through p."""
    t=math.atan2(p[1]-center[1],p[0]-center[0]);ab=(b-a)%TAU
    return (a,ab) if (t-a)%TAU<=ab else (b,TAU-ab)

def _linear_cote(P1,P2,A,B,label,size):
    """A straight cote as craft_tools.dimensions makes it (extension lines from the measured points, the line, its two
    arrows, its value), its dimension line A-B given (rotated: not parallel to its points)."""
    length=math.dist(A,B);ux,uy=(B[0]-A[0])/length,(B[1]-A[1])/length;nx,ny=-uy,ux;size=min(size,length*.2)
    out=[shape('line','Cote',*p,q[0]-p[0],q[1]-p[1]) for p,q in ((P1,A),(A,B),(P2,B))]
    for origin,sign in ((A,1),(B,-1)):
        base=(origin[0]+sign*ux*size,origin[1]+sign*uy*size)
        arrow=polygon([origin,(base[0]+nx*size*.45,base[1]+ny*size*.45),(base[0]-nx*size*.45,base[1]-ny*size*.45)],'Flèche cote',True);arrow['filled']=True;out.append(arrow)
    return out+[label]


# ---------------------------------------------------------------- Mozart meaning
def _shoelace(pts):return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1]))/2

def _reversed_loop(pts,bs):
    n=len(pts);return pts[::-1],[-bs[(n-2-j)%n] for j in range(n)]

def _keyhole(outer,holes):
    """One closed contour for a zone with holes: each hole is joined to the outer loop by a
    there-and-back bridge, so the zone (a band along an edge) stays one closed polyline."""
    pts,bs=list(outer[0]),list(outer[1])
    for hp,hb in holes:
        k,j=min(((k,j) for k in range(len(pts)) for j in range(len(hp))),key=lambda kj:math.dist(pts[kj[0]],hp[kj[1]]))
        hp=hp[j:]+hp[:j];hb=hb[j:]+hb[:j]
        pts=pts[:k+1]+hp+[hp[0],pts[k]]+pts[k+1:];bs=bs[:k]+[0.]+hb+[0.,bs[k]]+bs[k+1:]
    return pts,bs

def _arc_of(a,b,bulge):
    """Centre, radius and sweep of a bulged segment."""
    c=((a[0]+b[0])/2-(b[1]-a[1])*(1-bulge*bulge)/(4*bulge),(a[1]+b[1])/2+(b[0]-a[0])*(1-bulge*bulge)/(4*bulge))
    return c,math.dist(a,c),4*math.atan(bulge)

def real_piece(s):
    """0.19.23: a closed polyline that is a true piece: some area inside, its outline crossing itself nowhere."""
    from geometry import outline_chords,crossing_pairs,outline_area
    pts=[(s['x']+x,s['y']+y) for x,y in s['points']];bs=(list(s.get('bulges') or [])+[0.]*len(pts))[:len(pts)]
    if len(pts)<(2 if any(bs) else 3) or abs(outline_area(pts,bs))<1e-3:return False
    return not crossing_pairs(outline_chords(pts,bs,True))

def merged_sides(s,tol=.005):
    """0.18.1: a Mozart contour with fewer anchors and the same shape: two straight segments in
    line become one, two arcs of the same circle become one (Mozart cuts sides and corners in
    two). ``tol`` (mm): how far the removed point may be from the merged side or circle."""
    if s.get('kind')!='poly' or len(s.get('points',[]))<3:return s
    closed=bool(s.get('closed'));pts=[(s['x']+x,s['y']+y) for x,y in s['points']];bs=list(s.get('bulges') or [0.]*len(pts))
    bs=(bs+[0.]*len(pts))[:len(pts)]
    def joined(k):
        """The bulge of the side k-1 → k+1 replacing the two sides around point k, or None."""
        n=len(pts);a,p,b=pts[k-1],pts[k],pts[(k+1)%n];u,v=bs[k-1],bs[k]
        if abs(u)<1e-12 and abs(v)<1e-12:
            d=math.dist(a,b)
            if d<1e-9 or (p[0]-a[0])*(b[0]-p[0])+(p[1]-a[1])*(b[1]-p[1])<=0:return None
            return 0. if abs((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]))/d<=tol else None
        if abs(u)<1e-12 or abs(v)<1e-12 or (u>0)!=(v>0):return None
        (c1,r1,s1),(c2,r2,s2)=_arc_of(a,p,u),_arc_of(p,b,v)
        if math.dist(c1,c2)>tol or abs(r1-r2)>tol or abs(s1+s2)>=2*math.pi-1e-6:return None
        return math.tan((s1+s2)/4)
    changed=True
    while changed and len(pts)>(3 if closed else 2):
        changed=False
        for k in range(len(pts)) if closed else range(1,len(pts)-1):
            if k==0 and not closed:continue
            new=joined(k)
            if new is None:continue
            bs[k-1]=new;del pts[k];del bs[k];changed=True
            if k==0:pts=pts[-1:]+pts[:-1];bs=bs[-1:]+bs[:-1]   # point 0 removed: the previous point leads
            break
    if len(pts)==len(s['points']):return s
    out=polygon(pts,s['name'],closed)
    if any(abs(b)>1e-12 for b in bs):out['bulges']=bs
    for key,value in s.items():
        if key not in out and key!='bulges':out[key]=copy.deepcopy(value)
    return out

def _cran_shape(block):
    """(depth, kind, bar width, cap width, gap) of a cran block, read from its strokes; ``gap``
    (0.18.1): where its stem is cut, in fractions of the depth (PitTacCT: 8 to 9,5 of 12)."""
    segs=[];bx,by=(block or {}).get('base',(0.,0.))
    for item in (block or {}).get('items',[]):
        codes=item['codes']
        if item['type']=='LINE':pts=[(_num(codes,10),_num(codes,20)),(_num(codes,11),_num(codes,21))]
        elif item['type']=='LWPOLYLINE':pts=list(zip([float(v) for c,v in codes if c==10],[float(v) for c,v in codes if c==20]))
        elif item['type']=='POLYLINE':pts=[(_num(s,10),_num(s,20)) for s in item['subs']]
        else:continue
        pts=[(x-bx,y-by) for x,y in pts];segs+=list(zip(pts,pts[1:]))
    depth=max((max(a[0],b[0]) for a,b in segs),default=0)
    if depth<1:return DEFAULT_CRAN
    bars=[(a[0],abs(b[1]-a[1])) for a,b in segs if abs(b[0]-a[0])<1e-6 and abs(b[1]-a[1])>1e-6]
    cap=max((w for x,w in bars if x>=depth*.95),default=0);mid=max((w for x,w in bars if x<depth*.95),default=0)
    stem=sorted((min(a[0],b[0]),max(a[0],b[0])) for a,b in segs if abs(a[1])<1e-6 and abs(b[1])<1e-6 and abs(b[0]-a[0])>1e-6)
    gap=None
    if stem and stem[0][0]<1e-6:
        reach=stem[0][1]
        for lo,hi in stem[1:]:
            if lo>reach+1e-6:gap=(reach/depth,lo/depth);break
            reach=max(reach,hi)
    if mid:return depth,'cross',mid,cap or None,gap if cap else None
    if cap:return depth,'t',cap,None,None
    return depth,None,None,None,None

def _preparation(label,xdata):
    """Kind, type, length and thickness of a Mozart preparation (text « REMBORD 7 », hatch data)."""
    text=' '.join(label.split()).upper()
    m=re.fullmatch(r'(.*?)\s*(\d+(?:[.,]\d+)?)\s*(?:MM)?',text)
    name,length=(m[1].strip(),float(m[2].replace(',','.'))) if m and m[1].strip() else (text,None)
    if name.startswith('REMBORD'):kind,typ='parage','rembord'
    elif 'PINCE' in name:kind,typ='parage','pince'
    elif name.startswith('PARAGE'):kind,typ='parage',' '.join(w for w in name.split()[1:] if w not in ('EN','A','À')).lower() or 'parage'
    elif name.startswith('TEINTE'):kind,typ='teinte','teinte'
    elif 'SURCOUPE' in name or name.startswith('RIFIL'):kind,typ='surcoupe','surcoupe'   # 0.18.1: family P_07
    else:kind,typ='autre',text.lower()
    def value(i):
        try:v=float(xdata[i].replace(',','.'));return v if 0<v<=1000 else None
        except (IndexError,ValueError):return None
    # MOZ_PREP xdata of the hatch: length, then (probably) the skiving thickness, in mm.
    return kind,typ,length if length is not None else value(0),value(1)


class _Mozart:
    def __init__(self,raw,stem,model_color):
        self.stem=stem;self.model_color=model_color;self.notes=Counter();self.lines=[]
        self.dxf=_Dxf(raw);sections=self.dxf.sections()
        self.header={};var=None
        for c,v in self.dxf.pairs(*sections.get('HEADER',(0,0))):
            if c==9:var=v;self.header[var]=[]
            elif var:self.header[var].append((c,v))
        # Mozart draws in mm; $INSUNITS is often a template leftover, so it only gives a warning.
        units=int(_num(self.header.get('$INSUNITS',[]),70,4))
        if units in UNITS:self.lines.append(f'Le DXF annonce des {UNITS[units]} : lu en millimètres, comme Mozart.')
        self.block_pairs=sections.get('BLOCKS',(0,0));self.block_index=None   # 0.18.7: read when a cran needs its block
        self.table_pairs=sections.get('TABLES',(0,0));self.dim_styles=None   # 0.19.14: read when a dimension needs its style
        self.entities=[e for e in self.dxf.entities(*sections.get('ENTITIES',(0,0))) if _shown(e['codes'])]

    def block(self,name):
        """dict(base, items) of the block ``name`` (its BLOCKs one after the other, the base of the
        first one), None when there is none."""
        if self.block_index is None:self.block_index=self.dxf.blocks(*self.block_pairs)
        found=self.block_index.get(name)
        if not found:return None
        codes=found[0][0]
        return dict(base=(_num(codes,10),_num(codes,20)),items=[e for _,a,b in found for e in self.dxf.entities(a,b)])

    # Craft coordinates before the final translation: x right, y down, mm.
    def mirror(self,codes):return -1 if _num(codes,230,1.)<0 else 1
    def P(self,x,y,mx=1):return (mx*x,-y)
    def angle(self,deg,mx=1):return -(deg if mx>0 else 180-deg)
    def text_at(self,codes,valign=73):
        """Baseline start, height, Craft angle and text of a TEXT or ATTRIB."""
        mx=self.mirror(codes);h=_num(codes,40,2.5);text=_plain(_get(codes,1,''));a=self.angle(_num(codes,50),mx)
        p=self.P(_num(codes,10),_num(codes,20),mx);hor=int(_num(codes,72));ver=int(_num(codes,valign))
        if (hor or ver) and hor not in (3,5) and _get(codes,11) is not None:
            q=self.P(_num(codes,11),_num(codes,21),mx);w=len(text)*h*.6;th=math.radians(a)
            dx={1:w/2,2:w,4:w/2}.get(hor,0);dy={2:-h/2,3:-h}.get(ver,-h/2 if hor==4 else 0)
            # Back from the alignment point to the baseline start (y down: dy<0 is above).
            p=(q[0]-dx*math.cos(th)+dy*math.sin(th),q[1]-dx*math.sin(th)-dy*math.cos(th))
        return p,h,a,text
    def text_centre(self,p,h,a,text):
        th=math.radians(a);w=len(text)*h*.6
        return p[0]+w/2*math.cos(th)+h/2*math.sin(th),p[1]+w/2*math.sin(th)-h/2*math.cos(th)
    def mtext(self,codes):
        """Top-left corner, height, Craft angle and text of an MTEXT (insertion point in WCS)."""
        text=_plain(''.join(v for c,v in codes if c==3)+_get(codes,1,''));h=_num(codes,40,2.5)
        if _get(codes,11) is not None:a=-math.degrees(math.atan2(_num(codes,21),_num(codes,11)))
        else:a=-_num(codes,50)
        lines=text.split('\n') or [''];w=max(len(t) for t in lines)*h*.6;H=h*(1.6*len(lines)-.6)
        att=int(_num(codes,71,1)) or 1;col=(att-1)%3;row=(att-1)//3;dx=-w*col/2;dy=-H*row/2
        q=self.P(_num(codes,10),_num(codes,20));th=math.radians(a)
        return (q[0]+dx*math.cos(th)-dy*math.sin(th),q[1]+dx*math.sin(th)+dy*math.cos(th)),h,a,text,w

    def run(self):
        self.consumed=set();self.model='';self.crans=[];self.drills=[];self.remap={};self.sheet=None;self.open_cut={};workspace,shift=self.base()
        self.budget=100000;self.block_items={}   # 0.19.9: block entities read at most (copies included); each block's, once
        geometry=[];preps=[];texts=[];inserts=[];skipped=Counter();hatches=Counter();cotes=[]
        for e in _chained(self.entities):   # 0.19.9: a spline Craft wrote as several SPLINEs is one again
            if id(e) in self.consumed:continue
            kind=e['type'];layer=_get(e['codes'],8,'0')
            if kind in GEOMETRY:
                got=self.geometry(e)
                if got is None:skipped[kind]+=1   # 0.19.9: a curve without anything readable
                else:geometry+=got
            elif kind=='HATCH':
                # 0.18.1: a hatch of the pink lines' layer (MOZ_PREP_PD) is a zone begun in Mozart
                # and never given a type: no fiche shows it, Craft does not import it.
                if layer.upper()=='MOZ_PREP_PD' and not _xdata(e['codes'],'MOZ_PREP'):self.notes['Zones sans type (calque des lignes roses) ignorées']+=1
                elif layer.upper().startswith('MOZ_PREP'):preps.append(e)
                else:hatches[layer]+=1
            elif kind in ('TEXT','MTEXT'):texts.append(e)
            elif kind=='INSERT':
                if self.ordinary(e):self.explode(e,None,layer,0,geometry,inserts,skipped)   # 0.19.9: its drawing, where it lands
                else:inserts.append(e)
            elif kind=='POINT' and layer.upper().startswith('CRAFT_'):
                self.drills.append(drill_mark(self.P(_num(e['codes'],10),_num(e['codes'],20),self.mirror(e['codes'])),0.))
            elif kind=='DIMENSION':
                got=self.dimension(e)   # 0.19.14: a cote of Craft
                if got:cotes+=got
                elif int(_num(e['codes'],70))&7==6:self.notes['Cotes en ordonnée non importées']+=1
                else:skipped[kind]+=1
            elif kind not in IGNORED:skipped[kind]+=1
        if skipped:self.lines.append('Entités non importées : '+', '.join(f'{k} ×{n}' for k,n in sorted(skipped.items()))+'.')
        if hatches:self.lines.append(f'Hachures hors préparations ignorées : {sum(hatches.values())}.')
        items=self.rejoined(geometry)
        self.pieces=[s for s in items if s['style']['role']=='external' and path(s)[1]];ids={id(s) for s in self.pieces}
        # Crans may sit on any stroke, pieces first; texts and zones belong to closed shapes only.
        self.hosts=self.pieces+[s for s in items if id(s) not in ids]
        self.others=[s for s in self.hosts[len(self.pieces):] if s['kind']!='line' and path(s)[1]]
        # 0.18.7: the box of every stroke, computed once: each cran and each text looked for its
        # piece with bounds() on all the strokes, most of the import time. The strokes keep their
        # geometry until the end of the import (only names, ids and infos are added to them).
        self.boxes=[(s,bounds([s])) for s in self.hosts];self.box={id(s):b for s,b in self.boxes}
        for s in self.pieces:ensure_piece_id(s)
        data=self.data(inserts)
        zones=self.preparations(preps,texts)
        items=self.precuts(items,zones)
        free=[self.free_text(e) for e in texts if id(e) not in self.consumed]
        rank={'external':0,'internal':1}
        items=[s for s in items if s['style']['role']=='drawing']+zones+sorted((s for s in items if s['style']['role']!='drawing'),key=lambda s:rank.get(s['style']['role'],2))
        items+=self.crans+self.drills+data+[s for s in free if s]+cotes
        for s in items:
            if s.get('owner_id') in self.remap:s['owner_id']=self.remap[s['owner_id']]   # 0.18.1: to the précoupe
        if workspace is None:
            kept=kept_base(self.sheet[1] if self.sheet else ())   # 0.19.25: written without its base, Craft's own
            if kept is not None:workspace,shift=kept,(0.,0.)
            elif any(_get(e['codes'],8,'').upper().startswith('CRAFT_') for e in self.entities):shift=(0.,0.)
            else:
                # Without a base the drawing comes near the origin (whole millimetres).
                x,y,_,_=bounds(items) if items else (0,0,0,0);shift=(-math.floor(x),-math.floor(y))
        for s in items:s['x']+=shift[0];s['y']+=shift[1]
        try:validate(items)
        except ValueError as exc:raise ValueError('Import Mozart impossible : '+str(exc)) from exc
        warnings=self.lines+[f'{text} : {n}.' if n>1 else text+'.' for text,n in self.notes.items()]
        # 0.19.13: a Mozart pattern (its layers or its blocks), saved there again by Enregistrer (aller-retour Craft ↔ Mozart)
        mozart=any(_get(e['codes'],8,'').upper().startswith(('PIT_','MOZ_')) or e['type']=='INSERT' and re.match(r'(PIT|MOZ)',_get(e['codes'],2,'').upper()) for e in self.entities)
        import model_info
        infos=model_info.from_mozart(*self.sheet) if self.sheet else None
        if self.model and not (infos or {}).get('modele'):infos=dict(infos or {},modele=self.model)   # 0.19.14: the model written in yellow on the pieces
        return dict(items=items,workspace=workspace,infos=infos,report=dict(pieces=len(self.pieces),crans=len(self.crans),labels=len(data),preparations=len(zones),drills=len(self.drills),warnings=warnings,model=self.model,mozart=bool(mozart)))

    # ------------------------------------------------------------ base
    def base(self):
        """The Craft base drawn in Mozart (« Présentation »): six titled columns."""
        found={}
        for e in self.entities:
            if e['type'] not in ('TEXT','MTEXT'):continue
            if e['type']=='MTEXT':p,h,a,text,w=self.mtext(e['codes']);x=p[0]+w/2
            else:p,h,a,text=self.text_at(e['codes']);x=self.text_centre(p,h,a,text)[0]
            words=text.upper().split()
            if words and words[0] in LABELS:found.setdefault(_get(e['codes'],8,'0'),{}).setdefault(LABELS.index(words[0]),(x,text,e))
        if not found:return None,(0.,0.)
        layer,labels=max(found.items(),key=lambda kv:(len(kv[1]),kv[0]=='Présentation'))
        if len(labels)<3:return None,(0.,0.)
        verticals=[];horizontals=[]
        for e in self.entities:
            if e['type']!='LINE' or _get(e['codes'],8,'0')!=layer:continue
            a=self.P(_num(e['codes'],10),_num(e['codes'],20));b=self.P(_num(e['codes'],11),_num(e['codes'],21))
            if abs(a[0]-b[0])<1e-6 and abs(a[1]-b[1])>1:verticals.append((a[0],min(a[1],b[1]),max(a[1],b[1]),e))
            elif abs(a[1]-b[1])<1e-6 and abs(a[0]-b[0])>1:horizontals.append((min(a[0],b[0]),max(a[0],b[0]),a[1],e))
        if not verticals:return None,(0.,0.)
        rule=max(horizontals,key=lambda h:h[1]-h[0]) if horizontals else None
        edges=sorted([v[0] for v in verticals]+([rule[0],rule[1]] if rule else []))
        edges=[x for i,x in enumerate(edges) if not i or x-edges[i-1]>.5]
        kind='petite' if 'petite' in labels.get(1,(0,''))[1].lower() else 'maro';w=default_workspace(kind);columns={}
        for index,(x,text,e) in labels.items():
            col=next((i for i in range(len(edges)-1) if edges[i]<=x<edges[i+1]),None)
            if col is None or col in columns.values():return None,(0.,0.)
            columns[index]=col
        ordered=sorted(columns)
        if [columns[i] for i in ordered]!=sorted(columns.values()):return None,(0.,0.)
        for index,col in columns.items():
            width=round(edges[col+1]-edges[col],3)
            if 50<=width<=5000:w['widths'][index]=width
            else:self.lines.append(f'Colonne {LABELS[index]} de {width:.0f} mm : largeur Craft par défaut.')
        top=min(v[1] for v in verticals);bottom=max(v[2] for v in verticals)
        header_y=rule[2] if rule else top+.7*w['header']
        # Craft draws the column lines from 30 % of the title band down to the base bottom.
        if header_y-top>1 and 20<=(header_y-top)/.7<=5000:w['header']=round((header_y-top)/.7,3)
        if 20<=bottom-header_y<=50000:w['height']=round(bottom-header_y,3)
        first=ordered[0];left=edges[columns[first]]
        self.consumed.update(id(v[3]) for v in verticals);self.consumed.update(id(labels[i][2]) for i in labels)
        if rule:self.consumed.add(id(rule[3]))
        return validate_workspace(w),(sum(w['widths'][:first])-left,w['header']-header_y)

    # ------------------------------------------------------------ geometry
    def geometry(self,e,M=None,layer=None):
        """[shape], [] for a stroke too short; 0.19.9: None for a curve without anything readable; ``M``: the map
        of the block it is drawn in (Craft coordinates), ``layer``: the layer it takes there."""
        codes=e['codes'];kind=e['type'];layer=layer or _get(codes,8,'0');name=layer.upper();mx=self.mirror(codes)
        profile='Coupe extérieure' if name in ('PIT_DIS_AREA','CRAFT_EXTERNAL') else 'Coupe intérieure' if name.startswith('PIT_DIS_TA') or name=='CRAFT_INTERNAL' else {'CRAFT_SEAM':'Couture','CRAFT_GUIDE':'Aide'}.get(name,'Dessin')
        if kind in ('ELLIPSE','SPLINE'):return self.curve(e,M,profile,layer)   # 0.19.9
        s=None
        if kind=='LINE':
            a=self.P(_num(codes,10),_num(codes,20));b=self.P(_num(codes,11),_num(codes,21))
            if M:a,b=_apply(M,a),_apply(M,b)   # 0.19.9: drawn in a block
            if math.dist(a,b)>=TINY:s=shape('line','Ligne',*a,b[0]-a[0],b[1]-a[1])
        elif kind=='CIRCLE':
            c=self.P(_num(codes,10),_num(codes,20),mx);r=_num(codes,40)
            if M and not _similar(M):return self.oval_item(c,(r,0.),(0.,r),0.,TAU,M,profile,layer)   # 0.19.9: a block scaled unevenly
            if M:c=_apply(M,c);r*=_stretch(M)
            if r*2>=TINY:s=shape('circle','Cercle',c[0]-r,c[1]-r,2*r,2*r)
        elif kind=='ARC':
            c=self.P(_num(codes,10),_num(codes,20),mx);r=_num(codes,40);s0=_num(codes,50);span=(_num(codes,51)-s0)%360 or 360.
            start,sweep=math.radians(-mx*s0+(180 if mx<0 else 0)),math.radians(-mx*span)
            if M:
                # 0.19.9: drawn in a block; scaled unevenly, an arc is an oval's arc (c + u cos t + v sin t)
                u=(r*math.cos(start),r*math.sin(start));v=(-u[1],u[0]) if sweep>0 else (u[1],-u[0])
                if not _similar(M):return self.oval_item(c,u,v,0.,abs(sweep),M,profile,layer)
                a0=_apply(M,(c[0]+u[0],c[1]+u[1]));c=_apply(M,c);r*=_stretch(M)
                start=math.atan2(a0[1]-c[1],a0[0]-c[0]);sweep=sweep if _det(M)>0 else -sweep
            if r*math.radians(span)>=TINY:s=arc(c,r,start,sweep)
        else:
            if kind=='LWPOLYLINE':
                pts=[];bs=[]
                for c,v in codes:
                    if c==10:pts.append([float(v),0.]);bs.append(0.)
                    elif c==20 and pts:pts[-1][1]=float(v)
                    elif c==42 and pts:bs[-1]=float(v)
                closed=bool(int(_num(codes,70))&1)
            else:
                flags=int(_num(codes,70))
                if flags&(16|64):self.notes['Maillages 3D ignorés']+=1;return []
                verts=[v for v in e['subs'] if not int(_num(v,70))&(16|64|128)];mx=1 if flags&8 else mx
                pts=[[_num(v,10),_num(v,20)] for v in verts];bs=[_num(v,42) for v in verts];closed=bool(flags&1)
            pts=[list(self.P(x,y,mx)) for x,y in pts];bs=[-mx*b for b in bs]
            if M:pts,bs=_moved_polyline(M,pts,bs,closed)   # 0.19.9: drawn in a block
            if len(pts)>2 and math.dist(pts[0],pts[-1])<=1e-6:pts,bs,closed=pts[:-1],bs[:-1],True
            if len(pts)>=2:
                s=polygon(pts,'Pièce' if closed and profile=='Coupe extérieure' else 'Contour',closed)
                if any(abs(b)>1e-12 for b in bs):s['bulges']=bs
                s=merged_sides(without_micro(s))
                pp,cl=path(s);length=sum(math.dist(a,b) for a,b in zip(pp,pp[1:]+(pp[:1] if cl else [])))
                if length<TINY:s=None
        return self.finish([s] if s is not None else [],profile,layer)   # 0.19.9: shared with the curves

    def finish(self,shapes,profile,layer):
        """The profile of the strokes read from one entity; none: it was shorter than TINY."""
        if not shapes:self.notes[f'Traits de moins de {TINY:g} mm ignorés'.replace('.',',')]+=1;return []
        for s in shapes:
            s['profile']=profile;s['style']=dict(PROFILES[profile])
            if profile=='Coupe extérieure' and not path(s)[1]:
                note=f'Contours de pièce ouverts ({layer}) importés en trait';self.notes[note]+=1;self.__dict__.setdefault('open_cut',{})[id(s)]=note
        return shapes

    def rejoined(self,items,tolerance=.02):
        """0.19.22 (his Tilted.dwg: DBL FOND drawn as four lines on the cut layer): open strokes of the cut layer meeting
        end to end all around, without a branch, are one closed piece (as Joindre would make it)."""
        from editing import join_shapes
        cut=self.__dict__.get('open_cut') or {}
        loose=[s for s in items if id(s) in cut and not s.get('spline') and not s.get('ellipse')]
        if len(loose)<2 or len(loose)>2000:return items
        ends=[(k,p) for k,s in enumerate(loose) for p in (path(s)[0][0],path(s)[0][-1])]
        grid={}
        for n,(k,p) in enumerate(ends):grid.setdefault((round(p[0]/tolerance),round(p[1]/tolerance)),[]).append(n)
        def near(p):
            gx,gy=round(p[0]/tolerance),round(p[1]/tolerance)
            return [n for dx in (-1,0,1) for dy in (-1,0,1) for n in grid.get((gx+dx,gy+dy),()) if math.dist(ends[n][1],p)<=tolerance]
        group=list(range(len(loose)))
        def root(k):
            while group[k]!=k:group[k]=group[group[k]];k=group[k]
            return k
        for n,(k,p) in enumerate(ends):
            for m in near(p):group[root(ends[m][0])]=root(k)
        found={}
        for k in range(len(loose)):found.setdefault(root(k),[]).append(k)
        made=[];used=set()
        for members in found.values():
            if len(members)<2 or any(len(near(p))!=2 for k in members for p in (path(loose[k])[0][0],path(loose[k])[0][-1])):continue
            try:joined=join_shapes([loose[k] for k in members],tolerance)
            except (ValueError,KeyError,TypeError):continue
            if not path(joined)[1]:continue
            joined=merged_sides(without_micro(joined))
            # 0.19.23 (review): a true piece only: a real area, its outline crossing nowhere (a line drawn twice, a bow tie:
            # left as strokes, as before)
            if joined.get('kind')!='poly' or not real_piece(joined):continue
            joined['name']='Pièce';joined['profile']='Coupe extérieure';joined['style']=dict(PROFILES['Coupe extérieure'])
            joined.pop('piece_id',None);made.append(joined)
            for k in members:
                used.add(id(loose[k]));note=cut[id(loose[k])];self.notes[note]-=1
                if self.notes[note]<=0:del self.notes[note]
        if made:self.notes['Pièces refaites de traits bout à bout']+=len(made)
        return [s for s in items if id(s) not in used]+made

    def curve(self,e,M,profile,layer):
        """0.19.9: an ELLIPSE (an arc of it or the whole oval) as Craft's oval; a SPLINE (or a chain of them) as
        Craft's spline when it holds it exactly, else as a polyline within 0,005 mm of it (_spline_geometry);
        moved by M in a block. None: nothing readable (no point, a flat oval)."""
        codes=e['codes'];external=profile=='Coupe extérieure'
        if e['type']=='ELLIPSE':
            X,Y,ratio=_num(codes,11),_num(codes,21),_num(codes,40,1.);nz=-1. if _num(codes,230,1.)<0 else 1.
            t0=_num(codes,41);span=(_num(codes,42,TAU)-t0)%TAU
            if span<=1e-9 or span>=TAU-1e-9:span=TAU   # the whole oval
            # centre + major axis cos t + ratio (normal × major axis) sin t, with Craft's y going down
            return self.oval_item(self.P(_num(codes,10),_num(codes,20)),(X,-Y),(-nz*ratio*Y,-nz*ratio*X),t0,span,M,profile,layer)
        try:got=_spline_geometry(e,.002/(_stretch(M) if M else 1.))
        except (ValueError,ZeroDivisionError,OverflowError):got=None
        if got is None:return None
        kind,data=got;shapes=[]
        if M:data=[[_apply(M,p) for p in c] for c in data] if kind=='cubic' else [_apply(M,p) for p in data]
        if kind=='cubic':data=[c for c in data if max(math.dist(c[0],q) for q in c[1:])>1e-9]
        if kind=='cubic' and data:
            closed=math.dist(data[0][0],data[-1][3])<=1e-6
            if closed:data[-1]=list(data[-1][:3])+[data[0][0]]
            name='Pièce' if closed and external else 'Spline'
            shapes=[_fitted(data[k:k+1000],closed and len(data)<=1000,name) for k in range(0,len(data),1000)]
        elif kind=='poly' and len(data)>=2:
            closed=len(data)>3 and len(data)<=5001 and math.dist(data[0],data[-1])<=1e-6
            if closed:data=data[:-1]
            name='Pièce' if closed and external else 'Contour'
            shapes=[without_micro(polygon(data[k:k+5000],name,closed)) for k in range(0,len(data)-1,4999)]
        length=sum(sum(math.dist(a,b) for a,b in zip(pp,pp[1:]+(pp[:1] if cl else []))) for pp,cl in map(path,shapes))
        return self.finish(shapes if length>=TINY else [],profile,layer)

    def oval_item(self,c,u,v,t0,span,M,profile,layer):
        """0.19.9: Craft's oval c + u cos t + v sin t (_oval) moved by M; None when flat."""
        if M:c,u,v=_apply(M,c),_turn(M,u),_turn(M,v)
        s=_oval(c,u,v,t0,span,'Pièce' if span>=TAU and profile=='Coupe extérieure' else 'Ovale')
        if s is None:return self.finish([],profile,layer) if max(math.hypot(*u),math.hypot(*v))*span<TINY else None
        return self.finish([s] if ellipse_length(s)>=TINY else [],profile,layer)

    # ------------------------------------------------------------ blocks (0.19.9)
    def ordinary(self,e):
        """An INSERT of a block that is not Mozart's (PIT…, MOZ…: crans, drills, names, model sheet: data),
        drawn in the file (an external reference is not: « Blocs non importés ») and not flattened (scale 0)."""
        name=_get(e['codes'],2,'')
        if re.match(r'(PIT|MOZ)',name.upper()) and not name.upper().startswith('PITBT'):return False   # 0.19.22: PITBT: a piece of a cutting DXF (AAMA)
        block=self.block(name)
        return block is not None and bool(block['items']) and abs(_det(_insert_matrix(e['codes'],(0.,0.))))>1e-12

    def explode(self,e,M,layer,depth,out,inserts,skipped):
        """The strokes of an ordinary block where its INSERT puts them (``M``: the blocks around it, DXF):
        insertion point, scales (negative: mirrored), rotation, columns and rows of a MINSERT, read like the
        drawing's own; on layer 0 a stroke takes the INSERT's layer, as in AutoCAD; blocks in it too, 8 deep.
        A Mozart block inside one is read by ``data`` where it lands; its texts, hatches, visible attributes
        and other entities are counted as not imported. A block repeated so much that the drawing would pass
        8 000 strokes (Craft holds 10 000 objects) stays out, in « Blocs non importés » as before."""
        codes=e['codes'];name=_get(codes,2,'');block=self.block(name)
        if name not in self.block_items:self.block_items[name]=_chained([q for q in block['items'] if _shown(q['codes'])])
        items=self.block_items[name];cols,rows=max(1,int(_num(codes,70,1.))),max(1,int(_num(codes,71,1.)))
        if cols*rows*(len(items)+1)>self.budget or len(out)+cols*rows*len(items)>8000:inserts.append(e);return
        self.budget-=cols*rows*(len(items)+1);shown=sum(1 for a in e['subs'] if not int(_num(a,70))&1)
        if shown:skipped['ATTRIB']+=shown
        for i in range(cols):
            for j in range(rows):
                N=_compose(M or IDENTITY,_insert_matrix(codes,block['base'],i,j));C=_craft(N)
                for q in items:
                    qc=q['codes'];kind=q['type'];own=_get(qc,8,'0');lay=layer if own=='0' else own
                    if own=='1' and name.upper().startswith('PITBT'):lay='PIT_DIS_AREA'   # 0.19.22: AAMA: layer 1 is the cut line
                    if kind in GEOMETRY:
                        got=self.geometry(q,C,lay)
                        if got is None:skipped[kind]+=1
                        else:out+=got
                    elif kind=='INSERT':
                        if depth<8 and self.ordinary(q):self.explode(q,N,lay,depth+1,out,inserts,skipped)
                        elif re.match(r'(PIT|MOZ)',_get(qc,2,'').upper()):inserts.append(self.placed(q,N,lay))
                        else:inserts.append(q)   # its block is missing (or too deep): « Blocs non importés »
                    elif kind=='POINT' and lay.upper().startswith('CRAFT_'):self.drills.append(drill_mark(_apply(C,self.P(_num(qc,10),_num(qc,20),self.mirror(qc))),0.))
                    elif kind not in IGNORED:skipped[kind]+=1

    def placed(self,q,N,layer):
        """A Mozart block (cran, drill, name…) inside an ordinary block, as an INSERT of the drawing (DXF): where
        it lands, its X axis (rotation, X scale), its Y scale (negative: mirrored), its attributes moved with it."""
        a,b,c,d,e,f=_compose(N,_insert_matrix(q['codes'],(0.,0.)))
        codes=[(2,_get(q['codes'],2,'')),(8,layer),(10,e),(20,f),(41,math.hypot(a,c)),(42,math.copysign(math.hypot(b,d),a*d-b*c)),(50,math.degrees(math.atan2(c,a)))]
        return dict(type='INSERT',codes=codes,subs=[_moved_text(t,N) for t in q['subs']])

    # ------------------------------------------------------------ dimensions (0.19.14)
    def dim_style(self,name):
        """{code: value} of the dimension style ``name`` (TABLES › DIMSTYLE), {} when the file has none."""
        if self.dim_styles is None:
            self.dim_styles={};a,b=self.table_pairs;zs=self.dxf.zeros;lo=bisect_left(self.dxf.at,a);hi=bisect_left(self.dxf.at,b)
            for i in range(lo,hi):
                if zs[i][1]!='DIMSTYLE':continue
                codes=self.dxf.pairs(zs[i][0]+1,zs[i+1][0] if i+1<len(zs) else b);out={}
                for c,v in codes:
                    try:out.setdefault(c,v if c==2 else float(v))
                    except ValueError:out.setdefault(c,v)
                self.dim_styles.setdefault(str(out.get(2,'')).upper(),out)
        return self.dim_styles.get((name or '').upper(),{})

    def dimension(self,e):
        """0.19.14: an AutoCAD DIMENSION as Craft's cote (what its cote tools make: lines, arrows, the value, one group):
        straight (rotated: horizontal, vertical; aligned), radius, diameter, angle (2 lines or 3 points), from its
        definition points (y downwards; 11 and 16 in its own axes: mirrored when its normal points down); its value the
        measurement (« <> » in its text), its text's size and angle those drawn in its block, its arrows its style's
        (DSTYLE overrides first; Mozart: ISO-25). None: a kind Craft has no cote for (ordinate) or nothing to measure."""
        codes=e['codes'];kind=int(_num(codes,70))&7;mx=self.mirror(codes)
        def pt(code,ocs=False):return self.P(_num(codes,code),_num(codes,code+10),mx if ocs else 1)
        style=self.dim_style(_get(codes,3,''));own=_dim_overrides(codes)
        def size(code):
            v=own.get(code,style.get(code,DIM_SIZES[code]))
            return v if isinstance(v,float) and v>0 else DIM_SIZES[code]
        scale=size(40);arrow=size(41)*scale;height=size(140)*scale;angle=None
        block=self.block(_get(codes,2,'')) if _get(codes,2) else None;strokes=[]
        for q in (block or {}).get('items',[]):
            c=q['codes']
            if angle is None and q['type']=='TEXT':height,angle=_num(c,40,height),0.-_num(c,50)
            elif angle is None and q['type']=='MTEXT':   # its direction, or its angle (radians)
                height=_num(c,40,height);angle=0.-(math.degrees(math.atan2(_num(c,21),_num(c,11,1.))) if _get(c,11) is not None else _num(c,50))   # (50: degrees)
            elif q['type']=='LINE':strokes.append((self.P(_num(c,10),_num(c,20)),self.P(_num(c,11),_num(c,21))))
        height=min(30,max(.5,height));M=pt(11,True)
        user=_get(codes,1,'')
        def label(default,direction):
            text=_plain(user.replace('<>',default)) if user.strip() not in ('','<>') else default
            return aligned_annotation(text[:200] or default,M,angle if angle is not None else direction,height)
        width=.12
        if kind in (0,1):
            P1,P2,D=pt(13),pt(14),pt(10)
            if kind==0:a=math.radians(_num(codes,50));u=(math.cos(a),-math.sin(a))
            else:
                n=math.dist(P1,P2)
                if n<1e-9:return None
                u=((P2[0]-P1[0])/n,(P2[1]-P1[1])/n)
            A,B=[(D[0]+u[0]*((p[0]-D[0])*u[0]+(p[1]-D[1])*u[1]),D[1]+u[1]*((p[0]-D[0])*u[0]+(p[1]-D[1])*u[1])) for p in (P1,P2)]
            value=math.dist(A,B)
            if value<1e-6:return None
            out=_linear_cote(P1,P2,A,B,label(_cote_value(value),math.degrees(math.atan2(B[1]-A[1],B[0]-A[0]))),arrow);width=.15
        elif kind==4:
            C,T=pt(10),pt(15);r=math.dist(C,T)
            if r<1e-9:return None
            u=((T[0]-C[0])/r,(T[1]-C[1])/r);tol=1e-6*max(1.,r)
            # the end of its leader: the line of its block from its point on the arc, else towards its text
            P=next((b if math.dist(a,T)<=tol else a for a,b in strokes if min(math.dist(a,T),math.dist(b,T))<=tol and math.dist(a,b)>tol),None)
            if P is None:
                along=(M[0]-C[0])*u[0]+(M[1]-C[1])*u[1];P=(C[0]+u[0]*along,C[1]+u[1]*along)
                if math.dist(P,T)<1e-3:P=(T[0]+u[0]*2*arrow,T[1]+u[1]*2*arrow)
            out=[shape('line','Rayon',*T,P[0]-T[0],P[1]-T[1]),_cote_arrow(T,P,arrow),label('R'+_cote_value(r),math.degrees(math.atan2(P[1]-T[1],P[0]-T[0])))]
        elif kind==3:
            F,N=pt(10),pt(15);value=math.dist(F,N)
            if value<1e-9:return None
            out=[shape('line','Diamètre',*F,N[0]-F[0],N[1]-F[1]),_cote_arrow(F,N,arrow),_cote_arrow(N,F,arrow),label('Ø'+_cote_value(value),math.degrees(math.atan2(N[1]-F[1],N[0]-F[0])))]
        elif kind in (2,5):
            if kind==5:
                V,L=pt(15),pt(10);Q1,Q2=pt(13),pt(14)
                start,sweep=_sector(V,math.atan2(Q2[1]-V[1],Q2[0]-V[0]),math.atan2(Q1[1]-V[1],Q1[0]-V[0]),L)
            else:
                from editing import line_intersection
                p1,p2,p3,p4=pt(13),pt(14),pt(10),pt(15);L=pt(16,True)   # its two lines, the point of its arc
                try:V=line_intersection(p1,p2,p3,p4)
                except ValueError:return None
                sides=(math.atan2(p2[1]-p1[1],p2[0]-p1[0]),math.atan2(p4[1]-p3[1],p4[0]-p3[0]))
                rays=sorted(t%TAU for w in sides for t in (w,w+math.pi))   # the 4 half-lines from the vertex: the arc is between 2
                t=math.atan2(L[1]-V[1],L[0]-V[0])%TAU;k=max([i for i in range(4) if rays[i]<=t] or [3])
                start=rays[k];sweep=(rays[(k+1)%4]-start)%TAU
            r=math.dist(V,L)
            if r<1e-6 or not 1e-9<sweep<TAU-1e-9:return None
            q=arc(V,r,start,sweep,'Cote d’angle');pts=path(q)[0]
            out=[q,_cote_arrow(pts[0],pts[1],arrow),_cote_arrow(pts[-1],pts[-2],arrow),label(f'{math.degrees(sweep):.1f}°',math.degrees(start+sweep/2)+90)]
        else:return None   # ordinate: no cote of Craft for it
        group=uuid.uuid4().hex
        for s in out:
            s['dimension_group']=group;s['style']=dict(color='auto',width=width,dash=[],role='dimension')
            if s.get('annotation') and (kind not in (0,1) or abs(s.get('text_angle',0))>90+1e-9):s['text_angle']=(s.get('text_angle',0)+90)%180-90   # as the cote tools: never upside down
        return out

    # ------------------------------------------------------------ ownership
    def owner(self,points,pool=None):
        """The smallest closed piece containing most of the points (pieces before drawings)."""
        for group in ([pool] if pool is not None else [self.pieces,self.others]):
            best=None
            for s in group:
                box=self.box.get(id(s));x,y,X,Y=box if box is not None else bounds([s])
                if not any(x-.05<=p[0]<=X+.05 and y-.05<=p[1]<=Y+.05 for p in points):continue
                count=sum(1 for p in points if inside(s,p) or math.dist(contour_location(s,p)[1],p)<.05)
                if count*2<len(points) or count==0:continue
                key=(-count,abs(_shoelace(path(s)[0])))
                if best is None or key<best[0]:best=(key,s)
            if best:return best[1]
        return None

    def nearest(self,p,reach):
        best=None
        for s,(x,y,X,Y) in self.boxes:
            if not (x-reach<=p[0]<=X+reach and y-reach<=p[1]<=Y+reach):continue
            d=math.dist(contour_location(s,p)[1],p)
            if d<=reach and (best is None or d<best[0]-1e-9):best=(d,s)
        return best

    # ------------------------------------------------------------ inserts
    def data(self,inserts):
        labels=[];names=[];materials=[];models=[];unknown=Counter();moved=[];forms={}
        for e in inserts:
            name=_get(e['codes'],2,'');up=name.upper();codes=e['codes'];mx=self.mirror(codes)
            p=self.P(_num(codes,10),_num(codes,20),mx);attrs={_get(a,2,'').upper():a for a in e['subs']}
            if up.startswith('PITTAC') or up.startswith('MOZ_TAC'):
                sx,sy=_num(codes,41,1.),_num(codes,42,1.);th=math.radians(_num(codes,50))
                u=(mx*math.cos(th)*(1 if sx>=0 else -1),-math.sin(th)*(1 if sx>=0 else -1))
                # 0.18.7: each cran block is read once, not once per cran (a model has a few blocks for 100s of crans).
                if name not in forms:forms[name]=_cran_shape(self.block(name))
                depth,kind,width,cap,gap=forms[name];f=abs(sy or 1)
                mark=dict(depth=min(100,max(.1,depth*abs(sx or 1))))
                if kind:mark.update(kind=kind,width=min(100,max(.1,width*f)))
                if cap:mark['cap_width']=min(100,max(.1,cap*f))
                if gap:mark['gap']=[gap[0],gap[1]]
                self.cran(p,u,mark,moved)
            elif up=='MOZ_FUST':
                eti=_plain(_get(attrs.get('ETI',[]),1,'')).replace(',','.')
                try:d=float(eti)
                except ValueError:d=0.
                if not 0<=d<=10:self.notes['Mèches de plus de 10 mm posées en pointé']+=1;d=0.
                self.drills.append(drill_mark(p,d))
            elif up in ('PITDATIT','PITDATIM','PITNUM'):
                text=lambda tag:_plain(_get(attrs.get(tag,[]),1,''))
                spot=self.text_at(attrs['TESTO1'],74) if 'TESTO1' in attrs else (p,2.,self.angle(_num(codes,50),mx),'')
                if up=='PITNUM':models.append((p,text('NUMEROARTICOLO')))
                elif up=='PITDATIT':names.append((spot,text('TESTO1'),[text('NU1'),text('TIPOLOGIA'),text('NU2')]))
                else:materials.append((spot,text('TESTO1'),text('MATERIALE'),text('NPEZZI'),text('NUM1'),{tag:text(tag) for tag in attrs},_xdata(codes,'CRAFT')))   # 0.19.13: the whole fiche
            elif up=='MOZ_INFO':self.sheet=(_xdata(codes,'MOZ_INFO'),_xdata(codes,'CRAFT'))   # 0.19.13: the model sheet
            elif not re.match(r'(PIT|MOZ)',up):unknown[name]+=1
        if moved:self.lines.append('Crans posés à côté du contour dans Mozart (jusqu’à '+f'{max(moved):.1f}'.replace('.',',')+f' mm), ramenés sur leur pièce : {len(moved)}.')
        if unknown:self.lines.append('Blocs non importés : '+', '.join(f'{k} ×{n}' for k,n in sorted(unknown.items()))+'.')
        common=Counter(m for _,m in models if m).most_common(1)
        default=common[0][0] if common else self.stem;self.model=common[0][0] if common else ''
        def model(p):
            near=[(math.dist(q,p),m) for q,m in models if m and math.dist(q,p)<=50]
            return min(near)[1] if near else default
        for (p,h,a,_),full,parts in names:
            full=full or ' '.join(v for v in parts if v)
            if not full:continue
            values=parts if ' '.join(v for v in parts if v)==full else [full,'','']
            h=min(30,max(.5,h));m=model(p);th=math.radians(a)
            runs=[dict(text=m,height=max(.5,h*.85),dy=0,color=self.model_color,weight='bold',underline=True),
                  dict(text='  '.join(v for v in values if v),height=h,dy=h*1.8,color='auto',weight='normal')]
            # The name line keeps the Mozart baseline.
            corner=(p[0]+2.8*h*math.sin(th),p[1]-2.8*h*math.cos(th))
            labels.append(self.label(corner,runs,a,dict(kind='part_name',model=m,values=values,height=h,quantity='1',details=''),p,full))
        for (p,h,a,_),full,material,count,num1,attributes,craft in materials:
            match=re.match(r'^\s*(\d+)\s+(.*)$',full);name=(match[2] if match else full).strip() or re.sub(r'^[A-Z]-','',material).strip()
            if not name:continue
            try:qty=int(float(count))
            except ValueError:qty=int(match[1]) if match else 1
            qty=min(999,max(1,qty))
            try:tenths=round(float(num1.replace(',','.'))*10,3)
            except ValueError:tenths=0
            refente=f'{tenths:g}' if tenths>0 else ''
            h=min(30,max(.5,h));m=model(p);th=math.radians(a)
            runs=[dict(text=f'{qty} {name}'+(f' refente {refente}/10' if refente else ''),height=h,dy=0,color='auto',weight='normal')]
            corner=(p[0]+h*math.sin(th),p[1]-h*math.cos(th))
            sheet=piece_sheet.from_mozart(attributes,craft,qty)   # 0.19.13: coups de presse, couleur, couper avec…
            labels.append(self.label(corner,runs,a,dict(kind='material',model=m,values=[name],height=h,quantity=str(qty),details='',refente=refente,**sheet),p,None))
        return [s for s in labels if s]

    def label(self,corner,runs,angle,identification,anchor,name):
        s=text_bundle(corner,runs,angle,identification);host=self.owner([anchor])
        if host is None:   # 0.19.22: a small piece: Mozart starts its text outside it, the text lies on it
            x,y,X,Y=bounds([s]);host=self.owner([((x+X)/2,(y+Y)/2)])
        if host is None:self.notes['Textes Mozart hors de toute pièce (non rattachés)']+=1;return s
        s['owner_id']=ensure_piece_id(host);host.setdefault('piece_info',{})[identification['kind']]=clone(identification)
        if name:host['name']=name[:200]
        return s

    def cran(self,p,u,mark,moved):
        reach=max(TOUCH,mark['depth']);hit=self.nearest(p,reach)
        if hit is None:self.notes['Crans sans contour proche (ignorés)']+=1;return
        d,host=hit;foot=p
        if d>TOUCH:
            # Off the contour (fold line, base of a tooth): the foot is where the Mozart cran
            # axis crosses the contour, else the nearest point.
            axis=shape('line','',p[0]-u[0]*reach,p[1]-u[1]*reach,2*u[0]*reach,2*u[1]*reach)
            hits=[q for q in intersections(axis,host) if math.dist(q,p)<=reach]
            foot=min(hits,key=lambda q:math.dist(q,p)) if hits else contour_location(host,p)[1];moved.append(math.dist(foot,p))
        try:distance,_=locate(host,foot);_,normal=at_distance(host,distance)
        except (ValueError,ZeroDivisionError):self.notes['Crans sur un contour sans longueur (ignorés)']+=1;return
        # The Craft cran points to the same side of the contour as the Mozart block's X axis,
        # and keeps that axis when Mozart did not draw it square to the contour.
        dot=u[0]*normal[0]+u[1]*normal[1];mark.update(distance=distance,side=1 if dot>=0 else -1)
        if abs(dot)<math.cos(math.radians(2)):mark['direction']=list(u)
        cran=standalone_notch(host,mark);cran['owner_id']=ensure_piece_id(host);self.crans.append(cran)

    # ------------------------------------------------------------ preparations
    def preparations(self,hatches,texts):
        zones=[];candidates=[]
        for e in texts:
            layer=_get(e['codes'],8,'0')
            if e['type']=='TEXT' and layer.upper().startswith('MOZ_PREP'):
                p,h,a,text=self.text_at(e['codes'])
                if text:candidates.append((layer,self.text_centre(p,h,a,text),text,e))
        built=[]
        for e in hatches:
            codes=e['codes'];mx=self.mirror(codes);raw,approx=_hatch_loops(codes)
            if approx:self.notes['Bords de préparation en spline approchés']+=1
            loops=[([self.P(x,y,mx) for x,y in pts],[-mx*b for b in bs]) for pts,bs in raw]
            shapes=[]
            for pts,bs in loops:
                q=polygon(pts,'',True);q['bulges']=bs;shapes.append(q)
            if not shapes:self.notes['Préparations sans contour lisible']+=1;continue
            depth=[sum(1 for j,t in enumerate(shapes) if j!=i and inside(t,path(s)[0][0])) for i,s in enumerate(shapes)]
            islands=[]
            for i in [i for i in range(len(shapes)) if depth[i]%2==0]:
                holes=[j for j in range(len(shapes)) if depth[j]==depth[i]+1 and inside(shapes[i],path(shapes[j])[0][0])]
                outer=loops[i]
                if _shoelace(path(shapes[i])[0])<0:outer=_reversed_loop(*outer)
                inner=[loops[j] if _shoelace(path(shapes[j])[0])<0 else _reversed_loop(*loops[j]) for j in holes]
                islands.append(_keyhole(outer,inner))
            built.append((e,islands,shapes))
        # Each hatch takes the nearest unused text of its layer (inside the zone first), never
        # one whose length contradicts the hatch data (« REMBORD 7 » and « REMBORD 8 » share a layer).
        pairs=[]
        for k,(e,islands,shapes) in enumerate(built):
            layer=_get(e['codes'],8,'0');length=_preparation('',_xdata(e['codes'],'MOZ_PREP'))[2]
            for t,(tl,centre,text,te) in enumerate(candidates):
                if tl!=layer:continue
                d=min(0. if inside(s,centre) else math.dist(contour_location(s,centre)[1],centre) for s in shapes)
                own=_preparation(text,[])[2]
                pairs.append((d+(1e9 if length and own and own!=length else 0),k,t))
        given={};used=set()
        for d,k,t in sorted(pairs):
            if k in given or t in used:continue
            given[k]=t;used.add(t)
        for k,(e,islands,shapes) in enumerate(built):
            layer=_get(e['codes'],8,'0');xdata=_xdata(e['codes'],'MOZ_PREP')
            if k in given:
                label=candidates[given[k]][2];self.consumed.add(id(candidates[given[k]][3]))
            else:
                label=(xdata[4].strip() if len(xdata)>4 else '') or re.sub(r'^MOZ_PREP_[A-Z]_\d+_','',layer,flags=re.I).strip()
                self.notes['Préparations sans texte (nom du calque)']+=1
            kind,typ,length,thickness=_preparation(label,xdata)
            if re.match(r'^MOZ_PREP_P_07',layer,re.I):kind,typ='surcoupe','surcoupe'   # 0.18.1 Surcoupe / filetage
            extra={}
            if kind=='teinte':
                try:extra['couches']=max(1,min(20,int(float(xdata[2]))))
                except (IndexError,ValueError):pass
            holes=[]
            if kind=='surcoupe':
                # The band between the précoupe and the pieces to recut: its width, and the holes
                # (the pieces' contours) to find among the lines.
                loops=[path(q)[0] for q in shapes];depth=[sum(1 for j,t in enumerate(shapes) if j!=i and inside(t,loops[i][0])) for i in range(len(shapes))]
                area=lambda pts:abs(_shoelace(pts));perim=lambda pts:sum(math.dist(a,b) for a,b in zip(pts,pts[1:]+pts[:1]))
                outer=[loops[i] for i in range(len(loops)) if depth[i]%2==0];inner=[loops[i] for i in range(len(loops)) if depth[i]%2]
                ring=sum(area(p) for p in outer)-sum(area(p) for p in inner);line=(sum(perim(p) for p in outer)+sum(perim(p) for p in inner))/2
                if length is None and inner and line>0:length=round(ring/line,2)
                holes=[(min(q[0] for q in loops[i]),min(q[1] for q in loops[i]),max(q[0] for q in loops[i]),max(q[1] for q in loops[i]),area(loops[i]),shapes[i]) for i in range(len(loops)) if depth[i]%2]
            for pts,bs in islands:
                z=polygon(pts,'Préparation',True)
                if any(abs(b)>1e-12 for b in bs):z['bulges']=bs
                z['style']=dict(color=PREP_COLORS[kind],width=.1,dash=[],role='preparation')
                z['preparation']=dict(kind=kind,type=typ,length=length,thickness=thickness,label=label,**extra)
                # One hatch may cover several précoupes: each island takes the holes inside it (by
                # their boxes: a hole's points lie on the island's own outline).
                x,y,X,Y=bounds([z])   # 0.18.7: once (a zone may have 10⁴ points to hash for the cache)
                mine=[h for h in holes if x-.05<=h[0] and y-.05<=h[1] and h[2]<=X+.05 and h[3]<=Y+.05]
                if mine:z['_holes']=mine
                host=self.owner([((x+X)/2,(y+Y)/2)]+[tuple(q) for q in pts])
                if host is None:self.notes['Zones de préparation hors de toute pièce (posées sur leur pièce, elles s’y rattachent)']+=1
                else:z['owner_id']=ensure_piece_id(host)
                zones.append(z)
        return zones

    def precuts(self,items,zones):
        """0.18.1: a piece with a Surcoupe zone is a précoupe (Mozart's anse: cut 36 × 720, recut to
        26 × 710): the contour of each hole of the zone becomes a piece to recut (« objet de
        surcoupe »), its duplicates (the pink line of the same contour) are dropped."""
        import surcoupe
        drop=set();self.remap={}
        for z in zones:
            holes=z.pop('_holes',None)
            if not holes or not z.get('owner_id'):continue
            host=next((s for s in self.pieces if s.get('piece_id')==z['owner_id']),None)
            if host is None:continue
            found=0
            for x,y,X,Y,a,loop in holes:
                same=[s for s in items if id(s) not in drop and s is not host and s['style']['role'] in ('drawing',surcoupe.ROLE) and s.get('kind') in ('poly','circle','rect') and path(s)[1]]
                same=[s for s in same if all(abs(u-v)<=.05 for u,v in zip(bounds([s]),(x,y,X,Y))) and abs(abs(_shoelace(path(s)[0]))-a)<=max(1.,a*.005)]
                if same:
                    first=same[0];drop.update(id(s) for s in same[1:])
                else:
                    # Drawn only as the hole of the hatch (DIFORME_DA): the piece to recut is that hole.
                    first=copy.deepcopy(loop);first['name']='Contour';first['profile']='Dessin';items.append(first)
                first['style']=dict(surcoupe.STYLE);first['owner_id']=host['piece_id'];found+=1
                old=first.pop('piece_id',None)
                if old:
                    self.remap[old]=host['piece_id']
                    for key,value in (first.pop('piece_info',None) or {}).items():host.setdefault('piece_info',{}).setdefault(key,value)
            if found:host['surcoupe']=dict(columns=found,rows=1,gap=float(z['preparation'].get('length') or 0),follow=False)
        return [s for s in items if id(s) not in drop]

    def free_text(self,e):
        codes=e['codes']
        if e['type']=='MTEXT':corner,h,a,text,_=self.mtext(codes)
        else:
            p,h,a,text=self.text_at(codes);th=math.radians(a);corner=(p[0]+h*math.sin(th),p[1]-h*math.cos(th))
        if not text.strip():return None
        s=annotation(text[:2000],corner,min(30,max(.5,h)))
        if abs(a)>1e-9:s['text_angle']=a
        return s
