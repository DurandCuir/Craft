"""0.19.13 Contrôle des contours (proposed on 04/11: « les bouts non joints des pièces montrés d'un coup par des ronds
rouges, ceux de moins de 0,1 mm fermés en un clic » ; as Mozart's PitChiudiPoliTa / PitEviPoliTaChi: close the open
cut lines at once, show the closed pieces).

Exporter › Contrôle des contours… (and the Contrôle avant export window when it lists open cut lines): every open
end of a cut line (Coupe extérieure or intérieure) in a red ring, every closed piece outlined in green; the cut lines
whose two ends are less than 0,1 mm apart are closed in one click (« Fermer les écarts de moins de 0,1 mm »,
Annuler brings them back).
0.19.14: and each piece surcoupée inside its précoupe, the écart kept all round (an orange ring where it is not).
0.19.24 (proposed on 13/11, « Fais les pistes aussi »): the points left in the middle of a straight side or of a curve
(Mozart, Couper: the side and the curve as they are without them) in small blue rings, taken out in one click
(« Retirer les points inutiles », Annuler brings them back)."""
import math

LIMIT = .1
SLIT = 1.   # 0.19.22: an inner cut whose ends are farther apart than this (mm) is a slit, not a contour left open
RED, GREEN, ORANGE, BLUE = '#ff3b30', '#34c759', '#ff9500', '#0a84ff'
USELESS = .005   # mm: a point this near the straight side (or the circle) of its two neighbours changes nothing


def _cut(s):
    from craft_tools import style
    return style(s)['role'] in ('external', 'internal') and not s.get('preparation') and not s.get('annotation')


def open_lines(items):
    """[(index, first point, last point, gap between them)] of the open cut lines."""
    from geometry import path
    from craft_tools import style
    out = []
    for i, s in enumerate(items):
        if not _cut(s) or s.get('is_notch') or s.get('drill') or s.get('stitch'):
            continue
        try:
            pts, closed = path(s)
        except (ValueError, KeyError, TypeError):
            continue
        if closed or len(pts) < 2:
            continue
        gap = math.dist(pts[0], pts[-1])
        if gap > SLIT and style(s)['role'] == 'internal':
            continue   # 0.19.22 (found before installing): a slit (Fente d'ardillon, Etui_Lunettes) is an open inner cut
        out.append((i, pts[0], pts[-1], gap))
    return out


def closed_pieces(items):
    from entity_rules import closed_piece
    return [i for i, s in enumerate(items) if _cut(s) and closed_piece(s)]


def precut_problems(items, tolerance=.1):
    """0.19.14: [(précoupe, piece inside or None, the point to show, its distance to the précoupe's edge, outside)] for
    the pieces surcoupées that cross their précoupe, lie out of it or nearer its edge than its écart, and the précoupes
    left without a piece. The edges are looked up in a grid (a précoupe of 100 pieces: a fraction of a second)."""
    import surcoupe
    from precision_geometry import inside
    out = []
    for k, s in enumerate(items):
        if not surcoupe.is_precut(s):
            continue
        try:
            gap = float((s.get('surcoupe') or {}).get('gap') or 0)
            Q, _ = surcoupe._ring(s)
        except (TypeError, ValueError, KeyError):
            continue
        if len(Q) < 3:
            continue
        inners = surcoupe.inner_contours(items, k)
        if not inners:
            out.append((k, None, Q[0], 0., False))
            continue
        cell = max(gap, 1.)
        grid_q = surcoupe.SegmentGrid([Q], cell)
        for j in inners:
            try:
                P, _ = surcoupe._ring(items[j])
            except (TypeError, ValueError, KeyError):
                continue
            if len(P) < 2:
                continue
            grid_p = surcoupe.SegmentGrid([P], cell)
            crossing = next((a for a, b in zip(Q, Q[1:] + Q[:1]) if grid_p.crosses(a, b)), None)
            if crossing is not None:
                out.append((k, j, crossing, 0., True))
                continue
            if not inside(s, P[0]):
                out.append((k, j, P[0], 0., True))
                continue
            if gap <= 0:
                continue
            x0, y0 = min(p[0] for p in P) - gap, min(p[1] for p in P) - gap
            x1, y1 = max(p[0] for p in P) + gap, max(p[1] for p in P) + gap
            worst = min(((grid_q.distance(p, gap), p) for p in P), key=lambda w: w[0])
            near = [q for q in Q if x0 <= q[0] <= x1 and y0 <= q[1] <= y1]
            if near:
                worst = min(worst, min(((grid_p.distance(q, gap), q) for q in near), key=lambda w: w[0]), key=lambda w: w[0])
            if worst[0] < gap - tolerance:
                out.append((k, j, worst[1], worst[0], False))
    return out


def _simplifiable(s):
    """0.19.24: a contour whose useless points can go: a polyline of a cut line (Coupe extérieure or intérieure, a
    piece surcoupée), not a spline, a cran, a pointé, a piqûre, a zone or a text."""
    from craft_tools import style
    if s.get('kind') != 'poly' or s.get('spline') or s.get('components') or s.get('is_notch') or s.get('drill'):
        return False
    if s.get('stitch') or s.get('preparation') or s.get('annotation') or len(s.get('points') or ()) < 3:
        return False
    return style(s)['role'] in ('external', 'internal', 'surcoupe')


def _arc_middle(a, b, bulge):
    """The middle of the arc a → b (``bulge``: tan of a quarter of its sweep, positive anticlockwise)."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    return ((a[0] + b[0]) / 2 + dy * bulge / 2, (a[1] + b[1]) / 2 - dx * bulge / 2)


HARD = 20.   # degrees: a point where the contour turns more than this is a corner: never taken out (its sides stay)


def _directions(a, b, bulge):
    """(direction at a, direction at b) of the side a → b (unit vectors), None when a and b are one point."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    length = math.hypot(dx, dy)
    if length < 1e-9:
        return None
    ux, uy = dx / length, dy / length
    if abs(bulge) < 1e-12:
        return (ux, uy), (ux, uy)
    half = 2 * math.atan(bulge)   # half the sweep: the tangents turn by it on each side of the chord
    turned = lambda t: (ux * math.cos(t) - uy * math.sin(t), ux * math.sin(t) + uy * math.cos(t))
    return turned(-half), turned(half)


def _segment_distance(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    t = 0. if L2 < 1e-18 else max(0., min(1., ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
    return math.dist(p, (a[0] + t * dx, a[1] + t * dy))


def _straight_kept(points, tol):
    """Douglas-Peucker: the points of a straight run (its two ends kept) that must stay so that each point taken out is
    within ``tol`` of the side replacing it. The same run simplified again keeps them all (a second click finds
    nothing more, nothing adds up)."""
    keep = {0, len(points) - 1}
    todo = [(0, len(points) - 1)]
    while todo:
        i, j = todo.pop()
        if j <= i + 1:
            continue
        a, b = points[i], points[j]
        far, at = -1., None
        for k in range(i + 1, j):
            d = _segment_distance(points[k], a, b)
            if d > far:
                far, at = d, k
        if far > tol:
            keep.add(at)
            todo += [(i, at), (at, j)]
    return keep


def _arc_fits(points, bulges, tol):
    """The bulge of one arc from the first to the last of ``points`` in place of the arcs between them (``bulges``), or
    None: every point and the middle of every arc within ``tol`` of its circle, less than a whole turn."""
    from mozart_import import _arc_of
    sweep = sum(4 * math.atan(b) for b in bulges)
    if abs(sweep) >= 2 * math.pi - 1e-6:
        return None
    w = math.tan(sweep / 4)
    try:
        c, r, _ = _arc_of(points[0], points[-1], w)
    except ZeroDivisionError:
        return None
    checks = points[1:-1] + [_arc_middle(a, b, u) for a, b, u in zip(points, points[1:], bulges)]
    return w if all(abs(math.dist(q, c) - r) <= tol for q in checks) else None


def without_useless(s, tol=USELESS):
    """0.19.24: (``s`` without the points in the middle of a straight side or of a curve, those points in plan mm);
    ``s`` itself and [] when it has none. Every point taken out stays within ``tol`` of the side or arc replacing it
    (checked against all of them: a gentle curve drawn in short segments keeps its shape) and the same contour
    simplified again loses nothing more. A corner (a turn of more than HARD degrees), the meeting of a straight side
    and a curve and the first point always stay: the sides keep their number, order and start (Contrôle d'assemblage
    du sac; checked at the end, else nothing is taken out); a closed contour keeps 3 points at least."""
    from cad import polygon
    from mozart_import import _arc_of
    import copy
    if not _simplifiable(s):
        return s, []
    closed = bool(s.get('closed'))
    pts = [(s['x'] + x, s['y'] + y) for x, y in s['points']]
    n = len(pts)
    if n < (4 if closed else 3):
        return s, []
    bs = (list(s.get('bulges') or []) + [0.] * n)[:n]
    point = lambda k: pts[k % n]
    segs = n if closed else n - 1
    dirs = [_directions(point(k), point(k + 1), bs[k]) for k in range(segs)]
    straight = [abs(bs[k]) < 1e-12 for k in range(segs)]

    def hard(k):
        if k == 0 or not closed and k == n - 1:
            return True
        i, j = k - 1, k   # the sides before and after point k
        if dirs[i] is None or dirs[j] is None or straight[i] != straight[j]:
            return True
        if not straight[i]:
            if (bs[i] > 0) != (bs[j] > 0):
                return True
            try:
                (c1, r1, _), (c2, r2, _) = _arc_of(point(i), point(k), bs[i]), _arc_of(point(k), point(j + 1), bs[j])
            except ZeroDivisionError:
                return True
            if math.dist(c1, c2) > tol or abs(r1 - r2) > tol:
                return True
        u, v = dirs[i][1], dirs[j][0]
        return math.degrees(math.acos(max(-1., min(1., u[0] * v[0] + u[1] * v[1])))) > HARD

    corners = [k for k in range(n) if hard(k)]
    ends = corners + ([n] if closed else [])
    keep = set(corners)
    for h, e in zip(ends, ends[1:]):
        if e - h < 2:
            continue
        if straight[h]:
            keep |= {h + k for k in _straight_kept([point(k) for k in range(h, e + 1)], tol)} - {n}
            continue
        sweeps = [4 * math.atan(bs[k]) for k in range(h, e)]
        if abs(sum(sweeps)) >= 2 * math.pi - 1e-6:   # a whole circle from one corner: cut in three
            total, run, cuts = sum(sweeps), 0., []
            along = []
            for k in range(h + 1, e):
                run += sweeps[k - 1 - h]
                along.append((k, run))
            if len(along) < 2:
                keep |= set(range(h + 1, e))
                continue
            for share in (1 / 3, 2 / 3):
                k = min((a for a in along if a[0] not in cuts), key=lambda a: abs(a[1] - share * total))[0]
                cuts.append(k)
            parts = [h] + sorted(cuts) + [e]
        else:
            parts = [h, e]
        for a, b in zip(parts, parts[1:]):
            keep |= {a, b} - {n}
            if b - a >= 2 and _arc_fits([point(k) for k in range(a, b + 1)], bs[a:b], tol) is None:
                keep |= set(range(a + 1, b))   # (not one curve after all: as it is)
    kept = sorted(keep)

    def side(i, j):
        """The bulge from kept point i to the next kept one j (j = n: back to the first)."""
        return 0. if straight[i] else math.tan(sum(4 * math.atan(bs[k]) for k in range(i, j)) / 4)
    if closed and len(kept) < 3:   # (a half moon in arcs: its curve keeps a point in its middle)
        gaps = [(i, j) for i, j in zip(kept, kept[1:] + [n]) if not straight[i] and j - i >= 2]
        if not gaps:
            return s, []
        i, j = max(gaps, key=lambda g: abs(sum(4 * math.atan(bs[k]) for k in range(g[0], g[1]))))
        half = sum(4 * math.atan(bs[k]) for k in range(i, j)) / 2
        run, best = 0., None
        for k in range(i + 1, j):
            run += 4 * math.atan(bs[k - 1])
            if best is None or abs(run - half) < best[1]:
                best = (k, abs(run - half))
        kept = sorted(set(kept) | {best[0]})
        if len(kept) < 3:
            return s, []
    if len(kept) == n:
        return s, []
    after = kept + ([n] if closed else [])
    bulges = [side(i, j) for i, j in zip(after, after[1:])] + ([] if closed else [0.])
    out = polygon([point(k) for k in kept], s['name'], closed)
    if any(abs(b) > 1e-12 for b in bulges):
        out['bulges'] = bulges
    for key, value in s.items():
        if key not in out and key != 'bulges':
            out[key] = copy.deepcopy(value)
    # the sides as the Contrôle d'assemblage and the piqûres count them: the same, else nothing is taken out
    from geometry import path
    from stitching import _runs
    try:
        before = [(r[0], r[-1]) for r in _runs(*path(s))]
        now = [(r[0], r[-1]) for r in _runs(*path(out))]
    except (ValueError, KeyError, TypeError, ZeroDivisionError):
        return s, []
    if len(before) != len(now) or any(math.dist(a, c) > 1e-6 or math.dist(b, d) > 1e-6 for (a, b), (c, d) in zip(before, now)):
        return s, []
    return out, [point(k) for k in range(n) if k not in set(kept)]


def useless(items):
    """0.19.24: [(index, the contour without them, the points)] of the cut lines with useless points."""
    out = []
    for i, s in enumerate(items):
        q, gone = without_useless(s)
        if gone:
            out.append((i, q, gone))
    return out


def remove_useless(app):
    """0.19.24: takes them out (one step of Annuler); returns (points, contours)."""
    found = useless(app.items)
    if not found:
        return 0, 0
    app.snapshot()
    for i, q, gone in found:
        app.items[i] = q
    app.refresh()
    return sum(len(gone) for _, _, gone in found), len(found)


def closable(items, limit=LIMIT):
    """The open polylines whose ends are less than ``limit`` mm apart (and that have at least 3 points)."""
    out = []
    for i, a, b, gap in open_lines(items):
        s = items[i]
        if gap < limit and s.get('kind') == 'poly' and not s.get('spline') and len(s.get('points', [])) >= 4:
            out.append(i)
    return out


def closed_copy(s):
    """The polyline closed: its last point (on the first one) dropped, its last segment going back to the first."""
    import copy
    q = copy.deepcopy(s)
    pts = q['points'][:-1]
    q['points'] = pts
    q['closed'] = True
    if q.get('bulges'):
        q['bulges'] = list(q['bulges'][:len(pts)])
        while len(q['bulges']) < len(pts):
            q['bulges'].append(0.)
    xs = [q['x'] + x for x, y in pts]
    ys = [q['y'] + y for x, y in pts]
    q['w'], q['h'] = max(xs) - min(xs), max(ys) - min(ys)
    return q


def close_small(app, limit=LIMIT):
    """Closes them (one step of Annuler); returns how many."""
    ids = closable(app.items, limit)
    if not ids:
        return 0
    app.snapshot()
    for i in ids:
        app.items[i] = closed_copy(app.items[i])
    app.refresh()
    return len(ids)


def draw(app, problems=None, spare=None):
    """The red rings on the open ends, the closed pieces in green (tag contours_check); 0.19.14: the précoupes'
    problems in orange (``problems``: found already); 0.19.24: the useless points in small blue rings (``spare``:
    found already)."""
    from geometry import path
    c = app.canvas
    c.delete('contours_check')
    for i in closed_pieces(app.items):
        try:
            pts = path(app.items[i])[0]
        except (ValueError, KeyError, TypeError):
            continue
        if len(pts) > 1:
            c.create_line(*[v for p in pts + pts[:1] for v in app.to_screen(p)], fill=GREEN, width=2, tags='contours_check')
    for i, a, b, gap in open_lines(app.items):
        for p in (a, b):
            x, y = app.to_screen(p)
            c.create_oval(x - 7, y - 7, x + 7, y + 7, outline=RED, width=2.5, tags='contours_check')
    for k, j, p, d, out in (precut_problems(app.items) if problems is None else problems):
        x, y = app.to_screen(p)
        c.create_oval(x - 9, y - 9, x + 9, y + 9, outline=ORANGE, width=2.5, tags='contours_check')
    for i, q, gone in (useless(app.items) if spare is None else spare):
        for p in gone:
            x, y = app.to_screen(p)
            c.create_oval(x - 5, y - 5, x + 5, y + 5, outline=BLUE, width=2, tags='contours_check')
    c.tag_raise('contours_check')


def clear(app):
    try:
        app.canvas.delete('contours_check')
    except Exception:
        pass


def summary(items, problems=None, spare=None):
    open_ = open_lines(items)
    small = len(closable(items))
    pieces = len(closed_pieces(items))
    text = f'{pieces} pièce{"s" if pieces > 1 else ""} fermée{"s" if pieces > 1 else ""} · '   # « 0 pièce fermée »
    text += f'{len(open_)} contour{"s" if len(open_) > 1 else ""} ouvert{"s" if len(open_) > 1 else ""}'
    if small:
        text += f' (dont {small} à moins de 0,1 mm)'
    bad = precut_problems(items) if problems is None else problems
    empty = sum(1 for b in bad if b[1] is None)
    wrong = [b for b in bad if b[1] is not None]
    if wrong:
        out = sum(1 for b in wrong if b[4])
        text += f' · {len(wrong)} surcoupe{"s" if len(wrong) > 1 else ""} ' + ('hors de sa précoupe ou trop près du bord' if len(wrong) == 1 else 'hors de leur précoupe ou trop près du bord')
        if out:
            text += f' (dont {out} dehors)'
    if empty:
        text += f' · {empty} précoupe{"s" if empty > 1 else ""} sans pièce'
    spare = useless(items) if spare is None else spare
    if spare:
        n = sum(len(g) for _, _, g in spare)
        text += f' · {n} point{"s" if n > 1 else ""} inutile{"s" if n > 1 else ""}' + (f' ({len(spare)} contours)' if len(spare) > 1 else '')
    return text + '.'


def show(app):
    """Exporter › Contrôle des contours…: the marks, a small window to close the small gaps."""
    import tkinter as tk
    problems = precut_problems(app.items)   # 0.19.14: found once for the marks and the text
    spare = useless(app.items)   # 0.19.24: as the précoupes' problems
    draw(app, problems, spare)
    old = app.__dict__.get('_contours_window')
    if old is not None and old.winfo_exists():
        old.destroy()
    win = app.dialog('Contrôle des contours')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    app._contours_window = win
    text = tk.StringVar(value=summary(app.items, problems, spare))
    app.label(win, 'Bouts non joints : ronds rouges. Pièces fermées : en vert. Surcoupe hors de sa précoupe, trop près ou précoupe vide : rond orange.').pack(anchor='w', padx=14, pady=(12, 2))
    app.label(win, 'Point inutile (au milieu d’un côté droit ou d’un arrondi) : petit rond bleu.').pack(anchor='w', padx=14, pady=(0, 2))
    tk.Label(win, textvariable=text, bg=app.p['panel'], fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 10, 'bold')).pack(anchor='w', padx=14, pady=2)
    row = tk.Frame(win, bg=app.p['panel'])
    row.pack(fill='x', padx=14, pady=(8, 12))

    def again():
        problems = precut_problems(app.items)
        spare = useless(app.items)
        text.set(summary(app.items, problems, spare))
        draw(app, problems, spare)

    def close_them():
        n = close_small(app)
        again()
        app.status.set(f'{n} contour{"s" if n > 1 else ""} fermé{"s" if n > 1 else ""} (écart de moins de 0,1 mm).' if n else 'Aucun écart de moins de 0,1 mm.')

    def spare_them():
        """0.19.24: the useless points taken out (the contours keep their shape: 0,005 mm at most)."""
        n, k = remove_useless(app)
        again()
        app.status.set(f'{n} point{"s" if n > 1 else ""} inutile{"s" if n > 1 else ""} retiré{"s" if n > 1 else ""} '
                       f'({k} contour{"s" if k > 1 else ""}, même forme) ; Annuler les remet.' if n else 'Aucun point inutile.')

    def done():
        clear(app)
        win.destroy()
    app.button(row, 'Fermer les écarts de moins de 0,1 mm', close_them).pack(side='left')
    app.button(row, 'Retirer les points inutiles', spare_them).pack(side='left', padx=6)
    app.button(row, 'Fermer', done).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win._close_them = close_them
    win._spare_them = spare_them
    win._text = text
    return win
