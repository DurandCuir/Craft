"""Discoverable CAD commands and safe arithmetic; no UI or document mutation."""
from dataclasses import dataclass
import ast
import math
import re
import unicodedata


def normalize(text):
    return ''.join(c for c in unicodedata.normalize('NFKD',text.casefold()) if not unicodedata.combining(c)).strip()


@dataclass(frozen=True)
class Command:
    name: str
    aliases: tuple
    action: str
    hint: str
    parameter: str = ''


COMMANDS=(
    Command('Ligne',('ligne','line','li'),'line','Point de départ, puis longueur ou coordonnées.'),
    Command('Polyligne',('polyligne','polyline','poly','pl'),'poly','Tracer un contour ; fermer ou retour pour corriger le dernier point.'),
    Command('Rectangle',('rectangle','rect','rec'),'rect','Point de départ, puis largeur ; hauteur.'),
    Command('Cercle (rayon)',('cercle','circle','ci'),'circle_radius','Centre, puis rayon.'),
    Command('Arrondi',('arrondi','fillet','fi'),'fillet','Choisir deux côtés près du coin. Exemple : arrondi 5 mm.','fillet_radius'),
    Command('Chanfrein',('chanfrein','chamfer','ch'),'chamfer','Choisir deux côtés. Exemple : chanfrein 3 mm.','angle_value'),
    Command('Trous de ceinture',('trous de ceinture','trous','ceinture','tc'),'belt_holes','Nombre, écart, distance du bout et mèche, puis cliquer le bout de la sangle.'),
    Command('Fente d’ardillon',('fente d’ardillon',"fente d'ardillon",'fente ardillon','fente','ardillon','fa'),'buckle_slot','Longueur, largeur, distance du bout au milieu et tracé, puis cliquer le bout de la sangle.'),
    Command('Sangle entière',('sangle entiere','sangle','se'),'strap_piece','Longueur, largeur, bouts, trous et fente, puis le bout côté boucle et la direction.'),
    Command('Contrôle d’assemblage',('assemblage','assemblages','controle assemblage','controle d assemblage'),'assembly','Deux bords cousus ensemble, mesurés à la couture (2,5 mm, jonc 5 mm) : longueurs, écart, crans en face (posés d’un clic), points et fil.'),
    Command('Contrôle d’assemblage du sac',('assemblage du sac','assemblages du sac','controle du sac','tout le sac','sac','montage','ordre de montage','gamme de montage'),'assembly_bag','Tous les contrôles d’assemblage faits, gardés avec le modèle, contrôlés d’un coup dans l’ordre de montage, avec les étapes entre eux.'),   # 0.19.24, 0.19.26
    Command('Passant',('passant','passants'),'passant','La bande du passant à la longueur de la sangle (largeur, épaisseurs, aisance, recouvrement), puis un clic.'),
    Command('Poignée toron',('poignee toron','toron'),'toron','Profil, toron, cuir, longueur roulée (ou écart des anneaux et hauteur), précoupe, attaches sur anneau (perfos) ou cousues, enchapes, puis un bout et la direction.'),
    Command('Bout pointu',('bout pointu','boutpointu','pointe','bp'),'strap_point','Cliquer le petit côté d’une pièce, ou ses deux bords près du bout : pointe à 45°, ou de la longueur donnée, prise dans la sangle. Exemple : bp 20.','point_length'),
    Command('Bout de ceinture',('bout de ceinture','boutdeceinture','bc'),'strap_belt','Affinement, largeur du bout et arrondis, puis cliquer le petit côté d’une pièce, ou ses deux bords près du bout.'),
    # 0.19.6: after the other « bout … » (its alias « bout » takes a value: « bout 8 »).
    Command('Bout rond',('bout rond','boutrond','bout','br'),'strap_round','Cliquer le petit côté d’une pièce, ou ses deux bords près du bout : demi-cercle, ou un arc qui part à la distance donnée du bout. Exemple : br 8.','round_depth'),
    Command('Couper',('couper','trim','tr'),'trim','Cliquer ou balayer les portions à supprimer.'),
    Command('Rallonger',('rallonger','extend','ex'),'extend','Prolonger jusqu’à la prochaine intersection.'),
    Command('Miroir',('miroir','symetrie','mirror','mi'),'mirror','Sélectionner, puis tracer l’axe.'),
    Command('Déplacer',('deplacer','move','mv'),'move_anchor','Sélectionner les objets, puis repère de départ et d’arrivée.'),
    Command('Rotation',('rotation','orientation','rotate','ro'),'rotate','Sélectionner, centre de rotation, puis angle (90 = quart de tour dans le sens des aiguilles d’une montre).'),
    Command('Échelle',('echelle','scale','sc'),'scale','Sélectionner, point fixe, puis pourcentage (120 = +20 %).'),
    Command('Copier',('copier','copy','cp'),'copy','Sélectionner les lignes, repère, puis point d’arrivée.'),
    Command('Décaler un contour',('decaler','offset','of'),'offset_all','Distance, contour, puis côté du décalage.'),
    Command('Cran',('cran','crans','notch'),'notch','Choisir le contour, puis intérieur ou extérieur.'),
    Command('Copier les crans',('copier crans','copie crans','copy notch','cc'),'copy_notch','Sélectionner les crans, repère source, repère cible.'),
    Command('Piqûre',('piqure','couture','stitch','pq'),'stitch','Distance du bord et pas, Machine ou Main, puis la ligne ou le contour.'),
    Command('Nom de pièce',('nom','texte','text','nommer'),'part_name','Champs, premier point, puis orientation du texte.'),
    Command('Matière',('matiere','material'),'material','Matière, quantité, puis placement du texte.'),
    Command('Préparation',('preparation','parage','teinte','prep'),'preparation','Cliquer dans la zone : parage ou teinte, puis les zones suivantes.'),
    Command('Précoupe / surcoupe',('precoupe','surcoupe','serie'),'surcoupe','Choisir la pièce (clic ou n° d’ID unique + Entrée), puis colonnes, rangées, écart et forme.'),
    Command('Précoupe simple',('precoupe simple','precoupe1'),'surcoupe_simple','Choisir la pièce (clic ou n° d’ID unique + Entrée) : sa précoupe tout de suite, écart et forme de la dernière fois.'),
    Command('ID unique',('id','id unique','numeroter','numero'),'piece_id','Cliquer dans les pièces dans l’ordre ; Entrée numérote les autres.'),
    Command('Réseau',('reseau','array','ar','copies en serie'),'array','La sélection copiée en colonnes et rangées, ou autour d’un centre.'),
    Command('Étirer',('etirer','stretch','s'),'stretch','Une fenêtre : ce qui est dedans bouge, le reste suit.'),
    Command('Couper au point',('couper au point','break','coupure','scinder'),'break_point','Une ligne, une polyligne ou un arc coupé en deux là où on clique.'),
    Command('Contrôle des contours',('controle des contours','contours','bouts non joints','fermer les contours'),'contours_check','Bouts non joints en rouge, pièces fermées en vert ; écarts de moins de 0,1 mm fermés en un clic.'),
    Command('Infos du modèle',('infos','info','modele'),'model_info','Modèle, créateur, atelier, saison, indice, dates et fournitures.'),
    Command('Mesurer',('mesurer','mesure','distance','dist'),'measure','Choisir deux points pour lire leur distance.'),
    Command('Cote',('cote','cotation','dimension','dim'),'dimension','Choisir les deux points, puis placer la cote (ORTHO : horizontale / verticale).'),
    Command('Joindre',('joindre','join','jo'),'join','Suivre le contour et choisir le chemin aux intersections.'),
    Command('Décomposer',('decomposer','explode','xp'),'explode','Décomposer les objets sélectionnés.'),
    Command('Fermer le contour',('fermer','close','cl'),'!close','Fermer la polyligne en cours.'),
    Command('Retirer le dernier point',('retour','back','u'),'!back','Retirer le dernier sommet de la polyligne en cours.'),
    Command('Dupliquer',('dupliquer','duplicate','du'),'!duplicate','Dupliquer la sélection.'),
    Command('Ortho',('ortho','or'),'!ortho','Activer ou désactiver les directions horizontale / verticale.'),
    Command('Réglages',('reglages','options','parametres','preferences','op'),'!settings','Tous les réglages de Craft dans une fenêtre.'),   # 0.19.7
    Command('Accroches',('accroches','snap','sn'),'!snap','Activer ou désactiver les ancrages.'),
    Command('Cadrer le dessin',('cadrer','zoom','za'),'!fit','Afficher tous les tracés.'),
    Command('Régénérer',('regen','re','regenerer'),'!regen','Tout désélectionner, effacer ce qui traîne à l’écran et tout redessiner (comme Échap).'),
    Command('Annuler',('annuler','undo'),'!undo','Annuler la dernière modification.'),
    Command('Rétablir',('retablir','redo'),'!redo','Rétablir la dernière modification annulée.'),
    Command('Export PDF',('pdf','export pdf'),'!pdf','Ouvrir l’aperçu avant export.'),
    Command('Export DXF',('dxf','export dxf'),'!dxf','Vérifier les pièces en vert fluo avant export.'),
    Command('Calculer une longueur',('calcul','calc','='),'!calc','Exemple : calcul (80 + 2*5)/2 mm.','calculation'),
    Command('Guide des commandes',('aide','help','?'),'!help','Alias, exemples et lien vers le guide LibreCAD.'),
)


def resolve(text):
    query=normalize(text)
    for command in COMMANDS:
        for alias in sorted(command.aliases,key=len,reverse=True):
            if query==alias:return command,''
            # 0.19.6: a value after the name starts like a number (« bout 8 », not « bout pointu »)
            rest=query[len(alias)+1:].lstrip()
            if command.parameter and query.startswith(alias+' ') and rest[:1] and (rest[0].isdigit() or rest[0] in '.,(-+−'):return command,text.strip()[len(alias):].strip()   # 0.19.9: « calcul −5+8 »
    return None


def matching(text):
    query=normalize(text)
    def rank(command):
        words=[normalize(command.name),*command.aliases]
        if query in words:return 0
        if any(w.startswith(query) for w in words):return 1
        if any(query in w for w in words):return 2
        return 3
    return sorted((c for c in COMMANDS if rank(c)<3),key=rank)


# 0.19.9: the signs as the message of a wrong calculation writes them (typed or pasted): − × ÷ for - * /
SIGNS=str.maketrans({'−':'-','×':'*','÷':'/'})


def length_expression(text,unit='mm'):
    """A bounded arithmetic grammar; values use current units unless suffixed."""
    raw=text.strip().lower().replace(',','.').translate(SIGNS)   # 0.19.9: − × ÷ (typed or pasted) as - * /
    if len(raw)>160:raise ValueError('Calcul trop long.')
    # A suffix on the whole expression applies to its result.
    suffix=re.search(r'\s*(mm|cm)\s*$',raw)
    factor=10 if unit=='cm' else 1
    if suffix:
        factor=10 if suffix[1]=='cm' else 1;raw=raw[:suffix.start()].strip()
    raw=re.sub(r'(?<![\w.])0+(?=\d)','',raw)   # 0.19.9: « 045 », « 05 »: a decimal number (Python refuses its leading zeros)
    try:tree=ast.parse(raw,mode='eval')
    except (SyntaxError,ValueError):raise ValueError('Calcul invalide : utilisez des nombres et + − × / ( ).') from None
    if sum(1 for _ in ast.walk(tree))>60:raise ValueError('Calcul trop complexe.')
    def number(node):
        if isinstance(node,ast.Constant) and type(node.value) in (int,float):value=float(node.value)
        elif isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            value=number(node.operand)*(1 if isinstance(node.op,ast.UAdd) else -1)
        elif isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult,ast.Div)):
            a,b=number(node.left),number(node.right)
            if isinstance(node.op,ast.Add):value=a+b
            elif isinstance(node.op,ast.Sub):value=a-b
            elif isinstance(node.op,ast.Mult):value=a*b
            else:
                if b==0:raise ValueError('Division par zéro.')
                value=a/b
        else:raise ValueError('Seuls les nombres et + − × / ( ) sont acceptés.')
        if not math.isfinite(value) or abs(value)>1e9:raise ValueError('Valeur trop grande.')
        return value
    result=number(tree.body)*factor
    # 0.18.5: nothing is ever placed beyond ±100 m (the limit of a saved document).
    if abs(result)>100000:raise ValueError('Valeur hors limites (±100 m).')
    return result


def dimension_chunks(text,rectangle=False):
    if not rectangle:return [text]
    # Keep the historical 100*70 rectangle shortcut. More complex expressions
    # use arithmetic; explicit width/height separators remain ; or x.
    if ';' in text or re.search('[xX]',text):
        chunks=re.split('[;xX]',text)
        # 0.19.9: « 10;7 cm », « 10x7 cm »: a unit after the last value goes with the other plain values too (as with *)
        unit=re.search(r'\d\s*(mm|cm)\s*$',chunks[-1],re.I)
        if unit:chunks=[c.strip()+' '+unit[1] if re.fullmatch(r'\s*-?\d+(?:[.,]\d+)?\s*',c) else c for c in chunks]
        return chunks
    # 0.19.9: a unit after both values goes with both (« 100*70 mm », « 10*7 cm » made one product: 7000 mm); × as *
    unit=re.search(r'\s*(mm|cm)\s*$',text,re.I);body=(text[:unit.start()] if unit else text).translate(SIGNS)
    if re.fullmatch(r'\s*\d+(?:[.,]\d+)?\s*\*\s*\d+(?:[.,]\d+)?\s*',body):return [v+' '+unit[1] if unit else v for v in body.split('*')]
    return [text]


def coordinate(text,reference=None,unit='mm'):
    """Explicit coordinates preserve French decimal-comma length input.

    @dx;dy and dx..dy are relative; #x;y is absolute. Positive Y and
    polar angles follow Craft's screen/model axes (down, clockwise).
    """
    raw=text.strip();relative=raw.startswith('@') or '..' in raw
    if not(raw.startswith(('@','#')) or '..' in raw):return None
    if relative and reference is None:raise ValueError('Choisir d’abord un point de départ pour les coordonnées relatives.')
    body=raw[1:] if raw.startswith(('@','#')) else raw
    if '<' in body:
        parts=body.split('<')
        if len(parts)!=2:raise ValueError('Coordonnées polaires : @longueur<angle, par exemple @50<45.')
        radius=length_expression(parts[0],unit);angle=length_expression(parts[1],'mm')
        if radius<0:raise ValueError('La longueur polaire doit être positive.')
        theta=math.radians(angle);dx,dy=radius*math.cos(theta),radius*math.sin(theta)
    else:
        parts=body.split('..') if '..' in body else body.split(';') if ';' in body else body.split(',')
        if len(parts)!=2:raise ValueError('Coordonnées : @X;Y relatives ou #X;Y absolues.')
        dx,dy=(length_expression(v,unit) for v in parts)
    a=reference if relative else (0,0)
    if max(abs(a[0]+dx),abs(a[1]+dy))>100000:raise ValueError('Point hors limites (±100 m).')
    return a[0]+dx,a[1]+dy
