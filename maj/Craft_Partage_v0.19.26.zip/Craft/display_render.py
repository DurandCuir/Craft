"""Display-only antialiasing. Windows GDI+ needs no installed Python package.

Native canvas entities remain the source for tags and editing. Unsupported
backends/options keep their native drawing. CAD geometry and exports never pass
through this module. Pillow is a portable development/optional fallback.
"""
import base64,ctypes,io,math,struct,sys,time,zlib
from functools import lru_cache


def png_rgba(width,height,raw):
    def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    rows=b''.join(b'\0'+raw[y*width*4:(y+1)*width*4] for y in range(height))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(rows,3))+chunk(b'IEND',b'')


def rgba(color):
    if not color:return (0,0,0,0)
    value=color.lstrip('#')
    if len(value)==3:value=''.join(v*2 for v in value)
    return (*[int(value[i:i+2],16) for i in (0,2,4)],255)


def segments(points,dash):
    """Continuous dash phase across a polyline, in screen pixels."""
    pairs=list(zip(points,points[1:]))
    if not dash:return pairs
    pattern=list(dash)*(2 if len(dash)%2 else 1);phase=0;remaining=pattern[0];out=[]
    for a,b in pairs:
        length=math.dist(a,b)
        if length<1e-10:continue
        pos=0
        while pos<length-1e-10:
            step=min(remaining,length-pos)
            if phase%2==0:out.append((tuple(a[k]+(b[k]-a[k])*pos/length for k in (0,1)),tuple(a[k]+(b[k]-a[k])*(pos+step)/length for k in (0,1))))
            pos+=step;remaining-=step
            if remaining<1e-9:phase=(phase+1)%len(pattern);remaining=pattern[phase]
    return out


def ppm(width,height,rgb):
    return b'P6 %d %d 255\n'%(width,height)+bytes(rgb)


def png_rgb(width,height,rgb):
    def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    rows=b''.join(b'\0'+rgb[y*width*3:(y+1)*width*3] for y in range(height))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(rows,1))+chunk(b'IEND',b'')


def unpadded(buffer,width,height,stride):
    """0.19.24: the rows of a picture of 3 bytes a pixel, each ``stride`` bytes long in ``buffer`` (GDI+ pads them to 4
    bytes), one after the other without their padding."""
    row=width*3
    if stride==row:return buffer if len(buffer)==row*height else bytes(buffer[:row*height])
    view=memoryview(buffer);return b''.join(view[k*stride:k*stride+row] for k in range(height))


def supersampling(width,height):
    """Pillow draws at 2 or 3 times the size, then reduces (antialiasing)."""
    return 3 if width*height<300000 else 2


class PillowBackend:
    name='Pillow'
    @staticmethod
    def _drawn(width,height,ops,ground):
        """The lines drawn at 2 or 3 times the size, and that factor. ``ground``: the RGBA of the picture's ground; 0.19.25:
        an opaque one (R, G, B): an RGB picture (the same pixels; Pillow reduces an RGBA picture through a premultiplied
        copy of the whole of it, made again for each part)."""
        from PIL import Image,ImageDraw
        factor=supersampling(width,height);im=Image.new('RGB' if len(ground)==3 else 'RGBA',(width*factor,height*factor),ground);d=ImageDraw.Draw(im)
        colour=(lambda c:rgba(c)[:3]) if len(ground)==3 else rgba
        def coords(values):return [v*factor for v in values]
        for kind,xy,fill,outline,weight,dash,start,extent in ops:
            w=max(1,round(weight*factor));points=list(zip(xy[::2],xy[1::2]))
            if kind=='line':
                if dash:
                    for a,b in segments(points,dash):d.line(coords((*a,*b)),fill=colour(fill),width=w)
                else:d.line([tuple(coords(p)) for p in points],fill=colour(fill),width=w,joint='curve')
            elif kind=='polygon':
                if fill:d.polygon([tuple(coords(p)) for p in points],fill=colour(fill))
                if outline:d.line([tuple(coords(p)) for p in points+points[:1]],fill=colour(outline),width=w,joint='curve')
            elif kind=='rectangle':d.rectangle(coords(xy),fill=colour(fill) if fill else None,outline=colour(outline) if outline else None,width=w)
            elif kind=='oval':d.ellipse(coords(xy),fill=colour(fill) if fill else None,outline=colour(outline) if outline else None,width=w)
            elif kind=='arc':d.arc(coords(xy),-start-extent,-start,fill=colour(outline),width=w)
        return im,factor
    def render_parts(self,width,height,ops,background,boxes):
        """0.19.25: the parts ``boxes`` (x0, y0, x1, y1) of the opaque picture of the whole screen, each a PPM: the lines
        drawn once on the whole (the same cuts at its edges) and each part reduced from it (``resize(box=…)``: the same
        weights: the pixels of the whole)."""
        from PIL import Image
        im,factor=self._drawn(width,height,ops,rgba(background)[:3]);out=[]
        for x0,y0,x1,y1 in boxes:
            part=im.resize((x1-x0,y1-y0),Image.Resampling.LANCZOS,box=(x0*factor,y0*factor,x1*factor,y1*factor))
            out.append(ppm(x1-x0,y1-y0,part.tobytes()))
        return out
    def render(self,width,height,ops,background=None,box=None,base=None):
        """PNG with transparency, or (0.17.0) an opaque PPM on ``background``: Tk shows an opaque
        image at once, while a transparent one with many antialiased lines took over a second.
        0.19.7: ``base`` (x, y, w, h, RGB bytes): the background picture under the lines (« trait pas
        beau »: the lines over a picture were not smoothed).
        0.18.7: ``box`` (x0, y0, x1, y1): only that part of the picture, the same pixels as the whole:
        drawn on the whole (Pillow cuts a line at the picture's edge: a smaller picture would draw it
        a little differently) and reduced from the whole (``resize(box=…)``: the same weights; a
        reduction of a cut-out piece differs by a few levels)."""
        from PIL import Image
        im,factor=self._drawn(width,height,ops,rgba(background)[:3] if background and not base else (0,0,0,0))
        if box:
            x0,y0,x1,y1=box;width,height=x1-x0,y1-y0
            im=im.resize((width,height),Image.Resampling.LANCZOS,box=(x0*factor,y0*factor,x1*factor,y1*factor))
        else:im=im.resize((width,height),Image.Resampling.LANCZOS)
        if base:
            x0,y0=box[:2] if box else (0,0);out=Image.new('RGB',im.size,rgba(background)[:3] if background else (255,255,255))
            bx,by,bw,bh,rgb=base;out.paste(Image.frombytes('RGB',(bw,bh),bytes(rgb)),(bx-x0,by-y0));out.paste(im,(0,0),im)
            return ppm(out.size[0],out.size[1],out.tobytes())
        if background:return ppm(width,height,im.convert('RGB').tobytes())
        buf=io.BytesIO();im.save(buf,format='PNG',compress_level=2);return buf.getvalue()


class GdiBackend:
    name='GDI+'
    fast=True   # 0.19.24: an opaque picture drawn in GDI+'s own format and read as RGB at once (else as before)
    def __init__(self):
        from ctypes import wintypes as w
        self.g=ctypes.WinDLL('gdiplus');self.P=ctypes.c_void_p;self.F=ctypes.c_float
        class Startup(ctypes.Structure):_fields_=[('version',w.UINT),('callback',self.P),('suppress_thread',w.BOOL),('suppress_codecs',w.BOOL)]
        class Point(ctypes.Structure):_fields_=[('X',ctypes.c_float),('Y',ctypes.c_float)]
        class Rect(ctypes.Structure):_fields_=[('X',ctypes.c_int),('Y',ctypes.c_int),('Width',ctypes.c_int),('Height',ctypes.c_int)]
        class BitmapData(ctypes.Structure):_fields_=[('Width',w.UINT),('Height',w.UINT),('Stride',ctypes.c_int),('PixelFormat',ctypes.c_int),('Scan0',ctypes.c_void_p),('Reserved',ctypes.c_size_t)]
        self.Point=Point;self.Rect=Rect;self.BitmapData=BitmapData
        P=self.P;F=self.F;I=ctypes.c_int;U=ctypes.c_uint32
        specs={'GdiplusStartup':[ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(Startup),P], 'GdiplusShutdown':[ctypes.c_size_t],
          'GdipCreateBitmapFromScan0':[I,I,I,I,P,ctypes.POINTER(P)],'GdipGetImageGraphicsContext':[P,ctypes.POINTER(P)],
          'GdipSetSmoothingMode':[P,I],'GdipSetPixelOffsetMode':[P,I],'GdipGraphicsClear':[P,U],
          'GdipCreatePen1':[U,F,I,ctypes.POINTER(P)],'GdipDeletePen':[P], 'GdipSetPenLineJoin':[P,I],
          'GdipDrawLines':[P,P,ctypes.POINTER(Point),I], 'GdipDrawPolygon':[P,P,ctypes.POINTER(Point),I],
          'GdipCreateSolidFill':[U,ctypes.POINTER(P)],'GdipDeleteBrush':[P], 'GdipFillPolygon':[P,P,ctypes.POINTER(Point),I,I],
          'GdipDrawEllipse':[P,P,F,F,F,F],'GdipFillEllipse':[P,P,F,F,F,F],'GdipDrawRectangle':[P,P,F,F,F,F],'GdipFillRectangle':[P,P,F,F,F,F],
          'GdipDrawArc':[P,P,F,F,F,F,F,F], 'GdipBitmapLockBits':[P,ctypes.POINTER(Rect),U,I,ctypes.POINTER(BitmapData)],
          'GdipBitmapUnlockBits':[P,ctypes.POINTER(BitmapData)],'GdipDeleteGraphics':[P],'GdipDisposeImage':[P],
          'GdipDrawImageRectI':[P,P,I,I,I,I],'GdipSetInterpolationMode':[P,I]}
        for name,args in specs.items():fn=getattr(self.g,name);fn.argtypes=args;fn.restype=I
        self.token=ctypes.c_size_t();self.call('GdiplusStartup',ctypes.byref(self.token),ctypes.byref(Startup(1,None,False,False)),None)
        import atexit
        atexit.register(self.g.GdiplusShutdown,self.token)
    def call(self,name,*args):
        result=getattr(self.g,name)(*args)
        if result:raise OSError('GDI+ '+name+': '+str(result))
    def argb(self,color):
        r,g,b,a=rgba(color);return (a<<24)|(r<<16)|(g<<8)|b
    def bgra(self,color):
        """0.19.24: the colour with red and blue swapped: drawn so, GDI+'s bytes (B, G, R) are the picture's R, G, B."""
        r,g,b,a=rgba(color);return (a<<24)|(b<<16)|(g<<8)|r
    def draw_base(self,graphics,base,swapped=False):
        """0.19.7: the background picture (RGB rows) drawn as it is at (x, y): a 24-bit bitmap over our
        own bytes (B, G, R, rows padded to 4 bytes), pixel for pixel. 0.19.24 ``swapped``: the colours of the picture
        being made are swapped (bgra): its own bytes go as they are."""
        x,y,w,h,rgb=base;row=(w*3+3)//4*4;data=bytearray(row*h);line=bytearray(rgb)
        if not swapped:line[0::3],line[2::3]=line[2::3],line[0::3]
        if row==w*3:data[:]=line
        else:
            for k in range(h):data[k*row:k*row+w*3]=line[k*w*3:(k+1)*w*3]
        buffer=(ctypes.c_char*len(data)).from_buffer(data);bitmap=self.P()
        self.call('GdipCreateBitmapFromScan0',w,h,row,0x21808,buffer,ctypes.byref(bitmap))
        try:
            self.call('GdipSetInterpolationMode',graphics,5);self.call('GdipSetPixelOffsetMode',graphics,4)
            self.call('GdipDrawImageRectI',graphics,bitmap,x,y,w,h)
        finally:self.g.GdipDisposeImage(bitmap)
    def points(self,xy):
        """0.18.7: the coordinates as GDI+ points in one go (float32 pairs: the layout of an array
        of Point), instead of one Python object per point (25 times quicker)."""
        import array
        return (self.Point*(len(xy)//2)).from_buffer(array.array('f',xy[:len(xy)//2*2]))
    def render(self,width,height,ops,background=None,box=None,base=None):
        """0.18.7: ``box`` (x0, y0, x1, y1): only that part, drawn on the whole picture (the same
        positions and cuts at the edge as the whole), only its pixels read. 0.19.7: ``base`` (x, y, w, h,
        RGB bytes): the background picture drawn first, the lines smoothed over it. 0.19.24: an opaque picture is
        drawn in GDI+'s premultiplied format (its quickest), its colours swapped so that its pixels read in 24 bits are
        already the R, G, B rows of the PPM (no byte shuffled by Python); a refusal of GDI+: as before, for good."""
        if background and self.fast:
            try:return self._render(width,height,ops,background,box,base,True)
            except (OSError,ValueError,ctypes.ArgumentError):type(self).fast=False
        return self._render(width,height,ops,background,box,base,False)
    def render_parts(self,width,height,ops,background,boxes):
        """0.19.25: the parts ``boxes`` (x0, y0, x1, y1) of the opaque picture of the whole screen, each a PPM: the lines
        drawn once on the whole picture, only the pixels of each part read (the same pixels as the whole)."""
        if self.fast:
            try:return self._render(width,height,ops,background,None,None,True,boxes)
            except (OSError,ValueError,ctypes.ArgumentError):type(self).fast=False
        return self._render(width,height,ops,background,None,None,False,boxes)
    def _render(self,width,height,ops,background,box,base,quick,boxes=None):
        P=self.P;image=P();graphics=P();fmt=0xE200B if quick else 0x26200A;pens={};colour=self.bgra if quick else self.argb
        self.call('GdipCreateBitmapFromScan0',width,height,0,fmt,None,ctypes.byref(image))
        try:
            self.call('GdipGetImageGraphicsContext',image,ctypes.byref(graphics))
            self.call('GdipSetSmoothingMode',graphics,4);self.call('GdipSetPixelOffsetMode',graphics,4);self.call('GdipGraphicsClear',graphics,colour(background) if background else 0)
            if base:self.draw_base(graphics,base,quick)
            for kind,xy,fill,outline,weight,dash,start,extent in ops:
                array=self.points(xy);count=len(array);pen=P();brush=P()
                ink=fill if kind=='line' else outline
                try:
                    if ink:
                        # 0.17.0: one pen per colour and width for the whole picture.
                        known=pens.get((ink,weight))
                        if known is None:
                            self.call('GdipCreatePen1',colour(ink),weight,2,ctypes.byref(pen));self.call('GdipSetPenLineJoin',pen,2);pens[(ink,weight)]=pen
                        else:pen=known
                    if fill and kind!='line':self.call('GdipCreateSolidFill',colour(fill),ctypes.byref(brush))
                    if kind=='line':
                        if dash:
                            for a,b in segments(list(zip(xy[::2],xy[1::2])),dash):self.call('GdipDrawLines',graphics,pen,(self.Point*2)(self.Point(*a),self.Point(*b)),2)
                        else:self.call('GdipDrawLines',graphics,pen,array,count)
                    elif kind=='polygon':
                        if brush:self.call('GdipFillPolygon',graphics,brush,array,count,0)
                        if pen:self.call('GdipDrawPolygon',graphics,pen,array,count)
                    else:
                        x,y,X,Y=xy;frame=(x,y,max(0,X-x),max(0,Y-y))
                        if kind=='arc':self.call('GdipDrawArc',graphics,pen,*frame,-start,-extent)
                        else:
                            suffix='Ellipse' if kind=='oval' else 'Rectangle'
                            if brush:self.call('GdipFill'+suffix,graphics,brush,*frame)
                            if pen:self.call('GdipDraw'+suffix,graphics,pen,*frame)
                finally:
                    if brush:self.g.GdipDeleteBrush(brush)
            def read(left,top,right,bottom):
                w,h=right-left,bottom-top
                data=self.BitmapData();rect=self.Rect(left,top,w,h)
                if quick:   # read as 24-bit rows: R, G, B (the colours were swapped)
                    self.call('GdipBitmapLockBits',image,ctypes.byref(rect),1,0x21808,ctypes.byref(data))
                    try:
                        if data.Stride<w*3:raise OSError('GDI+ GdipBitmapLockBits: '+str(data.Stride))   # rows upside down: as before
                        return ppm(w,h,unpadded(ctypes.string_at(data.Scan0,data.Stride*h),w,h,data.Stride))
                    finally:self.g.GdipBitmapUnlockBits(image,ctypes.byref(data))
                self.call('GdipBitmapLockBits',image,ctypes.byref(rect),1,fmt,ctypes.byref(data))
                try:
                    if data.Stride==w*4:raw=bytearray(ctypes.string_at(data.Scan0,w*h*4))   # 0.18.7: in one go
                    else:
                        raw=bytearray(w*h*4)
                        for row in range(h):raw[row*w*4:(row+1)*w*4]=ctypes.string_at(data.Scan0+row*data.Stride,w*4)
                    if background:
                        rgb=bytearray(w*h*3);rgb[0::3]=raw[2::4];rgb[1::3]=raw[1::4];rgb[2::3]=raw[0::4]
                        return ppm(w,h,rgb)
                    raw[0::4],raw[2::4]=raw[2::4],raw[0::4]
                    return png_rgba(w,h,raw)
                finally:self.g.GdipBitmapUnlockBits(image,ctypes.byref(data))
            if boxes is not None:return [read(*b) for b in boxes]   # 0.19.25: the parts of the sparse picture
            return read(*(box if box else (0,0,width,height)))
        finally:
            for pen in pens.values():self.g.GdipDeletePen(pen)
            if graphics:self.g.GdipDeleteGraphics(graphics)
            self.g.GdipDisposeImage(image)


@lru_cache(maxsize=1)
def backend():
    if sys.platform=='win32':
        try:return GdiBackend()
        except (OSError,AttributeError):pass
    try:
        import PIL.Image
        return PillowBackend()
    except ImportError:return None


_OPS_PROC=r"""proc craft_canvas_row {c i kinds} {
    set t [$c type $i]
    if {[lsearch -exact $kinds $t] < 0} {return ""}
    if {[$c itemcget $i -stipple] ne ""} {return ""}
    if {$t eq "line"} {
        if {[$c itemcget $i -arrow] ne "none"} {return ""}
        set sm [$c itemcget $i -smooth]
        if {$sm ne "0" && $sm ne "false" && $sm ne ""} {return ""}
    }
    if {$t eq "arc" && [$c itemcget $i -style] ne "arc"} {return ""}
    set fill {};set outline {};set dash {};set start 0;set extent 0
    if {$t ne "arc"} {set fill [$c itemcget $i -fill]}
    if {$t ne "line"} {set outline [$c itemcget $i -outline]}
    if {$t eq "line"} {set dash [$c itemcget $i -dash]}
    if {$t eq "arc"} {set start [$c itemcget $i -start];set extent [$c itemcget $i -extent]}
    set tags [lsearch -all -inline -not -regexp [$c gettags $i] {^(zoom:|_obj|current$)}]
    return "$i\x1f[join [list $t [join $tags \x1d] [$c coords $i] $fill $outline [$c itemcget $i -width] $dash $start $extent] \x1f]"
}
proc craft_canvas_ops {c icons} {
    global craft_rows
    if {$icons} {set kinds {line polygon rectangle oval arc}} else {set kinds {line polygon}}
    set slot "$c $icons"
    if {!$icons && [info exists craft_rows($slot)]} {set known $craft_rows($slot)} else {set known {}}
    set fresh {}
    set out {}
    foreach i [$c find all] {
        if {[dict exists $known $i]} {set row [dict get $known $i]} else {set row [craft_canvas_row $c $i $kinds]}
        dict set fresh $i $row
        if {$row ne ""} {lappend out $row}
    }
    if {!$icons} {set craft_rows($slot) $fresh}
    return [join $out \x1e]
}
proc craft_forget_rows {c} {
    global craft_rows
    foreach slot [array names craft_rows "$c *"] {unset craft_rows($slot)}
}
proc craft_hide {c ids} {foreach i $ids {$c itemconfigure $i -state hidden}}
proc craft_show {c ids} {foreach i $ids {catch {$c itemconfigure $i -state normal}}}
proc craft_over {c ids} {
    set top {}
    foreach i $ids {if {[llength [$c find withtag $i]]} {set top $i;$c itemconfigure $i -state normal}}
    if {$top ne {} && [llength [$c find withtag _smooth_display]]} {$c raise _smooth_display $top}
}"""
_ALLOWED={'component_geometry','notch_geometry','marks','label','guides','prep_fill','grid'}   # 0.18.2: the grid is tagged


def _procs(canvas):
    tk=canvas.tk
    if not tk.call('info','procs','craft_over'):tk.eval(_OPS_PROC)
    return tk


def plain(value):
    """0.18.1: Tk 8.6.15 (Windows) hands some values back as _tkinter.Tcl_Obj (a colour or a
    width keeping a Tk internal type): unhashable and not a number for Python, the smoothing
    stopped on « unhashable type ». Their text is what counts; an empty Tcl list arrives as ()."""
    if isinstance(value,str):return value
    if isinstance(value,tuple):return ' '.join(plain(v) for v in value)
    return str(value)


_UNREAD=object()


def forget_rows(canvas):
    """The items were moved or resized where they are (wheel zoom, move of the view): read again."""
    try:_procs(canvas).call('craft_forget_rows',canvas._w)
    except Exception:pass


def canvas_rows(canvas,icons=False):
    """0.18.7: the smoothed items in stacking order, as (operations, item ids, keys). One Tcl call
    returning ONE string (split by Python: the list of lists cost ~25 ms for 900 lines). An item
    already read keeps its row (Tcl, by item: the items kept by draw_cache are not read again; the
    wheel zoom and the move of the view, which change items where they are, call forget_rows); a row
    already converted keeps its operation (Python, by key: kind, tags, coordinates, colours, width).
    A size kept for the zoom (« zoom: », 0.18.3), the groups of draw_cache (« _obj ») and Tk's
    « current » are not part of the key."""
    tk=_procs(canvas);colours=canvas.__dict__.setdefault('_rgb_names',{});known=canvas.__dict__.get('_ops_known') or {}
    if not icons and not canvas.__dict__.get('_rows_destroy_bound'):
        # 0.19.9: the rows kept for this canvas go with it (each rebuild_ui left those of the plan before: +0.34 MB on DIFORME)
        tk.call('bind',canvas._w,'<Destroy>','+catch [list craft_forget_rows %W]');canvas._rows_destroy_bound=True
    seen={};operations=[];identifiers=[];keys=[]
    def colour(value):
        if not value:return ''
        if value not in colours:colours[value]='#'+''.join(f'{round(v/257):02x}' for v in canvas.winfo_rgb(value))
        return colours[value]
    text=plain(tk.call('craft_canvas_ops',canvas._w,1 if icons else 0))
    for row in text.split('\x1e') if text else ():
        item,key=row.split('\x1f',1);op=known.get(key,_UNREAD)
        if op is _UNREAD:
            kind,tags,coords,fill,outline,width,dash,start,extent=key.split('\x1f')
            if tags and not icons and not set(tags.split('\x1d'))<=_ALLOWED:op=None
            else:op=(kind,tuple(map(float,coords.split())),colour(fill),colour(outline),float(width),tuple(map(float,dash.split())) if kind=='line' else (),float(start),float(extent))
        seen[key]=op
        if op is None:continue
        operations.append(op);identifiers.append(int(item));keys.append(key)
    canvas._ops_known=seen
    return tuple(operations),identifiers,tuple(keys)


def canvas_operations(canvas,icons=False):
    """0.17.0: read in ONE Tcl call (it took ~80 ms of Python→Tk calls for 4000 lines)."""
    ops,ids,_=canvas_rows(canvas,icons)
    return ops,ids


@lru_cache(maxsize=192)
def icon_image(width,height,ops,background):return backend().render(width,height,ops,background)


def icon_png(width,height,ops):return backend().render(width,height,ops)


def photo_image(canvas,data):
    """An opaque PPM goes straight to Tk; a Tk refusing binary PPM gets the same picture as PNG."""
    import tkinter as tk
    if data[:2]==b'P6':
        try:return tk.PhotoImage(master=canvas,data=data,format='PPM')
        except tk.TclError:
            head,rgb=data.split(b'\n',1);_,w,h,_=head.split();data=png_rgb(int(w),int(h),rgb)
    return tk.PhotoImage(master=canvas,data=base64.b64encode(data))


# 0.18.0: what the last smoothing did, for diagnostic.txt ('plan', 'icons').
STATUS={}


# 0.18.7: only the changed part of the smoothed picture is made again (a click, Supprimer, Annuler,
# a change of one piece): the lines that came or went give a rectangle; the lines over it and a
# margin (Pillow's reduction reaches 3 pixels) are drawn on the whole picture's frame, and only that
# rectangle, read or reduced from it, is copied into the picture. Beyond 60 % of the screen, or when
# unchanged lines changed their order, all is made again.
_MARGIN=4


def _extent(op):
    xy=op[1]
    if len(xy)<2:return None
    xs=xy[0::2];ys=xy[1::2];m=op[4]/2+3
    return (min(xs)-m,min(ys)-m,max(xs)+m,max(ys)+m)


def _left(keys,without):
    left=dict(without);out=[]
    for key in keys:
        if left.get(key,0)>0:left[key]-=1;continue
        out.append(key)
    return out


def changed_part(old_keys,new_keys,old_ops,new_ops,width,height):
    """The rectangle (x0, y0, x1, y1) of the picture that changes from ``old_keys`` to ``new_keys``
    (``old_ops`` / ``new_ops``: key → operation); () when no pixel changes; None when the whole
    picture is to be made again."""
    from collections import Counter
    count=Counter(old_keys);count.subtract(new_keys);gone=+count;came=-count
    if not gone and not came:return None if tuple(old_keys)!=tuple(new_keys) else ()
    if _left(old_keys,gone)!=_left(new_keys,came):return None   # the same lines, not in the same order
    boxes=[_extent(old_ops[key]) for key in gone]+[_extent(new_ops[key]) for key in came]
    boxes=[b for b in boxes if b]
    if not boxes:return ()
    x0=max(0,math.floor(min(b[0] for b in boxes)));y0=max(0,math.floor(min(b[1] for b in boxes)))
    x1=min(width,math.ceil(max(b[2] for b in boxes)));y1=min(height,math.ceil(max(b[3] for b in boxes)))
    if x1<=x0 or y1<=y0:return ()
    if (x1-x0)*(y1-y0)>.6*width*height:return None
    return (x0,y0,x1,y1)


def _patched(canvas,renderer,old,signature,ops,base=None):
    """The last smoothed picture with its changed part made again, or None. 0.19.25: the picture is the canvas's sheet
    (the whole screen, sparse or not): the part is put into it as it comes (PPM), no picture made for it."""
    photo=canvas.__dict__.get('_smooth_photo');before=canvas.__dict__.get('_smooth_ops')
    if photo is None or before is None or old is None or old[:3]!=signature[:3] or old[4:]!=signature[4:]:return None
    width,height,background,keys=signature[:4];now=dict(zip(keys,ops))
    part=changed_part(old[3],keys,before,now,width,height)
    if part is None:return None
    if part:
        x0,y0,x1,y1=part
        X0,Y0,X1,Y1=max(0,x0-_MARGIN),max(0,y0-_MARGIN),min(width,x1+_MARGIN),min(height,y1+_MARGIN)
        extents=canvas.__dict__.get('_op_extents') or {};kept={};inside=[]
        for key,op in zip(keys,ops):
            e=extents[key] if key in extents else _extent(op);kept[key]=e
            if e and e[2]>=X0 and e[0]<=X1 and e[3]>=Y0 and e[1]<=Y1:inside.append(op)
        canvas._op_extents=kept
        _put(photo,renderer.render(width,height,tuple(inside),background,box=(x0,y0,x1,y1),base=base),x0,y0)
        canvas._smooth_patched=part   # for the tests: what was made again
    else:canvas._smooth_patched=()
    return photo


# 0.19.25: the smoothed picture is a sheet as large as the screen, kept with the canvas (made once, emptied for each new
# picture: Tk then makes nothing for its empty parts), and only the parts of the screen where the smoothed lines differ
# from the bare canvas are put into it: tiles along the lines (a piece filling the screen: its sides, not its inside), a
# strip along each long straight side across or down (the base's lines), the edges of the zones (their inside, the same
# colour, is shown by the zone itself, just under the picture). The rest of the sheet stays empty: the canvas shows
# through. Parts over most of the screen (or very many): the whole screen at once, as before.
TILE=32        # the tiles of the sparse picture (pixels)
INK=4          # beyond half a line's width: antialiasing and Pillow's reduction reach this far (pixels)
STRIP=3*TILE   # a side straight across or down at least this long: a strip of its own
DENSE=.85      # parts covering more of the screen than this: the whole screen
MAX_PARTS=200
MERGE=2048     # pixels more to show rather than one part more
SPARSE=True    # (False: always the whole screen, as before; for the tests of what was made again)
GUIDES={'guides'}
UNDER={'prep_fill'}   # filled shapes shown as they are under the picture (preparation_ui.lower_fills keeps them under all)


def _tags(key):
    tags=key.split('\x1f',2)[1]
    return frozenset(tags.split('\x1d')) if tags else frozenset()


def ink_parts(ops,width,height,inside=None):
    """0.19.25: the rectangles (x0, y0, x1, y1) of the screen where the smoothed ``ops`` differ from the bare canvas (a
    line, INK pixels around it beyond half its width; a filled shape, unless ``inside`` (one flag an operation) says its
    inside is shown as it is: its edges only): tiles of TILE pixels, in runs along each row of tiles and in blocks of the
    same runs one under the other; a long side straight across or down: a strip of its own. [] : nothing to show."""
    T=TILE;half=T/2;cols=-(-width//T);rows=-(-height//T)
    if cols<=0 or rows<=0:return []
    grid=bytearray(cols*rows);ones=b'\x01'*cols;strips=[]
    def mark(x0,y0,x1,y1):
        a=int(x0//T);b=int(x1//T);c=int(y0//T);d=int(y1//T)
        if a<0:a=0
        if b>=cols:b=cols-1
        if c<0:c=0
        if d>=rows:d=rows-1
        if a>b or c>d:return
        n=b-a+1
        for k in range(c*cols+a,d*cols+a+1,cols):grid[k:k+n]=ones[:n]
    def segment(ax,ay,bx,by,r,strip):
        dx=abs(bx-ax);dy=abs(by-ay)
        if dx<=half and dy<=half:mark(min(ax,bx)-r,min(ay,by)-r,max(ax,bx)+r,max(ay,by)+r);return
        if strip and (dx<.5 or dy<.5) and max(dx,dy)>=STRIP:   # straight across or down: a strip
            x0=max(0,math.floor(min(ax,bx)-r));y0=max(0,math.floor(min(ay,by)-r))
            x1=min(width,math.ceil(max(ax,bx)+r));y1=min(height,math.ceil(max(ay,by)+r))
            if x1>x0 and y1>y0:strips.append((x0,y0,x1,y1))
            return
        k=math.ceil(max(dx,dy)/half);px,py=ax,ay
        for j in range(1,k+1):
            qx=ax+(bx-ax)*j/k;qy=ay+(by-ay)*j/k
            mark(min(px,qx)-r,min(py,qy)-r,max(px,qx)+r,max(py,qy)+r);px,py=qx,qy
    for index,op in enumerate(ops):
        kind,xy,fill=op[0],op[1],op[2]
        if len(xy)<2:continue
        r=op[4]/2+INK;xs=xy[0::2];ys=xy[1::2]
        x0=min(xs);x1=max(xs);y0=min(ys);y1=max(ys)
        if x1+r<0 or y1+r<0 or x0-r>width or y0-r>height:continue   # out of sight
        closed=kind=='polygon' and len(xs)>2
        # its inside: the rows of tiles crossing it at their middle, and its sides in tiles, never strips (review of
        # 0.19.25: the inside between a strip and the middle of its row of tiles was in no part)
        filled=closed and bool(fill) and (inside is None or inside[index])
        if filled:
            ring=list(zip(xs,ys));ring.append(ring[0])
            for ty in range(max(0,int(y0//T)),min(rows-1,int(y1//T))+1):
                yc=(ty+.5)*T;cut=sorted(ax+(yc-ay)*(bx-ax)/(by-ay) for (ax,ay),(bx,by) in zip(ring,ring[1:]) if (ay<=yc)!=(by<=yc))
                for k in range(0,len(cut)-1,2):mark(cut[k],yc,cut[k+1],yc)
        if x1-x0<=half and y1-y0<=half:mark(x0-r,y0-r,x1+r,y1+r);continue   # small: its box
        if closed:xs=xs+xs[:1];ys=ys+ys[:1]
        n=len(xs)
        for s in range(0,n-1,8):   # 8 sides at a time: their box when within half a tile, else side by side
            e=min(n,s+9);gx=xs[s:e];gy=ys[s:e];gx0=min(gx);gx1=max(gx);gy0=min(gy);gy1=max(gy)
            if gx1-gx0<=half and gy1-gy0<=half:mark(gx0-r,gy0-r,gx1+r,gy1+r);continue
            for k in range(s,e-1):segment(xs[k],ys[k],xs[k+1],ys[k+1],r,not filled)
    # runs of tiles along each row (two tiles or less apart: one run), each run added to the block over it when that
    # costs MERGE pixels or less (fewer parts: each costs Tk a call)
    out=[];blocks=[];spare=MERGE/(T*T)
    for ty in range(rows):
        row=grid[ty*cols:(ty+1)*cols];runs=[];tx=row.find(1)
        while tx>=0:
            end=row.find(0,tx)
            if end<0:end=cols
            if runs and tx-runs[-1][1]<=2:runs[-1]=(runs[-1][0],end)
            else:runs.append((tx,end))
            tx=row.find(1,end)
        now=[]
        for a,b in runs:
            best=None
            for k,(x0,x1,t0) in enumerate(blocks):
                if x1<a or x0>b:continue
                u0=min(x0,a);u1=max(x1,b);extra=(u1-u0-(x1-x0))*(ty-t0)+(u1-u0-(b-a))
                if extra<=spare and (best is None or extra<best[0]):best=(extra,k,u0,u1)
            if best:_,k,u0,u1=best;t0=blocks.pop(k)[2];now.append((u0,u1,t0))
            else:now.append((a,b,ty))
        for x0,x1,t0 in blocks:out.append((x0*T,t0*T,min(width,x1*T),min(height,ty*T)))
        blocks=now
    for x0,x1,t0 in blocks:out.append((x0*T,t0*T,min(width,x1*T),min(height,rows*T)))
    return out+strips


def _sheet(canvas,width,height):
    """0.19.25: the canvas's sheet for its smoothed picture, as large as the screen, emptied (Tk keeps nothing for its
    empty parts); a new one when the screen's size changed."""
    import tkinter as tk
    photo=canvas.__dict__.get('_smooth_photo')
    if photo is not None and canvas.__dict__.get('_smooth_sheet')==(width,height):
        try:canvas.tk.call(photo.name,'blank');return photo
        except tk.TclError:pass
    photo=tk.PhotoImage(master=canvas,width=width,height=height);canvas._smooth_photo=photo;canvas._smooth_sheet=(width,height)
    return photo


_PPM_PUT=[True]


def _put(photo,data,x,y):
    """0.19.25: a part of the picture (PPM, or PNG) put into the sheet at (x, y); a Tk refusing binary PPM gets it as PNG."""
    import tkinter as tk
    if data[:2]==b'P6':
        if _PPM_PUT[0]:
            try:photo.tk.call(photo.name,'put',data,'-format','ppm','-to',x,y);return
            except tk.TclError:_PPM_PUT[0]=False
        head,rgb=data.split(b'\n',1);_,w,h,_=head.split();data=png_rgb(int(w),int(h),rgb)
    photo.tk.call(photo.name,'put',base64.b64encode(data),'-format','png','-to',x,y)


def _timed(label,since):
    """0.19.24: the time of a step of the smoothing, for lenteurs.txt (slow_log: its parts of the moment)."""
    now=time.perf_counter()
    try:
        import slow_log
        slow_log.add(label,now-since)
    except Exception:pass
    return now


def paint(canvas,icons=False):
    import tkinter as tk
    renderer=backend();which='icons' if icons else 'plan'
    if renderer is None:STATUS[which]='aucun moteur (ni GDI+ ni Pillow)';return False
    try:
        width=int(float(plain(canvas.cget('width')))) if icons else canvas.winfo_width()
        height=int(float(plain(canvas.cget('height')))) if icons else canvas.winfo_height()
        if width<2 or height<2 or width*height>16000000:
            if not icons:drop_picture(canvas)
            return False
        start=time.perf_counter()
        ops,ids,keys=canvas_rows(canvas,icons);tags=()
        if not icons:
            tags=tuple(map(_tags,keys))
            if ops and all(t and t<=GUIDES for t in tags):ops=()   # 0.19.24: only the base's lines: drawn as they are
            start=_timed('lissage : lecture',start)
        if not ops:
            if not icons:drop_picture(canvas)   # 0.18.7: a picture kept by draw_cache for this pass goes
            return False
        # 0.17.0: an OPAQUE picture on the canvas colour, at the very bottom: Tk displays it at
        # once (a transparent one with thousands of antialiased lines froze Craft over a second).
        background='#'+''.join(f'{round(v/257):02x}' for v in canvas.winfo_rgb(plain(canvas.cget('background'))))
        if icons:
            signature=(width,height,background,keys);old=canvas.__dict__.get('_smooth_signature')
            if old==signature:photo=canvas._smooth_photo
            else:photo=photo_image(canvas,icon_image(width,height,ops,background));canvas._smooth_signature=signature;canvas._smooth_ops=None
            canvas.delete('_smooth_display')
            canvas.tag_lower(canvas.create_image(0,0,image=photo,anchor='nw',tags='_smooth_display'));canvas._smooth_photo=photo
            canvas.tk.call('craft_hide',canvas._w,ids);canvas._smooth_hidden=ids
            canvas.__dict__.pop('_smooth_stale',None)
            canvas._smooth_backend=renderer.name;STATUS[which]='OK ('+renderer.name+')';return True
        base=None
        if canvas.find_withtag('background_image') and canvas.itemcget('background_image','state')!='hidden':
            # 0.19.7: a background picture shown: it goes under the smoothed lines (the picture of it made last,
            # at its place on the screen); none ready (a lighter one during a gesture): the lines stay as they are.
            base=canvas.__dict__.get('_smooth_base')
            if not base or base[0]!=canvas.__dict__.get('_background_key'):drop_picture(canvas);return False
        # 0.19.25: the zones shown as they are under the picture (its empty parts show their inside); over a background
        # picture: all in the picture, as before
        zone=[False]*len(ops) if base else [op[0]=='polygon' and bool(op[2]) and bool(t) and t<=UNDER for op,t in zip(ops,tags)]
        under=[i for i,z in zip(ids,zone) if z]
        signature=(width,height,background,keys,base[0] if base else None,None);old=canvas.__dict__.get('_smooth_signature')
        made=None
        if old==signature and canvas.__dict__.get('_smooth_photo') is not None:photo=canvas._smooth_photo
        elif _patched(canvas,renderer,old,signature,ops,base[1:] if base else None) is not None:
            photo=canvas._smooth_photo;start=_timed('lissage : rendu (une partie)',start)
        else:
            canvas._smooth_patched=None
            if base:parts=[(0,0,width,height)];datas=[renderer.render(width,height,ops,background,base=base[1:])]
            else:
                parts=ink_parts(ops,width,height,[not z for z in zone]) if SPARSE else [(0,0,width,height)]
                if not parts:drop_picture(canvas);return False   # (nothing in sight)
                if len(parts)>MAX_PARTS or sum((x1-x0)*(y1-y0) for x0,y0,x1,y1 in parts)>DENSE*width*height:parts=[(0,0,width,height)]
                datas=renderer.render_parts(width,height,ops,background,parts)
            start=_timed('lissage : rendu',start)
            photo=_sheet(canvas,width,height);made=(parts,datas)
            canvas._smooth_parts=parts;canvas._smooth_renders=canvas.__dict__.get('_smooth_renders',0)+1   # (for the tests)
        canvas._smooth_signature=signature;canvas._smooth_ops=dict(zip(keys,ops))
        canvas.delete('_smooth_display')
        item=canvas.create_image(0,0,image=photo,anchor='nw',tags='_smooth_display');canvas.tag_lower(item)
        if made:   # put once its item is there: Tk makes each part only
            for (x0,y0,x1,y1),data in zip(*made):_put(photo,data,x0,y0)
        if base:canvas.tag_lower('background_image')   # under it (seen again where the picture of the lines slides away)
        if under:   # the picture just over the zones: their inside shows through its empty parts
            canvas.tk.call('craft_over',canvas._w,under);shown=set(under);ids=[i for i in ids if i not in shown]
        canvas._smooth_under=under
        canvas.tk.call('craft_hide',canvas._w,ids);canvas._smooth_hidden=ids   # shown again by show_raw
        canvas.__dict__.pop('_smooth_stale',None)
        if made:
            parts=made[0];area=sum((x1-x0)*(y1-y0) for x0,y0,x1,y1 in parts)
            _timed('lissage : image %d partie%s (%d %%)'%(len(parts),'s' if len(parts)>1 else '',round(100*area/(width*height))),start)
        canvas._smooth_backend=renderer.name;STATUS[which]='OK ('+renderer.name+')';return True
    except (OSError,ValueError,tk.TclError,OverflowError,TypeError,AttributeError,KeyError) as exc:
        STATUS[which]=f'erreur {type(exc).__name__} : {exc}'
        # Keep native geometry visible if a platform backend cannot render it.
        canvas.delete('_smooth_display');canvas.__dict__.pop('_smooth_signature',None);canvas.__dict__.pop('_smooth_hidden',None);canvas.__dict__.pop('_smooth_stale',None);canvas.__dict__.pop('_smooth_under',None)
        for identifier in locals().get('ids',[]):canvas.itemconfigure(identifier,state='normal')
        return False


def drop_picture(canvas):
    """0.18.7: no smoothed picture this time (nothing to smooth): the picture kept until this pass
    (draw_cache) goes and the lines it hid are shown."""
    canvas.__dict__.pop('_smooth_stale',None);canvas.__dict__.pop('_smooth_under',None)
    if not canvas.find_withtag('_smooth_display'):return
    canvas.delete('_smooth_display');ids=canvas.__dict__.pop('_smooth_hidden',None)
    if ids:_procs(canvas).call('craft_show',canvas._w,ids)


def show_raw(canvas):
    """0.18.2: a move or a zoom starts: the smoothed picture (as large as the screen only) is
    removed and the lines it hid are shown again, in one Tcl call; a pending pass is dropped."""
    cancel_paint(canvas);forget_rows(canvas)   # 0.18.7: the items are going to move
    canvas.__dict__.pop('_smooth_stale',None);canvas.__dict__.pop('_smooth_under',None)
    if not canvas.find_withtag('_smooth_display'):return False
    canvas.delete('_smooth_display');ids=canvas.__dict__.pop('_smooth_hidden',None)
    if ids:_procs(canvas).call('craft_show',canvas._w,ids)
    return True


def cancel_paint(canvas):
    """Drop a pending smoothing pass (a drag or move is in progress)."""
    token=canvas.__dict__.get('_smooth_job')
    if token:
        try:canvas.after_cancel(token)
        except Exception:pass
    canvas._smooth_job=None


def queue_paint(canvas,delay=65):
    """Keep pointer motion native/immediate; finish with AA after a short idle (``delay`` ms; a
    timer, not an idle callback: a click or a key coming meanwhile is handled first)."""
    if not canvas.__dict__.get('_smooth_destroy_bound'):
        def cancel(event):
            token=canvas.__dict__.get('_smooth_job')
            if token:
                try:canvas.after_cancel(token)
                except Exception:pass
            canvas._smooth_job=None
        canvas.bind('<Destroy>',cancel,add='+');canvas._smooth_destroy_bound=True
    old=canvas.__dict__.get('_smooth_job')
    if old:
        try:canvas.after_cancel(old)
        except Exception:pass
    def finish():
        canvas._smooth_job=None
        if canvas.winfo_exists():paint(canvas)
    canvas._smooth_job=canvas.after(delay,finish)
