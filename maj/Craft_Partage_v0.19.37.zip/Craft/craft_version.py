"""Single source of truth for source packages and Windows builds."""
VERSION='0.19.37'
APP_ID='Craft.LeatherCAD.Desktop'
