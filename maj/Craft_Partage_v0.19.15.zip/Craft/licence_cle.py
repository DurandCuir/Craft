"""Clé publique du vendeur pour l’édition commerciale de Craft.
Produit par l’Espace vendeur. Ne contient aucun secret."""
CLES_PUBLIQUES = {'k1': 'z-JNTAFKLf_yyKpAMJLhk4112x_2S_RVJ38eYUYx3AE'}
REVOQUEES = frozenset([])
