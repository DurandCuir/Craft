"""Geometry in millimetres. No third-party dependencies."""
import math
import json
import marshal
import re
from functools import lru_cache
from pathlib import Path


def number(v):
    # 0.18.7: a float in range is returned as it is (float(str(v)) gives v back exactly): validating
    # an opened drawing checks 10⁴ of them. NaN and infinities fail the test and are refused below.
    if type(v) is float and -100000 <= v <= 100000:
        return v
    n = float(str(v).replace(',', '.'))
    if not math.isfinite(n) or abs(n) > 100000:
        raise ValueError('Valeur hors limites (±100 000 mm).')
    return n


def validate(items):
    if not isinstance(items, list) or len(items) > 10000:
        raise ValueError('Document invalide ou trop volumineux.')
    for s in items:
        if not isinstance(s, dict) or s.get('kind') not in ('line', 'rect', 'circle', 'poly'):
            raise ValueError('Type de pièce inconnu.')
        if not isinstance(s.get('name'), str) or len(s['name']) > 200:
            raise ValueError('Nom de pièce invalide.')
        for key in ('x', 'y', 'w', 'h', 'r'):
            s[key] = number(s.get(key, 0))
        if s['kind'] in ('rect', 'circle') and (s['w'] <= 0 or s['h'] <= 0):
            raise ValueError('Dimensions positives nécessaires.')
        if not 0 <= s['r'] <= min(abs(s['w']), abs(s['h'])) / 2:
            raise ValueError('Rayon incorrect.')
        if s['kind'] == 'circle' and abs(s['w'] - s['h']) > 1e-8:
            raise ValueError('Diamètre incohérent.')
        if s['kind'] == 'poly':
            pts = s.get('points')
            # 0.18.1: a preparation zone (only shown, never cut) may hold many islands: the
            # Surcoupe band of a précoupe of 100 round pieces.
            zone = s.get('preparation') or (isinstance(s.get('style'), dict) and s['style'].get('role') == 'preparation')
            if not isinstance(pts, list) or not 2 <= len(pts) <= (60000 if zone else 5000):
                raise ValueError('Contour invalide.')
            s['points'] = [[number(x), number(y)] for x, y in pts]
            if 'bulges' in s:
                if not isinstance(s['bulges'],list) or len(s['bulges'])!=len(pts):raise ValueError('Arcs de polyligne invalides.')
                s['bulges']=[number(v) for v in s['bulges']]
            if 'spline' in s:
                sp=s['spline']
                if not isinstance(sp,dict) or not isinstance(sp.get('segments'),list) or not 1<=len(sp['segments'])<=1000:raise ValueError('Spline invalide.')
                for c in sp['segments']:
                    if not isinstance(c,list) or len(c)!=4:raise ValueError('Segment de spline invalide.')
                    for pt in c:
                        if not isinstance(pt,(list,tuple)) or len(pt)!=2:raise ValueError('Point de spline invalide.')
                        for v in pt:number(v)
                if 'fit' in sp:
                    if not isinstance(sp['fit'],list) or not 2<=len(sp['fit'])<=1001:raise ValueError('Points de spline invalides.')
                    for x,y in sp['fit']:number(x);number(y)
                for vec in sp.get('tangents',{}).values():
                    if len(vec)!=2:raise ValueError('Tangente invalide.')
                    for v in vec:number(v)
            if 'components' in s:
                children=s['components']
                if not isinstance(children,list) or not 2<=len(children)<=1000 or any(not isinstance(q,dict) or q.get('components') for q in children):raise ValueError('Assemblage de courbes invalide.')
                validate(children)
            if 'ellipse' in s:
                e=s['ellipse']
                if not isinstance(e,dict):raise ValueError('Ovale invalide.')
                for k in ('rx','ry','angle','start','sweep'):e[k]=number(e.get(k,0))
                if not 0<e['ry']<=e['rx']<=50000 or not 0<e['sweep']<=2*math.pi+1e-7:raise ValueError('Axes ou portion d’ovale invalides.')
        if 'style' in s:
            st=s['style']
            if not isinstance(st,dict):raise ValueError('Style invalide.')
            st['width']=number(st.get('width',.2))
            if not .01<=st['width']<=5:raise ValueError('Épaisseur invalide.')
            if st.get('color','auto')!='auto' and not re.fullmatch(r'#[0-9a-fA-F]{6}',str(st.get('color'))):raise ValueError('Couleur invalide.')
            dash=st.get('dash',[])
            if not isinstance(dash,list) or len(dash)>12 or len(dash)%2 or any(not .05<=number(v)<=100 for v in dash):raise ValueError('Motif invalide.')
            st['dash']=[number(v) for v in dash];st.setdefault('color','auto');st.setdefault('role','drawing')
        if s.get('annotation'):
            if not isinstance(s.get('label'),str) or len(s['label'])>2000:raise ValueError('Annotation invalide.')
            s['text_height']=number(s.get('text_height',3))
            if 'text_angle' in s:s['text_angle']=number(s['text_angle'])
            if 'text_offset' in s:
                if not isinstance(s['text_offset'],list) or len(s['text_offset'])!=2:raise ValueError('Position du texte invalide.')
                s['text_offset']=[number(v) for v in s['text_offset']]
            if not .5<=s['text_height']<=30:raise ValueError('Taille de texte invalide.')
        if 'text_runs' in s:
            if not isinstance(s['text_runs'],list) or not 1<=len(s['text_runs'])<=8:raise ValueError('Bloc de texte invalide.')
            for run in s['text_runs']:
                if not isinstance(run,dict) or not isinstance(run.get('text'),str) or len(run['text'])>500:raise ValueError('Texte invalide.')
                run['height']=number(run.get('height',3));run['dy']=number(run.get('dy',0))
                if not .3<=run['height']<=40:raise ValueError('Taille de texte invalide.')
                if run.get('color','auto')!='auto' and not re.fullmatch(r'#[0-9a-fA-F]{6}',str(run.get('color'))):raise ValueError('Couleur de texte invalide.')
        if s.get('drill'):
            if s['kind']!='circle' or not 0<=number(s.get('drill_diameter',0))<=30:raise ValueError('Mèche invalide.')
        if 'stitch' in s:
            # 0.18.0 Piqûre: by machine, or by hand with the pitch of its holes.
            st=s['stitch']
            if not isinstance(st,dict) or st.get('kind') not in ('machine','hand'):raise ValueError('Piqûre invalide.')
            st['pitch']=number(st.get('pitch',3.85))
            if not .5<=st['pitch']<=30:raise ValueError('Pas de piqûre invalide.')
        marks=s.get('notches',[])
        if not isinstance(marks,list) or len(marks)>5000:raise ValueError('Crans invalides.')
        for mark in marks:
            if not isinstance(mark,dict):raise ValueError('Cran invalide.')
            if mark.get('side',1) not in (-1,1) or not .1<=number(mark.get('width',2))<=100:raise ValueError('Orientation ou largeur du cran invalide.')
            if 'direction' in mark:
                direction=mark['direction']
                if not isinstance(direction,list) or len(direction)!=2 or abs(math.hypot(*[number(v) for v in direction])-1)>.0001:raise ValueError('Direction du cran invalide.')
            if 'cap_width' in mark and not .1<=number(mark['cap_width'])<=100:raise ValueError('Largeur de tête du cran invalide.')
            if 'gap' in mark:
                gap=mark['gap']
                if not isinstance(gap,list) or len(gap)!=2 or not 0<number(gap[0])<number(gap[1])<1:raise ValueError('Coupure du cran invalide.')
                mark['gap']=[number(v) for v in gap]
            if not isinstance(mark,dict) or number(mark.get('distance',-1))<0 or not .1<=number(mark.get('depth',3))<=100:raise ValueError('Cran invalide.')
    return items


# Cache only geometry, never colours, selection or annotations. Value keys detect
# in-place anchor edits; callers receive their own list, so cannot corrupt cache.
_GEOMETRY_KEYS=('kind','x','y','w','h','r','points','closed','bulges','spline','ellipse','components','reversed')
def _freeze(v):
    if isinstance(v,dict):return ('@dict',tuple((k,_freeze(v[k])) for k in sorted(v)))
    if isinstance(v,(list,tuple)):return ('@list',tuple(_freeze(q) for q in v))
    return v

def geometry_key(s):
    # Called for every item on every pointer move: the key must be cheap.
    # marshal is a lossless C serializer (format 2 has no shared references),
    # so equal bytes always mean equal geometry values; an in-place edit
    # changes the bytes and therefore the key, exactly like the frozen tuple.
    fields=tuple((k,s[k]) for k in _GEOMETRY_KEYS if k in s)
    try:return marshal.dumps(fields,2)
    except ValueError:return tuple((k,_freeze(v)) for k,v in fields)

def _thaw(v):
    if isinstance(v,tuple):
        if v[0]=='@dict':return {k:_thaw(q) for k,q in v[1]}
        return [_thaw(q) for q in v[1]]
    return v

def _as_lists(v):
    # Same shapes as _thaw: geometry code always receives fresh lists/dicts.
    if isinstance(v,dict):return {k:_as_lists(q) for k,q in v.items()}
    if isinstance(v,(list,tuple)):return [_as_lists(q) for q in v]
    return v

def _key_fields(key):
    if isinstance(key,bytes):return {k:_as_lists(v) for k,v in marshal.loads(key)}
    return dict((k,_thaw(v)) for k,v in key)

@lru_cache(maxsize=1<<16)   # 0.17.0: 80 pieces with their crans are ~6000 paths
def _cached_path(key):
    pts,closed=_path(_key_fields(key))
    return tuple(pts),closed

def clone(value):
    """0.17.0: a fast deep copy of drawing data (plain dicts, lists, numbers, strings); marshal is
    about ten times faster than copy.deepcopy on 1600 objects (Annuler, actions)."""
    try:return marshal.loads(marshal.dumps(value,2))
    except ValueError:
        import copy
        return copy.deepcopy(value)

def path(s):
    tol=_DISPLAY_TOL[0]
    pts,closed=_cached_fine(geometry_key(s),tol) if tol is not None else _cached_path(geometry_key(s))
    return list(pts),closed

# 0.18.5 (zoom up to 2 000 px/mm): while the plan is drawn past 80 px/mm, the curves are cut finer
# (about a quarter of a pixel) for the screen only; every computation keeps the usual cut.
_DISPLAY_TOL=[None]

class display_tolerance:
    def __init__(self,tol):self.tol=tol
    def __enter__(self):self.old=_DISPLAY_TOL[0];_DISPLAY_TOL[0]=self.tol;return self
    def __exit__(self,*exc):_DISPLAY_TOL[0]=self.old;return False

@lru_cache(maxsize=1<<14)
def _cached_fine(key,tol):
    pts,closed=_path(_key_fields(key),tol)
    return tuple(pts),closed

def _path(s,tol=.005):
    x, y, w, h, r = [s[k] for k in ('x', 'y', 'w', 'h', 'r')]
    if s.get('components'):
        from curves import parts
        pts=[]
        for q in parts(s):
            pp,_=path(q)
            if pts and math.dist(pts[-1],pp[0])<1e-6:pp=pp[1:]
            pts.extend(pp)
        if s.get('closed') and len(pts)>2 and math.dist(pts[0],pts[-1])<1e-6:pts.pop()
        return pts,bool(s.get('closed'))
    if s.get('spline'):
        from curves import spline_path
        return spline_path(s) if tol>=.005 else spline_path(s,tol*.6)
    if s.get('ellipse'):
        from precision_geometry import ellipse_path
        return ellipse_path(s) if tol>=.005 else ellipse_path(s,tol*.6)
    if s['kind'] == 'line':
        return [(x, y), (x+w, y+h)], False
    if s['kind'] == 'poly':
        pts=[(x+a,y+b) for a,b in s['points']];closed=bool(s.get('closed'));bs=s.get('bulges',[])
        if not any(bs):return pts,closed
        out=[]
        for i,(a,b) in enumerate(zip(pts,pts[1:]+pts[:1] if closed else pts[1:])):
            bulge=bs[i];out.append(a)
            if abs(bulge)<1e-10:continue
            chord=math.dist(a,b)
            if chord<1e-9:continue
            cx=(a[0]+b[0])/2-(b[1]-a[1])*(1-bulge*bulge)/(4*bulge)
            cy=(a[1]+b[1])/2+(b[0]-a[0])*(1-bulge*bulge)/(4*bulge)
            radius=math.dist(a,(cx,cy));start=math.atan2(a[1]-cy,a[0]-cx);sweep=4*math.atan(bulge)
            step=2*math.acos(max(-1,1-min(tol/radius,1)));count=min(4000,max(2,math.ceil(abs(sweep)/step)))
            out.extend((cx+radius*math.cos(start+sweep*j/count),cy+radius*math.sin(start+sweep*j/count)) for j in range(1,count))
        if not closed:out.append(pts[-1])
        return out,closed
    if s['kind'] == 'circle':
        # Fine tessellation: <= 0.01 mm chord error at supported practical sizes.
        radius = w/2
        count = max(64, math.ceil(math.pi/math.acos(max(-1, 1-min(tol/radius, 1)))))
        count = min(15000, 4*math.ceil(count/4))
        return [(x+radius+radius*math.cos(i*2*math.pi/count),
                 y+radius+radius*math.sin(i*2*math.pi/count)) for i in range(count)], True
    if not r:
        return [(x, y), (x+w, y), (x+w, y+h), (x, y+h)], True
    out = []
    n = max(12, math.ceil(math.pi/2 / math.acos(max(-1, 1-min(tol/r, 1)))))
    for cx, cy, start in [(x+w-r, y+r, -90), (x+w-r, y+h-r, 0),
                          (x+r, y+h-r, 90), (x+r, y+r, 180)]:
        for j in range(n+1):
            t = math.radians(start+j*90/n)
            out.append((cx+r*math.cos(t), cy+r*math.sin(t)))
    return out, True


# Pre-filters for pointer and intersection searches. Boxes come from the
# tessellated path, which stays within a few thousandths of a millimetre of the
# exact curve; the 1 mm + 1 % margin is far wider, so an item rejected here can
# never be within reach of the exact computation that follows.
def _margin(b):return 1+.01*max(b[2]-b[0],b[3]-b[1])

def near_box(s,p,reach):
    b=bounds([s]);m=reach+_margin(b)
    return b[0]-m<=p[0]<=b[2]+m and b[1]-m<=p[1]<=b[3]+m

def boxes_apart(s,t):
    a=bounds([s]);b=bounds([t]);m=max(_margin(a),_margin(b))
    return a[0]-m>b[2] or b[0]-m>a[2] or a[1]-m>b[3] or b[1]-m>a[3]

# 0.16.26: during one pointer event the shapes do not change, so each box is computed
# once per event instead of once per search (snaps, hover pick). Entries keep a reference
# to their shape, so an id can never be reused while the frame is open.
# 0.19.9: the boxes of the drawing's own shapes are kept from one pointer event to the next, until
# the plan is drawn again or is about to change (forget_boxes, from the application's redraw and
# snapshot): moving the mouse over a big pattern no longer works out every box again at every move.
# Other shapes (previews, moved copies) are kept for the event only.
_FRAME=None
_KEPT={}
_DRAWING=frozenset()
def forget_boxes():
    _KEPT.clear()
class pointer_frame:
    def __init__(self,items=()):
        self.items=items
    def __enter__(self):
        global _FRAME,_DRAWING
        self.owner=_FRAME is None
        if self.owner:_FRAME={};_DRAWING=frozenset(map(id,self.items))
        return self
    def __exit__(self,*exc):
        global _FRAME,_DRAWING
        if self.owner:_FRAME=None;_DRAWING=frozenset()
        return False

def frame_cache():
    # 0.19.9: the dict of the pointer event in progress (None outside pointer_frame), where a search keeps
    # what a later search of the same event reuses (cad.snap_point: the crossings under the pointer).
    return _FRAME

def bounds(items):
    frame=_FRAME   # 0.18.7: read once (a DWG worker thread computes boxes while the pointer moves)
    if frame is not None and len(items)==1:
        s=items[0];k=id(s);store=_KEPT if k in _DRAWING else frame;hit=store.get(k)
        if hit is not None and hit[0] is s:return hit[1]
        box=_cached_bounds(geometry_key(s));store[k]=(s,box);return box
    boxes=[_cached_bounds(geometry_key(s)) for s in items]
    if not boxes:return 0,0,100,100
    return min(b[0] for b in boxes),min(b[1] for b in boxes),max(b[2] for b in boxes),max(b[3] for b in boxes)

# Boxes are four numbers: a larger table keeps big patterns from thrashing.
@lru_cache(maxsize=16384)
def _cached_bounds(key):
    pts,_=_cached_path(key)
    if not pts:return 0,0,100,100
    return min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts)

# 0.19.9: a search near the pointer (snapping to crossings) reads only the segments under it: the segments
# of each contour are kept in runs of 32 with the box of each run, computed once per contour like its box.
def segments_near(s,box):
    """The segments of s's contour (as cad.segments, in their order) whose box meets box = (x0, y0, x1, y1)."""
    x0,y0,x1,y1=box
    return [(a,b) for X0,X1,Y0,Y1,run in _cached_runs(geometry_key(s),_DISPLAY_TOL[0]) if X0<=x1 and X1>=x0 and Y0<=y1 and Y1>=y0
            for a,b in run if (a[0]<=x1 or b[0]<=x1) and (a[0]>=x0 or b[0]>=x0) and (a[1]<=y1 or b[1]<=y1) and (a[1]>=y0 or b[1]>=y0)]

@lru_cache(maxsize=4096)
def _cached_runs(key,tol):
    pts,closed=_cached_fine(key,tol) if tol is not None else _cached_path(key)
    pairs=list(zip(pts,pts[1:]+pts[:1] if closed else pts[1:]));out=[]
    for k in range(0,len(pairs),32):
        run=tuple(pairs[k:k+32]);xs=[v for a,b in run for v in (a[0],b[0])];ys=[v for a,b in run for v in (a[1],b[1])]
        out.append((min(xs),max(xs),min(ys),max(ys),run))
    return tuple(out)


def anchors(s):
    pts, closed = path(s)
    if s['kind'] == 'circle':
        x,y,w,h = [s[k] for k in ('x','y','w','h')]
        return [(x+w/2,y+h/2),(x,y+h/2),(x+w,y+h/2),(x+w/2,y),(x+w/2,y+h)]
    if s['kind'] == 'rect':
        x,y,w,h = [s[k] for k in ('x','y','w','h')]
        return [(x,y),(x+w,y),(x+w,y+h),(x,y+h),(x+w/2,y),
                (x+w/2,y+h),(x,y+h/2),(x+w,y+h/2)]
    out = list(pts)
    for a,b in zip(pts, pts[1:]+pts[:1] if closed else pts[1:]):
        out.append(((a[0]+b[0])/2,(a[1]+b[1])/2))
    return out


def distance(p, a, b):
    dx,dy = b[0]-a[0],b[1]-a[1]
    n = dx*dx+dy*dy
    t = max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/n)) if n else 0
    return math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)


def save(file, items):
    validate(items)
    target = Path(file)
    temp = target.with_suffix(target.suffix+'.tmp')
    temp.write_text(json.dumps({'format':'atelier-patron','version':1,'units':'mm','shapes':items},
                               ensure_ascii=False,indent=2),encoding='utf-8')
    temp.replace(target)


def load(file):
    if Path(file).stat().st_size > 10000000:
        raise ValueError('Document trop volumineux.')
    doc = json.loads(Path(file).read_text(encoding='utf-8'))
    if doc.get('format') != 'atelier-patron' or doc.get('version') != 1 or doc.get('units') != 'mm':
        raise ValueError('Format de document non reconnu.')
    return validate(doc['shapes'])


def export_svg(file, items):
    from craft_tools import notch_shapes,style
    from editing import drill_decorations,annotation_parts
    items=export_entities(items)
    from xml.sax.saxutils import escape
    x,y,X,Y = bounds(items)
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{X-x+20}mm" height="{Y-y+20}mm" viewBox="{x-10} {y-10} {X-x+20} {Y-y+20}">']
    for s in items:
        st=style(s);color='black' if st['color']=='auto' else st['color'];dash=' '.join(map(str,st['dash']))
        if s.get('annotation'):
            from craft_tools import annotation_baseline
            tx,ty=annotation_baseline(s)
            align=' text-anchor="middle" dominant-baseline="central"' if 'text_offset' in s else ''
            out.append(f'<text x="{tx}" y="{ty}" transform="rotate({s.get("text_angle",0)} {tx} {ty})"{align} font-size="{s.get("text_height",3)}" font-weight="{s.get("text_weight","normal")}" fill="{color}">{escape(s["label"])}</text>');continue
        pts, closed = path(s)
        d = 'M '+' L '.join(f'{a:.6f},{b:.6f}' for a,b in pts)+(' Z' if closed else '')
        out.append(f'<path d="{d}" fill="{color if s.get("filled") else "none"}" stroke="{color}" stroke-width="{st['width']}" stroke-dasharray="{dash}"><title>{escape(s["name"])}</title></path>')
    Path(file).write_text('\n'.join(out+['</svg>']),encoding='utf-8')


def export_entities(items,pdf=False):
    from craft_tools import notch_shapes
    from editing import drill_decorations,annotation_parts,pdf_drill_parts
    from curves import parts
    from stitching import hole_shapes
    # 0.18.0: the holes of a hand stitch (dots on paper, circles of 1 mm otherwise).
    expanded=[q for s in items for q in (pdf_drill_parts(s) if pdf and s.get('drill') else annotation_parts(s)+notch_shapes(s)+drill_decorations(s)+hole_shapes(s,filled=pdf))]
    return [part for s in expanded for part in (parts(s) if s.get('components') else [s])]


def pdf_plan(items,workspace=None,margin=None,gap=None,paper='A4',**options):
    """``gap`` (mm): the space between pieces (alone: every zone together, the 0.17 « au plus
    serré »); ``paper`` (0.18.1): A4, A3, A2, A1 or A0. 0.18.5: ``options`` of
    pdf_layout.organized_plan (together, archives, budget, progress, tries)."""
    from pdf_layout import organized_plan,MARGIN
    return organized_plan(items,workspace,MARGIN if margin is None else margin,gap,paper,**options)


def ink(color,mono=False):
    """PDF colour (0-1) of a style colour; black & white prints every line and text in black."""
    if mono or color=='auto':return [0,0,0]
    return [int(color[i:i+2],16)/255 for i in (1,3,5)]


def export_pdf(file, items,workspace=None,plan=None,title=None,mono=False,margin=None,paper='A4'):
    """A4 at exactly 1:1, packed by zone; only oversized pieces are tiled.
    0.16.28: the model name is in the heading; no « Taille réelle » footer.
    0.16.29: page margin chosen by the user (5 mm by default), the title inside the frame
    so that printers never cut it, black & white option. 0.18.1: the plan's paper (A4 to A0).
    0.18.5: the content clip is larger than the area by half the page's widest line: a piece set
    against the frame keeps its whole line (the plan keeps the pieces 1 mm inside anyway)."""
    from craft_tools import style
    from pdf_layout import page_area,paper_size,stroke_reach,MARGIN,PRINTABLE,OVERLAP
    plan=plan or pdf_plan(items,workspace,margin,paper=paper)
    pw,ph=plan.get('size') or paper_size(plan.get('paper','A4'))
    m=plan.get('margin',MARGIN if margin is None else margin);left,top,W,H=plan.get('area') or page_area(m,plan.get('paper','A4'))
    factor = 72/25.4
    def pt(a): return f'{a*factor:.5f}'
    def text(a,b,t,size=9,angle=0,bold=False):
        t = t.replace('\\','\\\\').replace('(','\\(').replace(')','\\)')
        theta=math.radians(angle);co,si=math.cos(theta),math.sin(theta)
        return f'BT /{"F2" if bold else "F1"} {size} Tf {co:.8f} {si:.8f} {-si:.8f} {co:.8f} {pt(a)} {pt(b)} Tm ({t}) Tj ET\n'
    def line(a,b,c,d): return f'{pt(a)} {pt(b)} m {pt(c)} {pt(d)} l S\n'
    X=lambda a,ox:a-ox+left;Y=lambda b,oy:ph-top-(b-oy)          # plan mm -> PDF points space (mm, from the bottom)
    pages=[]
    for index,spec in enumerate(plan['page_specs']):
        ox,oy=spec['origin'];col,row=spec['col'],spec['row'];nx,ny=spec['columns'],spec['rows']
        heading=' | '.join(['Craft']+([title] if title else [])+[spec['zone'],f"page {index+1}/{plan['pages']}"])
        if nx>1 or ny>1:heading+=f' | colonne {col+1}/{nx} - ligne {row+1}/{ny} - recouvrement {OVERLAP:g} mm'
        e=stroke_reach(spec['items'])
        out=['0 G 0 g 0.35 w\n',text(m+1.5,ph-max(m,PRINTABLE)-4.2,heading,8),f'q {pt(left-e)} {pt(m-e)} {pt(W+2*e)} {pt(H+2*e)} re W n\n']
        for item in spec['items']:
            pts,closed=path(item);st=style(item);rgb=ink(st['color'],mono)
            out.append(' '.join(str(v) for v in rgb)+' RG '+' '.join(str(v) for v in rgb)+' rg '+pt(st['width'])+' w ['+' '.join(pt(v) for v in st['dash'])+'] 0 d\n')
            if item.get('annotation'):
                from craft_tools import annotation_baseline
                tx,ty=annotation_baseline(item);tx=X(tx,ox);ty=Y(ty,oy)
                angle=-item.get('text_angle',0);height=item.get('text_height',3)
                if 'text_offset' in item:
                    theta=math.radians(angle);half=len(item['label'])*height*.27
                    tx+=-half*math.cos(theta)+height*.35*math.sin(theta);ty+=-half*math.sin(theta)-height*.35*math.cos(theta)
                out.append(text(tx,ty,item['label'],height*factor,angle,item.get('text_weight')=='bold'))
                if item.get('text_underline'):
                    theta=math.radians(angle);length=len(item['label'])*height*.54
                    ux,uy=tx+height*.2*math.sin(theta),ty-height*.2*math.cos(theta)
                    out.append(line(ux,uy,ux+length*math.cos(theta),uy+length*math.sin(theta)))
                continue
            out.append(' '.join(f'{pt(X(a,ox))} {pt(Y(b,oy))} '+('m' if i==0 else 'l') for i,(a,b) in enumerate(pts)))
            out.append((' h' if closed else '')+(' f\n' if item.get('filled') else ' S\n'))
        out+=['Q\n','0.65 G [3 3] 0 d\n',f'{pt(m)} {pt(m)} {pt(pw-2*m)} {pt(ph-2*m)} re S\n','[] 0 d 0 G\n']
        if nx>1 or ny>1:
            for a in (left+2.5,left+W-2.5):
                for b in (m+2.5,m+H-2.5):out += [line(a-1.5,b,a+1.5,b),line(a,b-1.5,a,b+1.5)]
        pages.append(''.join(out).encode('cp1252',errors='replace'))
    # Minimal PDF writer. Each vector coordinate is converted from mm to PDF points.
    # Viewers print at actual size by default (PrintScaling /None); accents in names (WinAnsi).
    objects = [b'<< /Type /Catalog /Pages 2 0 R /ViewerPreferences << /PrintScaling /None >> >>',b'',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>']
    kids = []
    for data in pages:
        pid = len(objects)+1
        cid = pid+1
        kids.append(f'{pid} 0 R')
        objects.append(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {pt(pw)} {pt(ph)}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {cid} 0 R >>'.encode())
        objects.append(f'<< /Length {len(data)} >>\nstream\n'.encode()+data+b'\nendstream')
    objects[1] = f'<< /Type /Pages /Count {len(kids)} /Kids [{" ".join(kids)}] >>'.encode()
    out = bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n'); offsets = [0]
    for i,obj in enumerate(objects,1):
        offsets.append(len(out)); out.extend(f'{i} 0 obj\n'.encode()+obj+b'\nendobj\n')
    start = len(out)
    out.extend(f'xref\n0 {len(objects)+1}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]: out.extend(f'{offset:010d} 00000 n \n'.encode())
    out.extend(f'trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{start}\n%%EOF\n'.encode())
    # 0.19.9: written beside then put in place (like cad.write_document): a failed write never leaves a cut
    # PDF where the previous one was; the temporary file goes. A PDF open in a reader still gives PermissionError.
    p=Path(file);temp=p.with_name(p.name+'.tmp')
    try:temp.write_bytes(out);temp.replace(p)
    except BaseException:
        try:temp.unlink(missing_ok=True)
        except OSError:pass
        raise
    return len(pages)


def export_print_test(file):
    """A separate A4 calibration document; never mixed with fabrication pieces."""
    from cad import shape
    from craft_tools import annotation
    # 0.16.28: a 50 × 50 mm square.
    items=[shape('rect','Carré test',70,50,50,50),annotation('TEST 50 x 50 mm',(25,25),5),annotation('Mesurer 50 mm de chaque côté.',(25,115),3)]
    plan=dict(pages=1,page_specs=[dict(items=items,origin=(0,0),col=0,row=0,columns=1,rows=1,zone='Test impression')])
    return export_pdf(file,items,plan=plan)
