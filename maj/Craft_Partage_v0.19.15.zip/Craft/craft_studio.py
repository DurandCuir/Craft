"""Craft 0.4: dockable tool families and leatherworking commands."""
import tkinter as tk
from tkinter import ttk,messagebox,simpledialog
from pathlib import Path
import math,json,copy
from geometry import path,bounds
from cad import shape
from ui_widgets import draw_icon,contrast_color,zoom_tag,dash_px
from craft_tools import PROFILES,style,locate,perimeter,notch_shapes,copy_notches,dimensions,annotation,offset,portion,cote_label

EXTRA={'measure':'Règle','dimension':'Cote','radius':'Cote (rayon)',
'move_anchor':'Déplacer par ancrage','offset_all':'Décaler un contour','offset_edge':'Décaler un côté',
'offset_part':'Décaler une portion A → B','notch':'Ajouter un cran','copy_notch':'Copier les crans',
'part_name':'Nommer une pièce','material':'Matière'}


# 0.19.9: what Craft can use from archives.json (anything else is « unreadable »: never overwritten).
def archives_valid(a):
    return (isinstance(a,dict) and isinstance(a.get('names'),list) and len(a['names'])==3 and all(isinstance(n,list) for n in a['names'])
            and isinstance(a.get('materials',[]),list) and isinstance(a.get('material_info',{}),dict))


def extend(Base):
    class Craft(Base):
        def __init__(self):
            self.layout={};self.variants={};self.profiles=copy.deepcopy(PROFILES);self.active_profile='Dessin'
            self.archives={'names':[[],[],[]],'materials':[]};self.project_model=None;self.extra_points=[];self.extra_item=None
            self.pending_annotation=None;self.floats=[];self.log_messages=[];self._extra_ready=False
            super().__init__()
            self.maximize_and_fit()   # 0.19.5: before the window is first shown (it was shown at 1440 × 900, then drawn again maximised)

        def maximize_and_fit(self):
            try:tk.Tk.state(self,'zoomed')
            except (tk.TclError,AttributeError):
                try:self.attributes('-zoomed',True)
                except (tk.TclError,AttributeError):
                    try:self.geometry(f'{self.winfo_screenwidth()}x{self.winfo_screenheight()}+0+0')
                    except (tk.TclError,AttributeError,TypeError):pass   # (a window stand-in in the tests)
            self.after(220,self.fit_workspace)

        def help(self):
            # 0.19.9: LIRE_MOI.txt beside the modules, like dxf_base.dxf (exchange.py): in the source and, bundled by
            # Craft.spec, in the frozen edition (it was missing there: FileNotFoundError); missing anyway: said, no error
            try:guide=Path(__file__).with_name('LIRE_MOI.txt').read_text(encoding='utf-8')
            except (OSError,UnicodeError):messagebox.showinfo('Craft · mode d’emploi','Le mode d’emploi est introuvable sur ce PC.',parent=self);return
            win=self.dialog('Craft · mode d’emploi')
            win.resizable(True,True)
            text=tk.Text(win,width=95,height=32,wrap='word',bg=self.p['panel'],fg=self.p['ui_ink'],font=('Segoe UI',10))
            scroll=ttk.Scrollbar(win,orient='vertical',command=text.yview);scroll.pack(side='right',fill='y');text.configure(yscrollcommand=scroll.set)   # 0.19.0: the thin dark scroll bar
            text.pack(fill='both',expand=True);text.insert('1.0',guide);text.configure(state='disabled')
        def archive_path(self):
            from workspace_ui import settings_path
            return settings_path().with_name('archives.json')
        # 0.19.9: one change of the archives written on archives.json read again just before (two Craft windows: the last
        # one no longer drops what the other added), written whole.
        def change_archives(self,change,parent=None):
            """``change(archives)`` adds, modifies or deletes one entry; it is made on what the file holds, the file is
            written, then this window's copy is taken from it (in place: the lists open windows show stay theirs).
            False, the file untouched, when it cannot be read."""
            path=self.archive_path();fresh=None
            if not self.__dict__.get('archives_unreadable'):
                try:fresh=json.loads(path.read_text(encoding='utf-8'))
                except FileNotFoundError:fresh=copy.deepcopy(self.archives)   # no file (yet): this window's archives
                except (OSError,ValueError):fresh=None
            if not archives_valid(fresh):
                messagebox.showerror('Archives','Archives illisibles (archives.json) : rien n’est enregistré, pour ne pas les écraser.',parent=parent or self);return False
            change(fresh)   # a ValueError (« Cette matière existe déjà. »…): nothing written, nothing changed
            from app_preferences import write_atomic
            try:write_atomic(path,json.dumps(fresh,ensure_ascii=False,indent=2))
            except OSError:messagebox.showerror('Archives','Archives non enregistrées : archives.json est inaccessible.',parent=parent or self);return False
            mine=self.archives
            for key in [k for k in mine if k not in fresh]:del mine[key]
            for key,value in fresh.items():
                old=mine.get(key)
                if key=='names' and isinstance(old,list) and len(old)==len(value) and all(isinstance(c,list) for c in old):
                    for column,names in zip(old,value):column[:]=names
                elif isinstance(old,list) and isinstance(value,list):old[:]=value
                elif isinstance(old,dict) and isinstance(value,dict):old.clear();old.update(value)
                else:mine[key]=value
            return True
        def before_build(self):
            super().before_build();self.read_custom()   # 0.19.5: the user's toolbar layout from the first build
        def read_custom(self):
            try:
                from workspace_ui import settings_path
                p=json.loads(settings_path().read_text(encoding='utf-8'))
                self.layout=p.get('toolbar_layout',{});self.variants={}
                for k,v in p.get('profiles',{}).items():
                    if isinstance(k,str) and isinstance(v,dict):self.profiles[k]=v
            except (OSError,ValueError,TypeError,AttributeError):pass
            # 0.19.9: the archives on their own (a missing or damaged preferences.json left them out, and the next
            # Ajouter wrote archives.json with only the new entry). No file: an empty library; a file that cannot be
            # read is never written in this session (change_archives refuses).
            try:
                a=json.loads(self.archive_path().read_text(encoding='utf-8'))
                if not archives_valid(a):raise ValueError('archives.json')
                self.archives=a
            except FileNotFoundError:pass
            except (OSError,ValueError):self.archives_unreadable=True
        def load_custom(self):
            self.read_custom();self.rebuild_tools()
            if hasattr(self,'profile_box'):self.profile_box.configure(values=list(self.profiles))
        def persist_preferences(self):
            self.prefs.update(toolbar_layout=self.layout,tool_variants=self.variants,profiles=self.profiles)
            super().persist_preferences()
        def build(self):
            self.bottom_buttons=None
            super().build()
            self.rail.destroy();self.quickbar.pack_forget()
            self.topdock=tk.Frame(self.root_frame,bg=self.p['panel']);self.topdock.pack(fill='x',before=self.body)
            self.leftdock=tk.Frame(self.body,bg=self.p['panel']);self.leftdock.pack(side='left',before=self.canvas,fill='y')
            self.toolgroups={
              'Fichiers':[('new',[('new','Nouveau',self.new_doc)]),('open',[('open','Ouvrir',self.open_doc)]),('save',[('save','Enregistrer',self.save_doc)])],
              'Édition':[('undo',[('undo','Annuler',self.undo)]),('redo',[('redo','Rétablir',self.redo)]),('move',[('move_anchor','Déplacer par ancrage',None)]),('offset',[('offset_all','Contour entier',None),('offset_edge','Un côté',None),('offset_part','Portion A → B',None)])],
              'Géométrie':[('select',[('select','Sélection',None)]),('line',[('line','Ligne',None),('poly','Contour',None)]),('rect',[(t,lab,None) for t,lab in [('rect','Rectangle (2 coins)'),('rect_center','Rectangle (centré)'),('rect_round','Rectangle (arrondi)'),('rect_rot','Rectangle (orienté)'),('para','Parallélogramme')]]),('circle',[(t,lab,None) for t,lab in [('circle_radius','Cercle (rayon)'),('circle_diameter','Cercle (diamètre)'),('circle_2p','Cercle (2 points)'),('circle_3p','Cercle (3 points)')]])],
              'Mesures':[('measure',[('measure','Règle temporaire',None)]),('dimension',[('dimension','Cote',None),('radius','Cote (rayon)',None)])],
              'Assemblage':[('notch',[('notch','Ajouter un cran',None),('copy_notch','Copier les crans',None)])],
              'Identification':[('part_name',[('part_name','Nom de pièce',None)]),('material',[('material','Matière',None)])],
              'Traits':[('white',[('white','Dessin blanc',lambda:self.apply_profile('Dessin'))]),('external',[('external','Coupe',lambda:self.apply_profile('Coupe extérieure'))]),('internal',[('internal','Coupe intérieure',lambda:self.apply_profile('Coupe intérieure'))])]}
            self.configure_toolgroups()
            self.rebuild_tools()
            profiles=tk.Frame(self.topdock,bg=self.p['panel']);profiles.pack(fill='x',side='bottom')
            if getattr(self,'uses_line_category',False) is not True:self.build_line_picker(profiles)
            self.ortho_button.destroy();self.snap_button.destroy()
            for w in self.footer.winfo_children():
                if isinstance(w,tk.Button) and w.cget('text')=='Ancrages ▾':w.destroy()
            self.bottom_buttons={}
            for icon,fn,tip in [('grid',self.toggle_grid,'Grille · F7'),('snap',self.toggle_snap,'Ancrages · F3'),('ortho',self.toggle_ortho,'Orthogonal · F8')]:
                c=self.small_icon(self.footer,icon,fn,tip);c.pack(side='right',padx=2);self.bottom_buttons[icon]=c
            self.button(self.footer,'▾',self.snap_menu).pack(side='right')
            self.update_toggle_labels()
            # A sash changes history height while the drawing retains remaining room.
            sash=tk.Frame(self.root_frame,bg=self.field_border(),height=2,cursor='sb_v_double_arrow');sash.pack(fill='x',before=self.command_frame)
            hist=tk.Frame(self.root_frame,bg=self.p['panel'],height=55);hist.pack(fill='x',before=self.command_frame);hist.pack_propagate(False)
            self.command_prompt=tk.Label(hist,text='Commande',bg=self.p['panel'],fg=self.p['ui_ink'],font=('Segoe UI',10),anchor='w',padx=8)
            self.command_prompt.pack(fill='x')
            self.command_prompt.bind('<Button-1>',lambda e:self.open_commands())
            self.history=tk.Text(hist,height=3,bg=self.p['panel'],fg=self.p['ui_ink'],relief='flat',font=('Segoe UI',10),state='disabled')
            self.history.pack(fill='both',expand=True)
            drag={}
            sash.bind('<Button-1>',lambda e:drag.update(y=e.y_root,h=hist.winfo_height()))
            sash.bind('<B1-Motion>',lambda e:hist.configure(height=max(24,min(320,drag['h']+drag['y']-e.y_root))))
            tabs=tk.Frame(self.root_frame,bg=self.p['panel']);tabs.pack(fill='x',before=self.footer)
            self.object_tabs=tabs
            self.button(tabs,'Objet',lambda:None).pack(side='left')
            self.status.trace_add('write',lambda *a:self.log_status())
            self._extra_ready=True
        def configure_toolgroups(self):pass
        def build_line_picker(self,parent):
            self.profile_var=tk.StringVar(value=self.active_profile)
            self.profile_box=ttk.Combobox(parent,textvariable=self.profile_var,values=list(self.profiles),state='readonly',width=23)
            self.profile_box.pack(side='left');self.profile_box.bind('<<ComboboxSelected>>',lambda e:self.apply_profile(self.profile_var.get()))
        def log_status(self):
            if not hasattr(self,'history') or not self.history.winfo_exists():return
            text=self.status.get()
            if not text or self.log_messages[-1:]==[text]:return
            # Cursor distances are transient, not an error-history entry.
            if text==self.__dict__.get('_live_status') and self.start is not None:return   # 0.19.9: in every unit (was ' mm' only)
            self.log_messages.append(text);self.log_messages=self.log_messages[-200:]
            self.history.configure(state='normal');self.history.delete('1.0','end');self.history.insert('end','\n'.join(self.log_messages));self.history.configure(state='disabled');self.history.see('end')
        def small_icon(self,parent,icon,fn,tip):
            n=self.p['icon_size'];c=tk.Canvas(parent,width=n+10,height=n+10,bg=self.p['panel'],highlightthickness=1,highlightbackground=self.p['panel'],cursor='hand2')
            known=icon if icon in ('new','open','save','line','rect','circle','select','undo','redo','gear') else None
            if known:draw_icon(c,known,n,contrast_color(self.p['panel']));c.move('all',4,4)
            elif icon=='grid':
                for f in (.25,.5,.75):c.create_line(n*f+4,4,n*f+4,n+4,fill=self.p['ui_ink'],width=1.8);c.create_line(4,n*f+4,n+4,n*f+4,fill=self.p['ui_ink'],width=1.8)
            elif icon=='ortho':c.create_line(5,5,5,n+3,n+3,n+3,fill=self.p['ui_ink'],width=2.4)
            elif icon=='measure':
                c.create_rectangle(4,7,n+4,n,outline=self.p['ui_ink'],width=2)
                for i in range(1,5):
                    x=4+i*n/5;c.create_line(x,7,x,10 if i%2 else 12,fill=self.p['ui_ink'],width=1.8)
            else:
                symbols={'snap':'⊙','measure':'↔','dimension':'↤','move':'✥','offset':'∥','notch':'V','part_name':'N','material':'M','white':'✎','external':'✎','internal':'✎'}
                color={'external':'#ff3030','internal':'#142e90'}.get(icon,self.p['ui_ink'])
                c.create_text((n+10)/2,(n+10)/2,text=symbols.get(icon,icon[:1].upper()),font=('Segoe UI',max(11,n-1),'bold'),fill=color)
            c.bind('<Button-1>',lambda e:fn());c.bind('<Enter>',lambda e:self.status.set(tip));return c
        def rebuild_tools(self):
            if not hasattr(self,'toolgroups'):return
            for f in getattr(self,'floats',[]):
                try:f.destroy()
                except tk.TclError:pass
            self.floats=[]
            for parent in (self.topdock,self.leftdock):
                for w in parent.winfo_children():
                    if getattr(w,'tool_family',False):w.destroy()
                parent.bind('<Button-3>',self.category_menu)
            for name,buttons in self.toolgroups.items():
                info=self.layout.get(name,{});where=info.get('dock','top' if name in ('Fichiers','Édition','Traits') else 'left')
                if where=='hidden':continue
                parent=self.topdock if where=='top' else self.leftdock
                if where=='float':
                    parent=tk.Toplevel(self);parent.title(name);parent.configure(bg=self.p['panel']);parent.geometry(f'+{info.get("x",200)}+{info.get("y",200)}');self.floats.append(parent)
                f=tk.Frame(parent,bg=self.p['panel']);f.tool_family=True;f.pack(side='left' if where=='top' else 'top',anchor='nw',padx=2,pady=1)
                handle=self.label(f,'⋮⋮ '+name,font=('Segoe UI',7,'bold'));handle.pack(fill='x');handle.configure(cursor='fleur')
                handle.bind('<ButtonRelease-1>',lambda e,n=name:self.drop_category(e,n));handle.bind('<Button-3>',self.category_menu)
                handle.bind('<B1-Motion>',lambda e:self.status.set('Déplacez près du haut, de la gauche, ou relâchez pour une barre flottante.'))
                grid=tk.Frame(f,bg=self.p['panel']);grid.pack();grid.bind('<Button-3>',self.category_menu)
                count=int(info.get('count',1));columns=math.ceil(len(buttons)/count) if where=='top' else count
                for i,(icon,variants) in enumerate(buttons):
                    selected=self.variants.get(icon,variants[0][0]);chosen=next((v for v in variants if v[0]==selected),variants[0])
                    c=self.small_icon(grid,icon,lambda:None,chosen[1]);c.grid(row=i//columns,column=i%columns,padx=1,pady=1)
                    if chosen[0]!=variants[0][0]:
                        c.create_text(self.p['icon_size']+4,self.p['icon_size']+4,text=str(next(j+1 for j,v in enumerate(variants) if v==chosen)),font=('Segoe UI',7,'bold'),fill=self.p['accent'])
                    state={}
                    def invoke(v=chosen):
                        if v[2]:v[2]()
                        else:self.set_tool(v[0])
                    def popup(vs=variants,key=icon,st=state):
                        st['long']=True;m=self.menu()
                        for v in vs:
                            def choose(v=v):
                                self.variants[key]=v[0];self.persist_preferences()
                                if v[2]:v[2]()
                                else:self.set_tool(v[0])
                                self.after_idle(self.rebuild_tools)
                            m.add_command(label=v[1],command=choose)
                        try:m.tk_popup(self.winfo_pointerx(),self.winfo_pointery())
                        finally:m.grab_release()
                    def press(e,st=state,pop=popup):st['long']=False;st['timer']=self.after(430,pop)
                    def release(e,st=state,call=invoke):
                        if st.get('timer'):self.after_cancel(st['timer'])
                        if not st.get('long'):call()
                    c.bind('<ButtonPress-1>',press);c.bind('<ButtonRelease-1>',release)
                    c.bind('<Button-3>',lambda e,pop=popup:pop())
        def set_category(self,name,**options):self.layout[name]=dict(self.layout.get(name,{}),**options);self.persist_preferences();self.rebuild_tools()
        def update_toggle_labels(self):
            if not isinstance(getattr(self,'bottom_buttons',None),dict):return super().update_toggle_labels()
            for key,var in [('grid',self.grid),('snap',self.snap),('ortho',self.ortho)]:
                __import__('modern_style').tile(self.bottom_buttons[key],'on' if var.get() else None)   # 0.19.0: a switch that is on, on a rounded tile
        def error(self,typ,value,tb):
            # 0.19.9: the whole error kept in Erreurs.log (date, version, traceback; the file cut to its last ~200 KB) and
            # said plainly (« 'Tirets' » alone said nothing); a value Craft refuses (ValueError) keeps its own message.
            # Never raises.
            log=None
            try:
                import time,traceback
                from app_paths import user_data_directory
                from craft_version import VERSION
                log=user_data_directory()/'Erreurs.log';log.parent.mkdir(parents=True,exist_ok=True)
                try:text=log.read_text(encoding='utf-8',errors='replace')
                except FileNotFoundError:text=''
                text+=f'--- {time.strftime("%Y-%m-%d %H:%M:%S")} · Craft {VERSION}\n'+''.join(traceback.format_exception(typ,value,tb))
                if len(text)>200000:
                    text=text[-200000:];cut=text.find('\n--- ');text=text[cut+1:] if cut>=0 else text
                log.write_text(text,encoding='utf-8')
            except Exception:log=None
            try:
                try:said=str(value).strip()
                except Exception:said=''
                name=getattr(typ,'__name__','Exception');refused=isinstance(typ,type) and issubclass(typ,ValueError)
                if refused:message=said or 'Valeur refusée.'
                else:message='Une erreur s’est produite : '+(f'{said} ({name}).' if said else f'{name}.')+(f'\nDétails dans {log}' if log else '')
                self.status.set('Erreur : '+(said or name));messagebox.showerror('Craft',message,parent=self)
            except Exception:pass
        def set_tool(self,t):
            self.status.set('Commande : '+EXTRA.get(t,t))
            if t not in EXTRA:return super().set_tool(t)
            self.cancel();self.tool.set(t);self.mode_label.set(EXTRA[t]);self.last_command=('tool',t);self.extra_points=[];self.extra_item=None
            self.canvas.configure(cursor='crosshair');self.hint.set(EXTRA[t]+' : choisissez les points ou une pièce.')
        def set_hint(self):
            if self.tool.get() in EXTRA:self.hint.set(EXTRA[self.tool.get()]);return
            super().set_hint()
        def cancel(self):
            self.extra_points=[];self.extra_item=None;self.pending_annotation=None
            return super().cancel()
        def motion(self,e):
            if self.tool.get() not in EXTRA:return super().motion(e)
            self.cursor_screen=(e.x,e.y);p=self.point(e);self.pointer_world=p;self.canvas.delete('preview')
            if self.extra_points:
                a=self.extra_points[-1];self.canvas.create_line(*self.to_screen(a),*self.to_screen(p),fill=self.p['accent'],tags='preview',**self.guide_style())
                if self.tool.get()=='measure':self.status.set('Distance : '+self.format_length(math.dist(a,p))+' '+self.units.get())
        def add_items(self,items,command):
            if any(s.get('piece_id') for s in items):
                from entity_rules import fresh_copy_ids
                items=fresh_copy_ids(copy.deepcopy(items))
            if command in ('line','poly','rect','rect_center','rect_round','rect_rot','para','circle_radius','circle_diameter','circle_2p','circle_3p','spline_fit','arc_3p','arc_radius','arc_center','ellipse_center','ellipse_box','ellipse_axis'):
                for item in items:
                    item['style']=dict(style(item),color=getattr(self,'drawing_color','auto'))
            self.snapshot();self.items.extend(items);self.selected=len(self.items)-1
            self.complete_command(command);self.refresh()
        def down(self,e):
            t=self.tool.get()
            if t not in EXTRA:return super().down(e)
            self.canvas.focus_set();p=self.point(e);points=self.extra_points
            try:
                if t in ('part_name','material'):
                    if self.pending_annotation:
                        self.add_items([annotation(self.pending_annotation,p)],t);self.pending_annotation=None
                    else:
                        i=self.pick(p)
                        if i is None:raise ValueError('Cliquez le contour de la pièce à identifier.')
                        self.selected=i;self.identify_dialog(t)
                    return
                if t in ('measure','dimension'):
                    points.append(p)
                    if len(points)==2 and t=='measure':
                        a,b=__import__('craft_tools').measure_points(*points,self.ortho.get());value=self.format_length(math.dist(a,b));self.complete_command(t);self.redraw();self.status.set('Mesure : '+value+' '+self.units.get());return
                    if len(points)==3:
                        text=self.format_length(math.dist(points[0],points[1]))+' '+self.units.get()
                        self.add_items(dimensions(*points,text),t);return
                elif t=='radius':
                    if self.extra_item is None:
                        i=self.pick(p)
                        if i is None:raise ValueError('Choisissez un cercle ou un rectangle arrondi.')
                        s=self.items[i];r=s['w']/2 if s['kind']=='circle' else s.get('r',0)
                        if r<=0:raise ValueError('Le rayon n’est pas défini pour ce tracé.')
                        self.extra_item=(p,r)
                    else:
                        a,r=self.extra_item;self.add_items([shape('line','Repère rayon',*a,p[0]-a[0],p[1]-a[1]),cote_label('R '+self.format_length(r)+' '+self.units.get(),p,math.degrees(math.atan2(p[1]-a[1],p[0]-a[0])))],t)
                else:
                    if self.extra_item is None:
                        i=self.pick(p)
                        if i is None:raise ValueError('Cliquez le bord d’une pièce.')
                        self.extra_item=i;self.selected=i
                        if t=='notch':
                            self.snapshot();self.items[i].setdefault('notches',[]).append(dict(distance=locate(self.items[i],p)[0],depth=3))
                            self.complete_command(t);self.refresh();return
                        if t=='copy_notch':self.extra_points=[p];self.status.set('Choisissez le départ correspondant sur le contour cible.');return
                        if t in ('offset_all','offset_edge'):
                            d=simpledialog.askfloat('Décalage','Distance signée en '+self.units.get(),parent=self)
                            if d is None:self.cancel();return
                            q=offset(self.items[i],self.to_mm(str(d)),p,t=='offset_edge');self.add_items([q],t);return
                        self.extra_points=[];self.status.set('Choisissez le point d’ancrage A.' if t=='move_anchor' else 'Choisissez le début A de la portion.');return
                    i=self.extra_item
                    if t=='copy_notch':
                        j=self.pick(p)
                        if j is None or j==i:raise ValueError('Choisissez une autre pièce cible.')
                        reverse=messagebox.askyesno('Sens des crans','Inverser le sens de parcours sur la pièce cible ?',parent=self)
                        copied=copy_notches(self.items[i],self.items[j],self.extra_points[0],p,reverse)
                        self.snapshot();self.items[j].setdefault('notches',[]).extend(copied);self.complete_command(t);self.refresh();return
                    points.append(p)
                    if len(points)==2:
                        if t=='move_anchor':
                            a,b=points;self.snapshot();group=self.items[i].get('dimension_group')
                            targets=[s for s in self.items if s.get('dimension_group')==group] if group else [self.items[i]]
                            for s in targets:s['x']+=b[0]-a[0];s['y']+=b[1]-a[1]
                            self.complete_command(t);self.refresh()
                        else:
                            d=simpledialog.askfloat('Décalage de portion','Distance signée en '+self.units.get(),parent=self)
                            if d is not None:self.add_items([offset(portion(self.items[i],*points),self.to_mm(str(d)))],t)
                            else:self.cancel()
            except (ValueError,IndexError) as exc:self.status.set(str(exc));messagebox.showerror('Commande',str(exc),parent=self)
        def up(self,e):
            if self.tool.get() in EXTRA:return
            super().up(e)
        def pick(self,p):
            for i,s in reversed(list(enumerate(self.items))):
                if s.get('annotation'):
                    x,y,X,Y=bounds([s])
                    if x<=p[0]<=X and y<=p[1]<=Y:return i
            return super().pick(p)
        def finish_poly(self,closed):
            before=len(self.items);super().finish_poly(closed)
            if len(self.items)>before:
                self.items[-1]['profile']=self.active_profile;self.items[-1]['style']=dict(copy.deepcopy(self.profiles[self.active_profile]),color=getattr(self,'drawing_color','auto'));self.refresh()
        def apply(self):
            if self.selected is None:return
            old=copy.deepcopy(self.items[self.selected]);history=(list(self.undo_stack),list(self.redo_stack),self.last_command);super().apply()
            if self.selected is not None:
                for k,v in old.items():
                    if k not in ('kind','name','x','y','w','h','r','points','closed'):self.items[self.selected][k]=v
                if any(m['distance']>perimeter(self.items[self.selected]) for m in self.items[self.selected].get('notches',[])):
                    # 0.19.9: the piece as it was, Annuler / Rétablir as they were (undo() put the refused piece on
                    # Rétablir: Ctrl+Y applied it anyway, and the earlier Rétablir history was lost)
                    self.items[self.selected]=old;self.undo_stack,self.redo_stack,self.last_command=history;self.sync_fields();self.refresh()
                    raise ValueError('La nouvelle pièce est trop courte pour ses crans. Modification annulée.')
                self.refresh()
        def line_px(self):return float(self.prefs.get('line_px',1.8))
        def guide_style(self):
            """0.16.29: one dotted style for every guide (Symétrie axis, grips, Déplacer, Ajuster,
            Règle…): the same thickness and spacing as the Décaler preview."""
            return dict(width=self.line_px(),stipple='gray50')
        def draw_shape(self,s,color,width,tags=()):
            st=style(s);selected=self.selected is not None and self.selected<len(self.items) and self.items[self.selected] is s
            color=self.p['accent'] if 'hover' in tags else self.p['ink'] if st['color']=='auto' else st['color']
            # 0.16.20: same on-screen thickness at every zoom and for every shape (exports keep their widths).
            # 0.17.0: dimensions are thinner than the pattern lines, so a dimension line parallel to
            # a side stays distinct when zoomed out.
            stroke=self.line_px()*(.6 if s.get('dimension_group') else 1)
            if s.get('annotation'):
                off=s.get('text_offset',[0,0]);centered='text_offset' in s
                self.canvas.create_text(*self.to_screen((s['x']+off[0],s['y']+off[1])),text=s['label'],anchor='center' if centered else 'nw',angle=-s.get('text_angle',0),fill=color,font=('Segoe UI',-max(1,round(s.get('text_height',3)*self.scale))),tags=zoom_tag(tags,'t',s.get('text_height',3)))
            else:
                super().draw_shape(s,color,stroke,tags)
                if st['dash']:
                    # Most recently drawn contour can include anchor handles; use a dedicated path.
                    pts,closed=path(s)
                    if closed:pts+=pts[:1]
                    self.canvas.create_line(*[v for p in pts for v in self.to_screen(p)],fill=self.p['canvas'],width=stroke+1,tags=tags)
                    self.canvas.create_line(*[v for p in pts for v in self.to_screen(p)],fill=color,width=stroke,dash=dash_px(st['dash'],self.scale),tags=zoom_tag(tags,'d',st['dash']))
                for mark in notch_shapes(s):super().draw_shape(mark,color,1.8,tags or ('marks',))
        def commit_current(self,p):
            with self.held_redraw():return self.commit_styled(p)
        def commit_styled(self,p):
            before=len(self.items);super().commit_current(p)
            if len(self.items)>before:self.items[-1]['profile']=self.active_profile;self.items[-1]['style']=dict(copy.deepcopy(self.profiles[self.active_profile]),color=getattr(self,'drawing_color','auto'));self.refresh()
        def apply_profile(self,name):
            if name not in self.profiles:return
            self.active_profile=name
            if hasattr(self,'profile_var'):self.profile_var.set(name)
            if self.selected is not None:
                self.snapshot();s=self.items[self.selected];s['profile']=name;s['style']=copy.deepcopy(self.profiles[name]);self.refresh()
        def edit_profile(self):
            win=self.dialog('Profil de ligne');vars={}
            initial=self.profiles[self.active_profile]
            for key,label,value in [('name','Nom',self.active_profile),('width','Épaisseur en mm',initial['width']),('dash','Tirets / espaces en mm (vide = continu)',' '.join(map(str,initial['dash']))),('color','Couleur : auto ou #RRGGBB',initial['color'])]:
                self.label(win,label).pack(anchor='w',padx=15,pady=3);vars[key]=tk.StringVar(value=str(value));self.entry(win,vars[key],30).pack(padx=15,pady=3)
            def save():
                try:
                    name=vars['name'].get().strip();width=float(vars['width'].get().replace(',','.'));dash=[float(x) for x in vars['dash'].get().split()];color=vars['color'].get()
                    import re
                    if not name or not .01<=width<=5 or any(not .05<=d<=100 for d in dash) or len(dash)%2:raise ValueError('Nom, épaisseur ou motif invalide (paires tiret / espace).')
                    if color!='auto' and not re.fullmatch(r'#[0-9a-fA-F]{6}',color):raise ValueError('Couleur invalide.')
                    self.profiles[name]=dict(color=color,width=width,dash=dash,role=initial.get('role','drawing'))
                    self.profile_box.configure(values=list(self.profiles));self.apply_profile(name);self.persist_preferences();win.destroy()
                except ValueError as exc:messagebox.showerror('Profil',str(exc),parent=win)
            self.button(win,'Valider',save).pack(padx=15,pady=12,anchor='e')
        def identify_dialog(self,kind):
            win=self.dialog('Nom de pièce' if kind=='part_name' else 'Matière');fields=[]
            model=tk.StringVar(value=self.project_model or (Path(self.filename).stem if self.filename else 'Modèle'))
            if kind=='part_name':self.label(win,'Modèle (modifiable)').pack(padx=15,pady=5);self.entry(win,model,35).pack(padx=15,pady=5)
            pools=self.archives['names'] if kind=='part_name' else [self.archives['materials']]
            for i,pool in enumerate(pools):
                self.label(win,('Partie '+str(i+1)) if kind=='part_name' else 'Matière').pack(padx=15,pady=3)
                var=tk.StringVar();box=ttk.Combobox(win,textvariable=var,values=pool,state='readonly',width=35);box.pack(padx=15,pady=3);fields.append(var)
                self.button(win,'Archives…',lambda p=pool,b=box:self.edit_archive(p,win,lambda v:b.configure(values=v))).pack(padx=15,pady=3,anchor='w')
            def valid():
                values=[v.get().strip() for v in fields if v.get().strip()]
                if not values:messagebox.showinfo('Identification','Choisissez au moins une indication.',parent=win);return
                self.snapshot();item=self.items[self.selected]
                if kind=='part_name':
                    self.project_model=model.get().strip();item['part_names']=values;item['model']=self.project_model
                    text=' / '.join([self.project_model]+values)
                else:item['material']=values[0];text=values[0]
                win.destroy();self.pending_annotation=text;self.hint.set('Cliquez où placer les indications.');self.refresh();self.canvas.focus_set()
            self.button(win,'Valider',valid).pack(padx=15,pady=12,anchor='e')
    return Craft
