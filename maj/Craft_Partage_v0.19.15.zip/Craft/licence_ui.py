"""Licence dans l'interface de Craft : Aide > Activer une licence…, titre, export.

Édition personnelle (sans licence_cle) : rien n'est ajouté, aucun fichier écrit.
Le travail n'est jamais bloqué : ouvrir, dessiner et enregistrer restent
toujours possibles ; seul l'export PDF/DXF/SVG/DWG demande une licence ou un
essai en cours.
"""
import tkinter as tk
from tkinter import filedialog, messagebox

import licence

LIBELLE_MENU = 'Activer une licence…'


def _menu_aide(app):
    try:
        barre = app.nametowidget(app.cget('menu'))
    except (KeyError, tk.TclError):
        return None
    for i in range((barre.index('end') or 0) + 1):
        if barre.type(i) == 'cascade' and barre.entrycget(i, 'label') == 'Aide':
            return app.nametowidget(barre.entrycget(i, 'menu'))
    return None


def ajouter_menu(app):
    """Ajoute l'entrée juste avant la ligne « Version » (qui reste la dernière). Idempotent."""
    if not licence.commerciale():
        return False
    menu = _menu_aide(app)
    if menu is None:
        return False
    fin = menu.index('end')
    fin = -1 if fin is None else fin
    for i in range(fin + 1):
        if menu.type(i) == 'command' and menu.entrycget(i, 'label') == LIBELLE_MENU:
            return True
    position = fin + 1
    for i in range(fin + 1):
        if menu.type(i) == 'command' and menu.entrycget(i, 'label').startswith('Version '):
            position = i - 1 if i > 0 and menu.type(i - 1) == 'separator' else i
            break
    menu.insert_command(position, label=LIBELLE_MENU, command=lambda: ouvrir(app))
    return True


def ouvrir(app):
    garde = app.__dict__.get('_licence')
    if garde is not None:
        garde.dialogue()


class Garde:
    """État de licence d'une fenêtre Craft : titre, rappels, autorisation d'export."""

    def __init__(self, app):
        self.app = app
        self.fenetre = None
        self.etat = licence.etat_actuel()
        self.appliquer()
        self._minuterie = app.after(3600 * 1000, self.verifier)
        if not self.etat['export']:
            app.after(800, self.dialogue)
        elif self.etat['mode'] == 'grace' or (self.etat['jours'] is not None and self.etat['jours'] <= 7):
            app.after(800, lambda: self._statut(self.etat['message']))

    def _statut(self, texte):
        variable = self.app.__dict__.get('status')
        if variable is not None:
            try:
                variable.set(texte)
            except tk.TclError:
                pass

    def appliquer(self):
        etat = self.etat
        self.app.license_customer = etat['client'] if etat['mode'] in ('licence', 'grace', 'expiree') else None
        self.app.licence_label = etat['titre']
        mettre_a_jour = getattr(self.app, 'update_window_title', None)
        if callable(mettre_a_jour):
            mettre_a_jour()

    def verifier(self):
        try:
            if not self.app.winfo_exists():
                return
        except tk.TclError:
            return
        self.etat = licence.etat_actuel()
        self.appliquer()
        self._minuterie = self.app.after(3600 * 1000, self.verifier)

    def export_autorise(self):
        self.etat = licence.etat_actuel()
        self.appliquer()
        if self.etat['export']:
            return True
        if messagebox.askyesno('Licence nécessaire', self.etat['message'] + '\n\nActiver une licence maintenant ?', parent=self.app):
            self.dialogue()
        return False

    def dialogue(self):
        if self.fenetre is not None:
            try:
                if self.fenetre.window.winfo_exists():
                    self.fenetre.window.lift()
                    self.fenetre.window.focus_set()
                    return self.fenetre
            except tk.TclError:
                pass
        self.fenetre = Dialogue(self)
        return self.fenetre


class Dialogue:
    def __init__(self, garde):
        self.garde = garde
        app = garde.app
        w = self.window = tk.Toplevel(app)
        w.title('Licence Craft')
        w.resizable(False, False)
        w.transient(app)
        cadre = tk.Frame(w, padx=18, pady=14)
        cadre.pack(fill='both')
        tk.Label(cadre, text='Licence Craft', font=('Segoe UI', 13, 'bold')).pack(anchor='w')
        self.etat = tk.StringVar(value=garde.etat['message'])
        tk.Label(cadre, textvariable=self.etat, wraplength=440, justify='left', font=('Segoe UI', 10)).pack(anchor='w', pady=(6, 10))
        tk.Label(cadre, text='Collez ici la clé reçue par e-mail :', font=('Segoe UI', 10)).pack(anchor='w')
        self.texte = tk.Text(cadre, width=58, height=5, wrap='char', font=('Consolas', 9))
        self.texte.pack(fill='x', pady=(4, 6))
        self.retour = tk.Label(cadre, text='', wraplength=440, justify='left', font=('Segoe UI', 10))
        self.retour.pack(anchor='w', pady=(0, 8))
        boutons = tk.Frame(cadre)
        boutons.pack(fill='x')
        tk.Button(boutons, text='Coller', command=self.coller, padx=8).pack(side='left')
        tk.Button(boutons, text='Ouvrir un fichier…', command=self.fichier, padx=8).pack(side='left', padx=6)
        tk.Button(boutons, text='Fermer', command=w.destroy, padx=10).pack(side='right')
        self.bouton = tk.Button(boutons, text='Activer', command=self.activer, padx=14, default='active')
        self.bouton.pack(side='right', padx=6)
        w.bind('<Escape>', lambda e: w.destroy())
        w.bind('<Control-Return>', lambda e: self.activer())
        self.texte.focus_set()

    def coller(self):
        try:
            contenu = self.window.clipboard_get()
        except tk.TclError:
            contenu = ''
        if contenu:
            self.texte.delete('1.0', 'end')
            self.texte.insert('1.0', contenu.strip())

    def fichier(self):
        chemin = filedialog.askopenfilename(parent=self.window, title='Fichier de licence',
                                            filetypes=[('Licence Craft (*.craftlicence, *.txt)', '*.craftlicence *.txt'), ('Tous les fichiers (*.*)', '*.*')])
        if not chemin:
            return
        try:
            with open(chemin, 'r', encoding='utf-8', errors='replace') as flux:
                contenu = flux.read(20000)
        except OSError:
            self._message('Fichier illisible.', False)
            return
        self.texte.delete('1.0', 'end')
        self.texte.insert('1.0', contenu.strip())

    def _message(self, texte, succes):
        # 0.19.0 : couleurs lisibles sur le fond de la fenêtre (sombre avec l'interface moderne).
        try:
            r, g, b = (v / 257 for v in self.retour.winfo_rgb(self.retour.cget('bg')))
            sombre = 0.299 * r + 0.587 * g + 0.114 * b < 128
        except tk.TclError:
            sombre = False
        if sombre:
            couleur = '#4fbf6a' if succes else '#ff7b72'
        else:
            couleur = '#1f6b45' if succes else '#a3271f'
        self.retour.configure(text=texte, fg=couleur)

    def activer(self):
        try:
            etat = licence.activer(self.texte.get('1.0', 'end'))
        except licence.LicenceInvalide as exc:
            self._message(str(exc), False)
            return False
        except OSError:
            self._message('Impossible d’enregistrer la licence sur ce poste.', False)
            return False
        self.garde.etat = etat
        self.garde.appliquer()
        self.etat.set(etat['message'])
        self._message('Licence activée. Merci pour votre confiance !', True)
        return True


def install(app):
    """À appeler une fois la fenêtre construite. Renvoie la garde, ou None (édition personnelle)."""
    if not licence.commerciale():
        app.licence_label = None
        return None
    garde = Garde(app)
    app._licence = garde
    ajouter_menu(app)
    return garde
