"""Single source of truth for source packages and Windows builds."""
VERSION='0.19.29'
APP_ID='Craft.LeatherCAD.Desktop'
