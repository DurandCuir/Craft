"""0.19.13 Contrôle d'assemblage (« assemblages en 2D », 07/11: « tu calcules par rapport à l'épaisseur qu'aura sur
les assemblages la personne, mais ça il faudrait savoir quelle pièce va où et sur quoi »).

A click on the edge of a piece takes its side (between two corners, as the stitches cut a line: a smooth round
piece is one side); Maj + click adds the next side. A click on another piece takes the edge sewn on it (Maj + click:
its next side too). The window says both lengths and their difference, the crans in front of each other (the edges
taken in the direction that puts the most crans in front), the thickness at the seam (the refentes of both pieces,
1 mm when a piece has none; it can be typed), the points of the seam (points per cm of the Piqûre) and the thread
of a lock stitch: at each point, the length of the point and the thickness, for each of the two threads, without
margin. « Écrire sur le plan » leaves it written by the first edge; Entrée starts a new check; Échap ends.

0.19.14: the bag is sewn with the pieces surcoupées, not their précoupe (« ça va être avec les surcoupes que le sac sera
assemblé »): a click on a précoupe takes the side of its piece inside. The thickness at the seam follows the parage
of the edge: biseau, the middle of the bevel (« ça tombe au milieu du biseau »: between the edge and the leather);
rembord, the flap pared and folded on the leather itself (his way: leather + pared), or pared over twice its width
(2 × pared, to tick); another parage, its thickness; the renforts and doublures of the piece (by their names: RENFORT
FACE, DBL FACE…) are offered to tick.

0.19.24 (proposed on 13/11, « Fais les pistes aussi »: « le Contrôle d'assemblage de tout le sac d'un coup »): each check
done is kept with the model (its two edges: the pieces and their sides; Infos du modèle « assemblages », the .crft keeps
them, Annuler does not take them away); « Contrôle d'assemblage du sac… » (Exporter, « Tout le sac… » in the check's
window, typed « assemblage du sac ») checks them all again at once: lengths, écart, crans in front of each other, in a
list and on the plan (green: good; red: an écart over 0,5 mm; orange: crans not all in front; grey: a piece gone or its
sides changed, to check again). A double click opens the check of that pair; « Retirer de la liste ».

0.19.25 (« Go tes propositions et améliore toujours »): « Paires probables… » proposes the edges of two pieces of about
the same length with their crans in front of each other, to tick (proposals); the fiche « Assemblages » (fiches.py)
prints the pairs kept with their numbers, points and thread.

0.19.26 (« Go propositions c bien »): the edges measured at their seam (« En règle générale on pique toujours à 2,5mm.
Pour un Jonc comme sur difforme c’est 5mm »): 2,5 mm from the edge, a jonc's 5 mm kept with its pair
(Seam: the edge moved in, its round corners shorter); « Crans en face » adds on edge 2 the crans missing in front of
edge 1's; the bag's list is the order of montage (Monter / Descendre, numbered on the plan and on the fiche « Montage »),
with the steps between the seams (« il y a les étapes inter à prendre en compte »: typed, or proposed from the pieces:
parage, renfort, surcoupe, rembordé, teinture, jonc)."""
import bisect
import math
import tkinter as tk

COLORS = ('#ff9f1c', '#2ec4b6')
TOLERANCE = 1.   # mm: a cran in front of another one


def _pieces(app, every=False):
    """The edges that are sewn: the pieces (Coupe extérieure) but not the précoupes, and the pieces inside them.
    0.19.24 ``every``: also those of a layer hidden (the pairs kept)."""
    from entity_rules import closed_piece
    from craft_tools import style
    import surcoupe
    out = []
    hidden = __import__('preparation_ui').hidden_ids(app) if hasattr(app, 'prefs') and not every else set()   # 0.19.14: layers hidden
    for k, s in enumerate(app.items):
        if not closed_piece(s) or s.get('annotation') or k in hidden:
            continue
        role = style(s)['role']
        if role == 'external' and not surcoupe.is_precut(s) or role == surcoupe.ROLE and s.get('owner_id'):
            out.append(k)
    return out


def _precuts(app):
    import surcoupe
    hidden = __import__('preparation_ui').hidden_ids(app)   # 0.19.14: a hidden précoupe is not clicked
    return [k for k, s in enumerate(app.items) if surcoupe.is_precut(s) and k not in hidden]


def host(app, k):
    """The piece that carries the data of ``k`` (its précoupe for a piece inside one)."""
    s = app.items[k]
    if s.get('piece_id') or not s.get('owner_id'):
        return s
    return next((q for q in app.items if q.get('piece_id') == s['owner_id']), s)


_CACHE = {}


def sides(piece):
    """[(points, start distance along the contour, length)] between the corners, and the contour's length (kept for
    the same piece: the mouse moves over them)."""
    hit = _CACHE.get(id(piece))
    if hit is not None and hit[0] is piece:
        return hit[1]
    import stitching
    from geometry import path
    from craft_tools import locate
    pts, closed = path(piece)
    out = []
    for run in stitching._runs(pts, closed):
        length = sum(math.dist(a, b) for a, b in zip(run, run[1:]))
        if length > 1e-6:
            out.append((run, locate(piece, run[0])[0], length))
    value = (out, sum(r[2] for r in out))
    if len(_CACHE) > 500:
        _CACHE.clear()
    _CACHE[id(piece)] = (piece, value)
    return value


def _gap(p, run):
    best = 1e18
    for a, b in zip(run, run[1:]):
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = dx * dx + dy * dy
        t = 0 if L == 0 else max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L))
        best = min(best, math.dist(p, (a[0] + t * dx, a[1] + t * dy)))
    return best


def side_at(app, p, reach):
    """(piece index, side index) of the side nearest ``p`` within ``reach`` mm, or None. 0.19.14: on a précoupe, the
    nearest side of the piece inside it."""
    from geometry import bounds
    best = None
    for k in _pieces(app):
        s = app.items[k]
        x, y, X, Y = bounds([s])
        if not (x - reach <= p[0] <= X + reach and y - reach <= p[1] <= Y + reach):
            continue
        for i, (run, start, length) in enumerate(sides(s)[0]):
            d = _gap(p, run)
            if d <= reach and (best is None or d < best[0]):
                best = (d, k, i)
    if best:
        return best[1:]
    import surcoupe
    shown = set(_pieces(app))
    for k in _precuts(app):
        s = app.items[k]
        x, y, X, Y = bounds([s])
        if not (x - reach <= p[0] <= X + reach and y - reach <= p[1] <= Y + reach):
            continue
        if min(_gap(p, run) for run, _, _ in sides(s)[0]) > reach:
            continue
        for j in surcoupe.inner_contours(app.items, k):
            if j not in shown:
                continue
            for i, (run, start, length) in enumerate(sides(app.items[j])[0]):
                d = _gap(p, run)
                if best is None or d < best[0]:
                    best = (d, j, i)
    return best[1:] if best else None


def portion(app, chosen):
    """(points, start, length, total) of the sides ``chosen`` = (piece, [side indices]) taken in the contour's order."""
    k, ids = chosen
    runs, total = sides(app.items[k])
    ids = sorted(ids)
    # contiguous through the end of the contour (the last side then the first ones)
    n = len(runs)
    if len(ids) > 1 and ids[0] == 0 and ids[-1] == n - 1:
        cut = next(i for i in range(1, len(ids)) if ids[i] != ids[i - 1] + 1) if any(ids[i] != ids[i - 1] + 1 for i in range(1, len(ids))) else len(ids)
        ids = ids[cut:] + ids[:cut]
    pts, length = [], 0.
    for i in ids:
        pts += runs[i][0] if not pts else runs[i][0][1:]
        length += runs[i][2]
    return pts, runs[ids[0]][1], length, total


def in_one_run(app, k, ids):
    """0.19.22: the sides ``ids`` of piece ``k`` follow one another (one edge, round the closing corner too)."""
    n = len(sides(app.items[k])[0])
    taken = set(ids)
    return len(taken) == n or sum((j + 1) % n not in taken for j in taken) == 1


def adjacent(app, chosen, i):
    k, ids = chosen
    n = len(sides(app.items[k])[0])
    return any((i - j) % n in (1, n - 1) for j in ids)


_MARKS = {}
_MISSING = object()


def _cran_distance(cran, piece, piece_key):
    """Where the cran sits along the contour of ``piece`` (craft_tools.cran_mark), None when it is not on it; kept by
    their geometry (0.19.26: the bag's list read each piece's crans again for each of its edges, each time)."""
    from craft_tools import cran_mark
    from geometry import geometry_key
    key = (geometry_key(cran), piece_key)
    hit = _MARKS.get(key, _MISSING)
    if hit is _MISSING:
        mark = cran_mark(cran, piece)
        hit = None if mark is None else mark['distance']
        if len(_MARKS) > 20000:
            _MARKS.clear()
        _MARKS[key] = hit
    return hit


def crans(app, k, start, length, total):
    """The crans of piece ``k`` on the portion: their distances from its start (0.19.14: a piece inside a précoupe, the
    crans of its précoupe on its contour)."""
    from geometry import geometry_key
    piece = app.items[k]
    owner = piece.get('piece_id') or piece.get('owner_id')
    out = []
    piece_key = None
    for s in app.items:
        if s.get('is_notch') and s.get('owner_id') and s.get('owner_id') == owner:
            if piece_key is None:
                piece_key = geometry_key(piece)
            at = _cran_distance(s, piece, piece_key)
            if at is not None:
                d = (at - start) % total if total else 0.
                if d <= length + .05:
                    out.append(min(d, length))
    return sorted(out)


def facing_counts(a, la, b, lb):
    """(crans of a in front of b's, the same with b the other way round)"""
    def count(bs):
        left, n = list(bs), 0
        for x in a:
            hit = next((y for y in left if abs(x - y) <= TOLERANCE), None)
            if hit is not None:
                left.remove(hit)
                n += 1
        return n
    return count(b), count([lb - y for y in b])


def facing(a, la, b, lb):
    """(crans in front of each other, b reversed or not): the direction that puts the most of them in front."""
    same, back = facing_counts(a, la, b, lb)
    return (back, True) if back > same else (same, False)


# --- 0.19.26 the seam (« En règle générale on pique toujours à 2,5mm. Pour un Jonc comme sur difforme c’est 5mm ») ------

JONC = 5.   # mm from the edges: a seam with a jonc
SEAM = 2.5   # mm: « En règle générale on pique toujours à 2,5mm »


def default_seam(app):
    """The distance of a seam from the edges: 2,5 mm (review: never the last distance typed in the Piqûre tool, which
    keeps it, 0 too: every pair kept followed it)."""
    return SEAM


def seam_of(app, value):
    """A pair's seam: its own (a jonc: 5 mm) or 2,5 mm."""
    if value is None:
        return default_seam(app)
    try:
        d = float(value)
    except (TypeError, ValueError):
        return default_seam(app)
    return min(30., max(0., d)) if math.isfinite(d) else default_seam(app)


def seam_text(d):
    return _mm(d, 1) + (' jonc' if abs(d - JONC) < 1e-9 else '')


def seam_words(d):
    return f'à {_mm(d, 1)} mm du bord' + (', jonc' if abs(d - JONC) < 1e-9 else '')


class Seam:
    """0.19.26: an edge (its points in the contour's order) at its seam, ``d`` mm inside its piece (``inside``: 1 when the
    inside is on the left of the points): each straight part moved in, the moved parts meeting at their corners (a round
    corner of radius R: d × its angle shorter; a part that vanishes, as a round corner smaller than d, goes and its
    neighbours meet), the ends square to the edge. ``length``; ``at(x)``: where the point ``x`` mm along the edge (a
    cran) falls on the seam, in mm from its start; ``point(y)`` the point ``y`` mm along the seam, ``back(y)`` the
    point of the edge in front of it."""

    MITER = 4.   # a corner turning away from the inside: the seam meets at most this many times d from it, else cut square

    def __init__(self, pts, d, inside, _open=False):
        self.ring = None
        if not _open and len(pts) > 3 and math.dist(pts[0], pts[-1]) < 1e-6:   # the whole contour: its closing corner too
            lengths = [math.dist(a, b) for a, b in zip(pts, pts[1:])]
            total = sum(lengths)
            if total > 1e-9:   # (a seam round it: started in the middle of its longest part, where it has no corner)
                i = max(range(len(lengths)), key=lengths.__getitem__)
                a, b = pts[i], pts[i + 1]
                mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
                rot = Seam([mid] + list(pts[i + 1:]) + list(pts[1:i + 1]) + [mid], d, inside, True)
                s_mid = sum(lengths[:i]) + lengths[i] / 2
                self.ring = (rot, s_mid, total, rot.at((total - s_mid) % total))
                self.points, self.length, self.cut, self.samples, self.corners = rot.points, rot.length, total, rot.samples, {}
                return
        segs, travel = [], 0.
        for a, b in zip(pts, pts[1:]):
            L = math.dist(a, b)
            if L < 1e-9:
                continue
            u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
            n = (-u[1] * inside * d, u[0] * inside * d)
            segs.append(((a[0] + n[0], a[1] + n[1]), u, n, travel, L, a))
            travel += L
        self.segs, self.cut, self.travels, self.samples, self.corners = segs, travel, [q[3] for q in segs], None, {}
        if not segs:
            self.points, self.starts, self.order, self.length = list(pts[:1]) or [(0., 0.)], [0.], [], 0.
            return
        if not self._parts(d, inside):   # (an edge too tangled for its parts' meeting points: a spike, a slit)
            self._sampled(d, inside)

    def _parts(self, d, inside):
        """The seam from the moved parts and their meeting points; False when a meeting point is not one of the seam (a
        part met far from where it is: a spike's two sides nearly in line)."""
        segs = self.segs
        near = 1e-6 * max(1., d)

        def along(i, m):   # where m falls along part i, from the start of its moved line
            q, u = segs[i][:2]
            return (m[0] - q[0]) * u[0] + (m[1] - q[1]) * u[1]
        kept = [[0, segs[0][0], None]]   # [part, where its seam starts, 'chord' round a slit's end / 'inside' corner]
        for j in range(1, len(segs)):
            q, v, _, _, Lj, aj = segs[j]
            i = kept[-1][0]
            u = segs[i][1]
            cross = u[0] * v[1] - u[1] * v[0]
            if j == i + 1 and cross * inside < 0:   # a corner turning away from the inside: both parts go on to meet
                b = segs[i]
                m = self._meet(i, j) if abs(cross) > 1e-9 else None
                if m is not None and along(i, m) >= b[4] - near and along(j, m) <= near and math.dist(m, aj) <= self.MITER * d:
                    kept.append([j, m, 'inside'])
                else:   # (a slit: the seam cut square round its end)
                    kept += [[j, (b[5][0] + b[1][0] * b[4] + b[2][0], b[5][1] + b[1][1] * b[4] + b[2][1]), 'chord'], [j, q, None]]
                continue
            gone = False   # parts kept before j vanished
            while True:
                i, s, _ = kept[-1]
                m = self._meet(i, j)
                if along(i, m) <= along(i, s) + 1e-9:
                    if len(kept) > 1:
                        kept.pop()   # this part vanishes between its neighbours
                        if len(kept) > 1 and kept[-1][0] == i and kept[-1][2] == 'chord':
                            kept.pop()   # (second review: with the chord round the slit before it)
                        gone = True
                        continue
                    t = along(j, s)   # (the first part vanishes: the seam starts on part j, in front of its start)
                    if not -near <= t <= Lj + near:
                        return False
                    kept[0], m = [j, (q[0] + v[0] * t, q[1] + v[1] * t), None], None
                elif along(j, m) >= Lj - 1e-9:
                    m = None   # part j vanishes behind part i
                break
            if m is None:
                continue
            if (gone or j != i + 1) and not (-near <= along(j, m) and along(i, m) <= segs[i][4] + near):
                return False   # met beyond the parts themselves
            kept.append([j, m, None])
        last = segs[-1]
        end = (last[5][0] + last[1][0] * last[4] + last[2][0], last[5][1] + last[1][1] * last[4] + last[2][1])
        i, s, _ = kept[-1]
        if i != len(segs) - 1:   # the last part vanished: the seam ends on the last one kept, in front of the edge's end
            t = along(i, end)
            if not along(i, s) - near <= t <= segs[i][4] + near:
                return False
            q, u = segs[i][:2]
            end = (q[0] + u[0] * t, q[1] + u[1] * t)
        self.order = [i for i, _, _ in kept]
        self.points = [s for _, s, _ in kept] + [end]
        self.starts = [0.]
        for a, b in zip(self.points, self.points[1:]):
            self.starts.append(self.starts[-1] + math.dist(a, b))
        self.length = self.starts[-1]
        # (second review) a cran on an inside corner: where the two seams meet there
        self.corners = {j: self.starts[k] for k, (j, _, kind) in enumerate(kept) if kind == 'inside'}
        return self._clear(d, {k for k, e in enumerate(kept) if e[2] == 'chord'})

    def _grid(self, d, cell):
        """The edge's parts by the squares of ``cell`` mm they come within d of (along each part: second review, a long
        slanting part filled its whole box, a second for a 1,2 m strap at 0,5 mm)."""
        grid, floor = {}, math.floor
        for k, (_, u, _, _, L, a) in enumerate(self.segs):
            if L <= 2 * cell:   # (a short part: its box)
                b = (a[0] + u[0] * L, a[1] + u[1] * L)
                boxes = [(min(a[0], b[0]) - d, min(a[1], b[1]) - d, max(a[0], b[0]) + d, max(a[1], b[1]) + d)]
            else:   # (a long one: the boxes round its points every cell, each d + cell / 2 wide)
                r = d + cell / 2
                boxes = [(a[0] + u[0] * t - r, a[1] + u[1] * t - r, a[0] + u[0] * t + r, a[1] + u[1] * t + r)
                         for t in (min(n * cell, L) for n in range(int(L // cell) + 2))]
            for x0, y0, x1, y1 in boxes:
                for gx in range(floor(x0 / cell), floor(x1 / cell) + 1):
                    for gy in range(floor(y0 / cell), floor(y1 / cell) + 1):
                        cell_parts = grid.setdefault((gx, gy), [])
                        if not cell_parts or cell_parts[-1] != k:
                            cell_parts.append(k)
        return grid

    def _clear(self, d, chords):
        """Every point of the seam (each meeting point, and every 2 d along a long part) d at least from every part of the
        edge, else False (the edge tangled: a spike narrower than the seam); ``chords``: parts cut square round a slit
        (nearer: as they should be)."""
        cell, limit = max(2. * d, 1.), (d - 1e-6 * max(1., d)) ** 2
        grid = self._grid(d, cell)
        parts = [(q[5][0], q[5][1], q[1][0], q[1][1], q[4]) for q in self.segs]
        floor = math.floor

        def far(x, y, own):
            for o in grid.get((floor(x / cell), floor(y / cell)), ()):
                if o != own:
                    ax, ay, ux, uy, L = parts[o]
                    t = (x - ax) * ux + (y - ay) * uy
                    t = 0. if t < 0. else L if t > L else t
                    dx, dy = x - ax - ux * t, y - ay - uy * t
                    if dx * dx + dy * dy < limit:
                        return False
            return True
        pts, order, step = self.points, self.order, 2. * d
        for k, (p0, p1) in enumerate(zip(pts, pts[1:])):
            if k in chords:
                continue
            own = order[k]
            if not far(p0[0], p0[1], own):
                return False
            count = int(math.dist(p0, p1) // step)
            for t in range(1, count + 1):
                f = t / (count + 1)
                if not far(p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f, own):
                    return False
        return len(pts) < 2 or len(pts) - 2 in chords or far(pts[-1][0], pts[-1][1], order[-1])

    def _distance(self, p, k):
        """From p to the edge's part k."""
        a, u, L = self.segs[k][5], self.segs[k][1], self.segs[k][4]
        t = min(max((p[0] - a[0]) * u[0] + (p[1] - a[1]) * u[1], 0.), L)
        return math.hypot(p[0] - a[0] - u[0] * t, p[1] - a[1] - u[1] * t)

    STEP = .25   # mm between the points of an edge moved in (the fallback)

    def _sampled(self, d, inside):
        """(fallback) points of the edge every STEP mm moved in by d, those nearer than d to the edge dropped (a corner cut
        by its neighbours), the seam through the others; each kept with the point of the edge it comes from."""
        segs, near, cell = self.segs, 1e-5 * max(1., d), max(2. * d, 1.)
        grid = self._grid(d, cell)

        def trim(u, v):   # how much a corner toward the inside cuts each of its parts at the seam (else 0)
            cross, dot = u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1]
            return d * math.tan(min(abs(math.atan2(cross, dot)), math.radians(170)) / 2) if cross * inside > 0 else 0.
        xs, ys, points, cuts, y, last = [], [], [], [], 0., None
        for k, (_, u, n, travel, L, a) in enumerate(segs):
            count = max(1, math.ceil(L / self.STEP))
            spots = {L * t / count for t in range(count + (k == len(segs) - 1))}
            t0 = trim(segs[k - 1][1], u) if k else 0.   # (second review: where the part's seam begins and ends, so that a
            t1 = L - trim(u, segs[k + 1][1]) if k + 1 < len(segs) else L   # round a little wider than the seam keeps it)
            spots |= {t for t in (t0, t1) if 0. <= t <= L and t0 <= t1 and (t < L or k == len(segs) - 1)}
            for tt in sorted(spots):
                c = (a[0] + u[0] * tt, a[1] + u[1] * tt)
                p = (c[0] + n[0], c[1] + n[1])
                if all(self._distance(p, o) >= d - near for o in grid.get((math.floor(p[0] / cell), math.floor(p[1] / cell)), ()) if o != k):
                    if last is not None:
                        y += math.dist(last, p)
                    last = p
                    points.append(p)
                    cuts.append(c)
                    ys.append(y)
                xs.append(travel + tt)
                if len(ys) < len(xs):   # (dropped: at the place of the last point kept)
                    ys.append(y)
        if not points:
            points, cuts, ys = [segs[0][0]], [segs[0][5]], [0.] * len(xs)
        self.samples, self.corners = (xs, ys, cuts), {}
        self.order, self.points = [], points
        self.starts = [0.]
        for a, b in zip(points, points[1:]):
            self.starts.append(self.starts[-1] + math.dist(a, b))
        self.length = self.starts[-1]

    def _meet(self, i, j):
        (p, u), (q, v) = self.segs[i][:2], self.segs[j][:2]
        den = u[0] * v[1] - u[1] * v[0]
        if abs(den) < 1e-9:   # in line (or a half turn): the next part's start
            return q
        t = ((q[0] - p[0]) * v[1] - (q[1] - p[1]) * v[0]) / den
        return (p[0] + u[0] * t, p[1] + u[1] * t)

    def at(self, x):
        if self.ring:
            rot, s_mid, total, y0 = self.ring
            return (rot.at((x - s_mid) % total) - y0) % self.length if self.length else 0.
        if self.samples:
            xs, ys, _ = self.samples
            i = bisect.bisect_right(xs, x) - 1
            if i < 0:
                return ys[0]
            if i >= len(xs) - 1:
                return ys[-1]
            f = (x - xs[i]) / (xs[i + 1] - xs[i]) if xs[i + 1] > xs[i] else 0.
            return ys[i] + (ys[i + 1] - ys[i]) * f
        if not self.order:
            return x
        j = max(0, bisect.bisect_right(self.travels, x) - 1)
        if self.corners:
            c = bisect.bisect_left(self.travels, x - 1e-6)
            if c < len(self.travels) and abs(self.travels[c] - x) <= 1e-6 and c in self.corners:
                return self.corners[c]   # (on an inside corner: where its two seams meet)
        k = bisect.bisect_right(self.order, j) - 1
        if k < 0:
            return 0.   # (on a part that vanished before the seam's start)
        if self.order[k] != j:
            return self.starts[k + 1]   # a part that vanished: at the corner where it went
        q0, u, n, travel, L, a = self.segs[j]
        t = min(max(x - travel, 0.), L)
        moved = (a[0] + u[0] * t + n[0], a[1] + u[1] * t + n[1])
        p0, p1 = self.points[k], self.points[k + 1]
        w = (p1[0] - p0[0], p1[1] - p0[1])
        ww = w[0] * w[0] + w[1] * w[1]
        f = 0. if ww < 1e-18 else min(1., max(0., ((moved[0] - p0[0]) * w[0] + (moved[1] - p0[1]) * w[1]) / ww))
        return self.starts[k] + f * math.sqrt(ww)

    def point(self, y):
        if self.ring:
            return self.ring[0].point((y + self.ring[3]) % self.length if self.length else 0.)
        k = min(max(0, bisect.bisect_right(self.starts, y) - 1), len(self.points) - 2)
        if k < 0:
            return self.points[0], 0
        p0, p1 = self.points[k], self.points[k + 1]
        span = self.starts[k + 1] - self.starts[k]
        f = 0. if span < 1e-12 else min(1., max(0., (y - self.starts[k]) / span))
        return (p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f), k

    def back(self, y):
        """The point of the edge in front of the point ``y`` mm along the seam (moved back out)."""
        if self.ring:
            return self.ring[0].back((y + self.ring[3]) % self.length if self.length else 0.)
        if self.samples:
            cuts = self.samples[2]
            p, k = self.point(y)
            if k + 1 >= len(cuts):
                return cuts[-1]
            span = self.starts[k + 1] - self.starts[k]
            f = 0. if span < 1e-12 else min(1., max(0., (y - self.starts[k]) / span))
            return (cuts[k][0] + (cuts[k + 1][0] - cuts[k][0]) * f, cuts[k][1] + (cuts[k + 1][1] - cuts[k][1]) * f)
        if not self.order:
            return None
        p, k = self.point(y)
        n = self.segs[self.order[k]][2]
        return (p[0] - n[0], p[1] - n[1])


_SEAMS = {}


def seam_line(pts, d, inside):
    """Seam(pts, d, inside), kept for the same points (the bag's list and the proposals ask again for the same edges)."""
    key = (tuple((float(x), float(y)) for x, y in pts), float(d), inside)
    line = _SEAMS.get(key)
    if line is None:
        if len(_SEAMS) > 500:   # (each holds its edge: a few kB)
            _SEAMS.clear()
        line = _SEAMS[key] = Seam(pts, d, inside)
    return line


def measured(app, chosen, d):
    """0.19.26: the edge ``chosen`` (piece, sides) at its seam, ``d`` mm inside the piece: (its points (at the cut), its
    start along the contour, its length at the seam, the contour's length, its crans at the seam (mm from its start))."""
    from craft_tools import interior_side
    pts, start, length, total = portion(app, chosen)
    cut = crans(app, chosen[0], start, length, total)
    if d <= 0:
        return pts, start, length, total, cut
    try:
        line = seam_line(pts, d, interior_side(app.items[chosen[0]]))
    except ValueError:
        return pts, start, length, total, cut
    return pts, start, line.length, total, [line.at(x) for x in cut]


def thickness(app, k):
    """The refente of piece ``k`` in mm (« refente 10/10 » = 1 mm), None when it has none."""
    info = (host(app, k).get('piece_info') or {}).get('material') or {}
    try:
        v = float(str(info.get('refente', '')).replace(',', '.'))
    except ValueError:
        return None
    return v / 10 if v > 0 else None


def _along(pts, step=2.):
    """Points every ``step`` mm along a line."""
    out = []
    for a, b in zip(pts, pts[1:]):
        n = max(1, int(math.dist(a, b) / step))
        out += [(a[0] + (b[0] - a[0]) * j / n, a[1] + (b[1] - a[1]) * j / n) for j in range(n)]
    return out + pts[-1:]


def parage(app, k, pts):
    """The parage zone along most of the edge ``pts`` of piece ``k`` (its préparation data), or None."""
    from geometry import geometry_key, path
    owners = {app.items[k].get('piece_id'), app.items[k].get('owner_id'), host(app, k).get('piece_id')} - {None}
    samples = _along(pts)
    best = None
    for s in app.items:
        data = s.get('preparation')
        if not data or data.get('kind') != 'parage' or s.get('owner_id') not in owners:
            continue
        try:
            ring = path(s)[0]
        except (ValueError, KeyError, TypeError):
            continue
        near = _near_count(samples, ring, key=geometry_key(s))
        if near >= len(samples) / 2 and (best is None or near > best[0]):
            best = (near, data)
    return best[1] if best else None


_RINGS = {}


def _near_count(samples, ring, reach=.3, cell=2., key=None):
    """0.19.27: how many of ``samples`` lie inside ``ring`` or nearer than ``reach`` to it, counted as before
    (preparations.inside, then _gap) but each point measured only against the sides of the ring near it: a grid of
    squares of ``cell`` mm along each side, and for inside the sides across its band of ``cell`` mm, kept by ``key`` (the
    zone's geometry) (the fiche Montage measured each edge's points every 2 mm against every side of every parage: 70 %
    of its time)."""
    if len(ring) < 2:
        from preparations import inside
        return sum(1 for q in samples if inside(ring, q) or _gap(q, ring + ring[:1]) < reach)
    floor = math.floor
    kept = _RINGS.get((key, reach, cell)) if key is not None else None
    if kept is None:
        kept = _ring_grid(ring, reach, cell)
        if key is not None:
            if len(_RINGS) > 500:
                _RINGS.clear()
            _RINGS[(key, reach, cell)] = kept
    run, (x0, y0, x1, y1), grid, bands, cell = kept
    n = 0
    for q in samples:
        x, y = q
        if not (x0 <= x <= x1 and y0 <= y <= y1):   # (outside its box: neither inside nor near)
            continue
        hit = False
        for k in bands.get(floor(y / cell), ()):   # (preparations.inside: the sides across y, the same sum)
            a, b = run[k], run[k + 1]
            if (a[1] > y) != (b[1] > y) and x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]:
                hit = not hit
        if hit:
            n += 1
            continue
        for k in grid.get((floor(x / cell), floor(y / cell)), ()):
            a, b = run[k], run[k + 1]
            dx, dy = b[0] - a[0], b[1] - a[1]
            L = dx * dx + dy * dy
            t = 0 if L == 0 else max(0, min(1, ((q[0] - a[0]) * dx + (q[1] - a[1]) * dy) / L))
            if math.dist(q, (a[0] + t * dx, a[1] + t * dy)) < reach:   # (as _gap measures it)
                n += 1
                break
    return n


def _ring_grid(ring, reach, cell):
    """(the ring closed, its box widened by ``reach``, its sides by the squares of ``cell`` mm they come within reach of,
    by the bands of ``cell`` mm across their height, the size of the squares). Each box a hair wider than ``reach``
    (review: a point just outside a side's box by rounding was near it for _gap): it only picks the sides to measure. A
    huge ring: larger squares (review: a ring a kilometre long filled the memory)."""
    floor = math.floor
    run = ring + ring[:1]
    xs, ys = [p[0] for p in ring], [p[1] for p in ring]
    reach += 1e-13 * (1. + max(max(map(abs, xs)), max(map(abs, ys))))   # (a few hundred times the rounding)
    cell = max(cell, sum(math.dist(a, b) for a, b in zip(run, run[1:])) / 20000.)
    grid, bands = {}, {}
    for k, (a, b) in enumerate(zip(run, run[1:])):
        for band in range(floor(min(a[1], b[1]) / cell), floor(max(a[1], b[1]) / cell) + 1):
            bands.setdefault(band, []).append(k)
        L = math.dist(a, b)
        if L <= 2 * cell:   # (a short side: its box)
            boxes = [(min(a[0], b[0]) - reach, min(a[1], b[1]) - reach, max(a[0], b[0]) + reach, max(a[1], b[1]) + reach)]
        else:   # (a long one: boxes round its points every cell, reach + cell / 2 wide: a slanting side never fills its box)
            r, ux, uy = reach + cell / 2, (b[0] - a[0]) / L, (b[1] - a[1]) / L
            boxes = [(a[0] + ux * t - r, a[1] + uy * t - r, a[0] + ux * t + r, a[1] + uy * t + r)
                     for t in (min(n * cell, L) for n in range(int(L // cell) + 2))]
        for bx0, by0, bx1, by1 in boxes:
            for gx in range(floor(bx0 / cell), floor(bx1 / cell) + 1):
                for gy in range(floor(by0 / cell), floor(by1 / cell) + 1):
                    found = grid.setdefault((gx, gy), [])
                    if not found or found[-1] != k:
                        found.append(k)
    return run, (min(xs) - reach, min(ys) - reach, max(xs) + reach, max(ys) + reach), grid, bands, cell


def edge_thickness(app, k, pts, double=False):
    """(thickness at the seam in mm, what it is made of, the refente known, a rembord found) of the edge ``pts``."""
    leather = thickness(app, k)
    e = leather if leather is not None else 1.
    data = parage(app, k, pts)
    if not data:
        return e, f'cuir {_mm(e, 2)}', leather is not None, False
    kind = str(data.get('type') or '').upper()
    try:
        t = float(data.get('thickness')) / 10
    except (TypeError, ValueError):
        t = None
    if not t or t <= 0:
        return e, f'cuir {_mm(e, 2)} (parage {kind.lower() or "sans épaisseur"} : épaisseur non donnée)', leather is not None, 'REMBORD' in kind
    if 'BISEAU' in kind:
        return (e + t) / 2, f'parage biseau à {_mm(t, 2)} : milieu du biseau {_mm((e + t) / 2, 2)}', leather is not None, False
    if 'REMBORD' in kind:
        if double:
            return 2 * t, f'rembord paré à {_mm(t, 2)}, plié : 2 × {_mm(t, 2)}', leather is not None, True
        return e + t, f'rembord paré à {_mm(t, 2)}, plié sur le cuir : {_mm(e, 2)} + {_mm(t, 2)}', leather is not None, True
    return t, f'parage {kind.lower()} à {_mm(t, 2)}', leather is not None, False


def _name(s):
    info = (s.get('piece_info') or {}).get('part_name') or {}
    values = info.get('values') or []
    return ' '.join(str(v) for v in values if v).strip().upper() or str(s.get('name') or '').strip().upper()


LAYER_WORDS = ('RENFORT', 'RFT', 'DOUBLURE', 'DBL', 'NON TISSE', 'NON TISSÉ')


def piece_names(app, every=False):
    """0.19.27: [(index, name)] of the pieces (_pieces), read once for all the pieces whose layers are looked for."""
    return [(j, _name(host(app, j))) for j in _pieces(app, every)]


def layers(app, k, every=False, names=None):
    """The renforts and doublures of piece ``k`` found by their names (« RENFORT FACE », « DBL FACE » for FACE):
    [(index, name, thickness in mm or None)]. 0.19.25 ``every``: also among the pieces of a layer hidden (the
    proposals look at every piece). 0.19.27 ``names``: piece_names(app, every), when several pieces are looked at (the
    names were read again for each piece: Paires probables, Étape…)."""
    import re
    name = _name(host(app, k))
    if not name:
        return []
    word = re.compile(r'(^|\W)' + re.escape(name) + r'(\W|$)')
    out = []
    for j, other in (piece_names(app, every) if names is None else names):
        if j == k or other == name or not any(w in other for w in LAYER_WORDS) or not word.search(other):
            continue
        if any(other == o for _, o, _ in out):
            continue
        out.append((j, other, thickness(app, j)))
    return out


def thread(length, points, thick):
    """(points, thread in mm) of a lock stitch ``length`` mm long: each of the two threads lies along each point
    (10 / points per cm) and crosses the thickness once at each point."""
    n = max(1, round(length * points / 10))
    step = 10 / points
    return n, n * 2 * (step + thick)


def _drop_stale(app):
    """0.19.24 (review): the edges taken whose piece changed meanwhile (its sides fewer, the drawing changed under the
    tool: an IndexError at each move of the mouse) are let go: the check starts again."""
    st = app.__dict__.get('assembly_state')
    if not st:
        return False
    for key in ('a', 'b'):
        chosen = st.get(key)
        if not chosen:
            continue
        k, ids = chosen
        try:
            ok = bool(ids) and k < len(app.items) and max(ids) < len(sides(app.items[k])[0])
        except (IndexError, KeyError, TypeError, ValueError, ZeroDivisionError):
            ok = False
        if not ok:
            st.update(a=None, b=None, kept=None, added=False)
            return True
    return False


def result(app):
    """The numbers of the check (None while the second edge is not chosen)."""
    _drop_stale(app)
    st = app.__dict__.get('assembly_state') or {}
    if not st.get('a') or not st.get('b'):
        return None
    seam = seam_of(app, st.get('seam'))   # 0.19.26: measured at the seam
    pa, sa, la, ta, ca = measured(app, st['a'], seam)
    pb, sb, lb, tb, cb = measured(app, st['b'], seam)
    front, reversed_ = facing(ca, la, cb, lb)
    double = bool(st.get('double'))
    ta_, da, ka, ra = edge_thickness(app, st['a'][0], pa, double)
    tb_, db, kb, rb = edge_thickness(app, st['b'][0], pb, double)
    names = piece_names(app)   # 0.19.27: read once for both edges
    first = layers(app, st['a'][0], names=names)
    found = first + [x for x in layers(app, st['b'][0], names=names) if x[0] not in {y[0] for y in first}]
    ticked = [x for x in found if x[0] in (st.get('layers') or set())]
    extra = sum(x[2] if x[2] is not None else 1. for x in ticked)
    thick = st.get('thickness') if st.get('thickness') is not None else ta_ + tb_ + extra
    points = st.get('points') or round(10 / app.prefs.get('stitch_pitch', 10 / 3), 2)
    n, fil = thread(max(la, lb), points, thick)
    return dict(la=la, lb=lb, diff=la - lb, ca=len(ca), cb=len(cb), front=front, reversed=reversed_, thickness=thick,
                known=(ka, kb), points=points, n=n, thread=fil, a=pa, b=pb, made=(da, db), rembord=ra or rb, layers=found,
                seam=seam, crans_a=ca, crans_b=cb)


def _mm(v, digits=1):
    return f'{round(v, digits):g}'.replace('.', ',')


def summary(r):
    return (f'{_mm(r["la"])} / {_mm(r["lb"])} mm {seam_words(r["seam"])} (écart {_mm(abs(r["diff"]))}) · crans {r["front"]} en face '
            f'sur {r["ca"]} / {r["cb"]} · {r["n"]} points · fil ≈ {_mm(r["thread"] / 10, 0)} cm')


# --- the tool -----------------------------------------------------------------------------------------------------

def start(app):
    if hasattr(app, 'plan_active') and not app.plan_active() and hasattr(app, 'select_section'):
        app.select_section('plan')   # 0.19.25 (review): the check is made on the plan, never over a fiche shown
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    app.tool.set('assembly')
    app.last_command = ('tool', 'assembly')
    app.assembly_state = dict(a=None, b=None, thickness=None, points=None, kept=None, added=False)
    app.highlight_tools()
    prompt(app)
    app.refresh()


def resume(app):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return start(app)
    app.tool.set('assembly')   # 0.19.22: (Annuler / Rétablir left the Sélection under this prompt)
    app.last_command = ('tool', 'assembly')
    app.highlight_tools()
    st.pop('placed', None)
    found = _found_again(app, st)   # 0.19.26: the same edges, found by their pieces (« Crans en face » then Annuler)
    if not found:
        st.update(a=None, b=None, kept=None, added=False)
    prompt(app)
    draw(app)
    if found:
        window(app)   # (second review: Annuler closed it; refilled when it is still there)


def _frozen(chosen):
    return (chosen[0], tuple(chosen[1]))


def _hold(app, st, a, b):
    """0.19.26: the two edges of the check as they are kept (their pieces' keys), with the places they were taken at."""
    st['edges'] = dict(at=(_frozen(st['a']), _frozen(st['b'])), a=dict(a), b=dict(b))


def _found_again(app, st):
    """0.19.26: after Annuler / Rétablir, the check's two edges found again by their pieces' keys, their sides the same
    in number (else the check starts again, as before)."""
    edges = st.get('edges') or {}
    if not st.get('a') or not st.get('b') or edges.get('at') != (_frozen(st['a']), _frozen(st['b'])):
        return False
    pieces = _pieces(app, every=True)
    found = [piece_index(app, edges[x]['piece'], pieces) for x in ('a', 'b')]
    try:
        if None in found or any(len(sides(app.items[k])[0]) != edges[x]['count'] or max(edges[x]['sides']) >= edges[x]['count']
                                for k, x in zip(found, 'ab')):
            return False
    except (IndexError, KeyError, TypeError, ValueError, ZeroDivisionError):
        return False
    st.update(a=(found[0], e_sides(edges['a'])), b=(found[1], e_sides(edges['b'])))
    edges['at'] = (_frozen(st['a']), _frozen(st['b']))
    return True


def prompt(app):
    st = app.assembly_state
    _drop_stale(app)
    if not st.get('a'):
        app.status.set("Contrôle d'assemblage : cliquer le bord de la 1re pièce (Maj + clic : ajouter le côté suivant).")
    elif not st.get('b'):
        app.status.set("Cliquer le bord cousu dessus, sur l'autre pièce (Maj + clic : ajouter un côté ; Entrée : même pièce).")
    else:
        r = result(app)
        app.status.set('Assemblage : ' + summary(r) + ' · Entrée : nouveau contrôle.')


def _reach(app):
    return 8 / max(app.scale, 1e-9)


def hover(app, e):
    draw(app, side_at(app, app.raw(e), _reach(app)))


def draw(app, under=None):
    c = app.canvas
    c.delete('assembly_preview')
    if hasattr(app, 'plan_active') and not app.plan_active():
        return   # (review) a fiche shown: nothing over it
    _drop_stale(app)
    st = app.__dict__.get('assembly_state') or {}
    seam = seam_of(app, st.get('seam'))
    for key, color in zip(('a', 'b'), COLORS):
        if st.get(key):
            pts = portion(app, st[key])[0]
            c.create_line(*[v for p in pts for v in app.to_screen(p)], fill=color, width=5, capstyle='round', tags=('assembly_preview',))
            if seam > 0 and st.get('b'):   # 0.19.26: the seam where it is measured, dashed
                from craft_tools import interior_side
                try:
                    line = seam_line(pts, seam, interior_side(app.items[st[key][0]])).points
                except ValueError:
                    line = ()
                if len(line) > 1:
                    c.create_line(*[v for p in line for v in app.to_screen(p)], fill=color, width=1.5, dash=(5, 3), tags=('assembly_preview',))
    if under is not None:
        run = sides(app.items[under[0]])[0][under[1]][0]
        c.create_line(*[v for p in run for v in app.to_screen(p)], fill=app.p.get('accent', '#61c9ee'), width=3, dash=(6, 4), tags=('assembly_preview',))


def click(app, e):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return None
    _drop_stale(app)
    found = side_at(app, app.raw(e), _reach(app))
    if found is None:
        app.invalid_at(e, 'Cliquer le bord d’une pièce (Coupe extérieure).')
        return 'break'
    k, i = found
    shift = bool(getattr(e, 'state', 0) & 1)

    def grow(key):
        """Maj + click on a side of the same piece: added if it follows, removed if it was taken."""
        k0, ids = st[key]
        if i in ids:
            if len(ids) > 1 and in_one_run(app, k0, [j for j in ids if j != i]):   # 0.19.22: an end of the edge only (a
                ids.remove(i)                                                     # side in its middle split it in two)
        elif adjacent(app, st[key], i):
            ids.append(i)
    if not st.get('a'):
        st.update(a=(k, [i]), thickness=None, seam=None)   # 0.19.14: a thickness typed is for its own check (0.19.26: a jonc too)
    elif not st.get('b'):
        if k == st['a'][0] and not st.get('switched'):
            if shift:
                grow('a')
            else:
                st.update(a=(k, [i]), thickness=None, seam=None)
        else:
            st.update(b=(k, [i]), thickness=None)
    elif shift and k == st['b'][0]:
        grow('b')
    elif shift and k == st['a'][0]:
        grow('a')
    else:   # a new check from this edge
        st.update(a=(k, [i]), b=None, switched=False, thickness=None, kept=None, added=False, seam=None)
    st.pop('placed', None)   # (second review: « Crans en face » again turns them only right after)
    if st.get('b'):
        remember(app)   # 0.19.24: kept with the model (Contrôle d'assemblage du sac); (review) first: its jonc shown
    prompt(app)
    draw(app)
    if st.get('b'):
        window(app)
    return 'break'


def enter(app):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return 'break'
    if st.get('a') and not st.get('b'):
        st['switched'] = True   # the second edge on the same piece
        app.status.set("Cliquer le bord cousu dessus (sur la même pièce ou une autre).")
        return 'break'
    st.update(a=None, b=None, switched=False, thickness=None, kept=None, added=False, seam=None)
    st.pop('placed', None)
    prompt(app)
    draw(app)
    return 'break'


def write(app):
    """The check written on the plan, by the middle of the first edge."""
    from craft_tools import annotation
    r = result(app)
    if r is None:
        return None
    pts = r['a']
    half, travel, at = sum(math.dist(a, b) for a, b in zip(pts, pts[1:])) / 2, 0., pts[0]
    for a, b in zip(pts, pts[1:]):
        seg = math.dist(a, b)
        if travel + seg >= half:
            t = (half - travel) / seg if seg else 0
            at = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            break
        travel += seg
    text = annotation('Assemblage : ' + summary(r), (at[0] + 2, at[1] + 2), 2.5)
    text['assembly'] = dict(la=round(r['la'], 2), lb=round(r['lb'], 2), front=r['front'], points=r['points'], thickness=r['thickness'],
                            seam=r['seam'])
    app.snapshot()
    app.items.append(text)
    app.refresh()
    draw(app)
    return text


def _model_cran(app, chosen):
    """The settings of a cran already on the edge (piece, sides) to shape the new ones like it: its mark and whether it
    points inside; None without one."""
    from craft_tools import cran_mark, interior_side
    k, ids = chosen
    piece = app.items[k]
    owner = piece.get('piece_id') or piece.get('owner_id')
    pts, start, length, total = portion(app, chosen)
    for s in app.items:
        if s.get('is_notch') and owner and s.get('owner_id') == owner:
            mark = cran_mark(s, piece)
            if mark is not None and ((mark['distance'] - start) % total if total else 0.) <= length + .05:
                try:
                    return mark, mark.get('side', 1) == interior_side(piece)
                except ValueError:
                    return mark, True
    return None


def crans_in_front(app):
    """0.19.26 « Crans en face » (« Craft pose sur le 2e bord les crans qui manquent, en face de ceux du 1er »): on edge 2,
    a cran in front of each cran of edge 1 that has none there: at the same distance along the seam from the end facing
    edge 1's start (as the check counts them in front: review), shaped as a cran already on edge 2 (else on edge 1), on a
    corner along its bisector (as the Cran tool); one Annuler. Edge 2 without a cran: the way two pieces drawn the same
    way round are sewn (their edges run opposite), and « Crans en face » again right after puts them the other way. The
    number added."""
    st = app.__dict__.get('assembly_state') or {}
    r = result(app)
    if r is None:
        return 0
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    edges = (_frozen(st['a']), _frozen(st['b']))
    placed = st.get('placed')
    again = bool(placed) and placed['edges'] == edges and len(app.items) == placed['count'] and all(
        app.items[len(app.items) - len(placed['ids']) + n] is c for n, c in enumerate(placed['ids']))
    removed = []
    if again:   # « Crans en face » again right after: the crans it put, the other way (the same Annuler)
        removed = app.items[len(app.items) - len(placed['ids']):]
        del app.items[len(app.items) - len(placed['ids']):]
        r = result(app)
    else:
        bagged = (app.__dict__.get('_bag_placed') or {}).get(edges)
        if bagged and all(any(c is s for s in app.items) for c in bagged['ids']):
            # 0.19.27 (second review): the crans the whole bag put the way pieces are sewn (edge 2 had none): the other way
            try:
                app.snapshot()
            except Exception as exc:   # (read-only: licence_ui.LectureSeule)
                app.status.set(str(exc))
                return 0
            app._bag_placed.pop(edges, None)
            removed = list(bagged['ids'])
            app.items[:] = [s for s in app.items if not any(s is c for c in removed)]
            r = result(app)
            placed, again = dict(back=bagged['back']), True
    st.pop('placed', None)
    n = 0
    try:
        n = _in_front(app, st, r, edges, placed['back'] if again else None)
    finally:
        if removed and not n:   # (none put the other way: as they were)
            app.items.extend(removed)
            app.refresh()
    return n


def _new_crans(app, st, r, was=None):
    """The crans to put on edge 2 of the check ``st`` (a, b: piece, sides) in front of edge 1's, ``r`` its numbers
    (crans_a, crans_b, la, lb, b: edge 2's points, seam): (crans, the way they go, edge 2 had none or a tie (the way
    guessed), why none when none, how many of edge 2's are just beside where one goes: MISPLACED, to move, none put
    there). ``was``: the way crans just put went (now the other way)."""
    from craft_tools import interior_side, locate, new_cran, standalone_notch
    from entity_rules import ensure_piece_id
    ca, cb, la, lb = r['crans_a'], r['crans_b'], r['la'], r['lb']
    if not ca:
        return [], False, False, 'Aucun cran sur le bord 1 : rien à mettre en face.', 0
    piece = app.items[st['b'][0]]
    try:
        inside = interior_side(piece)
        guess = interior_side(app.items[st['a'][0]]) == inside   # (edge 2 without a cran: sewn, they run opposite)
    except ValueError:
        return [], False, False, 'Bord 2 : contour sans intérieur, crans impossibles.', 0
    same, other = facing_counts(ca, la, cb, lb)
    guessed = was is None and same == other
    back = (not was) if was is not None else other > same if other != same else guess   # (second review: a tie: as sewn)
    pts = r['b']
    ring = len(pts) > 3 and math.dist(pts[0], pts[-1]) < 1e-6   # (edge 2 all round: 0 and its length the same place)

    def apart(y, z):
        gap = abs(y - z)
        return min(gap, lb - gap) if ring else gap
    wanted, near = [], 0
    for x in ca:
        y = min(max(lb - x if back else x, 0.), lb)   # (along edge 2 itself)
        if ring and y >= lb - 1e-9:
            y = 0.
        if not any(apart(y, z) <= TOLERANCE for z in cb + wanted):
            if any(apart(y, z) < MISPLACED for z in cb):   # 0.19.27 (second review): one of edge 2's just beside: to move,
                near += 1                                  # never a second one beside it
                continue
            wanted.append(y)
    if not wanted:
        return [], back, guessed, (f'{near} cran{"s" if near > 1 else ""} du bord 2 presque en face (à moins de {_mm(MISPLACED)} mm) : '
                                   f'à déplacer ; aucun ajouté.' if near else 'Les crans du bord 2 sont déjà en face de ceux du bord 1.'), near
    line = seam_line(pts, r['seam'], inside) if r['seam'] > 0 else None
    model = _model_cran(app, st['b']) or _model_cran(app, st['a'])
    mark, pointing_in = model if model else (None, True)
    side = inside if pointing_in else -inside
    owner = piece.get('piece_id') or piece.get('owner_id') or ensure_piece_id(piece)
    made, taken = [], []
    for y in wanted:
        if line is not None:
            spot = line.back(y)
        else:
            spot, travel = pts[-1], 0.
            for a, b in zip(pts, pts[1:]):
                L = math.dist(a, b)
                if travel + L >= y and L > 0:
                    t = (y - travel) / L
                    spot = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
                    break
                travel += L
        if spot is None:
            continue
        distance = locate(piece, spot)[0]
        if any(abs(distance - other) < TOLERANCE / 2 for other in taken):
            continue   # (second review: several wanted by an inside corner: one cran there, never a stack)
        taken.append(distance)
        settings = new_cran(distance, side)
        for key in ('depth', 'kind', 'width', 'cap_width', 'gap'):
            if mark and key in mark:
                settings[key] = mark[key]
        bisector = app.corner_bisector(piece, distance, side) if hasattr(app, 'corner_bisector') else None
        if bisector:
            settings['direction'] = bisector   # (on a corner: along its bisector, as the Cran tool)
        cran = standalone_notch(piece, settings)
        cran['owner_id'] = owner
        made.append(cran)
    return made, back, guessed, None if made else 'Aucun cran posé sur le bord 2.', near


def _in_front(app, st, r, edges, was):
    """crans_in_front once the check is known: ``was`` the way the crans just put went (put now the other way), None."""
    again = was is not None
    made, back, tie, why, near = _new_crans(app, st, r, was)
    cb, ca = r['crans_b'], r['crans_a']
    if why:
        app.status.set(why)
        return 0
    if not again:
        try:
            app.snapshot()
        except Exception as exc:   # (read-only: licence_ui.LectureSeule)
            app.status.set(str(exc))
            return 0
    app.items.extend(made)
    turned = tie and any(abs(x - y) > TOLERANCE for x, y in zip(sorted(ca), sorted(r['lb'] - x for x in ca)))
    if not cb or again or turned:   # (0.19.27, second review: a tie with crans on edge 2, the two ways not the same places)
        st['placed'] = dict(edges=edges, count=len(app.items), ids=list(made), back=back)
    app.refresh()
    draw(app)
    win = app.__dict__.get('_assembly_window')
    if win is not None and win.winfo_exists():
        win._refill()
    prompt(app)
    n = len(made)
    after = result(app)
    short = len(ca) - (after['front'] if after else len(ca)) - near   # (second review: by an inside corner, a cran falls at the
    app.status.set(f'{n} cran{"s" if n > 1 else ""} ajouté{"s" if n > 1 else ""} sur le bord 2, en face de ceux du bord 1'   # corner)
                   + (f' ({short} pas tout à fait en face)' if short > 0 else '')
                   + (f' ; {near} du bord 2 presque en face (à moins de {_mm(MISPLACED)} mm) : à déplacer' if near else '')
                   + (' ; « Crans en face » encore : l’autre sens' if st.get('placed') else '') + ' (Annuler : les retire).')
    return n


MISPLACED = 3.   # mm: a cran of edge 2 this near where one should be (not within TOLERANCE): one to move, not one to add


def _numbers(ns):
    """« n° 2 », « n° 2 et 5 », « n° 2, 3 et 5 »"""
    ns = [str(n) for n in ns]
    return 'n° ' + (ns[0] if len(ns) == 1 else ', '.join(ns[:-1]) + ' et ' + ns[-1])


LEFT = (('écart', 'écart de plus de 0,5 mm : à régler d’abord'),
        ('presque', 'un cran du 2e bord presque en face : à déplacer'),
        ('autant', 'autant de crans sur le 2e bord, pas tous en face : à déplacer'),
        ('sens', 'sens à choisir : « Crans en face » de la couture'),
        ('à refaire', 'à refaire'))


def crans_in_front_bag(app):
    """0.19.27 « Crans en face » for the whole bag (« pour tout le sac d'un seul clic »): each pair kept whose edges are
    the same length at the seam (ECART) gets on edge 2 the crans missing in front of edge 1's, as « Crans en face » puts
    them for one (each pair counting the crans put for the ones before it); one snapshot, one Annuler. Left alone, and
    said with their numbers and what to do (reviews: DIFORME's linings, 7,86 mm apart, got 7 crans more each): a pair to
    check again, an écart, a cran of edge 2 near where one goes (MISPLACED: to move, not one more beside it), edge 2 with
    as many crans as edge 1, a tie with crans on edge 2 when the two ways differ (which way: « Crans en face » of the
    pair). Edge 2 without a cran: the way pieces are sewn, said when the two ways differ; « Crans en face » of that pair
    then puts them the other way (_bag_placed). The number put."""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    pieces = _pieces(app, every=True)
    put, sewn, saved, marked = 0, [], False, False
    guessed, left, bagged = [], {}, {}
    for n, pair in enumerate(entries(app), 1):
        if 'etape' in pair:
            continue
        found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
        if None in found or any(len(sides(app.items[k])[0]) != e['count'] or max(e['sides']) >= e['count']
                                for k, e in zip(found, (pair['a'], pair['b']))):
            left.setdefault('à refaire', []).append(n)
            continue
        st = dict(a=(found[0], e_sides(pair['a'])), b=(found[1], e_sides(pair['b'])))
        d = seam_of(app, pair.get('seam'))
        try:
            pa, _, la, _, ca = measured(app, st['a'], d)
            pb, _, lb, _, cb = measured(app, st['b'], d)
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            left.setdefault('à refaire', []).append(n)
            continue
        marked = marked or bool(ca)
        same, other = facing_counts(ca, la, cb, lb)
        if not ca or max(same, other) == len(ca):
            continue   # (nothing on edge 1, or each of its crans has one in front already)
        if abs(la - lb) > ECART:
            left.setdefault('écart', []).append(n)
            continue
        # (second review) both ways the same places (a cran in the middle, at both ends…): no way to choose
        symmetric = all(abs(x - y) <= TOLERANCE for x, y in zip(sorted(ca), sorted(lb - x for x in ca)))

        def misplaced(back):
            """a cran of edge 2 near (not in front of) where one of edge 1's goes, that way round"""
            return any(not any(abs(y - z) <= TOLERANCE for z in cb) and any(abs(y - z) < MISPLACED for z in cb)
                       for y in (lb - x if back else x for x in ca))
        tie = bool(cb) and same == other and not symmetric
        if misplaced(other > same) or tie and misplaced(other <= same):
            left.setdefault('presque', []).append(n)
            continue
        if tie:
            left.setdefault('sens', []).append(n)
            continue
        if len(cb) >= len(ca):
            left.setdefault('autant', []).append(n)
            continue
        made, back, _, _, _ = _new_crans(app, st, dict(crans_a=ca, crans_b=cb, la=la, lb=lb, b=pb, seam=d))
        if not made:
            continue
        if not saved:
            try:
                app.snapshot()
            except Exception as exc:   # (read-only: licence_ui.LectureSeule)
                app.status.set(str(exc))
                return 0
            saved = True
        app.items.extend(made)
        put += len(made)
        sewn.append(n)
        if not cb and not symmetric:   # (the way pieces are sewn: to check; that pair's own « Crans en face »: the other way)
            guessed.append(n)
            bagged[(_frozen(st['a']), _frozen(st['b']))] = dict(ids=list(made), back=back)
    app._bag_placed = bagged
    said = ''
    if left:
        count = sum(len(v) for v in left.values())
        said = (' Laissée' if count == 1 else ' Laissées') + ' : ' + ' ; '.join(
            f'{_numbers(left[key])} ({text})' for key, text in LEFT if key in left) + '.'
    if not put:
        app.status.set(('Aucun cran ajouté.' if left else 'Chaque cran du 1er bord a déjà son cran en face.' if marked
                        else 'Aucun cran sur le 1er bord des coutures du sac : rien à mettre en face.') + said)
        return 0
    app.refresh()
    win = app.__dict__.get('_bag_window')
    if win is not None and win.winfo_exists():
        win._refill()
    check = app.__dict__.get('_assembly_window')   # (review: a check open shows the crans put)
    if check is not None and check.winfo_exists():
        if (app.__dict__.get('assembly_state') or {}).get('b'):
            draw(app)
        check._refill()
    one = put == 1
    app.status.set(f'{put} cran{"" if one else "s"} ajouté{"" if one else "s"} ({_numbers(sewn)} ; Annuler {"le" if one else "les"} retire).'
                   + (f' {"Couture" if len(guessed) == 1 else "Coutures"} {_numbers(guessed)} : 2e bord sans cran, crans mis dans le sens '
                      f'des pièces cousues, à vérifier sur le plan (« Crans en face » de la couture : l’autre sens).' if guessed else '')
                   + said)
    return put


def window(app):
    """The numbers of the check, kept up to date; the thickness and the points per cm can be typed."""
    from tkinter import messagebox
    old = app.__dict__.get('_assembly_window')
    if old is not None and old.winfo_exists():
        old._refill()
        return old
    win = app.dialog("Contrôle d'assemblage")
    try:
        win.grab_release()
    except tk.TclError:
        pass
    app._assembly_window = win
    panel = app.p['panel']
    box = tk.Frame(win, bg=panel)
    box.pack(fill='x', padx=16, pady=(14, 4))
    labels = {}
    for row, (key, text) in enumerate((('a', 'Bord 1'), ('b', 'Bord 2'), ('diff', 'Écart'), ('crans', 'Crans en face'), ('n', 'Points'), ('thread', 'Fil (2 fils, sans marge)'))):
        app.label(box, text).grid(row=row, column=0, sticky='w', pady=2)
        labels[key] = tk.StringVar()
        tk.Label(box, textvariable=labels[key], bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 10, 'bold')).grid(row=row, column=1, sticky='w', padx=10)
    thick, points, seam = tk.StringVar(), tk.StringVar(), tk.StringVar()
    app.label(box, 'Épaisseur à la couture (mm)').grid(row=6, column=0, sticky='w', pady=2)
    app.entry(box, thick, 7).grid(row=6, column=1, sticky='w', padx=10)
    app.label(box, 'Points par cm').grid(row=7, column=0, sticky='w', pady=2)
    app.entry(box, points, 7).grid(row=7, column=1, sticky='w', padx=10)
    app.label(box, 'Couture (mm du bord)').grid(row=8, column=0, sticky='w', pady=2)   # 0.19.26: measured there
    seam_row = tk.Frame(box, bg=panel)
    seam_row.grid(row=8, column=1, sticky='w', padx=10)
    seam_entry = app.entry(seam_row, seam, 7)
    seam_entry.pack(side='left')
    jonc = tk.BooleanVar()
    note = tk.StringVar()
    tk.Label(win, textvariable=note, bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 9), justify='left', wraplength=330).pack(fill='x', padx=16)
    extras = tk.Frame(win, bg=panel)   # 0.19.14: the rembord's way, the renforts and doublures to add
    extras.pack(fill='x', padx=16)
    ticks = {}
    double = tk.BooleanVar(value=bool(app.assembly_state.get('double')))
    check = dict(bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), selectcolor=app.field_background(), activebackground=panel, font=('Segoe UI', 9))

    def joncs():
        """0.19.26: a jonc: the seam at 5 mm (kept with the pair); unticked: 2,5 mm again"""
        st = app.assembly_state
        st['seam'] = JONC if jonc.get() else None
        st.pop('placed', None)   # (second review: then « Crans en face »: at that seam, never the other way)
        remember(app)
        refill()
        prompt(app)
        draw(app)
    __import__('modern_style').make_check(seam_row, text=f'jonc ({_mm(JONC)} mm)', variable=jonc, command=joncs, **check).pack(side='left', padx=8)

    def changed():
        st = app.assembly_state
        st['double'] = double.get()
        st['layers'] = {j for j, v in ticks.items() if v.get()}
        st['thickness'] = None   # the thickness computed again
        refill()
        prompt(app)

    def build_extras(r):
        for w in extras.winfo_children():
            w.destroy()
        make = __import__('modern_style').make_check
        if r['rembord']:
            make(extras, text='Rembord paré sur 2 × sa largeur (sinon : rabat paré plié sur le cuir)', variable=double, command=changed, **check).pack(anchor='w')
        chosen = app.assembly_state.get('layers') or set()
        for j, name, t in r['layers']:
            v = ticks.setdefault(j, tk.BooleanVar(value=j in chosen))
            make(extras, text=f'+ {name} ({_mm(t, 2) + " mm" if t is not None else "1 mm compté"})', variable=v, command=changed, **check).pack(anchor='w')

    def refill():
        r = result(app)
        if r is None:
            for v in labels.values():
                v.set('—')
            return
        labels['a'].set(f'{_mm(r["la"])} mm')
        labels['b'].set(f'{_mm(r["lb"])} mm')
        labels['diff'].set(f'{_mm(abs(r["diff"]))} mm' + (' ✓' if abs(r['diff']) <= .5 else (' : bord 1 plus long' if r['diff'] > 0 else ' : bord 2 plus long')))
        labels['crans'].set(f'{r["front"]} (bord 1 : {r["ca"]}, bord 2 : {r["cb"]})' + (' · sens inverse' if r['reversed'] else ''))
        price, speed, hourly = sewing_prefs(app)   # 0.19.27: its thread and its time in the model's cost
        minutes = max(r['la'], r['lb']) / 10 / speed if speed else None
        labels['n'].set(f'{r["n"]} ({_mm(r["points"], 2)} par cm)'
                        + (f' · ≈ {_mm(minutes, 1)} min' if minutes is not None else '')
                        + (f' · {euros(minutes / 60 * hourly)}' if minutes is not None and hourly else ''))
        labels['thread'].set(f'≈ {_mm(r["thread"] / 10, 0)} cm' + (f' · {euros(r["thread"] / 1000 * price)}' if price else ''))
        thick.set(_mm(r['thickness'], 2))
        points.set(_mm(r['points'], 2))
        seam.set(_mm(r['seam'], 2))
        jonc.set(abs(r['seam'] - JONC) < 1e-9)
        missing = [n for n, known in zip(('1', '2'), r['known']) if not known]
        note.set(f'Bord 1 : {r["made"][0]} · bord 2 : {r["made"][1]}.'
                 + (' 1 mm compté pour le cuir de la pièce ' + ' et '.join(missing) + ' (pas de refente dans sa matière).' if missing else '')
                 + ('' if r['layers'] else ' Renforts et doublures : à ajouter à l’épaisseur.'))
        key = (r['rembord'], tuple(j for j, _, _ in r['layers']))
        if win.__dict__.get('_extras_key') != key:
            win._extras_key = key
            build_extras(r)

    def typed(e=None):
        st = app.assembly_state
        try:
            t = float(thick.get().replace(',', '.'))
            p = float(points.get().replace(',', '.'))
            d = float(seam.get().replace(',', '.'))
            if not 0 < t <= 50 or not .5 <= p <= 20 or not 0 <= d <= 30:
                raise ValueError
        except ValueError:
            messagebox.showerror("Contrôle d'assemblage", 'Épaisseur : 0 à 50 mm ; points par cm : 0,5 à 20 ; couture : 0 à 30 mm du bord.', parent=win)
            return 'break' if e is not None else False   # 0.19.22: (the button: nothing written)
        st['thickness'], st['points'] = t, p
        before = st.get('seam')
        if seam.get().strip() != _mm(seam_of(app, before), 2):   # (review: as shown, rounded: kept as it was)
            st['seam'] = None if abs(d - default_seam(app)) < 1e-9 else d   # 0.19.26 (2,5 mm: nothing kept)
        if st['seam'] != before:
            st.pop('placed', None)
            remember(app)
            draw(app)
        refill()
        prompt(app)
        return 'break' if e is not None else True
    for w in box.winfo_children() + [seam_entry]:
        if isinstance(w, tk.Entry):
            w.bind('<Return>', typed)
            w.bind('<FocusOut>', lambda e: None)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(8, 14))
    app.button(foot, 'Écrire sur le plan', lambda: typed() and write(app)).pack(side='left')
    app.button(foot, 'Crans en face', lambda: typed() and crans_in_front(app), kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.26
    app.button(foot, 'Tout le sac…', lambda: bag(app), kind='secondary').pack(side='left', padx=6)   # 0.19.24
    app.button(foot, 'Fermer', win.destroy).pack(side='right')
    win._refill = refill
    win._seam, win._jonc, win._joncs, win._typed = seam, jonc, joncs, typed   # (essais)
    refill()
    return win


# --- 0.19.24 the whole bag: every check done, kept with the model, checked again at once ----------------------------------

KEY = 'assemblages'
GOOD, BAD, WARN, GREY = '#34c759', '#ff3b30', '#ff9500', '#8e8e93'
ECART = .5   # mm: over it, the pair is in red (the check's ✓ above)


def piece_key(app, k):
    """What names piece ``k`` in a pair kept: its piece_id (given if it has none); a piece surcoupée: its précoupe's."""
    s = app.items[k]
    if s.get('piece_id'):
        return s['piece_id']
    import surcoupe
    from craft_tools import style
    if s.get('owner_id') and style(s)['role'] == surcoupe.ROLE:
        return 'dans:' + s['owner_id']   # (its copies in the précoupe are the same piece)
    from entity_rules import ensure_piece_id
    before = dict(s)
    key = ensure_piece_id(s)
    # (review) the same piece in the drawings Annuler / Rétablir bring back gets the same id: a change undone that did
    # not touch it never makes its pair « introuvable »
    for state in list(app.__dict__.get('undo_stack') or ()) + list(app.__dict__.get('redo_stack') or ()):
        for q in (state.get('items') or ()) if isinstance(state, dict) else ():
            if isinstance(q, dict) and not q.get('piece_id') and q == before:
                q['piece_id'] = key
    return key


def piece_index(app, key, pieces=None):
    """The piece named ``key`` (piece_key), or None when it is gone."""
    pieces = _pieces(app, every=True) if pieces is None else pieces
    if key.startswith('dans:'):
        owner = key[5:]
        return next((k for k in pieces if not app.items[k].get('piece_id') and app.items[k].get('owner_id') == owner), None)
    return next((k for k in pieces if app.items[k].get('piece_id') == key), None)


def edge_of(app, chosen):
    k, ids = chosen
    return dict(piece=piece_key(app, k), sides=sorted(set(ids)), count=len(sides(app.items[k])[0]))


def _ident(pair):
    """The same two edges, in either order."""
    return tuple(sorted((e['piece'], tuple(e['sides'])) for e in (pair['a'], pair['b'])))


def entries(app):
    """0.19.26: the bag's list in the order of montage: the pairs kept (dict a, b; seam: a jonc's) and the steps between
    them (dict etape: its text), copies."""
    out = []
    for e in (app.__dict__.get('infos') or {}).get(KEY) or []:
        if 'etape' in e:
            out.append(dict(etape=e['etape']))
        else:
            pair = dict(a=dict(e['a']), b=dict(e['b']))
            if e.get('seam') is not None:
                pair['seam'] = e['seam']
            out.append(pair)
    return out


def kept_pairs(app):
    return [e for e in entries(app) if 'a' in e]


def _store(app, rows):
    """The bag's list (pairs and steps) in the Infos du modèle (a new dict: the « * » of the tab compares it with the one
    saved)."""
    infos = dict(app.__dict__.get('infos') or {})
    if rows:
        infos[KEY] = rows
    else:
        infos.pop(KEY, None)
    app.infos = infos or None
    for name in ('update_window_title', 'rebuild_tabs'):
        if hasattr(app, name):
            getattr(app, name)()


def remember(app):
    """The check shown kept with the model: the same edges once; while a check goes on (a side added, the second edge
    taken again), the pair it added follows it."""
    st = app.__dict__.get('assembly_state') or {}
    if not st.get('a') or not st.get('b'):
        return
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        return   # (read-only: the check is shown, nothing is kept)
    pair = dict(a=edge_of(app, st['a']), b=edge_of(app, st['b']))
    _hold(app, st, pair['a'], pair['b'])
    new = _ident(pair)
    old = st.get('kept')
    pairs = entries(app)   # (0.19.26: the steps between them stay where they are)
    idents = [_ident(p) if 'a' in p else None for p in pairs]
    if new != old and new in idents:   # (review) a check reaching a pair kept: its seam (a jonc) with it
        st['seam'] = pairs[idents.index(new)].get('seam')
    if st.get('seam') is not None:
        pair['seam'] = st['seam']   # 0.19.26: a jonc's
    if old is not None and old != new and st.get('added') and old in idents:   # the pair of this check follows its edges
        at = idents.index(old)
        if new in idents:   # now the same as another one kept: that one, its sides counted again
            del pairs[at]
            idents.pop(at)
            pairs[idents.index(new)] = pair
            added = False
        else:
            pairs[at] = pair
            added = True
    elif new in idents:
        at = idents.index(new)
        if pairs[at] == pair and old == new:
            return
        pairs[at] = pair   # (review) checked again: its sides counted again (« côtés changés » goes)
        added = st.get('added') if old == new else False
    else:
        pairs.append(pair)
        added = True
    st.update(kept=new, added=added)
    _store(app, pairs)
    win = app.__dict__.get('_bag_window')
    if win is not None and win.winfo_exists():
        win._refill()


def _side_text(app, k, ids):
    name = _name(host(app, k)) or 'Pièce'
    return name + (f' · {len(ids)} côtés' if len(ids) > 1 else '')


def check(app, pair, pieces=None):
    """The pair kept checked again: dict(state 'ok' / 'bad' (écart) / 'crans' / 'gone' / 'changed', its texts, the edges'
    points)."""
    pieces = _pieces(app, every=True) if pieces is None else pieces
    out = dict(a_text=pair['a']['piece'][:8], b_text=pair['b']['piece'][:8], lengths='', diff='', crans='', a=None, b=None,
               seam=seam_of(app, pair.get('seam')))
    found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
    for key, k, e in zip(('a_text', 'b_text'), found, (pair['a'], pair['b'])):
        if k is not None:
            out[key] = _side_text(app, k, e['sides'])
    def shown(k, e):
        """(grey on the plan) the edge as it is when its sides are still there, else the whole contour"""
        if k is None:
            return None
        try:
            if max(e['sides']) < len(sides(app.items[k])[0]):
                return portion(app, (k, e_sides(e)))[0]
            pts, closed = __import__('geometry').path(app.items[k])
            return pts + pts[:1] if closed else pts
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            return None
    if None in found:
        return dict(out, state='gone', text='— pièce introuvable', a=shown(found[0], pair['a']), b=shown(found[1], pair['b']))
    for k, e in zip(found, (pair['a'], pair['b'])):
        if len(sides(app.items[k])[0]) != e['count'] or max(e['sides']) >= e['count']:
            return dict(out, state='changed', text='— côtés changés : refaire ce contrôle', a=shown(found[0], pair['a']), b=shown(found[1], pair['b']))
    seam = seam_of(app, pair.get('seam'))   # 0.19.26: at the seam
    out['seam'] = seam
    try:
        pa, sa, la, ta, ca = measured(app, (found[0], e_sides(pair['a'])), seam)
        pb, sb, lb, tb, cb = measured(app, (found[1], e_sides(pair['b'])), seam)
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        return dict(out, state='changed', text='— côtés changés : refaire ce contrôle')
    front, _ = facing(ca, la, cb, lb)
    diff = abs(la - lb)
    out.update(a=pa, b=pb, la=la, lb=lb, lengths=f'{_mm(la)} / {_mm(lb)}', diff=_mm(diff, 2), crans=f'{front} sur {len(ca)} / {len(cb)}')
    if diff > ECART:
        return dict(out, state='bad', text=f'✗ écart de {_mm(diff, 2)} mm')
    if not front == len(ca) == len(cb):
        return dict(out, state='crans', text=f'⚠ crans : {front} en face sur {len(ca)} / {len(cb)}')
    return dict(out, state='ok', text='✓ bon')


def e_sides(edge):
    return list(edge['sides'])


def checks(app):
    pieces = _pieces(app, every=True)
    return [check(app, pair, pieces) for pair in kept_pairs(app)]


COLOUR = dict(ok=GOOD, bad=BAD, crans=WARN, gone=GREY, changed=GREY)


def _fingerprint(app):
    """What the checks depend on: the pieces of the pairs and their crans (marshal: quick), the pairs."""
    import marshal
    pairs = kept_pairs(app)
    names = {e['piece'] for p in pairs for e in (p['a'], p['b'])}
    owners = {n[5:] if n.startswith('dans:') else n for n in names}
    parts = [s for s in app.items if s.get('piece_id') in owners or s.get('owner_id') in owners]
    try:
        return marshal.dumps((pairs, parts), 2)
    except ValueError:
        return None


def draw_bag(app):
    """The edges of the pairs kept on the plan (tag assembly_bag), in the colour of their state; the pair chosen in the
    list wider, in the check's two colours. Checked again when the pieces or their crans changed."""
    marks = app.__dict__.get('_bag_marks')
    c = app.canvas
    c.delete('assembly_bag')
    if not marks:
        return
    win = app.__dict__.get('_bag_window')
    if win is None or not win.winfo_exists():
        clear_bag(app)   # (its window gone another way)
        return
    if hasattr(app, 'plan_active') and not app.plan_active():
        return   # a fiche shown: nothing over it
    key = _fingerprint(app)
    if key is not None and key != marks.get('key'):
        return win._refill()   # the list and the plan checked again (it draws them)
    chosen = marks.get('chosen')
    for pts, pick in zip(marks.get('proposal') or (), COLORS):   # 0.19.25: the probable pair picked in its list
        if pts and len(pts) > 1:
            c.create_line(*[v for p in pts for v in app.to_screen(p)], fill=pick, width=6, capstyle='round', dash=(8, 4), tags=('assembly_bag',))
    for n, row in enumerate(marks['rows']):
        for edge, pick in (('a', COLORS[0]), ('b', COLORS[1])):
            pts = row.get(edge)
            if not pts or len(pts) < 2:
                continue
            xy = [v for p in pts for v in app.to_screen(p)]
            if n == chosen:
                c.create_line(*xy, fill=pick, width=6, capstyle='round', tags=('assembly_bag',))
            c.create_line(*xy, fill=COLOUR[row['state']], width=3 if n != chosen else 2, capstyle='round', tags=('assembly_bag',))
            if row.get('n'):   # 0.19.26: its number in the order of montage, by the middle of each edge
                x, y = app.to_screen(_middle(pts))
                c.create_oval(x - 9, y - 9, x + 9, y + 9, fill=app.p.get('panel', '#2b2f33'), outline=COLOUR[row['state']], width=2, tags=('assembly_bag',))
                c.create_text(x, y, text=str(row['n']), fill=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 9, 'bold'), tags=('assembly_bag',))
    c.tag_raise('assembly_bag')


def _middle(pts):
    """The point half way along a line."""
    half = sum(math.dist(a, b) for a, b in zip(pts, pts[1:])) / 2
    for a, b in zip(pts, pts[1:]):
        L = math.dist(a, b)
        if L >= half and L > 0:
            t = half / L
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        half -= L
    return pts[-1]


def clear_bag(app):
    app.__dict__.pop('_bag_marks', None)
    try:
        app.canvas.delete('assembly_bag')
    except tk.TclError:
        pass


def open_pair(app, pair):
    """The check of a pair kept, in the tool (its window: the thickness, the points and the thread)."""
    pieces = _pieces(app, every=True)
    found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
    if None in found:
        return False
    for k, e in zip(found, (pair['a'], pair['b'])):
        if len(sides(app.items[k])[0]) != e['count'] or max(e['sides']) >= e['count']:
            return False   # (review: its sides changed: an IndexError at each move of the mouse)
    start(app)
    st = app.assembly_state
    # (review) corrected here (Maj + clic), the pair follows: never a second one beside it
    st.update(a=(found[0], e_sides(pair['a'])), b=(found[1], e_sides(pair['b'])), kept=_ident(pair), added=True, seam=pair.get('seam'))
    _hold(app, st, pair['a'], pair['b'])
    prompt(app)
    draw(app)
    window(app)
    return True


# --- 0.19.25 the fiche « Assemblages » (fiches.py): the pairs kept with their numbers, points and thread -------------------

WORDS = dict(ok='bon', bad='écart', crans='crans', gone='à refaire', changed='à refaire')


def fiche_rows(app):
    """The fiche « Montage » (0.19.25 « Assemblages »), in the list's order of montage: the pairs kept [dict(a, b: the
    edges (ID unique, name, sides), seam, lengths (at the seam), diff, crans, state, word, thickness, n, thread (mm), la,
    lb)] and the steps between them [dict(etape: its text)]. Thickness, points and thread as the check counts them before
    anything is typed: the refentes and parages of both edges (1 mm for a leather without refente), the points per cm of
    the Piqûre; a pair to check again: its numbers left out. 0.19.27: drawing (each piece's outline and its edge),
    minutes (at the speed of Réglages, when given)."""
    import piece_ids
    pieces = _pieces(app, every=True)
    prefs = app.__dict__.get('prefs') or {}
    points = round(10 / (prefs.get('stitch_pitch') or 10 / 3), 2)
    speed = sewing_prefs(app)[1]
    out = []
    for pair in entries(app):
        if 'etape' in pair:
            out.append(dict(etape=pair['etape'], state='etape'))
            continue
        r = check(app, pair, pieces)
        found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
        row = dict(a=r['a_text'], b=r['b_text'], lengths=r['lengths'], diff=r['diff'], crans=r['crans'], state=r['state'],
                   word=WORDS[r['state']], thickness=None, n=None, thread=None, points=points, la=r.get('la'), lb=r.get('lb'),
                   seam=r['seam'])
        for key, k in zip(('a', 'b'), found):
            number = piece_ids.number_of(app.items, k) if k is not None else None
            if number:
                row[key] = f'{number} · {row[key]}'
        if None not in found and r.get('a') and r.get('b') and r['state'] in ('ok', 'bad', 'crans'):   # 0.19.27: its drawing (the pieces, the edges sewn; review: never a pair to check again, its old sides on the new contour)
            try:
                row['drawing'] = [(__import__('geometry').path(app.items[k]), list(edge)) for k, edge in zip(found, (r['a'], r['b']))]   # (the piece sewn, in a précoupe too)
            except (ValueError, KeyError, TypeError, IndexError):
                pass
        if r['state'] in ('ok', 'bad', 'crans'):
            try:
                thick = edge_thickness(app, found[0], r['a'])[0] + edge_thickness(app, found[1], r['b'])[0]
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                thick = None
            if thick is not None:
                n, fil = thread(max(r['la'], r['lb']), points, thick)
                row.update(thickness=thick, n=n, thread=fil)
                if speed:   # 0.19.27: its time at the machine
                    row['minutes'] = max(r['la'], r['lb']) / 10 / speed
        out.append(row)
    return out


# --- 0.19.27 the thread and the time of the seams in the model's cost (« Le fil et le temps de piqûre de chaque couture
# dans le coût du modèle ») ------------------------------------------------------------------------------------------------

SLOWEST = .1   # cm/min: a slower speed is none (review: 1e-310 made the minutes infinite, the fiches failed)


def sewing_prefs(app):
    """(price of the thread in €/m, speed of the seam in cm/min, cost of an hour in €/h) of Réglages › Outils: 0 when
    not given (nothing counted, like a material without a price)."""
    prefs = app.__dict__.get('prefs') or {}

    def value(key, least=0.):
        v = prefs.get(key)
        return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and v > least else 0.
    return value('thread_price'), value('sewing_speed', SLOWEST), value('hourly_cost')


def sewing(app, rows=None):
    """The thread and the time of the bag's seams (fiche_rows: the pairs whose numbers are known; a pair to check again
    is not counted): dict(seams, left (pairs not counted), thread (mm), length (mm, the longer edge of each), price,
    thread_cost (€ or None), minutes (None without a speed), hourly, time_cost (€ or None))."""
    price, speed, hourly = sewing_prefs(app)
    rows = fiche_rows(app) if rows is None else rows
    pairs = [r for r in rows if 'etape' not in r]
    counted = [r for r in pairs if r.get('thread') is not None]
    fil = sum(r['thread'] for r in counted)
    length = sum(max(r['la'], r['lb']) for r in counted)
    minutes = length / 10 / speed if speed and counted else None
    return dict(seams=len(counted), left=len(pairs) - len(counted), thread=fil, length=length, price=price,
                thread_cost=fil / 1000 * price if price and counted else None, minutes=minutes, speed=speed,
                hourly=hourly, time_cost=minutes / 60 * hourly if minutes is not None and hourly else None)


def euros(v):
    return f'{v:.2f}'.replace('.', ',') + ' €'


# --- 0.19.25 the pairs proposed (« Go tes propositions »: « Craft te propose les paires d'assemblage probables (même
# longueur, crans en face), tu n'as qu'à cocher ») ------------------------------------------------------------------------

NEAR = 3.          # mm: the lengths of a probable pair at most this far apart, or SPREAD of the longer
SPREAD = .03       # (the edges are measured at the cut: round corners make them a little longer than at the seam)
SHORTEST = 10.     # mm: a shorter edge is never proposed
LONGEST_RUN = 12   # sides in a row at most in one edge
MOST = 60          # proposals shown at most


def _known_key(app, k):
    """The name of piece ``k`` in the pairs kept, when it has one (nothing given: proposing changes nothing)."""
    s = app.items[k]
    if s.get('piece_id'):
        return s['piece_id']
    import surcoupe
    from craft_tools import style
    if s.get('owner_id') and style(s)['role'] == surcoupe.ROLE:
        return 'dans:' + s['owner_id']
    return None


def _cran_spots(app, k, total):
    """The crans of piece ``k``: their distances along its contour, from its start."""
    from geometry import geometry_key
    piece = app.items[k]
    owner = piece.get('piece_id') or piece.get('owner_id')
    if not owner:
        return []
    out = []
    piece_key = None
    for s in app.items:
        if s.get('is_notch') and s.get('owner_id') == owner:
            if piece_key is None:
                piece_key = geometry_key(piece)
            at = _cran_distance(s, piece, piece_key)
            if at is not None:
                out.append(at % total if total else 0.)
    return sorted(out)


def _alike(a, la, b, lb):
    """The crans ``a`` (along an edge ``la`` long) in front of the crans ``b`` once ``b`` is brought to that length, either
    way (3 mm or 1 % apart at most): round corners drift crans measured at the cut."""
    tol = max(3., .01 * la)
    k = la / lb if lb else 1.

    def count(bs):
        left, n = sorted(bs), 0
        for x in a:
            hit = next((y for y in left if abs(x - y) <= tol), None)
            if hit is not None:
                left.remove(hit)
                n += 1
        return n
    return max(count([y * k for y in b]), count([(lb - y) * k for y in b]))


def _bends(pts, reach):
    """How much a line's seam can differ from it, per mm of the seam's distance (``reach`` mm at most): 2 tan(turn / 2)
    at each of its corners, the turns near enough to meet at that distance counted as one corner (review: a round
    smaller than the seam loses as a sharp corner, more than its angle), a corner counted 170° at most."""
    cap = math.radians(170)
    turns = []   # (the turn at a point inside the line, the length to the next point)
    for a, b, c in zip(pts, pts[1:], pts[2:]):
        u, v = (b[0] - a[0], b[1] - a[1]), (c[0] - b[0], c[1] - b[1])
        cross, dot = u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1]
        turns.append((abs(math.atan2(cross, dot)) if cross or dot < 0 else 0., math.dist(b, c)))
    total, corner = 0., 0.
    for k, (turn, after) in enumerate(turns):
        corner += turn
        following = turns[k + 1][0] if k + 1 < len(turns) else None
        if following is not None and after < reach * (math.tan(min(corner, cap) / 2) + math.tan(min(following, cap) / 2)):
            continue   # (the part after it vanishes at that distance: one corner with the next)
        total += 2 * math.tan(min(corner, cap) / 2)
        corner = 0.
    return total


def proposals(app):
    """0.19.25: the probable pairs of edges: two edges (a side, or several in a row, each end side with a cran) of two
    pieces of about the same length (NEAR mm or SPREAD apart at most, SHORTEST mm long at least) with about as many
    crans, most of them falling in front of each other (``_alike``); never a piece with its own renfort or doublure, nor
    an edge already in a pair kept. [dict(a=(k, ids), b=(k, ids), la, lb, ca, cb, front: in front as the check counts
    them, seam: a jonc's 5 mm when the edges go together there, else None)]: the most crans alike first, then the closest
    numbers of crans, then the closest lengths. 0.19.26: measured at the seam (2,5 mm, or a jonc's 5 mm
    when that puts more crans in front or the lengths clearly closer: DIFORME's FACE and CAVOUR)."""
    from craft_tools import interior_side
    pieces = _pieces(app, every=True)
    taken = {}   # the sides of the edges kept: sewn already (review: nor an edge sharing a side with one)
    for pair in kept_pairs(app):
        for e in (pair['a'], pair['b']):
            taken.setdefault(e['piece'], set()).update(e['sides'])
    usual = default_seam(app)
    distances = [usual] + ([JONC] if abs(JONC - usual) > 1e-9 else [])
    reach = max(distances)   # (review: an edge's seam differs from it by its bends × the seam's distance at most:
    edges = []   # (length, k, ids, crans along the edge, bends)   (a round base all round, twice two round corners)
    for k in pieces:
        try:
            runs, total = sides(app.items[k])
            n = len(runs)
            spots = _cran_spots(app, k, total) if n and total > 0 else []   # (review: a cran it cannot read, as check())
        except (ValueError, KeyError, TypeError, ZeroDivisionError, IndexError):
            continue
        if not spots:
            continue
        def on(start, length):
            return sorted(min((d - start) % total, length) for d in spots if (d - start) % total <= length + .05)
        marked = [bool(on(start, length)) for _, start, length in runs]
        for i in range(n):   # each edge: from side i, one side or more in a row (round the closing corner too)
            if not marked[i]:
                continue
            start, length, ids, line = runs[i][1], 0., [], []
            for m in range(min(n, LONGEST_RUN)):
                j = (i + m) % n
                length += runs[j][2]
                line += list(runs[j][0][1:] if ids else runs[j][0])
                ids.append(j)
                if length < SHORTEST or not marked[j] or m + 1 == n and i:   # (the whole contour: once)
                    continue
                # 0.19.26: how far its seam can be from it (the whole contour: its closing corner too)
                bend = _bends(line + line[1:2] if m + 1 == n else line, reach)
                edges.append((length, k, tuple(ids), on(start, length), bend))
    edges.sort(key=lambda e: e[0])
    names = piece_names(app, True)   # 0.19.27: read once
    own = {k: {j for j, _, _ in layers(app, k, True, names)} for k in pieces}   # a piece and its renforts / doublures (by their names)
    found = {}
    most = max((e[4] for e in edges), default=0.)
    lines = {}

    def at_seam(k, ids, cut, d):
        """(length at the seam d, crans there) of the edge, kept"""
        key = (k, ids, d)
        if key not in lines:
            pts, start, length, total = portion(app, (k, list(ids)))
            try:
                line = seam_line(pts, d, interior_side(app.items[k])) if d > 0 else None
            except ValueError:
                line = None
            lines[key] = (line.length, [line.at(v) for v in cut]) if line else (length, list(cut))
        return lines[key]
    for x, (la, ka, ia, ca, ua) in enumerate(edges):
        for lb, kb, ib, cb, ub in edges[x + 1:]:
            if lb - la > max(NEAR, SPREAD * (lb + reach * most)) + reach * (ua + most):
                break
            if lb - la > max(NEAR, SPREAD * (lb + reach * ub)) + reach * (ua + ub):
                continue
            if kb == ka or kb in own[ka] or ka in own[kb] or abs(len(ca) - len(cb)) > max(1, round(.15 * max(len(ca), len(cb)))):
                continue
            key = tuple(sorted(((ka, tuple(sorted(ia))), (kb, tuple(sorted(ib))))))
            named = [_known_key(app, k) for k in (ka, kb)]
            if named[0] is not None and named[0] == named[1]:
                continue   # (review) two copies in one précoupe: the same piece for a pair kept
            if taken.get(named[0], set()) & set(ia) or taken.get(named[1], set()) & set(ib):
                continue
            best = None
            for d in distances:   # 0.19.26: at the seam; a jonc's only when clearly better than 2,5 mm
                sa, xa = at_seam(ka, ia, ca, d)
                sb, xb = at_seam(kb, ib, cb, d)
                if abs(sa - sb) > max(NEAR, SPREAD * max(sa, sb)):
                    continue
                alike = _alike(xa, sa, xb, sb)
                if alike < max(1, (max(len(ca), len(cb)) + 1) // 2):
                    continue   # their crans do not fall in front of each other: a coincidence of lengths
                front, _ = facing(xa, sa, xb, sb)
                if best is not None and not (front > best[4] or front == best[4] and abs(best[2] - best[3]) - abs(sa - sb) > ECART):
                    continue
                best = (d, alike, sa, sb, front)
            if best is None:
                continue
            d, alike, sa, sb, front = best
            score = (-round(alike / max(len(ca), len(cb)), 1), abs(len(ca) - len(cb)), abs(sa - sb))
            if key not in found or score < found[key][0]:
                found[key] = (score, dict(a=(ka, list(ia)), b=(kb, list(ib)), la=sa, lb=sb, ca=len(ca), cb=len(cb), front=front,
                                          pieces=(app.items[ka], app.items[kb]), seam=None if d == usual else d))
    out = []
    for _, p in sorted(found.values(), key=lambda v: v[0]):   # the best first; one seam once (edges overlapping on both pieces)
        if not any({p['a'][0], p['b'][0]} == {q['a'][0], q['b'][0]} and all(
                set(dict((p['a'], p['b']))[k]) & set(dict((q['a'], q['b']))[k]) for k in {p['a'][0], p['b'][0]}) for q in out):
            out.append(p)
    return out[:MOST]


def add_pairs(app, chosen):
    """0.19.25: the proposals ``chosen`` kept with the model (each once); the number added."""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    pairs = entries(app)   # (0.19.26: after the steps and pairs already there)
    idents = {_ident(p) for p in pairs if 'a' in p}
    added = 0
    for p in chosen:
        pair = dict(a=edge_of(app, p['a']), b=edge_of(app, p['b']))
        if p.get('seam') is not None:
            pair['seam'] = p['seam']   # 0.19.26: a jonc
        if _ident(pair) not in idents:
            pairs.append(pair)
            idents.add(_ident(pair))
            added += 1
    if added:
        _store(app, pairs)
    win = app.__dict__.get('_bag_window')
    if win is not None and win.winfo_exists():
        win._refill()
    return added


def propose(app):
    """0.19.25 « Paires probables… » (Contrôle d'assemblage du sac): the probable pairs in a list to tick; a click shows
    the pair on the plan; « Ajouter les paires cochées » keeps them with the model."""
    from tkinter import ttk
    old = app.__dict__.get('_proposal_window')
    if old is not None and old.winfo_exists():
        old._refill()
        old.lift()
        return old
    win = app.dialog('Paires probables')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._proposal_window = win
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    head = tk.StringVar()
    tk.Label(win, textvariable=head, bg=panel, fg=ink, font=('Segoe UI', 10), justify='left', wraplength=620).pack(anchor='w', padx=14, pady=(12, 4))
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    columns = (('tick', '', 3), ('a', 'Bord 1', 24), ('b', 'Bord 2', 24), ('seam', 'Couture', 8), ('len', 'Longueurs (mm)', 15), ('crans', 'Crans', 15))
    table = ttk.Treeview(area, columns=[k for k, _, _ in columns], show='headings', height=10, selectmode='browse')
    for key, label, width in columns:
        table.heading(key, text=label)
        table.column(key, width=width * 7, anchor='center' if key == 'tick' else 'w', stretch=key in ('a', 'b'))
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')
    state = dict(rows=[], ticked=set())

    def text(chosen):
        k, ids = chosen
        return _side_text(app, k, ids)

    def stale():
        """(review) the drawing changed under the list: its pieces are not where they were"""
        items = app.items
        return any(not all(k < len(items) and items[k] is s for k, s in zip((p['a'][0], p['b'][0]), p['pieces'])) for p in state['rows'])

    def refill():
        state['rows'] = rows = proposals(app)
        state['ticked'] = set()
        table.delete(*table.get_children())
        for n, p in enumerate(rows):
            table.insert('', 'end', iid=str(n), values=('☐', text(p['a']), text(p['b']), seam_text(seam_of(app, p.get('seam'))),
                                                        f'{_mm(p["la"])} / {_mm(p["lb"])}', f'{p["ca"]} / {p["cb"]} ({p["front"]} en face)'))
        if rows:
            head.set(f'{len(rows)} paire{"s" if len(rows) > 1 else ""} de bords de même longueur à la couture (à 3 mm ou 3 % près), '
                     'aux crans en face : cocher celles qui sont cousues ensemble, puis « Ajouter les paires cochées ». Clic : la paire '
                     'sur le plan. Couture « jonc » : les bords vont ensemble à 5 mm.')
        else:
            head.set('Aucune paire probable : il faut des crans en face sur les deux bords (les bords déjà dans la liste du sac '
                     'ne sont pas proposés).')
        shown(None)

    def shown(n):
        marks = app.__dict__.get('_bag_marks')
        if marks is None:
            return
        if n is None or n >= len(state['rows']):
            marks.pop('proposal', None)
        else:
            p = state['rows'][n]
            try:
                marks['proposal'] = (portion(app, (p['a'][0], list(p['a'][1])))[0], portion(app, (p['b'][0], list(p['b'][1])))[0])
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                marks.pop('proposal', None)
        draw_bag(app)

    def toggle(n):
        if n in state['ticked']:
            state['ticked'].discard(n)
        else:
            state['ticked'].add(n)
        table.set(str(n), 'tick', '☑' if n in state['ticked'] else '☐')

    def clicked(e):
        row = table.identify_row(e.y)
        if row and table.identify_column(e.x) == '#1':
            toggle(int(row))

    def picked(e=None):
        if stale():
            return refill()
        sel = table.selection()
        shown(int(sel[0]) if sel else None)

    def key_toggle(e=None):
        sel = table.selection()
        if sel:
            toggle(int(sel[0]))
        return 'break'

    def double(e):
        if table.identify_column(e.x) == '#1':
            return 'break'   # (review) its first click ticked it already: the double click leaves it ticked
        return key_toggle(e)
    table.bind('<Button-1>', clicked, add='+')
    table.bind('<<TreeviewSelect>>', picked)
    table.bind('<space>', key_toggle)
    table.bind('<Double-1>', double)

    def add():
        chosen = [state['rows'][n] for n in sorted(state['ticked'])]
        if not chosen:
            app.status.set('Cocher les paires cousues ensemble.')
            return
        if stale():
            refill()
            app.status.set('Le dessin a changé : la liste est refaite, cocher à nouveau.')
            return
        added = add_pairs(app, chosen)
        if added:
            app.status.set(f'{added} assemblage{"s" if added > 1 else ""} ajouté{"s" if added > 1 else ""} au contrôle du sac.')
        refill()

    def done():
        marks = app.__dict__.get('_bag_marks')
        if marks is not None:
            marks.pop('proposal', None)
            draw_bag(app)
        app.__dict__.pop('_proposal_window', None)
        win.destroy()
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Ajouter les paires cochées', add).pack(side='left')
    app.button(foot, 'Fermer', done).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win.bind('<FocusIn>', lambda e: refill() if e.widget is win and stale() else None)   # back from the plan, changed
    win._refill = refill
    win._table = table
    win._toggle = toggle
    win._add = add
    win._done = done
    win._state = state
    refill()
    return win


def montage_rows(app):
    """0.19.26: the bag's list in its order of montage: each pair checked again (check()) or a step (state 'etape', its
    text), each with its number n (1, 2, …: the same on the plan and on the fiche)."""
    pieces = _pieces(app, every=True)
    out = []
    for n, e in enumerate(entries(app), 1):
        if 'etape' in e:
            out.append(dict(state='etape', text=e['etape'], n=n, a=None, b=None, a_text=e['etape'], b_text='', lengths='', diff='', crans=''))
        else:
            out.append(dict(check(app, e, pieces), n=n))
    return out


STEP_LONGEST = 200   # characters of a step


def clean_step(text):
    return ' '.join(''.join(ch if ch >= ' ' else ' ' for ch in str(text or '')).split())[:STEP_LONGEST]


STEPS_KEPT = 40   # 0.19.27: steps typed, kept for the other models (the last ones first)


def typed_steps(app):
    """0.19.27 (« « Étape… » propose les étapes déjà tapées dans tes autres modèles »): the steps he typed, in any model,
    the last ones first (preferences « montage_steps »)."""
    out = []
    for t in (app.__dict__.get('prefs') or {}).get('montage_steps') or ():
        t = clean_step(t) if isinstance(t, str) else ''
        if t and t not in out:
            out.append(t)
    return out[:STEPS_KEPT]


def remember_steps(app, texts, forget=False):
    """The steps ``texts`` kept first among the steps typed (``forget``: taken out), in the preferences."""
    prefs = app.__dict__.get('prefs')
    if prefs is None:
        return
    texts = [t for t in (clean_step(x) for x in texts) if t]
    kept = typed_steps(app)
    new = [t for t in kept if t not in texts] if forget else (texts + [t for t in kept if t not in texts])[:STEPS_KEPT]
    if new != kept:
        prefs['montage_steps'] = new
        try:
            app.persist_preferences()
        except (OSError, AttributeError):
            pass


def steps_proposed(app):
    """0.19.26 (« il y a les étapes inter à prendre en compte »): the steps Craft sees on the pieces of the pairs kept,
    each with where it goes, before the first pair of its piece: [(text, its place in the list)]. For each piece, in this
    order: its parages (« FACE : parage rembord 7 »), its renforts and doublures by their names (« RENFORT FACE : coller
    sur FACE »), its surcoupe (a piece in a précoupe), its rembordé (a parage rembord), its teinture; before a pair with
    a jonc, « FACE / CAVOUR : poser le jonc ». A step already in the list is not proposed again."""
    import surcoupe
    from craft_tools import style
    rows = entries(app)
    have = {e['etape'] for e in rows if 'etape' in e}
    pieces = _pieces(app, every=True)
    names = piece_names(app, True)   # 0.19.27: read once
    first = {}   # piece (its key in the pairs) -> the place of its first pair in the list
    for i, e in enumerate(rows):
        if 'a' in e:
            for edge in (e['a'], e['b']):
                first.setdefault(edge['piece'], i)
    out = []

    def add(text, at):
        text = clean_step(text)
        if text and text not in have and all(text != t for t, _ in out):
            out.append((text, at))
    for key, at in sorted(first.items(), key=lambda kv: kv[1]):
        k = piece_index(app, key, pieces)
        if k is None:
            continue
        piece = app.items[k]
        name = _name(host(app, k)) or 'Pièce'
        owners = {piece.get('piece_id'), piece.get('owner_id'), host(app, k).get('piece_id')} - {None}
        zones = [q['preparation'] for q in app.items if isinstance(q.get('preparation'), dict) and q.get('owner_id') in owners]
        rembord = False
        for z in zones:
            if z.get('kind') == 'parage':
                add(f'{name} : {str(z.get("label") or "parage").strip().lower()}', at)
                rembord = rembord or 'REMBORD' in str(z.get('type') or '').upper()
        for j, layer, _ in layers(app, k, True, names):
            if _known_key(app, j) not in first:   # (a doublure sewn to the lining's other pieces: assembled, not glued)
                add(f'{layer} : coller sur {name}', at)
        if piece.get('owner_id') and not piece.get('piece_id') and style(piece)['role'] == surcoupe.ROLE:
            add(f'{name} : surcoupe', at)
        if rembord:
            add(f'{name} : rembordé', at)
        if any(z.get('kind') == 'teinte' for z in zones):
            add(f'{name} : teinture', at)
    for i, e in enumerate(rows):
        if 'a' in e and abs(seam_of(app, e.get('seam')) - JONC) < 1e-9 and e.get('seam') is not None:
            found = [piece_index(app, e[x]['piece'], pieces) for x in ('a', 'b')]
            if None not in found:   # (second review: the seam it goes in, by both pieces, the larger first: FACE / CAVOUR)
                found.sort(key=lambda k: -_area(host(app, k)))
                add(' / '.join(_name(host(app, k)) or 'Pièce' for k in found) + ' : poser le jonc', i)
    return out


def _area(s):
    from geometry import outline_area
    try:
        return abs(outline_area(s['points'], s.get('bulges') or [0.] * len(s['points'])))
    except (KeyError, TypeError, ValueError, ZeroDivisionError, IndexError):
        return 0.


def insert_steps(app, steps):
    """0.19.26: the steps [(text, place: before the line at that place in the list, None: at the end)] put in the bag's
    list (several at one place: in their order; a step typed twice is put twice: review, « Encoller » before two seams);
    the line chosen in the bag's list stays the same line. The number put."""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    rows = entries(app)
    chosen = []
    for order, (text, at) in enumerate(steps):
        text = clean_step(text)
        if text:
            chosen.append((len(rows) if at is None else min(max(0, at), len(rows)), order, text))
    for at, _, text in sorted(chosen, reverse=True):
        rows.insert(at, dict(etape=text))
    if chosen:
        marks = app.__dict__.get('_bag_marks')
        if marks and marks.get('chosen') is not None:   # (review: the same line chosen, below the steps put above it)
            marks['chosen'] += sum(1 for at, _, _ in chosen if at <= marks['chosen'])
        _store(app, rows)
        win = app.__dict__.get('_bag_window')
        if win is not None and win.winfo_exists():
            win._refill()
    return len(chosen)


def steps_window(app, after=None):
    """0.19.26 « Étape… » (Contrôle d'assemblage du sac): a step typed, put after the line chosen in the list (or at its
    end); the steps Craft proposes (steps_proposed) to tick, each put before the first pair of its piece; 0.19.27: the
    steps he typed before, in this model or another (typed_steps), to tick too, put after the line chosen as typed;
    « Oublier » takes the one chosen out of them."""
    from tkinter import ttk
    old = app.__dict__.get('_steps_window')
    if old is not None and old.winfo_exists():
        old._after = after
        old._refill()
        old.lift()
        return old
    win = app.dialog('Étape de montage')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._steps_window = win
    win._after = after
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    line = tk.Frame(win, bg=panel)
    line.pack(fill='x', padx=14, pady=(12, 4))
    app.label(line, 'Étape').pack(side='left')
    typed = tk.StringVar()
    entry = app.entry(line, typed, 44)
    entry.pack(side='left', padx=8, fill='x', expand=True)
    head = tk.StringVar()
    tk.Label(win, textvariable=head, bg=panel, fg=ink, font=('Segoe UI', 9), justify='left', wraplength=520).pack(anchor='w', padx=14, pady=(4, 2))
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    table = ttk.Treeview(area, columns=('tick', 'text', 'from'), show='headings', height=8, selectmode='browse')
    table.heading('tick', text='')
    table.heading('text', text='Étapes proposées')
    table.heading('from', text='Origine')
    table.column('tick', width=24, anchor='center', stretch=False)
    table.column('text', width=400, anchor='w', stretch=True)
    table.column('from', width=110, anchor='w', stretch=False)
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')
    state = dict(rows=[], ticked=set())

    def refill():
        seen = steps_proposed(app)
        have = {e['etape'] for e in entries(app) if 'etape' in e} | {t for t, _ in seen}
        state['rows'] = seen + [(t, None) for t in typed_steps(app) if t not in have]   # 0.19.27 (None: as typed)
        state['ticked'] = set()
        table.delete(*table.get_children())
        for n, (text, at) in enumerate(state['rows']):
            table.insert('', 'end', iid=str(n), values=('☐', text, 'sur les pièces' if at is not None else 'déjà tapée'))
        head.set('Taper une étape (elle va après la ligne choisie dans la liste du sac), ou cocher celles proposées : vues sur les '
                 'pièces (chacune avant le premier assemblage de sa pièce), déjà tapées (après la ligne choisie) ; l’ordre se '
                 'règle ensuite avec ▲ ▼.'
                 if state['rows'] else 'Taper une étape : elle va après la ligne choisie dans la liste du sac ; l’ordre se règle '
                 'ensuite avec ▲ ▼.')

    def toggle(n):
        state['ticked'] ^= {n}
        table.set(str(n), 'tick', '☑' if n in state['ticked'] else '☐')

    def clicked(e):
        row = table.identify_row(e.y)
        if row and table.identify_column(e.x) == '#1':
            toggle(int(row))

    def double(e):
        if table.identify_column(e.x) == '#1':
            return 'break'
        sel = table.selection()
        if sel:
            toggle(int(sel[0]))
        return 'break'
    table.bind('<Button-1>', clicked, add='+')
    table.bind('<Double-1>', double)

    def line_chosen():
        """the line chosen in the bag's list now (review: not when this window was opened)"""
        bag = app.__dict__.get('_bag_window')
        if bag is not None and bag.winfo_exists():
            picked = bag._table.selection()
            return int(picked[0]) if picked else None
        return win._after

    def add(e=None):
        text = clean_step(typed.get())
        rows = entries(app)
        steps = []
        at = line_chosen()
        after = len(rows) if at is None or at >= len(rows) else at + 1
        if text:
            steps.append((text, after))
        fresh = dict(steps_proposed(app))   # (review: where they go in the list as it is now; already put: not again)
        have = {r['etape'] for r in rows if 'etape' in r}
        used = [text] if text else []
        for n in sorted(state['ticked']):
            t, where = state['rows'][n]
            if where is None:   # 0.19.27: typed before: after the line chosen, as typed (not when in the list already)
                if t not in have and t != text:
                    steps.append((t, after))
                    used.append(t)
            elif t in fresh:
                steps.append((t, fresh[t]))
        if not steps:
            app.status.set('Ces étapes sont déjà dans la liste.' if state['ticked'] else 'Taper une étape, ou cocher celles proposées.')
            refill()
            return 'break' if e is not None else None
        put = insert_steps(app, steps)
        if put:
            typed.set('')
            app.status.set(f'{put} étape{"s" if put > 1 else ""} dans la liste du sac.')
            if used:
                remember_steps(app, used)   # 0.19.27: for the other models (the last used first)
        refill()
        return 'break' if e is not None else None
    entry.bind('<Return>', add)

    def forget():
        """0.19.27: the step typed before chosen in the list taken out of the steps kept"""
        sel = table.selection()
        row = state['rows'][int(sel[0])] if sel else None
        if row is None or row[1] is not None:
            app.status.set('Choisir une étape « déjà tapée » à oublier.')
            return
        remember_steps(app, [row[0]], forget=True)
        app.status.set(f'Étape oubliée : {row[0]}')
        refill()

    def done():
        app.__dict__.pop('_steps_window', None)
        win.destroy()
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Ajouter', add).pack(side='left')
    app.button(foot, 'Oublier', forget, kind='secondary').pack(side='left', padx=6)   # 0.19.27
    app.button(foot, 'Fermer', done).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win._refill = refill
    win._table = table
    win._toggle = toggle
    win._typed = typed
    win._add = add
    win._forget = forget
    win._done = done
    win._state = state
    refill()
    entry.focus_set()
    return win


def bag(app):
    """Exporter › Contrôle d'assemblage du sac…: every pair kept, checked again at once. 0.19.26: the list is the order of
    montage (▲ ▼), with the steps between the seams (« Étape… »), numbered the same on the plan and on the fiche."""
    from tkinter import ttk, simpledialog
    old = app.__dict__.get('_bag_window')
    if old is not None and old.winfo_exists():
        old._refill()
        old.lift()
        return old
    win = app.dialog("Contrôle d'assemblage du sac")
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):   # opened from a tool: stays open after it (Échap, Annuler, the next check)
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._bag_window = win
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    app.label(win, 'Chaque Contrôle d’assemblage fait est gardé avec le modèle ; ici, tous contrôlés d’un coup, à la couture, dans '
                   'l’ordre de montage (▲ ▼). Double-clic : ouvrir ce contrôle, ou changer l’étape.').pack(anchor='w', padx=14, pady=(12, 2))
    if app.__dict__.get('mozart_source') and not app.__dict__.get('filename'):   # a DWG Mozart cannot keep them
        app.label(win, 'DWG Mozart : la liste est gardée tant qu’il est ouvert ; Enregistrer sous… (.crft) la garde avec le modèle.').pack(anchor='w', padx=14, pady=(0, 2))
    head = tk.StringVar()
    tk.Label(win, textvariable=head, bg=panel, fg=ink, font=('Segoe UI', 10, 'bold'), justify='left').pack(anchor='w', padx=14, pady=2)
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    columns = (('n', 'N°', 4), ('a', 'Bord 1 · étape', 26), ('b', 'Bord 2', 22), ('seam', 'Couture', 8), ('len', 'Longueurs (mm)', 14),
               ('diff', 'Écart (mm)', 9), ('crans', 'Crans en face', 12), ('state', 'État', 26))
    table = ttk.Treeview(area, columns=[k for k, _, _ in columns], show='headings', height=11, selectmode='browse')
    for key, label, width in columns:
        table.heading(key, text=label)
        table.column(key, width=width * 7, anchor='center' if key == 'n' else 'w', stretch=key in ('a', 'b', 'state'))
    for state, colour in COLOUR.items():
        table.tag_configure(state, foreground=colour)
    table.tag_configure('etape', foreground=ink)
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    moves = tk.Frame(area, bg=panel)
    moves.pack(side='right', fill='y', padx=(6, 0))
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='left', fill='y')
    marks = app.__dict__.setdefault('_bag_marks', {})

    def refill():
        rows = montage_rows(app)
        marks.update(rows=rows, key=_fingerprint(app))
        chosen = marks.get('chosen')
        if chosen is not None and chosen >= len(rows):
            marks['chosen'] = chosen = None
        table.delete(*table.get_children())
        for n, r in enumerate(rows):
            if r['state'] == 'etape':
                table.insert('', 'end', iid=str(n), values=(r['n'], r['text'], '', '', '', '', '', 'étape'), tags=('etape',))
            else:
                table.insert('', 'end', iid=str(n), values=(r['n'], r['a_text'], r['b_text'], seam_text(r['seam']), r['lengths'], r['diff'],
                                                            r['crans'], r['text']), tags=(r['state'],))
        if chosen is not None:
            table.selection_set(str(chosen))
            table.see(str(chosen))
        pairs = [r for r in rows if r['state'] != 'etape']
        count = {s: sum(1 for r in pairs if r['state'] == s) for s in COLOUR}
        steps = len(rows) - len(pairs)
        if not pairs:
            head.set('Aucun assemblage gardé : « Paires probables… » (bords de même longueur aux crans en face), ou « Ajouter un '
                     'assemblage » puis cliquer les deux bords cousus ensemble.')
        else:
            parts = [f'{count["ok"]} bon{"s" if count["ok"] > 1 else ""}']
            if count['bad']:
                parts.append(f'{count["bad"]} avec un écart de plus de 0,5 mm')
            if count['crans']:
                parts.append(f'{count["crans"]} aux crans pas tous en face')
            if count['gone'] + count['changed']:
                parts.append(f'{count["gone"] + count["changed"]} à refaire')
            head.set(f'{len(pairs)} assemblage{"s" if len(pairs) > 1 else ""} : ' + ', '.join(parts)
                     + (f' ; {steps} étape{"s" if steps > 1 else ""} entre eux' if steps else '') + '.')
        draw_bag(app)

    def chosen_row():
        picked = table.selection()
        return int(picked[0]) if picked else None

    def picked(e=None):
        n = chosen_row()
        again = n == marks.get('chosen')   # (second review: the list made again chose it again: what the status says stays)
        marks['chosen'] = n
        draw_bag(app)
        if not again and n is not None and n < len(marks.get('rows') or ()):
            r = marks['rows'][n]
            if r['state'] == 'etape':
                app.status.set(f'Étape {r["n"]} : {r["text"]}')
            else:
                app.status.set(f'{r["n"]}. {r["a_text"]} ↔ {r["b_text"]} : ' + (f'{r["lengths"]} mm {seam_words(r["seam"])}, écart {r["diff"]}, crans {r["crans"]} · ' if r['lengths'] else '') + r['text'].lstrip('✓✗⚠— '))
    table.bind('<<TreeviewSelect>>', picked)

    def writable():
        if hasattr(app, 'licence_complet') and not app.licence_complet():
            app.read_only_said()
            return False
        return True

    def opened(e=None):
        n = chosen_row()
        rows = entries(app)
        if n is None or n >= len(rows):
            return 'break'
        if 'etape' in rows[n]:   # a step: its text changed
            if not writable():
                return 'break'
            text = simpledialog.askstring('Étape de montage', 'Étape', initialvalue=rows[n]['etape'], parent=win)
            if text is not None and clean_step(text) and clean_step(text) != rows[n]['etape']:
                rows[n] = dict(etape=clean_step(text))
                _store(app, rows)
                remember_steps(app, [text])   # 0.19.27 (second review: only a step changed, typed by him)
                refill()
            return 'break'
        if not open_pair(app, rows[n]):
            app.status.set('Pièce introuvable ou côtés changés : refaire ce contrôle (Ajouter un assemblage), puis retirer celui-ci.')
        return 'break'
    table.bind('<Double-1>', opened)

    def moved(step):
        """▲ ▼: the line chosen one place up or down in the order of montage"""
        if not writable():
            return
        n = chosen_row()
        rows = entries(app)
        if n is None or n >= len(rows):
            app.status.set('Choisir dans la liste la ligne à monter ou descendre.')
            return
        m = n + step
        if not 0 <= m < len(rows):
            return
        rows[n], rows[m] = rows[m], rows[n]
        marks['chosen'] = m
        _store(app, rows)
        refill()
    app.button(moves, '▲', lambda: moved(-1), kind='secondary').pack(fill='x', pady=(0, 4))
    app.button(moves, '▼', lambda: moved(1), kind='secondary').pack(fill='x')

    def removed():
        if not writable():
            return
        n = chosen_row()
        rows = entries(app)
        if n is None or n >= len(rows):
            app.status.set('Choisir dans la liste l’assemblage ou l’étape à retirer.')
            return
        gone = rows.pop(n)
        st = app.__dict__.get('assembly_state')
        if 'a' in gone and st and st.get('kept') == _ident(gone):   # (review: only the check whose pair it was forgets it)
            st.update(kept=None, added=False)
        marks['chosen'] = None
        _store(app, rows)
        refill()
        app.status.set('Étape retirée de la liste.' if 'etape' in gone else 'Assemblage retiré de la liste.')

    def added():
        start(app)
        app.status.set("Contrôle d'assemblage : cliquer le bord de la 1re pièce, puis le bord cousu dessus (gardé dans la liste du sac).")

    def step():
        """0.19.26 « Étape… »: a step between the seams"""
        if writable():
            steps_window(app, chosen_row())

    def fiche():
        """0.19.25: the fiche « Montage » (« Assemblages ») in its tab at the bottom (the list, to print)."""
        if not entries(app):
            app.status.set('Aucun assemblage gardé : rien à mettre sur la fiche.')
            return
        if hasattr(app, 'add_fiche'):
            app.add_fiche('fiche:assemblages')

    def done():
        for name in ('_proposal_window', '_steps_window'):
            other = app.__dict__.get(name)
            if other is not None and other.winfo_exists():
                other._done()
        clear_bag(app)
        win.destroy()
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Ajouter un assemblage', added).pack(side='left')
    app.button(foot, 'Paires probables…', lambda: propose(app), kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.25
    app.button(foot, 'Étape…', step, kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.26
    app.button(foot, 'Crans en face', lambda: writable() and crans_in_front_bag(app), kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.27
    app.button(foot, 'Retirer de la liste', removed, kind='secondary').pack(side='left', padx=6)
    app.button(foot, 'Fermer', done).pack(side='right')
    app.button(foot, 'Fiche', fiche, kind='secondary').pack(side='right', padx=6)   # 0.19.25: the fiche « Montage »
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win.bind('<FocusIn>', lambda e: refill() if e.widget is win else None)   # back from the plan: checked again
    win._refill = refill
    win._table = table
    win._removed = removed
    win._opened = opened
    win._moved = moved
    win._step = step
    win._done = done
    win._head = head
    win._fiche = fiche
    refill()
    return win
