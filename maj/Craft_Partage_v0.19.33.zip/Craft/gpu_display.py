"""0.19.31 (« On pourrait faire tourner sous carte graphique pareil ? » after « mozart n'a pas de lag », go of 15/11/2026):
while the view moves (the wheel, the view moved), the plan is drawn by the graphics card (Direct2D, Windows) in a window
laid over the canvas, smoothed at each notch as Mozart draws it. Meanwhile Tk draws nothing (its view is moved away from
its items, xview: the items themselves are scaled and moved as before, everything else sees them as before), so neither
its lines nor its picture are made at each notch. The card's picture goes once Tk's own smoothed picture is shown.

The card draws what Tk would show: the items read once when the gesture starts (each notch only changes the transform
the card applies, the « G » of a batch), the items made since (pieces coming into view) read when they come, the cross,
the grips and what follows the pointer read again at each picture. The layers of the smoothed display: the zones, the
smoothed lines, the other items, then those over the plan. What the card cannot draw (a picture, an arrow, a curve
smoothed by Tk…), « Zoom par la carte graphique » off, another system, an error: as before (Tk's own lines)."""
import math,sys,time
from array import array

STATUS={}
SHIFT=1<<26      # px Tk's view is moved away from its items while the card draws
WAIT=1.5         # s the card's picture waits at most for Tk's smoothed picture once the gesture is over
QUIET=3.         # s without a gesture: the card's picture goes (it never stays over the canvas)
POLL=20          # ms between two looks at the smoothing under way, once the gesture is over
STIPPLES={'gray12':.125,'gray25':.25,'gray50':.5,'gray75':.75}
CAPS={'butt':0,'projecting':1,'round':2}
JOINS={'miter':0,'bevel':1,'round':2}
ANCHORS={'center':(.5,.5),'n':(.5,0.),'s':(.5,1.),'w':(0.,.5),'e':(1.,.5),'nw':(0.,0.),'ne':(1.,0.),'sw':(0.,1.),'se':(1.,1.)}
JUSTIFY={'left':0,'right':1,'center':2}   # DWRITE_TEXT_ALIGNMENT: leading, trailing, center
IDENTITY=(1.,0.,0.,1.,0.,0.)
UNDER={'prep_fill'}   # (display_render.UNDER: the zones under the smoothed picture)
# the base and the grid: drawn again by Tk when the wheel stops (quick_settle): read again at each picture, under the plan
BASE={'guides','grid'}
LAYERS=5   # 0 the zones, 1 the base and the grid, 2 the smoothed lines, 3 the plan's other items, 4 what is over the plan
# what tools draw again as the pointer moves, besides the app's own lists (read again at each picture: never the whole plan)
MOVING={'notch_preview','grip_menu','trim_path','route_marks','edit_preview','notch_host','moving','copy_preview','tracking',
        'prep_hover','assembly_preview','stretch_preview','array_preview','corner_preview','pick_selection','cran_copy',
        'bg_preview','contours_check','copy_selection','mirror_selection','selection_box','xform','ruler_value'}   # (review)
# 0.19.33: what Tk only shifts as the pointer moves (Déplacer: the objects moved; Copier: the copy to place): read once, then
# drawn shifted as one of them is (its first point), never read again at each picture
MOVERS={'moving','copy_preview'}
MOVER=10   # their rows' layer: MOVER + the layer they would be in
# 0.19.33: the selection rectangles (craft_refined.draw_selection_box) drawn by the card while they follow the pointer: their
# tint (a picture as large as the plan, for Tk) drawn as the rectangle it shows, what they light (« :lit ») read once each
BOXES=('selection_box','cran_copy','mirror_selection','copy_selection','pick_selection','xform')
LIT=24     # the rows' layer of what a rectangle lights
FACTORY=[None]   # what makes the card's drawer of a canvas (Direct2D under Windows; the tests: a recorder)
SEEN=[None,0]    # the card's picture seen on the screen in this session (True), or not yet (None); the looks without answer
SEEN_AFTER=150   # ms after it is shown, the mark read back
SEEN_TRIES=3     # looks without answer (colours changed by the screen…), then trusted
MARK=8           # px of the mark (the canvas's colour but for its green, MARK_SHIFT apart), in the corner at the bottom right
MARK_SHIFT=8
DISABLED=[None]  # why the card is not used any more in this session (an error)


class Unsupported(Exception):
    """Something shown that the card does not draw: Tk draws, as before."""


# --- transforms (x' = a x + c y + e, y' = b x + d y + f: Direct2D's matrix) --------------------------------------------
def then(n,m):
    """``n`` then ``m``."""
    return (n[0]*m[0]+n[1]*m[2],n[0]*m[1]+n[1]*m[3],n[2]*m[0]+n[3]*m[2],n[2]*m[1]+n[3]*m[3],n[4]*m[0]+n[5]*m[2]+m[4],n[4]*m[1]+n[5]*m[3]+m[5])


def inverse(m):
    a,b,c,d,e,f=m;det=a*d-b*c
    return (d/det,-b/det,-c/det,a/det,(c*f-d*e)/det,(b*e-a*f)/det)


def apply(m,x,y):return (m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5])


def scale_of(m):return math.sqrt(abs(m[0]*m[3]-m[1]*m[2]))


def change_of(change):
    """A notch of the wheel ('zoom', x, y, k: Tk's scale about (x, y)), the view moved ('move', dx, dy)."""
    if change[0]=='zoom':
        _,x,y,k=change;return (k,0.,0.,k,x*(1-k),y*(1-k))
    return (1.,0.,0.,1.,float(change[1]),float(change[2]))


# --- what Tk shows, read in one call --------------------------------------------------------------------------------
_PROCS=r"""proc craft_gpu_font {f} {
    # (his PC, 0.19.32) the size Tk really draws: its line's height over the family's own (at 100 px), never the size
    # asked (Windows draws a font of « -1 » pixel far larger)
    global craft_gpu_fonts craft_gpu_ratio
    if {![info exists craft_gpu_fonts($f)]} {
        set a [font actual $f]
        set family [dict get $a -family]
        if {![info exists craft_gpu_ratio($family)]} {
            set craft_gpu_ratio($family) [expr {max(.5,[font metrics [list $family -100] -linespace] / 100.0)}]
        }
        set space [font metrics $f -linespace]
        set craft_gpu_fonts($f) [list $family [expr {-$space / $craft_gpu_ratio($family)}] [dict get $a -weight] [dict get $a -slant] $space]
    }
    return $craft_gpu_fonts($f)
}
proc craft_gpu_item {c i t} {
    switch -- $t {
        line {
            if {[$c itemcget $i -arrow] ne "none"} {return ?}
            set sm [$c itemcget $i -smooth]
            if {$sm ne "0" && $sm ne "false" && $sm ne ""} {return ?}
            set f [$c itemcget $i -fill]
            if {$f eq ""} {return ""}
            return [list line $f {} [$c itemcget $i -width] [$c itemcget $i -dash] [$c itemcget $i -capstyle] [$c itemcget $i -joinstyle] [$c itemcget $i -stipple] {}]
        }
        polygon {
            set sm [$c itemcget $i -smooth]
            if {$sm ne "0" && $sm ne "false" && $sm ne ""} {return ?}
            set f [$c itemcget $i -fill];set o [$c itemcget $i -outline]
            if {$f eq "" && $o eq ""} {return ""}
            return [list polygon $f $o [$c itemcget $i -width] [$c itemcget $i -dash] butt [$c itemcget $i -joinstyle] [$c itemcget $i -stipple] [$c itemcget $i -outlinestipple]]
        }
        rectangle - oval {
            set f [$c itemcget $i -fill];set o [$c itemcget $i -outline]
            if {$f eq "" && $o eq ""} {return ""}
            return [list $t $f $o [$c itemcget $i -width] [$c itemcget $i -dash] butt miter [$c itemcget $i -stipple] [$c itemcget $i -outlinestipple]]
        }
        text {
            set f [$c itemcget $i -fill];set s [$c itemcget $i -text]
            if {$f eq "" || $s eq ""} {return ""}
            if {[$c itemcget $i -width] > 0} {return ?}
            set font [$c itemcget $i -font]
            set w 0;set n 0
            foreach line [split $s \n] {set m [font measure $font $line];if {$m > $w} {set w $m};incr n}
            lassign [craft_gpu_font $font] family size weight slant space
            return [list text $f {} 0 {} butt miter [$c itemcget $i -stipple] {} $family $size $weight $slant [$c itemcget $i -anchor] [$c itemcget $i -angle] [$c itemcget $i -justify] $w [expr {$n*$space}]]
        }
        default {return ?}
    }
}
proc craft_gpu_layer {c i t tags} {
    if {$t ne "line" && $t ne "polygon"} {return 3}
    if {[$c itemcget $i -stipple] ne ""} {return 3}
    set tags [lsearch -all -inline -not -regexp $tags {^(zoom:|_obj|current$)}]
    # (review) a zone that Déplacer or a copy to place shifts stays a zone: under every line, as Tk keeps it
    set zone [lsearch -all -inline -not -regexp $tags {^(moving|copy_preview)$}]
    if {$t eq "polygon" && [$c itemcget $i -fill] ne "" && [llength $zone] && [lsearch -exact -not $zone prep_fill] < 0} {return 0}
    if {[craft_allowed $tags]} {return 2}
    return 3
}
proc craft_gpu_scene {c top under smooth over base mover lit littop} {
    # (review) what is read again at each picture found by Tk itself (tag expressions $over, $base), the others only
    # looked at by their id: most items cost one test
    global craft_brows
    set cs [$c cget -state]
    foreach i $under {set below($i) 1}
    if {$smooth && [info exists craft_brows($c)]} {set known $craft_brows($c)} else {set known {}}
    foreach i [$c find withtag $base] {set vol($i) 2}
    foreach i [$c find withtag $over] {set vol($i) 1}
    set movers {}
    if {$mover ne ""} {foreach i [$c find withtag $mover] {set vol($i) 3;lappend movers $i}}
    set lits {}
    if {$lit ne ""} {foreach i [$c find withtag $lit] {set vol($i) 4;lappend lits $i}}
    foreach i [$c find withtag {_smooth_display||_smooth_next||background_image}] {set picture($i) 1}
    set meta {};set bin [binary format a0 {}];set texts {};set plan 0;set added 0;set high $top;set gone {}
    foreach i [$c find all] {
        if {[info exists picture($i)]} continue
        if {[info exists vol($i)]} {
            set v $vol($i)
            if {$v == 3 && $top} continue
            if {$v == 4 && $i <= $littop} continue
        } else {
            set v 0
            incr plan
            if {$i <= $top} continue
            incr added
            if {$i > $high} {set high $i}
        }
        set t [$c type $i]
        set st [$c itemcget $i -state]
        if {$st eq ""} {set st $cs}
        if {$t eq "image"} {
            # (never drawn by the card: hidden, nothing to draw; shown: Tk draws, as before; 0.19.33: a rectangle's tint,
            # drawn by the card as the rectangle it shows)
            if {$st eq "hidden"} continue
            if {[lsearch -glob [$c gettags $i] *:tint] >= 0} continue
            return [list ? "$t $i [$c gettags $i]"]
        }
        if {!$v && [dict exists $known $i] && [dict get $known $i] ne ""} {
            if {$st eq "hidden" && ![info exists below($i)]} {lappend gone $i}
            continue
        }
        if {$st eq "hidden" && ![info exists below($i)]} continue
        set e [craft_gpu_item $c $i $t]
        if {$e eq ""} continue
        if {$e eq "?"} {return [list ? "$t $i [$c gettags $i]"]}
        if {$v == 1} {set layer 4} elseif {$v == 2} {set layer 1} elseif {$v == 3} {set layer [expr {10 + [craft_gpu_layer $c $i $t [$c gettags $i]]}]} elseif {$v == 4} {set layer 24} else {set layer [craft_gpu_layer $c $i $t [$c gettags $i]]}
        set xy [$c coords $i]
        lappend meta "$i\x1f$layer\x1f[llength $xy]\x1f[join $e \x1f]"
        append bin [binary format d* $xy]
        if {$t eq "text"} {lappend texts [$c itemcget $i -text]}
    }
    return [list [join $meta \x1e] $bin $texts $plan $added $high $gone $movers $lits]
}"""


def _procs(app):
    canvas=app.canvas;tk=canvas.tk
    __import__('display_render')._procs(canvas)   # (craft_allowed: what the smoothing smooths)
    if not tk.call('info','procs','craft_gpu_scene'):
        tk.eval(_PROCS)
    if canvas.__dict__.get('_gpu_over') is None:
        tags=set(app.SCREEN_TAGS)|set(app.FIXED_TEXT_TAGS)|set(app.KEEP_SIZE_TAGS)|set(app.OVERLAYS)|MOVING
        canvas._gpu_over='||'.join(sorted(tags-BASE-MOVERS));canvas._gpu_base='||'.join(sorted(BASE));canvas._gpu_mover='||'.join(sorted(MOVERS));canvas._gpu_lit='||'.join(t+':lit' for t in BOXES)
    return tk


class Row:
    __slots__=('item','layer','kind','fill','outline','width','dash','cap','join','alpha','line_alpha','xy','text','font','anchor','angle','justify','box')


# 0.19.33: the background picture drawn by the card too (it was Tk then: the wheel and the view moved as before 0.19.31): the
# picture as Tk shows it (faded once, cropped), at PICTURE_MOST pixels at most along its longest side, made once (kept with
# the app) and given to the card under everything; Tk's own picture, at the screen's size, comes with its drawing once the
# gesture is over.
PICTURE_MOST=2048


class Picture:
    __slots__=('key','width','height','data')


def picture(app):
    """(Picture, its rectangle on the plan in mm (x, y, w, h)) of the background picture shown; None: none."""
    import background_ui,backdrop
    b=background_ui.current(app)
    if not b or not background_ui.visible(app):
        app.__dict__.pop('_card_picture',None)   # (review: up to 16 MB, not kept once the picture is gone or hidden)
        return None
    c=app.canvas
    st=app.__dict__.get('bg_tool');crop=background_ui.WHOLE if st and st['kind']=='crop' else background_ui.kept_crop(app)
    x,y,w,h=background_ui.cut(background_ui.frame_rect(app),crop)
    pw,ph=b['pixels'];l,t,r,bm=crop;src=(l*pw,t*ph,max(1e-3,(r-l)*pw),max(1e-3,(bm-t)*ph))
    k=min(1.,PICTURE_MOST/max(src[2],src[3],1.))
    size=(max(1,round(src[2]*k)),max(1,round(src[3]*k)))
    colour=tuple(round(v/257) for v in c.winfo_rgb(c.cget('background')))
    key=(len(b['data']),b['data'][:48],b['data'][-48:],tuple(round(v,3) for v in src),size,round(b['opacity'],3),colour)
    kept=app.__dict__.get('_card_picture')
    if kept is None or kept.key!=key:
        try:data=backdrop.require().view(backdrop.faded(b,colour),src,size,1.,colour)
        except (OSError,ValueError,MemoryError) as exc:raise Unsupported('image de fond : '+str(exc)[:60])   # (review: Tk's own picture says it; never the card cut for the session)
        rgb=bytes(data[len(b'P6 %d %d 255\n'%size):])   # (review: bytes, not a memoryview: its strided slices 4 × slower, 98 → 24 ms at 2048 × 1536)
        n=size[0]*size[1]
        if len(rgb)!=3*n:raise Unsupported('image de fond')
        bgra=bytearray(4*n);bgra[0::4]=rgb[2::3];bgra[1::4]=rgb[1::3];bgra[2::4]=rgb[0::3];bgra[3::4]=b'\xff'*n
        kept=Picture();kept.key=key;kept.width,kept.height=size;kept.data=bytes(bgra);app._card_picture=kept
    return kept,(x,y,w,h)


def _bytes(blob):
    from display_render import plain
    if isinstance(blob,str):return blob.encode('latin-1')
    if not isinstance(blob,bytes):return bytes(blob) if isinstance(blob,(bytearray,memoryview)) else plain(blob).encode('latin-1')
    return blob


def read(app,top,under,littop=0):
    """The items shown after id ``top`` (the plan's: all at 0) and those over the plan (always), in stacking order: (rows,
    count of the plan's items, how many came after ``top``, the highest id of the plan's). Unsupported: something the
    card does not draw. At 0, the lines the smoothing smooths come from its own reading (display_render.read_plan: their
    values kept by item, only their coordinates read again after a zoom), drawn as it draws them (round joins)."""
    from display_render import plain,read_plan
    canvas=app.canvas;tk=_procs(app)
    colours=canvas.__dict__.setdefault('_gpu_colours',{})
    def rgb(value):
        if not value:return None
        v=colours.get(value)
        if v is None:v=colours[value]=tuple(c/65535. for c in canvas.winfo_rgb(value))
        return v
    smoothed=[]
    if not top:
        meta,blob=read_plan(canvas)
        numbers=array('d');numbers.frombytes(_bytes(blob));at=0
        for line in meta.split('\x1e') if meta else ():
            f=line.split('\x1f');n=int(f[-1]);r=Row()
            r.item=int(f[0]);r.kind=f[1];tags=set(f[2].split('\x1d')) if f[2] else set()
            r.fill=rgb(f[3]);r.outline=rgb(f[4]);r.width=max(1.,float(f[5] or 1));r.dash=_dash(f[6]) if r.kind=='line' else None
            r.cap=0;r.join=2;r.alpha=r.line_alpha=1.
            r.layer=0 if r.kind=='polygon' and r.fill is not None and tags and tags<=UNDER else 2
            r.xy=numbers[at:at+n];at+=n
            if not tags&BASE:smoothed.append(r)
    out=tk.splitlist(tk.call('craft_gpu_scene',canvas._w,top,tuple(under),0 if top else 1,canvas._gpu_over,canvas._gpu_base,canvas._gpu_mover,canvas._gpu_lit,littop))
    if plain(out[0])=='?':raise Unsupported(plain(out[1]))
    meta,blob,texts,plan,added,high,gone,movers,lits=out
    canvas._gpu_lits=[int(v) for v in tk.splitlist(lits)]   # (0.19.33: what the rectangles light now)
    if not top and smoothed:
        movers={int(v) for v in tk.splitlist(movers)}
        if movers:smoothed=[r for r in smoothed if r.item not in movers]   # (0.19.33: read below with their own layer)
    meta=plain(meta)
    texts=[plain(t) for t in tk.splitlist(texts)]
    numbers=array('d');numbers.frombytes(_bytes(blob))
    if smoothed:
        gone={int(v) for v in tk.splitlist(gone)}
        if gone:smoothed=[r for r in smoothed if r.item not in gone]
    rows=smoothed;at=0;k=0
    for line in meta.split('\x1e') if meta else ():
        f=line.split('\x1f');r=Row();n=int(f[2])
        r.item=int(f[0]);r.layer=int(f[1]);r.kind=f[3];r.fill=rgb(f[4]);r.outline=rgb(f[5])
        r.width=max(1.,float(f[6] or 1));r.dash=_dash(f[7]);r.cap=CAPS.get(f[8],0);r.join=JOINS.get(f[9],2)
        r.alpha=STIPPLES.get(f[10],.5) if f[10] else 1.;r.line_alpha=STIPPLES.get(f[11],.5) if f[11] else 1.
        r.xy=numbers[at:at+n];at+=n
        if r.kind=='text':
            r.text=texts[k];k+=1
            family,size,weight,slant=f[12],float(f[13]),f[14],f[15]
            px=-size if size<0 else size*_points(canvas)
            r.font=(family,px,700 if weight=='bold' else 400,2 if slant=='italic' else 0)
            r.anchor=ANCHORS.get(f[16],(.5,.5));r.angle=float(f[17] or 0);r.justify=JUSTIFY.get(f[18],0)
            r.box=(float(f[19]),float(f[20]))
        rows.append(r)
    return rows,int(plain(plan)),int(plain(added)),int(plain(high))


def _points(canvas):
    """Tk's pixels in a point."""
    v=canvas.__dict__.get('_gpu_points')
    if v is None:
        try:v=float(canvas.tk.call('tk','scaling'))
        except Exception:v=96/72
        canvas._gpu_points=v
    return v


def _dash(value):
    if not value:return None
    try:out=tuple(float(v) for v in value.split())
    except ValueError:raise Unsupported('tirets '+value)
    if not out or not any(out):return None
    return out*2 if len(out)%2 else out


# --- the items as the card's commands ---------------------------------------------------------------------------------
def _figure(r):
    """The points of a row, closed or not: (flat coordinates, closed)."""
    xy=r.xy
    if r.kind=='rectangle':
        x0,y0,x1,y1=xy;return [x0,y0,x1,y0,x1,y1,x0,y1],True
    if r.kind=='oval':
        x0,y0,x1,y1=xy;cx,cy,rx,ry=(x0+x1)/2,(y0+y1)/2,abs(x1-x0)/2,abs(y1-y0)/2
        n=24 if max(rx,ry)<8 else 48 if max(rx,ry)<60 else 96
        out=[]
        for i in range(n):
            a=2*math.pi*i/n;out+=[cx+rx*math.cos(a),cy+ry*math.sin(a)]
        return out,True
    return list(xy),r.kind=='polygon'


def _box(points):
    xs=points[0::2];ys=points[1::2]
    return (min(xs),min(ys),max(xs),max(ys))


class _Run:
    """Consecutive items of one style, drawn as one geometry each for their fills and their lines (their order kept:
    a fill never covers a line of the same run: what is checked for; small boxes in a grid of CELL px, the long ones
    (more than LONG cells across: review, a zone 19 000 px wide) checked one by one)."""
    CELL=64
    LONG=8
    def __init__(self,key,fill,line):
        self.key=key;self.fill=fill;self.line=line;self.fills=[];self.lines=[];self.closed=[];self.ids=[];self.cells={}
        self.small=[];self.long=[]
    def _long(self,box):
        c=self.CELL*self.LONG
        return box[2]-box[0]>c or box[3]-box[1]>c
    def meets(self,box):
        if not self.fill:return False
        over=lambda b:b[0]<=box[2] and box[0]<=b[2] and b[1]<=box[3] and box[1]<=b[3]
        if any(over(b) for b in self.long):return True
        if self._long(box):return any(over(b) for b in self.small)
        c=self.CELL
        for gx in range(int(box[0]//c),int(box[2]//c)+1):
            for gy in range(int(box[1]//c),int(box[3]//c)+1):
                for b in self.cells.get((gx,gy),()):
                    if over(b):return True
        return False
    def add(self,item,points,closed,box):
        self.ids.append(item)
        if self.fill:
            self.fills.append(points)
            if self._long(box):self.long.append(box)
            else:
                self.small.append(box);c=self.CELL
                for gx in range(int(box[0]//c),int(box[2]//c)+1):
                    for gy in range(int(box[1]//c),int(box[3]//c)+1):self.cells.setdefault((gx,gy),[]).append(box)
        if self.line:self.lines.append(points);self.closed.append(closed)


def commands(renderer,rows):
    """The commands of rows by layer: [layer] → [('fill', geometry, rgba) | ('stroke', geometry, rgba, width, dash, cap,
    join) | ('text', layout, rgba, x, y, angle, left, top)]; the geometries and layouts made (to release)."""
    layers=[[] for _ in range(LAYERS)];made=[];run=None
    def flush():
        nonlocal run
        if run is None:return
        layer=layers[run.key[0]]
        if run.fills:
            g=renderer.path(run.fills,[True]*len(run.fills),True,run.ids);made.append(g);layer.append(('fill',g,run.fill))
        if run.lines:
            g=renderer.path(run.lines,run.closed,False,run.ids);made.append(g)
            _,_,_,_,width,dash,cap,join=run.key;layer.append(('stroke',g,run.line,width,dash,cap,join))
        run=None
    for r in rows:
        if r.kind=='text':
            flush()
            if r.fill is None:continue
            layout=renderer.text(r.text,r.font,r.justify,r.box,r.item);made.append(layout)
            w,h=r.box;ax,ay=r.anchor
            layers[r.layer].append(('text',layout,r.fill+(r.alpha,),r.xy[0],r.xy[1],r.angle,-ax*w,-ay*h))
            continue
        points,closed=_figure(r)
        if len(points)<4:continue
        fill=r.fill+(r.alpha,) if r.fill is not None and r.kind!='line' else None
        ink=r.fill if r.kind=='line' else r.outline
        line=ink+(r.alpha if r.kind=='line' else r.line_alpha,) if ink is not None else None
        if fill is None and line is None:continue
        key=(r.layer,r.kind=='line',fill,line,r.width,r.dash,r.cap,r.join)
        box=_box(points)
        if run is None or run.key!=key or run.meets(box):
            flush();run=_Run(key,fill,line)
        run.add(r.item,points,closed,box)
    flush()
    return layers,made


# --- the mirror of a canvas while the view moves --------------------------------------------------------------------
class Mirror:
    PLAN=(0,2,3)    # the layers read once (then only moved by the card), the others read again at each picture
    def __init__(self,app,renderer):
        self.app=app;self.canvas=app.canvas;self.renderer=renderer
        self.state='idle'   # 'active' (the gesture), 'settling' (waiting for Tk's picture), 'idle'
        self.batches=[]     # (inverse of G when read, layers)
        self.made=[];self.volatile=[];self.G=IDENTITY;self.top=0;self.plan=0;self.drawn=None;self.shifted=False
        self.last=0.;self.since=0.;self.timer=None;self.token=0;self.size=None;self.background=None;self.soon=None
        self.kept=False;self.epoch=None;self.captures=0;self.marking=False;self.mark=None;self.gesture=0
        self.picture=None   # 0.19.33: (Picture, its rectangle on the canvas when read) of the background picture
        self.mover=None     # 0.19.33: (an item moved, its first point when read, its layers) of what Tk shifts (MOVERS)
        self.lit={};self.littop=0   # 0.19.33: what the rectangles light (item: (its layers, its handles, inverse of G when read)), the highest read
        self.refused=None   # (review) the drawing (_drawn_count) the card could not draw: a rectangle, Déplacer not read again at each move
    # Tk's view, away from its items while the card draws (nothing for Tk to draw), back after
    def away(self):
        if self.shifted:return
        c=self.canvas
        if str(c.cget('xscrollincrement'))!='1':c.configure(xscrollincrement=1)
        c.xview_scroll(SHIFT,'units');self.shifted=True
    def back(self):
        if not self.shifted:return
        self.shifted=False
        try:
            c=self.canvas;x=int(round(float(c.canvasx(0))))
            if x:c.xview_scroll(-x,'units')
        except Exception:pass
    def release(self):
        r=self.renderer
        r.forget()   # (never a picture drawn again with what goes)
        for h in self.made+self.volatile+([self.mark[0]] if self.mark else []):r.release(h)
        for entry in self.lit.values():
            for h in entry[1]:r.release(h)
        self.made=[];self.volatile=[];self.batches=[];self.kept=False;self.mark=None;self.lit={};self.littop=0
        self.mover=None   # (review: its layers' handles released with made; kept, it refused the next gesture's wheel)
    def corner(self):
        """Where the mark is (canvas pixels): its middle."""
        w,h=self.size;return (w-2-MARK//2,h-2-MARK//2)
    def colours(self):
        """(the canvas's colour, the mark's) in 0…255."""
        r,g,b=(round(v*255) for v in self.background)
        return (r,g,b),(r,g+MARK_SHIFT if g+MARK_SHIFT<=255 else g-MARK_SHIFT,b)
    def marked(self):
        """The mark: (its geometry, its colour)."""
        if self.mark is None:
            w,h=self.size;x0,y0,x1,y1=w-2-MARK,h-2-MARK,w-2,h-2
            mark=self.colours()[1]
            self.mark=(self.renderer.path([[x0,y0,x1,y0,x1,y1,x0,y1]],[True],True),tuple(v/255. for v in mark)+(1.,))
        return self.mark
    def capture(self):
        """Everything read again (the gesture starts; the plan was drawn again)."""
        self.release();self.captures+=1
        c=self.canvas;under=c.__dict__.get('_smooth_hidden') or () if c.find_withtag('_smooth_display') else ()
        start=time.perf_counter()
        rows,self.plan,_,self.top=read(self.app,0,under)
        layers,made=commands(self.renderer,[r for r in rows if r.layer in self.PLAN])
        self.made=made;self.G=IDENTITY;self.batches=[(IDENTITY,layers)];self.kept=True
        self.mover=None
        moving=[r for r in rows if r.layer>=MOVER]
        if moving:
            for r in moving:r.layer-=MOVER
            mlayers,mmade=commands(self.renderer,moving);self.made+=mmade
            first=moving[0];self.mover=(first.item,(first.xy[0],first.xy[1]),mlayers)
            gone={id(r) for r in moving};rows=[r for r in rows if id(r) not in gone]
        rows=self.lighted(rows)
        self.picture=None
        got=picture(self.app)
        if got:
            if not getattr(self.renderer,'bitmaps',False):raise Unsupported('image de fond')
            pic,(x,y,w,h)=got;x0,y0=self.app.to_screen((x,y));x1,y1=self.app.to_screen((x+w,y+h))
            self.picture=(pic,(min(x0,x1),min(y0,y1),max(x0,x1),max(y0,y1)))
        self.drawn=c.__dict__.get('_drawn_count')
        self.size=(c.winfo_width(),c.winfo_height())
        self.background=tuple(v/65535. for v in c.winfo_rgb(c.cget('background')))
        _timed('carte graphique : lecture du plan',start)
        return rows
    def lighted(self,rows):
        """0.19.33: what the rectangles light read once each (rows of LIT, one batch an item), what they no longer light
        dropped; the other rows."""
        new=[r for r in rows if r.layer==LIT]
        for r in new:
            r.layer=4;layers,made=commands(self.renderer,[r]);self.lit[r.item]=(layers,made,inverse(self.G));self.littop=max(self.littop,r.item)   # (review: Tk scales and moves them with the plan)
        now=set(self.canvas.__dict__.get('_gpu_lits') or ())
        for item in [i for i in self.lit if i not in now]:
            for h in self.lit.pop(item)[1]:self.renderer.release(h)
        if not new:return rows
        ids={id(r) for r in new};return [r for r in rows if id(r) not in ids]
    def holds_drawing(self):
        """The plan read still holds for the drawing on the canvas (nothing drawn again since, the same size)."""
        c=self.canvas
        return self.kept and c.__dict__.get('_drawn_count')==self.drawn and (c.winfo_width(),c.winfo_height())==self.size
    def holds(self):
        """The plan read for the last gesture still holds for this one: nothing drawn again since, the same size, and Tk's
        items changed only by the gestures the card followed (the view changed once since: this notch or move)."""
        return self.holds_drawing() and self.epoch is not None and self.app.__dict__.get('_view_epoch',0)==self.epoch+1
    def frame(self,change=None,fresh=False):
        """The card's picture of Tk's items now: ``change``, the change of Tk's items since the last picture (by the
        wheel or the view moved); what came since read, what follows the pointer read again. ``fresh``: the gesture
        starts (the plan read for the last one kept if it holds)."""
        c=self.canvas
        if self.mover and change is not None:raise Unsupported('vue changée pendant un déplacement')   # (0.19.33: Tk, as before)
        shift=None;reads=self.captures
        if self.mover and not (fresh and not self.holds() or c.__dict__.get('_drawn_count')!=self.drawn or not self.kept):
            xy=c.coords(self.mover[0])   # 0.19.33: where Tk has shifted what moves
            if len(xy)<2:self.kept=False   # (made again: read again)
            else:shift=(1.,0.,0.,1.,float(xy[0])-self.mover[1][0],float(xy[1])-self.mover[1][1])
        if fresh and not self.holds() or c.__dict__.get('_drawn_count')!=self.drawn or not self.kept:rows=self.capture()
        elif (c.winfo_width(),c.winfo_height())!=self.size:raise Unsupported('taille')   # (resized: <Configure> stops it too)
        else:
            if change is not None:self.G=then(self.G,change_of(change))
            rows,plan,added,high=read(self.app,self.top,(),self.littop)
            if plan!=self.plan+added:rows=self.capture()   # (an item of the plan went: all again)
            else:
                rows=self.lighted(rows)
                self.plan=plan;self.top=high
                new=[r for r in rows if r.layer in self.PLAN]
                if new:
                    layers,made=commands(self.renderer,new);self.made+=made;self.batches.append((inverse(self.G),layers))
        self.epoch=self.app.__dict__.get('_view_epoch',0)
        start=time.perf_counter()
        if self.volatile:
            self.renderer.forget()
            for h in self.volatile:self.renderer.release(h)
            self.volatile=[]
        again,self.volatile=commands(self.renderer,[r for r in rows if r.layer not in self.PLAN and r.layer<LAYERS])
        tint=boxing(self.app)
        if tint:   # 0.19.33: the rectangle's tint, as Tk shows it (selection.overlay_pixel: its colour at 45 / 255)
            colour,(x0,y0,x1,y1)=tint;g=self.renderer.path([[x0,y0,x1,y0,x1,y1,x0,y1]],[True],True);self.volatile.append(g)
            tint=('fill',g,tuple(int(colour[i:i+2],16)/255. for i in (1,3,5))+(45/255.,),IDENTITY)
        out=[]
        if self.picture:out.append(('bitmap',self.picture[0],self.picture[1],self.G))   # 0.19.33: under everything
        placed=[(then(back,self.G),layers) for back,layers in self.batches]
        if self.captures!=reads:shift=None   # (review: read again below (an item of the plan gone): where they are now)
        if self.mover:placed.append((shift or IDENTITY,self.mover[2]))   # (0.19.33: over the rest of their layer)
        for layer in range(LAYERS):
            if layer in self.PLAN:
                for m,layers in placed:
                    k=scale_of(m)
                    for cmd in layers[layer]:out.append(_placed(cmd,m,k,layer==3))
            else:
                if layer==4:
                    if tint:out.append(tint)
                    for item in sorted(self.lit):
                        layers,_,back=self.lit[item];m=then(back,self.G);k=scale_of(m)
                        for cmd in layers[4]:out.append(_placed(cmd,m,k,True))
                for cmd in again[layer]:out.append(_placed(cmd,IDENTITY,1.,layer==4))
        if self.marking:out.append(('fill',)+self.marked()+(IDENTITY,))
        self.renderer.draw(self.size,self.background,out)
        _timed('carte graphique : image',start)


CRISP=(1.,0.,0.,1.,.5,.5)   # half a pixel: a line of 1 px at whole coordinates on its pixels


def _placed(cmd,m,k,native=False):
    """A command with its transform: a line keeps its width on the screen, its dashes follow the zoom (as zoom_marks).
    ``native``: drawn by Tk as it is (not smoothed: his PC, the cross was blurred over two pixels): a line of an odd width
    moved half a pixel, on its pixels as Tk draws it."""
    if cmd[0]=='stroke':
        _,g,rgba,width,dash,cap,join=cmd
        if native and round(width)%2:m=then(m,CRISP)
        return ('stroke',g,rgba,m,width/k,tuple(d*k for d in dash) if dash else None,cap,join,width)
    if cmd[0]=='text':
        _,layout,rgba,x,y,angle,left,top=cmd
        a=math.radians(angle);co,si=math.cos(a),math.sin(a)
        return ('text',layout,rgba,then((co,-si,si,co,x,y),m),left,top)
    return ('fill',cmd[1],cmd[2],m)


def _timed(label,since):
    from display_render import _timed as timed
    return timed(label,since)


# --- the app's side ---------------------------------------------------------------------------------------------------
def _factory():
    if FACTORY[0] is None and sys.platform=='win32':FACTORY[0]=Direct2D
    return FACTORY[0]


def wanted(app):
    """The card draws while the view moves: « Zoom par la carte graphique » on, Windows, the plan shown, no background
    picture."""
    if DISABLED[0] or not app.prefs.get('gpu_display',True) or _factory() is None:return False
    try:
        if 'canvas' not in app.__dict__ or not app.canvas.winfo_exists() or not app.plan_active():return False
        # (review) objects changed where they are by a gesture of their own (a grip, a contour): Tk draws, as before;
        # 0.19.33: Déplacer and a copy being placed (only shifted by Tk: MOVERS) are drawn by the card too
        if app.grip_drag or app.__dict__.get('_contour_drag'):return False
        if app.__dict__.get('bg_tool'):return False   # (the picture's own frame being set: Tk)
        return getattr(_factory(),'bitmaps',False) or not __import__('background_ui').visible(app)   # 0.19.33: with the picture too
    except Exception:return False


def _mirror(app):
    c=app.canvas;m=c.__dict__.get('_gpu_mirror')
    if m is None or m.app is not app:
        made=_factory()
        m=Mirror(app,made(c));c._gpu_mirror=m
        c.bind('<Destroy>',lambda e,c=c:closed(c) if str(e.widget)==c._w else None,add='+')
        c.bind('<Configure>',lambda e,a=app:stop(a),add='+')
        # (review) a click, a key: before Craft's own handlers (one of them returning « break » skipped the card's)
        tag='CraftCarte'+str(id(c))
        for sequence in ('<ButtonPress-1>','<ButtonPress-3>'):c.bind_class(tag,sequence,lambda e,a=app:stop(a))
        c.bind_class(tag,'<KeyPress>',lambda e,a=app:None if e.keysym in MODIFIERS else keyed(a,e))
        c.bind_class(tag,'<Motion>',lambda e,a=app:touched(a))
        c.bindtags((tag,)+tuple(t for t in c.bindtags() if t!=tag))
        if not app.__dict__.get('_gpu_keys'):   # (review: once for the app, not again for each window built)
            c.bind_all('<KeyPress>',lambda e,a=app:None if e.keysym in MODIFIERS else keyed(a,e),add='+');app._gpu_keys=True
            top=c.winfo_toplevel()
            top.bind('<Unmap>',lambda e,a=app,t=top:stop(a) if e.widget is t else None,add='+')   # (minimised)
        STATUS['carte']=getattr(m.renderer,'status','prête')
    return m


def boxing(app):
    """0.19.33: a selection rectangle follows the pointer: (its colour, its rectangle on the canvas); None."""
    try:
        st=app.__dict__.get('_box_tint')
        if not st or not st.get('owner') or not st.get('shown'):return None
        at=app.canvas.coords(st['owner']+':tint')
        if len(at)<2:return None
        colour,(x0,y0,x1,y1)=st['shown'];ax,ay=float(at[0]),float(at[1])   # (review: its picture moved by the wheel or a move of the view, as Tk shows it)
        return colour,(x0+ax,y0+ay,x1+ax,y1+ay)
    except Exception:return None


def boxed(app):
    """0.19.33: the rectangle drawn again (craft_refined.draw_selection_box): drawn by the card, its picture made once the
    pointer's event is over (touched); False when it is not."""
    if not wanted(app) or not boxing(app):return False
    try:
        m=_mirror(app)
        if m.state=='idle':
            if m.refused is not None and m.refused==app.canvas.__dict__.get('_drawn_count'):return False
            m.refused=app.canvas.__dict__.get('_drawn_count')   # (until it is drawn: Unsupported leaves it)
            look=SEEN[0] is None and SEEN[1]<SEEN_TRIES   # (review: as moved: never an empty canvas, the card's picture unseen)
            if look:m.marking=True
            m.frame(None,fresh=True)
            m.refused=None
            m.renderer.show(m.size);m.renderer.paint()
            m.away();m.state='active';m.gesture+=1
            if look:app.after(SEEN_AFTER,_seen,m,m.gesture)
        m.last=time.monotonic();m.token+=1
        _watch(m)
        touched(app)
        return True
    except Unsupported as why:
        STATUS['carte']='pas pour ce dessin ('+str(why)[:80]+')'
        stop(app);return False
    except Exception as exc:
        _fail(app,exc);return False


def dragging(app):
    """0.19.33: something follows the pointer that Tk only shifts (Déplacer, a copy being placed)."""
    try:
        if app.translating_ids():return True
        copy=app.__dict__.get('copy_state')
        return bool(copy and copy.get('phase')=='place')
    except Exception:return False


def dragged(app):
    """0.19.33: Tk shifted what follows the pointer (Déplacer: fast_translate; Copier: shift_copy_preview): drawn by the
    card, its picture made once the pointer's event is over (touched); False when it is not (Tk, as before)."""
    if not wanted(app) or not dragging(app):
        stop(app);return False
    try:
        m=_mirror(app)
        if m.state=='idle':
            if m.refused is not None and m.refused==app.canvas.__dict__.get('_drawn_count'):return False
            m.refused=app.canvas.__dict__.get('_drawn_count')   # (until it is drawn: Unsupported leaves it)
            m.kept=False   # (read again: what moves among the plan)
            look=SEEN[0] is None and SEEN[1]<SEEN_TRIES   # (review: as moved: never an empty canvas, the card's picture unseen)
            if look:m.marking=True
            m.frame(None,fresh=True)
            if m.mover is None:raise Unsupported('rien qui se déplace')
            m.refused=None
            m.renderer.show(m.size);m.renderer.paint()
            m.away();m.state='active';m.gesture+=1
            if look:app.after(SEEN_AFTER,_seen,m,m.gesture)
        m.last=time.monotonic();m.token+=1
        _watch(m)
        touched(app)
        return True
    except Unsupported as why:
        STATUS['carte']='pas pour ce dessin ('+str(why)[:80]+')'
        stop(app);return False
    except Exception as exc:
        _fail(app,exc);return False


def drawing(app):
    """0.19.33: the card shows the plan now (Tk's view away: what Tk would show is never seen)."""
    try:
        m=app.canvas.__dict__.get('_gpu_mirror')
        return m is not None and m.state=='active'
    except Exception:return False


def active(app):
    """0.19.33: the card draws the plan now (a gesture under way): what Tk would draw for it alone can wait."""
    try:
        m=app.canvas.__dict__.get('_gpu_mirror')
        return m is not None and m.state=='active' and m.picture is not None
    except Exception:return False


def moved(app,change=None):
    """The view moved (Tk's items already moved: a notch of the wheel ('zoom', x, y, k), the view moved ('move', dx, dy)):
    drawn by the card. False when it is not (Tk shows its own lines, as before)."""
    if not wanted(app) or dragging(app):   # (review: the view changed during Déplacer / a copy placed: Tk, as before, every notch)
        stop(app);return False
    m=None
    try:
        m=_mirror(app)
        first=m.state=='idle'
        look=first and SEEN[0] is None and SEEN[1]<SEEN_TRIES
        if look:m.marking=True
        m.frame(change,fresh=first)
        if first:m.renderer.show(m.size);m.renderer.paint()   # (drawn again once shown: a hidden window keeps nothing)
        m.away();m.state='active';m.last=time.monotonic();m.token+=1
        if first:m.gesture+=1
        if look:app.after(SEEN_AFTER,_seen,m,m.gesture)
        _watch(m)
        return True
    except Unsupported as why:
        STATUS['carte']='pas pour ce dessin ('+str(why)[:80]+')'
        stop(app);return False
    except Exception as exc:
        _fail(app,exc);return False


PREPARE=250      # ms after the full drawing once the hand rests: the plan read for the card (the next gesture starts at once)
RESTED=.3        # s the mouse rests before it


def prepare(app,tries=8):
    """The plan read for the card while the hand rests (after the full drawing that follows a gesture, a document
    opened): the next notch or move of the view only moves it (Mirror.holds)."""
    if not wanted(app):return
    try:
        m=_mirror(app)
        if m.state!='idle' or m.holds_drawing():return
        busy=app.view_gesture() or app.__dict__.get('pan') or app.grip_drag or app.translating_ids() or _smoothing(app)
        if busy or time.monotonic()-app.__dict__.get('_moved_at',0)<RESTED:
            if tries:app.after(PREPARE,prepare,app,tries-1)
            return
        m.capture();m.epoch=app.__dict__.get('_view_epoch',0)
    except Unsupported:
        stop(app)
    except Exception as exc:_fail(app,exc)


def _seen(m,gesture):
    """(once a session, review: a canvas left empty would be the worst) the mark of the card's picture read back from
    the screen: Tk's own colour there instead: the card's picture is not on the screen, Craft draws as before."""
    app=m.app
    if m.state=='idle' or m.gesture!=gesture or not m.marking:
        m.marking=False;return   # (the gesture over first: looked at the next one)
    try:
        pixel=m.renderer.look(*m.corner())
        ground,mark=m.colours()
        near=lambda a,b,d:all(abs(x-y)<=d for x,y in zip(a,b))
        if pixel is not None and near(pixel,mark,3):
            SEEN[0]=True
        elif pixel is not None and near(pixel,ground,2):
            m.marking=False
            return _fail(app,OSError('le dessin de la carte ne s’affiche pas à l’écran'))
        else:
            SEEN[1]+=1   # (neither: the screen's colours changed, something over the canvas: looked again next time)
        m.marking=False
        if m.state!='idle':m.frame()   # (the mark gone)
    except Unsupported:stop(app)
    except Exception as exc:_fail(app,exc)


def touched(app):
    """The pointer moved over the canvas while the card draws: its picture made again at once after (the cross, a tool's
    preview)."""
    m=app.canvas.__dict__.get('_gpu_mirror') if 'canvas' in app.__dict__ else None
    if m is None or m.state not in ('active','settling') or m.soon or app.__dict__.get('pan'):return   # (the view moving: its own pictures)
    def again():
        m.soon=None
        if m.state in ('active','settling'):
            try:m.frame()
            except Unsupported:stop(app)
            except Exception as exc:_fail(app,exc)
    m.soon=app.after_idle(again)


def settled(app):
    """The gesture is over (the wheel stopped, the view let go): the card's picture stays until Tk's smoothed picture is
    there (at most WAIT s)."""
    m=app.canvas.__dict__.get('_gpu_mirror') if 'canvas' in app.__dict__ else None
    if m is None or m.state!='active':return
    m.state='settling';m.since=time.monotonic()   # (its last picture kept: the same view; what the settle drew comes with Tk's)
    _check(m)


def _smoothing(app):
    """A smoothing of the plan still to come (in the background or at once)."""
    c=app.canvas
    return __import__('display_render').busy(c) or bool(app.__dict__.get('_smooth_idle')) or bool(c.__dict__.get('_smooth_job'))


def _check(m):
    if m.state!='settling':return
    app=m.app
    try:waiting=_smoothing(app) and time.monotonic()-m.since<WAIT
    except Exception:waiting=False
    if waiting:
        try:app.after(POLL,_check,m)
        except Exception:pass
        return
    _end(m)


MODIFIERS={'Shift_L','Shift_R','Control_L','Control_R','Alt_L','Alt_R','Caps_Lock','Num_Lock','Win_L','Win_R'}
LOOK=100         # ms between two looks at the gesture while the card draws
LOST=.15         # s after the last notch or move with no gesture under way any more (its settle dropped): Tk at once


def _watch(m):
    """Never the card's picture over the canvas once the gesture is over without its settle (review: a click or a key
    that cancelled it without stopping the card), nor long after the last gesture."""
    if m.timer is not None:return
    def look():
        m.timer=None
        quiet=time.monotonic()-m.last
        try:going=bool(m.app.view_gesture()) or dragging(m.app) or bool(boxing(m.app))   # (0.19.33: a drag, a rectangle)
        except Exception:going=False
        if m.state=='active' and (quiet>QUIET or quiet>LOST and not going):_end(m);return
        if m.state in ('active','settling'):
            try:m.timer=m.app.after(LOOK,look)
            except Exception:pass
    try:m.timer=m.app.after(LOOK,look)
    except Exception:pass


def _end(m):
    """Tk's view back over its items and the card's window hidden: its last picture stays on the screen until Tk draws
    (nothing erases it: review), one drawing of Tk instead of two."""
    if m.state=='idle':return
    m.state='idle';m.back()
    try:
        m.renderer.hide()
        if not m.kept:m.release()   # (kept for the next gesture otherwise)
    except Exception:m.release()


ENDING={'Escape','Return','KP_Enter'}


def keyed(app,e):
    """A key: Tk's own drawing at once (stop); 0.19.33 (review): while the card draws what Déplacer or a copy to place
    shifts, a key typed for its distance only makes the card's picture again (the preview shifts it: dragged), never Tk's
    whole view drawn again and the plan read again at each digit."""
    try:
        if getattr(e,'keysym','') not in ENDING and drawing(app) and dragging(app):
            touched(app);return
    except Exception:pass
    stop(app)


def stop(app):
    """Something else than the view changes (a click, a key, a drawing, the window's size): Tk's own drawing at once;
    the plan read for the card not kept."""
    c=app.__dict__.get('canvas')
    m=c.__dict__.get('_gpu_mirror') if c is not None else None
    if m is None:return
    if m.state!='idle':_end(m)
    m.kept=False
    if m.state=='idle' and m.made:
        try:m.release()
        except Exception:pass


def closed(canvas):
    """The canvas goes (the window built again): its card's window and what it holds go with it."""
    m=canvas.__dict__.pop('_gpu_mirror',None)
    if m is None:return
    m.state='idle'
    try:m.release();m.renderer.close()
    except Exception:pass


def _fail(app,exc):
    """An error of the card: not used any more in this session (diagnostic.txt), Tk draws as before."""
    DISABLED[0]=f'{type(exc).__name__} : {exc}'[:200]
    STATUS['carte']='erreur, coupée pour cette séance : '+DISABLED[0]
    try:__import__('slow_log').add('carte graphique : erreur '+DISABLED[0],0.)
    except Exception:pass
    c=app.__dict__.get('canvas');m=c.__dict__.get('_gpu_mirror') if c is not None else None
    if m is not None:
        m.back();m.state='idle'
        try:m.renderer.hide()
        except Exception:pass
        try:m.release()
        except Exception:pass


def status():
    """For diagnostic.txt."""
    if DISABLED[0]:return 'Carte graphique : '+STATUS.get('carte','')
    if sys.platform!='win32':return 'Carte graphique : non (pas Windows)'
    if 'carte' not in STATUS:
        try:STATUS['carte']=Direct2D.probe()
        except Exception as exc:STATUS['carte']=f'non ({type(exc).__name__} : {exc})'[:200]
    return 'Carte graphique : '+STATUS['carte']


# --- Direct2D (Windows) ---------------------------------------------------------------------------------------------
class Direct2D:
    """The card's window over a canvas (a child of it that the mouse goes through) and its Direct2D drawer."""
    _api=None
    bitmaps=True   # 0.19.33: draws the background picture
    @classmethod
    def api(cls):
        if cls._api is None:cls._api=_Api()
        return cls._api
    @classmethod
    def probe(cls):
        a=cls.api()
        return 'Direct2D prêt'
    def __init__(self,canvas):
        a=self.api();self.a=a;self.parent=int(canvas.winfo_id());self.size=(max(1,canvas.winfo_width()),max(1,canvas.winfo_height()))
        self.rt=None;self.brushes={};self.styles={};self.formats={};self.last=None;self.status='Direct2D';self.pictures={}
        a.clip_children(self.parent)
        self.hwnd=a.window(self.parent,self.size)
        try:self._target()
        except Exception:
            a.destroy(self.hwnd);self.hwnd=None;raise
    def _target(self):
        a=self.a
        self._drop_target()
        self.rt=a.target(self.hwnd,self.size)
        if not a.hardware(self.rt):   # (review: Direct2D without the card, remote desktop or a VM: maybe slower than Tk)
            self._drop_target();raise OSError('Direct2D sans carte graphique (logiciel)')
        self.status='Direct2D (carte graphique)'
    def _drop_target(self):
        a=self.a
        for b in self.brushes.values():a.release(b)
        self.brushes={}
        for b in self.pictures.values():a.release(b)   # (a bitmap belongs to its target: made again for the next one)
        self.pictures={}
        if self.rt:a.release(self.rt)
        self.rt=None
    def brush(self,rgba):
        b=self.brushes.get(rgba)
        if b is None:b=self.brushes[rgba]=self.a.brush(self.rt,rgba)
        return b
    def style(self,cap,join,dash,width):
        units=tuple(round(d/width,3) for d in dash) if dash else ()
        key=(cap,join,units)
        s=self.styles.get(key)
        if s is None:s=self.styles[key]=self.a.stroke_style(cap,join,units)
        return s
    def bitmap(self,pic):
        """0.19.33: the card's bitmap of a Picture (made once for this target; two kept at most)."""
        b=self.pictures.get(pic.key)
        if b is None:
            if len(self.pictures)>=2:
                for v in self.pictures.values():self.a.release(v)
                self.pictures={}
            b=self.pictures[pic.key]=self.a.bitmap(self.rt,pic)
        return b
    def forget(self):self.last=None
    def path(self,figures,closed,filled,ids=None):return self.a.path(figures,closed,filled)
    def text(self,string,font,justify,box,item=None):
        family,size,weight,style=font
        key=(family,size,weight,style,justify)
        f=self.formats.get(key)
        if f is None:
            if len(self.formats)>=64:   # (review: one a size seen; a layout keeps what it needs of its format)
                for v in self.formats.values():self.a.release(v)
                self.formats={}
            f=self.formats[key]=self.a.text_format(family,size,weight,style,justify)
        return self.a.layout(string,f,box)
    def release(self,handle):self.a.release(handle)
    def draw(self,size,background,commands):
        if size!=self.size:
            self.size=size;self.a.move(self.hwnd,size);self._target()
        if len(self.styles)>64:   # (the dashes of many zooms: only between two pictures, none in use)
            self.last=None
            for v in self.styles.values():self.a.release(v)
            self.styles={}
        self.last=(background,commands)
        if self.rt is None:self._target()
        if not self.a.render(self,background,commands):   # (the card's device lost: made again, drawn again once)
            self._target()
            if not self.a.render(self,background,commands):raise OSError('Direct2D : image perdue')
    def look(self,x,y):
        """The colour on the screen (R, G, B) at the canvas's pixel (x, y); None when it cannot be read."""
        return self.a.pixel(self.parent,x,y)
    def paint(self):
        """The last picture again (once shown)."""
        if self.last and self.rt:
            try:self.a.render(self,*self.last)
            except Exception:pass
    def show(self,size):
        if size!=self.size:self.size=size;self.a.move(self.hwnd,size);self._target()
        self.a.show(self.hwnd,True)
    def hide(self):
        self.last=None
        self.a.show(self.hwnd,False)
    def close(self):
        a=self.a
        for s in self.styles.values():a.release(s)
        for f in self.formats.values():a.release(f)
        self.styles={};self.formats={}
        self._drop_target()
        a.destroy(self.hwnd)


class _Api:
    """Direct2D, DirectWrite and the window, through ctypes (the vtables of their interfaces)."""
    def __init__(self):
        import ctypes
        import ctypes.wintypes as W
        self.ctypes=ctypes;self.W=W
        F=ctypes.c_float;U=ctypes.c_uint;VP=ctypes.c_void_p
        class GUID(ctypes.Structure):_fields_=[('Data1',W.DWORD),('Data2',W.WORD),('Data3',W.WORD),('Data4',ctypes.c_ubyte*8)]
        class POINT2F(ctypes.Structure):_fields_=[('x',F),('y',F)]
        class COLORF(ctypes.Structure):_fields_=[('r',F),('g',F),('b',F),('a',F)]
        class MATRIX(ctypes.Structure):_fields_=[('m11',F),('m12',F),('m21',F),('m22',F),('dx',F),('dy',F)]
        class PIXELFORMAT(ctypes.Structure):_fields_=[('format',U),('alphaMode',U)]
        class RTPROPS(ctypes.Structure):_fields_=[('type',U),('pixelFormat',PIXELFORMAT),('dpiX',F),('dpiY',F),('usage',U),('minLevel',U)]
        class SIZEU(ctypes.Structure):_fields_=[('width',U),('height',U)]
        class HWNDPROPS(ctypes.Structure):_fields_=[('hwnd',VP),('pixelSize',SIZEU),('presentOptions',U)]
        class STROKEPROPS(ctypes.Structure):_fields_=[('startCap',U),('endCap',U),('dashCap',U),('lineJoin',U),('miterLimit',F),('dashStyle',U),('dashOffset',F)]
        self.GUID,self.POINT2F,self.COLORF,self.MATRIX,self.RTPROPS,self.SIZEU,self.HWNDPROPS,self.STROKEPROPS=GUID,POINT2F,COLORF,MATRIX,RTPROPS,SIZEU,HWNDPROPS,STROKEPROPS
        self.PIXELFORMAT=PIXELFORMAT
        class RECTF(ctypes.Structure):_fields_=[('left',F),('top',F),('right',F),('bottom',F)]
        class BITMAPPROPS(ctypes.Structure):_fields_=[('pixelFormat',PIXELFORMAT),('dpiX',F),('dpiY',F)]
        self.RECTF,self.BITMAPPROPS=RECTF,BITMAPPROPS
        LRESULT=ctypes.c_ssize_t
        class WNDCLASSEXW(ctypes.Structure):
            _fields_=[('cbSize',W.UINT),('style',W.UINT),('lpfnWndProc',VP),('cbClsExtra',ctypes.c_int),('cbWndExtra',ctypes.c_int),('hInstance',W.HINSTANCE),
                      ('hIcon',W.HICON),('hCursor',W.HANDLE),('hbrBackground',W.HBRUSH),('lpszMenuName',W.LPCWSTR),('lpszClassName',W.LPCWSTR),('hIconSm',W.HICON)]
        u=self.user32=ctypes.WinDLL('user32',use_last_error=True);k=ctypes.WinDLL('kernel32',use_last_error=True)
        u.DefWindowProcW.argtypes=[W.HWND,W.UINT,W.WPARAM,W.LPARAM];u.DefWindowProcW.restype=LRESULT
        u.RegisterClassExW.argtypes=[ctypes.POINTER(WNDCLASSEXW)];u.RegisterClassExW.restype=W.ATOM
        u.CreateWindowExW.argtypes=[W.DWORD,W.LPCWSTR,W.LPCWSTR,W.DWORD,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,W.HWND,W.HMENU,W.HINSTANCE,W.LPVOID];u.CreateWindowExW.restype=W.HWND
        u.DestroyWindow.argtypes=[W.HWND];u.IsWindow.argtypes=[W.HWND]
        u.SetWindowPos.argtypes=[W.HWND,W.HWND,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,W.UINT]
        u.ClientToScreen.argtypes=[W.HWND,ctypes.POINTER(W.POINT)]
        u.GetDC.argtypes=[W.HWND];u.GetDC.restype=W.HDC;u.ReleaseDC.argtypes=[W.HWND,W.HDC]
        try:
            u.LogicalToPhysicalPointForPerMonitorDPI.argtypes=[W.HWND,ctypes.POINTER(W.POINT)];self.physical=u.LogicalToPhysicalPointForPerMonitorDPI
        except AttributeError:self.physical=None
        g=self.gdi32=ctypes.WinDLL('gdi32',use_last_error=True)
        g.CreateCompatibleDC.argtypes=[W.HDC];g.CreateCompatibleDC.restype=W.HDC
        g.CreateDIBSection.argtypes=[W.HDC,VP,W.UINT,ctypes.POINTER(VP),W.HANDLE,W.DWORD];g.CreateDIBSection.restype=W.HBITMAP
        g.SelectObject.argtypes=[W.HDC,W.HGDIOBJ];g.SelectObject.restype=W.HGDIOBJ
        g.BitBlt.argtypes=[W.HDC,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,W.HDC,ctypes.c_int,ctypes.c_int,W.DWORD]
        g.DeleteObject.argtypes=[W.HGDIOBJ];g.DeleteDC.argtypes=[W.HDC]
        class BITMAPINFOHEADER(ctypes.Structure):
            _fields_=[('biSize',W.DWORD),('biWidth',W.LONG),('biHeight',W.LONG),('biPlanes',W.WORD),('biBitCount',W.WORD),('biCompression',W.DWORD),
                      ('biSizeImage',W.DWORD),('biXPelsPerMeter',W.LONG),('biYPelsPerMeter',W.LONG),('biClrUsed',W.DWORD),('biClrImportant',W.DWORD)]
        self.BITMAPINFOHEADER=BITMAPINFOHEADER
        u.ShowWindow.argtypes=[W.HWND,ctypes.c_int]
        u.MoveWindow.argtypes=[W.HWND,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,W.BOOL]
        u.GetWindowLongPtrW.argtypes=[W.HWND,ctypes.c_int];u.GetWindowLongPtrW.restype=ctypes.c_ssize_t
        u.SetWindowLongPtrW.argtypes=[W.HWND,ctypes.c_int,ctypes.c_ssize_t];u.SetWindowLongPtrW.restype=ctypes.c_ssize_t
        k.GetModuleHandleW.argtypes=[W.LPCWSTR];k.GetModuleHandleW.restype=W.HMODULE
        self.instance=k.GetModuleHandleW(None)
        d2d1=ctypes.WinDLL('d2d1');dwrite=ctypes.WinDLL('dwrite')
        d2d1.D2D1CreateFactory.argtypes=[U,ctypes.POINTER(GUID),VP,ctypes.POINTER(VP)];d2d1.D2D1CreateFactory.restype=ctypes.HRESULT
        dwrite.DWriteCreateFactory.argtypes=[U,ctypes.POINTER(GUID),ctypes.POINTER(VP)];dwrite.DWriteCreateFactory.restype=ctypes.HRESULT
        self.protos={}
        self.factory=VP();d2d1.D2D1CreateFactory(0,ctypes.byref(self.guid('06152247-6f50-465a-9245-118bfd3b6007')),None,ctypes.byref(self.factory))
        self.write=VP();dwrite.DWriteCreateFactory(0,ctypes.byref(self.guid('b859ee5a-d838-4b5b-a2e8-1adc7d93db48')),ctypes.byref(self.write))
        # (review) no window procedure of Python: Windows calling Python from inside Tk's loop could stop Craft (a Tk
        # object freed there); user32's own one, the window disabled: its mouse goes to the canvas (Microsoft: « the
        # system passes the child's mouse input messages to the parent »), nothing erases it (no brush), the
        # compositor keeps its last picture
        wc=WNDCLASSEXW(ctypes.sizeof(WNDCLASSEXW),0,ctypes.cast(u.DefWindowProcW,VP).value,0,0,self.instance,None,None,None,None,'CraftCarteGraphique',None)
        if not u.RegisterClassExW(ctypes.byref(wc)):raise OSError('RegisterClassExW %d'%ctypes.get_last_error())
        self.wc=wc
        # the calls made at each picture, their prototypes made once
        self.m_begin=self.proto(None);self.m_end=self.proto(ctypes.c_long,VP,VP);self.m_clear=self.proto(None,ctypes.POINTER(COLORF))
        self.m_transform=self.proto(None,ctypes.POINTER(MATRIX));self.m_draw=self.proto(None,VP,VP,F,VP);self.m_fill=self.proto(None,VP,VP,VP)
        self.m_layout=self.proto(None,POINT2F,VP,VP,U)
        self.m_bitmap=self.proto(None,VP,ctypes.POINTER(RECTF),F,U,ctypes.POINTER(RECTF))   # DrawBitmap
    def guid(self,text):
        a,b,c,d,e=text.split('-');tail=bytes.fromhex(d+e)
        return self.GUID(int(a,16),int(b,16),int(c,16),(self.ctypes.c_ubyte*8)(*tail))
    def proto(self,restype,*argtypes):
        key=(restype,argtypes);p=self.protos.get(key)
        if p is None:p=self.protos[key]=self.ctypes.WINFUNCTYPE(restype,self.ctypes.c_void_p,*argtypes)
        return p
    def method(self,obj,index,proto):
        ctypes=self.ctypes
        vtable=ctypes.cast(obj,ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
        return proto(vtable[index])
    def call(self,obj,index,restype,argtypes,*args):
        return self.method(obj,index,self.proto(restype,*argtypes))(obj,*args)
    def release(self,obj):
        if obj:self.call(obj,2,self.ctypes.c_ulong,())
    # the window
    def clip_children(self,parent):
        u=self.user32;style=u.GetWindowLongPtrW(parent,-16)
        if not style&0x02000000:u.SetWindowLongPtrW(parent,-16,style|0x02000000)   # WS_CLIPCHILDREN: Tk never draws over it
    def window(self,parent,size):
        u=self.user32
        # WS_EX_NOPARENTNOTIFY; WS_CHILD | WS_CLIPSIBLINGS | WS_DISABLED (review: never WS_EX_TRANSPARENT: out of the
        # canvas's clip region, Tk drew over it)
        hwnd=u.CreateWindowExW(0x00000004,'CraftCarteGraphique',None,0x40000000|0x04000000|0x08000000,0,0,size[0],size[1],parent,None,self.instance,None)
        if not hwnd:raise OSError('CreateWindowExW %d'%self.ctypes.get_last_error())
        # under Tk's own widgets in the canvas (review: the value typed, the search of commands): HWND_BOTTOM;
        # SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE
        u.SetWindowPos(hwnd,1,0,0,0,0,0x0001|0x0002|0x0010)
        return hwnd
    def move(self,hwnd,size):self.user32.MoveWindow(hwnd,0,0,size[0],size[1],False)
    def pixel(self,hwnd,x,y):
        """The colour on the screen at the point (x, y) of the window ``hwnd``: (R, G, B), None. Craft is not DPI-aware:
        its point in the screen's own pixels (a display at 125 %…)."""
        ctypes=self.ctypes;W=self.W;u=self.user32;g=self.gdi32
        pt=W.POINT(int(x),int(y))
        if not u.ClientToScreen(hwnd,ctypes.byref(pt)):return None
        if self.physical is not None:
            try:self.physical(hwnd,ctypes.byref(pt))
            except Exception:pass
        screen=u.GetDC(None)
        if not screen:return None
        try:
            mem=g.CreateCompatibleDC(screen)
            if not mem:return None
            try:
                header=self.BITMAPINFOHEADER(ctypes.sizeof(self.BITMAPINFOHEADER),1,-1,1,32,0,0,0,0,0,0);bits=ctypes.c_void_p()
                bitmap=g.CreateDIBSection(mem,ctypes.byref(header),0,ctypes.byref(bits),None,0)
                if not bitmap or not bits.value:return None
                try:
                    old=g.SelectObject(mem,bitmap)
                    ok=g.BitBlt(mem,0,0,1,1,screen,pt.x,pt.y,0x00CC0020|0x40000000)   # SRCCOPY | CAPTUREBLT
                    g.SelectObject(mem,old)
                    if not ok:return None
                    b,gr,r=ctypes.string_at(bits,4)[:3]
                    return (r,gr,b)
                finally:g.DeleteObject(bitmap)
            finally:g.DeleteDC(mem)
        finally:u.ReleaseDC(None,screen)
    def show(self,hwnd,on):self.user32.ShowWindow(hwnd,8 if on else 0)   # SW_SHOWNA, SW_HIDE
    def destroy(self,hwnd):
        if hwnd and self.user32.IsWindow(hwnd):self.user32.DestroyWindow(hwnd)
    # Direct2D
    def target(self,hwnd,size):
        ctypes=self.ctypes;VP=ctypes.c_void_p
        props=self.RTPROPS(0,self.PIXELFORMAT(0,0),96.,96.,0,0);hp=self.HWNDPROPS(hwnd,self.SIZEU(*size),2)   # D2D1_PRESENT_OPTIONS_IMMEDIATELY
        rt=VP()
        self.call(self.factory,14,ctypes.HRESULT,(ctypes.POINTER(self.RTPROPS),ctypes.POINTER(self.HWNDPROPS),ctypes.POINTER(VP)),ctypes.byref(props),ctypes.byref(hp),ctypes.byref(rt))
        return rt
    def hardware(self,rt):
        try:return bool(self.call(rt,56,self.ctypes.c_int,(self.ctypes.POINTER(self.RTPROPS),),self.ctypes.byref(self.RTPROPS(2,self.PIXELFORMAT(0,0),96.,96.,0,0))))   # (review: HARDWARE is 2)
        except Exception:return False
    def brush(self,rt,rgba):
        ctypes=self.ctypes;VP=ctypes.c_void_p;b=VP();c=self.COLORF(*rgba)
        self.call(rt,8,ctypes.HRESULT,(ctypes.POINTER(self.COLORF),VP,ctypes.POINTER(VP)),ctypes.byref(c),None,ctypes.byref(b))
        return b
    def bitmap(self,rt,pic):
        """0.19.33: an ID2D1Bitmap of a Picture (BGRA rows, opaque): ID2D1RenderTarget::CreateBitmap (4)."""
        ctypes=self.ctypes;VP=ctypes.c_void_p;U=ctypes.c_uint;b=VP()
        data=(ctypes.c_char*len(pic.data)).from_buffer_copy(pic.data)
        props=self.BITMAPPROPS(self.PIXELFORMAT(87,3),96.,96.)   # DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_IGNORE
        self.call(rt,4,ctypes.HRESULT,(self.SIZEU,VP,U,ctypes.POINTER(self.BITMAPPROPS),ctypes.POINTER(VP)),
                  self.SIZEU(pic.width,pic.height),ctypes.cast(data,VP),pic.width*4,ctypes.byref(props),ctypes.byref(b))
        return b
    def stroke_style(self,cap,join,units):
        ctypes=self.ctypes;VP=ctypes.c_void_p;s=VP()
        props=self.STROKEPROPS(cap,cap,cap,join,10.,5 if units else 0,0.)
        dashes=(ctypes.c_float*len(units))(*units) if units else None
        self.call(self.factory,11,ctypes.HRESULT,(ctypes.POINTER(self.STROKEPROPS),ctypes.POINTER(ctypes.c_float),ctypes.c_uint,ctypes.POINTER(VP)),
                  ctypes.byref(props),dashes,len(units),ctypes.byref(s))
        return s
    def path(self,figures,closed,filled):
        """One geometry for many figures (flat coordinates each)."""
        ctypes=self.ctypes;VP=ctypes.c_void_p;U=ctypes.c_uint;P=self.POINT2F
        geometry=VP();self.call(self.factory,10,ctypes.HRESULT,(ctypes.POINTER(VP),),ctypes.byref(geometry))
        sink=VP()
        try:
            self.call(geometry,17,ctypes.HRESULT,(ctypes.POINTER(VP),),ctypes.byref(sink))
            self.call(sink,3,None,(U,),0)   # SetFillMode: ALTERNATE (Tk's)
            begin=self.method(sink,5,self.proto(None,P,U));add=self.method(sink,6,self.proto(None,ctypes.POINTER(P),U));end=self.method(sink,8,self.proto(None,U))
            flat=array('f')
            starts=[]
            for points in figures:starts.append((len(flat)//2,len(points)//2));flat.extend(points)
            buffer=(ctypes.c_float*len(flat)).from_buffer(flat) if flat else None
            base=ctypes.addressof(buffer) if flat else 0
            for (at,n),shut in zip(starts,closed):
                begin(sink,P(flat[2*at],flat[2*at+1]),0 if filled else 1)
                if n>1:add(sink,ctypes.cast(base+8*(at+1),ctypes.POINTER(P)),n-1)
                end(sink,1 if shut else 0)
            self.call(sink,9,ctypes.HRESULT,())   # Close
        except Exception:
            self.release(sink);self.release(geometry);raise
        self.release(sink)
        return geometry
    def text_format(self,family,size,weight,style,justify):
        ctypes=self.ctypes;VP=ctypes.c_void_p;U=ctypes.c_uint;f=VP()
        self.call(self.write,15,ctypes.HRESULT,(ctypes.c_wchar_p,VP,U,U,U,ctypes.c_float,ctypes.c_wchar_p,ctypes.POINTER(VP)),
                  family,None,weight,style,5,float(max(1.,size)),'fr-fr',ctypes.byref(f))
        self.call(f,3,ctypes.HRESULT,(U,),justify);self.call(f,4,ctypes.HRESULT,(U,),0);self.call(f,5,ctypes.HRESULT,(U,),1)   # alignment, top, no wrapping
        return f
    def layout(self,string,fmt,box):
        ctypes=self.ctypes;VP=ctypes.c_void_p;U=ctypes.c_uint;layout=VP()
        self.call(self.write,18,ctypes.HRESULT,(ctypes.c_wchar_p,U,VP,ctypes.c_float,ctypes.c_float,ctypes.POINTER(VP)),
                  string,len(string.encode('utf-16-le','surrogatepass'))//2,fmt,float(max(1.,box[0])),float(max(1.,box[1])),ctypes.byref(layout))
        return layout
    def render(self,owner,background,commands):
        """A picture; False when the card's device was lost (D2DERR_RECREATE_TARGET)."""
        ctypes=self.ctypes;rt=owner.rt;M=self.MATRIX;P=self.POINT2F
        begin=self.method(rt,48,self.m_begin);end=self.method(rt,49,self.m_end);clear=self.method(rt,47,self.m_clear)
        transform=self.method(rt,30,self.m_transform);draw=self.method(rt,22,self.m_draw);fill=self.method(rt,23,self.m_fill)
        text=self.method(rt,28,self.m_layout);picture=self.method(rt,26,self.m_bitmap)
        begin(rt)
        try:
            transform(rt,ctypes.byref(M(*IDENTITY)))
            clear(rt,ctypes.byref(self.COLORF(*background,1.)))
            current=IDENTITY
            for cmd in commands:
                kind=cmd[0];m=cmd[3]
                if m is not current:transform(rt,ctypes.byref(M(*m)));current=m
                if kind=='fill':fill(rt,cmd[1],owner.brush(cmd[2]),None)
                elif kind=='bitmap':picture(rt,owner.bitmap(cmd[1]),ctypes.byref(self.RECTF(*cmd[2])),1.,1,None)   # 0.19.33: LINEAR
                elif kind=='stroke':
                    _,g,rgba,_,width,dash,cap,join,screen=cmd
                    draw(rt,g,owner.brush(rgba),width,owner.style(cap,join,dash,screen))
                else:
                    _,layout,rgba,_,left,top=cmd;text(rt,P(left,top),layout,owner.brush(rgba),0)
        finally:
            hr=end(rt,None,None)
        if hr==-2003238900:return False   # 0x8899000C
        if hr<0:raise OSError('Direct2D EndDraw %#x'%(hr&0xffffffff))
        return True


class Recorder:
    """For the tests (any system): what the card would draw, kept; ``fail``: an error at the next picture."""
    status='essai'
    bitmaps=True
    def __init__(self,canvas):
        self.canvas=canvas;self.frames=[];self.shown=False;self.live={};self.closed=False;self.fail=None;self.size=None;self.n=0
    def path(self,figures,closed,filled,ids=None):
        self.n+=1;h=('path',self.n);self.live[h]=(list(figures),list(closed),filled,list(ids or ()));return h
    def text(self,string,font,justify,box,item=None):
        self.n+=1;h=('text',self.n);self.live[h]=(string,font,justify,box,item);return h
    def release(self,handle):self.live.pop(handle,None)
    def draw(self,size,background,commands):
        if self.fail:raise self.fail
        for cmd in commands:assert cmd[0]=='bitmap' or cmd[1] in self.live,cmd
        self.size=size;self.frames.append((background,list(commands),dict(self.live)))
    def show(self,size):self.shown=True;self.size=size
    def paint(self):pass
    def forget(self):pass
    answer=None   # (what look reads back: the tests set it)
    def look(self,x,y):self.looked=(x,y);return self.answer
    def hide(self):self.shown=False
    def close(self):self.closed=True;self.live={}
