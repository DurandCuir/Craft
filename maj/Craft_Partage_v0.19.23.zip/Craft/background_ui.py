"""0.18.0 « Image de fond »: a photo, a scan or a PDF page under the plan, at its real size, to copy
a drawing with lines.

Fichier › Image de fond ▸ Insérer… (JPG, PNG, BMP, GIF, TIFF, PDF — the page chosen —, WEBP / HEIC
when Windows reads them): the real width is proposed from the file (resolution of a scan, size
of a PDF page) and can be typed; « Caler » makes it exact from two points of the picture and their
real distance. The picture stays behind every line, faded (« Transparence »), can be moved or
hidden, and is never exported nor printed. A light copy of it is kept in the document (.crft),
so the original file may move or disappear.

0.18.5 « Déplacer / redimensionner l’image de fond »: a frame with 8 handles around the picture,
like a frame in a page layout. Dragging anywhere but a handle moves it (or a click on a repère,
then a click on the arrival point); an edge sets the width or the height, a corner both, keeping
the proportions (Maj: freely). A handle can also be clicked, then placed by a second click. The
size (or the distance) is shown beside the cross, a value typed replaces it (one length, or
« largeur;hauteur » for a corner), ORTHO keeps a move horizontal or vertical, the point held snaps
to the anchors of the drawing. The outline follows the mouse at once, the picture is drawn again
just behind it; one Annuler per gesture; Entrée (nothing held) or Échap ends."""
import base64
import math
import os
import time
import tkinter as tk
from tkinter import filedialog,messagebox,ttk
from types import SimpleNamespace

OPACITIES=('20 %','30 %','40 %','50 %','60 %','80 %','100 %')
DEFAULT_OPACITY=.4
FILE_TYPES=[('Images et PDF','*.jpg *.jpeg *.png *.bmp *.gif *.tif *.tiff *.webp *.heic *.heif *.pdf'),('Tous les fichiers','*.*')]
TAG='background_image'
# 0.19.7 « impression que image fait laguer »: during a gesture (wheel, move of the view, frame of the picture)
# the picture is made at a third of the screen's resolution and enlarged by Tk (9 times fewer pixels to make),
# sharp again when the gesture is over; the last times are written in diagnostic.txt.
QUICK=3
TIMES={}
WHOLE=(0.,0.,1.,1.)


def valid(b):
    """A background read from a document: checked, or None when it is not usable."""
    if not isinstance(b,dict):return None
    try:
        out=dict(name=str(b.get('name',''))[:200],format=b['format'],data=b['data'],pixels=[int(v) for v in b['pixels']],
                 x=float(b['x']),y=float(b['y']),w=float(b['w']),h=float(b['h']),
                 opacity=float(b.get('opacity',DEFAULT_OPACITY)),visible=bool(b.get('visible',True)))
    except (KeyError,TypeError,ValueError):return None
    if out['format'] not in ('jpeg','png') or not isinstance(out['data'],str) or not 0<len(out['data'])<=14_000_000:return None
    if len(out['pixels'])!=2 or not all(1<=v<=20000 for v in out['pixels']):return None
    if not all(math.isfinite(out[k]) for k in ('x','y','w','h','opacity')) or not (0<out['w']<=100000 and 0<out['h']<=100000):return None
    if not all(abs(out[k])<=1e6 for k in ('x','y')):return None
    out['opacity']=max(.05,min(1.,out['opacity']))
    from cad import valid_crop
    crop=valid_crop(b.get('crop'))
    if crop:out['crop']=crop   # 0.19.7 « Recadrer »
    return out


def current(app):return app.__dict__.get('background')


def world(app,x,y):return app.raw(SimpleNamespace(x=x,y=y))


def visible(app):
    b=current(app);return bool(b and b.get('visible',True))


# --- Menu ---------------------------------------------------------------------------------------

def build_menu(app,parent):
    """« Image de fond » ▸ in Fichier, its entries greyed while there is no picture."""
    m=tk.Menu(parent,tearoff=False);app._background_menu=m;app._background_shown=tk.BooleanVar(master=app,value=True)
    m.add_command(label='Insérer une image de fond…',command=lambda:insert(app))
    m.add_checkbutton(label='Afficher l’image de fond',variable=app._background_shown,command=lambda:show(app,app._background_shown.get()))
    m.add_command(label='Déplacer / redimensionner l’image de fond',command=lambda:start_tool(app,'move'))   # 0.18.5: the frame
    m.add_command(label='Recadrer l’image de fond',command=lambda:start_tool(app,'crop'))   # 0.19.7
    m.add_command(label='Annuler le recadrage',command=lambda:reset_crop(app))
    m.add_command(label='Caler l’image : deux points et leur distance',command=lambda:start_tool(app,'calibrate'))
    m.add_command(label='Transparence…',command=lambda:opacity_dialog(app))
    m.add_command(label='Retirer l’image de fond',command=lambda:remove(app))
    def refresh_menu():
        b=current(app);state='normal' if b else 'disabled';app._background_shown.set(bool(b and b.get('visible',True)))
        for k in range(1,m.index('end')+1):
            m.entryconfigure(k,state='normal' if b and (m.entrycget(k,'label')!='Annuler le recadrage' or b.get('crop')) else 'disabled')
    m.configure(postcommand=refresh_menu)
    return m


# --- Insertion ----------------------------------------------------------------------------------

def insert(app):
    import doc_files,backdrop
    options=dict(parent=app,title='Insérer une image de fond',filetypes=FILE_TYPES);folder=doc_files.initial_dir(app.prefs)
    if folder:options['initialdir']=folder
    file=filedialog.askopenfilename(**options)
    if not file:return None
    page=0
    if file.lower().endswith('.pdf'):
        try:
            import pdf_reader
            with open(file,'rb') as f:count=pdf_reader.page_count(f.read())
        except (OSError,ValueError) as exc:messagebox.showerror('Image de fond',str(exc),parent=app);return None
        if count>1:
            page=ask_page(app,count)
            if page is None:return None
    app.configure(cursor='watch');app.update_idletasks()
    try:picture,width_mm,fmt=backdrop.read_picture(file,page)
    except (OSError,ValueError) as exc:
        app.configure(cursor='');messagebox.showerror('Image de fond',str(exc),parent=app);return None
    finally:app.configure(cursor='')   # 0.19.9: never left on 'watch', whatever the error
    return size_dialog(app,file,picture,width_mm,fmt)


def ask_page(app,count):
    """The page of a PDF with several pages (None if the window is closed)."""
    win=app.dialog('Page du PDF');result=[None];value=tk.StringVar(value='1')
    row=tk.Frame(win,bg=app.p['panel']);row.pack(padx=18,pady=14)
    app.label(row,'Page').pack(side='left');box=ttk.Spinbox(row,from_=1,to=count,textvariable=value,width=5);box.pack(side='left',padx=8);app.label(row,f'sur {count}').pack(side='left')
    def choose(e=None):
        try:n=int(value.get())
        except ValueError:return 'break'
        if 1<=n<=count:result[0]=n-1;win.destroy()
        return 'break'
    app.button(win,'Choisir',choose).pack(pady=(0,14));box.bind('<Return>',choose);win.bind('<Return>',choose)
    box.focus_set();app.wait_window(win)
    return result[0]


def size_dialog(app,file,picture,width_mm,fmt):
    """Real width (proposed from the file, else fitted to the view), visibility, then « Placer »."""
    import backdrop
    b=backdrop.require();pw,ph=b.size(picture)
    if not width_mm:
        x0,y0=world(app,0,0);x1,y1=world(app,app.canvas.winfo_width(),app.canvas.winfo_height())
        width_mm=max(10.,min(abs(x1-x0),abs(y1-y0)*pw/ph)*.8)
    win=app.dialog('Image de fond');panel=app.p['panel'];app._background_window=win
    app.label(win,f'{os.path.basename(file)} · {pw} × {ph} px').pack(anchor='w',padx=16,pady=(14,6))
    form=tk.Frame(win,bg=panel);form.pack(fill='x',padx=16)
    width=tk.StringVar(value=fmt_mm(width_mm));height=tk.StringVar();seen=tk.StringVar(value=f'{round(DEFAULT_OPACITY*100)} %')
    def update(*args):
        try:height.set('Hauteur : '+fmt_mm(float(width.get().replace(',','.'))*ph/pw)+' mm')
        except ValueError:height.set('')
    width.trace_add('write',update);update()
    app.label(form,'Largeur réelle').grid(row=0,column=0,sticky='w',pady=3);field=app.entry(form,width,9);field.grid(row=0,column=1,padx=8,sticky='w')
    app.label(form,'mm').grid(row=0,column=2,sticky='w');app.label(form,textvariable=height).grid(row=1,column=0,columnspan=3,sticky='w')
    app.label(form,'Visibilité').grid(row=2,column=0,sticky='w',pady=(8,3));ttk.Combobox(form,textvariable=seen,values=OPACITIES,width=7,state='readonly').grid(row=2,column=1,padx=8,sticky='w',pady=(8,3))
    buttons=tk.Frame(win,bg=panel);buttons.pack(padx=16,pady=14)
    def place(calibrate):
        try:
            w=float(width.get().replace(',','.'))
            if not 1<=w<=100000:raise ValueError
        except ValueError:messagebox.showerror('Image de fond','Largeur : de 1 à 100 000 mm.',parent=win);return
        opacity=int(seen.get().split()[0])/100;win.destroy();app.canvas.focus_set()
        app.configure(cursor='watch');app.update_idletasks()
        try:copy=backdrop.light_copy(picture,fmt)
        except (OSError,ValueError) as exc:app.configure(cursor='');messagebox.showerror('Image de fond',str(exc),parent=app);return
        finally:app.configure(cursor='')
        b.dispose(picture)
        h=w*ph/pw;cx,cy=world(app,app.canvas.winfo_width()/2,app.canvas.winfo_height()/2)
        new=dict(name=os.path.basename(file),x=cx-w/2,y=cy-h/2,w=w,h=h,opacity=opacity,visible=True,**copy)
        app.snapshot();app.background=new;app.refresh()
        app.status.set('Image de fond placée'+(' : cliquer deux points de l’image.' if calibrate else '.'))
        # 0.19.7: like a picture inserted in Word, its frame at once (move it, size it); Entrée: done
        start_tool(app,'calibrate' if calibrate else 'move')
    app.button(buttons,'Placer',lambda:place(False)).pack(side='left',padx=6)
    app.button(buttons,'Placer et caler',lambda:place(True)).pack(side='left',padx=6)
    field.bind('<Return>',lambda e:(place(False),'break')[1]);field.select_range(0,'end');field.focus_set()
    return win


def fmt_mm(v):
    return f'{v:.1f}'.rstrip('0').rstrip('.').replace('.',',')


# --- Display ------------------------------------------------------------------------------------

def crop_of(b):
    """0.19.7 « Recadrer »: the part of the picture kept (left, top, right, bottom, fractions of it)."""
    c=b.get('crop') if b else None
    return tuple(c) if c else WHOLE


def cut(rect,crop):
    """The rectangle of the part ``crop`` of a picture whose whole is ``rect`` (x, y, w, h)."""
    x,y,w,h=rect;l,t,r,b=crop;return (x+l*w,y+t*h,(r-l)*w,(b-t)*h)


def whole(rect,crop):
    """The whole picture's rectangle when its part ``crop`` is ``rect``."""
    x,y,w,h=rect;l,t,r,b=crop;W,H=w/(r-l),h/(b-t);return (x-l*W,y-t*H,W,H)


def frame_rect(app):
    """0.18.5: the picture's rectangle (x, y, w, h) on the plan: while its frame is dragged, the one
    being set (the document changes once, at the end of the gesture). 0.19.7: the frame dragged is the
    part kept (« Recadrer »): the whole picture goes with it."""
    b=current(app);g=gesture(app);st=app.__dict__.get('bg_tool')
    if g and st and st['kind']=='move':return whole(g['rect'],crop_of(b))
    return (b['x'],b['y'],b['w'],b['h'])


def kept_crop(app):
    """0.19.7: the part kept, the one being set while « Recadrer » moves a side."""
    g=gesture(app);st=app.__dict__.get('bg_tool')
    if g and st and st['kind']=='crop' and 'crop' in g:return g['crop']
    return crop_of(current(app))


def visible_rect(app):
    """0.19.7: the rectangle of the part of the picture shown on the plan."""
    return cut(frame_rect(app),kept_crop(app))


def under(app,x,y):
    """0.19.7: the picture shown under the screen point (x, y)."""
    b=current(app)
    if not b or not b.get('visible',True) or not app.plan_active():return False
    vx,vy,vw,vh=visible_rect(app);p=world(app,x,y)
    return vx<=p[0]<=vx+vw and vy<=p[1]<=vy+vh


def gesture(app):
    st=app.__dict__.get('bg_tool');return st.get('gesture') if st else None


def draw(app):
    """The visible part of the picture at the screen's size, under everything (0.18.5: and, over the
    lines, the frame of « Déplacer / redimensionner » or the points of « Caler »). 0.19.7: lighter while
    the view moves (the wheel turning, the view held), sharp with the drawing after."""
    moving=getattr(app,'view_gesture',None)
    picture(app,quick=bool(moving and moving()));overlay(app)


def picture(app,quick=False,keep_smooth=False):
    """The visible part of the picture at the screen's size, under everything. 0.19.7: faded once
    (backdrop.faded), only its part kept (« Recadrer »; the whole while it is cropped); ``quick``: during a
    gesture, a third of the resolution enlarged by Tk; the picture of it made last also goes under the
    smoothed lines (display_render.paint, « trait pas beau »); ``keep_smooth``: the smoothed lines kept
    (they slide with it while the view moves)."""
    import display_render
    c=app.canvas;c.delete(TAG);b=current(app);app._background_shift=None;app._background_whole=False
    if not b or not b.get('visible',True) or not app.plan_active():
        # it had the picture under its lines: it goes, and the lines it hid are shown again
        if c.__dict__.pop('_background_key',None) is not None:display_render.drop_picture(c)
        c.__dict__.pop('_smooth_base',None);return
    st=app.__dict__.get('bg_tool');crop=WHOLE if st and st['kind']=='crop' else kept_crop(app)
    W,H=max(1,c.winfo_width()),max(1,c.winfo_height())
    x,y,w,h=cut(frame_rect(app),crop);x0,y0=app.to_screen((x,y));x1,y1=app.to_screen((x+w,y+h))
    if x1<=x0 or y1<=y0:return
    vx0,vy0=max(0,math.floor(x0)),max(0,math.floor(y0));vx1,vy1=min(W,math.ceil(x1)),min(H,math.ceil(y1))
    if vx1-vx0<1 or vy1-vy0<1:return
    pw,ph=b['pixels'];l,t,r,bm=crop;ox,oy,sw,sh=l*pw,t*ph,(r-l)*pw,(bm-t)*ph;fx,fy=sw/(x1-x0),sh/(y1-y0)
    sx,sy=ox+max(0.,(vx0-x0)*fx),oy+max(0.,(vy0-y0)*fy)   # whole screen pixels: a fraction of a picture pixel is dropped
    src=(sx,sy,max(1e-3,min(ox+sw-sx,(vx1-vx0)*fx)),max(1e-3,min(oy+sh-sy,(vy1-vy0)*fy)));dst=(vx1-vx0,vy1-vy0)
    colour=tuple(round(v/257) for v in c.winfo_rgb(c.cget('background')));k=QUICK if quick else 1
    key=(len(b['data']),b['data'][:48],b['data'][-48:],tuple(round(v,3) for v in src),dst,round(b['opacity'],3),colour,k)
    cached=app.__dict__.get('_background_photo')
    if not cached or cached[0]!=key:
        import backdrop,display_render
        try:
            started=time.perf_counter();small=(max(1,math.ceil(dst[0]/k)),max(1,math.ceil(dst[1]/k)))
            data=backdrop.require().view(backdrop.faded(b,colour),src,small,1.,colour);photo=display_render.photo_image(c,data)
            if k>1:
                big=tk.PhotoImage(master=c,width=dst[0],height=dst[1]);c.tk.call(big,'copy',photo,'-zoom',k,k,'-to',0,0,dst[0],dst[1]);photo=big
            base=None if k>1 else (vx0,vy0,dst[0],dst[1],data[len(b'P6 %d %d 255\n'%dst):])
            cached=(key,photo,base);app._background_photo=cached;TIMES['quick' if k>1 else 'full']=(time.perf_counter()-started,dst)
            if k==1 and not app.__dict__.get('_background_logged') and hasattr(app,'write_diagnostic'):
                app._background_logged=True;app.after(3000,app.write_diagnostic)   # its time in diagnostic.txt
        except (OSError,ValueError,tk.TclError) as exc:
            app._background_photo=None;app.status.set('Image de fond : '+str(exc));return
    # The picture made last and the place it is shown at now (a pan or « Déplacer » by whole pixels gives the
    # same picture at another place): the smoothed lines are made over it there.
    place=key+(vx0,vy0)
    if not keep_smooth and c.__dict__.get('_background_key')!=place:display_render.drop_picture(c)   # its lines over another picture
    c._background_key=place;c._smooth_base=((place,vx0,vy0)+tuple(cached[2][2:])) if cached[2] else None
    item=c.create_image(vx0,vy0,image=cached[1],anchor='nw',tags=TAG);c.tag_lower(item)
    # 0.18.5: where the picture's corner is from the image drawn (a move only slides it), and whether
    # all of it is drawn (nothing new to show when it slides).
    app._background_shift=(x0-vx0,y0-vy0);app._background_whole=x0>=0 and y0>=0 and x1<=W and y1<=H


def show(app,on):
    b=current(app)
    if not b:return
    if bool(on)==b.get('visible',True):return
    if not on:quit_tool(app)   # 0.18.5: no frame around a hidden picture
    app.snapshot();b['visible']=bool(on);app.refresh()   # kept in the .crft: an Annuler step (refused in read-only)


def reset_crop(app):
    """0.19.7 « Annuler le recadrage »: the whole picture again (one Annuler)."""
    b=current(app)
    if not b or not b.get('crop'):return
    quit_tool(app);app.snapshot();b.pop('crop',None);app.refresh();app.status.set('Image de fond entière.')


def context_entries(app,m):
    """0.19.7: a right click on the picture (nothing drawn under the mouse): what can be done with it."""
    b=current(app)
    m.add_command(label='Régler l’image (déplacer, taille)',command=lambda:start_tool(app,'move'))
    m.add_command(label='Recadrer',command=lambda:start_tool(app,'crop'))
    if b and b.get('crop'):m.add_command(label='Annuler le recadrage',command=lambda:reset_crop(app))
    m.add_command(label='Caler : deux points et leur distance',command=lambda:start_tool(app,'calibrate'))
    m.add_command(label='Redresser : deux points d’un trait droit',command=lambda:start_tool(app,'straighten'))   # 0.19.13
    m.add_command(label='Transparence…',command=lambda:opacity_dialog(app))
    m.add_command(label='Masquer',command=lambda:show(app,False))
    m.add_command(label='Retirer',command=lambda:remove(app))


def remove(app):
    if not current(app):return
    quit_tool(app);app.snapshot();app.background=None;app._background_photo=None;app.canvas.delete(TAG);app.refresh();app.status.set('Image de fond retirée.')


def opacity_dialog(app):
    """« Transparence »: how much of the picture shows (10 to 100 %), seen at once."""
    b=current(app)
    if not b:return None
    if not getattr(app,'licence_complet',lambda:True)():return app.read_only_said()   # read-only: nothing to set
    win=app.dialog('Transparence');panel=app.p['panel'];value=tk.DoubleVar(value=round(b['opacity']*100))
    text=tk.StringVar(value=f'{round(b["opacity"]*100)} %');app._opacity_window=win;before=b['opacity'];job=[None]
    row=tk.Frame(win,bg=panel);row.pack(padx=16,pady=(16,8))
    app.label(row,'Visibilité').pack(side='left')
    def changed(*args):
        v=max(10,min(100,round(value.get())));text.set(f'{v} %')
        if job[0]:app.after_cancel(job[0])
        def apply():
            job[0]=None
            if current(app) is b:b['opacity']=v/100;app.refresh()
        job[0]=app.after(80,apply)
    scale=ttk.Scale(row,from_=10,to=100,orient='horizontal',length=220,variable=value,command=changed);scale.pack(side='left',padx=10)
    app.label(row,textvariable=text,width=6).pack(side='left')
    def close():
        if job[0]:app.after_cancel(job[0]);job[0]=None
        try:
            if current(app) is b:
                v=max(10,min(100,round(value.get())))/100
                if abs(v-before)>1e-9:
                    # One undo step for the whole setting.
                    b['opacity']=before;app.snapshot();b['opacity']=v
                app.refresh()
        finally:win.destroy();app.canvas.focus_set()   # never a window that cannot be closed
    app.button(win,'Fermer',close).pack(pady=(0,14));win.protocol('WM_DELETE_WINDOW',close);win.bind('<Return>',lambda e:close())
    return win


# --- Frame (move, width, height) and calibrate -----------------------------------------------------

HANDLES=('nw','ne','se','sw','n','e','s','w')   # corners first: they win on a tiny frame
SIDES=dict(nw=(-1,-1),n=(0,-1),ne=(1,-1),e=(1,0),se=(1,1),s=(0,1),sw=(-1,1),w=(-1,0))   # the sides each handle moves
GRAB=7;EDGE=4   # px: around a handle, along an edge
SMALLEST=1.;LARGEST=100000.   # mm, as at the insertion


def start_tool(app,kind):
    if not current(app):return
    app.finish_action();app.cancel();app.tool.set('select');app.highlight_tools()
    if not current(app)['visible']:current(app)['visible']=True;app.refresh()
    app.bg_tool=dict(kind=kind,points=[],gesture=None,hover=None,aim=None)
    bind_release(app);watch_value(app)
    app.status.set({'move':'Glisser l’image, un bord ou un coin (Maj : sans garder les proportions) · Entrée : terminer.',
                    'crop':'Tirer un bord ou un coin pour cacher cette partie de l’image · Entrée : terminer.',
                    'straighten':'Redresser : cliquer deux points d’un trait de la photo qui doit être droit.'}.get(kind,'Choisir premier point de l’image'))
    app.canvas.focus_set()
    if kind=='crop':draw(app)   # 0.19.7: the whole picture, the part cut greyed
    else:overlay(app)


def quit_tool(app):
    st=app.__dict__.get('bg_tool')
    if not st:return
    if st.get('job'):app.after_cancel(st['job'])
    app.bg_tool=None;app.canvas.delete('bg_preview');end_value(app)
    if st['kind']=='crop':draw(app)   # only the part kept again


def bind_release(app):
    """0.18.5: the end of a drag (the plan's release goes to the tools; this one is added beside it,
    again if the plan was bound anew)."""
    c=app.canvas;held=app.__dict__.get('_bg_release')
    if held and held[0] is c and held[1] in (c.bind('<ButtonRelease-1>') or ''):return
    app._bg_release=(c,c.bind('<ButtonRelease-1>',lambda e:release(app,e),add='+'))


def watch_value(app):
    """0.18.5: the value box stays beside the cross while a value is typed (the arrow's own value box
    is put away at each key) and the frame follows the value at once."""
    var=app.command_value;held=app.__dict__.get('_bg_value_trace')
    if held and held[0] is var:return
    def typed(*args):
        if app.__dict__.get('bg_tool') and not app.__dict__.get('_bg_value_job'):app._bg_value_job=app.after_idle(lambda:value_changed(app))
    app._bg_value_trace=(var,var.trace_add('write',typed))


def value_changed(app):
    app._bg_value_job=None;st=app.__dict__.get('bg_tool')
    if not st or not app.winfo_exists():return
    g=st.get('gesture')
    if g:follow(app,g,g['p'],g['free']);show_gesture(app,g)
    show_value(app)


def hint(app):
    st=app.__dict__.get('bg_tool')
    if not st:return None
    if st['kind']=='crop':
        g=st.get('gesture');part=g['part'] if g else st.get('hover')
        return '' if g and g['held'] else 'Tirer un bord ou un coin' if part is None else 'Placer bord' if len(part)==1 else 'Placer coin'
    if st['kind']=='move':
        g=st.get('gesture')
        if g:return '' if g['held'] else 'Choisir point d’arrivée' if g['part']=='move' else 'Placer coin' if len(g['part'])==2 else 'Placer bord'
        part=st.get('hover')
        return 'Glisser ou choisir repère' if part in (None,'move') else 'Largeur et hauteur' if len(part)==2 else 'Largeur' if part in ('e','w') else 'Hauteur'
    n=len(st['points'])
    return ('Choisir premier point de l’image','Choisir second point de l’image','Distance réelle au clavier')[min(n,2)]


def handles(app,rect):
    """The 8 handles on the screen."""
    x,y,w,h=rect;x0,y0=app.to_screen((x,y));x1,y1=app.to_screen((x+w,y+h));xm,ym=(x0+x1)/2,(y0+y1)/2
    return dict(nw=(x0,y0),n=(xm,y0),ne=(x1,y0),e=(x1,ym),se=(x1,y1),s=(xm,y1),sw=(x0,y1),w=(x0,ym))


def part_at(app,x,y):
    """What a press at (x, y) takes: a handle, or 'move' (anywhere else: the picture is moved).
    0.19.7: on the part of the picture shown (« Recadrer »); while cropping, only a handle (None elsewhere)."""
    st=app.__dict__.get('bg_tool');pts=handles(app,visible_rect(app));x0,y0=pts['nw'];x1,y1=pts['se']
    if st and st['kind']=='crop':
        k=min(HANDLES,key=lambda k:math.dist(pts[k],(x,y)))
        if math.dist(pts[k],(x,y))<=GRAB:return k
        if y0<=y<=y1 and min(abs(x-x0),abs(x-x1))<=EDGE:return 'w' if abs(x-x0)<=abs(x-x1) else 'e'
        if x0<=x<=x1 and min(abs(y-y0),abs(y-y1))<=EDGE:return 'n' if abs(y-y0)<=abs(y-y1) else 's'
        return None
    if min(x1-x0,y1-y0)<3*GRAB and x0<x<x1 and y0<y<y1:return 'move'   # a tiny frame is moved from inside
    k=min(HANDLES,key=lambda k:math.dist(pts[k],(x,y)))
    if math.dist(pts[k],(x,y))<=GRAB:return k
    if y0<=y<=y1 and min(abs(x-x0),abs(x-x1))<=EDGE:return 'w' if abs(x-x0)<=abs(x-x1) else 'e'
    if x0<=x<=x1 and min(abs(y-y0),abs(y-y1))<=EDGE:return 'n' if abs(y-y0)<=abs(y-y1) else 's'
    return 'move'


def reshaped(rect,part,start,p,free=False,typed=None):
    """The frame (x, y, w, h) once its part went from start to p: 'move' slides it; an edge moves
    alone; a corner keeps the proportions (free: not) along the side the mouse changes most. typed:
    the lengths typed (mm): the distance of a move along the mouse, the width of an edge or a
    corner (« largeur;hauteur » for a corner: both)."""
    x,y,w,h=rect
    if part=='move':
        dx,dy=p[0]-start[0],p[1]-start[1];n=math.hypot(dx,dy)
        if typed and n>1e-9:dx,dy=dx/n*typed[0],dy/n*typed[0]
        return (x+dx,y+dy,w,h)
    sx,sy=SIDES[part]
    if typed and sx and sy and len(typed)>1:W,H=typed[0],typed[1];free=True
    elif typed:W,H=(typed[0],h) if sx else (w,typed[0])
    else:W,H=(p[0]-(x if sx>0 else x+w))*sx if sx else w,(p[1]-(y if sy>0 else y+h))*sy if sy else h
    if sx and sy and not free:
        rx,ry=W/w,H/h;k=rx if typed or abs(rx-1)>=abs(ry-1) else ry
        k=max(SMALLEST/min(w,h),min(LARGEST/max(w,h),k));W,H=w*k,h*k
    else:W,H=max(SMALLEST,min(LARGEST,W)),max(SMALLEST,min(LARGEST,H))
    return (x+w-W if sx<0 else x,y+h-H if sy<0 else y,W,H)


def ortho(app,p,origin):
    """0.18.5 (n° 28): with ORTHO, a point placed after a first one stays on its horizontal or vertical."""
    if origin is None or not app.ortho.get():return p
    marker=app.__dict__.get('snap_marker')
    if marker and marker[1] not in ('nearest','guides'):return p   # 0.19.6: an anchor wins over ORTHO
    q=(p[0],origin[1]) if abs(p[0]-origin[0])>=abs(p[1]-origin[1]) else (origin[0],p[1])
    if math.dist(q,p)>1e-7:app.snap_marker=None
    return q


def aim(app,e,origin=None):
    """The point clicked or held: snapped to the anchors of the drawing, then ORTHO from origin."""
    return ortho(app,app.point(e),origin)


def held_point(app,g,e):
    # An edge goes to the point held (it snaps); a move and a corner keep ORTHO from where they started.
    return aim(app,e,None if len(g['part'])==1 else g['start'])


def shifted(e):return bool(getattr(e,'state',0)&1)


def typed_values(app):
    """The lengths typed in the value box (mm), None if nothing usable; and the reason."""
    text=app.command_value.get().strip()
    if not text:return None,''
    try:
        values=[app.parse_length(v.strip()) for v in text.replace('x',';').replace('X',';').split(';') if v.strip()]
        if not values or len(values)>2 or any(not 0<v<=LARGEST for v in values):raise ValueError('Taper une longueur positive (largeur;hauteur pour un coin).')
        return values,''
    except ValueError as exc:return None,str(exc)


def follow(app,g,p,free):
    g['p']=p;g['free']=free;g['rect']=reshaped(g['rect0'],g['part'],g['start'],p,free or 'crop' in g,typed_values(app)[0])
    if 'crop' in g:
        # 0.19.7 « Recadrer »: the sides moved stay inside the picture, the part kept at least 1 % of it
        F=frame_rect(app);x,y,w,h=g['rect'];X,Y,W,H=F;l,t,r,b=g['crop0'];sx,sy=SIDES[g['part']]
        if sx<0:l=min(max(0.,(x-X)/W),r-.01)
        if sx>0:r=max(min(1.,(x+w-X)/W),l+.01)
        if sy<0:t=min(max(0.,(y-Y)/H),b-.01)
        if sy>0:b=max(min(1.,(y+h-Y)/H),t+.01)
        g['crop']=(l,t,r,b);g['rect']=cut(F,g['crop'])


def length_text(app,v):
    unit=app.units.get();return fmt_mm(v/(10 if unit=='cm' else 1))+' '+unit


def live_text(app,g):
    """0.18.5 (n° 31): beside the cross during the gesture: the distance of a move, else the size
    (0.19.7: of the part kept while cropping)."""
    x,y,w,h=g['rect']
    if g['part']=='move':return length_text(app,math.dist((x,y),g['rect0'][:2]))
    f=10 if app.units.get()=='cm' else 1
    return f'{fmt_mm(w/f)} × {fmt_mm(h/f)} {app.units.get()}'


def show_value(app):
    """The value box beside the cross: the live value in grey, or the value typed."""
    st=app.__dict__.get('bg_tool')
    if not st or 'command_entry' not in app.__dict__ or not hasattr(app,'place_value_bubble'):return
    g=st.get('gesture');pts=st['points']
    if st['kind'] in ('move','crop'):text=live_text(app,g) if g else None
    elif len(pts)==1 and st.get('aim'):text=length_text(app,math.dist(pts[0],st['aim']))
    elif len(pts)==2:text=length_text(app,math.dist(*pts))
    else:text=None
    if text is None:return
    x,y=app.cursor_screen;app._bubble_placeholder=text;app.place_value_bubble(x+16,y+16)


def end_value(app):
    if 'command_entry' not in app.__dict__:return
    if app.command_value.get():app.command_value.set('')
    app.command_entry.place_forget();app.canvas.focus_set()


def overlay(app):
    """Over the lines: the frame and its handles (« Déplacer / redimensionner »), or the points of
    « Caler »."""
    c=app.canvas;c.delete('bg_frame');st=app.__dict__.get('bg_tool')
    if not st or not current(app) or not app.plan_active():return
    accent=app.p['accent'];tags=('bg_preview','bg_frame')
    if st['kind'] in ('calibrate','straighten'):
        for q in st['points']:
            x,y=app.to_screen(q)
            for sign in (-1,1):c.create_line(x-6,y-sign*6,x+6,y+sign*6,fill=accent,width=1.5,tags=tags)
        if len(st['points'])==2:c.create_line(*app.to_screen(st['points'][0]),*app.to_screen(st['points'][1]),fill=accent,tags=tags,**app.guide_style())
        return
    g=st.get('gesture');pts=handles(app,visible_rect(app));lit=g['part'] if g else st.get('hover');empty=c.cget('background')
    if st['kind']=='crop':
        # 0.19.7: the part cut greyed (still shown while cropping), the frame of the part kept
        F=handles(app,frame_rect(app));X0,Y0=F['nw'];X1,Y1=F['se'];x0,y0=pts['nw'];x1,y1=pts['se']
        for box in ((X0,Y0,X1,y0),(X0,y1,X1,Y1),(X0,y0,x0,y1),(x1,y0,X1,y1)):
            if box[2]-box[0]>.5 and box[3]-box[1]>.5:c.create_rectangle(*box,fill='#000000',stipple='gray50',outline='',tags=tags)
        c.create_rectangle(X0,Y0,X1,Y1,outline=accent,dash=(3,3),tags=tags)
    c.create_rectangle(*pts['nw'],*pts['se'],outline=accent,width=1.5,tags=tags)
    for k in HANDLES:
        x,y=pts[k];c.create_rectangle(x-4,y-4,x+4,y+4,fill=accent if k==lit else empty,outline=accent,width=1.2,tags=tags)


def draw_marks(app):overlay(app)


def show_gesture(app,g):
    """The frame at once; the picture slid with it (a move), or drawn again just behind it."""
    c=app.canvas;c.delete('bg_guide');g['shown']=True
    if 'crop' in g:overlay(app);return   # 0.19.7: the whole picture stays as it is while cropping, only the grey moves
    # The smoothed lines were made over the picture where it was: they go while it moves (the lines shown
    # as they are), smoothed again over it at the end.
    import display_render;display_render.drop_picture(c)
    if g['part']=='move':
        a=g['start'];x,y=g['rect'][:2];x0,y0=g['rect0'][:2]
        c.create_line(*app.to_screen(a),*app.to_screen((a[0]+x-x0,a[1]+y-y0)),fill=app.p['accent'],tags=('bg_preview','bg_guide'),**app.guide_style())
        slide_picture(app)
    else:queue_picture(app)
    overlay(app)


def slide_picture(app):
    c=app.canvas;shift=app.__dict__.get('_background_shift');items=c.find_withtag(TAG)
    if shift is not None and items:
        ix,iy=c.coords(items[0])[:2];x,y=app.to_screen(frame_rect(app)[:2]);c.move(TAG,x-shift[0]-ix,y-shift[1]-iy)
        c.__dict__.pop('_smooth_base',None)   # 0.19.7: no smoothing over it until it is drawn again at its place
    if shift is None or not app.__dict__.get('_background_whole'):queue_picture(app)   # parts out of the screen come in


def queue_picture(app):
    """The picture drawn again at most every 3 × its cost (≥ 0.04 s) while the frame changes, and
    once more where the mouse stops: the outline never waits for it."""
    st=app.__dict__.get('bg_tool')
    if not st or st.get('job'):return
    wait=max(0.,st.get('drawn',0.)+max(.04,3*st.get('cost',.03))-time.monotonic())
    st['job']=app.after(max(1,round(wait*1000)),lambda:render(app,st))


def render(app,st):
    st['job']=None
    if app.__dict__.get('bg_tool') is not st or not app.winfo_exists():return
    t=time.perf_counter();picture(app,quick=bool(st.get('gesture')));st['cost']=time.perf_counter()-t;st['drawn']=time.monotonic()   # 0.19.7: lighter during the gesture


def cross(app,p):
    """The cross (and the step text) on the point used, the anchor found shown on it."""
    actual=app.cursor_screen;app.cursor_screen=app.to_screen(p)
    try:app.draw_crosshair()
    finally:app.cursor_screen=actual
    marker=app.snap_marker
    if marker and app.snap.get() and hasattr(app,'snap_symbol'):
        x,y=app.to_screen(marker[0]);app.snap_symbol(app.canvas,marker[1],x,y,app.prefs.get('anchor_color','#efcf4b'),('bg_preview','bg_guide'))


def click(app,e):
    st=app.bg_tool;b=current(app)
    if b is None:quit_tool(app);return 'break'
    if st['kind']=='crop' and not st.get('gesture') and part_at(app,e.x,e.y) is None:
        if not under(app,e.x,e.y):quit_tool(app);app.status.set('Image recadrée.');app.draw_crosshair()   # 0.19.7: a click beside it: done
        return 'break'
    if st['kind'] in ('move','crop'):return press(app,e)
    if len(st['points'])>=2:return 'break'
    # 0.18.5: ORTHO for the second point (0.19.13: not to straighten: the point of the photo itself)
    p=app.raw(e) if st['kind']=='straighten' else aim(app,e,st['points'][0] if st['points'] else None)
    st['points'].append(p)
    if len(st['points'])==1:app.status.set('Choisir second point de l’image');overlay(app);return 'break'
    a,q=st['points']
    if math.dist(a,q)<1e-6:st['points'].pop();app.status.set('Choisir un second point différent.');return 'break'
    if st['kind']=='straighten':return straighten(app,a,q)
    # The measured distance in grey in the value box; the real one is typed, then Entrée.
    app.canvas.delete('bg_guide');overlay(app)
    if app.command_value.get():app.command_value.set('')
    show_value(app);app.command_entry.focus_set()
    app.status.set('Distance réelle entre les deux points (mm)');return 'break'


def press(app,e):
    """A press in the frame: a gesture starts (a handle, or a move from the point pressed); during a
    gesture started by a click, the click that places it."""
    st=app.bg_tool;g=st.get('gesture');app.cursor_screen=(e.x,e.y)
    if g:follow(app,g,held_point(app,g,e),shifted(e));return finish(app)
    part=part_at(app,e.x,e.y);rect=visible_rect(app)   # 0.19.7: the frame is the part shown
    if part=='move':start=aim(app,e)
    else:
        sx,sy=SIDES[part];x,y,w,h=rect;start=(x+w*(sx+1)/2 if sx else x+w/2,y+h*(sy+1)/2 if sy else y+h/2);app.snap_marker=None
    g=st['gesture']=dict(part=part,rect0=rect,rect=rect,start=start,p=start,free=shifted(e),press=(e.x,e.y),held=True,moved=False,shown=False)
    if st['kind']=='crop':g['crop0']=g['crop']=kept_crop(app)
    st['hover']=part;app.canvas.delete('bg_guide');overlay(app);cross(app,start)
    if app.command_value.get():app.command_value.set('')
    show_value(app);app.command_entry.focus_set()   # a value may be typed during the gesture
    return 'break'


def release(app,e):
    st=app.__dict__.get('bg_tool');g=st.get('gesture') if st else None
    if not g or not g['held'] or not app.plan_active():return
    g['held']=False
    if g['moved'] or math.hypot(e.x-g['press'][0],e.y-g['press'][1])>=4:
        app.cursor_screen=(e.x,e.y);follow(app,g,held_point(app,g,e),shifted(e));finish(app);return
    # A click: the part held follows the mouse, a second click places it (like the grips).
    app.status.set('Choisir point d’arrivée' if g['part']=='move' else 'Placer coin' if len(g['part'])==2 else 'Placer bord')
    cross(app,g['p'])


def finish(app):
    """The gesture is over: one Annuler step when the picture changed."""
    st=app.bg_tool;g=st['gesture'];st['gesture']=None;b=current(app)
    if st.get('job'):app.after_cancel(st['job']);st['job']=None
    end_value(app);app.canvas.delete('bg_guide')
    if b and 'crop' in g:
        from cad import valid_crop
        crop=valid_crop(g['crop'])
        if crop!=b.get('crop'):
            app.snapshot()
            if crop:b['crop']=crop
            else:b.pop('crop',None)
            app.refresh();l,t,r,bm=crop or WHOLE;f=10 if app.units.get()=='cm' else 1
            app.status.set(f'Partie gardée : {fmt_mm((r-l)*b["w"]/f)} × {fmt_mm((bm-t)*b["h"]/f)} {app.units.get()}.')
        else:
            if g['shown']:picture(app)
            overlay(app)
        app.draw_crosshair();return 'break'
    new=whole(g['rect'],crop_of(b)) if b else g['rect']   # 0.19.7: the frame was the part shown
    if b and max(abs(u-v) for u,v in zip(new,(b['x'],b['y'],b['w'],b['h'])))>1e-9:
        app.snapshot();b.update(x=new[0],y=new[1],w=new[2],h=new[3]);app.refresh()
        f=10 if app.units.get()=='cm' else 1
        app.status.set('Image de fond déplacée.' if g['part']=='move' else f'Image de fond : {fmt_mm(new[2]/f)} × {fmt_mm(new[3]/f)} {app.units.get()}.')
    else:
        if g['shown']:
            picture(app)   # slid or drawn on the way: back exactly in place
            if hasattr(app,'schedule_smooth'):app.schedule_smooth()   # the lines smoothed over it again (dropped while it moved)
        overlay(app)
    app.draw_crosshair();return 'break'


def enter(app):
    """Entrée: the real distance after the two points of « Caler » (the picture is scaled around the
    first point); in the frame, the gesture held is placed (with the value typed), else the frame
    is done."""
    st=app.__dict__.get('bg_tool');b=current(app)
    if not st or not b:return None
    if st['kind'] in ('move','crop'):
        g=st.get('gesture')
        if not g:quit_tool(app);app.status.set('Image recadrée.' if st['kind']=='crop' else 'Image de fond en place.');app.draw_crosshair();return 'break'
        typed,why=typed_values(app)
        if why:app.command_value.set('');app.status.set(why);return 'break'   # refused: cleared, never added to the next one
        if typed and g['part']=='move' and math.dist(g['p'],g['start'])<1e-9:app.command_value.set('');app.status.set('Donner d’abord la direction avec la souris.');return 'break'
        follow(app,g,g['p'],g['free']);return finish(app)
    if len(st['points'])<2:quit_tool(app);app.status.set('Calage abandonné.');app.draw_crosshair();return 'break'   # 0.18.5: Entrée ends here too
    text=app.command_value.get().strip()
    try:real=app.parse_length(text) if text else None
    except ValueError:real=None
    if not real or real<=0:app.command_value.set('');app.status.set('Taper la distance réelle, puis Entrée.');return 'break'
    a,q=st['points'];factor=real/math.dist(a,q)
    app.snapshot();b['x']=a[0]+(b['x']-a[0])*factor;b['y']=a[1]+(b['y']-a[1])*factor;b['w']*=factor;b['h']*=factor
    quit_tool(app);app.refresh();app.status.set(f'Image calée : largeur {fmt_mm(b["w"])} mm.');return 'break'


def straighten_angle(a,q):
    """0.19.13 « Redresser »: the turn (degrees, visually anticlockwise) that puts the line a → q of the photo
    horizontal or vertical, whichever is nearer."""
    seen=math.degrees(math.atan2(-(q[1]-a[1]),q[0]-a[0]))   # Craft's y goes down
    target=round(seen/90)*90
    return target-seen


def turned(b,degrees):
    """The background ``b`` turned by ``degrees`` about the middle of its picture: a new light copy (the corners
    the turn uncovers in white), its frame the turned picture's box, the same millimetres per pixel; the
    recadrage dropped."""
    import backdrop
    back=backdrop.require();pic=backdrop.held(b);w,h=back.size(pic)
    t=math.radians(degrees);c,s=math.cos(t),math.sin(t)
    W,H=max(1,math.ceil(abs(w*c)+abs(h*s)-1e-6)),max(1,math.ceil(abs(w*s)+abs(h*c)-1e-6))
    page=back.page(W,H)
    def place(u,v):return (W/2+u*c+v*s,H/2-u*s+v*c)
    back.draw_picture(page,pic,[place(-w/2,-h/2),place(w/2,-h/2),place(-w/2,h/2)])
    copy=backdrop.light_copy(page,b['format'])
    try:back.dispose(page)
    except Exception:pass
    sx,sy=b['w']/w,b['h']/h;cx,cy=b['x']+b['w']/2,b['y']+b['h']/2
    out=dict(b,**copy);out.pop('crop',None)
    out['w'],out['h']=W*sx,H*sy;out['x'],out['y']=cx-out['w']/2,cy-out['h']/2
    return out


def straighten(app,a,q):
    b=current(app);angle=straighten_angle(a,q)
    if abs(angle)<.01:quit_tool(app);app.refresh();app.status.set('Le trait est déjà droit.');return 'break'
    try:new=turned(b,angle)
    except (OSError,ValueError) as exc:quit_tool(app);app.status.set('Redresser : '+str(exc));return 'break'
    app.snapshot();b.clear();b.update(new);app._background_photo=None
    quit_tool(app);app.refresh();app.status.set(f'Image redressée de {fmt_mm(abs(angle))}° ('+('sens inverse des aiguilles' if angle>0 else 'sens des aiguilles')+').')
    return 'break'


def motion(app,e):
    st=app.bg_tool;b=current(app);app.cursor_screen=(e.x,e.y);app._inside_plan=True;c=app.canvas
    if b is None:quit_tool(app);app.draw_crosshair();return
    c.delete('bg_guide')
    if st['kind'] in ('calibrate','straighten'):
        pts=st['points'];p=app.raw(e) if st['kind']=='straighten' else aim(app,e,pts[0] if len(pts)==1 else None);st['aim']=p
        if len(pts)==1:c.create_line(*app.to_screen(pts[0]),*app.to_screen(p),fill=app.p['accent'],tags=('bg_preview','bg_guide'),**app.guide_style())
        overlay(app);cross(app,p)
        if pts and st['kind']=='calibrate':show_value(app)   # 0.18.5: the distance at once, then the value typed
    else:
        g=st.get('gesture')
        if g:
            if g['held'] and math.hypot(e.x-g['press'][0],e.y-g['press'][1])>=4:g['moved']=True
            follow(app,g,held_point(app,g,e),shifted(e));show_gesture(app,g);cross(app,g['p']);show_value(app)
        else:
            part=part_at(app,e.x,e.y)
            if part=='move':p=aim(app,e)
            else:p=app.raw(e);app.snap_marker=None   # on a handle (or nothing to take while cropping): the cross stays
            if part!=st.get('hover'):st['hover']=part;overlay(app)
            cross(app,p)
    # Shown now, even when the mouse moves fast (the picture is drawn later, when there is time).
    try:c.update_idletasks()
    except tk.TclError:pass
