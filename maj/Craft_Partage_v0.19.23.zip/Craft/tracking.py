"""0.17.0 Repérage (like AutoCAD object snap tracking), always on with the anchors while drawing.

Resting a moment on an anchor point keeps it (small cross). Moving away horizontally or
vertically from a kept point, a dotted line shows the alignment and the pointer is held on it,
even without ORTHO; on the crossing of two such lines it is held on both. A value typed then
Entrée places the point at that distance from the kept point, along the dotted line. Resting
again on a kept point forgets it; points are forgotten when the command ends."""
import math

DWELL_MS=400
REACH_PX=8
MAX_POINTS=3
KINDS={'endpoint','midpoint','center','intersection','quadrant','centroid','node'}   # 0.19.13
TOOLS=frozenset({'line','poly','rect','rect_center','rect_round','rect_rot','para','circle_radius','circle_diameter','circle_2p','circle_3p',
                 'arc_3p','arc_radius','arc_center','spline_fit','ellipse_center','ellipse_box','ellipse_axis','measure','dimension','dimension_aligned','drill'})


def state(app):
    st=app.__dict__.get('_track')
    if st is None:st=app._track=dict(points=[],candidate=None,job=None,lines=[])
    return st


MOVING=frozenset({'move_anchor','copy','rotate','scale','mirror'})


def active(app):
    """0.18.0: also while a grip is dragged and while moving, copying, turning or mirroring, on
    the points of any finished shape."""
    try:
        if not app.snap.get():return False
        t=app.tool.get()
        return t in TOOLS or t in MOVING or (t=='select' and app.__dict__.get('grip_drag') is not None)
    except Exception:return False


def hover(app):
    """At each pointer move: resting on the same anchor for DWELL_MS keeps (or forgets) it."""
    st=state(app);marker=app.__dict__.get('snap_marker')
    if not marker or marker[1] not in KINDS:
        st['candidate']=None;return
    p=(float(marker[0][0]),float(marker[0][1]))
    # 0.18.0: a hand that trembles on the point (or a neighbour anchor 1 pixel away) still rests on it.
    if st['candidate'] is not None and math.dist(st['candidate'],p)<=1.5/max(app.scale,1e-9):return
    st['candidate']=p
    if st['job']:
        try:app.after_cancel(st['job'])
        except Exception:pass
    st['job']=app.after(DWELL_MS,lambda:dwell(app,p))


def dwell(app,p):
    st=state(app);st['job']=None
    if st['candidate'] is None or math.dist(st['candidate'],p)>1.5/max(app.scale,1e-9) or not active(app):return
    if any(math.dist(q,p)<1e-9 for q in st['points']):st['points']=[q for q in st['points'] if math.dist(q,p)>=1e-9]
    else:st['points']=([p]+st['points'])[:MAX_POINTS]
    draw(app)


SOFT=('nearest','guides','extension','parallel')


def align(app,p,kind=None,locked=None):
    """The pointer held on the vertical and/or horizontal of a kept point. ``locked`` is the axis
    ORTHO already fixes ('x' or 'y'); it is not moved."""
    st=state(app);st['lines']=[]
    # A precise anchor wins; a point only « on » a line (nearest, base guide; 0.19.13: the extension of a line, a
    # parallel) gives way to the dotted line.
    if (kind and kind not in SOFT) or not st['points'] or not active(app):return p
    reach=REACH_PX/max(app.scale,1e-9);vertical=horizontal=None
    for a in st['points']:
        dx,dy=abs(p[0]-a[0]),abs(p[1]-a[1])
        if locked!='x' and dx<=reach and (vertical is None or dx<vertical[0]):vertical=(dx,a)
        if locked!='y' and dy<=reach and (horizontal is None or dy<horizontal[0]):horizontal=(dy,a)
    if vertical is None and horizontal is None:return p
    q=(vertical[1][0] if vertical else p[0],horizontal[1][1] if horizontal else p[1])
    st['lines']=[(a,q) for _,a in (v for v in (vertical,horizontal) if v) if math.dist(a,q)>1e-9]
    return q


def draw(app):
    c=app.canvas;c.delete('tracking')
    if not active(app):return
    st=state(app);ink=app.p['accent']
    for a in st['points']:
        x,y=app.to_screen(a)
        c.create_line(x-4,y,x+5,y,fill=ink,width=1,tags='tracking');c.create_line(x,y-4,x,y+5,fill=ink,width=1,tags='tracking')
    for a,q in st['lines']:
        c.create_line(*app.to_screen(a),*app.to_screen(q),fill=ink,tags='tracking',**app.guide_style())


def typed_point(app,value):
    """Entrée with a distance while held on ONE dotted line: that distance from the kept point."""
    st=state(app)
    if len(st['lines'])!=1 or not value or value<=0:return None
    a,q=st['lines'][0];n=math.dist(a,q)
    return (a[0]+(q[0]-a[0])/n*value,a[1]+(q[1]-a[1])/n*value) if n>1e-9 else None


def reset(app):
    st=state(app)
    if st['job']:
        try:app.after_cancel(st['job'])
        except Exception:pass
    st.update(points=[],candidate=None,job=None,lines=[])
    try:app.canvas.delete('tracking')
    except Exception:pass
