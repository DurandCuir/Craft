"""0.17.0 Fiches (bottom tabs), made from the plan, always up to date, printable.
0.18.0: « Générer fiches » offers those with something to show; the one chosen opens in its tab.
0.18.1: presented like Mozart's fiches: A4 sheets in a frame, the créateur, the model and the page
at the top; for each material a band (material, couleur / réf., surface); one line per piece (its
picture with its width and height, its name, its quantity and what the fiche is about; 0.18.2: no
more « Outil / Emporte-pièce : <modèle> » line); at the bottom the fiche's name, the Indice and its
date (Infos du modèle).
Fiches: Coupe (in the order of the base's columns, renforts included, the précoupes counted,
totals and costs at the end), Refente, Parage (zones in colour with their legend), Teinte
(couches), Surcoupe (0.18.2, was « Surcoupe filetage »: the filetage is done afterwards), Fiche
technique générale and Nomenclature (0.18.2: read from the bottom like the person's own, pieces
grouped by material, then the fournitures).
Printed or exported by category, each on its own pages (never mixed); « Toutes » prints them all.

A fiche is a list of pages, each a list of drawing orders in millimetres on the A4 sheet (origin at
the top left): shown on the canvas and written as PDF from the same pages.
0.19.14: the band of each material stands out (light grey across the sheet, the material in bold, a thick rule and a
little space before a new material, never alone at the bottom of a page); the « Image » of the Infos du modèle small
beside the model's name at the top of every page (canvas, PDF and printing)."""
import piece_sheet
import math
import unicodedata
from pathlib import Path

AUTO = (('fiche:coupe', 'Coupe'), ('fiche:refente', 'Refente'), ('fiche:parage', 'Parage'), ('fiche:teinte', 'Teinte'),
        ('fiche:surcoupe', 'Surcoupe'), ('fiche:generale', 'Générale'), ('fiche:nomenclature', 'Nomenclature'))
FOOTER = {'fiche:coupe': 'Fiche coupe', 'fiche:refente': 'Fiche refente', 'fiche:parage': 'Fiche parage',
          'fiche:teinte': 'Fiche teinture', 'fiche:surcoupe': 'Fiche surcoupe',
          'fiche:generale': 'Fiche technique générale', 'fiche:nomenclature': 'Nomenclature'}
PAPER, INK, EDGE, RULE, SHADE = '#ffffff', '#000000', '#8a8a8a', '#9a9a9a', '#ececec'
LEGEND = ('#e5408f', '#7b3fbf', '#20a058', '#e07b1a', '#2f7fd1', '#c23b3b', '#8a6d3b', '#00a0a0')
TEINTE, SURCOUPE = '#f08a24', '#8f9dff'
PW, PH = 210., 297.
L, T, R, B = 8., 8., 202., 289.        # the frame
HEAD, BAND, FOOT = 14., 13., 7.
TEXT_X = 118.                          # the text of a line
THUMB = (16., 110.)                    # where the pictures go
LINE = 4.6                             # between two lines of text
# 0.19.14: the band of a material in light grey (about 17 % ink: a clear grey in black and white, the black text read
# on it), a thick rule and a little space before a new material; the Image du modèle at most 26 × 11 mm
BAND_FILL, BAND_RULE, BAND_GAP = '#d4d4d4', .8, 2.5
PHOTO_W, PHOTO_H, PHOTO_GAP = 26., 11., 3.


def fmt(v, digits=2):
    if v is None or v == '':
        return '—'
    return f'{v:.{digits}f}'.replace('.', ',')


def num(v):
    if v is None or v == '':
        return '—'
    return f'{float(v):.1f}'.rstrip('0').rstrip('.').replace('.', ',')


def size_text(v):
    """A dimension of a picture, like Mozart's: whole millimetres (one decimal under 10 mm)."""
    if v >= 10 or abs(v - round(v)) < .05:
        return str(round(v))
    return f'{v:.1f}'.replace('.', ',')


def pieces_text(n):
    return f'{n} pc' if n == 1 else f'{n} pcs'


def is_auto(key):
    return isinstance(key, str) and key.startswith('fiche:')


# --------------------------------------------------------------------------------- the data
def head_of(app):
    """Créateur, model, Indice and its date for the frame of every fiche (Infos du modèle); 0.19.14: its Image (None
    without a usable one)."""
    import model_info
    from cad import validate_model_image
    infos = app.__dict__.get('infos') or {}
    return dict(author=infos.get('createur', ''), model=model_info.model_name(app), indice=infos.get('indice') or '0',
                date=infos.get('modifie_le') or infos.get('cree_le') or model_info.today(), image=validate_model_image(infos.get('image')))


def image_key(image):
    """0.19.14: what tells one Image du modèle from another, cheaply (its data is never compared whole)."""
    if not isinstance(image, dict):
        return None
    data = image.get('data') if isinstance(image.get('data'), str) else ''
    middle = len(data) // 2
    return (image.get('format'), len(data), data[:64], data[middle:middle + 64], data[-64:])


def photo_size(image):
    """0.19.14: (width, height) in mm of the Image du modèle at the top of a fiche: its proportions, at most
    PHOTO_W × PHOTO_H; None without one."""
    try:
        w, h = (float(v) for v in image['pixels'])
    except (KeyError, TypeError, ValueError, IndexError):
        return None
    if not (math.isfinite(w) and math.isfinite(h) and w > 0 and h > 0 and image.get('data')):
        return None
    k = min(PHOTO_W / w, PHOTO_H / h)
    return w * k, h * k


def _material(items, i):
    """(material, quantity, refente, its fiche de pièce) written on piece ``i``."""
    import re
    from entity_rules import piece_labels
    found = piece_labels(items, i).get('material')
    data = (items[found[0]].get('identification') or {}) if found else {}
    name = ((data.get('values') or [''])[0] or '').strip()
    if not name and found:
        runs = items[found[0]].get('text_runs') or []
        m = re.match(r'^(\d+)\s+(.*)$', runs[0]['text'] if runs else '')
        name = m[2] if m else ''
        data = dict(data, quantity=m[1] if m else data.get('quantity'))
    try:
        count = max(1, int(str(data.get('quantity', '1')).strip() or 1))
    except ValueError:
        count = 1
    return name or '—', count, str(data.get('refente', '') or '').strip(), data


def pieces(app):
    """The finished pieces (closed, Coupe externe, name and material) in the order of the base's
    columns (Dessus, Doublures, Renforts, Aides), then by material, then from top to bottom."""
    import materials as mat
    import surcoupe as sc
    import piece_ids
    from cad import column_labels
    from entity_rules import fabrication_ids, closed_piece
    from craft_tools import style
    from export_check import piece_name
    from geometry import bounds
    items = app.items
    archives = app.__dict__.get('archives') or {}
    workspace = app.__dict__.get('workspace')
    out = []
    for i in fabrication_ids(items):
        s = items[i]
        if not closed_piece(s) or style(s)['role'] != 'external':
            continue
        material, count, refente, sheet = _material(items, i)
        info = mat.info(archives, material)
        x, y, X, Y = bounds([s])
        col = mat.column_at(workspace, (x + X) / 2)
        per = sc.per_precut(items, i) if sc.is_precut(s) else 1
        cut = sc.precuts_needed(count, per) if sc.is_precut(s) else count
        surface = mat.surface_mm2(s)
        owner = s.get('piece_id')
        # 0.19.13 fiche de pièce: the surface multiplied, the piece's écart géométrique instead of the material's chute
        factor = piece_sheet.number(sheet, 'surface') or 1.
        gap = piece_sheet.number(sheet, 'ecart') or 0.
        out.append(dict(index=i, piece=s, name=piece_name(items, i), material=material, quantity=count, refente=refente,
                        info=info, column=col, column_label=column_labels(workspace)[col].capitalize() if col is not None and col < len(column_labels(workspace)) else '',
                        surface=surface, cut=cut, per=per, precut=sc.is_precut(s), cost=mat.cost(surface * factor / 1e6, cut, info['price'], gap if gap > 0 else info['waste']),
                        sheet=sheet, cut_lines=piece_sheet.cut_lines(sheet, count), refente_lines=piece_sheet.refente_lines(sheet),
                        number=piece_ids.number_of(items, i), box=(x, y, X, Y),
                        zones=[z for z in items if z.get('preparation') and owner and z.get('owner_id') == owner]))
    out.sort(key=lambda r: (r['column'] if r['column'] is not None else 99, mat.sort_key(r['material']), round(r['box'][1], 1), round(r['box'][0], 1)))
    return out


def zone_rows(rows, kind):
    return [r for r in rows if any(z['preparation'].get('kind') == kind for z in r['zones'])]


def surcoupe_rows(app, rows):
    return [r for r in rows if r['precut'] or any(z['preparation'].get('kind') == 'surcoupe' for z in r['zones'])]


def available(items, archives, app=None):
    """« Générer fiches »: the fiches that have something to show."""
    class Doc:
        pass
    doc = app
    if doc is None:
        doc = Doc()
        doc.items, doc.archives, doc.workspace, doc.infos, doc.filename, doc.project_model = items, archives, None, None, None, None
    try:
        rows = pieces(doc)
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        rows = []
    out = []
    for key, title in AUTO:
        if key in ('fiche:coupe', 'fiche:generale', 'fiche:nomenclature'):
            has = bool(rows)
        elif key == 'fiche:refente':
            has = any(r['refente'] for r in rows)
        elif key == 'fiche:surcoupe':
            has = bool(surcoupe_rows(doc, rows))
        else:
            has = bool(zone_rows(rows, key.split(':')[1]))
        if has:
            out.append(dict(id=key, title=title))
    return out


# --------------------------------------------------------------------------------- text sizes
_REG = dict(zip(' !"#$%&\'()*+,-./', (278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278)))
_REG.update({c: 556 for c in '0123456789'})
_REG.update(dict(zip(':;<=>?@', (278, 278, 584, 584, 584, 556, 1015))))
_REG.update(dict(zip('ABCDEFGHIJKLMNOPQRSTUVWXYZ', (667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611))))
_REG.update(dict(zip('[\\]^_`', (278, 278, 278, 469, 556, 333))))
_REG.update(dict(zip('abcdefghijklmnopqrstuvwxyz', (556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500))))
_REG.update({'{': 334, '|': 260, '}': 334, '~': 584, '²': 333, '×': 584, '€': 556, '°': 400, '·': 278, '’': 222, '«': 556, '»': 556, '↔': 1000, '—': 1000, '–': 556})
_BOLD = dict(_REG)
_BOLD.update(dict(zip('ABCDEFGHIJKLMNOPQRSTUVWXYZ', (722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722, 611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611))))
_BOLD.update(dict(zip('abcdefghijklmnopqrstuvwxyz', (556, 611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778, 556, 556, 500))))
_BOLD.update({'!': 333, ':': 333, ';': 333, '?': 611, '"': 474, "'": 238})


def text_width(text, size, bold=False):
    """Width in mm of a text in Helvetica (the PDF font) of ``size`` mm."""
    table = _BOLD if bold else _REG
    total = 0
    for c in str(text):
        w = table.get(c)
        if w is None:
            base = unicodedata.normalize('NFD', c)[:1]
            w = table.get(base, 556)
        total += w
    return total * size / 1000


def fitted(text, size, width, bold=False):
    """The text cut with « … » to fit ``width`` mm."""
    text = str(text)
    if text_width(text, size, bold) <= width:
        return text
    while text and text_width(text + '…', size, bold) > width:
        text = text[:-1]
    return text + '…'


# --------------------------------------------------------------------------------- pages
class Page(list):
    """Drawing orders in mm: ('line', points, width, colour, dash), ('poly', points, fill,
    outline, width), ('text', x, y, text, size, anchor, bold, angle, colour) — y of a text is its
    middle; anchor 'w', 'center' or 'e'; 0.19.14: ('image', x, y, width, height, picture) — its top
    left corner, the picture as kept in the infos (cad.validate_model_image)."""
    def line(self, pts, width=.25, color=INK, dash=None):
        self.append(('line', [tuple(p) for p in pts], width, color, list(dash) if dash else None))

    def poly(self, pts, fill=None, outline=None, width=.2):
        self.append(('poly', [tuple(p) for p in pts], fill, outline, width))

    def rect(self, x0, y0, x1, y1, fill=None, outline=INK, width=.25):
        self.poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], fill, outline, width)

    def text(self, x, y, text, size=3., anchor='w', bold=False, angle=0., color=INK):
        self.append(('text', x, y, str(text), size, anchor, bold, angle, color))

    def image(self, x, y, w, h, picture):
        self.append(('image', x, y, w, h, picture))


class Book:
    """The pages of one fiche: frame, top band and bottom line on each; « Page n/N » at the end."""
    def __init__(self, key, head):
        self.key = key
        self.head = head
        self.pages = []
        self.page = None
        self.y = 0.

    def new_page(self):
        p = Page()
        self.pages.append(p)
        p.rect(L, T, R, B, None, INK, .35)
        p.line([(L, T + HEAD), (R, T + HEAD)], .3)
        p.text(L + 3, T + 5, fitted(self.head.get('author', ''), 3.2, 60), 3.2)
        model, picture = self.head.get('model', ''), self.head.get('image')
        size = photo_size(picture)
        if size:
            # 0.19.14 « Image du modèle »: small, at the left of the model's name, both centred where the name was
            w, h = size
            name = fitted(model, 5., 90 - w - PHOTO_GAP) if model else ''
            x = (L + R - w - (PHOTO_GAP + text_width(name, 5.) if name else 0.)) / 2
            p.image(x, T + (HEAD - h) / 2, w, h, picture)
            if name:
                p.text(x + w + PHOTO_GAP, T + 7, name, 5.)
        else:
            p.text((L + R) / 2, T + 7, fitted(model, 5., 90), 5., 'center')
        p.line([(L, B - FOOT), (R, B - FOOT)], .3)
        p.text(L + 14, B - FOOT / 2, FOOTER.get(self.key, 'Fiche'), 3.)
        p.text(R - 4, B - FOOT / 2, f'Indice : {self.head.get("indice", "0")}      du : {self.head.get("date", "")}', 3., 'e')
        self.page = p
        self.y = T + HEAD
        return p

    def room(self):
        return B - FOOT - self.y

    def at_top(self):
        """Nothing on the page yet under its top band."""
        return self.y <= T + HEAD + 1e-6

    def band_room(self):
        """0.19.14: the height the band of a material takes here (with its space and thick rule under what is
        already on the page)."""
        return BAND + (0. if self.at_top() else BAND_GAP)

    def band(self, left, centre, right, suite=False):
        """The band of a material: column at the left, material in the middle, couleur / réf. and
        surface at the right, « (suite) » on the next pages. 0.19.14 (« la 2e matière se voit mal »): a
        light grey band across the sheet, the material in bold and larger; under something on the page, a
        little space and a thick rule before it."""
        p, y = self.page, self.y
        top = self.at_top()
        if not top:
            y += BAND_GAP
        p.rect(L + .2, y + (.15 if top else 0.), R - .2, y + BAND, BAND_FILL, None, 0)   # inside the lines around it
        if not top:
            p.line([(L, y), (R, y)], BAND_RULE)
        if left:
            p.text(L + 3, y + 4.6, left.upper(), 2.6)
        p.text((L + R) / 2, y + 4.6, fitted(centre, 4.6, 110, True), 4.6, 'center', True)
        for k, line in enumerate([v for v in right if v][:2]):
            p.text(R - 5, y + 4.4 + k * 4.4, line, 3.4, 'e')
        if suite:
            p.text((L + R) / 2, y + 10, '(suite)', 2.4, 'center')
        p.line([(L, y + BAND), (R, y + BAND)], .3)
        self.y = y + BAND

    def finish(self):
        n = len(self.pages)
        for k, p in enumerate(self.pages):
            p.text(R - 6, T + 6, f'Page  {k + 1}/{n}', 3.2, 'e')
        return self.pages


# --------------------------------------------------------------------------------- pictures
def members(items, i):
    """What the picture of piece ``i`` shows: its contour, crans, inner lines, the pieces to
    recut of a précoupe and its zones (texts aside)."""
    from entity_rules import fabrication_ids
    owner = items[i].get('piece_id')
    ids = set(fabrication_ids(items, [i], points=True)) | {i}
    if owner:
        ids |= {k for k, s in enumerate(items) if s.get('owner_id') == owner}
    return [items[k] for k in sorted(ids) if not (items[k].get('annotation') or items[k].get('dimension_group'))]


def strokes(items, i, outer_dash=None):
    """(points, closed, width, dash) of the picture of piece ``i``, in plan mm."""
    from geometry import path, export_entities
    from craft_tools import style
    import surcoupe as sc
    out = []
    shown = [s for s in members(items, i) if not s.get('preparation')]
    for s in export_entities(shown, pdf=True):
        try:
            pts, closed = path(s)
        except (ValueError, KeyError, TypeError):
            continue
        if len(pts) < 2:
            continue
        st = style(s)
        role = st['role']
        if s is shown[0] or (role == 'external' and outer_dash is not None):
            dash = outer_dash
            width = .3
        else:
            dash = sc.STYLE['dash'] if role == sc.ROLE else (st['dash'] if role in ('seam', 'guide') else None)
            width = .2
        out.append((pts, closed, width, dash))
    return out


def picture(page, items, row, box, scale, zone_fill=None, outer_dash=None, dims=True):
    """Piece ``row`` drawn in ``box`` (x0, y0, x1, y1 on the page) at ``scale`` (page mm per plan
    mm), centred; its zones filled by ``zone_fill(zone)``; width above, height at the left."""
    import preparations as prep
    x, y, X, Y = row['box']
    w, h = (X - x) * scale, (Y - y) * scale
    ox = (box[0] + box[2]) / 2 - w / 2
    oy = (box[1] + box[3]) / 2 - h / 2
    tr = lambda p: (ox + (p[0] - x) * scale, oy + (p[1] - y) * scale)
    if zone_fill:
        for z in row['zones']:
            colour = zone_fill(z)
            if colour:
                page.poly([tr(p) for p in prep.ring_points(z)], colour, None, 0)
    top, left = oy, ox
    for pts, closed, width, dash in strokes(items, row['index'], outer_dash):
        q = [tr(p) for p in pts]
        if closed:
            q.append(q[0])
        page.line(q, width, INK, dash)
        if q:   # 0.19.22 (found before installing: Mozart crans stick out of the outline and crossed the sizes)
            top = min(top, min(p[1] for p in q))
            left = min(left, min(p[0] for p in q))
    if dims:
        page.text(ox + w / 2, top - 2.6, size_text(X - x), 3., 'center')
        page.text(left - 2.8, oy + h / 2, size_text(Y - y), 3., 'center', angle=90.)
    return ox, oy, w, h


def common_scale(rows, width=90., height=110.):
    """One scale for every picture of a fiche (sizes compare), the largest piece fitting."""
    scale = 1.
    for r in rows:
        x, y, X, Y = r['box']
        scale = min(scale, width / max(1e-6, X - x), height / max(1e-6, Y - y))
    return scale


# --------------------------------------------------------------------------------- the fiches
def quantity_line(r):
    if r['precut'] and r['per'] > 1:
        return f'{r["cut"]} précoupe{"s" if r["cut"] > 1 else ""} · {pieces_text(r["quantity"])}'
    return pieces_text(r['cut'] if r['precut'] else r['quantity'])


def refente_text(value):
    return f'{str(value).replace(".", ",")}/10' if value else ''


def legend_key(z):
    p = z['preparation']
    return (str(p.get('type', '')).lower(), p.get('length'), p.get('thickness'))


def legend_text(z):
    """« Parage en pince 8 mm à 7/10 », « Rembord 7 mm à 5/10 »."""
    p = z['preparation']
    kind = str(p.get('type', '') or 'Parage').strip()
    name = {'pince': 'Parage en pince', 'rembord': 'Rembord'}.get(kind.lower(), kind[:1].upper() + kind[1:])
    text = name + (f' {num(p["length"])} mm' if p.get('length') else '')
    return text + (f' à {num(p["thickness"])}/10' if p.get('thickness') else '')


def groups(rows, with_surface=False, with_cost=False):
    """Consecutive lines of the same column and material, with the band's texts."""
    out = []
    for r in rows:
        key = (r['column'], r['material'])
        if not out or out[-1]['key'] != key:
            out.append(dict(key=key, rows=[], left=r['column_label'], material=r['material'], color=r['info'].get('color', '')))
        out[-1]['rows'].append(r)
    for g in out:
        right = [g['color']]
        if with_surface:
            right.append(f'{fmt(sum(r["surface"] * r["cut"] for r in g["rows"]) / 1e6, 4)} m²')
        if with_cost and any(r['cost'] is not None for r in g['rows']):
            right[-1] += f' · {fmt(sum(r["cost"] for r in g["rows"] if r["cost"] is not None))} €'
        g['right'] = right
    return out


def card_fiche(book, items, rows, key, model, lines_of, mode='common', zone_fill=None, outer_dash=None, with_surface=False, with_cost=False, surface_left=False):
    """Bands and lines of pictures. ``mode`` 'common': one scale for the fiche, lines as high as
    their picture; 'each': three lines a page, each picture as large as its line allows."""
    scale = common_scale(rows) if mode == 'common' else None
    book.new_page()
    for g in groups(rows, with_surface, with_cost):
        first = True
        for r in g['rows']:
            lines = lines_of(r)
            text_h = len(lines) * LINE + 6
            if mode == 'common':
                x, y, X, Y = r['box']
                pic_h = max(3., (Y - y) * scale)
                height = max(pic_h + 12, text_h, 18)
            else:
                height = (B - FOOT - T - HEAD - BAND) / 3
            need = height + (book.band_room() if first else 0)   # a band never alone at the bottom of a page
            if book.room() < need:
                book.new_page()
                book.band(g['left'], g['material'], g['right'], suite=not first)
            elif first:
                book.band(g['left'], g['material'], g['right'])
            first = False
            p = book.page
            top = book.y
            left = 34. if surface_left else THUMB[0]
            if surface_left:
                p.text(L + 3, top + 6, f'{fmt(r["surface"] / 1e6, 4)} m²', 2.8)
            if mode == 'common':
                box = (left, top + 7, THUMB[1], top + height - 4)
                picture(p, items, r, box, scale, zone_fill, outer_dash)
            else:
                x, y, X, Y = r['box']
                each = min(1., (THUMB[1] - left - 10) / max(1e-6, X - x), (height - 16) / max(1e-6, Y - y))
                picture(p, items, r, (left + 6, top + 8, THUMB[1], top + height - 5), each, zone_fill, outer_dash)
            ty = top + 5
            for line in lines:
                if isinstance(line, tuple):
                    colour, text = line
                    p.rect(TEXT_X, ty - 1.4, TEXT_X + 4.5, ty + 1.4, colour, None, 0)
                    p.text(TEXT_X + 7, ty, fitted(text, 3., R - TEXT_X - 12), 3.)
                else:
                    p.text(TEXT_X, ty, fitted(line, 3., R - TEXT_X - 5), 3.)
                ty += LINE
            book.y = top + height
            if mode != 'common':
                p.line([(L, book.y), (R, book.y)], .3)
    if not rows:
        book.page.text((L + R) / 2, T + HEAD + 20, 'Aucune pièce.', 4., 'center')
    return book


def totals(book, rows):
    """Coupe: the totals by material (pieces, surface, with the chute, cost) and the grand total."""
    import materials as mat
    by = {}
    for r in rows:
        t = by.setdefault(r['material'], dict(material=r['material'], pieces=0, surface=0., waste=0., cost=None))
        t['pieces'] += r['cut']
        t['surface'] += r['surface'] * r['cut'] / 1e6
        t['waste'] += r['surface'] * r['cut'] / 1e6 * (1 + r['info']['waste'] / 100)
        if r['cost'] is not None:
            t['cost'] = (t['cost'] or 0) + r['cost']
    lines = [by[k] for k in sorted(by, key=mat.sort_key)]
    if not lines:
        return
    cols = [(L + 4, 'Matière', 'w'), (118., 'Pièces', 'e'), (146., 'Surface (m²)', 'e'), (174., 'Avec chute (m²)', 'e'), (R - 4, 'Coût (€)', 'e')]
    need = 16 + 6 * (len(lines) + 1)
    if book.room() < min(need, 60):
        book.new_page()
    p, y = book.page, book.y + 6
    p.text(L + 4, y, 'Totaux', 3.6, bold=True)
    y += 6
    p.rect(L + 2, y - 3, R - 2, y + 3, SHADE, None, 0)
    for x, title, anchor in cols:
        p.text(x, y, title, 2.8, anchor, True)
    grand = None if all(t['cost'] is None for t in lines) else sum(t['cost'] or 0 for t in lines)
    rows_out = [(t['material'], str(t['pieces']), fmt(t['surface'], 4), fmt(t['waste'], 4), fmt(t['cost'])) for t in lines]
    rows_out.append(('Total', str(sum(t['pieces'] for t in lines)), fmt(sum(t['surface'] for t in lines), 4), fmt(sum(t['waste'] for t in lines), 4), fmt(grand)))
    for k, values in enumerate(rows_out):
        y += 6
        if y > B - FOOT - 4:
            book.new_page()
            p, y = book.page, book.y + 6
        bold = k == len(rows_out) - 1
        if bold:
            p.line([(L + 2, y - 3), (R - 2, y - 3)], .3)
        for (x, _, anchor), value in zip(cols, values):
            p.text(x, y, fitted(value, 3., 70) if anchor == 'w' else value, 3., anchor, bold)
    book.y = y + 4


# --------------------------------------------------------------------------------- nomenclature
# 0.18.2: like the person's own (Nomenclature_DiformeJONC): read from the bottom, the header just
# above the foot of the sheet; RP (ID unique) | NB | Nom | Matériaux | Informations.
NOMEN = (('RP', 11., 'center'), ('NB', 11., 'center'), ('Nom', 66., 'w'), ('Matériaux', 42., 'center'), ('Informations', 58., 'w'))
NOMEN_ROW, NOMEN_PITCH, NOMEN_TEXT = 5.5, 3.3, 2.9   # mm: smallest line, between two lines of a cell, text
# (a bag like DIFORME, 33 pieces and 8 fournitures, holds on one sheet)
NOMEN_KINDS = {'Cuir': 0, 'Tissu': 1, 'Renfort': 2, 'Gabarit': 3}


def category(r):
    """0 faces extérieures (Dessus), 1 doublures, 2 renforts, 3 aides: the base's column of the
    piece, else the type of its material (4 when unknown)."""
    col = r['column']
    if col is not None and 2 <= col <= 5:
        return col - 2
    return NOMEN_KINDS.get(r['info'].get('type'), 4)


def nomenclature_order(rows):
    """The pieces as the person orders them: all the pieces of a material together, the materials
    in the order of their first piece (faces extérieures, doublures, renforts, aides; a lining in
    the leather of the dessus stays with it); in a material the ID uniques' order, then the pieces
    without one in the base's order."""
    def key(r):
        if r['number']:
            return (0, r['number'], 0, 0., 0.)
        return (1, 0, category(r), round(r['box'][1], 1), round(r['box'][0], 1))
    first = {}
    for r in rows:
        k = (category(r), key(r))
        if r['material'] not in first or k < first[r['material']]:
            first[r['material']] = k
    return sorted(rows, key=lambda r: (first[r['material']], key(r)))


def torons(app, rows):
    """0.19.14: [(Ø, cut length, how many)] of the torons of the handles among the pieces (the Poignée toron writes them
    on its piece, or on the piece inside its précoupe), the same toron counted together."""
    found = {}
    owners = {}
    for s in app.items:
        if s.get('toron') and s.get('owner_id'):
            owners.setdefault(s['owner_id'], s['toron'])
    for r in rows:
        s = app.items[r['index']]
        data = s.get('toron') or owners.get(s.get('piece_id'))
        if not isinstance(data, dict):
            continue
        try:
            key = (float(data['diameter']), float(data['length']))
            n = int(r['quantity'])
        except (KeyError, TypeError, ValueError):
            continue
        found[key] = found.get(key, 0) + n
    return [(d, l, n) for (d, l), n in found.items()]


def nomenclature_lines(app, rows):
    """[(cells, merge keys)] from the first line (at the bottom) to the last: the pieces, then the
    fournitures of the Infos du modèle as typed. A material is written once for its pieces (and
    for fournitures that follow each other with the same one); Informations once when they follow
    each other in a material."""
    import surcoupe as sc
    out = []
    for r in nomenclature_order(rows):
        info = []
        if r['refente']:
            info.append('Refente ' + refente_text(r['refente']))
        info += r.get('refente_lines', []) + [x for x in r.get('cut_lines', []) if x.startswith(('Couleur', 'Couper'))]
        if r['precut']:
            gap = sc.band_width(app.items, r['index'])
            info.append(f'Précoupe de {r["per"]}' if r['per'] > 1 else 'Surcoupe' + (f' {num(gap)} mm' if gap else ''))
        out.append([str(r['number'] or ''), str(r['quantity']), r['name'], r['material'], ' · '.join(info), ('piece', r['material'])])
    run = 0
    # 0.19.14: the toron of each Poignée toron, a fourniture written by Craft (its Ø, its cut with the biseaux)
    for diameter, length, n in torons(app, rows):
        run += 1
        out.append(['', str(n), 'TORON', f'Ø {num(diameter)} mm', f'coupe {num(length)} mm (biseaux compris)', ('supply', run)])
    for s in (app.__dict__.get('infos') or {}).get('fournitures') or []:
        material = str(s.get('matiere', '') or '').strip()
        if not (out and out[-1][5][0] == 'supply' and material and out[-1][3] == material):
            run += 1
        out.append(['', str(s.get('nb', '') or ''), str(s.get('nom', '') or ''), material, str(s.get('info', '') or ''), ('supply', run)])
    lines = []
    for k, (rp, nb, name, material, info, group) in enumerate(out):
        mat_key = group if material else None
        info_key = (group, info) if info else None
        lines.append(([rp, nb, name, material, info], [None, None, None, mat_key, info_key]))
    return lines


def wrapped(text, size, width, most=3):
    """``text`` on the lines ``width`` mm needs (at most ``most``, the last one cut with …)."""
    out = []
    for word in str(text).split():
        if out and text_width(out[-1] + ' ' + word, size) <= width:
            out[-1] += ' ' + word
        else:
            out.append(word)
    out = out or ['']
    if len(out) > most:
        out = out[:most - 1] + [' '.join(out[most - 1:])]
    return [fitted(line, size, width) for line in out]


def nomenclature(book, app, rows):
    """The table read from the bottom: the header just above the foot, the first piece above it,
    the fournitures at the top; on the next sheets the same. A cell merged over several lines
    (material, informations) is framed once and written in its middle."""
    xs, x = [], L + 3
    for _, width, _ in NOMEN:
        xs.append(x)
        x += width
    right = x
    lines = nomenclature_lines(app, rows)
    pad = 2.2

    def height(cells, keys, alone):
        need = NOMEN_ROW
        for c, (text, (_, width, _)) in enumerate(zip(cells, NOMEN)):
            if keys[c] is None or alone[c]:
                need = max(need, pad + len(wrapped(text, NOMEN_TEXT, width - 3)) * NOMEN_PITCH)
        return need
    # a merged cell alone on its line counts for the line's height
    alone = []
    for k, (cells, keys) in enumerate(lines):
        alone.append([keys[c] is not None and (k == 0 or lines[k - 1][1][c] != keys[c]) and (k == len(lines) - 1 or lines[k + 1][1][c] != keys[c]) for c in range(len(NOMEN))])
    heights = [height(cells, keys, alone[k]) for k, (cells, keys) in enumerate(lines)]
    head_h = 7.
    bottom = B - FOOT - 3.
    top_limit = T + HEAD + 3.
    sheets, placed, y = [], [], bottom - head_h
    for k, h in enumerate(heights):
        if placed and y - h < top_limit:
            sheets.append(placed)
            placed, y = [], bottom - head_h
        placed.append((k, y - h, y))
        y -= h
    sheets.append(placed)
    for placed in sheets:
        book.new_page()
        p = book.page
        p.rect(xs[0], bottom - head_h, right, bottom, SHADE, None, 0)
        for (title, width, _), x0 in zip(NOMEN, xs):
            p.text(x0 + width / 2, bottom - head_h / 2, title, NOMEN_TEXT, 'center', True)
        if not placed:
            p.text((L + R) / 2, bottom - head_h - 12, 'Aucune pièce.', 4., 'center')
            p.rect(xs[0], bottom - head_h, right, bottom, None, INK, .3)
            continue
        top = placed[-1][1]
        for c, ((_, width, anchor), x0) in enumerate(zip(NOMEN, xs)):
            blocks = []
            for k, y0, y1 in placed:
                key = lines[k][1][c]
                if blocks and key is not None and blocks[-1][0] == key:
                    blocks[-1][2] = y0
                else:
                    blocks.append([key, y1, y0, lines[k][0][c]])
            for key, y1, y0, text in blocks:
                p.line([(x0, y1), (x0 + width, y1)], .2)
                p.line([(x0, y0), (x0 + width, y0)], .2)
                if not text:
                    continue
                parts = wrapped(text, NOMEN_TEXT, width - 3)
                while len(parts) > 1 and len(parts) * NOMEN_PITCH > y1 - y0 - 1:
                    parts = wrapped(text, NOMEN_TEXT, width - 3, len(parts) - 1)
                mid = (y0 + y1) / 2 - (len(parts) - 1) * NOMEN_PITCH / 2
                tx = x0 + 1.5 if anchor == 'w' else x0 + width / 2
                for n, part in enumerate(parts):
                    p.text(tx, mid + n * NOMEN_PITCH, part, NOMEN_TEXT, 'w' if anchor == 'w' else 'center')
        for x0 in xs[1:]:
            p.line([(x0, top), (x0, bottom)], .2)
        p.rect(xs[0], top, right, bottom, None, INK, .3)
        p.line([(xs[0], bottom - head_h), (right, bottom - head_h)], .3)


def pages(app, key, rows=None):
    """The pages of fiche ``key``."""
    import materials as mat
    import surcoupe as sc
    rows = pieces(app) if rows is None else rows
    head = head_of(app)
    model = head['model']
    book = Book(key, head)
    items = app.items
    if key == 'fiche:coupe':
        card_fiche(book, items, rows, key, model, lambda r: [r['name'], quantity_line(r)] + r.get('cut_lines', []), with_surface=True, with_cost=True)
        totals(book, rows)
    elif key == 'fiche:refente':
        chosen = [r for r in rows if r['refente']]
        card_fiche(book, items, chosen, key, model, lambda r: [r['name'], quantity_line(r), refente_text(r['refente'])] + r.get('refente_lines', []))
    elif key == 'fiche:parage':
        chosen = zone_rows(rows, 'parage')
        colours = {}
        for r in chosen:
            for z in r['zones']:
                if z['preparation'].get('kind') == 'parage':
                    colours.setdefault(legend_key(z), LEGEND[len(colours) % len(LEGEND)])

        def lines(r):
            out = [r['name'], quantity_line(r)]
            if r['refente']:
                out.append(refente_text(r['refente']))
            seen = []
            for z in r['zones']:
                k = legend_key(z)
                if z['preparation'].get('kind') == 'parage' and k not in seen:
                    seen.append(k)
                    out.append((colours[k], legend_text(z)))
            return out
        card_fiche(book, items, chosen, key, model, lines, 'each', lambda z: colours.get(legend_key(z)) if z['preparation'].get('kind') == 'parage' else None)
    elif key == 'fiche:teinte':
        chosen = zone_rows(rows, 'teinte')

        def lines(r):
            coats = max([int(z['preparation'].get('couches') or 1) for z in r['zones'] if z['preparation'].get('kind') == 'teinte'] or [1])
            return [r['name'], quantity_line(r), f'Couche(s) : {coats}']
        card_fiche(book, items, chosen, key, model, lines, 'each', lambda z: TEINTE if z['preparation'].get('kind') == 'teinte' else None)
    elif key == 'fiche:surcoupe':
        chosen = surcoupe_rows(app, rows)

        def lines(r):
            out = [r['name'], quantity_line(r)]
            gap = sc.band_width(items, r['index'])
            if gap:
                out.append(f'Surcoupe {num(gap)} mm')
            final = sc.final_size(items, r['index'])
            if final:
                out.append(f'Fini {size_text(final[0])} × {size_text(final[1])}')
            if r['per'] > 1:
                out.append(f'{r["per"]} pièces par précoupe')
            return out
        card_fiche(book, items, chosen, key, model, lines, 'each', lambda z: SURCOUPE if z['preparation'].get('kind') == 'surcoupe' else None, outer_dash=sc.STYLE['dash'])
    elif key == 'fiche:generale':
        def lines(r):
            out = [r['name'], f'{quantity_line(r)}      {model or ""}'.rstrip()]
            if r['refente']:
                out.append('Refente ' + refente_text(r['refente']))
            return out
        card_fiche(book, items, rows, key, model, lines, with_surface=True, surface_left=True)
    elif key == 'fiche:nomenclature':
        nomenclature(book, app, rows)
    else:
        book.new_page()
    return book.finish()


# --------------------------------------------------------------------------------- on screen
_CACHE = {}


def _signature(app, key):
    import json
    try:
        archive = json.dumps((app.__dict__.get('archives') or {}).get('material_info', {}), sort_keys=True, default=str)
    except (TypeError, ValueError):
        archive = ''
    infos = app.__dict__.get('infos')
    if isinstance(infos, dict) and 'image' in infos:
        infos = dict(infos, image=image_key(infos['image']))   # 0.19.14: the picture by its key, not written out at each drawing
    return (key, id(app.items), app.__dict__.get('_doc_version', 0), len(app.items), repr(infos), archive,
            repr(app.__dict__.get('workspace')), app.__dict__.get('filename'), app.__dict__.get('project_model'))


def cached_pages(app, key):
    sig = _signature(app, key)
    found = _CACHE.get(id(app))
    if found and found[0] == sig:
        return found[1]
    result = pages(app, key)
    _CACHE[id(app)] = (sig, result)
    return result


def draw(app, key):
    """The fiche on the canvas: its A4 sheets one below the other; the wheel scrolls them."""
    c = app.canvas
    c.delete('all')
    app.pointer_cursor('arrow')
    if not is_auto(key):
        return
    W, H = max(200, c.winfo_width()), max(200, c.winfo_height())
    try:
        sheets = cached_pages(app, key)
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError) as exc:
        c.create_text(40, 40, text='Fiche indisponible : ' + str(exc), anchor='nw', fill=app.p['ui_ink'], font=('Segoe UI', 11))
        return
    width = max(260, min(W - 80, 860))
    k = width / PW
    left = (W - width) / 2
    gap = 26
    top0 = 44 - app.__dict__.get('_fiche_scroll', 0)
    for n, page in enumerate(sheets):
        top = top0 + n * (PH * k + gap)
        if top > H or top + PH * k < 0:
            continue
        c.create_rectangle(left, top, left + width, top + PH * k, fill=PAPER, outline=EDGE, tags='fiche_sheet')
        render_canvas(c, page, left, top, k)
    app._fiche_height = 44 + len(sheets) * (PH * k + gap)
    bar = app.__dict__.get('_fiche_bar')
    if bar is None or not bar.winfo_exists():
        import tkinter as tk
        bar = tk.Frame(c, bg=app.p['panel'])
        app._fiche_bar = bar
        app.button(bar, 'Imprimer…', lambda: choose(app, 'print')).pack(side='left', padx=3)
        app.button(bar, 'Exporter PDF…', lambda: choose(app, 'pdf')).pack(side='left', padx=3)
    c.create_window(W - 16, 8, window=bar, anchor='ne')


def render_canvas(c, page, left, top, k):
    X = lambda x: left + x * k
    Y = lambda y: top + y * k
    for op in page:
        kind = op[0]
        if kind == 'line':
            _, pts, width, color, dash = op
            if len(pts) < 2:
                continue
            opts = dict(fill=color, width=max(.6, width * k), tags='fiche')
            if dash:
                opts['dash'] = tuple(max(1, round(v * k)) for v in dash)
            c.create_line(*[v for p in pts for v in (X(p[0]), Y(p[1]))], **opts)
        elif kind == 'poly':
            _, pts, fill, outline, width = op
            if len(pts) < 3:
                continue
            c.create_polygon(*[v for p in pts for v in (X(p[0]), Y(p[1]))], fill=fill or '', outline=outline or '', width=max(.6, width * k) if outline else 0, tags='fiche')
        elif kind == 'text':
            _, x, y, text, size, anchor, bold, angle, color = op
            px = max(1, round(size * k))
            if px < 4:
                continue
            opts = dict(text=text, anchor=anchor, fill=color, font=('Helvetica', -px, 'bold' if bold else 'normal'), tags='fiche')
            if angle:
                opts['angle'] = angle
            c.create_text(X(x), Y(y), **opts)
        elif kind == 'image':
            _, x, y, w, h, picture = op
            photo = photo_of(c, picture, max(1, round(w * k)), max(1, round(h * k)))
            if photo is not None:
                c.create_image(X(x), Y(y), image=photo, anchor='nw', tags=('fiche', 'fiche_photo'))


def photo_of(canvas, picture, width, height):
    """0.19.14: the Image du modèle at width × height pixels for ``canvas`` (backdrop: Pillow, GDI+ under Windows),
    kept for its next drawings (the wheel scrolls the fiche); None when it cannot be read: the fiche is drawn
    without it."""
    kept = canvas.__dict__.setdefault('_fiche_photos', {})
    key = (image_key(picture), width, height)
    if key not in kept:
        if len(kept) >= 8:
            kept.clear()
        try:
            import base64
            import backdrop
            import display_render
            b = backdrop.require()
            decoded = b.from_encoded(base64.b64decode(picture['data']))
            try:
                pw, ph = b.size(decoded)
                data = b.view(decoded, (0, 0, pw, ph), (width, height), 1., (255, 255, 255))
            finally:
                b.dispose(decoded)
            kept[key] = display_render.photo_image(canvas, data)
        except Exception:   # never a fiche refused for its picture (unreadable, no picture reader…)
            kept[key] = None
    return kept[key]


def scroll(app, e):
    step = -80 if (getattr(e, 'delta', 0) > 0 or getattr(e, 'num', 0) == 4) else 80
    H = app.canvas.winfo_height()
    limit = max(0, app.__dict__.get('_fiche_height', 0) - H + 40)
    app._fiche_scroll = max(0, min(limit, app.__dict__.get('_fiche_scroll', 0) + step))
    app.redraw()


# --------------------------------------------------------------------------------- PDF
def _pdf_colour(c):
    c = c.lstrip('#')
    return ' '.join(f'{int(c[i:i + 2], 16) / 255:.4f}' for i in (0, 2, 4))


def render_pdf(page, images=None):
    """The PDF content stream of a page; ``images``: the name of each picture's image (by image_key) in the PDF,
    a picture without one is left out."""
    k = 72 / 25.4
    out = []

    def P(x, y):
        return f'{x * k:.2f} {(PH - y) * k:.2f}'

    def esc(t):
        return t.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)')
    for op in page:
        kind = op[0]
        if kind == 'line':
            _, pts, width, color, dash = op
            if len(pts) < 2:
                continue
            d = '[' + ' '.join(f'{v * k:.2f}' for v in dash) + '] 0 d' if dash else '[] 0 d'
            out.append(f'{_pdf_colour(color)} RG {width * k:.3f} w {d} 1 j ' + ' '.join(P(*p) + (' m' if n == 0 else ' l') for n, p in enumerate(pts)) + ' S\n')
        elif kind == 'poly':
            _, pts, fill, outline, width = op
            if len(pts) < 3:
                continue
            path = ' '.join(P(*p) + (' m' if n == 0 else ' l') for n, p in enumerate(pts)) + ' h'
            if fill and outline:
                out.append(f'{_pdf_colour(fill)} rg {_pdf_colour(outline)} RG {width * k:.3f} w [] 0 d {path} B\n')
            elif fill:
                out.append(f'{_pdf_colour(fill)} rg {path} f\n')
            elif outline:
                out.append(f'{_pdf_colour(outline)} RG {width * k:.3f} w [] 0 d {path} S\n')
        elif kind == 'text':
            _, x, y, text, size, anchor, bold, angle, color = op
            w = text_width(text, size, bold)
            th = math.radians(angle)
            d = (math.cos(th), -math.sin(th))          # along the text, page coordinates (y down)
            u = (-math.sin(th), -math.cos(th))         # up the text
            shift = {'w': 0., 'center': w / 2, 'e': w}.get(anchor, 0.)
            bx = x - d[0] * shift - u[0] * .36 * size
            by = y - d[1] * shift - u[1] * .36 * size
            co, si = math.cos(th), math.sin(th)
            out.append(f'BT /{"F2" if bold else "F1"} {size * k:.2f} Tf {_pdf_colour(color)} rg {co:.5f} {si:.5f} {-si:.5f} {co:.5f} {P(bx, by)} Tm ({esc(text)}) Tj ET\n')
        elif kind == 'image':
            _, x, y, w, h, picture = op
            name = (images or {}).get(image_key(picture))
            if name and w > 0 and h > 0:
                out.append(f'q {w * k:.3f} 0 0 {h * k:.3f} {x * k:.3f} {(PH - y - h) * k:.3f} cm /{name} Do Q\n')
    return ''.join(out)


def jpeg_frame(data):
    """0.19.14: (width, height, components, bits, kind) of a JPEG read from its frame header (SOF0 to SOF15), None
    when it has none."""
    if data[:2] != b'\xff\xd8':
        return None
    i, n = 2, len(data)
    while i + 4 <= n:
        if data[i] != 0xFF:
            return None
        marker = data[i + 1]
        if marker == 0xFF:          # fill byte
            i += 1
            continue
        if marker == 0x01 or 0xD0 <= marker <= 0xD8:   # markers without a length
            i += 2
            continue
        if marker in (0xD9, 0xDA):   # the end, or the picture's data before any frame
            return None
        length = int.from_bytes(data[i + 2:i + 4], 'big')
        if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
            if length < 8 or i + 10 > n:
                return None
            height, width = int.from_bytes(data[i + 5:i + 7], 'big'), int.from_bytes(data[i + 7:i + 9], 'big')
            return (width, height, data[i + 9], data[i + 4], marker) if width and height else None
        if length < 2:
            return None
        i += 2 + length
    return None


def pdf_image(picture):
    """0.19.14: (entries of its dictionary, bytes) of the Image du modèle as a PDF image: a JPEG kept as it is
    (DCTDecode); a PNG, or a JPEG a PDF does not take as it is (CMYK, arithmetic coding…), decoded by backdrop
    (Pillow, GDI+ under Windows) into RGB pixels (FlateDecode). None when it cannot be read: the fiches are
    written without it."""
    import base64
    import zlib
    try:
        raw = base64.b64decode(picture['data'])
    except (KeyError, TypeError, ValueError):
        return None
    if picture.get('format') == 'jpeg':
        frame = jpeg_frame(raw)
        if frame and frame[2] in (1, 3) and frame[3] == 8 and frame[4] in (0xC0, 0xC1, 0xC2):
            space = 'DeviceGray' if frame[2] == 1 else 'DeviceRGB'
            return f'/Width {frame[0]} /Height {frame[1]} /ColorSpace /{space} /BitsPerComponent 8 /Filter /DCTDecode', raw
    try:
        import backdrop
        w, h, rgb = backdrop.decoded_rgb(raw)
    except Exception:   # no picture reader here, a picture it cannot read: the fiches without it
        return None
    return f'/Width {w} /Height {h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode', zlib.compress(rgb, 6)


def write_pdf(file, sheets):
    """A4 portrait PDF of the pages (Helvetica, WinAnsi): the number of pages. 0.19.14: each picture (the Image du
    modèle) written once as an image the pages use; one that cannot be read is left out."""
    k = 72 / 25.4
    names, images = {}, []
    for p in sheets:
        for op in p:
            key = image_key(op[5]) if op[0] == 'image' else None
            if key is not None and key not in names:
                made = pdf_image(op[5])
                names[key] = f'Im{len(images) + 1}' if made else None
                if made:
                    images.append(made)
    names = {key: name for key, name in names.items() if name}
    data = [render_pdf(p, names).encode('cp1252', errors='replace') for p in sheets]
    objects = [b'<< /Type /Catalog /Pages 2 0 R /ViewerPreferences << /PrintScaling /None >> >>', b'',
               b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
               b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>']
    first = len(objects) + 1   # Im1 is this object, Im2 the next…; then the pages
    for entries, raw in images:
        objects.append(f'<< /Type /XObject /Subtype /Image {entries} /Length {len(raw)} >>\nstream\n'.encode() + raw + b'\nendstream')
    kids = []
    for p, d in zip(sheets, data):
        pid = len(objects) + 1
        kids.append(f'{pid} 0 R')
        used = sorted({names.get(image_key(op[5])) for op in p if op[0] == 'image'} - {None})
        xobjects = (' /XObject << ' + ' '.join(f'/{v} {first + int(v[2:]) - 1} 0 R' for v in used) + ' >>') if used else ''
        objects.append(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PW * k:.2f} {PH * k:.2f}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >>{xobjects} >> /Contents {pid + 1} 0 R >>'.encode())
        objects.append(f'<< /Length {len(d)} >>\nstream\n'.encode() + d + b'\nendstream')
    objects[1] = f'<< /Type /Pages /Count {len(kids)} /Kids [{" ".join(kids)}] >>'.encode()
    buf = bytearray(b'%PDF-1.4\n%\xe2\xe3\xcf\xd3\n')
    offsets = []
    for i, obj in enumerate(objects, 1):
        offsets.append(len(buf))
        buf.extend(f'{i} 0 obj\n'.encode() + obj + b'\nendobj\n')
    start = len(buf)
    buf.extend(f'xref\n0 {len(objects) + 1}\n0000000000 65535 f \n'.encode())
    for o in offsets:
        buf.extend(f'{o:010d} 00000 n \n'.encode())
    buf.extend(f'trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{start}\n%%EOF\n'.encode())
    # 0.19.9: written beside then put in place (like cad.write_document): a failed write never leaves a cut
    # PDF where the previous one was; the temporary file goes. A PDF open in a reader still gives PermissionError.
    p = Path(file)
    temp = p.with_name(p.name + '.tmp')
    try:
        temp.write_bytes(buf)
        temp.replace(p)
    except BaseException:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass
        raise
    return len(data)


def book_of(app, keys):
    """The pages of the fiches ``keys``, one after the other (each on its own pages)."""
    rows = pieces(app)
    out = []
    for key in keys:
        out += pages(app, key, rows)
    return out


# --------------------------------------------------------------------------------- print / export
def safe(text):
    import re
    # A name Windows accepts; never starting with « ~ » (Tk would read it as a user's folder).
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]+', '_', text or 'Fiche').strip(' .').lstrip('~').strip(' .') or 'Fiche'


def title_of(app, keys):
    import model_info
    names = dict(AUTO)
    model = model_info.model_name(app)
    what = 'Fiches' if len(keys) > 1 else 'Fiche ' + names.get(keys[0], '').lower()
    return what + (' - ' + model if model else '')


def choose(app, action):
    """0.18.1: the fiches to print or export: the one shown, some or « Toutes » (each on its own
    pages); the choice is remembered."""
    import tkinter as tk
    offered = available(app.items, app.archives, app)
    if not offered:
        app.status.set('Aucune fiche à imprimer.')
        return None
    keys = [v['id'] for v in offered]
    last = [k for k in app.prefs.get('fiche_choice', []) if k in keys]
    current = app.__dict__.get('active_section')
    chosen = set(last or ([current] if current in keys else keys[:1]))
    win = app.dialog('Imprimer les fiches' if action == 'print' else 'Exporter les fiches en PDF')
    panel = app.p['panel']
    options = dict(bg=panel, fg=app.p['ui_ink'], selectcolor=app.field_background(), activebackground=panel, font=('Segoe UI', 10))
    boxes = {k: tk.BooleanVar(value=k in chosen) for k in keys}
    every = tk.BooleanVar(value=len(chosen) == len(keys))

    def all_changed():
        for v in boxes.values():
            v.set(every.get())

    def one_changed():
        every.set(all(v.get() for v in boxes.values()))
    __import__('modern_style').make_check(win, text='Toutes', variable=every, command=all_changed, **options).pack(anchor='w', padx=16, pady=(14, 2))
    for v in offered:
        __import__('modern_style').make_check(win, text=v['title'], variable=boxes[v['id']], command=one_changed, **options).pack(anchor='w', padx=32)

    def go(e=None):
        picked = [k for k in keys if boxes[k].get()]
        if not picked:
            return 'break'
        win.destroy()
        app.prefs['fiche_choice'] = picked
        try:
            app.persist_preferences()
        except OSError:
            pass
        return (print_fiches if action == 'print' else save_fiches)(app, picked)
    row = tk.Frame(win, bg=panel)
    row.pack(fill='x', padx=16, pady=(10, 14))
    app.button(row, 'Annuler', win.destroy).pack(side='right')
    app.button(row, 'Imprimer' if action == 'print' else 'Exporter PDF…', go).pack(side='right', padx=6)
    win.bind('<Return>', go)
    win.bind('<Escape>', lambda e: win.destroy())
    win._fiche_choice = dict(boxes=boxes, every=every, go=go)
    return win


def save_fiches(app, keys):
    from tkinter import filedialog, messagebox
    if hasattr(app, 'licence_export') and not app.licence_export():
        return None
    import doc_files
    title = title_of(app, keys)
    options = dict(parent=app, defaultextension='.pdf', filetypes=doc_files.export_types('pdf'), initialfile=safe(title) + '.pdf')
    folder = doc_files.initial_dir(app.prefs)
    if folder:
        options['initialdir'] = folder
    file = filedialog.asksaveasfilename(**options)
    if not file:
        return None
    try:
        n = write_pdf(file, book_of(app, keys))
        doc_files.remember_folder(app.prefs, file)
        app.status.set(f'Fiches exportées ({n} page{"s" if n > 1 else ""}) : ' + Path(file).name)
        return file
    except OSError as exc:
        messagebox.showerror('Fiches', str(exc), parent=app)
        return None


def print_fiches(app, keys):
    """« Imprimer »: the fiches chosen as one PDF sent to the printer (each fiche on its pages)."""
    from export_preview import print_target, start_print_helper, print_pdf, wait_print
    if hasattr(app, 'licence_export') and not app.licence_export():
        return None
    title = title_of(app, keys)
    sheets = book_of(app, keys)
    for target in print_target(title):
        try:
            write_pdf(target, sheets)
            break
        except PermissionError:
            continue
    else:
        app.status.set('Fichier d’impression occupé : fermer le lecteur PDF.')
        return None
    process = start_print_helper(target, 'Craft - ' + title)
    if process is None:
        try:
            app.status.set(print_pdf(target))
        except OSError as exc:
            app.status.set('Impression impossible : ' + str(exc))
    else:
        app.status.set('Impression…')
        # 0.19.9: the helper's result is read as for the pattern (its failure opens the PDF in the reader).
        app.after(250, lambda: wait_print(app, process, target))
    return target
