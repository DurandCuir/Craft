"""0.19.0: the modern look of Craft, in one place.

Every colour comes from the palette chosen in Réglages (panel, canvas, accent): only the alert
colours are fixed. Rounded shapes are drawn here, antialiased, as opaque pictures on the colour
around them (nothing relies on transparency): the same pixels under Windows and Linux.

What is here:
- ``tokens``: the colours of the interface, derived from the palette;
- ``font``: Segoe UI Variable (Windows 11) or Segoe UI;
- ``Button``, ``Checkbutton``, ``Radiobutton``: the usual Tk widgets for the code and the tests
  (``invoke``, ``cget('text')``, ``state``…), drawn rounded and flat;
- ``tile``: the rounded background of an icon button (hover, chosen tool, switch on);
- ``MenuStrip``: the menu bar drawn by Craft (the Windows one stayed white over a dark Craft);
- ``tooltip``: the help bubble;
- the message windows (``messagebox``) and the small questions (``simpledialog``) in Craft's look;
- ``frame``: under Windows, the title bar in the panel colour (dark mode, Windows 11 colour) and
  small rounded corners for the floating lists and bubbles;
- ``apply``: all of it for a window, at startup and after a change of colours.
"""
import collections
import functools
import math
import os
import tkinter as tk
import weakref

from ui_widgets import contrast_color

FAMILY = 'Segoe UI'
GRIP = 6            # radius of a button, a field, a tab (px at 100 %)
_REAL = dict(Button=tk.Button, Checkbutton=tk.Checkbutton, Radiobutton=tk.Radiobutton, Frame=tk.Frame,
             Label=tk.Label, Toplevel=tk.Toplevel)


def real():
    """False while tests replaced the Tk widgets by stand-ins: plain widgets are made then."""
    return all(getattr(tk, k) is v for k, v in _REAL.items())


# ----------------------------------------------------------------------------------------------
# Colours

def rgb(color, widget=None):
    """'#rrggbb' (or '#rgb', or a Tk colour name with ``widget``) to an (r, g, b) tuple."""
    value = str(color or '').strip()
    if value.startswith('#') and len(value) in (4, 7):
        value = value[1:]
        if len(value) == 3:
            value = ''.join(v * 2 for v in value)
        try:
            return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))
        except ValueError:
            pass
    if widget is not None:
        try:
            return tuple(round(v / 257) for v in widget.winfo_rgb(color))
        except tk.TclError:
            pass
    return {'white': (255, 255, 255), 'black': (0, 0, 0)}.get(value.lower(), (128, 128, 128))


def hexa(values):
    return '#' + ''.join(f'{max(0, min(255, round(v))):02x}' for v in values)


def mix(a, b, t, widget=None):
    """The colour ``t`` of the way from ``a`` to ``b``."""
    A, B = rgb(a, widget), rgb(b, widget)
    return hexa(x + (y - x) * t for x, y in zip(A, B))


def tokens(p):
    """The interface colours for the palette ``p`` (panel, canvas, accent)."""
    P, A = p.get('panel', '#202429'), p.get('accent', '#61c9ee')
    dark = contrast_color(P) == '#ffffff'
    ink = '#ffffff' if dark else '#000000'
    t = dict(dark=dark, panel=P, canvas=p.get('canvas', '#101215'), accent=A, on_accent=contrast_color(A), ink=ink)
    if dark:
        t.update(text=mix(P, ink, .88), muted=mix(P, ink, .56), faint=mix(P, ink, .36),
                 raised=mix(P, ink, .095), hover=mix(P, ink, .14), pressed=mix(P, ink, .19),
                 border=mix(P, ink, .13), field=mix(P, ink, .055), field_border=mix(P, ink, .17),
                 strip=mix(P, '#000000', .16), tip=mix(P, ink, .1), menu=mix(P, ink, .045))
    else:
        # Light panel: raised parts a little darker than the panel, with a fine edge (a lighter
        # fill vanished on a white panel).
        t.update(text=mix(P, ink, .86), muted=mix(P, ink, .55), faint=mix(P, ink, .33),
                 raised=mix(P, ink, .07), hover=mix(P, ink, .11), pressed=mix(P, ink, .16),
                 border=mix(P, ink, .16), field=mix(P, '#ffffff', .85), field_border=mix(P, ink, .25),
                 strip=mix(P, ink, .05), tip=mix(P, '#ffffff', .75), menu=mix(P, '#ffffff', .7))
    # 0.19.2: a fine outline round every block (tool categories, menus, tabs, buttons, fields), plain
    # enough to tell the zones apart, like before 0.19.0 but rounded.
    t['outline'] = t['field_border'] = t['button_edge'] = mix(P, ink, .24 if dark else .26)
    t['accent_soft'] = mix(P, A, .26 if dark else .2)
    t['accent_edge'] = mix(P, A, .62)
    t['accent_hover'] = mix(A, ink, .14) if dark else mix(A, '#000000', .1)
    t['accent_pressed'] = mix(A, P, .22)
    t['accent_line'] = mix(A, ink, .3)   # the outline of the main action
    t['danger'] = '#e5534b' if dark else '#c62828'
    t['warning'] = '#e3a33b' if dark else '#b26a00'
    t['ok'] = '#4fbf6a' if dark else '#2a8a45'
    return t


_TOKENS = {}


def tokens_for(p):
    """``tokens`` kept per palette (called on every redraw of the tabs)."""
    key = (p.get('panel'), p.get('canvas'), p.get('accent'))
    found = _TOKENS.get(key)
    if found is None:
        if len(_TOKENS) > 64:
            _TOKENS.clear()
        found = _TOKENS[key] = tokens(p)
    return found


def theme(widget=None):
    """The colours for ``widget``'s window: from the palette of the Craft window (always the current
    one), else those set by ``apply``, else those of the default palette."""
    try:
        root = widget._root() if widget is not None else tk._default_root
        if root is not None:
            palette = root.__dict__.get('p')
            if isinstance(palette, dict) and palette.get('panel'):
                return tokens_for(palette)
            found = root.__dict__.get('_modern_tokens')
            if found:
                return found
    except (AttributeError, tk.TclError, TypeError):
        pass
    return tokens_for({})


def background(widget, default=None):
    """The background colour behind ``widget`` (its parent's), whatever the parent's kind."""
    parent = getattr(widget, 'master', None)
    while parent is not None:
        try:
            value = str(parent.cget('background'))
            if value:
                return value
        except (tk.TclError, AttributeError):
            pass
        parent = getattr(parent, 'master', None)
    return default or theme(widget)['panel']


# ----------------------------------------------------------------------------------------------
# Font

def setup_family(root):
    """Segoe UI Variable (Windows 11) when installed, else Segoe UI (what Craft used until 0.18)."""
    global FAMILY
    try:
        from tkinter import font as tkfont
        families = set(tkfont.families(root))
    except (tk.TclError, RuntimeError):
        return FAMILY
    for name in ('Segoe UI Variable Text', 'Segoe UI'):
        if name in families:
            FAMILY = name
            break
    return FAMILY


def font(size=10, *style):
    return (FAMILY, size, *style)


def text_width(widget, spec, text):
    try:
        return int(widget.tk.call('font', 'measure', spec, text))
    except tk.TclError:
        return 7 * len(text)


def line_height(widget, spec):
    try:
        return int(widget.tk.call('font', 'metrics', spec, '-linespace'))
    except tk.TclError:
        return 16


# ----------------------------------------------------------------------------------------------
# Rounded pictures

def _cover(px, py, x0, y0, x1, y1, r):
    """Part of the pixel centred on (px, py) inside the rectangle (x0, y0, x1, y1) with corners of
    radius r (signed distance to the edge, half a pixel each side)."""
    hx, hy = (x1 - x0) / 2, (y1 - y0) / 2
    qx = abs(px - (x0 + x1) / 2) - (hx - r)
    qy = abs(py - (y0 + y1) / 2) - (hy - r)
    d = math.hypot(max(qx, 0.), max(qy, 0.)) + min(max(qx, qy), 0.) - r
    return min(1., max(0., .5 - d))


@functools.lru_cache(maxsize=256)
def _band(r, L, ri, band, B, E, F):
    """0.19.5: the top band of a rounded picture, row by row (left pixels, middle pixel, right pixels):
    the same for every width and height (the bottom band is the same, upside down). Computed on the
    smallest picture with that band: the same bytes as on any larger one (checked on 6 000 pictures)."""
    w = h = 2 * band + 1

    def pixel(co, ci):
        return bytes(round(b * (1 - co) + e * (co - ci) + f * ci) for b, e, f in zip(B, E, F))
    rows = []
    for y in range(band):
        py = y + .5
        cells = [pixel(_cover(x + .5, py, 0, 0, w, h, r), _cover(x + .5, py, L, L, w - L, h - L, ri) if L else _cover(x + .5, py, 0, 0, w, h, r)) for x in range(band)]
        co = _cover(w / 2, py, 0, 0, w, h, r)
        ci = _cover(w / 2, py, L, L, w - L, h - L, ri) if L else co
        rows.append((b''.join(cells), pixel(co, ci), b''.join(reversed(cells))))
    return tuple(rows)


def raster(w, h, r, fill, back, edge=None, line=1):
    """A w×h rounded rectangle (radius r) filled with ``fill``, its edge of ``line`` px in ``edge``,
    on ``back`` around the corners: a binary PPM (opaque)."""
    w, h = max(1, int(w)), max(1, int(h))
    r = max(0., min(float(r), w / 2, h / 2))
    B, F = rgb(back), rgb(fill)
    E = rgb(edge) if edge else F
    L = line if edge else 0
    ri = max(0., r - L)

    def pixel(co, ci):
        return bytes(round(b * (1 - co) + e * (co - ci) + f * ci) for b, e, f in zip(B, E, F))

    band = int(math.ceil(r)) + 1 + L

    def row(y):
        py = y + .5
        if w <= 2 * band:
            return b''.join(pixel(_cover(x + .5, py, 0, 0, w, h, r), _cover(x + .5, py, L, L, w - L, h - L, ri) if L else _cover(x + .5, py, 0, 0, w, h, r)) for x in range(w))
        left = b''.join(pixel(_cover(x + .5, py, 0, 0, w, h, r), _cover(x + .5, py, L, L, w - L, h - L, ri) if L else _cover(x + .5, py, 0, 0, w, h, r)) for x in range(band))
        right = b''.join(pixel(_cover(x + .5, py, 0, 0, w, h, r), _cover(x + .5, py, L, L, w - L, h - L, ri) if L else _cover(x + .5, py, 0, 0, w, h, r)) for x in range(w - band, w))
        co = _cover(w / 2, py, 0, 0, w, h, r)
        ci = _cover(w / 2, py, L, L, w - L, h - L, ri) if L else co
        return left + pixel(co, ci) * (w - 2 * band) + right
    # 0.19.2: the rows between the corners are all the same (straight sides): drawn once (a tall
    # outlined category was 27 ms, now about 1 ms).
    middle = row(band) if h > 2 * band else None
    if middle is not None and w > 2 * band:
        # 0.19.5: the corner rows come from _band (a button 2,4 → 0,15 ms when its radius and colours were seen).
        n = w - 2 * band
        head = [a + m * n + b for a, m, b in _band(r, L, ri, band, B, E, F)]
        return b'P6 %d %d 255\n' % (w, h) + b''.join(head) + middle * (h - 2 * band) + b''.join(reversed(head))
    rows = [middle if band <= y < h - band else row(y) for y in range(h)]
    return b'P6 %d %d 255\n' % (w, h) + b''.join(rows)


def _store(widget):
    root = widget._root()
    store = root.__dict__.get('_modern_images')
    if store is None:
        store = root._modern_images = weakref.WeakValueDictionary()
    return store


_RECENT = 96   # 0.19.2: pictures kept after their last widget (a hover back and forth is not drawn again)


def picture(widget, w, h, r, fill, back, edge=None, line=1):
    """The Tk picture of ``raster`` (kept while a widget uses it, and the last ones used)."""
    key = (int(w), int(h), round(float(r), 2), str(fill), str(back), str(edge) if edge else None, line)
    store = _store(widget)
    image = store.get(key)
    if image is None:
        from display_render import photo_image
        image = photo_image(widget, raster(w, h, r, fill, back, edge, line))
        store[key] = image
    root = widget._root()
    recent = root.__dict__.get('_modern_recent')
    if recent is None:
        recent = root._modern_recent = collections.OrderedDict()
    recent[key] = image
    recent.move_to_end(key)
    while len(recent) > _RECENT:
        recent.popitem(last=False)
    return image


def indicator(widget, size, radio, on, t, back, disabled=False):
    """The box of a Checkbutton / the ring of a Radiobutton, with ``gap`` px after it for the text."""
    key = ('indicator', size, radio, on, disabled, str(back), t['accent'], t['field'], t['field_border'])
    store = _store(widget)
    image = store.get(key)
    if image is not None:
        return image
    s = int(size)
    gap = max(5, round(s * .45))
    accent = t['faint'] if disabled else t['accent']
    if on:
        shape = raster(s, s, s / 2 if radio else max(3, s * .22), accent, back)
    else:
        shape = raster(s, s, s / 2 if radio else max(3, s * .22), t['field'], back, t['muted'] if not disabled else t['faint'], 1)
    head, data = shape.split(b'\n', 1)
    rows = [bytearray(data[y * s * 3:(y + 1) * s * 3]) for y in range(s)]
    if on:
        mark = rgb(t['on_accent'] if not disabled else t['panel'])
        F = rgb(accent)
        if radio:
            rr = s * .2
            for y in range(s):
                for x in range(s):
                    c = _cover(x + .5, y + .5, s / 2 - rr, s / 2 - rr, s / 2 + rr, s / 2 + rr, rr)
                    if c:
                        rows[y][3 * x:3 * x + 3] = bytes(round(f + (m - f) * c) for f, m in zip(F, mark))
        else:
            # A tick: two strokes, antialiased by distance to the segments.
            pts = [(s * .27, s * .52), (s * .44, s * .69), (s * .74, s * .33)]
            half = max(.9, s * .075)
            for y in range(s):
                for x in range(s):
                    px, py = x + .5, y + .5
                    d = min(_segment(px, py, *pts[0], *pts[1]), _segment(px, py, *pts[1], *pts[2]))
                    c = min(1., max(0., half + .5 - d))
                    if c and _cover(px, py, 0, 0, s, s, max(3, s * .22)) > .5:
                        old = rows[y][3 * x:3 * x + 3]
                        rows[y][3 * x:3 * x + 3] = bytes(round(o + (m - o) * c) for o, m in zip(old, mark))
    B = rgb(back)
    pad = bytes(B) * gap
    body = b''.join(bytes(row) + pad for row in rows)
    from display_render import photo_image
    image = photo_image(widget, b'P6 %d %d 255\n' % (s + gap, s) + body)
    store[key] = image
    return image


def _segment(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    k = max(0., min(1., ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy or 1)))
    return math.hypot(px - ax - k * dx, py - ay - k * dy)


def rounded_points(x0, y0, x1, y1, r, steps=5):
    """The outline of a rounded rectangle as polygon points (for a canvas, smoothed with the icons)."""
    r = max(0., min(r, (x1 - x0) / 2, (y1 - y0) / 2))
    pts = []
    for cx, cy, start in ((x1 - r, y0 + r, -90), (x1 - r, y1 - r, 0), (x0 + r, y1 - r, 90), (x0 + r, y0 + r, 180)):
        for k in range(steps + 1):
            a = math.radians(start + 90 * k / steps)
            pts += [cx + r * math.cos(a), cy + r * math.sin(a)]
    return pts


# ----------------------------------------------------------------------------------------------
# Icon buttons: the rounded tile behind the icon

TILE = 'modern_tile'


def tile_fill(canvas, state):
    """The colour of the tile ``state`` (None: no tile)."""
    if not state:
        return None
    t = theme(canvas)
    return {'hover': t['hover'], 'pressed': t['pressed'], 'active': t['accent_soft'], 'on': t['accent_soft']}.get(state, t['hover'])


def tile(canvas, state=None):
    """The rounded background of an icon button: None (nothing), 'hover', 'pressed', 'active' (the
    tool in use) or 'on' (a switch that is on). The tile is a canvas polygon smoothed with the icon;
    the icon's soft fills are drawn again on the tile colour (``_modern_redraw``)."""
    try:
        if canvas.__dict__.get('_modern_tile') == state and (state is None or canvas.find_withtag(TILE)):
            return
        t = theme(canvas)
        canvas.delete(TILE)
        canvas._modern_tile = state
        ground = tile_fill(canvas, state)
        if canvas.__dict__.get('_modern_ground') != ground:
            canvas._modern_ground = ground
            redraw = canvas.__dict__.get('_modern_redraw')
            if redraw is not None:
                redraw()
        if state:
            w = int(float(canvas.cget('width')))
            h = int(float(canvas.cget('height')))
            fill = ground
            outline = t['accent_edge'] if state in ('active', 'on') else (t['outline'] if canvas.__dict__.get('_modern_outlined') else '')
            item = canvas.create_polygon(*rounded_points(.5, .5, w - .5, h - .5, max(3, min(w, h) * .22)), fill=fill, outline=outline, width=1, tags=(TILE,))
            canvas.tag_lower(item)
        elif canvas.__dict__.get('_modern_outlined'):
            # 0.19.2: a button standing alone (the bottom bar): its fine outline when nothing is lit.
            w = int(float(canvas.cget('width')))
            h = int(float(canvas.cget('height')))
            item = canvas.create_polygon(*rounded_points(.5, .5, w - .5, h - .5, max(3, min(w, h) * .22)), fill='', outline=t['outline'], width=1, tags=(TILE,))
            canvas.tag_lower(item)
        if canvas.__dict__.get('_smooth_hidden') is not None or canvas.find_withtag('_smooth_display'):
            from display_render import paint
            paint(canvas, icons=True)
    except Exception:
        pass


def outlined(canvas):
    """0.19.2: an icon button standing alone (the bottom bar) keeps a fine outline; its tiles (hover,
    switch on) come inside it."""
    try:
        canvas._modern_outlined = True
        state = canvas.__dict__.get('_modern_tile')
        canvas._modern_tile = '-'   # draw again
        tile(canvas, state)
    except Exception:
        pass
    return canvas


def hover_tile(canvas):
    """Hover / press feedback of an icon button, keeping the state set by the code (tool in use,
    switch on): the hover shows only when nothing else is shown."""
    if canvas.__dict__.get('_modern_hover'):
        return canvas
    canvas._modern_hover = True

    def enter(e):
        if canvas.__dict__.get('_modern_tile') in (None, 'hover', 'pressed'):
            tile(canvas, 'hover')

    def leave(e):
        if canvas.__dict__.get('_modern_tile') in ('hover', 'pressed'):
            tile(canvas, None)

    def press(e):
        if canvas.__dict__.get('_modern_tile') in (None, 'hover'):
            tile(canvas, 'pressed')

    def release(e):
        if canvas.__dict__.get('_modern_tile') == 'pressed':
            tile(canvas, 'hover')
    for sequence, fn in (('<Enter>', enter), ('<Leave>', leave), ('<ButtonPress-1>', press), ('<ButtonRelease-1>', release)):
        canvas.bind(sequence, fn, add='+')
    return canvas


# ----------------------------------------------------------------------------------------------
# Buttons

# What a disabled modern widget refuses (it keeps Tk's state 'normal' so that Tk never greys its picture).
BLOCKED = ('<ButtonPress-1>', '<ButtonRelease-1>', '<space>', '<KeyRelease-space>', '<<Invoke>>',
           '<KeyPress-plus>', '<KeyPress-equal>', '<KeyPress-minus>')
_LOGICAL = ('bg', 'background', 'activebackground', 'activeforeground', 'relief', 'bd', 'borderwidth',
            'highlightthickness', 'highlightbackground', 'highlightcolor', 'overrelief', 'padx', 'pady',
            'width', 'height', 'default', 'selectcolor', 'offrelief', 'indicatoron', 'compound', 'image',
            'selectimage', 'disabledforeground', 'anchor', 'justify', 'wraplength', 'fg', 'foreground')
PRIMARY = ('Valider', 'OK', 'Appliquer', 'Imprimer', 'Exporter', 'Enregistrer', 'Créer', 'Générer', 'Activer', 'Oui',
           'Continuer', 'Installer', 'Mettre à jour', 'Insérer', 'Placer', 'Récupérer', 'Redémarrer', 'Choisir')
SECONDARY = ('Annuler', 'Fermer', 'Non', 'Retour', 'Ignorer', 'Plus tard', 'Supprimer')


def kind_of(text):
    """'primary' for the main action of a window (Valider, Appliquer, Imprimer, Exporter…)."""
    words = (text or '').strip()
    if not words or words in ('+', '▾', '×', '…'):
        return 'secondary'
    if any(words.startswith(w) for w in SECONDARY):
        return 'secondary'
    return 'primary' if any(words.startswith(w) for w in PRIMARY) else 'secondary'


class _Logical:
    """Visual options kept for the code (cget gives back what was set) and drawn by Craft."""

    def _split(self, kw):
        for key in list(kw):
            if key in _LOGICAL:
                self._logical[key] = kw.pop(key)
        if 'state' in kw:
            self._state = str(kw.pop('state'))
        if 'command' in kw:
            self._command = kw.pop('command')
        return kw

    def configure(self, cnf=None, **kw):
        if cnf is None and not kw:
            return super().configure()
        if isinstance(cnf, str):
            if cnf in self._logical or cnf == 'state':
                return (cnf, cnf, cnf.capitalize(), '', self.cget(cnf))
            return super().configure(cnf)
        kw = self._split(dict(cnf or {}, **kw))
        look = {k: kw.pop(k) for k in ('kind', 'radius') if k in kw}
        self._look.update(look)
        result = super().configure(**kw) if kw else None
        self._render()
        return result

    config = configure

    def cget(self, key):
        key = {'background': 'bg', 'borderwidth': 'bd'}.get(key, key)
        if key == 'state':
            return self._state
        if key == 'command':
            return self._command
        for k in (key, {'bg': 'background', 'bd': 'borderwidth'}.get(key, key)):
            if k in self._logical:
                return self._logical[k]
        if key in ('bg', 'activebackground'):
            return self.__dict__.get('_fill') or background(self)
        if key in ('relief', 'overrelief'):
            return 'flat'
        if key in ('bd', 'highlightthickness'):
            return 0
        return super().cget(key)

    def __getitem__(self, key):
        return self.cget(key)

    def __setitem__(self, key, value):
        self.configure({key: value})

    def keys(self):
        return list(super().keys())

    def _blocked(self, e=None):
        return 'break' if self._state == 'disabled' else None

    def _call(self):
        if self._state == 'disabled':
            return ''
        command = self._command
        if command is None or command == '':
            return ''
        if callable(command):
            return command()
        return self.tk.call(command)


class Button(_Logical, tk.Button):
    """0.19.0: a rounded, flat button, same Tk widget (the code and the tests invoke it, read its
    text and state). Kinds: 'primary' (the main action, accent colour), 'secondary', 'ghost'
    (shown on hover), 'swatch' (a colour chip: its ``bg``), 'danger'. A button stretched by its
    window (pack fill) is drawn at its real width."""

    def __init__(self, master=None, cnf=None, **kw):
        kw = dict(cnf or {}, **kw)
        self._logical = {}
        self._look = {'kind': kw.pop('kind', None), 'radius': kw.pop('radius', None)}
        self._state = 'normal'
        self._command = None
        self._mouse = None
        self._focus = False
        self._size = None
        self._var = None
        self._traces = []
        kw = self._split(kw)
        kw['font'] = _family(kw.get('font')) or font(10)
        self._takefocus = kw.pop('takefocus', 1)
        super().__init__(master, relief='flat', bd=0, highlightthickness=0, padx=0, pady=0, compound='center',
                         command=self._call, takefocus=self._takefocus, **kw)
        # Tk under X11 keeps 2 px around a picture button (for its pressed shift); under Windows we
        # ask them ourselves, so the 1 px shift of a press never cuts the picture's edge.
        self._spare = 2 if self.tk.call('tk', 'windowingsystem') == 'win32' else 0
        if 'textvariable' in kw:
            self._watch(kw['textvariable'])
        for sequence, fn in (('<Enter>', lambda e: self._hover('hover')), ('<Leave>', lambda e: self._hover(None)),
                             ('<ButtonPress-1>', lambda e: self._hover('pressed')), ('<ButtonRelease-1>', self._released),
                             ('<FocusIn>', lambda e: self._focused(True)), ('<FocusOut>', lambda e: self._focused(False)),
                             ('<Configure>', self._resized)):
            self.bind(sequence, fn, add='+')
        for sequence in BLOCKED:
            self.bind(sequence, self._blocked, add='+')
        self._modern_hover = True
        self._render()

    def configure(self, cnf=None, **kw):
        merged = dict(cnf) if isinstance(cnf, dict) else {}
        merged.update(kw)
        if 'textvariable' in merged:
            self._watch(merged['textvariable'])
        if 'takefocus' in merged:
            self._takefocus = merged['takefocus']
        return super().configure(cnf, **kw)

    def destroy(self):
        for name, command in self._traces:
            try:
                self.tk.call('trace', 'remove', 'variable', name, 'write', command)
            except tk.TclError:
                pass
        self._traces = []
        super().destroy()

    config = configure

    def invoke(self):
        return self._call()

    def _watch(self, var):
        try:
            name = str(var)
            if not name:
                return
            self._var = name
            command = self.register(lambda *a: self._render())
            self.tk.call('trace', 'add', 'variable', name, 'write', command)
            self._traces.append((name, command))   # removed with the button (else a later set() fails)
        except tk.TclError:
            pass

    def _text(self):
        if self._var:
            try:
                return str(self.tk.globalgetvar(self._var))
            except tk.TclError:
                pass
        return str(super().cget('text'))

    def _hover(self, mouse):
        self._mouse = mouse
        self._render()

    def _released(self, e):
        inside = 0 <= e.x < self.winfo_width() and 0 <= e.y < self.winfo_height()
        self._hover('hover' if inside else None)

    def _focused(self, on):
        self._focus = on
        self._render()

    def _resized(self, e):
        if (e.width, e.height) != self.__dict__.get('_seen'):
            self._seen = (e.width, e.height)
            self._render()

    def _colours(self):
        t = theme(self)
        back = background(self)
        kind = self._look.get('kind') or ('swatch' if not self._text().strip() and self._logical.get('bg', self._logical.get('background')) else kind_of(self._text()))
        mouse = None if self._state == 'disabled' else self._mouse
        signal = _signal(self._logical.get('fg', self._logical.get('foreground')), t, self)
        if kind == 'primary':
            fill = {'hover': t['accent_hover'], 'pressed': t['accent_pressed']}.get(mouse, t['accent'])
            ink, edge = t['on_accent'], t['accent_line']
        elif kind == 'danger':
            fill = mix(t['danger'], t['ink'], .12) if mouse == 'hover' else t['danger']
            ink, edge = '#ffffff', mix(t['danger'], t['ink'], .3)
        elif kind == 'swatch':
            fill = self._logical.get('bg', self._logical.get('background', t['raised']))
            ink, edge = contrast_color(rgb_hex(fill, self)), (t['text'] if mouse else t['outline'])
        elif kind == 'ghost':
            fill = {'hover': t['hover'], 'pressed': t['pressed']}.get(mouse, back)
            ink, edge = t['text'], t['outline']   # 0.19.2: outlined like the other buttons
        elif kind == 'flat':
            fill, ink, edge = back, t['text'], None
        else:
            fill = {'hover': t['hover'], 'pressed': t['pressed']}.get(mouse, t['raised'])
            ink, edge = t['text'], None
            edge = t['button_edge']
            custom = self._logical.get('bg', self._logical.get('background'))
            if custom and rgb_hex(custom, self) not in (rgb_hex(back, self), rgb_hex(t['panel'])):
                # A colour set by the code to show a choice (the mèche, the Piqûre, the Symétrie in
                # use): a soft fill edged with that colour, never the look of the main action.
                fill = mix(back, rgb_hex(custom, self), .4 if mouse == 'hover' else .28, self)
                ink, edge = t['text'], rgb_hex(custom, self)
        if signal and kind not in ('primary', 'danger', 'swatch'):
            ink = signal
        if self._state == 'disabled':
            if kind in ('primary', 'danger', 'secondary'):
                fill = t['raised'] if kind != 'secondary' else mix(t['raised'], back, .5)
            ink = t['faint']
        if self._focus and self._state != 'disabled' and kind not in ('ghost', 'tab'):
            edge = t['accent'] if kind != 'primary' else t['text']
        return fill, edge, ink, back

    def _render(self):
        try:
            if not self.winfo_exists():
                return
            spec = super().cget('font')
            text = self._text()
            lh = line_height(self, spec)
            padx = _pixels(self._logical.get('padx'), 12)
            pady = _pixels(self._logical.get('pady'), 4)
            natural_w = text_width(self, spec, text) + 2 * padx if text else 0
            chars = self._logical.get('width')
            if chars not in (None, '', 0, '0'):
                try:
                    natural_w = max(natural_w, int(float(chars)) * text_width(self, spec, '0') + (2 * padx if text else 8))
                except (TypeError, ValueError):
                    pass
            natural_w = max(natural_w, lh + 2 * pady)
            natural_h = lh + 2 * pady
            lines = self._logical.get('height')
            if lines not in (None, '', 0, '0'):
                try:
                    natural_h = max(natural_h, int(float(lines)) * lh + 2 * pady)
                except (TypeError, ValueError):
                    pass
            w, h = natural_w, natural_h
            # The size asked of the window stays the natural one (width / height below); a button
            # stretched by its window (pack fill, grid sticky) is drawn at its real size, less the
            # 2 px Tk keeps around a picture button.
            W, H = self.winfo_width(), self.winfo_height()
            extra_w = max(0, self.winfo_reqwidth() - natural_w) if self._size else 2
            extra_h = max(0, self.winfo_reqheight() - natural_h) if self._size else 2
            if W > 1 and W - extra_w > natural_w:
                w = W - extra_w
            if H > 1 and H - extra_h > natural_h:
                h = H - extra_h
            fill, edge, ink, back = self._colours()
            r = self._look.get('radius')
            r = min(GRIP if r is None else r, h / 2)
            image = picture(self, w, h, r, fill, back, edge, 1)
            tk.Misc.configure(self, image=image, bg=back, activebackground=back, fg=ink, activeforeground=ink,
                              disabledforeground=ink, width=int(natural_w) + self._spare, height=int(natural_h) + self._spare,
                              takefocus=0 if self._state == 'disabled' else self._takefocus)
            self._image = image
            self._fill = fill
            self._size = (int(w), int(h))
        except Exception:
            pass   # never stops a window: the button keeps its last look


def rgb_hex(color, widget=None):
    return hexa(rgb(color, widget))


def _signal(color, t, widget):
    """A text colour set by the code to say something (the accent of a switch that is on, an
    alert): kept; the ordinary ink of the palette is replaced by the modern text colour."""
    if not color:
        return None
    value = rgb_hex(color, widget)
    return None if value in ('#ffffff', '#000000', rgb_hex(t['text']), rgb_hex(t['ink'])) else value


def _family(spec):
    """('Segoe UI', 10, …) given by the code: the same in the modern family."""
    if isinstance(spec, tuple) and spec and spec[0] == 'Segoe UI':
        return (FAMILY,) + tuple(spec[1:])
    return spec


def _pixels(value, default):
    try:
        return int(float(value)) if value not in (None, '') else default
    except (TypeError, ValueError):
        return default


class _Choice(_Logical):
    """Check box and round choice drawn by Craft (same Tk widgets)."""
    radio = False

    def __init__(self, master=None, cnf=None, **kw):
        kw = dict(cnf or {}, **kw)
        self._logical = {}
        self._look = {}
        self._state = 'normal'
        self._command = None
        kw = self._split(kw)
        kw['font'] = _family(kw.get('font')) or font(10)
        t = theme(master)
        back = _parent_bg(master, t)
        self._takefocus = kw.pop('takefocus', '')
        super().__init__(master, indicatoron=False, relief='flat', offrelief='flat', overrelief='flat', bd=0,
                         highlightthickness=0, compound='left', anchor='w', bg=back, activebackground=back,
                         selectcolor=back, fg=t['text'], activeforeground=t['text'], disabledforeground=t['faint'],
                         command=self._call, padx=2, pady=2, cursor='arrow', takefocus=self._takefocus, **kw)
        for sequence in BLOCKED:
            self.bind(sequence, self._blocked, add='+')
        self._render()

    def invoke(self):
        if self._state == 'disabled':
            return ''
        return super().invoke()

    def _render(self):
        try:
            t = theme(self)
            back = _parent_bg(self.master, t)
            size = max(12, round(line_height(self, super().cget('font')) * .78))
            off = indicator(self, size, self.radio, False, t, back, self._state == 'disabled')
            on = indicator(self, size, self.radio, True, t, back, self._state == 'disabled')
            ink = t['faint'] if self._state == 'disabled' else (_signal(self._logical.get('fg', self._logical.get('foreground')), t, self) or t['text'])
            tk.Misc.configure(self, image=off, selectimage=on, bg=back, activebackground=back, selectcolor=back,
                              fg=ink, activeforeground=ink, takefocus=0 if self._state == 'disabled' else self._takefocus)
            self._images = (off, on)
        except Exception:
            pass


def _parent_bg(master, t):
    try:
        return str(master.cget('background')) or t['panel']   # str: a Tcl object under some Tk versions
    except (tk.TclError, AttributeError):
        return t['panel']


class Checkbutton(_Choice, tk.Checkbutton):
    radio = False


class Radiobutton(_Choice, tk.Radiobutton):
    radio = True


# ----------------------------------------------------------------------------------------------
# Labels drawn rounded (menu bar entries, tabs, pills)

class Pill(tk.Label):
    """A label on a rounded background (menu bar, bottom tabs, small chips): no button behaviour."""

    def __init__(self, master, text='', fill=None, ink=None, hover=None, radius=None, padx=10, pady=3, size=10, weight=None, edge=None, **kw):
        t = theme(master)
        self._spec = font(size, weight) if weight else font(size)
        self._fill, self._ink, self._hover_fill, self._radius, self._edge = fill, ink, hover, radius, edge
        self._padx, self._pady, self._mouse = padx, pady, False
        super().__init__(master, text=text, compound='center', bd=0, padx=0, pady=0, font=self._spec,
                         bg=_parent_bg(master, t), cursor='arrow', **kw)
        self.bind('<Enter>', lambda e: self._set_mouse(True), add='+')
        self.bind('<Leave>', lambda e: self._set_mouse(False), add='+')
        self.render()

    def _set_mouse(self, inside):
        self._mouse = inside
        self.render()

    def look(self, fill=None, ink=None, hover=None):
        self._fill, self._ink, self._hover_fill = fill, ink, hover
        self.render()

    def render(self):
        try:
            t = theme(self)
            back = _parent_bg(self.master, t)
            text = str(self.cget('text'))
            lh = line_height(self, self._spec)
            w = max(text_width(self, self._spec, text) + 2 * self._padx, lh + 2 * self._pady)
            h = lh + 2 * self._pady
            fill = (self._hover_fill or t['hover']) if self._mouse and self._hover_fill != '' else (self._fill or back)
            r = min(GRIP if self._radius is None else self._radius, h / 2)
            image = picture(self, w, h, r, fill, back, self._edge)   # 0.19.2: the outline even on the panel
            tk.Label.configure(self, image=image, bg=back, fg=self._ink or t['text'])
            self._image = image
        except Exception:
            pass


class RoundFrame(tk.Frame):
    """A frame on a rounded background (a field holding a label and an entry, a tab): its children
    take ``fill`` as background; the rounded picture follows the frame's size."""

    def __init__(self, master, fill=None, edge=None, radius=None, back=None, **kw):
        t = theme(master)
        self._fill, self._edge, self._radius, self._around = fill or t['field'], edge, radius, back
        super().__init__(master, bg=self._fill, bd=0, highlightthickness=0, **kw)
        self._back = tk.Label(self, bd=0, bg=self._fill, padx=0, pady=0)
        self._back.place(x=0, y=0, relwidth=1, relheight=1)
        self._back.lower()
        self.bind('<Configure>', lambda e: self.draw(), add='+')

    def look(self, fill=None, edge=False):
        """New colours (the outline kept unless given); the children keep theirs (the caller sets them)."""
        if fill:
            self._fill = fill
        if edge is not False:
            self._edge = edge
        try:
            tk.Frame.configure(self, bg=self._fill)
            self._back.configure(bg=self._fill)
        except tk.TclError:
            return
        self.draw()

    def draw(self):
        try:
            w, h = self.winfo_width(), self.winfo_height()
            if w < 3 or h < 3:
                return
            t = theme(self)
            back = self._around or _parent_bg(self.master, t)   # 0.19.2: or the colour under a floating frame
            r = min(GRIP if self._radius is None else self._radius, h / 2)
            image = picture(self, w, h, r, self._fill, back, self._edge, 1)
            self._back.configure(image=image)
            self._image = image
        except tk.TclError:
            pass


# Makers: the modern widget, or the plain Tk one while tests use stand-ins.

def make_button(parent, **kw):
    if not real():
        return tk.Button(parent, **{k: v for k, v in kw.items() if k not in ('kind', 'radius')})
    return Button(parent, **kw)


def make_check(parent, **kw):
    return Checkbutton(parent, **kw) if real() else tk.Checkbutton(parent, **kw)


def make_radio(parent, **kw):
    return Radiobutton(parent, **kw) if real() else tk.Radiobutton(parent, **kw)


def make_pill(parent, **kw):
    if not real():
        return tk.Label(parent, text=kw.get('text', ''))
    return Pill(parent, **kw)


def make_round(parent, **kw):
    if not real():
        return tk.Frame(parent)
    return RoundFrame(parent, **kw)


def make_strip(parent, model):
    if not real():
        return tk.Frame(parent)
    return MenuStrip(parent, model)


# ----------------------------------------------------------------------------------------------
# Menu bar

class MenuStrip(tk.Frame):
    """0.19.0: the menu bar drawn by Craft, in the panel colour (the Windows menu bar stayed white).
    It shows the cascades of ``model`` (the same tk.Menu as before: the layers keep adding to it)."""

    def __init__(self, master, model):
        t = theme(master)
        super().__init__(master, bg=t['panel'])
        self.model = model
        self.entries = None
        self.labels = []
        self.opened = None
        self.bind('<Enter>', lambda e: self.sync(), add='+')
        # F10 opens the first menu, as the Windows menu bar did.
        top = master.winfo_toplevel()
        if not top.__dict__.get('_modern_f10'):
            top._modern_f10 = True
            top.bind('<F10>', lambda e: self.keyboard(), add='+')
        top._modern_strip = self
        self.sync()

    def keyboard(self):
        strip = self.winfo_toplevel().__dict__.get('_modern_strip', self)
        try:
            if strip.winfo_exists():
                strip.sync()
                if strip.labels:
                    strip.after(1, lambda: strip.open(strip.labels[0].menu_path, strip.labels[0]))
        except tk.TclError:
            pass
        return 'break'

    def cascades(self):
        try:
            end = self.model.index('end')
        except tk.TclError:
            return []
        if end is None:
            return []
        return [(self.model.entrycget(i, 'label'), str(self.model.entrycget(i, 'menu'))) for i in range(end + 1) if self.model.type(i) == 'cascade']

    def sync(self):
        entries = self.cascades()
        if entries == self.entries:
            return
        self.entries = entries
        for w in self.labels:
            w.destroy()
        self.labels = []
        t = theme(self)
        for label, menu in entries:
            w = Pill(self, text=label, ink=t['text'], padx=10, pady=2, edge=t['outline'])   # 0.19.2: outlined
            w.pack(side='left', padx=(4 if not self.labels else 0, 3), pady=(3, 3))
            w.menu_path = menu
            w.bind('<ButtonPress-1>', lambda e, m=menu, w=w: self.open(m, w))
            self.labels.append(w)

    def open(self, path, label):
        if self.opened is not None:
            return
        try:
            menu = self.nametowidget(path)
        except KeyError:
            return
        t = theme(self)
        label.look(fill=t['hover'], ink=t['text'])
        self.opened = label
        try:
            menu.tk_popup(label.winfo_rootx(), label.winfo_rooty() + label.winfo_height())
        finally:
            self.opened = None
            try:
                menu.grab_release()
            except tk.TclError:
                pass
            try:
                label.look(fill=None, ink=t['text'])
            except tk.TclError:
                pass
        # Under Windows the list is closed by the click on another menu of the bar: that one opens
        # at once, as on a menu bar (the click on the same menu only closes it).
        if _primary_button_down():
            try:
                x, y = self.winfo_pointerxy()
                under = self.winfo_containing(x, y)
            except (tk.TclError, KeyError):
                under = None
            if under in self.labels and under is not label:
                self.after(1, lambda: self.open(under.menu_path, under))


def _primary_button_down():
    """Windows: the main mouse button is held down now (False elsewhere or if unknown)."""
    if os.name != 'nt':
        return False
    try:
        import ctypes
        user32 = ctypes.WinDLL('user32')
        key = 0x02 if user32.GetSystemMetrics(23) else 0x01     # SM_SWAPBUTTON: left-handed mouse
        return bool(user32.GetAsyncKeyState(key) & 0x8000)
    except Exception:
        return False


# ----------------------------------------------------------------------------------------------
# Help bubbles

def tooltip(master, text, x, y, above_of=None):
    """A help bubble at (x, y) on the screen (or above ``above_of`` when it would leave the screen)."""
    try:
        return _tooltip(master, text, x, y, above_of)
    except Exception:
        return None


def _tooltip(master, text, x, y, above_of=None):
    t = theme(master)
    w = tk.Toplevel(master)
    w.withdraw()
    w.overrideredirect(True)
    w.configure(bg=t['field_border'], bd=0)
    tk.Label(w, text=text, bg=t['tip'], fg=t['text'], padx=9, pady=4, font=font(9), justify='left').pack(padx=1, pady=1)
    w.update_idletasks()
    x = max(5, min(int(x), w.winfo_screenwidth() - w.winfo_reqwidth() - 8))
    if above_of is not None:
        y = above_of - w.winfo_reqheight() - 7
    w.geometry(f'+{x}+{max(5, int(y))}')
    w.deiconify()
    try:
        w.lift()
    except tk.TclError:
        pass
    return w


# ----------------------------------------------------------------------------------------------
# Fields, lists, texts: flat with a fine edge, the accent when they have the keyboard

def field(t=None, widget=None):
    t = t or theme(widget)
    return dict(bg=t['field'], fg=t['text'], insertbackground=t['text'], relief='flat', bd=0, highlightthickness=1,
                highlightbackground=t['field_border'], highlightcolor=t['accent'], selectbackground=t['accent_soft'],
                selectforeground=t['text'], disabledbackground=t['panel'], disabledforeground=t['faint'],
                readonlybackground=t['field'], font=font(10))


def listing(t=None, widget=None):
    t = t or theme(widget)
    return dict(bg=t['field'], fg=t['text'], relief='flat', bd=0, highlightthickness=1, highlightbackground=t['field_border'],
                highlightcolor=t['accent'], selectbackground=t['accent_soft'], selectforeground=t['text'],
                activestyle='none', font=font(10), selectborderwidth=0)


def text_box(t=None, widget=None):
    t = t or theme(widget)
    return dict(bg=t['field'], fg=t['text'], insertbackground=t['text'], relief='flat', bd=0, highlightthickness=1,
                highlightbackground=t['field_border'], highlightcolor=t['accent'], selectbackground=t['accent_soft'],
                selectforeground=t['text'], font=font(10))


def spinbox(t=None, widget=None):
    options = field(t, widget)
    t = t or theme(widget)
    options.update(buttonbackground=t['raised'], buttoncursor='arrow', relief='flat')
    options.pop('readonlybackground', None)
    return options


def menu_options(t=None, widget=None):
    t = t or theme(widget)
    return dict(bg=t['menu'], fg=t['text'], activebackground=t['accent_soft'], activeforeground=t['text'],
                disabledforeground=t['faint'], selectcolor=t['accent'], relief='flat', bd=1, activeborderwidth=0,
                font=font(10))


def field_back(canvas, fill=None, edge=None):
    """A canvas used as a field (line type, colour): its rounded background, under its drawing."""
    try:
        t = theme(canvas)
        w, h = int(float(canvas.cget('width'))), int(float(canvas.cget('height')))
        image = picture(canvas, w, h, min(GRIP, h / 2), fill or t['field'], _parent_bg(canvas.master, t), edge or t['field_border'])
        canvas.delete('modern_field')
        item = canvas.create_image(0, 0, image=image, anchor='nw', tags=('modern_field',))
        canvas.tag_lower(item)
        canvas._modern_field = image
    except Exception:
        pass


def modern_font(widget, value):
    """A font given as Segoe UI in the modern family (Segoe UI Variable under Windows 11); others kept."""
    if FAMILY == 'Segoe UI' or not value:
        return None
    try:
        parts = widget.tk.splitlist(value) if isinstance(value, str) else tuple(value)
    except (tk.TclError, TypeError):
        return None
    if parts and str(parts[0]) == 'Segoe UI':
        return (FAMILY,) + tuple(parts[1:])
    return None


_OPTION_NAMES = {}   # 0.19.8: (Python class, Tk class) → the names of its options


def option_names(w, cls=None):
    """The option names of a widget, asked once per kind of widget (``keys()`` lists every option with its
    values: 600 widgets restyled asked Tk 600 times for the same lists)."""
    key = (type(w), cls or w.winfo_class())
    names = _OPTION_NAMES.get(key)
    if names is None:
        names = _OPTION_NAMES[key] = frozenset(w.keys())
    return names


def restyle(widget):
    """Fields, lists and texts of a window already built: the modern colours (their size, text and
    behaviour unchanged), the modern font family. Buttons and choices are made modern where they are
    created; a widget marked ``_modern_keep`` keeps its look."""
    t = theme(widget)
    stack = [widget]
    while stack:
        w = stack.pop()
        try:
            if getattr(w, '_modern_keep', False):
                continue
            cls = w.winfo_class()
            names = option_names(w, cls)
            if 'font' in names and not isinstance(w, (Button, _Choice, Pill)):
                swapped = modern_font(w, w.cget('font'))
                if swapped:
                    w.configure(font=swapped)
            if cls == 'Entry':
                opts = field(t)
                opts.pop('font', None)
                w.configure(**{k: v for k, v in opts.items() if k in names})
            elif cls == 'Spinbox':
                opts = spinbox(t)
                opts.pop('font', None)
                w.configure(**{k: v for k, v in opts.items() if k in names})
            elif cls == 'Listbox':
                opts = listing(t)
                opts.pop('font', None)
                w.configure(**{k: v for k, v in opts.items() if k in names})
            elif cls == 'Text' and str(w.cget('state')) != 'disabled':
                opts = text_box(t)
                opts.pop('font', None)
                w.configure(**{k: v for k, v in opts.items() if k in names})
            elif cls == 'Label' and not isinstance(w, Pill):
                # The plain ink of the panel (pure white or black) softened like the other texts.
                if rgb_hex(w.cget('foreground'), w) in ('#ffffff', '#000000') and rgb_hex(w.cget('background'), w) == rgb_hex(t['panel']):
                    w.configure(foreground=t['text'])
            stack.extend(w.winfo_children())
        except (tk.TclError, AttributeError):
            pass


# ----------------------------------------------------------------------------------------------
# ttk widgets (lists to choose from, number boxes, sliders, scroll bars) and Tk defaults

def style_ttk(root, t):
    from tkinter import ttk
    style = ttk.Style(root)
    try:
        if style.theme_use() != 'clam':
            style.theme_use('clam')
    except tk.TclError:
        return
    f = font(10)
    style.configure('.', background=t['panel'], foreground=t['text'], fieldbackground=t['field'], bordercolor=t['field_border'],
                    lightcolor=t['field'], darkcolor=t['field'], troughcolor=t['panel'], selectbackground=t['accent_soft'],
                    selectforeground=t['text'], insertcolor=t['text'], arrowcolor=t['muted'], focuscolor=t['accent'], font=f)
    style.map('.', foreground=[('disabled', t['faint'])], fieldbackground=[('disabled', t['panel'])])
    for name in ('TCombobox', 'TSpinbox', 'TEntry'):
        style.configure(name, padding=(6, 3), arrowsize=12, bordercolor=t['field_border'], lightcolor=t['field'],
                        darkcolor=t['field'], background=t['raised'], fieldbackground=t['field'], foreground=t['text'])
        style.map(name, bordercolor=[('focus', t['accent']), ('hover', t['muted'])], lightcolor=[('focus', t['field'])],
                  background=[('active', t['hover']), ('pressed', t['pressed'])], arrowcolor=[('hover', t['text']), ('disabled', t['faint'])],
                  fieldbackground=[('readonly', t['field']), ('disabled', t['panel'])], foreground=[('disabled', t['faint'])],
                  selectbackground=[('readonly', t['field'])], selectforeground=[('readonly', t['text'])])
    for orient in ('Vertical', 'Horizontal'):
        style.configure(f'{orient}.TScrollbar', background=t['raised'], troughcolor=t['panel'], bordercolor=t['panel'],
                        lightcolor=t['raised'], darkcolor=t['raised'], arrowcolor=t['muted'], gripcount=0, arrowsize=11, relief='flat')
        style.map(f'{orient}.TScrollbar', background=[('active', t['hover']), ('pressed', t['pressed'])],
                  lightcolor=[('active', t['hover'])], darkcolor=[('active', t['hover'])])
        style.configure(f'{orient}.TScale', background=t['raised'], troughcolor=t['field'], bordercolor=t['field_border'],
                        lightcolor=t['raised'], darkcolor=t['raised'], sliderlength=16, gripcount=0)
        style.map(f'{orient}.TScale', background=[('active', t['accent']), ('pressed', t['accent'])])
    for name in ('TCheckbutton', 'TRadiobutton'):
        style.configure(name, background=t['panel'], foreground=t['text'], indicatorbackground=t['field'],
                        indicatorforeground=t['on_accent'], indicatormargin=(0, 0, 6, 0), padding=2)
        style.map(name, indicatorbackground=[('selected', t['accent']), ('pressed', t['hover'])], background=[('active', t['panel'])])
    style.configure('TButton', background=t['raised'], foreground=t['text'], bordercolor=t['outline'], lightcolor=t['raised'],
                    darkcolor=t['raised'], padding=(12, 4), relief='flat')
    style.map('TButton', background=[('active', t['hover']), ('pressed', t['pressed'])], foreground=[('disabled', t['faint'])])
    style.configure('Treeview', background=t['field'], fieldbackground=t['field'], foreground=t['text'], bordercolor=t['field_border'],
                    lightcolor=t['field'], darkcolor=t['field'], rowheight=max(20, line_height(root, f) + 6))
    style.map('Treeview', background=[('selected', t['accent_soft'])], foreground=[('selected', t['text'])])
    style.configure('Treeview.Heading', background=t['raised'], foreground=t['muted'], bordercolor=t['border'],
                    lightcolor=t['raised'], darkcolor=t['raised'], relief='flat', font=font(9))
    style.map('Treeview.Heading', background=[('active', t['hover'])])
    style.configure('TNotebook', background=t['panel'], bordercolor=t['outline'])
    style.configure('TNotebook.Tab', background=t['panel'], foreground=t['muted'], bordercolor=t['outline'], padding=(12, 5))
    style.map('TNotebook.Tab', background=[('selected', t['raised'])], foreground=[('selected', t['text'])])
    style.configure('TFrame', background=t['panel'])
    style.configure('TLabel', background=t['panel'], foreground=t['text'])
    style.configure('TSeparator', background=t['border'])
    # The list under a Combobox is a Tk Listbox: its colours come from the option database.
    root.option_add('*TCombobox*Listbox.background', t['menu'], 60)
    root.option_add('*TCombobox*Listbox.foreground', t['text'], 60)
    root.option_add('*TCombobox*Listbox.selectBackground', t['accent_soft'], 60)
    root.option_add('*TCombobox*Listbox.selectForeground', t['text'], 60)
    root.option_add('*TCombobox*Listbox.font', f, 60)
    root.option_add('*TCombobox*Listbox.relief', 'flat', 60)
    root.option_add('*TCombobox*Listbox.borderWidth', 0, 60)


def option_defaults(root, t):
    """Defaults for the Tk widgets created without colours (priority below what the code sets)."""
    f = font(10)
    pairs = {
        '*Font': f, '*Toplevel.background': t['panel'], '*Frame.background': t['panel'], '*Label.background': t['panel'],
        '*Label.foreground': t['text'], '*Message.background': t['panel'], '*Message.foreground': t['text'],
        '*Entry.background': t['field'], '*Entry.foreground': t['text'], '*Entry.insertBackground': t['text'],
        '*Entry.relief': 'flat', '*Entry.borderWidth': 0, '*Entry.highlightThickness': 1,
        '*Entry.highlightBackground': t['field_border'], '*Entry.highlightColor': t['accent'],
        '*Entry.selectBackground': t['accent_soft'], '*Entry.selectForeground': t['text'],
        '*Spinbox.background': t['field'], '*Spinbox.foreground': t['text'], '*Spinbox.buttonBackground': t['raised'],
        '*Spinbox.relief': 'flat', '*Spinbox.highlightThickness': 1, '*Spinbox.highlightBackground': t['field_border'],
        '*Spinbox.highlightColor': t['accent'], '*Spinbox.insertBackground': t['text'],
        '*Listbox.background': t['field'], '*Listbox.foreground': t['text'], '*Listbox.relief': 'flat', '*Listbox.borderWidth': 0,
        '*Listbox.highlightThickness': 1, '*Listbox.highlightBackground': t['field_border'], '*Listbox.highlightColor': t['accent'],
        '*Listbox.selectBackground': t['accent_soft'], '*Listbox.selectForeground': t['text'], '*Listbox.activeStyle': 'none',
        '*Text.background': t['field'], '*Text.foreground': t['text'], '*Text.insertBackground': t['text'], '*Text.relief': 'flat',
        '*Text.highlightThickness': 1, '*Text.highlightBackground': t['field_border'], '*Text.highlightColor': t['accent'],
        '*Text.selectBackground': t['accent_soft'], '*Text.selectForeground': t['text'],
        '*Button.background': t['raised'], '*Button.foreground': t['text'], '*Button.activeBackground': t['hover'],
        '*Button.activeForeground': t['text'], '*Button.relief': 'flat', '*Button.borderWidth': 0, '*Button.highlightThickness': 0,
        '*Checkbutton.background': t['panel'], '*Checkbutton.foreground': t['text'], '*Checkbutton.activeBackground': t['panel'],
        '*Checkbutton.activeForeground': t['text'], '*Checkbutton.selectColor': t['field'], '*Checkbutton.highlightThickness': 0,
        '*Radiobutton.background': t['panel'], '*Radiobutton.foreground': t['text'], '*Radiobutton.activeBackground': t['panel'],
        '*Radiobutton.activeForeground': t['text'], '*Radiobutton.selectColor': t['field'], '*Radiobutton.highlightThickness': 0,
        '*Scrollbar.background': t['raised'], '*Scrollbar.troughColor': t['panel'], '*Scrollbar.activeBackground': t['hover'],
        '*Scrollbar.relief': 'flat', '*Scrollbar.borderWidth': 0, '*Scrollbar.highlightThickness': 0, '*Scrollbar.elementBorderWidth': 0,
        '*Menu.background': t['menu'], '*Menu.foreground': t['text'], '*Menu.activeBackground': t['accent_soft'],
        '*Menu.activeForeground': t['text'], '*Menu.selectColor': t['accent'], '*Menu.relief': 'flat', '*Menu.activeBorderWidth': 0,
        '*Menu.disabledForeground': t['faint'], '*Scale.background': t['panel'], '*Scale.troughColor': t['field'],
        '*Scale.highlightThickness': 0,
    }
    for key, value in pairs.items():
        root.option_add(key, value, 'widgetDefault')


# ----------------------------------------------------------------------------------------------
# Windows: the title bar in the panel colour, small rounded corners for floating windows

def _colorref(color):
    r, g, b = rgb(color)
    return r | g << 8 | b << 16


_LIBRARIES = []


def _windows():
    """Private user32 / dwmapi handles with their signatures (the window_caption module has its own)."""
    if not _LIBRARIES:
        import ctypes
        from ctypes import wintypes
        user32, dwm = ctypes.WinDLL('user32'), ctypes.WinDLL('dwmapi')
        user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
        user32.GetAncestor.restype = wintypes.HWND
        user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
        user32.SetWindowPos.restype = wintypes.BOOL
        dwm.DwmSetWindowAttribute.argtypes = [wintypes.HWND, wintypes.DWORD, ctypes.POINTER(ctypes.c_int), wintypes.DWORD]
        dwm.DwmSetWindowAttribute.restype = ctypes.c_long
        _LIBRARIES[:] = [user32, dwm]
    return _LIBRARIES


def frame(window, force=False):
    """Under Windows 10 / 11: the title bar dark (or light) like the panel, its exact colour under
    Windows 11, the fine border; a floating window (list, bubble) gets small rounded corners under
    Windows 11. Elsewhere, or if Windows refuses: nothing changes."""
    if os.name != 'nt':
        return False
    try:
        if not force and window.__dict__.get('_modern_framed'):
            return True
        import ctypes
        user32, dwm = _windows()
        hwnd = user32.GetAncestor(window.winfo_id(), 2) or window.winfo_id()

        def put(attribute, value):
            v = ctypes.c_int(value)
            return dwm.DwmSetWindowAttribute(hwnd, attribute, ctypes.byref(v), ctypes.sizeof(v))
        t = theme(window)
        popup = False
        try:
            popup = bool(window.wm_overrideredirect())
        except tk.TclError:
            pass
        if popup:
            put(33, 3)                      # DWMWA_WINDOW_CORNER_PREFERENCE: DWMWCP_ROUNDSMALL
        else:
            if put(20, 1 if t['dark'] else 0) != 0:     # DWMWA_USE_IMMERSIVE_DARK_MODE
                put(19, 1 if t['dark'] else 0)          # the same before Windows 10 20H1
            put(35, _colorref(t['panel']))  # DWMWA_CAPTION_COLOR (Windows 11)
            put(36, _colorref(t['text']))   # DWMWA_TEXT_COLOR
            put(34, _colorref(t['border'])) # DWMWA_BORDER_COLOR
            user32.SetWindowPos(hwnd, None, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0004 | 0x0010 | 0x0020)
            caption = window.__dict__.get('_caption_controller')
            if caption is not None:
                caption.palette.clear()     # the centred title samples the new bar colour again
        window._modern_framed = True
        return True
    except Exception:
        return False


def _mapped(event):
    w = event.widget
    try:
        if isinstance(w, (tk.Tk, tk.Toplevel)) and not w.__dict__.get('_modern_seen'):
            w._modern_seen = True
            frame(w)
            if not w.wm_overrideredirect():
                restyle(w)      # every window: fields, lists and texts in the modern look
    except tk.TclError:
        pass


# ----------------------------------------------------------------------------------------------
# Message windows and small questions in Craft's look

_NATIVE = {}
ICONS = {'info': ('i', 'accent'), 'warning': ('!', 'warning'), 'error': ('×', 'danger'), 'question': ('?', 'accent')}


def _owner(parent):
    """The window a message belongs to, when it is shown; None (the native message window is
    used, which stays visible) when Craft is minimised or not shown yet."""
    root = parent if parent is not None else tk._default_root
    if root is None:
        return None
    try:
        return root if root.winfo_exists() and root.winfo_toplevel().winfo_viewable() else None
    except tk.TclError:
        return None


def _place(w, owner):
    w.update_idletasks()
    try:
        top = owner.winfo_toplevel()
        if not top.winfo_viewable():
            raise tk.TclError
        # Over Craft, even on a screen left of or above the main one (negative coordinates).
        x = top.winfo_rootx() + (top.winfo_width() - w.winfo_reqwidth()) // 2
        y = top.winfo_rooty() + max(40, (top.winfo_height() - w.winfo_reqheight()) // 3)
    except tk.TclError:
        x = max(0, (w.winfo_screenwidth() - w.winfo_reqwidth()) // 2)
        y = max(0, (w.winfo_screenheight() - w.winfo_reqheight()) // 3)
    w.geometry(f'+{x}+{y}')


def _symbol(parent, icon, t):
    glyph, colour = ICONS.get(icon, ICONS['info'])
    colour = t[colour]
    c = tk.Canvas(parent, width=30, height=30, bg=t['panel'], highlightthickness=0)
    c.create_oval(2, 2, 28, 28, fill=colour, outline='')
    ink = contrast_color(colour)
    if glyph == 'i':
        c.create_line(15, 13, 15, 22, fill=ink, width=2.6)
        c.create_oval(13.4, 7.4, 16.6, 10.6, fill=ink, outline='')
    elif glyph == '!':
        c.create_line(15, 8, 15, 17, fill=ink, width=2.6)
        c.create_oval(13.4, 19.4, 16.6, 22.6, fill=ink, outline='')
    elif glyph == '×':
        c.create_line(10, 10, 20, 20, fill=ink, width=2.6)
        c.create_line(20, 10, 10, 20, fill=ink, width=2.6)
    else:
        c.create_line(11, 12, 11, 11, 12, 8.5, 15, 7.5, 18, 8.5, 19, 11, 18, 13, 15, 15, 15, 18, fill=ink, width=2.4)
        c.create_oval(13.5, 20, 16.5, 23, fill=ink, outline='')
    try:
        from display_render import paint
        paint(c, icons=True)
    except Exception:
        pass
    return c


def _window(owner, title):
    t = theme(owner)
    w = tk.Toplevel(owner)
    w.withdraw()
    w.title(title or 'Craft')
    w.configure(bg=t['panel'])
    w.resizable(False, False)
    try:
        # Like Tk's own message window: tied to its window only when that one is shown (a window
        # tied to a hidden one would stay hidden under Windows).
        if owner.winfo_toplevel().winfo_viewable():
            w.transient(owner.winfo_toplevel())
    except tk.TclError:
        pass
    return w, t


def _plan_pointer(owner, shown):
    """0.19.9: on the plan, Windows' pointer is hidden (Craft draws its cross). While a message or a question
    is open, the plan shows the normal arrow (before: no pointer until it reached the small window); the
    cross comes back when it closes."""
    try:
        app = owner._root()
        if shown:
            if hasattr(app, 'pointer_cursor') and hasattr(app, 'canvas'):
                app.pointer_cursor('arrow')
                app.canvas.delete('crosshair')
        elif hasattr(app, 'restore_pointer'):
            app.after_idle(app.restore_pointer)
    except (tk.TclError, AttributeError):
        pass


def _modal(w, owner, first):
    previous_grab = None
    previous_focus = None
    try:
        previous_grab = w.grab_current()
        previous_focus = owner.focus_get()
    except (tk.TclError, KeyError):
        pass
    _plan_pointer(owner, True)
    _place(w, owner)
    w.deiconify()
    try:
        w.lift()
        w.wait_visibility()
        w.grab_set()
    except tk.TclError:
        pass
    (first if first is not None else w).focus_set()
    try:
        w.wait_window()
    finally:
        _plan_pointer(owner, False)
        for action in (lambda: previous_grab.grab_set() if previous_grab is not None and previous_grab.winfo_viewable() else None,
                       lambda: previous_focus.focus_set() if previous_focus is not None and previous_focus.winfo_exists() else None):
            try:
                action()
            except (tk.TclError, AttributeError):
                pass


class _Unmade(Exception):
    """The Craft window could not be made (no Tk window yet…): the original one is used."""


def message(title, text, buttons, default=None, cancel=None, icon='info', parent=None, detail=None):
    """A message window; ``buttons`` are (label, value) from left to right; returns the value
    chosen (``cancel`` for Échap and the window's ×)."""
    owner = _owner(parent)
    if owner is None:
        raise _Unmade('no window')
    try:
        w, t = _window(owner, title)
    except tk.TclError as exc:
        raise _Unmade(str(exc))
    result = {'value': cancel}
    body = tk.Frame(w, bg=t['panel'])
    body.pack(fill='both', expand=True, padx=(18, 22), pady=(18, 10))
    _symbol(body, icon, t).pack(side='left', anchor='n', padx=(0, 14))
    words = tk.Frame(body, bg=t['panel'])
    words.pack(side='left', fill='both', expand=True)
    tk.Label(words, text=text or '', bg=t['panel'], fg=t['text'], font=font(10), justify='left', wraplength=440, anchor='w').pack(anchor='w', fill='x')
    if detail:
        tk.Label(words, text=detail, bg=t['panel'], fg=t['muted'], font=font(9), justify='left', wraplength=440, anchor='w').pack(anchor='w', fill='x', pady=(6, 0))
    row = tk.Frame(w, bg=t['panel'])
    row.pack(fill='x', padx=18, pady=(6, 16))
    holder = tk.Frame(row, bg=t['panel'])
    holder.pack(side='right')
    values = [v for _, v in buttons]
    default = default if default in values else values[0]
    chosen = {}

    def close(value):
        result['value'] = value
        w.destroy()
    for label, value in buttons:   # left to right: Tab and the arrows follow the screen
        b = Button(holder, text=label, kind='primary' if value == default else 'secondary', command=lambda v=value: close(v), padx=16)
        b.pack(side='left', padx=(8, 0))
        chosen[value] = b
        letter = label[:1].lower()
        if letter.isascii() and letter.isalpha():   # O(ui), N(on), A(nnuler), R(éessayer), like Windows' boxes
            for key in (letter, letter.upper()):
                w.bind(f'<KeyPress-{key}>', lambda e, v=value: close(v))
    w.bind('<Return>', lambda e: close(_focused_value(w, chosen) or default))
    w.bind('<KP_Enter>', lambda e: close(_focused_value(w, chosen) or default))
    w.bind('<Escape>', lambda e: close(cancel))
    copy_text = lambda e: (w.clipboard_clear(), w.clipboard_append('\n\n'.join(v for v in (title, text, detail) if v)))
    w.bind('<Control-c>', copy_text)
    w.bind('<Control-C>', copy_text)   # 0.19.9: with Caps Lock on too, like the main window's shortcuts
    order = list(chosen.values())
    for k, b in enumerate(order):
        b.bind('<Left>', lambda e, k=k: order[max(0, k - 1)].focus_set())
        b.bind('<Right>', lambda e, k=k: order[min(len(order) - 1, k + 1)].focus_set())
    w.protocol('WM_DELETE_WINDOW', lambda: close(cancel))
    if icon in ('error', 'warning'):
        try:
            w.bell()
        except tk.TclError:
            pass
    _modal(w, owner, None)
    return result['value']


def _focused_value(w, chosen):
    try:
        focus = w.focus_get()
    except (tk.TclError, KeyError):
        return None
    return next((v for v, b in chosen.items() if b is focus), None)


def ask_value(kind, title, prompt, initialvalue=None, minvalue=None, maxvalue=None, parent=None, show=None):
    """askstring / askfloat / askinteger in Craft's look: None when cancelled; a decimal comma is
    accepted; a refused value is said in the window, which stays open."""
    owner = _owner(parent)
    if owner is None:
        raise _Unmade('no window')
    try:
        w, t = _window(owner, title)
    except tk.TclError as exc:
        raise _Unmade(str(exc))
    result = {'value': None}
    body = tk.Frame(w, bg=t['panel'])
    body.pack(fill='both', expand=True, padx=20, pady=(16, 6))
    tk.Label(body, text=prompt or '', bg=t['panel'], fg=t['text'], font=font(10), justify='left', wraplength=360, anchor='w').pack(anchor='w', fill='x')
    value = tk.StringVar(value='' if initialvalue is None else str(initialvalue))
    options = field(t)
    options.pop('disabledbackground', None)
    options.pop('readonlybackground', None)
    entry = tk.Entry(body, textvariable=value, width=32, show=show or '', **options)
    entry.pack(fill='x', pady=(8, 2), ipady=4)
    error = tk.Label(body, text='', bg=t['panel'], fg=t['danger'], font=font(9), anchor='w', justify='left')
    error.pack(anchor='w', fill='x')
    row = tk.Frame(w, bg=t['panel'])
    row.pack(fill='x', padx=20, pady=(4, 16))

    def accept():
        raw = value.get().strip()
        if kind == 'string':
            result['value'] = value.get()
            w.destroy()
            return
        try:
            number = float(raw.replace(',', '.')) if kind == 'float' else int(raw)
        except ValueError:
            error.configure(text='Nombre entier attendu.' if kind == 'integer' else 'Nombre attendu.')
            entry.focus_set()
            entry.select_range(0, 'end')
            return
        if minvalue is not None and number < minvalue:
            error.configure(text=f'Au moins {minvalue:g}.')
            entry.focus_set()
            return
        if maxvalue is not None and number > maxvalue:
            error.configure(text=f'Au plus {maxvalue:g}.')
            entry.focus_set()
            return
        result['value'] = number
        w.destroy()
    holder = tk.Frame(row, bg=t['panel'])
    holder.pack(side='right')
    ok = Button(holder, text='OK', kind='primary', command=accept, padx=20)
    ok.pack(side='left')
    cancel = Button(holder, text='Annuler', kind='secondary', command=w.destroy, padx=16)
    cancel.pack(side='left', padx=(8, 0))
    # 0.19.9: Entrée on a button (Tab to « Annuler ») is that button, as in message(); else OK (it was always OK)
    chosen = {accept: ok, w.destroy: cancel}
    for sequence in ('<Return>', '<KP_Enter>'):
        w.bind(sequence, lambda e: (_focused_value(w, chosen) or accept)())
    w.bind('<Escape>', lambda e: w.destroy())
    w.protocol('WM_DELETE_WINDOW', w.destroy)
    entry.select_range(0, 'end')
    entry.icursor('end')
    _modal(w, owner, entry)
    return result['value']


def _replacement(name):
    native = _NATIVE[name]
    kinds = {
        'showinfo': ([('OK', 'ok')], 'ok', 'info'), 'showwarning': ([('OK', 'ok')], 'ok', 'warning'),
        'showerror': ([('OK', 'ok')], 'ok', 'error'), 'askquestion': ([('Oui', 'yes'), ('Non', 'no')], 'no', 'question'),
        'askyesno': ([('Oui', 'yes'), ('Non', 'no')], 'no', 'question'),
        'askokcancel': ([('OK', 'ok'), ('Annuler', 'cancel')], 'cancel', 'question'),
        'askyesnocancel': ([('Oui', 'yes'), ('Non', 'no'), ('Annuler', 'cancel')], 'cancel', 'question'),
        'askretrycancel': ([('Réessayer', 'retry'), ('Annuler', 'cancel')], 'cancel', 'warning'),
    }
    buttons, cancel, icon = kinds[name]

    def ask(title=None, message_text=None, **options):
        if 'message' in options and message_text is None:
            message_text = options.pop('message')
        if not real():
            return native(title, message_text, **options)
        try:
            value = message(title, message_text, buttons, default=options.get('default'), cancel=cancel,
                            icon=options.get('icon', icon), parent=options.get('parent'), detail=options.get('detail'))
        except _Unmade:
            return native(title, message_text, **options)
        if name in ('showinfo', 'showwarning', 'showerror'):
            return 'ok'
        if name == 'askquestion':
            return value
        if name == 'askyesnocancel':
            return None if value == 'cancel' else value == 'yes'
        return value in ('yes', 'ok', 'retry')
    ask.__name__ = name
    ask._craft_modern = True
    return ask


def _question(kind, native):
    def ask(title, prompt, **options):
        if not real():
            return native(title, prompt, **options)
        try:
            return ask_value(kind, title, prompt, initialvalue=options.get('initialvalue'), minvalue=options.get('minvalue'),
                             maxvalue=options.get('maxvalue'), parent=options.get('parent'), show=options.get('show'))
        except _Unmade:
            return native(title, prompt, **options)
    ask._craft_modern = True
    return ask


def install_dialogs():
    """tkinter.messagebox and tkinter.simpledialog answered by Craft's windows (once per run; a
    window that cannot be made falls back to the original)."""
    import tkinter.messagebox as mb
    import tkinter.simpledialog as sd
    for name in ('showinfo', 'showwarning', 'showerror', 'askquestion', 'askokcancel', 'askyesno', 'askyesnocancel', 'askretrycancel'):
        current = getattr(mb, name)
        if getattr(current, '_craft_modern', False):
            continue
        _NATIVE[name] = current
        setattr(mb, name, _replacement(name))
    for name, kind in (('askstring', 'string'), ('askfloat', 'float'), ('askinteger', 'integer')):
        current = getattr(sd, name)
        if getattr(current, '_craft_modern', False):
            continue
        _NATIVE[name] = current
        setattr(sd, name, _question(kind, current))


# ----------------------------------------------------------------------------------------------
# All of it for a window

def apply(root, prefs):
    """The modern look for the window ``root`` with the palette ``prefs``: colours, font, ttk,
    Tk defaults, message windows, title bars (now and for every window opened later)."""
    t = tokens(prefs)
    if not real():
        return t
    try:
        setup_family(root)
    except Exception:
        pass
    root._modern_tokens = t
    try:
        style_ttk(root, t)
        option_defaults(root, t)
    except tk.TclError:
        pass
    install_dialogs()
    if not root.__dict__.get('_modern_bound'):
        root._modern_bound = True
        try:
            root.bind_class('Toplevel', '<Map>', _mapped, add='+')
            from ui_widgets import bind_own
            bind_own(root, '<Map>', _mapped)   # 0.19.3: the main window's own first showing only
        except tk.TclError:
            pass
    if root.__dict__.get('_modern_framed'):
        frame(root, force=True)
    return t
