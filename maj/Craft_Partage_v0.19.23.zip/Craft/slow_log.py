"""0.19.21 (« laggy quand je suis zoomé, j'ai l'impression à cause des ancrages », « je ne vois plus ma souris »,
09/11/2026): Craft notes in lenteurs.txt, in its data folder (beside diagnostic.txt), every moment it took more than
50 ms to answer (a move of the mouse, a click, the wheel, a key, a drawing done later), with what it was doing then:
the tool, the zoom, the accroches, the number of objects and selected ones, and the time spent snapping, drawing the
plan, lighting what is under the mouse. And when the cross stops following the mouse. Nothing is sent anywhere; the
file keeps its last lines only."""
import math
import time
import tkinter
import weakref

LIMIT = .050          # s: slower than this is noted
WINDOW_OPEN = 3.      # s: longer, a window or a menu was open meanwhile (Enregistrer sous, clic droit…): not a slowness
FILE = 'lenteurs.txt'
KEEP = 400            # lines kept in the file
EVENTS = {'2': 'touche', '4': 'clic', '5': 'relâché', '6': 'souris', '38': 'molette', '22': 'fenêtre', '7': 'entrée', '8': 'sortie'}
PARTS = (('point', 'accroches'), ('redraw', 'dessin'), ('draw_hover', 'survol'), ('draw_piece_anchors', 'ancres'), ('pick', 'choix'))

_app = None           # weak reference to the Craft window
_lines = []           # waiting to be written
_parts = {}           # time spent in each part during the event under way
_depth = 0
_lost = {'count': 0, 'said': 0.}
_installed = False


def install():
    """Before the window is built: every Tk callback (events and delayed drawings) is timed."""
    global _installed
    if _installed:
        return
    _installed = True
    base = tkinter.CallWrapper

    class Timed(base):
        def __call__(self, *args):
            global _depth
            if _app is None or _depth:
                return base.__call__(self, *args)
            _depth += 1
            _parts.clear()
            start = time.perf_counter()
            try:
                return base.__call__(self, *args)
            finally:
                _depth -= 1
                try:
                    spent = time.perf_counter() - start
                    if LIMIT < spent < WINDOW_OPEN:
                        note(self, args, spent)
                    if self.subst and len(args) > 15 and args[15] == '6':
                        watch_cross(self.widget, args)
                except Exception:
                    pass

    tkinter.CallWrapper = Timed


def attach(app):
    """Once the window is built: what is noted is about this window; the parts timed, on the window's class (once:
    a method replaced on the instance would hide a later change of the class's own)."""
    global _app
    _app = weakref.ref(app)
    cls = type(app)
    for name, label in PARTS:
        method = getattr(cls, name, None)
        if method is None or getattr(method, '_slow_log_part', False):
            continue

        def timed(self, *args, _method=method, _label=label, **kw):
            start = time.perf_counter()
            try:
                return _method(self, *args, **kw)
            finally:
                _parts[_label] = _parts.get(_label, 0.) + time.perf_counter() - start
        timed._slow_log_part = True
        timed.__name__ = getattr(method, '__name__', name)
        timed.__doc__ = getattr(method, '__doc__', None)
        setattr(cls, name, timed)


def context(app):
    d = app.__dict__
    out = []
    try:
        out.append('outil=' + app.tool.get())
        out.append(f'zoom={app.scale:.2f} px/mm'.replace('.', ','))
        snaps = [k for k, v in getattr(app, 'snap_vars', {}).items() if v.get()]
        out.append('accroches=' + (f'oui ({len(snaps)})' if app.snap.get() else 'non'))
        out.append('ortho=oui' if app.ortho.get() else 'ortho=non')
        out.append(f'objets={len(app.items)}')
        if app.selected_set:
            out.append(f'sélection={len(app.selected_set)}')
        states = [label for key, label in (('grip_drag', 'poignée tenue'), ('move_state', 'déplacement'), ('_box_pending', 'rectangle'),
                                          ('box_start', 'clic tenu'), ('_stack_choice', 'liste des ancres'), ('_grip_menu', 'menu Étirer'),
                                          ('corner_first', '1er côté choisi'), ('bg_tool', 'image de fond'), ('pick_phase', 'sélection d’une commande'))
                  if d.get(key)]
        if states:
            out.append('en cours : ' + ', '.join(states))
    except Exception:
        pass
    return ' · '.join(out)


def later(f):
    """For a drawing done later (after / after_idle): the function it calls; None for anything else. (tkinter's
    ``callit`` carries the function's name since Python 3.12; its code keeps its own.)"""
    if getattr(getattr(f, '__code__', None), 'co_name', None) != 'callit':
        return None
    for cell in getattr(f, '__closure__', None) or ():
        try:
            inner = cell.cell_contents
        except ValueError:
            continue
        if callable(inner) and not isinstance(inner, (tkinter.Misc, type)):
            return inner
    return None


def note(wrapper, args, spent):
    """Only what the plan or the window answers (mouse, keys) and what is drawn later; not the buttons and menus
    (their windows stay open inside them), nor this note itself."""
    app = _app() if _app else None
    if app is None:
        return
    inner = later(wrapper.func)
    if wrapper.subst:
        if wrapper.widget is not app and wrapper.widget is not app.__dict__.get('canvas'):
            return
        if len(args) > 15 and args[15] == '4' and args[1] == '3':
            return   # 0.19.22: the right click's menu stays open inside it (Windows): its time is the menu's
        func = getattr(wrapper.func, '__name__', '') or '?'
    elif inner is not None:
        if getattr(inner, '__module__', None) == __name__:
            return
        func = getattr(inner, '__name__', '') or '?'
    else:
        return
    kind = EVENTS.get(args[15], 'événement ' + str(args[15])) if wrapper.subst and len(args) > 15 else 'plus tard'
    parts = ', '.join(f'{label} {seconds * 1000:.0f} ms' for label, seconds in sorted(_parts.items(), key=lambda kv: -kv[1]) if seconds >= .005)
    line = f'{time.strftime("%d/%m %H:%M:%S")}  {spent * 1000:5.0f} ms  {kind} ({func})' + (f' · {parts}' if parts else '') + ' · ' + context(app)
    remember(app, line)


def watch_cross(widget, args):
    """The cross drawn far from the mouse (or not at all while the mouse is hidden) on several moves in a row."""
    app = _app() if _app else None
    d = app.__dict__ if app is not None else {}
    # (Déplacer puts the cross on its moved repère, a held grip has no cross: not a sign of being stuck. 0.19.22: ORTHO
    # leaves the cross on the mouse, or on an anchor beside it: watched too — he works with ORTHO on.)
    if app is None or widget is not d.get('canvas') or not d.get('_inside_plan') or d.get('move_state') or d.get('grip_drag'):
        _lost['count'] = 0
        return
    c = app.canvas
    try:
        x, y = float(args[8]), float(args[9])
        items = c.find_withtag('crosshair')
        if items:
            if len(items) < 3:
                return
            cx, cy = c.coords(items[2])[0], c.coords(items[0])[1]
            far = math.hypot(cx - x, cy - y) > 60
        else:
            far = str(c.cget('cursor')) == 'none'
    except (tkinter.TclError, ValueError, IndexError):
        return
    if not far:
        _lost['count'] = 0
        return
    _lost['count'] += 1
    if _lost['count'] >= 4 and time.monotonic() - _lost['said'] > 5:
        _lost['said'] = time.monotonic()
        where = 'pas de croix, souris cachée' if not items else f'croix à {math.hypot(cx - x, cy - y):.0f} px de la souris'
        remember(app, f'{time.strftime("%d/%m %H:%M:%S")}  bloqué : la croix ne suit plus la souris ({where}) · ' + context(app))


_flush = {'app': None, 'headed': False}


def remember(app, line):
    """Written within 3 s (one write for a burst of slow moves)."""
    _lines.append(line)
    owner = _flush['app']() if _flush['app'] else None
    if owner is app:
        return
    try:
        app.after(3000, flush)
        _flush['app'] = weakref.ref(app)
    except tkinter.TclError:
        pass


def flush():
    global _lines
    _flush['app'] = None
    lines, _lines = _lines, []
    if not lines:
        return
    try:
        from app_paths import user_data_directory
        import craft_version
        path = user_data_directory() / FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        old = path.read_text(encoding='utf-8').splitlines() if path.exists() else []
        if not _flush['headed']:
            _flush['headed'] = True
            lines.insert(0, f'--- Craft {craft_version.VERSION}, {time.strftime("%d/%m/%Y %H:%M")} ---')
        path.write_text('\n'.join((old + lines)[-KEEP:]) + '\n', encoding='utf-8')
    except Exception:
        pass
