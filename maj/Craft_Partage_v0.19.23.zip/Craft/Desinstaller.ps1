﻿$ErrorActionPreference = 'Stop'
$target = Join-Path $env:LOCALAPPDATA 'Craft'
# 0.19.15: an error is shown (the window opened by « Applications installees » would close at once).
trap {
    Write-Host ('Erreur : ' + $_.Exception.Message)
    Read-Host 'Appuyez sur Entree pour fermer' | Out-Null
    exit 1
}
# 0.19.15: the shared edition (installed by « Installer Craft » for his friends) is known before anything is removed:
# its link, its licence module, its own Python, its line in « Applications installees ».
$uninstall = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Craft'
$shared = (Test-Path -LiteralPath (Join-Path $target 'craft_distribution.py')) -or (Test-Path -LiteralPath (Join-Path $target 'licence_cle.py')) -or (Test-Path -LiteralPath (Join-Path $target 'Python')) -or (Test-Path -LiteralPath $uninstall)
Write-Host 'Suppression du programme uniquement. Vos patrons enregistres ailleurs sont conserves.'
$answer = Read-Host 'Supprimer Craft ? (O/N)'
if ($answer -notmatch '^\s*(o|oui)\s*$') { exit }   # 0.19.15: « oui » too
# 0.19.15: never while Craft is open (its files are in use): the locks of the running Craft windows, a Python process.
$running = Join-Path $target 'running'
if (Test-Path -LiteralPath $running) {
    foreach ($lock in Get-ChildItem -LiteralPath $running -Filter '*.json' -File -ErrorAction SilentlyContinue) {
        $id = 0
        if ([int]::TryParse($lock.BaseName, [ref]$id)) {
            $process = Get-Process -Id $id -ErrorAction SilentlyContinue
            if ($process -and $process.ProcessName -match '^pythonw?$') {
                Write-Host 'Craft est ouvert : fermez-le, puis relancez la desinstallation.'
                Read-Host 'Appuyez sur Entree pour fermer' | Out-Null
                exit 1
            }
        }
    }
}
# Each file on its own: one in use does not stop the others; this script and the line in « Applications installees »
# go last, only when everything else went (otherwise the uninstallation can be run again).
$failed = @()
function Remove-Path([string]$path, [switch]$folder) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    if ($folder) { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue }
    else { Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $path) { $script:failed += $path }
}
$self = Join-Path $target 'Desinstaller.ps1'
$desktop = [Environment]::GetFolderPath('Desktop')
if ($desktop) { Remove-Path (Join-Path $desktop 'Craft.lnk') }
$programs = [Environment]::GetFolderPath('Programs')
if ($programs) { Remove-Path (Join-Path $programs 'Craft') -folder }
foreach ($name in @('atelier.pyw','geometry.py','cad.py','workspace_ui.py','ui_widgets.py','exchange.py','dxf_base.dxf','updater.py','craft_tools.py','craft_studio.py','craft_refined.py','craft_workbench.py','precision_ui.py','precision_geometry.py','craft_brand.py','advanced_edit.py','advanced_ui.py','curves.py','finish_ui.py','Craft-logo2.ico','brand-shortcuts.sha256','editing.py','refined_icons.py','selection.py','Mettre_a_jour.cmd','Mettre_a_jour.ps1','Lancer.pyw','VerifierPython.py','Base_Maro.patron','Base_Petite_Maroquinerie.patron','LIRE_MOI.txt','Exemple_porte_cartes.patron')) {
    Remove-Path (Join-Path $target $name)
}
# 0.18.0: every file listed by the installed manifest (modules, DWG converter), then the .crft association.
$tracking = Join-Path $target 'installed_files.json'
if (Test-Path -LiteralPath $tracking) {
    $doc = $null
    try { $doc = Get-Content -LiteralPath $tracking -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $doc = $null }
    if ($doc -and $doc.files) {
        foreach ($name in $doc.files.PSObject.Properties.Name) {
            if ($name -match '^[A-Za-z0-9_.-]+$' -and $name -notlike '*.patron' -and $name -ne 'Desinstaller.ps1') {
                Remove-Path (Join-Path $target $name)
            }
        }
    }
}
$classes = 'HKCU:\Software\Classes'
$extension = Get-Item -LiteralPath "$classes\.crft" -ErrorAction SilentlyContinue
if ($extension -and $extension.GetValue('') -eq 'Craft.Patron') { Remove-Item -LiteralPath "$classes\.crft" -Recurse -ErrorAction SilentlyContinue }
if (Test-Path -LiteralPath "$classes\Craft.Patron") { Remove-Item -LiteralPath "$classes\Craft.Patron" -Recurse -ErrorAction SilentlyContinue }
if ($shared) {
    # 0.19.15: its own Python, the updates downloaded, its marks. Preferences, archives, the licence (commercial) and
    # the patterns stay.
    foreach ($folder in @('Python','Mises_a_jour','__pycache__')) { Remove-Path (Join-Path $target $folder) -folder }
    foreach ($name in @('mises_a_jour.json','installed_files.json','installed_version.json','craft_distribution.py','licence_cle.py','craft_certificats.py','online_update.py','Craft-logo3-green.ico')) {
        Remove-Path (Join-Path $target $name)
    }
    foreach ($icon in Get-ChildItem -LiteralPath $target -Filter 'Craft-logo3-green-*.ico' -File -ErrorAction SilentlyContinue) { Remove-Path $icon.FullName }
}
if ($failed.Count -gt 0) {
    Write-Host ('{0} fichier(s) de Craft n''ont pas pu etre supprimes (en cours d''utilisation) :' -f $failed.Count)
    $failed | Select-Object -First 5 | ForEach-Object { Write-Host ('  ' + $_) }
    Write-Host 'Fermez Craft (ou redemarrez Windows), puis relancez la desinstallation.'
    Read-Host 'Appuyez sur Entree pour fermer' | Out-Null
    exit 1
}
if (Test-Path -LiteralPath $uninstall) { Remove-Item -LiteralPath $uninstall -Recurse -ErrorAction SilentlyContinue }
Remove-Item -LiteralPath $self -Force -ErrorAction SilentlyContinue
if ($shared) {
    Write-Host 'Craft supprime. Vos patrons, vos reglages et votre licence sont conserves.'
    Read-Host 'Appuyez sur Entree pour fermer' | Out-Null
} else {
    Write-Host 'Programme supprime. Python reste installe. Les fichiers personnels sont conserves.'
}
