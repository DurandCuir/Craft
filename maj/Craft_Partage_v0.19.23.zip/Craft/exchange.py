"""DXF export (no runtime dependencies); DWG read and written by LibreDWG, shipped with Craft (0.18.0)."""
from pathlib import Path
import math
import os
import re
import shutil
import subprocess
import tempfile
from geometry import validate, path, bounds

# 0.19.9: the only line weights DXF / AutoCAD accept (group 370, in hundredths of mm; -1/-2/-3 ByLayer,
# ByBlock, Default): a Piqûre (0,12 mm) wrote 12, its holes 10, and AutoCAD had to repair the file.
LINEWEIGHTS=(0,5,9,13,15,18,20,25,30,35,40,50,53,60,70,80,90,100,106,120,140,158,200,211)


def lineweight(width):
    """0.19.9: the valid DXF line weight nearest to a width in mm (the thinner one between two)."""
    try:value=float(width)*100
    except (TypeError,ValueError):return -3
    if not math.isfinite(value):return -3
    return min(LINEWEIGHTS,key=lambda w:(abs(w-value),w))


def export_dxf(file,items):
    if not items:raise ValueError('Le dessin est vide.')
    validate(items)
    from craft_tools import style,notch_shapes
    from editing import drill_decorations,annotation_parts
    from curves import parts,cubics
    from stitching import hole_shapes
    # 0.18.0: a hand stitch exports its holes (circles of 1 mm) with its line, on CRAFT_SEAM.
    items=[q for s in items for q in annotation_parts(s)+notch_shapes(s)+drill_decorations(s)+hole_shapes(s)]
    items=[q for s in items for q in (parts(s) if s.get('components') else [s])]
    items=sorted(items,key=lambda s:0 if style(s)['role']=='internal' else 2 if style(s)['role']=='external' else 1)
    template=Path(__file__).with_name('dxf_base.dxf').read_text(encoding='cp1252')
    template='\n'.join(line.strip() for line in template.splitlines())+'\n'
    output=[];handle=0x1000;linetypes={}
    def pair(code,val):return f'{code}\n{val:.12g}\n' if isinstance(val,float) else f'{code}\n{val}\n'
    def entity(kind,subclass,values):
        nonlocal handle
        text=pair(0,kind)+pair(5,format(handle,'X'))+pair(330,'17')+pair(100,'AcDbEntity')+pair(8,layer)+pair(370,lineweight(st['width']))+(pair(420,int(st['color'][1:],16)) if st['color']!='auto' else '')+(pair(6,linetype) if linetype else '')+pair(100,subclass)
        handle+=1
        output.append(text+''.join(pair(code,value) for code,value in values))
    for s in items:
        st=style(s);layer={'external':'CRAFT_EXTERNAL','internal':'CRAFT_INTERNAL','seam':'CRAFT_SEAM','notch':'CRAFT_NOTCH','dimension':'CRAFT_DIMENSION','guide':'CRAFT_GUIDE'}.get(st['role'],'CRAFT_DRAWING')
        pattern=tuple(st['dash']);linetype=None
        if pattern:
            if pattern not in linetypes:linetypes[pattern]='CRAFT_DASH_'+str(len(linetypes)+1)
            linetype=linetypes[pattern]
        if s.get('drill_point'):
            entity('POINT','AcDbPoint',[(10,s['x']+s['w']/2),(20,-s['y']-s['h']/2),(30,0.)]);continue
        if s.get('filled'):
            points,_=path(s);pts=points[:3]+points[2:3]
            entity('SOLID','AcDbTrace',[(code,float(v)) for i,p in enumerate(pts) for code,v in [(10+i,p[0]),(20+i,-p[1]),(30+i,0.)]]);continue
        if s.get('annotation'):
            from craft_tools import annotation_baseline
            tx,ty=annotation_baseline(s);ty=-ty
            values=[(10,tx),(20,ty),(30,0.),(40,s.get('text_height',3)),(1,s['label'].replace('\n',' ')),(50,-s.get('text_angle',0))]
            if 'text_offset' in s:values += [(72,1),(11,tx),(21,ty),(31,0.)]
            values += [(100,'AcDbText')]
            if 'text_offset' in s:values += [(73,2)]
            entity('TEXT','AcDbText',values);continue
        x,y,w,h,r=[s[k] for k in ('x','y','w','h','r')]
        if s.get('spline'):
            for control in cubics(s):
                values=[(70,8),(71,3),(72,8),(73,4),(74,0)]+[(40,float(k)) for k in (0,0,0,0,1,1,1,1)]
                for a,b in control:values.extend([(10,a),(20,-b),(30,0.)])
                entity('SPLINE','AcDbSpline',values)
        elif s.get('ellipse'):
            e=s['ellipse'];a=e['angle']
            entity('ELLIPSE','AcDbEllipse',[(10,x),(20,-y),(30,0.),(11,e['rx']*math.cos(a)),(21,-e['rx']*math.sin(a)),(31,0.),(210,0.),(220,0.),(230,-1.),(40,e['ry']/e['rx']),(41,e['start']),(42,e['start']+e['sweep'])])
        elif s['kind']=='line':
            entity('LINE','AcDbLine',[(10,x),(20,-y),(30,0.),(11,x+w),(21,-y-h),(31,0.)])
        elif s['kind']=='circle':
            entity('CIRCLE','AcDbCircle',[(10,x+w/2),(20,-y-w/2),(30,0.),(40,w/2)])
        else:
            if s['kind']=='rect' and r>0:
                b=-math.tan(math.pi/8)
                pts=[(x+r,-y,0.),(x+w-r,-y,b),(x+w,-y-r,0.),(x+w,-y-h+r,b),
                     (x+w-r,-y-h,0.),(x+r,-y-h,b),(x,-y-h+r,0.),(x,-y-r,b)]
                closed=True
            elif s['kind']=='poly' and any(s.get('bulges',[])):
                closed=s.get('closed',False);pts=[(x+a,-y-b,-s['bulges'][i]) for i,(a,b) in enumerate(s['points'])]
            else:
                points,closed=path(s);pts=[(a,-b,0.) for a,b in points]
            values=[(90,len(pts)),(70,1 if closed else 0)]
            for a,b,bulge in pts:values.extend([(10,a),(20,b),(42,bulge)])
            entity('LWPOLYLINE','AcDbPolyline',values)
    # Export a complete DXF document using a generated, empty R2000 template.
    content,count=re.subn(r'(0\s*\nSECTION\s*\n2\s*\nENTITIES\s*\n).*?(?=0\s*\nENDSEC)',
                          lambda m:m[1]+''.join(output),template,count=1,flags=re.S)
    if count!=1:raise ValueError('Gabarit DXF invalide.')
    # 0.19.13: the line types numbered after the entities and $HANDSEED just after them (as the DWG Mozart): their
    # handles 50000 and the $HANDSEED 10000000 left a jump in the DWG's handle map (« handleoff looks wrong »), and
    # LibreDWG gave its own APPID the handle 10000000
    ltypes=[]
    for pattern,name in linetypes.items():
        values=[(0,'LTYPE'),(5,format(handle,'X')),(330,'2'),(100,'AcDbSymbolTableRecord'),(100,'AcDbLinetypeTableRecord'),(2,name),(70,0),(3,'Craft motif'),(72,65),(73,len(pattern)),(40,sum(pattern))]
        for j,value in enumerate(pattern):values.extend([(49,float(value if j%2==0 else -value)),(74,0)])
        ltypes.append(''.join(pair(code,value) for code,value in values));handle+=1
    content=re.sub(r'(9\s*\n\$HANDSEED\s*\n5\s*\n)[0-9A-Fa-f]+',lambda m:m[1]+format(handle,'X'),content,count=1)
    x,y,X,Y=bounds(items)
    for key,xyz in [('EXTMIN',(x,-Y,0)),('EXTMAX',(X,-y,0))]:
        replacement=''.join(pair(code,float(v)) for code,v in zip((10,20,30),xyz))
        content=re.sub(r'(9\s*\n\$'+key+r'\s*\n)10\s*\n[^\n]+\n20\s*\n[^\n]+\n30\s*\n[^\n]+\n',
                       lambda m:m[1]+replacement,content,count=1)
    if ltypes:
        match=re.search(r'(0\nTABLE\n2\nLTYPE\n)(.*?)(?=0\nENDTAB)',content,re.S)
        if not match:raise ValueError('Table DXF de motifs absente.')
        block=match[0];block=re.sub(r'(70\n)(\d+)',lambda m:m[1]+str(int(m[2])+len(ltypes)),block,count=1)
        content=content[:match.start()]+block+''.join(ltypes)+content[match.end():]
    # 0.19.9: written beside the target, then put in its place (as export_dwg): a file already there is
    # replaced only by a complete one; the temporary file never stays.
    target=Path(file)
    fd,name=tempfile.mkstemp(prefix='.Craft-',suffix='.dxf',dir=target.parent);os.close(fd);temp=Path(name)
    try:temp.write_text(content,encoding='cp1252',errors=UNICODE_ESCAPE);os.replace(temp,target)
    finally:temp.unlink(missing_ok=True)


LIBRARY='libredwg-0.dll'


# 0.19.22 (found before installing: ≥, →, ⌀, ⅓ came back as « ? »): a character the DXF's code page (cp1252) has not
# is written as AutoCAD does, \U+XXXX (read back by mozart_import, AutoCAD, LibreDWG).
UNICODE_ESCAPE='craft_dxf_unicode'
def _escape(error):
    return ''.join(f'\\U+{ord(c):04X}' if ord(c)<=0xFFFF else '?' for c in error.object[error.start:error.end]),error.end
import codecs
codecs.register_error(UNICODE_ESCAPE,_escape)
LIBRARY_SHA256='0e3302aec058b0c4d28554ed8ad8317b473c3f6bd67e1d0262f22668b57262d0'


def assemble_library(folder):
    """0.18.0: libredwg-0.dll copied in two parts (``.part1``, ``.part2``: a copy limited to
    30 MB per file) is put back together once, checked, and the parts removed. The library
    itself (from an update ZIP) is left as it is."""
    import hashlib
    folder=Path(folder);target=folder/LIBRARY
    if target.is_file():return target
    parts=[folder/(LIBRARY+f'.part{k}') for k in (1,2)]
    if not all(p.is_file() and not p.is_symlink() for p in parts):return None
    data=b''.join(p.read_bytes() for p in parts)
    if hashlib.sha256(data).hexdigest()!=LIBRARY_SHA256:return None
    temp=folder/(LIBRARY+'.tmp');temp.write_bytes(data);os.replace(temp,target)
    for p in parts:
        try:p.unlink()
        except OSError:pass
    return target


def libredwg(name):
    """0.18.0: the DWG converter shipped with Craft (GNU LibreDWG 0.13.3, GPL: LibreDWG_LICENCE.txt):
    dwg2dxf.exe and dxf2dwg.exe beside Craft with libredwg-0.dll. Nothing else to install.
    CRAFT_LIBREDWG may point to another folder (tests, Linux build)."""
    if os.name=='nt':
        try:assemble_library(Path(__file__).resolve().parent)
        except OSError:pass
    for folder in (os.environ.get('CRAFT_LIBREDWG'),str(Path(__file__).resolve().parent)):
        if not folder:continue
        for candidate in ((Path(folder)/(name+'.exe'),) if os.name=='nt' else (Path(folder)/name,)):
            if candidate.is_file():return candidate
    raise ValueError('Convertisseur DWG absent : réinstallez Craft.')


# 0.19.19: Windows refusing to start the converter (« [WinError 4551] Une stratégie de contrôle d'application a bloqué
# ce fichier », 09/11/2026): Smart App Control or App Control (programs not signed), a rule of the PC (group policy) or
# the antivirus. Said plainly with what to do; ui_widgets.show_error offers to open the page of Windows Security.
BLOCKED='Windows a bloqué le convertisseur DWG de Craft'
SMART_APP='Contrôle intelligent des applications'
INTEGRITY_ERRORS=frozenset({4551,4556,4557,4558,4559,4580,4581,4582})   # ERROR_SYSTEM_INTEGRITY_…
OTHER_BLOCKS=frozenset({225,226,1260})   # ERROR_VIRUS_INFECTED, ERROR_VIRUS_DELETED, ERROR_ACCESS_DISABLED_BY_POLICY
DLL_REFUSED=frozenset({0xC0000428,0xC0000428-2**32})   # STATUS_INVALID_IMAGE_HASH: libredwg-0.dll refused at its start


def blocked_message(code):
    """What Windows' refusal ``code`` means for the DWG converter, and what to do."""
    if code in (225,226):
        return (BLOCKED+' : l’antivirus l’a mis de côté.\n\nSécurité Windows › Protection contre les virus et menaces › '
                'Historique de protection : autorisez-le, ou réinstallez Craft.')
    if code==1260:return BLOCKED+' : une règle de ce PC l’interdit. Demandez à la personne qui gère ce PC.'
    return (BLOCKED+' : son « '+SMART_APP+' » refuse les programmes qui ne sont pas signés.\n\n'
            'Pour ouvrir et enregistrer des DWG : Sécurité Windows › Contrôle des applications et du navigateur › '
            'Paramètres du contrôle intelligent des applications › Désactivé. L’antivirus de Windows reste actif.\n\n'
            'Sur un PC d’école ou d’entreprise, c’est la personne qui gère ce PC qui le règle.')


def run_libredwg(name,args,folder,timeout=120):
    """Run one LibreDWG tool hidden, inside ``folder`` with plain file names (no accent in the
    command line: the tools read it in the Windows code page)."""
    exe=libredwg(name);options={}
    if os.name=='nt':options['creationflags']=subprocess.CREATE_NO_WINDOW
    try:result=subprocess.run([str(exe),*args],cwd=str(folder),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,**options)
    except subprocess.TimeoutExpired as exc:raise ValueError('Le convertisseur DWG ne répond pas (plus de deux minutes).') from exc
    except OSError as exc:
        code=getattr(exc,'winerror',None)
        if code in INTEGRITY_ERRORS or code in OTHER_BLOCKS:raise ValueError(blocked_message(code)) from exc
        raise ValueError('Le convertisseur DWG ne démarre pas : '+str(exc)) from exc
    if os.name=='nt' and result.returncode in DLL_REFUSED:raise ValueError(blocked_message(4551))
    return result


def tool_text(result):
    text=((result.stderr or b'')+(result.stdout or b'')).decode(errors='replace')
    lines=[line.strip() for line in text.splitlines() if line.strip() and not line.startswith(('Reading','Writing','Warning'))]
    return ' '.join(lines)[-400:]


def is_dwg(file):
    with Path(file).open('rb') as f:return re.fullmatch(rb'AC10\d{2}',f.read(6)) is not None


def dwg_dxf_bytes(dwg):
    """Any AutoCAD DWG (R13 to 2018) written as DXF by LibreDWG, in its own version: the DXF's
    bytes. 0.18.7: read where the converter wrote them; opening a DWG (mozart_import) no longer
    copies them to a second temporary file first."""
    source=Path(dwg)
    if not source.is_file():raise ValueError('Fichier DWG introuvable.')
    if not is_dwg(source):raise ValueError('Ce fichier n’est pas un DWG AutoCAD.')
    with tempfile.TemporaryDirectory(prefix='Craft-DWG-') as tmp:
        shutil.copyfile(source,Path(tmp)/'patron.dwg')
        result=run_libredwg('dwg2dxf',['-y','-o','patron.dxf','patron.dwg'],tmp)
        out=Path(tmp)/'patron.dxf'
        if not out.is_file() or out.stat().st_size<64:raise ValueError('Ce DWG n’a pas pu être lu. '+tool_text(result))
        data=out.read_bytes()
    if b'SECTION' not in data[:4000]:raise ValueError('Ce DWG n’a pas pu être lu.')
    return data


def dwg_to_dxf(dwg,target):
    """Any AutoCAD DWG (R13 to 2018) written as DXF by LibreDWG, in its own version."""
    data=dwg_dxf_bytes(dwg);Path(target).write_bytes(data)
    return Path(target)


_HANDLE_CODES=frozenset({5,105,480,481,1005}|set(range(320,370))|set(range(390,400)))


def _records(pairs):
    """(start, end) of each « 0 » record in the group pairs."""
    starts=[k for k,(c,_) in enumerate(pairs) if c.strip()=='0']
    return list(zip(starts,starts[1:]+[len(pairs)]))


def _swap_handle(pairs,a,b):
    if a==b:return pairs
    swap={a:b,b:a}
    out=[]
    for c,v in pairs:
        try:code=int(c)
        except ValueError:code=None
        if code in _HANDLE_CODES and v.strip().upper() in swap:v=swap[v.strip().upper()]
        out.append((c,v))
    return out


def dwg_ready(text):
    """0.19.9: the DXF given to LibreDWG for a DWG 2000 (AutoCAD opened Craft's DWG with 55 errors to repair and
    Mozart could not write the material into it): *Model_Space / *Paper_Space on AutoCAD's handles 1F / 1B
    (the converter makes them there: the file had two *Model_Space), no MLEADERSTYLE (not in the 2000 format),
    the VPORT axes and the MTEXT values the converter leaves empty, $DIMSTYLE naming a style of the file."""
    nl='\r\n' if '\r\n' in text else '\n'
    lines=text.split(nl)
    if lines and lines[-1]=='':lines.pop()
    if len(lines)%2:raise ValueError('DXF incomplet')
    pairs=list(zip(lines[0::2],lines[1::2]))
    def value(k):return pairs[k][1].strip()
    def code(k):return pairs[k][0].strip()
    # 0.19.11: the named objects dictionary on AutoCAD's handle C (LibreDWG looks for it there: else AutoCAD set again
    # the dictionaries ACAD_GROUP, ACAD_MLINESTYLE, ACAD_LAYOUT, ACAD_PLOTSTYLENAME and ACAD_PLOTSETTINGS, 5 errors)
    for s,e in _records(pairs):
        if value(s)=='DICTIONARY':
            fields={code(k):value(k) for k in range(e-1,s,-1)}
            if fields.get('330','0')=='0' and fields.get('5'):pairs=_swap_handle(pairs,fields['5'].upper(),'C')
            break
    # the special block records on AutoCAD's handles
    for name,want in (('*MODEL_SPACE','1F'),('*PAPER_SPACE','1B')):
        for s,e in _records(pairs):
            if value(s)=='BLOCK_RECORD':
                fields={code(k):value(k) for k in range(s+1,e)}
                if fields.get('2','').upper()==name and fields.get('5'):
                    pairs=_swap_handle(pairs,fields['5'].upper(),want);break
    # 0.19.13: the handle B left free: LibreDWG gives it to the VX table control it adds (a DXF never has one); the
    # dictionary that Craft's templates had on B made two objects with the handle B in the DWG
    taken={value(k).upper() for k in range(len(pairs)) if code(k) in ('5','105')}   # with $HANDSEED: never chosen
    if 'B' in taken:
        top=max(int(h,16) for h in taken if re.fullmatch('[0-9A-F]+',h))
        pairs=_swap_handle(pairs,'B',format(top+1,'X'))
    # MLEADERSTYLE: its class, its objects, its dictionary and the entries pointing to them
    drop=set()
    for s,e in _records(pairs):
        if value(s)=='MLEADERSTYLE':drop|={value(k).upper() for k in range(s+1,e) if code(k)=='5'}
    for k in range(len(pairs)-1):
        if code(k)=='3' and value(k)=='ACAD_MLEADERSTYLE' and code(k+1) in ('350','360'):drop.add(value(k+1).upper())
    records=_records(pairs);styles=[];out=list(pairs[:records[0][0]] if records else pairs)
    for s,e in records:
        kind=value(s);body=pairs[s+1:e]
        fields={}
        for c,v in body:fields.setdefault(c.strip(),v.strip())
        if kind=='CLASS' and fields.get('1')=='MLEADERSTYLE':continue
        if kind=='MLEADERSTYLE' or kind=='DICTIONARY' and fields.get('5','').upper() in drop:continue
        if kind=='DICTIONARY' and drop:
            kept=[];k=0
            while k<len(body):
                if body[k][0].strip()=='3' and k+1<len(body) and body[k+1][0].strip() in ('350','360') and body[k+1][1].strip().upper() in drop:k+=2;continue
                kept.append(body[k]);k+=1
            body=kept
        elif kind=='MTEXT':
            have=set(fields);res=[]
            for c,v in body:
                res.append((c,v))
                if c.strip()=='30' and '210' not in have:res+=[('210','0.0'),('220','0.0'),('230','1.0')]
                if c.strip()=='40' and '11' not in have:res+=[('11','1.0'),('21','0.0'),('31','0.0')]
                if c.strip()=='41' and '46' not in have:res.append(('46','0.0'))
            if '73' not in have:res+=[('73','1'),('44','1.0')]
            body=res
        elif kind=='VPORT' and '111' not in fields:
            body=body+[('110','0.0'),('120','0.0'),('130','0.0'),('111','1.0'),('121','0.0'),('131','0.0'),('112','0.0'),('122','1.0'),('132','0.0')]
        elif kind=='DIMSTYLE' and fields.get('2'):styles.append(fields['2'])
        out.append(pairs[s]);out+=body
    # $DIMSTYLE naming a dimension style that exists
    if styles:
        for k in range(len(out)-1):
            if out[k][0].strip()=='9' and out[k][1].strip()=='$DIMSTYLE' and out[k+1][0].strip()=='2':
                if out[k+1][1].strip() not in styles:out[k+1]=(out[k+1][0],'Standard' if 'Standard' in styles else styles[0])
                break
    # 0.19.22 (found before installing): LibreDWG numbers the objects it adds (its APPID, the VX table of the 2000 format) after the LAST object it reads,
    # not after $HANDSEED: that object takes the highest handle, so that nothing of the file is numbered after it
    # (Craft's layers 32 to 38, the APPID CRAFT 25C of the Mozart template had the same handles as LibreDWG's objects)
    last=next((h for s,e in reversed(_records(out)) for h in [next((out[k][1].strip().upper() for k in range(s+1,e) if out[k][0].strip() in ('5','105')),None)] if h),None)
    top=max((int(v.strip(),16) for k,(c,v) in enumerate(out) if k and c.strip() in ('5','105') and out[k-1][0].strip()!='9' and re.fullmatch('[0-9A-Fa-f]+',v.strip())),default=0)
    if last and re.fullmatch('[0-9A-F]+',last) and int(last,16)<top:out=_swap_handle(out,last,format(top+1,'X'))
    # $HANDSEED above every handle (the dictionary moved from B is the last one)
    seed=[k+1 for k in range(len(out)-1) if out[k][0].strip()=='9' and out[k][1].strip()=='$HANDSEED' and out[k+1][0].strip()=='5']
    if seed:
        used=[int(v.strip(),16) for k,(c,v) in enumerate(out) if c.strip() in ('5','105') and k!=seed[0] and re.fullmatch('[0-9A-Fa-f]+',v.strip())]
        try:current=int(out[seed[0]][1].strip(),16)
        except ValueError:current=0
        if used and current<=max(used):out[seed[0]]=(out[seed[0]][0],format(max(used)+1,'X'))
    return nl.join(x for p in out for x in p)+nl


def dxf_to_dwg(dxf,target):
    """Craft's DXF written as a DWG 2000 by LibreDWG (opened by every AutoCAD since 2000)."""
    with tempfile.TemporaryDirectory(prefix='Craft-DWG-') as tmp:
        raw=Path(dxf).read_bytes().decode('latin-1')
        try:ready=dwg_ready(raw)
        except Exception:ready=raw   # an unexpected DXF: converted as it is
        (Path(tmp)/'Craft.dxf').write_bytes(ready.encode('latin-1'))
        result=run_libredwg('dxf2dwg',['-o','Craft.dwg','Craft.dxf'],tmp)
        out=Path(tmp)/'Craft.dwg'
        if not out.is_file() or out.stat().st_size<64 or not is_dwg(out):raise ValueError('Le DWG n’a pas pu être écrit. '+tool_text(result))
        shutil.copyfile(out,target)
    return Path(target)


def export_dwg(file,items):
    """Through Craft's own DXF, converted by LibreDWG; an existing file is replaced only once the
    new DWG is complete."""
    with tempfile.TemporaryDirectory(prefix='Craft-DWG-') as tmp:
        dxf=Path(tmp)/'Craft.dxf';export_dxf(dxf,items);made=dxf_to_dwg(dxf,Path(tmp)/'Craft.dwg')
        target=Path(file)
        fd,name=tempfile.mkstemp(prefix='.Craft-',suffix='.dwg',dir=target.parent);os.close(fd);temp_target=Path(name)
        try:shutil.copyfile(made,temp_target);temp_target.replace(target)
        finally:temp_target.unlink(missing_ok=True)
