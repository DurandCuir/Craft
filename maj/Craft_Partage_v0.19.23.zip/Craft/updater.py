"""Local ZIP updates for Craft. Standard library only; no downloading or installation."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

APP_ID='craft-desktop'
MANIFEST='craft-update.json'
REQUIRED={'Lancer.pyw','atelier.pyw','geometry.py','cad.py','workspace_ui.py','ui_widgets.py','exchange.py','dxf_base.dxf','updater.py'}
TRACKING='installed_files.json'
METADATA={'installed_version.json',TRACKING}
RUNTIME=REQUIRED|{'window_caption.py','display_render.py','entity_rules.py','native_edit.py','command_catalog.py','pdf_layout.py','export_preview.py','windows_identity.py','atelier_core.py','bootstrap.py','app_paths.py','app_preferences.py','craft_version.py','brand_assets.py','advanced_edit.py','advanced_ui.py','curves.py','finish_ui.py','craft_brand.py','craft_tools.py','craft_studio.py','craft_refined.py','craft_workbench.py','precision_ui.py','precision_geometry.py','editing.py','refined_icons.py','selection.py','licence.py','licence_ui.py','licence_cle.py','update_notice.py','print_direct.py','autosave.py','regions.py','transform.py','transform_ui.py','tracking.py','mozart_import.py','materials.py','export_check.py','preparations.py','preparation_ui.py','fiches.py','LIRE_MOI.txt','Mettre_a_jour.cmd','Mettre_a_jour.ps1','Desinstaller.ps1','VerifierPython.py'}
# 0.18.0: the DWG converter (LibreDWG, GPL) is shipped with Craft; only these binaries are allowed.
BINARIES={'dwg2dxf.exe','dxf2dwg.exe','libredwg-0.dll'}
RUNTIME|=BINARIES|{'LibreDWG_LICENCE.txt','LibreDWG_LISEZMOI.txt','doc_files.py','stitching.py','backdrop.py','background_ui.py','pdf_reader.py'}
RUNTIME|={'model_info.py','piece_ids.py','surcoupe.py','surcoupe_ui.py'}   # 0.18.1
RUNTIME|={'anchor_stack.py','dash_lines.py','deep_zoom.py'}   # 0.18.5
RUNTIME|={'draw_cache.py'}   # 0.18.7
RUNTIME|={'modern_style.py'}   # 0.19.0
RUNTIME|={'belt_holes_ui.py'}   # 0.19.5
RUNTIME|={'strap_ui.py'}   # 0.19.6
RUNTIME|={'settings_ui.py'}   # 0.19.7
RUNTIME|={'mozart_export.py','mozart_base.dxf'}   # 0.19.8
RUNTIME|={'online_update.py','craft_distribution.py','craft_certificats.py'}   # 0.19.15 (the last two: the shared edition only)
MAX_FILE=40*1024*1024        # libredwg-0.dll is about 34 MB
MAX_BYTES=100*1024*1024


def sha256(data):return hashlib.sha256(data).hexdigest()


def allowed(name):
    if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}',name):return False
    if name in ('preferences.json','installed_version.json',MANIFEST):return False
    suffix=Path(name).suffix.lower()
    if suffix=='.patron':return name in ('Base_Maro.patron','Base_Petite_Maroquinerie.patron','Exemple_porte_cartes.patron')
    if suffix in ('.exe','.dll'):return name in BINARIES
    return suffix in ('.py','.pyw','.dxf','.txt','.cmd','.ps1')


def version_tuple(version):
    if not isinstance(version,str) or not re.fullmatch(r'\d{1,4}\.\d{1,4}\.\d{1,4}',version):raise ValueError('Version de mise à jour invalide.')
    return tuple(map(int,version.split('.')))


def parse_manifest(data):
    if len(data)>100000:raise ValueError('Manifeste trop volumineux.')
    doc=json.loads(data)
    if not isinstance(doc,dict) or doc.get('app_id')!=APP_ID or doc.get('schema')!=1:raise ValueError('Ce paquet n’est pas une mise à jour Craft compatible.')
    version_tuple(doc.get('version'))
    files=doc.get('files')
    if not isinstance(files,dict) or len(files)>120 or not REQUIRED.issubset(files):raise ValueError('La mise à jour est incomplète.')
    for name,digest in files.items():
        if not allowed(name) or not isinstance(digest,str) or not re.fullmatch(r'[0-9a-f]{64}',digest):raise ValueError('Nom ou empreinte de fichier non autorisé.')
    return doc


def read_bundle(source,folder=False):
    """Return verified bytes. Never use extractall or trust paths in an archive."""
    source=Path(source)
    if folder:
        manifest_bytes=(source/MANIFEST).read_bytes();manifest=parse_manifest(manifest_bytes)
        payload={};total=0
        for name,digest in manifest['files'].items():
            p=source/name
            if p.is_symlink() or not p.is_file() or p.stat().st_size>MAX_FILE:raise ValueError('Fichier de mise à jour invalide.')
            total+=p.stat().st_size
            if total>MAX_BYTES:raise ValueError('Paquet trop volumineux.')
            payload[name]=p.read_bytes()
    else:
        with zipfile.ZipFile(source) as z:
            infos=z.infolist();names=[p.filename for p in infos]
            if len(infos)>100 or len(set(names))!=len(names):raise ValueError('Archive ambiguë ou trop volumineuse.')
            for info in infos:
                parts=PurePosixPath(info.filename).parts
                if '\\' in info.filename or '..' in parts or not parts or parts[0]!='Craft' or len(parts)>2:
                    raise ValueError('Chemin non autorisé dans le ZIP.')
                if (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Liens non autorisés dans la mise à jour.')
                if info.file_size<0 or info.file_size>MAX_FILE:raise ValueError('Fichier trop volumineux.')
            if sum(i.file_size for i in infos)>MAX_BYTES:raise ValueError('Paquet trop volumineux.')
            manifest_bytes=z.read('Craft/'+MANIFEST);manifest=parse_manifest(manifest_bytes)
            expected={'Craft/'+name for name in manifest['files']}|{'Craft/'+MANIFEST}
            if any(name not in expected and name!='Craft/' for name in names):raise ValueError('Le ZIP contient des fichiers inattendus.')
            payload={name:z.read('Craft/'+name) for name in manifest['files']}
    for name,digest in manifest['files'].items():
        if sha256(payload[name])!=digest:raise ValueError('Mise à jour endommagée : '+name)
    return manifest,payload


def current_version(target):
    p=Path(target)/'installed_version.json'
    try:return json.loads(p.read_text(encoding='utf-8'))['version']
    except (OSError,ValueError,KeyError,TypeError):
        try:
            version_file=Path(target)/'craft_version.py'
            text=(version_file if version_file.is_file() else Path(target)/'workspace_ui.py').read_text(encoding='utf-8')
            match=re.search(r"^VERSION=['\"]([^'\"]+)['\"]",text,re.M)
            return match[1] if match else '0.0.0'
        except OSError:return '0.0.0'


def process_alive(pid):
    if not isinstance(pid,int) or pid<=0:return False
    if os.name=='nt':
        import ctypes
        kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong]
        kernel.OpenProcess.restype=ctypes.c_void_p
        kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
        kernel.WaitForSingleObject.restype=ctypes.c_ulong
        kernel.CloseHandle.argtypes=[ctypes.c_void_p]
        handle=kernel.OpenProcess(0x100000,False,pid)
        if not handle:return ctypes.get_last_error()==5
        try:return kernel.WaitForSingleObject(handle,0)==0x102
        finally:kernel.CloseHandle(handle)
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False
    except PermissionError:return True


def wait_exit(pid,timeout=45):
    deadline=time.monotonic()+timeout
    while process_alive(pid):
        if time.monotonic()>deadline:raise ValueError('Craft est toujours ouvert. Fermez-le avant la mise à jour.')
        time.sleep(.2)


def ensure_closed(target):
    locks=Path(target)/'running'
    if not locks.exists():return
    for p in locks.glob('*.json'):
        try:
            pid=int(p.stem)
            if process_alive(pid):raise ValueError('Une fenêtre Craft est encore ouverte. Fermez toutes les fenêtres Craft.')
        except (TypeError,OverflowError):continue


def restore_backup(target,backup):
    target=Path(target);backup=Path(backup)
    metadata=json.loads((backup/'transaction.json').read_text(encoding='utf-8'))
    originals=metadata['originals'];created=metadata['created']
    if not isinstance(originals,dict) or not isinstance(created,list):raise ValueError('Sauvegarde invalide.')
    for name,digest in originals.items():
        if name not in METADATA and not allowed(name):raise ValueError('Sauvegarde invalide.')
        data=(backup/name).read_bytes()
        if sha256(data)!=digest:raise ValueError('Sauvegarde endommagée : '+name)
    for name in created:
        if name not in METADATA and not allowed(name):raise ValueError('Sauvegarde invalide.')
    failed=[]
    for name in originals:
        p=target/name
        if p.is_symlink():raise ValueError('Cible de restauration invalide.')
        try:
            if p.is_file() and sha256(p.read_bytes())==originals[name]:continue   # never replaced (or already back)
            shutil.copyfile(backup/name,p)
        except OSError as exc:failed.append((name,exc))   # the others are put back all the same
    for name in created:
        try:(target/name).unlink(missing_ok=True)
        except OSError as exc:failed.append((name,exc))
    if failed:raise failed[0][1]


def previous_files(target):
    try:
        p=Path(target)/TRACKING
        if p.is_symlink():return {}
        doc=json.loads(p.read_text(encoding='utf-8'))
        return doc.get('files',{}) if isinstance(doc,dict) and doc.get('app_id')==APP_ID and isinstance(doc.get('files'),dict) else {}
    except (OSError,ValueError,TypeError):return {}


def removable_runtime(name):
    return allowed(name) and (Path(name).suffix.lower() in ('.py','.pyw','.cmd','.ps1') or name in ('dxf_base.dxf','mozart_base.dxf','LIRE_MOI.txt'))


def cleanup_obsolete(target,keep_backup=None):
    """Only verified runtime leftovers inside the installation are eligible."""
    target=Path(target).resolve()
    cache=target/'__pycache__'
    if cache.is_dir() and not cache.is_symlink():
        # 0.19.6: only the compiled copies of modules no longer installed go: Python compiles a changed module
        # again by itself (clearing them all made the first start after an update compile every module:
        # « Démarrage : 4,4 s, modules 2,2 s »).
        # Files copied with the ZIP's own date (2026-01-01: Installer.cmd keeps it) cannot tell a new module from
        # the old one by its date: then all go, as before.
        import time
        stamp=time.mktime((2026,1,1,0,0,0,0,0,-1))
        zipped=any(abs(p.stat().st_mtime-stamp)<=2*86400 for p in target.glob('*.py') if p.is_file())
        for p in cache.iterdir():
            # a compiled copy whose module is gone, or a leftover of a write cut short (« x.pyc.123 »)
            stale=p.suffix=='.pyc' and (zipped or not (target/(p.name.split('.')[0]+'.py')).is_file()) or '.pyc.' in p.name
            if p.is_file() and not p.is_symlink() and stale:
                try:p.unlink()
                except OSError:pass
        try:cache.rmdir()   # (only when empty)
        except OSError:pass
    locks=target/'running'
    if locks.is_dir() and not locks.is_symlink():
        for p in locks.glob('*.json'):
            if p.is_symlink() or not p.stem.isdigit():continue
            if not process_alive(int(p.stem)):
                try:p.unlink()
                except OSError:pass
        try:locks.rmdir()
        except OSError:pass
    # Recognize archived packages by name AND a complete, matching manifest.
    for folder in target.iterdir():
        if not folder.is_dir() or folder.is_symlink() or not re.fullmatch(r'Craft[_-](?:Mise_a_jour[_-])?v?\d+\.\d+\.\d+',folder.name,re.I):continue
        root=folder/'Craft' if (folder/'Craft').is_dir() else folder
        try:
            if any(p.is_symlink() for p in folder.rglob('*')):continue
            doc=parse_manifest((root/MANIFEST).read_bytes())
            if version_tuple(doc['version'])>=version_tuple(current_version(target)):continue
            expected=set(doc['files'])|{MANIFEST}
            if any(not p.is_file() or p.name not in expected for p in root.iterdir()):continue
            if root!=folder and list(folder.iterdir())!=[root]:continue
            if not all((root/n).is_file() and sha256((root/n).read_bytes())==h for n,h in doc['files'].items()):continue
            shutil.rmtree(folder)
        except (OSError,ValueError,TypeError):continue
    backups=target.parent/'Craft-backups'
    if not backups.is_dir() or backups.is_symlink():return
    candidates=[p for p in backups.iterdir() if p.is_dir() and not p.is_symlink() and re.match(r'^\d+\.\d+\.\d+-',p.name)]
    keep=Path(keep_backup) if keep_backup else max(candidates,key=lambda p:p.stat().st_mtime,default=None)
    for folder in candidates:
        if folder==keep:continue
        try:
            doc=json.loads((folder/'transaction.json').read_text());originals=doc['originals']
            if not isinstance(originals,dict) or any(n not in METADATA and (not allowed(n) or Path(n).suffix=='.patron') for n in originals):continue
            if any(p.is_symlink() or not p.is_file() or p.name not in set(originals)|{'transaction.json'} for p in folder.iterdir()):continue
            if not all(sha256((folder/n).read_bytes())==h for n,h in originals.items()):continue
            shutil.rmtree(folder)
        except (OSError,ValueError,KeyError,TypeError):continue


def maintain_installation(target):
    """Runs once per installed version, whatever installed it (updater, older
    helper or a direct copy): old backups (the newest is kept) and older Craft
    update ZIPs are removed (0.19.9: and the Craft-update-* folders of the temporary folder
    left by earlier updates, once a day old; the one of this update goes at a later version's
    first start). Patterns, archives and preferences are never touched."""
    target=Path(target).resolve();version=current_version(target)
    if (target/TRACKING).is_symlink():return
    doc=None
    try:
        doc=json.loads((target/TRACKING).read_text())
        if isinstance(doc,dict) and doc.get('app_id')==APP_ID and doc.get('version')==version and doc.get('cleaned')==version:return
    except (OSError,ValueError,TypeError):pass
    # 0.19.9: once per version, no longer at every start: with the current ZIP still in Téléchargements (after
    # a ZIP update) each start unzipped and checked its 36 MB twice and read every installed file (0,7 to 0,9 s).
    try:cleanup_download_packages(target)
    except OSError:pass
    cleanup_update_helpers()   # 0.19.9
    try:
        cleanup_obsolete(target)
        cleanup_old_packages(version)
        # 0.19.6: the fingerprints written with this version (update, installation) are kept: reading every
        # file again (with the 34 MB DWG library) slowed the first start after an update.
        known=doc.get('files') if isinstance(doc,dict) and doc.get('app_id')==APP_ID and doc.get('version')==version else None
        if isinstance(known,dict) and known and all(isinstance(k,str) and isinstance(v,str) for k,v in known.items()):files=known
        else:files={n:sha256((target/n).read_bytes()) for n in RUNTIME if (target/n).is_file() and not (target/n).is_symlink()}
        (target/TRACKING).write_text(json.dumps(dict(app_id=APP_ID,version=version,files=files,cleaned=version),indent=2),encoding='utf-8')
    except OSError:pass


def download_directories():
    directories=[Path.home()/'Downloads']
    if os.name=='nt':
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,r'Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders') as key:
                value,_=winreg.QueryValueEx(key,'{374DE290-123F-4565-9164-39C4925E467B}');directories.insert(0,Path(os.path.expandvars(value)))
        except OSError:pass
    # 0.19.9: one folder once, however it is written (the home folder and the registry often give the same one)
    seen={}
    for folder in directories:
        try:key=os.path.normcase(os.path.realpath(folder))
        except (OSError,ValueError):key=os.path.normcase(str(folder))
        seen.setdefault(key,folder)
    return list(seen.values())


def cleanup_old_packages(version,directories=None):
    """Older Craft update ZIPs (name, manifest and content verified) are removed
    from the download folders once a newer version is installed (0.16.16)."""
    removed=[]
    for folder in (download_directories() if directories is None else directories):
        try:candidates=[p for p in Path(folder).glob('*.zip')]
        except OSError:continue
        for candidate in candidates:
            match=re.fullmatch(r'Craft_Mise_a_jour_v(\d+\.\d+\.\d+)(?:\s*\(\d+\))?\.zip',candidate.name,re.I)
            if not match or candidate.is_symlink() or not candidate.is_file():continue
            try:
                if version_tuple(match[1])>=version_tuple(version):continue
                manifest,_=read_bundle(candidate)
                if manifest['version']!=match[1]:continue
                candidate.unlink();removed.append(candidate.name)
            except (OSError,ValueError,KeyError,zipfile.BadZipFile):continue
    return removed


EDITION_FILES=('licence_cle.py','craft_distribution.py')   # 0.19.15: what only the shared edition (his friends') has


def check_edition(target,names):
    """0.19.15: an update of the other edition is refused: his own Craft never takes the shared one (licence, Internet),
    a friend's never loses its licence and its updates (Aide › Mettre à jour Craft depuis un ZIP, the helper)."""
    installed=tuple((Path(target)/n).is_file() for n in EDITION_FILES)
    if tuple(n in names for n in EDITION_FILES)!=installed:
        raise ValueError('Ce ZIP est celui d’une autre édition de Craft : il n’est pas installé.')


def apply_update(target,manifest,payload,first_install=False):
    target=Path(target).resolve()
    if first_install:target.mkdir(parents=True,exist_ok=True)
    elif not (target/'Lancer.pyw').is_file() or not (target/'workspace_ui.py').is_file():raise ValueError('Craft doit déjà être installé. Utilisez Installer.cmd pour une première installation.')
    # The public entry point revalidates even if called outside the normal ZIP flow.
    manifest=parse_manifest(json.dumps(manifest).encode())
    if not first_install:check_edition(target,manifest['files'])
    if set(payload)!=set(manifest['files']) or any(sha256(payload[n])!=digest for n,digest in manifest['files'].items()):raise ValueError('Contenu de mise à jour invalide.')
    if version_tuple(manifest['version'])<=version_tuple(current_version(target)):raise ValueError('Cette version est déjà installée ou est plus ancienne.')
    ensure_closed(target)
    backups=target.parent/'Craft-backups';backups.mkdir(exist_ok=True)
    backup=Path(tempfile.mkdtemp(prefix=current_version(target)+'-',dir=backups))
    originals={};created=[];changes={}
    obsolete=[]
    for name,digest in previous_files(target).items():
        p=target/name
        if name not in payload and removable_runtime(name) and p.is_file() and not p.is_symlink() and sha256(p.read_bytes())==digest:obsolete.append(name)
    for name,data in payload.items():
        p=target/name
        # All existing pattern files, including supplied templates, are user data.
        if p.exists() and p.suffix.lower()=='.patron':continue
        if p.is_symlink():raise ValueError('Cible de mise à jour invalide : '+name)
        changes[name]=data
    changes['installed_version.json']=json.dumps(dict(app_id=APP_ID,version=manifest['version']),indent=2).encode()
    changes[TRACKING]=json.dumps(dict(app_id=APP_ID,version=manifest['version'],files={n:h for n,h in manifest['files'].items() if Path(n).suffix!='.patron'}),indent=2).encode()
    # All old bytes are backed up before any file is replaced.
    for name in set(changes)|set(obsolete):
        p=target/name
        if p.is_symlink():raise ValueError('Cible de mise à jour invalide : '+name)
        if p.exists():
            data=p.read_bytes();(backup/name).write_bytes(data);originals[name]=sha256(data)
        else:created.append(name)
    (backup/'transaction.json').write_text(json.dumps(dict(originals=originals,created=created),indent=2),encoding='utf-8')
    with tempfile.TemporaryDirectory(prefix='Craft-stage-',dir=target.parent) as stage:
        stage=Path(stage)
        for name,data in changes.items():(stage/name).write_bytes(data)
        # Launcher and version marker are last, after all application modules.
        names=sorted(changes,key=lambda n:(n in ('Lancer.pyw','installed_version.json'),n))
        try:
            for name in names:os.replace(stage/name,target/name)
            for name in obsolete:(target/name).unlink()
        except Exception:
            restore_backup(target,backup)
            raise
    try:cleanup_obsolete(target,backup)
    except OSError:pass
    return backup


def install_bundle(source,target):
    """Installer.cmd (0.16.17): first installation on a new PC, or upgrade of an
    existing Craft. The same version already installed is left as it is."""
    manifest,payload=read_bundle(source,folder=True);target=Path(target)
    if (target/'Lancer.pyw').is_file() and (target/'workspace_ui.py').is_file():
        if version_tuple(manifest['version'])<=version_tuple(current_version(target)):return None
        return apply_update(target,manifest,payload)
    return apply_update(target,manifest,payload,first_install=True)


def start_update(package,target,restart,reopen=None):
    manifest,_=read_bundle(package)
    if version_tuple(manifest['version'])<=version_tuple(current_version(target)):raise ValueError('Ce ZIP ne contient pas de version plus récente.')
    helperdir=Path(tempfile.mkdtemp(prefix='Craft-update-'))
    helper=helperdir/'updater.py';shutil.copyfile(__file__,helper)
    # Copying the package makes the update independent of Downloads or a USB key.
    bundle=helperdir/'update.zip';shutil.copyfile(package,bundle)
    python=Path(restart)
    if python.name.lower()=='pythonw.exe':python=python.with_name('python.exe')
    args=[str(python),'-E',str(helper),'--package',str(bundle),'--target',str(target),
          '--wait-pid',str(os.getpid()),'--restart',str(restart),'--original-package',str(Path(package).resolve())]
    if reopen:args+=['--reopen',str(reopen)]
    options={}
    if os.name=='nt':options['creationflags']=subprocess.CREATE_NO_WINDOW
    subprocess.Popen(args,cwd=helperdir,**options)
    return manifest['version']


HELPER_FILES=('updater.py','update.zip')   # what start_update puts in its Craft-update-xxxxxxxx folder


def cleanup_update_helpers(folder=None,age=86400):
    """0.19.9: the folders start_update leaves in the temporary folder (Craft-update-xxxxxxxx with the copy of
    updater.py and of the ZIP, about 9 MB each time) go once a day old, when they hold nothing else: no other
    file or folder, no link (called at the first start of each version). Returns the names of the folders removed."""
    import stat
    removed=[];limit=time.time()-age
    def plain(p,kind):
        st=os.lstat(p)   # not followed: a link or a junction (reparse point) is never a plain file or folder
        return kind(st.st_mode) and not stat.S_ISLNK(st.st_mode) and not getattr(st,'st_file_attributes',0)&0x400 and st.st_mtime<limit
    try:
        base=Path(folder) if folder else Path(tempfile.gettempdir())
        folders=[p for p in base.iterdir() if re.fullmatch(r'Craft-update-[a-z0-9_]{8}',p.name)]
    except OSError:return removed
    for p in folders:
        try:
            if not plain(p,stat.S_ISDIR):continue
            inside=list(p.iterdir())
            if any(q.name not in HELPER_FILES or not plain(q,stat.S_ISREG) for q in inside):continue
            for q in inside:q.unlink()
            p.rmdir();removed.append(p.name)
        except OSError:continue
    return removed


def show_error(message):
    if os.name=='nt':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None,str(message),'Mise à jour Craft',16)
    else:print(message,file=sys.stderr)


def read_development_bundle(source):
    """Recognize our old source distribution by both signed content hashes and layout."""
    source=Path(source)
    match=re.fullmatch(r'Craft_Base_Developpement_v(\d+\.\d+\.\d+)(?:\s*\(\d+\))?\.zip',source.name,re.I)
    if not match:raise ValueError('Archive de développement inconnue.')
    version=match[1];root='Craft_Base_'+version+'/'
    with zipfile.ZipFile(source) as z:
        infos=z.infolist();names=[q.filename for q in infos]
        if len(infos)>500 or len(names)!=len(set(names)) or sum(q.file_size for q in infos)>MAX_BYTES:raise ValueError('Archive de développement invalide.')
        for info in infos:
            name=info.filename
            if not name.startswith(root) or '..' in PurePosixPath(name).parts or '\\' in name or (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Chemin de développement invalide.')
            rel=name[len(root):]
            if rel.endswith('/'):continue
            allowed_root=rel in ('.gitignore','AGENTS.md','README.md','CODE_MAP.md','requirements-dev.txt','requirements-build-windows.txt')
            allowed_tree=any(rel.startswith(folder) for folder in ('app/','tests/','tools/','docs/','packaging/','branding/','dist/'))
            if not(allowed_root or allowed_tree):raise ValueError('Fichier personnel dans l’archive.')
            if Path(rel).suffix=='.patron' and Path(rel).name not in ('Base_Maro.patron','Base_Petite_Maroquinerie.patron','Exemple_porte_cartes.patron'):raise ValueError('Patron personnel dans l’archive.')
        manifest=parse_manifest(z.read(root+'app/'+MANIFEST))
        if manifest['version']!=version:raise ValueError('Versions incompatibles.')
        for name,digest in manifest['files'].items():
            if sha256(z.read(root+'app/'+name))!=digest:raise ValueError('Sources modifiées : '+name)
        nested=root+'dist/Craft_Mise_a_jour_v'+version+'.zip'
        with tempfile.TemporaryDirectory() as tmp:
            bundle=Path(tmp)/'verified.zip';bundle.write_bytes(z.read(nested));runtime,_=read_bundle(bundle)
        if runtime!=manifest:raise ValueError('Paquet intégré incompatible.')
    return manifest


def cleanup_packages(package,version,current=None):
    """Only verified, older Craft bundles alongside the successfully installed ZIP. 0.19.9: ``current``, its
    manifest when the caller has just verified it with read_bundle (the ZIP is not read a second time)."""
    package=Path(package).resolve();removed=[]
    try:
        if current is None:current,_=read_bundle(package)
        if current['version']!=version:return removed
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile):return removed
    for candidate in package.parent.glob('*.zip'):
        if candidate==package or candidate.is_symlink():continue
        if not re.fullmatch(r'Craft_(?:Mise_a_jour|Windows|Base_Developpement)_v\d+\.\d+(?:\.\d+)?(?:\s*\(\d+\))?\.zip',candidate.name,re.I):continue
        try:
            old=read_development_bundle(candidate) if candidate.name.lower().startswith('craft_base_developpement_') else read_bundle(candidate)[0]
            if version_tuple(old['version'])<version_tuple(version) or (old['version']==version and old['files']==current['files']):
                candidate.unlink();removed.append(candidate.name)
        except (OSError,ValueError,KeyError,zipfile.BadZipFile):continue
    return removed


def cleanup_download_packages(target):
    """Compatibility with old updater helpers: require the exact current ZIP first."""
    target=Path(target);version=current_version(target)
    directories=download_directories()   # 0.19.9: each folder once (it was often read twice)
    for folder in directories:
        packages=[p for p in folder.glob('Craft_Mise_a_jour_v'+version+'*.zip') if p.is_file() and not p.is_symlink() and re.fullmatch(r'Craft_Mise_a_jour_v'+re.escape(version)+r'(?:\s*\(\d+\))?\.zip',p.name,re.I)]
        def modified(package):
            try:return package.stat().st_mtime
            except OSError:return 0
        for package in sorted(packages,key=modified,reverse=True):
            try:
                manifest,payload=read_bundle(package)
                # A renamed or unrelated ZIP never authorizes cleanup.
                if manifest['version']!=version or not all((target/n).is_file() and sha256((target/n).read_bytes())==manifest['files'][n] for n in payload if Path(n).suffix!='.patron'):continue
                cleanup_packages(package,version,manifest);break   # 0.19.9: the ZIP just verified is not read again
            except (OSError,ValueError,KeyError,zipfile.BadZipFile):continue


def precompile(folder,pause=0.):
    """0.19.6: Craft's modules compiled ahead (Python's __pycache__, only those changed): the first start
    after an update no longer compiles them. ``pause``: seconds between two modules (in a thread while
    Craft is open, so that it stays fluid). Never fails."""
    import time,py_compile,importlib.util
    try:
        folder=Path(folder)
        for p in sorted(folder.glob('*.py')):
            if p.is_symlink():continue
            try:
                cached=Path(importlib.util.cache_from_source(str(p)))
                if cached.is_file():
                    data=cached.read_bytes()[:16];st=p.stat()
                    # the header (PEP 552): flags 0 (timestamp), the source's mtime and size
                    if len(data)==16 and int.from_bytes(data[4:8],'little')==0 and int.from_bytes(data[8:12],'little')==int(st.st_mtime)&0xFFFFFFFF and int.from_bytes(data[12:16],'little')==st.st_size&0xFFFFFFFF:continue
                py_compile.compile(str(p),doraise=True)
            except Exception:continue
            if pause:time.sleep(pause)
    except Exception:pass


def main(argv=None):
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--package');p.add_argument('--from-folder')
    p.add_argument('--target',required=True);p.add_argument('--wait-pid',type=int);p.add_argument('--restart');p.add_argument('--reopen');p.add_argument('--original-package')
    args=p.parse_args(argv)
    target=Path(args.target);backup=None
    try:
        if args.wait_pid:wait_exit(args.wait_pid)
        manifest,payload=read_bundle(args.from_folder or args.package,bool(args.from_folder))
        backup=apply_update(target,manifest,payload)
        if args.original_package:cleanup_packages(args.original_package,manifest['version'])
        precompile(target)   # 0.19.6: Craft starts without compiling its modules
        if args.restart:
            launch=[args.restart,'-E',str(target/'Lancer.pyw')]
            if args.reopen:launch+=['--reopen',args.reopen]
            subprocess.Popen(launch,cwd=target)
        else:print('Craft mis à jour : '+manifest['version']+'\nSauvegarde précédente : '+str(backup))
        return 0
    except Exception as exc:
        show_error(str(exc)+'\nVos préférences et patrons sont conservés.\n'+('Sauvegarde : '+str(backup) if backup else ''))
        return 1


if __name__=='__main__':sys.exit(main())
