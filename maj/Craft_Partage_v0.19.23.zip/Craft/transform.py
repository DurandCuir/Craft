"""0.17.0: Rotation and Échelle of any Craft shape, exact (arcs stay arcs). With Échelle,
texts, crans, arrows and drill marks keep their size and only follow their place; dimension
values are recomputed."""
import math,re
from geometry import path,clone
from cad import polygon
from curves import compound,parts_view,cubics,from_cubics
from precision_geometry import canonical


def affine(c,degrees=0.,factor=1.):
    """Visual anticlockwise rotation (Craft's y axis points down) and uniform scale about c."""
    t=math.radians(degrees);cs,sn=math.cos(t)*factor,math.sin(t)*factor
    def point(p):
        x,y=p[0]-c[0],p[1]-c[1];return c[0]+x*cs+y*sn,c[1]-x*sn+y*cs
    return point


def rigid(s):
    """Kept at their size by Échelle: they mark a place, they are not geometry to enlarge."""
    return bool(s.get('annotation') or s.get('is_notch') or s.get('filled') or s.get('drill'))


def reference(s):
    if s.get('drill'):return s['x']+s['w']/2,s['y']+s['h']/2
    # 0.19.9: a text placed by its centre (cote value, aligned text) keeps that point, not its box corner
    if s.get('annotation') and 'text_offset' in s:return s['x']+s['text_offset'][0],s['y']+s['text_offset'][1]
    return s['x'],s['y']


# 0.19.9: clone (marshal) instead of copy.deepcopy in this module: the same data, several times faster
# (the Rotation / Échelle preview transforms the whole selection at each mouse move).
def moved(s,dx,dy):
    q=clone(s);q['x']+=dx;q['y']+=dy;return q


def relabel(text,factor):
    """'100' → '120' for a 120 % scale; angles and anything else are kept."""
    if not text or text.endswith('°'):return text
    m=re.fullmatch(r'([^\d\-]*)(-?\d+(?:[.,]\d+)?)(.*)',text.strip())
    if not m:return text
    value=float(m[2].replace(',','.'))*factor;digits=f'{value:.2f}'.rstrip('0').rstrip('.')
    if ',' in m[2]:digits=digits.replace('.',',')
    return m[1]+digits+m[3]


def transform(s,c,degrees=0.,factor=1.):
    q=_transform(s,c,degrees,factor)
    if s.get('notches') and not rigid(s):_marks(q,s,c,degrees,factor)
    return q


def _marks(q,s,c,degrees,factor):
    """0.19.9: the crans kept inside a shape (``notches``: distances along its contour) stay at the same place of the
    piece: with Échelle their distance grew with nothing (at 200 % a cran 30 mm from the start stayed at 30 mm, so
    elsewhere on the piece), and a rectangle turned or rounded, or a circle turned, starts its contour elsewhere.
    Each cran is found again on the new contour, on the same side; a fixed direction turns; its size is kept."""
    from craft_tools import at_distance
    from precision_geometry import contour_location
    point=affine(c,degrees,factor);spin=affine((0,0),degrees);out=[]
    for m in clone(s['notches']):
        try:
            p,n=at_distance(s,m['distance']);target=point(p);d=m['distance']*factor   # the same place when the contour
            if math.dist(at_distance(q,d)[0],target)>.01:d=contour_location(q,target)[0]   # still starts there, else found
            _,n2=at_distance(q,d);v=spin(n)
            m['distance']=d;m['side']=m.get('side',1)*(1 if n2[0]*v[0]+n2[1]*v[1]>=0 else -1)
        except (ValueError,ZeroDivisionError,KeyError,IndexError):m['distance']=m['distance']*factor
        if m.get('direction'):m['direction']=list(spin(tuple(m['direction'])))
        out.append(m)
    q['notches']=out


def _transform(s,c,degrees=0.,factor=1.):
    if factor!=1 and rigid(s):
        ref=reference(s);target=affine(c,degrees,factor)(ref)
        q=transform(s,ref,degrees,1.);q=moved(q,target[0]-ref[0],target[1]-ref[1])
        if s.get('annotation') and s.get('dimension_group'):
            for key in ('label','name'):
                if key in q:q[key]=relabel(q[key],factor)
        return q
    point=affine(c,degrees,factor);turn=math.radians(degrees)
    if s.get('annotation'):
        # The text keeps its size; its box and offset turn around its anchor.
        q=clone(s);q['x'],q['y']=point((s['x'],s['y']));spin=affine((0,0),degrees)
        if s.get('points'):q['points']=[list(spin(tuple(p))) for p in s['points']]
        if 'text_offset' in s:q['text_offset']=list(spin(tuple(s['text_offset'])))
        q['text_angle']=s.get('text_angle',0)-degrees
        return q
    if s.get('components'):
        # 0.19.9: the children read without a deep copy (transform never changes what it is given)
        q=compound([transform(child,c,degrees,factor) for child in parts_view(s)],s['name'],s.get('closed',False))
        for key,value in s.items():
            if key not in q and key not in ('components',):q[key]=clone(value)
        return q
    if s.get('spline'):
        q=from_cubics([[point(p) for p in cubic] for cubic in cubics(s)],s.get('closed',False),s['name'])
        # 0.19.9: its points and end tangents follow (a spline through points stays editable by them)
        old=s['spline'];new=q['spline'];spin=affine((0,0),degrees)
        if old.get('fit'):new['fit']=[[x-q['x'],y-q['y']] for x,y in (point((s['x']+a,s['y']+b)) for a,b in old['fit'])]
        if old.get('tangents'):new['tangents']={end:list(spin(tuple(v))) for end,v in old['tangents'].items()}
        for key,value in old.items():
            if key not in new:new[key]=clone(value)
        return _keep(q,s)
    if s.get('ellipse'):
        q=clone(s);q['x'],q['y']=point((s['x'],s['y']));e=q['ellipse']
        e['rx']*=factor;e['ry']*=factor;e['angle']=e['angle']-turn;q['w']=s['w']*factor;q['h']=s['h']*factor;return q
    if s['kind']=='circle':
        r=s['w']/2;centre=point((s['x']+r,s['y']+r));q=clone(s);r*=factor;q.update(x=centre[0]-r,y=centre[1]-r,w=2*r,h=2*r);return q
    if s['kind']=='line':
        A,B=map(point,path(s)[0]);q=clone(s);q.update(x=A[0],y=A[1],w=B[0]-A[0],h=B[1]-A[1]);return q
    if s['kind']=='rect' and not s.get('r') and abs(degrees/90-round(degrees/90))<1e-9:
        pts=[point(p) for p in path(s)[0]];xs=[p[0] for p in pts];ys=[p[1] for p in pts]
        q=clone(s);q.update(x=min(xs),y=min(ys),w=max(xs)-min(xs),h=max(ys)-min(ys));return q
    native=canonical(s)
    pts=[(native['x']+x,native['y']+y) for x,y in native['points']]
    q=polygon([point(p) for p in pts],s['name'],bool(native.get('closed')))
    if native.get('bulges'):q['bulges']=list(native['bulges'])   # same orientation: same bulges
    return _keep(q,s)


def _keep(q,s):
    for key,value in s.items():
        if key not in q and key not in ('points','bulges','r','spline','closed'):q[key]=clone(value)
    return q   # 0.19.9: no inherit(): the loop has already copied all its keys (style, piece_id…)


def selection_reach(items,c):
    """Distance from the fixed point to the farthest point of the selection (100 % for Échelle)."""
    far=0.
    for s in items:
        if s.get('annotation'):pts=[(s['x'],s['y'])]
        else:
            try:pts=path(s)[0]
            except (KeyError,ValueError,TypeError):continue
        far=max([far]+[math.dist(p,c) for p in pts])
    return far
