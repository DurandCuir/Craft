"""Zones de préparation: the closed region around a click, like AutoCAD BOUNDARY / HATCH
« point intérieur ». Millimetres, standard library only.

The lines that can bound a zone (geometry.path: arcs, ovals and splines are sampled within
0.005 mm) are split at their crossings, ends closer than TOL are joined, dangling lines are
dropped, and the face of the resulting planar graph that holds the click is returned with
its islands. Only the lines near the click are used: the face lies inside the smallest
closed shape holding the click, or else inside the box of one group of touching lines."""
import math
from geometry import path,bounds
from entity_rules import geometry_entity

TOL=.02          # mm: ends, crossings and touching lines closer than this are joined
TOL2=TOL*TOL
_BAD=(ValueError,KeyError,TypeError,ZeroDivisionError,IndexError)


def boundary_entity(s):
    """Lines that bound zones: not crans, texts, cotes, drills, arrows nor the zones themselves."""
    if not geometry_entity(s):return False
    st=s.get('style')
    if isinstance(st,dict) and 'role' in st:return st['role']!='preparation'
    from craft_tools import PROFILES
    return PROFILES.get(s.get('profile','Dessin'),PROFILES['Dessin'])['role']!='preparation'


def region_at(items,p,scale=1.0):
    """Smallest closed region bounded by the drawing that holds p (mm), or None.

    Returns dict(points,holes,area,perimeter,width,bbox). points: the outer boundary,
    counter-clockwise in model axes (positive shoelace area, so clockwise on the y-down
    canvas), no repeated last point. holes: the islands inside it, clockwise (usually []).
    area excludes the holes, perimeter includes them. width: w of a band A = w·L,
    P = 2L + 2w (smaller root; sqrt(A) when there is none), to 0.1 mm. bbox: (x0,y0,x1,y1).
    scale (px per mm, as for the pick helpers) is accepted for the canvas; the region
    never depends on the zoom."""
    p=(float(p[0]),float(p[1]));x,y=p;shapes=[];holder=None
    for s in items:
        if not boundary_entity(s):continue
        try:b=bounds([s])
        except _BAD:continue
        shapes.append((b,s))
        if b[0]<=x<=b[2] and b[1]<=y<=b[3]:
            pts,closed=path(s);area=(b[2]-b[0])*(b[3]-b[1])
            if closed and len(pts)>2 and (holder is None or area<holder[0]) and _inside(pts,p):holder=(area,b)
    # A closed shape holding p holds its whole region; otherwise the region is bounded by one
    # group of touching lines, whose box holds p (tried smallest first).
    boxes=[holder[1]] if holder else _groups(shapes,p)
    for b in boxes:
        m=4*TOL;W=(b[0]-m,b[1]-m,b[2]+m,b[3]+m)
        found=_region([s for c,s in shapes if c[0]<=W[2] and c[2]>=W[0] and c[1]<=W[3] and c[3]>=W[1]],p,W)
        if found is None:
            if holder:return None
            continue
        r=found['bbox']
        # Lines outside the window cannot cut a region that stays inside it.
        if holder or (r[0]>=b[0]-2*TOL and r[1]>=b[1]-2*TOL and r[2]<=b[2]+2*TOL and r[3]<=b[3]+2*TOL):return found
    return None


def _inside(pts,p):
    x,y=p;result=False;a=pts[-1]
    for b in pts:
        if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:result=not result
        a=b
    return result


def _boxes(s,box):
    """Boxes (grown by TOL) of the segments of s that reach box."""
    x0,y0,x1,y1=box;pts,closed=path(s);out=[]
    for a,b in zip(pts,pts[1:]+pts[:1] if closed else pts[1:]):
        lx,hx=(a[0],b[0]) if a[0]<b[0] else (b[0],a[0]);ly,hy=(a[1],b[1]) if a[1]<b[1] else (b[1],a[1])
        if lx<=x1 and hx>=x0 and ly<=y1 and hy>=y0:out.append((lx-TOL,ly-TOL,hx+TOL,hy+TOL))
    return out


def _linked(s,t,a,b):
    """s and t (boxes a and b, grown by TOL) may touch: some of their segments come close
    where the boxes overlap (a piece inside a frame or next to another one does not)."""
    box=(max(a[0],b[0]),max(a[1],b[1]),min(a[2],b[2]),min(a[3],b[3]));one=_boxes(s,box)
    if not one:return False
    two=_boxes(t,box)
    return any(p[0]<=q[2] and q[0]<=p[2] and p[1]<=q[3] and q[1]<=p[3] for p in one for q in two)


def _join(shapes,p,close):
    """Groups of shapes whose boxes overlap (and, with close, whose lines come close),
    as (box, shapes) for the groups whose box holds p."""
    n=len(shapes);parent=list(range(n))
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    box=[(b[0]-TOL,b[1]-TOL,b[2]+TOL,b[3]+TOL) for b,_ in shapes];order=sorted(range(n),key=lambda i:box[i][0])
    for k in range(n):
        i=order[k];a=box[i]
        for kk in range(k+1,n):
            j=order[kk];b=box[j]
            if b[0]>a[2]:break
            if b[1]>a[3] or b[3]<a[1]:continue
            ri,rj=find(i),find(j)
            if ri!=rj and (not close or _linked(shapes[i][1],shapes[j][1],a,b)):parent[ri]=rj
    groups={}
    for i in range(n):
        r=find(i);b=shapes[i][0];g=groups.get(r)
        if g is None:groups[r]=[b,[shapes[i]]]
        else:c=g[0];g[0]=(min(c[0],b[0]),min(c[1],b[1]),max(c[2],b[2]),max(c[3],b[3]));g[1].append(shapes[i])
    x,y=p
    return [g for g in groups.values() if g[0][0]<=x<=g[0][2] and g[0][1]<=y<=g[0][3]]


def _groups(shapes,p):
    """Boxes of the groups of touching lines that hold p, smallest first. Boxes that merely
    overlap are sorted out first (cheap), then lines that really come close."""
    found=[box for _,group in _join(shapes,p,False) for box,_ in _join(group,p,True)]
    return sorted(found,key=lambda g:(g[2]-g[0])*(g[3]-g[1]))


def _region(shapes,p,W):
    # Work relative to p: the click is (0,0) and big drawings keep their precision.
    ox,oy=p;x0,y0,x1,y1=W[0]-ox,W[1]-oy,W[2]-ox,W[3]-oy;X=[];Y=[];S=[];paths=[]
    for s in shapes:
        try:paths.append(path(s))
        except _BAD:continue
    paths.sort(key=lambda q:not q[1])        # closed contours first: their points win the joins
    for pts,closed in paths:
        n=len(pts);ids={}
        for k in range(n if closed and n>2 else n-1):
            a=pts[k];b=pts[k+1] if k+1<n else pts[0]
            ax,ay,bx,by=a[0]-ox,a[1]-oy,b[0]-ox,b[1]-oy
            if ax<x0 and bx<x0 or ax>x1 and bx>x1 or ay<y0 and by<y0 or ay>y1 and by>y1 or ax==bx and ay==by:continue
            i=ids.get(k)
            if i is None:i=ids[k]=len(X);X.append(ax);Y.append(ay)
            kb=(k+1)%n;j=ids.get(kb)
            if j is None:j=ids[kb]=len(X);X.append(bx);Y.append(by)
            S.append((i,j))
    m=len(S)
    if m<2:return None
    parent=list(range(len(X)))
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    def union(i,j):
        i,j=find(i),find(j)
        if i!=j:parent[max(i,j)]=min(i,j)
    D=[];lo=[]
    for i,j in S:
        ax,ay,bx,by=X[i],Y[i],X[j],Y[j];dx,dy=bx-ax,by-ay;D.append((ax,ay,bx,by,dx,dy,math.hypot(dx,dy)));lo.append(min(ax,bx))
    ev=[None]*m
    def mark(k,t,q):
        e=ev[k]
        if e is None:ev[k]=[(t,q)]
        else:e.append((t,q))
    def near(q,k):
        # An end within TOL of segment k: k passes through it (T-junction, overlap, tiny gap).
        ax,ay,bx,by,dx,dy,L=D[k];qx,qy=X[q],Y[q];t=((qx-ax)*dx+(qy-ay)*dy)/(L*L)
        t=0. if t<0 else 1. if t>1 else t;ex,ey=ax+t*dx-qx,ay+t*dy-qy
        if ex*ex+ey*ey>TOL2:return
        if t*L<=TOL:union(q,S[k][0])
        elif (1-t)*L<=TOL:union(q,S[k][1])
        else:
            # The point moves onto k (a line end along itself, a curve vertex by < TOL), so
            # that no long line is tilted through it.
            if find(q)==q:X[q]=ax+t*dx;Y[q]=ay+t*dy
            mark(k,t,q)
    half=TOL/2;order=sorted(range(m),key=lo.__getitem__)
    for o in range(m):
        k=order[o];ax,ay,bx,by,ux,uy,Lk=D[k];i0,i1=S[k]
        kx0=lo[k]-TOL;kx1=max(ax,bx)+TOL;ky0=min(ay,by)-TOL;ky1=max(ay,by)+TOL
        for oo in range(o+1,m):
            l=order[oo]
            if lo[l]>kx1:break
            cx,cy,ex,ey,vx,vy,Ll=D[l]
            if cy<ky0 and ey<ky0 or cy>ky1 and ey>ky1:continue
            j0,j1=S[l]
            if j0!=i0 and j0!=i1 and kx0<=cx<=kx1 and ky0<=cy<=ky1:near(j0,k)
            if j1!=i0 and j1!=i1 and kx0<=ex<=kx1 and ky0<=ey<=ky1:near(j1,k)
            if i0!=j0 and i0!=j1 and min(cx,ex)-TOL<=ax<=max(cx,ex)+TOL and min(cy,ey)-TOL<=ay<=max(cy,ey)+TOL:near(i0,l)
            if i1!=j0 and i1!=j1 and min(cx,ex)-TOL<=bx<=max(cx,ex)+TOL and min(cy,ey)-TOL<=by<=max(cy,ey)+TOL:near(i1,l)
            # Proper crossing away from the four ends (the ends are handled just above).
            den=ux*vy-uy*vx
            if abs(den)<=1e-9*Lk*Ll:continue
            wx,wy=cx-ax,cy-ay;t=(wx*vy-wy*vx)/den;u=(wx*uy-wy*ux)/den
            if half<t*Lk<Lk-half and half<u*Ll<Ll-half:
                q=len(X);X.append(ax+t*ux);Y.append(ay+t*uy);parent.append(q);mark(k,t,q);mark(l,u,q)
    # Join every point to the points closer than TOL (grid of TOL cells).
    cells={};inv=1/TOL
    for q in range(len(X)):
        qx,qy=X[q],Y[q];gx,gy=math.floor(qx*inv),math.floor(qy*inv)
        for cx in (gx-1,gx,gx+1):
            for cy in (gy-1,gy,gy+1):
                for r in cells.get((cx,cy),()):
                    if (qx-X[r])**2+(qy-Y[r])**2<=TOL2:union(q,r)
        cell=cells.get((gx,gy))
        if cell is None:cells[gx,gy]=[q]
        else:cell.append(q)
    adj={}
    for k in range(m):
        e=ev[k]
        if e:e.sort();seq=[find(S[k][0])]+[find(q) for _,q in e]+[find(S[k][1])]
        else:seq=(find(S[k][0]),find(S[k][1]))
        for a,b in zip(seq,seq[1:]):
            if a!=b:adj.setdefault(a,set()).add(b);adj.setdefault(b,set()).add(a)
    # Dangling lines (stubs, overshoots, open construction lines) bound nothing.
    stack=[v for v,w in adj.items() if len(w)<2]
    while stack:
        v=stack.pop();w=adj.pop(v,None)
        for u in w or ():
            nu=adj[u];nu.discard(v)
            if len(nu)<2:stack.append(u)
    return _faces(adj,X,Y,p) if adj else None


def _faces(adj,X,Y,p):
    order={};pos={}
    for v,w in adj.items():
        xv,yv=X[v],Y[v];ws=sorted(w,key=lambda u:math.atan2(Y[u]-yv,X[u]-xv));order[v]=ws
        for k,u in enumerate(ws):pos[v,u]=k
    # Each walk keeps its face on its left (next edge = the most clockwise turn): bounded
    # faces run counter-clockwise (area > 0), the outline of each group of lines clockwise.
    seen=set();walks=[]
    for v0,w in adj.items():
        for u0 in w:
            if (v0,u0) in seen:continue
            a,b=v0,u0;cyc=[]
            while (a,b) not in seen:
                seen.add((a,b));cyc.append(a);a,b=b,order[b][pos[b,a]-1]
            xs=[X[v] for v in cyc];ys=[Y[v] for v in cyc]
            walks.append((sum(xs[i-1]*ys[i]-xs[i]*ys[i-1] for i in range(len(cyc)))/2,min(xs),min(ys),max(xs),max(ys),cyc,xs,ys))
    # The click is (0,0); the smallest bounded face around it is its region.
    best=None
    for wk in walks:
        if wk[0]>0 and wk[1]<=0<=wk[3] and wk[2]<=0<=wk[4] and (best is None or wk[0]<best[0]) and _inside(list(zip(wk[6],wk[7])),(0.,0.)):best=wk
    if best is None:return None
    holes=[];negatives=[wk for wk in walks if wk[0]<0]
    if len(negatives)>1:
        # Islands: other groups of lines inside the region, not nested in a smaller face.
        comp={}
        for v in adj:
            if v in comp:continue
            comp[v]=v;stack=[v]
            while stack:
                for u in adj[stack.pop()]:
                    if u not in comp:comp[u]=v;stack.append(u)
        A,a,b,c,d=best[:5];cf=comp[best[5][0]];poly=list(zip(best[6],best[7]))
        for wk in negatives:
            cn=comp[wk[5][0]];q=(wk[6][0],wk[7][0])
            if cn==cf or wk[1]<a or wk[2]<b or wk[3]>c or wk[4]>d or not _inside(poly,q):continue
            if any(0<o[0]<A and comp[o[5][0]] not in (cf,cn) and o[1]<=q[0]<=o[3] and o[2]<=q[1]<=o[4] and _inside(list(zip(o[6],o[7])),q) for o in walks):continue
            holes.append(wk[5])
    loops=[[(X[v],Y[v]) for v in loop] for loop in _loops(best[5])]
    outer=max(loops,key=_area);rings=[_clean(outer)]+[_clean(l) for l in loops if l is not outer]
    rings+=[_clean([(X[v],Y[v]) for v in loop]) for h in holes for loop in _loops(h)]
    area=sum(_area(r) for r in rings);perimeter=sum(math.dist(r[i-1],r[i]) for r in rings for i in range(len(r)))
    half=perimeter/2;disc=half*half-4*area
    width=2*area/(half+math.sqrt(disc)) if disc>=0 else math.sqrt(max(area,0))
    ox,oy=p;moved=[[(x+ox,y+oy) for x,y in r] for r in rings];xs=[q[0] for q in moved[0]];ys=[q[1] for q in moved[0]]
    return dict(points=moved[0],holes=moved[1:],area=area,perimeter=perimeter,width=round(width,1),bbox=(min(xs),min(ys),max(xs),max(ys)))


def _area(pts):return sum(pts[i-1][0]*pts[i][1]-pts[i][0]*pts[i-1][1] for i in range(len(pts)))/2


def _loops(cyc):
    """Split a walk at the lines it runs along twice (bridges to islands): one loop each."""
    n=len(cyc);half=[(cyc[i-1],cyc[i]) for i in range(1,n)]+[(cyc[-1],cyc[0])];present=set(half)
    if not any((b,a) in present for a,b in half):return [cyc]
    stack=[[]];out=[];opened=set()
    for a,b in half:
        if (b,a) not in present:stack[-1].append(a)
        elif (b,a) in opened and len(stack)>1:out.append(stack.pop())
        else:opened.add((a,b));stack.append([])
    return [loop for loop in out+stack if len(loop)>2]


def _clean(pts):
    """Drop the points where the boundary goes straight on (splits left by removed lines)."""
    i=0
    while len(pts)>3 and i<len(pts):
        a,b,c=pts[i-1],pts[i],pts[(i+1)%len(pts)];ux,uy=b[0]-a[0],b[1]-a[1];vx,vy=c[0]-b[0],c[1]-b[1]
        if abs(ux*vy-uy*vx)<=1e-9*math.hypot(ux+vx,uy+vy) and ux*vx+uy*vy>=0:pts.pop(i);i=max(i-1,0)
        else:i+=1
    return pts
