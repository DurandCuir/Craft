"""Craft construction metadata, offsets, assembly marks, and dimension graphics."""
import math,copy,uuid
from geometry import path,number,clone,segments_walk
from cad import polygon,shape,project,segment_intersection

PROFILES={
 'Dessin':dict(color='auto',width=.2,dash=[],role='drawing'),
 'Couture':dict(color='auto',width=.25,dash=[3,2],role='seam'),
 'Coupe extérieure':dict(color='#ff3030',width=.25,dash=[],role='external'),
 'Coupe intérieure':dict(color='#142e90',width=.25,dash=[],role='internal'),
 'Aide':dict(color='auto',width=.15,dash=[6,2,1,2],role='guide')}

def style(s):
    # 0.17.0: called for every line at every redraw; a plain copy (the dash list copied) instead of
    # a deep copy.
    d=dict(PROFILES.get(s.get('profile','Dessin'),PROFILES['Dessin']));d.update(s.get('style',{}))
    if isinstance(d.get('dash'),list):d['dash']=list(d['dash'])
    return d


def segments(s):
    pts,closed=path(s);return list(zip(pts,pts[1:]+pts[:1] if closed else pts[1:]))


def perimeter(s):return segments_walk(s)[1]   # 0.19.16: once per contour (the same sum, in the same order)


def locate(s,p):
    best=None;travel=0
    for a,b in segments(s):
        q=project(p,a,b);dist=math.dist(q,p)
        if best is None or dist<best[0]:best=(dist,travel+math.dist(a,q),q)
        travel+=math.dist(a,b)
    if best is None:raise ValueError('Contour vide.')
    return best[1],best[2]


def at_distance(s,d):
    segs,total,closed=segments_walk(s)   # 0.19.16: the segments and the length kept per contour
    if total<1e-8:raise ValueError('Contour sans longueur.')
    if closed:d%=total
    elif not -1e-6<=d<=total+1e-6:raise ValueError('Le cran dépasse la longueur de la pièce cible.')
    d=max(0,min(d,total))
    for a,b in segs:
        n=math.dist(a,b)
        if n<1e-9:continue
        if d<=n+1e-8:return (a[0]+(b[0]-a[0])*d/n,a[1]+(b[1]-a[1])*d/n),(-(b[1]-a[1])/n,(b[0]-a[0])/n)
        d-=n
    a,b=segs[-1];n=math.dist(a,b);return b,(-(b[1]-a[1])/n,(b[0]-a[0])/n)


def interior_side(s):
    """Sign of the local left normal pointing into a simple closed contour."""
    pts,closed=path(s)
    if not closed:raise ValueError('Le choix intérieur / extérieur nécessite une pièce fermée.')
    area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1]))
    if abs(area)<1e-8:raise ValueError('Le contour fermé ne délimite pas de surface.')
    return 1 if area>0 else -1


def notch_local_side(s,choice):
    if choice in ('inside','outside'):
        return interior_side(s)*(1 if choice=='inside' else -1)
    return choice  # Open lines retain a local left/right choice.


def notch_shapes(s):
    result=[]
    for mark in s.get('notches',[]):
        p,n=at_distance(s,mark['distance']);depth=mark.get('depth',3)*mark.get('side',1)
        if mark.get('direction'):
            n=tuple(mark['direction']);depth=mark.get('depth',3)
        # 0.18.1: the Mozart cran's stem is cut (``gap``, fractions of the depth): the stem is the
        # first stroke, its end the fourth, after the bar and the cap.
        gap=mark.get('gap') if mark.get('kind')=='cross' and mark.get('cap_width') else None
        stem=gap[0] if gap else 1.
        q=shape('line','Cran',*p,n[0]*depth*stem,n[1]*depth*stem)
        q['style']=dict(color='auto',width=.2,dash=[],role='notch');result.append(q)
        if mark.get('kind') in ('t','cross'):
            factor=.5 if mark.get('kind')=='cross' else 1
            tip=(p[0]+n[0]*depth*factor,p[1]+n[1]*depth*factor);w=mark.get('width',2)/2;tangent=(n[1],-n[0])
            cross=shape('line','Cran T',tip[0]-tangent[0]*w,tip[1]-tangent[1]*w,2*tangent[0]*w,2*tangent[1]*w);cross['style']=clone(q['style']);result.append(cross)
            if mark.get('cap_width'):
                tip=(p[0]+n[0]*depth,p[1]+n[1]*depth);w=mark['cap_width']/2
                cap=shape('line','Extrémité du cran',tip[0]-tangent[0]*w,tip[1]-tangent[1]*w,2*tangent[0]*w,2*tangent[1]*w);cap['style']=clone(q['style']);result.append(cap)
        if gap:
            tail=shape('line','Cran',p[0]+n[0]*depth*gap[1],p[1]+n[1]*depth*gap[1],n[0]*depth*(1-gap[1]),n[1]*depth*(1-gap[1]))
            tail['style']=clone(q['style']);result.append(tail)
    return result


def copy_notches(source,target,start_a,start_b,reverse=False):
    origin_a=locate(source,start_a)[0];origin_b=locate(target,start_b)[0];total=perimeter(source)
    copied=[]
    for mark in source.get('notches',[]):
        d=mark['distance']-origin_a
        if path(source)[1]:d%=total
        if d<-.001:raise ValueError('Choisissez le départ avant les crans source.')
        dest=origin_b+(-d if reverse else d)
        at_distance(target,dest)
        copied.append(dict(copy.deepcopy(mark),distance=dest%perimeter(target) if path(target)[1] else dest))
    if not copied:raise ValueError('La pièce source ne possède pas de crans.')
    return copied


def annotation(text,p,height=3):
    # A bounding box aids picking and physical export framing, not a visible path.
    s=polygon([p,(p[0]+max(1,len(text))*height*.6,p[1]+height)],text[:200],False)
    s.update(annotation=True,label=text,text_height=height);return s


def annotation_baseline(s):
    if 'text_offset' in s:dx,dy=s['text_offset']
    else:
        theta=math.radians(s.get('text_angle',0));height=s.get('text_height',3)
        dx,dy=-height*math.sin(theta),height*math.cos(theta)
    return s['x']+dx,s['y']+dy


def text_bundle(p,runs,angle=0,identification=None):
    width=max(r.get('dx',0)+len(r['text'])*r['height']*.65 for r in runs)
    height=max(r['dy']+r['height']*1.3 for r in runs)
    theta=math.radians(angle);c,s=math.cos(theta),math.sin(theta)
    pts=[(p[0]+x*c-y*s,p[1]+x*s+y*c) for x,y in [(0,0),(width,0),(width,height),(0,height)]]
    result=polygon(pts,'Identification',True)
    result.update(annotation=True,label=' / '.join(r['text'] for r in runs),text_height=runs[0]['height'],text_runs=clone(runs),text_angle=angle)
    if identification is not None:result['identification']=clone(identification)
    return result


def aligned_annotation(text,center,angle,height=5):
    if angle>90:angle-=180
    if angle< -90:angle+=180
    half=max(1,len(text))*height*.3;theta=math.radians(angle)
    ux,uy=math.cos(theta),math.sin(theta);vx,vy=-uy,ux
    corners=[(center[0]+ux*xx+vx*yy,center[1]+uy*xx+vy*yy) for xx,yy in [(-half,-height/2),(half,-height/2),(half,height/2),(-half,height/2)]]
    label=polygon(corners,text,True);label.update(annotation=True,label=text,text_height=height,text_angle=angle,text_offset=[center[0]-label['x'],center[1]-label['y']])
    return label


# 0.16.27: dimension sizes in drawing millimetres, a middle ground for the base plan
# (readable when one column fills the screen); text written along the dimension line.
COTE_TEXT=8.0
COTE_ARROW=6.0
COTE_GAP=COTE_TEXT*1.0


def cote_label(text,point,angle):
    """Dimension value centred beside `point`, written along `angle` (degrees, world),
    on the upper side of the dimension line."""
    if angle>90:angle-=180
    if angle< -90:angle+=180
    theta=math.radians(angle)
    return aligned_annotation(text,(point[0]+math.sin(theta)*COTE_GAP,point[1]-math.cos(theta)*COTE_GAP),angle,COTE_TEXT)


def dimensions(a,b,label_pos,text):
    dx,dy=b[0]-a[0],b[1]-a[1];length=math.hypot(dx,dy)
    if length<1e-8:raise ValueError('Les points de mesure sont confondus.')
    nx,ny=-dy/length,dx/length;off=(label_pos[0]-a[0])*nx+(label_pos[1]-a[1])*ny
    A=(a[0]+nx*off,a[1]+ny*off);B=(b[0]+nx*off,b[1]+ny*off)
    lines=[shape('line','Cote',*p,q[0]-p[0],q[1]-p[1]) for p,q in [(a,A),(A,B),(b,B)]]
    size=min(COTE_ARROW,length*.2)
    for origin,sign in ((A,1),(B,-1)):
        base=(origin[0]+sign*dx/length*size,origin[1]+sign*dy/length*size)
        arrow=polygon([origin,(base[0]+nx*size*.45,base[1]+ny*size*.45),(base[0]-nx*size*.45,base[1]-ny*size*.45)],'Flèche cote',True);arrow['filled']=True;lines.append(arrow)
    lines.append(cote_label(text,((A[0]+B[0])/2,(A[1]+B[1])/2),math.degrees(math.atan2(dy,dx))))
    group=uuid.uuid4().hex
    for s in lines:s['dimension_group']=group;s['style']=dict(color='auto',width=.15,dash=[],role='dimension')
    return lines


def offset(s,d,point=None,edge_only=False):
    d=number(d)
    if abs(d)<1e-8:raise ValueError('Distance de décalage nulle.')
    if s['kind']=='circle':
        r=s['w']/2+d
        if r<=0:raise ValueError('Le rayon devient nul ou négatif.')
        q=copy.deepcopy(s);q.update(x=s['x']-d,y=s['y']-d,w=r*2,h=r*2);q.pop('notches',None);return q
    if edge_only and s['kind']=='rect' and s.get('r',0)>0 and point is not None:
        x,y,w,h,r=[s[k] for k in ('x','y','w','h','r')]
        corners=[(x+w-r,y+r,-90),(x+w-r,y+h-r,0),(x+r,y+h-r,90),(x+r,y+r,180)]
        for cx,cy,start in corners:
            px,py=point
            corner=(start==-90 and px>=cx and py<=cy) or (start==0 and px>=cx and py>=cy) or (start==90 and px<=cx and py>=cy) or (start==180 and px<=cx and py<=cy)
            if corner:
                new_r=r-d
                if new_r<=0:raise ValueError('Le décalage annule le rayon du coin.')
                return polygon([(cx+new_r*math.cos(math.radians(start+i*90/48)),cy+new_r*math.sin(math.radians(start+i*90/48))) for i in range(49)],'Arc décalé',False)
    segs=segments(s)
    if edge_only:
        a,b=min(segs,key=lambda ab:math.dist(project(point,*ab),point));segs=[(a,b)]
    shifted=[]
    for a,b in segs:
        n=math.dist(a,b)
        if n<1e-8:continue
        ux,uy=-(b[1]-a[1])/n,(b[0]-a[0])/n
        shifted.append(((a[0]+ux*d,a[1]+uy*d),(b[0]+ux*d,b[1]+uy*d)))
    if not shifted:raise ValueError('Contour non décalable.')
    if len(shifted)==1:
        a,b=shifted[0];return shape('line','Décalage',*a,b[0]-a[0],b[1]-a[1])
    closed=path(s)[1] and not edge_only;pts=[]
    def intersect(one,two):
        a,b=one;c,e=two;u=(b[0]-a[0],b[1]-a[1]);v=(e[0]-c[0],e[1]-c[1]);den=u[0]*v[1]-u[1]*v[0]
        if abs(den)<1e-9:return b
        t=((c[0]-a[0])*v[1]-(c[1]-a[1])*v[0])/den
        p=(a[0]+u[0]*t,a[1]+u[1]*t)
        if math.dist(p,b)>abs(d)*20+1:raise ValueError('Angle trop aigu pour ce décalage.')
        return p
    if not closed:pts.append(shifted[0][0])
    for i in range(len(shifted) if closed else len(shifted)-1):pts.append(intersect(shifted[i],shifted[(i+1)%len(shifted)]))
    if not closed:pts.append(shifted[-1][1])
    q=polygon(pts,'Décalage',closed);test=segments(q)
    for i,(a,b) in enumerate(test):
        for j,(c,e) in enumerate(test[i+2:],i+2):
            if closed and i==0 and j==len(test)-1:continue
            if segment_intersection(a,b,c,e):raise ValueError('Ce décalage se croise ; réduisez la distance.')
    return q


def portion(s,a,b):
    da,pa=locate(s,a);db,pb=locate(s,b);pts=[pa];travel=0;total=perimeter(s)
    if path(s)[1] and db<da:db+=total
    if db<da:da,db=db,da;pa,pb=pb,pa;pts=[pa]
    for cycle in range(2 if db>total else 1):
        travel=cycle*total
        for p,q in segments(s):
            travel+=math.dist(p,q)
            if da+1e-7<travel<db-1e-7:pts.append(q)
    pts.append(pb);return polygon(pts,'Portion',False)


# 0.18.1: the cran of Mozart (block PitTacCT): 18 mm long, a bar of a third of the length at
# mid-length, a cap of a quarter at the end, the stem cut from 2/3 to 19/24 of the length.
CRAN_GAP=(2/3,19/24)
CRAN=dict(depth=18.,kind='cross',width=6.,cap_width=4.5,gap=list(CRAN_GAP))
# Sizes the Cran tool gave before: 15 mm (until 0.17), 12 mm (0.18.0), 14,4 mm (Mozart -20 %, 0.18.0).
OLD_CRAN_DEPTHS=(12.,14.4,15.)


def cran_settings(depth):
    """A cran of ``depth`` mm with the proportions of Mozart's cran."""
    return dict(depth=depth,kind='cross',width=depth/3,cap_width=depth/4,gap=list(CRAN_GAP))


def new_cran(distance,side):
    """The settings of a cran placed with the Cran tool."""
    return dict(distance=distance,side=side,**copy.deepcopy(CRAN))


def cran_form(strokes):
    """Foot, unit direction and shape of a cran read from its strokes (stem first, then bar, cap
    and the end of a cut stem): dict(foot, direction, depth, kind, width, cap_width, gap)."""
    pts=path(strokes[0])[0] if strokes else []
    if len(pts)<2:return None
    a,b=pts[0],pts[-1];stem=math.dist(a,b)
    if stem<1e-6:return None
    u=((b[0]-a[0])/stem,(b[1]-a[1])/stem)
    along=lambda q:(q[0]-a[0])*u[0]+(q[1]-a[1])*u[1]
    depth=max([stem]+[along(q) for t in strokes[1:] for q in path(t)[0]])
    form=dict(foot=a,direction=u,depth=depth)
    if len(strokes)>1:
        q=path(strokes[1])[0];middle=((q[0][0]+q[-1][0])/2,(q[0][1]+q[-1][1])/2)
        form.update(kind='cross' if len(strokes)>2 or math.dist(a,middle)<depth*.75 else 't',width=perimeter(strokes[1]))
    if len(strokes)>2:form['cap_width']=perimeter(strokes[2])
    if len(strokes)>3 and depth>1e-6:
        tail=path(strokes[3])[0];form['gap']=[stem/depth,min(along(tail[0]),along(tail[-1]))/depth]
    return form


def reshaped_cran(cran,depth=None):
    """0.18.1: a cran drawn again with Mozart's proportions (``depth`` mm, else its own length),
    at the same foot and in the same direction; the cran itself when it is not a cross cran."""
    from curves import parts
    strokes=parts(cran) if cran.get('components') else [cran]
    form=cran_form(strokes) if cran.get('is_notch') else None
    if not form or form.get('kind')!='cross' or not form.get('cap_width'):return cran
    (x,y),(ux,uy)=form['foot'],form['direction']
    # A 2 mm line across the foot whose left normal is the cran's direction.
    host=shape('line','Pied',x-uy,y+ux,2*uy,-2*ux)
    new=standalone_notch(host,dict(distance=1.,side=1,**cran_settings(depth or form['depth'])))
    for key,value in cran.items():
        if key not in ('components','points','x','y','w','h','kind','closed','bulges'):new[key]=clone(value)
    return new


def standalone_notch(host,mark):
    """A cran is a single selectable object with three independent-colour strokes."""
    from curves import compound
    # 0.19.9: a plain copy of the piece (its strokes are only read from it): a grip moved on a piece of 200
    # points carrying 60 crans copied the whole piece 60 times at each move of the mouse.
    source=dict(host);source['notches']=[clone(mark)]   # 0.19.16: clone (marshal), several times faster than deepcopy
    strokes=notch_shapes(source);fixed=dict(color='#c696cf',width=.18,dash=[],role='notch')
    for stroke in strokes:stroke['style']=dict(fixed,dash=[]);stroke['is_notch']=True
    result=compound(strokes,'Cran',False);result['style']=fixed;result['is_notch']=True
    return result


def cran_mark(cran,host):
    """0.16.30: where and how a cran sits on its piece (distance along the contour, depth,
    side, kind, widths), read back from its strokes; None when it is not on that contour."""
    from curves import parts
    strokes=parts(cran) if cran.get('components') else [cran]
    if not cran.get('is_notch') or not strokes:return None
    form=cran_form(strokes)
    if form is None:return None
    a=form['foot'];u=form['direction']
    try:
        d,projection=locate(host,a)
        if math.dist(a,projection)>.1:return None
        _,normal=at_distance(host,d)
    except (ValueError,ZeroDivisionError):return None
    mark=dict(distance=d,depth=form['depth'],side=1 if u[0]*normal[0]+u[1]*normal[1]>=0 else -1)
    for key in ('kind','width','cap_width','gap'):
        if key in form:mark[key]=form[key]
    return mark


def rebuilt_cran(cran,host,mark):
    """The same cran rebuilt on its piece with `mark` (new place, depth or side)."""
    new=standalone_notch(host,mark)
    for key in ('owner_id','style','profile'):
        if key in cran:new[key]=copy.deepcopy(cran[key])
    return new


def along_contour(host,distance):
    """A distance kept on the contour: it goes round a closed piece, stops at a line's ends."""
    total=perimeter(host)
    return distance%total if path(host)[1] else max(0.,min(total,distance))


def cran_host(items,cran):
    """Index of the piece carrying a cran: its owner, else the contour through its foot.
    0.18.1: a cran of a piece to recut belongs to its précoupe but stands on the inner contour:
    the contour through its foot is then looked for."""
    from curves import parts
    from entity_rules import geometry_entity
    strokes=parts(cran) if cran.get('components') else [cran]
    pts=path(strokes[0])[0] if strokes else []
    owner=cran.get('owner_id')
    if owner:
        for j,s in enumerate(items):
            if s.get('piece_id')==owner and not s.get('is_notch'):
                try:
                    if not pts or math.dist(locate(s,pts[0])[1],pts[0])<=.1:return j
                except (ValueError,ZeroDivisionError):return j
                break
    if not pts:return None
    best=None
    from geometry import near_box
    for j,s in enumerate(items):
        if s is cran or not geometry_entity(s):continue
        if not near_box(s,pts[0],.1):continue   # 0.19.9: only contours whose box is at hand (each copied cran looked at all)
        try:d=math.dist(locate(s,pts[0])[1],pts[0])
        except (ValueError,ZeroDivisionError):continue
        if d<=.1 and (best is None or d<best[0]):best=(d,j)
    return best[1] if best else None


def linear_cote(members):
    """0.16.30: the parts of a straight cote (dimension line, the two extension lines from
    the measured points, arrows, value) as indexes into `members`; None for other cotes."""
    lines=[k for k,s in enumerate(members) if s.get('kind')=='line' and s.get('name')=='Cote' and not s.get('annotation')]
    arrows=[k for k,s in enumerate(members) if s.get('filled')]
    labels=[k for k,s in enumerate(members) if s.get('annotation')]
    if len(members)!=6 or len(lines)!=3 or len(arrows)!=2 or len(labels)!=1:return None
    ends={k:path(members[k])[0] for k in lines}
    for k in lines:
        A,B=ends[k][0],ends[k][-1]
        if math.dist(A,B)<1e-9:continue
        others=[j for j in lines if j!=k]
        at_a=[j for j in others if math.dist(ends[j][-1],A)<1e-6];at_b=[j for j in others if math.dist(ends[j][-1],B)<1e-6]
        if len(at_a)==1 and len(at_b)==1 and at_a!=at_b:return dict(line=k,ext=(at_a[0],at_b[0]),arrows=arrows,label=labels[0])
    return None


def cote_normal(members,parts):
    """Unit normal of a straight cote's dimension line."""
    (ax,ay),(bx,by)=path(members[parts['line']])[0][0],path(members[parts['line']])[0][-1]
    n=math.hypot(bx-ax,by-ay);return -(by-ay)/n,(bx-ax)/n


def shifted_cote(members,parts,delta):
    """The straight cote with its dimension line moved `delta` mm along its normal; the
    extension lines still start on the measured points."""
    out=[copy.deepcopy(s) for s in members];nx,ny=cote_normal(members,parts);dx,dy=nx*delta,ny*delta
    for j in [parts['line'],*parts['arrows'],parts['label']]:out[j]['x']+=dx;out[j]['y']+=dy
    for j in parts['ext']:
        s=out[j];end=(s['x']+s['w']+dx,s['y']+s['h']+dy);s['w']=end[0]-s['x'];s['h']=end[1]-s['y']
    return out


def retexted(s,text):
    """0.16.30: a text (free text, cote value) with a new wording, same place, size and links."""
    if s.get('text_offset') is not None:
        new=aligned_annotation(text,(s['x']+s['text_offset'][0],s['y']+s['text_offset'][1]),s.get('text_angle',0),s.get('text_height',5))
    elif not s.get('text_angle') and s.get('kind')=='poly' and len(s.get('points',[]))==2:
        new=annotation(text,(s['x'],s['y']),s.get('text_height',3))
    else:
        new=copy.deepcopy(s);new.update(label=text,name=text[:200]);return new
    for key,value in s.items():
        if key not in new:new[key]=copy.deepcopy(value)
    return new


def copy_independent_notches(crans,source,target,reference,target_reference,reverse=False):
    """Transfer selected crans by contour distance, keeping their local inside/outside."""
    from curves import parts
    start=locate(source,reference)[0];dest=locate(target,target_reference)[0]
    source_closed=path(source)[1];target_closed=path(target)[1]
    source_sign=interior_side(source) if source_closed else 1
    target_sign=(interior_side(target) if target_closed else 1)*(-1 if reverse else 1)
    found=[]
    for cran in crans:
        strokes=parts(cran) if cran.get('components') else [cran]
        if not cran.get('is_notch') or not strokes:raise ValueError('Sélectionnez uniquement les crans à copier.')
        form=cran_form(strokes)
        if form is None:raise ValueError('Sélectionnez uniquement les crans à copier.')
        a=form['foot'];b=(a[0]+form['direction'][0],a[1]+form['direction'][1]);d,projection=locate(source,a)
        if math.dist(a,projection)>.1:raise ValueError('Les crans sélectionnés doivent appartenir au contour source choisi.')
        found.append((form,a,b,d,d-start))
    if source_closed and found:
        # 0.19.9: on a closed source the crans are measured from the reference along the stretch they are on: the
        # contour is cut once for them all, in the middle of the largest stretch without any (a cran past the
        # first vertex was measured the long way round; one more than half a turn away must still go forward).
        P=perimeter(source);ahead=sorted({0.}|{delta%P for *_,delta in found})
        gaps=[(ahead[k+1]-ahead[k],0,(ahead[k]+ahead[k+1])/2) for k in range(len(ahead)-1)]+[(P-ahead[-1],1,(ahead[-1]+P)/2)]
        cut=max(gaps)[2]   # equal stretches: the one before the reference (forward, as before 0.19.9)
        found=[(form,a,b,d,delta%P if delta%P<cut else delta%P-P) for form,a,b,d,delta in found]
    result=[]
    for form,a,b,d,delta in found:
        delta*=source_sign
        # Signed distance lets a reference at the end of a closed source also
        # transfer onto an open target, without adding an entire perimeter.
        distance=dest+target_sign*delta
        if target_closed:distance%=perimeter(target)
        # at_distance raises before any data is changed if an open target is too short.
        _,normal=at_distance(source,d);_,target_normal=at_distance(target,distance)
        side=1 if (b[0]-a[0])*normal[0]+(b[1]-a[1])*normal[1]>=0 else -1
        if source_closed and target_closed:side=side*source_sign*interior_side(target)
        else:side=side*source_sign*target_sign
        mark=dict(distance=distance,depth=form['depth'],side=side)
        for key in ('kind','width','cap_width','gap'):
            if key in form:mark[key]=form[key]
        result.append(standalone_notch(target,mark))
    return result


def separate_notches(items):
    result=[]
    for item in items:
        if not item.get('notches'):result.append(item);continue
        host=copy.deepcopy(item);marks=host.pop('notches');result.append(host)
        result.extend(standalone_notch(host,mark) for mark in marks)
    return result


def measure_points(a,b,ortho=True):
    """Distance between the picked points (snapping kept). 0.16.29: horizontal or vertical
    only when ORTHO is on; otherwise the real distance, in any direction."""
    if not ortho:return a,b
    return a,((b[0],a[1]) if abs(b[0]-a[0])>=abs(b[1]-a[1]) else (a[0],b[1]))
