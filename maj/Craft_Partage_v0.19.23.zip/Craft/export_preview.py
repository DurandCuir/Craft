"""Native export review: shared PDF layout and temporary neon export highlighting.
0.18.7: the PDF window opens at once; the pieces are packed behind it (pdf_layout.plan_steps, a few
milliseconds at a time between the events of Tk, never in another thread: the geometry caches are
shared with the drawing) and the pages are kept for the same drawing and options."""
import copy,math,time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from geometry import path, bounds, export_entities, export_pdf
from exchange import export_dxf
from craft_tools import style

GREEN='#39ff14'
SLICE=.012     # 0.18.7: seconds of packing between two looks at the events (the window stays usable)
PLANS=12       # 0.18.7: packings kept for the session (same drawing and options: shown at once)


def clip_segment(a,b,box):
    """Liang–Barsky clipping to the very same printable A4 area as the PDF."""
    x,y,X,Y=box;dx,dy=b[0]-a[0],b[1]-a[1];lo,hi=0.,1.
    for p,q in ((-dx,a[0]-x),(dx,X-a[0]),(-dy,a[1]-y),(dy,Y-a[1])):
        if abs(p)<1e-12:
            if q<0:return None
        elif p<0:lo=max(lo,q/p)
        else:hi=min(hi,q/p)
        if lo>hi:return None
    return ((a[0]+lo*dx,a[1]+lo*dy),(a[0]+hi*dx,a[1]+hi*dy))


from entity_rules import fabrication_ids


def export_ids(app,selection,points=False):
    return fabrication_ids(app.items,app.selected_ids() if selection else None,points)


def model_title(app):
    """Model name written in the PDF heading (0.16.28; 0.18.1: the Modèle of the Infos du modèle
    first)."""
    import model_info
    return model_info.model_name(app)


def print_pdf(file):
    """0.16.28: print directly through the default PDF viewer (Windows « print » verb);
    a viewer without that verb opens the PDF instead. Returns the status message."""
    import os
    start=getattr(os,'startfile',None)
    if start is None:raise OSError('Impression directe disponible sous Windows.')
    try:start(str(file),'print');return 'PDF envoyé à l’impression.'
    except OSError:
        start(str(file));return 'PDF ouvert : Ctrl+P, taille réelle.'


def helper_process(*args):
    """Windows: print_direct.py in its own process (a printer driver problem never closes
    Craft). None when it cannot be started here."""
    import os,subprocess,sys
    from pathlib import Path
    helper=Path(__file__).with_name('print_direct.py')
    if os.name!='nt' or not helper.exists():return None
    try:return subprocess.Popen([sys.executable,str(helper),*map(str,args)],creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),close_fds=True)
    except OSError:return None


def start_print_helper(file,name,printer=None,copies=1,mono=False,devmode=None):
    """0.16.29: printing straight to the chosen printer (A4, real size, copies, colour or black
    & white), without any Windows window; without a printer name, the Windows print window."""
    from pathlib import Path
    args=[file,name]
    if printer:args+=['--printer',printer]
    if copies and int(copies)>1:args+=['--copies',int(copies)]
    if mono:args.append('--mono')
    if printer and devmode and Path(devmode).is_file():args+=['--devmode',devmode]
    return helper_process(*args)


# 0.19.9: was ExportReview.wait_print; fiches.print_fiches reads the helper's result the same way.
def wait_print(app,process,target,paper='A4'):
    """The print helper's result in the status bar; when it failed (code 2: no printer, driver),
    the PDF opens in the PDF reader instead."""
    code=process.poll()
    if code is None:app.after(250,lambda:wait_print(app,process,target,paper));return
    if code in (0,1,3):app.status.set({0:'Impression lancée.',1:'Impression annulée.',3:f'Impression : papier {paper} requis.'}[code]);return
    try:app.status.set(print_pdf(target))   # the helper failed: the PDF opens in the PDF reader
    except OSError as exc:app.status.set('Impression impossible : '+str(exc))


def print_folder():
    import tempfile
    from pathlib import Path
    folder=Path(tempfile.gettempdir())/'Craft_impression';folder.mkdir(parents=True,exist_ok=True);return folder


def safe_name(text):
    import re
    return re.sub(r'[<>:"/\\|?*\x00-\x1f]+','_',text or '').strip(' .')


def print_target(title):
    folder=print_folder();base=safe_name(title) or 'Patron'
    return [folder/(base+(f' ({k})' if k else '')+'.pdf') for k in range(30)]


def devmode_file(printer):
    """Printer settings chosen with « Propriétés… », kept for Craft's next prints."""
    return print_folder()/((safe_name(printer) or 'imprimante')+'.devmode')


def plan_key(items,workspace,archives,options):
    """0.18.7: what the pages depend on, cheaply (a few ms on DIFORME): every value of the objects
    packed, the base (its zones), the types of the materials (the zone of a piece outside the base)
    and the options. Any change of the drawing gives another key; None: nothing kept."""
    import hashlib,marshal
    try:data=marshal.dumps((items,workspace,(archives or {}).get('material_info')),2)
    except (ValueError,AttributeError):return None
    return (hashlib.blake2b(data,digest_size=20).digest(),*options)


def kept_plans(app):
    """0.18.7: the packings kept for Craft's session, key → plan, the latest used last."""
    return app.__dict__.setdefault('_pdf_plans',{})


def keep(app,key,plan):
    if key is None:return
    plans=kept_plans(app);plans.pop(key,None);plans[key]=plan
    while len(plans)>PLANS:plans.pop(next(iter(plans)))


def packing_text(share):
    return f'Rangement des pièces… {round(100*min(share,.99))} %'


class Packing:
    """0.18.7: a packing run behind the window, SLICE seconds at a time from Tk's event loop (never
    in another thread). Its clock counts only the time spent packing: the budget tries as many
    packings as a packing done at once, so the same pages. ``listener(job)`` is told after each
    slice run from the event loop (``over``: ``plan`` or ``error`` known)."""
    def __init__(self,widget,key,make,listener):
        self.widget=widget;self.key=key;self.listener=listener;self.share=0.;self.worked=0.;self.since=None;self.after=None
        self.over=False;self.plan=None;self.error=None
        self.steps=make(self.clock,self.told)
    def clock(self):
        return self.worked+(time.perf_counter()-self.since if self.since is not None else 0.)
    def told(self,share):self.share=share
    def run(self,first=False):
        """One slice; True while the packing goes on (the next slice is scheduled)."""
        self.unschedule()
        if self.over:return False
        self.since=time.perf_counter();end=self.since+SLICE;failure=None
        try:
            while time.perf_counter()<end:next(self.steps)
        except StopIteration as stop:self.over=True;self.plan=stop.value
        except ValueError as exc:self.over=True;self.error=exc
        except Exception as exc:
            # An unexpected error in a slice run between events: the window is told (it shows the
            # error and frees a waiting export), then the error is reported as before.
            self.cancel()
            if first:raise
            self.error=failure=exc
        except BaseException:self.cancel();raise
        finally:
            if self.since is not None:self.worked+=time.perf_counter()-self.since;self.since=None
        if not self.over:self.after=self.widget.after_idle(self.hop)
        if not first:self.listener(self)
        if failure is not None:raise failure
        return not self.over
    def hop(self):
        # after_idle then after(0): Tk redraws between two slices (a chain of after(0) alone would
        # starve its idle redraws), without the timer wait of after(1) on Windows.
        self.after=None if self.over else self.widget.after(0,self.slice)
    def slice(self):
        self.after=None;self.run()
    def unschedule(self):
        """One chain of slices only (a slice run directly drops the one scheduled)."""
        if self.after:
            try:self.widget.after_cancel(self.after)
            except tk.TclError:pass
        self.after=None
    def cancel(self):
        """Abandoned: no more slices, its result never comes."""
        self.over=True;self.unschedule();self.steps.close()


class ExportReview:
    def __init__(self,app,kind,whole=False):
        self.app=app;self.kind=kind;self.page=0;self.closed=False;self.print_button=None
        self.job=None;self.error=None;self.waiting=None;self.options=[]       # 0.18.7: packing behind
        self.window=app.dialog('PDF et impression' if kind=='pdf' else 'Aperçu avant export '+kind.upper());self.window.resizable(True,True);self.window.geometry('860x720' if kind=='pdf' else '780x660')
        chosen=bool(app.selected_ids()) and not whole   # 0.19.9: whole: a selection without a valid piece is set aside (open_review)
        self.scope=tk.StringVar(value='selection' if chosen else 'all')
        top=tk.Frame(self.window,bg=app.p['panel']);top.pack(fill='x',padx=12,pady=10)
        for value,label in [('selection','Sélection actuelle'),('all','Tout le plan')]:
            button=__import__('modern_style').make_radio(top,text=label,variable=self.scope,value=value,command=self.refresh,state='normal' if value=='all' or chosen else 'disabled',bg=app.p['panel'],fg=app.p['ui_ink'],selectcolor=app.field_background(),activebackground=app.p['panel'])
            button.pack(side='left',padx=8);self.options.append(button)
        self.info=app.label(self.window,'');self.info.pack(fill='x',padx=16)
        app.label(self.window,'Pièces complètes en vert · nom + matière + coupe').pack(padx=16,pady=6)
        self.canvas=tk.Canvas(self.window,bg='#484b50',highlightthickness=0,height=460);self.canvas.pack(fill='both',expand=True,padx=12,pady=6)
        self.canvas.bind('<Configure>',lambda e:self.draw())
        if kind=='pdf':self.build_print_panel()
        else:
            row=tk.Frame(self.window,bg=app.p['panel']);row.pack(fill='x',padx=12,pady=6)
            app.button(row,'Annuler',self.close).pack(side='right',padx=6)
            self.save_button=app.button(row,'Exporter '+kind.upper()+'…',self.save);self.save_button.pack(side='right',padx=6)
        self.window.protocol('WM_DELETE_WINDOW',self.close);self.window.bind('<Escape>',lambda e:self.close())
        self.window.bind('<Destroy>',self.destroyed,add='+');app._export_review=self;self.refresh()

    def build_print_panel(self):
        """0.16.29: pages, margins, colour or black & white, printer and copies in Craft's own
        window; « Imprimer » prints at once at real size, without a Windows window."""
        app=self.app;panel=app.p['panel'];prefs=app.prefs
        field=__import__('modern_style').spinbox(__import__('modern_style').tokens_for(app.p));field.update(justify='center')   # 0.19.0: flat number boxes
        self.margin=tk.StringVar(value=mm_text(margin_of(prefs)))
        self.mono=tk.BooleanVar(value=bool(prefs.get('print_mono',False)));self.printer=tk.StringVar(value='');self.copies=tk.StringVar(value='1')
        pages=tk.Frame(self.window,bg=panel);pages.pack(fill='x',padx=12,pady=(6,2))
        app.button(pages,'‹ Page',lambda:self.step(-1)).pack(side='left')
        self.page_label=app.label(pages,'');self.page_label.pack(side='left',padx=12)
        app.button(pages,'Page ›',lambda:self.step(1)).pack(side='left')
        for value,label in [(True,'Noir et blanc'),(False,'Couleur')]:
            __import__('modern_style').make_radio(pages,text=label,variable=self.mono,value=value,command=self.options_changed,bg=panel,fg=app.p['ui_ink'],selectcolor=app.field_background(),activebackground=panel,font=('Segoe UI',10)).pack(side='right',padx=3)
        app.label(pages,'mm').pack(side='right',padx=(2,14))
        self.margin_box=tk.Spinbox(pages,from_=3,to=30,increment=1,width=4,textvariable=self.margin,command=self.options_changed,**field);self.margin_box.pack(side='right')
        self.margin_box.bind('<KeyRelease>',lambda e:self.typed());self.margin_box.bind('<FocusOut>',lambda e:self.margin.set(mm_text(self.margin_value())))
        app.label(pages,'Marges').pack(side='right',padx=(0,5))
        # 0.17.0 hand cutting: pieces packed as tightly as wanted (1 mm minimum, 5 by default).
        # 0.18.5: « Classer » every piece together or each type of piece (zone of the base) on its own
        # pages, remembered in « pdf_tight » (True: together, the former « au plus serré »); the gap
        # counts for both.
        self.together=tk.BooleanVar(value=bool(prefs.get('pdf_tight',False)));self.gap=tk.StringVar(value=mm_text(gap_of(prefs)))
        pack=tk.Frame(self.window,bg=panel);pack.pack(fill='x',padx=12,pady=(2,2))
        app.label(pack,'Classer').pack(side='left',padx=(0,2))
        for value,label in [(True,'Tout ensemble'),(False,'Par type de pièce')]:
            button=__import__('modern_style').make_radio(pack,text=label,variable=self.together,value=value,command=self.options_changed,bg=panel,fg=app.p['ui_ink'],selectcolor=app.field_background(),activebackground=panel,font=('Segoe UI',10))
            button.pack(side='left',padx=3);self.options.append(button)
        app.label(pack,'Écart entre pièces').pack(side='left',padx=(14,5))
        self.gap_box=tk.Spinbox(pack,from_=1,to=50,increment=1,width=4,textvariable=self.gap,command=self.options_changed,**field);self.gap_box.pack(side='left')
        self.gap_box.bind('<KeyRelease>',lambda e:self.typed());self.gap_box.bind('<FocusOut>',lambda e:self.gap.set(mm_text(self.gap_value())))
        app.label(pack,'mm').pack(side='left',padx=(2,0))
        # 0.18.1: A4 to A0 (an A3 printer prints fewer, larger pages), remembered.
        from pdf_layout import PAPERS,paper_name
        self.paper=tk.StringVar(value=paper_name(prefs.get('pdf_paper','A4')))
        self.paper_box=ttk.Combobox(pack,textvariable=self.paper,state='readonly',width=5,values=list(PAPERS));self.paper_box.pack(side='right')
        self.paper_box.bind('<<ComboboxSelected>>',lambda e:self.options_changed())
        app.label(pack,'Papier').pack(side='right',padx=(14,5))
        actions=tk.Frame(self.window,bg=panel);actions.pack(fill='x',padx=12,pady=(4,10))
        app.label(actions,'Imprimante').pack(side='left')
        self.printer_box=ttk.Combobox(actions,textvariable=self.printer,state='readonly',width=24,values=[]);self.printer_box.pack(side='left',padx=(6,10))
        self.printer_box.bind('<<ComboboxSelected>>',lambda e:self.remember('printer',self.printer.get()))
        app.label(actions,'Copies').pack(side='left')
        tk.Spinbox(actions,from_=1,to=99,increment=1,width=3,textvariable=self.copies,**field).pack(side='left',padx=(6,10))
        self.properties_button=app.button(actions,'Propriétés…',self.printer_properties);self.properties_button.pack(side='left')
        app.button(actions,'Annuler',self.close).pack(side='right',padx=(6,0))
        self.save_button=app.button(actions,'Exporter PDF…',self.save);self.save_button.pack(side='right',padx=6)
        self.print_button=app.button(actions,'Imprimer',self.print_now);self.print_button.pack(side='right',padx=6)
        self.options+=[self.margin_box,self.gap_box,self.paper_box]     # 0.18.7: what changes the pages
        self.load_printers()

    def remember(self,key,value):
        if self.app.prefs.get(key)!=value:
            self.app.prefs[key]=value
            try:self.app.persist_preferences()
            except OSError:pass

    def margin_value(self):
        try:value=float(str(self.margin.get()).replace(',','.'))
        except (ValueError,AttributeError):return margin_of(self.app.prefs)
        return min(30.,max(3.,value))

    def gap_value(self):
        try:value=float(str(self.gap.get()).replace(',','.'))
        except (ValueError,AttributeError):return gap_of(self.app.prefs)
        return min(50.,max(1.,value))

    def paper_value(self):
        from pdf_layout import paper_name
        return paper_name(self.paper.get()) if self.kind=='pdf' and hasattr(self,'paper') else 'A4'

    def packing(self):
        """Space between pieces (mm) of the PDF plan; 0.18.5: for both ways of classing them."""
        return self.gap_value() if self.kind=='pdf' and hasattr(self,'gap') else None

    def options_changed(self):
        self.__dict__.pop('_typing',None)
        if self.closed:return
        self.remember('pdf_margin',self.margin_value());self.remember('print_mono',bool(self.mono.get()))
        if hasattr(self,'paper'):self.remember('pdf_paper',self.paper_value())
        if hasattr(self,'together'):self.remember('pdf_tight',bool(self.together.get()));self.remember('pdf_gap',self.gap_value())
        self.refresh()

    def typed(self):
        """0.18.5: a value typed in a field: the pieces are packed again once the typing stops (a
        packing may take up to 2 s)."""
        pending=self.__dict__.get('_typing')
        if pending:self.window.after_cancel(pending)
        self._typing=self.window.after(350,self.options_changed)

    def make_plan(self):
        """0.18.5: the PDF pages of the current options. 0.18.7: kept for the same drawing and options
        (reopening the window or going back to an option shows them at once); else None while the
        pieces are packed behind (``self.job``: a first slice now, the rest between the events)."""
        from pdf_layout import BUDGET,plan_steps
        from geometry import clone
        options=(self.margin_value(),self.packing(),self.paper_value(),bool(self.together.get()))
        archives=self.app.__dict__.get('archives');key=plan_key(self.items,self.app.workspace,archives,options)
        plans=kept_plans(self.app);job=self.job
        if key is not None and key in plans:
            self.stop_packing();plan=plans.pop(key);plans[key]=plan;return plan
        if job is not None and key is not None and job.key==key:return None      # these pages are being packed
        self.stop_packing()
        # A copy: the packing goes on between events, whatever happens to the drawing meanwhile.
        items,workspace,archives=clone((self.items,self.app.workspace,archives));margin,gap,paper,together=options
        job=Packing(self.window,key,lambda clock,told:plan_steps(items,workspace,margin,gap,paper,together=together,archives=archives,budget=BUDGET,progress=told,clock=clock),self.packed)
        if job.run(first=True):self.job=job;return None      # a small drawing is packed before the window shows
        if job.error is not None:raise job.error
        keep(self.app,key,job.plan);return job.plan

    def stop_packing(self):
        job,self.job=self.job,None
        if job is not None:job.cancel()

    def packed(self,job):
        """0.18.7: after each slice of a packing behind, the share done; at its end the pages, kept,
        and shown when it is still the packing of the window's options (an abandoned one never is);
        an export waiting for them is done then."""
        if job.over and job.plan is not None:keep(self.app,job.key,job.plan)
        if self.closed or job is not self.job:return
        if not job.over:
            text=packing_text(job.share)
            if self.info.cget('text')!=text:self.info.configure(text=text)
            return
        self.job=None
        if job.error is not None:self.plan=None;self.entities=[];self.error=str(job.error);self._highlight_view=None
        else:self.plan=job.plan;self.page=min(self.page,self.plan['pages']-1)
        self.settle()

    def settle(self):
        """The window shows its state; once the pages of the options are known (no packing behind),
        an export waiting for them is done (dropped on an error)."""
        waiting=None
        if self.job is None:waiting,self.waiting=self.waiting,None
        if waiting:self.lock(False)
        self.show();self.highlight();self.draw()
        if waiting and self.plan:waiting()

    def when_ready(self,action):
        """0.18.7: « Exporter » or « Imprimer » while the pieces are being packed: done as soon as the
        pages are ready (the share shown, the options kept as they are meanwhile); never a part of a
        packing nor the pages of other options."""
        if self.job is None:
            if self.kind=='pdf' and self.plan is None:   # the packing ended on an error meanwhile (file dialog open)
                messagebox.showerror('PDF et impression',self.error or 'Rangement des pièces impossible.',parent=self.window);return
            action();return
        if not self.waiting:self.lock(True)
        self.waiting=action;self.show()

    def lock(self,on):
        """While an export waits for its pages, the options that change them stay as they are (colour,
        printer and copies are read when it is done)."""
        if on:self._states={w:str(w.cget('state')) for w in self.options}
        for w,state in self.__dict__.get('_states',{}).items():
            try:w.configure(state='disabled' if on else state)
            except tk.TclError:pass

    def load_printers(self):
        """Windows printers, read by print_direct.py in its own process (it can take a moment
        with network printers: the window stays usable meanwhile)."""
        out=print_folder()/'imprimantes.json'
        try:out.unlink()
        except OSError:pass
        process=helper_process('--printers',out)
        if process is None:self.set_printers([],'');return
        self.properties_button.configure(state='disabled');self.printer_box.configure(values=['Recherche des imprimantes…']);self.printer.set('Recherche des imprimantes…')
        def wait(count=0):
            if self.closed:return
            code=process.poll()
            if code is None and count<150:self.window.after(100,lambda:wait(count+1));return
            try:
                import json;data=json.loads(out.read_text(encoding='utf-8')) if code==0 else {}
            except (OSError,ValueError):data={}
            self.set_printers(data.get('printers',[]),data.get('default',''))
        self.window.after(100,wait)

    def set_printers(self,names,default):
        self.printers=list(names)
        if not self.printers:
            # No list (here or if Windows did not answer): the Windows print window chooses the printer.
            self.printer_box.configure(values=['Imprimante par défaut']);self.printer.set('Imprimante par défaut');self.properties_button.configure(state='disabled');return
        chosen=self.app.prefs.get('printer')
        self.printer_box.configure(values=self.printers);self.printer.set(chosen if chosen in self.printers else default if default in self.printers else self.printers[0])
        self.properties_button.configure(state='normal')

    def chosen_printer(self):
        name=self.printer.get();return name if name in getattr(self,'printers',[]) else None

    def printer_properties(self):
        name=self.chosen_printer()
        if not name:return
        process=helper_process('--prefs',name,devmode_file(name))
        if process is None:return
        self.app.status.set('Propriétés de l’imprimante…')
        def wait():
            if self.closed and process.poll() is None:self.app.after(200,wait);return
            code=process.poll()
            if code is None:self.app.after(200,wait);return
            self.app.status.set({0:'Réglages de l’imprimante gardés pour Craft.',1:'Propriétés fermées.'}.get(code,'Propriétés indisponibles.'))
        self.app.after(200,wait)

    def current_items(self):
        return [self.app.items[i] for i in export_ids(self.app,self.scope.get()=='selection',points=self.kind=='pdf')]

    def refresh(self):
        """The objects of the scope and, for the PDF, the pages of the options: kept ones at once,
        else packed behind (0.18.7) while the window stays usable."""
        self.plan=None;self.error=None
        try:
            self.items=self.current_items();self.entities=export_entities(self.items,pdf=self.kind=='pdf')
            if self.kind=='pdf':self.plan=self.make_plan()
            if self.plan:self.page=min(self.page,self.plan['pages']-1)
            elif self.job is None:self.page=0
        except ValueError as exc:
            self.stop_packing();self.entities=[];self.plan=None;self.page=0;self.error=str(exc)
        self._highlight_view=None;self.settle()

    def show(self):
        """The line above the pages (pieces and pages, the share packed, or why not), the buttons and,
        0.18.7, the wait cursor over the preview while the pieces are being packed."""
        busy=self.job is not None
        if self.error:text=self.error
        elif busy:text=packing_text(self.job.share)
        else:
            # 0.18.1: finished pieces (closed, Coupe externe, name and material), not objects.
            from entity_rules import piece_count
            k=piece_count(self.items);n=self.plan['pages'] if self.plan else 0
            text=f"{k} pièce{'s' if k>1 else ''} · "+(f"{n} page{'s' if n>1 else ''} {self.paper_value()}" if self.kind=='pdf' else 'DXF en millimètres · arcs et courbes conservés')
        self.info.configure(text=text);state='normal' if self.items and not self.error and not self.waiting else 'disabled'
        self.save_button.configure(state=state)
        if self.print_button is not None:self.print_button.configure(state=state)
        if self.kind=='pdf':
            self.canvas.configure(cursor='watch' if busy else '')
            if not self.plan:self.page_label.configure(text='')

    def highlight(self):
        if self.closed:return
        c=self.app.canvas;view=(self.app.scale,self.app.ox,self.app.oy)
        if view==getattr(self,'_highlight_view',None) and c.find_withtag('export_highlight'):return
        self._highlight_view=view;c.delete('export_highlight')
        for s in self.entities:
            if s.get('dimension_group') or style(s)['role']=='dimension':continue
            if s.get('annotation'):
                x,y,X,Y=bounds([s]);c.create_rectangle(*self.app.to_screen((x,y)),*self.app.to_screen((X,Y)),outline=GREEN,width=2,tags='export_highlight');continue
            pts,closed=path(s);pts=pts+pts[:1] if closed else pts
            if len(pts)>1:c.create_line(*[v for p in pts for v in self.app.to_screen(p)],fill=GREEN,width=2.5,tags='export_highlight')
        c.tag_raise('export_highlight')

    def step(self,delta):
        if self.plan:self.page=max(0,min(self.plan['pages']-1,self.page+delta));self.draw()

    def draw(self):
        if self.closed or not hasattr(self,'entities'):return
        c=self.canvas;c.delete('all');W=max(100,c.winfo_width());H=max(100,c.winfo_height())
        if self.kind=='pdf':
            if not self.plan:return
            from pdf_layout import paper_size
            pw,ph=self.plan.get('size') or paper_size(self.paper_value())
            scale=min((W-30)/pw,(H-30)/ph);left=(W-pw*scale)/2;top=(H-ph*scale)/2
            c.create_rectangle(left,top,left+pw*scale,top+ph*scale,fill='white',outline='#dddddd',tags='paper')
            transform=lambda p:(left+p[0]*scale,top+p[1]*scale)
            spec=self.plan['page_specs'][self.page];ox,oy=spec['origin'];col,row=spec['col'],spec['row']
            self.page_label.configure(text=f"Page {self.page+1} / {self.plan['pages']} · {spec['zone']}")
            from pdf_layout import PRINTABLE,page_area,stroke_reach
            m=self.plan.get('margin',10.);aleft,atop,aw,ah=self.plan.get('area') or page_area(m,self.paper_value())
            c.create_rectangle(*transform((m,m)),*transform((pw-m,ph-m)),outline='#aaaaaa',dash=(3,3))
            heading=' | '.join(['Craft']+([model_title(self.app)] if model_title(self.app) else [])+[spec['zone'],f"page {self.page+1}/{self.plan['pages']}"])
            c.create_text(*transform((m+1.5,max(m,PRINTABLE)+4.2)),text=heading,anchor='sw',font=('Segoe UI',-max(4,round(2.2*scale))),fill='black')
            # 0.18.5: the clip of the PDF: the area and half the page's widest line.
            e=stroke_reach(spec['items']);locate=lambda p:(p[0]-ox+aleft,p[1]-oy+atop);clip=(aleft-e,atop-e,aleft+aw+e,atop+ah+e);ink='black';entities=spec['items']
        else:
            c.configure(bg=self.app.p['canvas'])
            if not self.entities:return
            x,y,X,Y=bounds(self.entities);scale=min((W-40)/max(1,X-x),(H-40)/max(1,Y-y));left=(W-(X-x)*scale)/2;top=(H-(Y-y)*scale)/2
            transform=lambda p:(left+p[0]*scale,top+p[1]*scale)
            locate=lambda p:(p[0]-x,p[1]-y);clip=None;ink=self.app.p['ink'];entities=self.entities
        mono=self.kind=='pdf' and bool(self.mono.get())
        for s in entities:
            st=style(s);color=ink if st['color']=='auto' or mono else st['color']
            if s.get('annotation'):
                off=s.get('text_offset',[0,0]);pt=locate((s['x']+off[0],s['y']+off[1]))
                if clip and not(clip[0]<=pt[0]<=clip[2] and clip[1]<=pt[1]<=clip[3]):continue
                c.create_text(*transform(pt),text=s['label'],anchor='center' if 'text_offset' in s else 'nw',angle=-s.get('text_angle',0),fill=color,font=('Segoe UI',-max(1,round(s.get('text_height',3)*scale))),tags='export_entity');continue
            pts,closed=path(s);pts=[locate(p) for p in pts];pts=pts+pts[:1] if closed else pts
            if s.get('filled') and (not clip or all(clip[0]<=p[0]<=clip[2] and clip[1]<=p[1]<=clip[3] for p in pts)):
                c.create_polygon(*[v for p in pts for v in transform(p)],fill=color,outline='',tags='export_entity');continue
            for a,b in zip(pts,pts[1:]):
                segment=clip_segment(a,b,clip) if clip else (a,b)
                if segment:
                    opts=dict(fill=color,width=max(.5,st['width']*scale),tags='export_entity')
                    if st['dash']:opts['dash']=tuple(max(1,round(v*scale)) for v in st['dash'])
                    c.create_line(*transform(segment[0]),*transform(segment[1]),**opts)

    def checked(self):
        """0.17.0: the 30 mm check again for the scope chosen here (« Tout le plan » too); 0.18.2:
        the double line for the PDF and « Imprimer » too. False: the window closes on the plan."""
        from export_check import ready
        if not ready(self.app,self.kind,sorted(self.app.selected_ids()) if self.scope.get()=='selection' else None,warnings=False):self.close();return False
        try:self.window.grab_set()
        except tk.TclError:return False
        return True

    def save(self):
        if not self.checked():return
        import doc_files
        options=dict(parent=self.window,defaultextension='.'+self.kind,filetypes=doc_files.export_types(self.kind));folder=doc_files.initial_dir(self.app.prefs)
        if folder:options['initialdir']=folder
        file=filedialog.asksaveasfilename(**options)
        if not file:return
        doc_files.remember_folder(self.app.prefs,file)
        try:self.app.persist_preferences()
        except Exception:pass
        if not self.closed:self.when_ready(lambda:self.write(file))

    def write(self,file):
        try:
            items=copy.deepcopy(self.current_items())
            if self.kind=='pdf':
                count=export_pdf(file,items,workspace=self.app.workspace,plan=self.plan,title=model_title(self.app),mono=bool(self.mono.get()));self.offer_print_test(file);messagebox.showinfo('PDF prêt',f"{count} page{'s' if count>1 else ''} {self.paper_value()}. Imprimer à Taille réelle / 100 %.",parent=self.window)
            else:export_dxf(file,items)
            self.app.status.set(self.kind.upper()+' exporté : '+file);self.close()
        except (ValueError,OSError) as exc:messagebox.showerror('Export '+self.kind.upper(),str(exc),parent=self.window)

    def print_now(self):
        """0.16.28: « Imprimer » without saving a PDF first. 0.16.29: straight to the printer
        chosen here, with its copies, margins and colour or black & white. 0.18.7: once the pages
        are packed."""
        if not self.checked():return
        self.when_ready(self.print_pages)

    def print_pages(self):
        try:
            items=copy.deepcopy(self.current_items());title=model_title(self.app);mono=bool(self.mono.get())
            try:copies=max(1,min(99,int(self.copies.get())))
            except ValueError:copies=1
            for target in print_target(title):
                try:export_pdf(target,items,workspace=self.app.workspace,plan=self.plan,title=title,mono=mono);break
                except PermissionError:continue   # still open in the viewer: next name
            else:raise OSError('Fichier d’impression occupé : fermer le lecteur PDF.')
            printer=self.chosen_printer()
            process=start_print_helper(target,'Craft - '+(title or 'Patron'),printer=printer,copies=copies,mono=mono,devmode=devmode_file(printer) if printer else None)
            if process is None:self.app.status.set(print_pdf(target));self.close();return
            app=self.app;paper=self.paper_value();app.status.set('Impression…');self.close();app.after(250,lambda:wait_print(app,process,target,paper))   # 0.19.9: shared with the fiches
        except (ValueError,OSError) as exc:messagebox.showerror('Imprimer',str(exc),parent=self.window)

    def offer_print_test(self,patron_file):
        # 0.16.28: 50 × 50 mm square (new key: offered once again with the new test).
        if self.app.prefs.get('pdf_square_test_offered',False):return
        answer=messagebox.askyesno('Test impression','Créer un PDF de test séparé ?\nCarré 50 × 50 mm pour vérifier l’impression à 100 %.',parent=self.window)
        self.app.prefs['pdf_square_test_offered']=True;self.app.persist_preferences()
        if not answer:return
        from pathlib import Path
        from geometry import export_print_test
        target=filedialog.asksaveasfilename(parent=self.window,title='PDF de test séparé',initialdir=str(Path(patron_file).parent),initialfile='Craft_Test_Impression.pdf',defaultextension='.pdf',filetypes=[('PDF (*.pdf)','*.pdf')])
        if not target:return
        if Path(target).resolve()==Path(patron_file).resolve():
            messagebox.showerror('Test impression','Choisir un fichier différent du patron.',parent=self.window);return
        try:export_print_test(target)
        except (ValueError,OSError) as exc:messagebox.showerror('Test impression','Test non créé. Patron enregistré.\n'+str(exc),parent=self.window)

    def destroyed(self,event):
        if event.widget is self.window:self.close(destroy=False)

    def close(self,destroy=True):
        if self.closed:return
        self.closed=True;self.waiting=None
        self.stop_packing()      # 0.18.7: the packing behind is abandoned with the window
        if getattr(self.app,'_export_review',None) is self:self.app._export_review=None
        try:
            if self.__dict__.get('_typing'):self.window.after_cancel(self._typing)
        except tk.TclError:pass
        try:
            self.app.canvas.delete('export_highlight')
            if destroy:self.window.destroy()
            self.app.canvas.focus_set()
        except tk.TclError:pass   # Craft is closing with the preview open


def mm_text(value):return f'{value:g}'.replace('.',',')


def gap_of(prefs):
    try:return min(50.,max(1.,float(prefs.get('pdf_gap',5.))))
    except (TypeError,ValueError):return 5.


def margin_of(prefs):
    from pdf_layout import MARGIN
    try:return min(30.,max(3.,float(prefs.get('pdf_margin',MARGIN))))
    except (TypeError,ValueError):return MARGIN


def open_review(app,kind):
    previous=getattr(app,'_export_review',None)
    if previous:previous.close()
    if not app.items:app.status.set('Aucun objet à exporter.');return None
    from export_check import ready
    from entity_rules import closed_piece
    scope=sorted(app.selected_ids())
    # 0.19.9: a selection without a valid piece (a line, a cote…): the whole plan, as if nothing was selected.
    if scope and not any(closed_piece(app.items[i]) and style(app.items[i])['role']=='external' for i in fabrication_ids(app.items,scope)):scope=[]
    if not ready(app,kind,scope or None):return None
    return ExportReview(app,kind,whole=not scope)
