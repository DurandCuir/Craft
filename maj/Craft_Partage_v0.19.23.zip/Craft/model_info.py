"""0.18.1 « Infos du modèle » (icon of the Fichiers group): what the person writes about the model
(modèle, description, créateur, atelier, saison, indice) and the fournitures of the nomenclature
(colle, fil, fermoir…). Craft only fills in the two dates, still editable: « Créé le » at the
first save, « Modifié le » when the drawing changed. Kept in the .crft (cad.validate_infos), shown on the fiches.
0.19.13: also Mozart's fields (version, ligne, matière(s), client(s), info 1 to 3, approuvé / vérifié le… par…,
note); a Mozart file gives its model sheet (MOZ_INFO: from_mozart), kept as it was for a DWG Mozart written again.
0.19.14: Mozart's 3rd value is the materials (« Vachette lisse bordeaux, crocodile… » on TILTED: « dans description
n'inscrit pas tous les cuirs »), the créateur at its 10th or 15th place (« AD » on TILTED); the dates are no longer
filled in by just looking (« applique ça que si j'ai modifié des choses ») : « Créé le » at the first save, « Modifié
le » when the drawing changed and is saved.
0.19.14 « Image » : a photo of the model (JPG or PNG, « Choisir… », « Retirer ») kept in the .crft (infos['image'],
cad.validate_model_image), small beside the model's name at the top of every fiche; never in Mozart's data."""
import copy
import os
import re
import time
from pathlib import Path

LABELS = (('modele', 'Modèle'), ('indice', 'Indice'), ('description', 'Description'), ('createur', 'Créateur'),
          ('atelier', 'Atelier'), ('saison', 'Saison'), ('version', 'Version'), ('ligne', 'Ligne'), ('clients', 'Client(s)'),
          ('matieres', 'Matière(s)'), ('info1', 'Info 1'), ('info2', 'Info 2'), ('info3', 'Info 3'),
          ('cree_le', 'Créé le'), ('modifie_le', 'Modifié le'), ('approuve_le', 'Approuvé le'), ('approuve_par', 'par'),
          ('verifie_le', 'Vérifié le'), ('verifie_par', 'par'), ('note', 'Note'))
# 0.19.13: the places of Mozart's model sheet (its 21 MOZ_INFO values) Craft knows, read on his DIFORME (« Diforme »,
# « Cuir de vachette », « Salle 36 », « 11/09/24 », « DURAND Alexis », « 1 », « Automne/Hiver 24/25 »)
MOZART_PLACES = ((0, 'modele'), (2, 'matieres'), (6, 'atelier'), (8, 'cree_le'), (9, 'createur'), (14, 'createur'), (17, 'indice'), (19, 'saison'))
CRAFT_ONLY = tuple(k for k, _ in LABELS if k not in {b for a, b in MOZART_PLACES}) + ('dernier_id',)
SUPPLY_LABELS = (('nom', 'Nom', 22), ('nb', 'NB', 5), ('matiere', 'Matériaux', 16), ('info', 'Informations', 26))
IMAGE_SIDE = 800   # 0.19.14: pixels kept of the Image du modèle (printed at most 26 × 11 mm)
IMAGE_TYPES = [('Images JPG ou PNG', '*.jpg *.jpeg *.png')]


def today():
    return time.strftime('%d/%m/%Y')


def file_date(file, created=True):
    """The date of a file (its creation under Windows, else its last change), '' when unknown."""
    try:
        st = Path(file).stat()
    except (OSError, TypeError):
        return ''
    stamp = getattr(st, 'st_birthtime', None) if created else None
    if stamp is None:
        stamp = st.st_ctime if created and os.name == 'nt' else st.st_mtime
    return time.strftime('%d/%m/%Y', time.localtime(stamp))


def dated(infos, file=None, changed=True):
    """The infos to write with a save: « Créé le » when empty (the date of the file it replaces,
    else today), « Modifié le » when the drawing changed (both stay as typed otherwise)."""
    out = dict(infos or {})
    if not out.get('cree_le'):
        out['cree_le'] = file_date(file) or today()
    if changed:
        out['modifie_le'] = today()
    return out


def from_mozart(values, craft=()):
    """The infos of a Mozart file: its model sheet's values at the places Craft knows (the date « 11/09/24 » as
    « 11/09/2024 »), Craft's own data of that sheet (« clé=valeur ») for the fields Mozart has no known place for,
    and the values as they were (``mozart_info``). None when there is nothing."""
    out = {}
    older = {}
    for item in craft or ():
        key, _, value = str(item).partition('=')
        if key in CRAFT_ONLY and value.strip():
            out[key] = value.strip()[:1000]
        elif key == 'matieres':
            older[key] = value.strip()[:1000]
    values = [str(v) for v in values or ()]
    if 'matieres' in older:
        # 0.19.14: a DWG Mozart written by 0.19.13 had the description at Mozart's 3rd place and the materials in
        # Craft's data: read as it was written
        if older['matieres']:
            out['matieres'] = older['matieres']
        if len(values) > 2 and values[2].strip() and 'description' not in out:
            out['description'] = values[2].strip()[:1000]
        values = values[:2] + [''] + values[3:] if len(values) > 2 else values
    for index, key in MOZART_PLACES:
        if index < len(values) and values[index].strip() and not (key == 'createur' and out.get(key) and index == 14):
            value = values[index].strip()
            if key == 'cree_le':
                m = re.fullmatch(r'(\d{1,2})/(\d{1,2})/(\d{2}|\d{4})', value)
                value = f'{int(m[1]):02d}/{int(m[2]):02d}/{"20" + m[3] if len(m[3]) == 2 else m[3]}' if m else value
            out[key] = value[:1000]
    if any(v.strip() for v in values) or older.get('matieres'):
        out['mozart_info'] = values[:50]
    return out or None


def craft_data(infos):
    """Craft's data of Mozart's model sheet: the fields Mozart has no known place for, « clé=valeur » (0.19.14: never
    the Image du modèle)."""
    infos = infos or {}
    return [f'{k}={str(infos.get(k) or "")[:240]}' for k in CRAFT_ONLY if k != 'image' and str(infos.get(k) or '').strip()]


def read_image(file):
    """0.19.14 « Image du modèle »: a JPG or PNG file as kept in the infos (cad.validate_model_image), read by backdrop
    (Pillow, GDI+ under Windows): upright (a phone photo turned), at most IMAGE_SIDE pixels."""
    import backdrop
    picture, _, fmt = backdrop.read_picture(file)
    try:
        kept = backdrop.light_copy(picture, fmt, IMAGE_SIDE)
    finally:
        backdrop.require().dispose(picture)
    return dict(kept, name=Path(file).name[:200])


def thumbnail(widget, image, width=72, height=40):
    """0.19.14: the Image du modèle small for the window (its proportions, at most width × height pixels, on the
    widget's colour); None without a readable one."""
    try:
        import base64
        import backdrop
        import display_render
        b = backdrop.require()
        picture = b.from_encoded(base64.b64decode(image['data']))
        try:
            pw, ph = b.size(picture)
            k = min(width / pw, height / ph)
            colour = tuple(round(v / 257) for v in widget.winfo_rgb(widget.cget('background')))
            data = b.view(picture, (0, 0, pw, ph), (max(1, round(pw * k)), max(1, round(ph * k))), 1., colour)
        finally:
            b.dispose(picture)
        return display_render.photo_image(widget, data)
    except Exception:   # the window shows its name only
        return None


def model_name(app):
    """The model's name for the fiches: the one written in the infos, else the model of the
    pieces' names, else the file's name."""
    infos = app.__dict__.get('infos') or {}
    name = infos.get('modele') or app.__dict__.get('project_model') or (Path(app.filename).stem if getattr(app, 'filename', None) else '')
    return str(name or '').strip()


def dialog(app):
    """The « Infos du modèle » window: the fields, then the fournitures; « Valider » keeps them in
    the drawing (« Annuler » the change); the file is written by « Enregistrer »."""
    import tkinter as tk
    from tkinter import ttk, messagebox
    from cad import validate_infos, validate_model_image
    old = copy.deepcopy(app.__dict__.get('infos') or {})
    win = app.dialog('Infos du modèle')
    panel = app.p['panel']
    # 0.19.14: the dates as they are (empty until the first save): just looking changes nothing
    values = {key: tk.StringVar(value=old.get(key, '')) for key, _ in LABELS}
    form = tk.Frame(win, bg=panel)
    form.pack(fill='x', padx=16, pady=(14, 6))
    places = dict(modele=(0, 0), indice=(0, 2), description=(1, 0), createur=(2, 0), atelier=(2, 2), saison=(3, 0), version=(3, 2),
                  ligne=(4, 0), clients=(4, 2), matieres=(5, 0), info1=(6, 0), info2=(7, 0), info3=(8, 0), cree_le=(9, 0), modifie_le=(9, 2),
                  approuve_le=(10, 0), approuve_par=(10, 2), verifie_le=(11, 0), verifie_par=(11, 2), note=(12, 0))
    widths = dict(modele=26, indice=8, description=58, createur=26, atelier=20, saison=26, version=8, ligne=26, clients=20, matieres=58,
                  info1=58, info2=58, info3=58, cree_le=12, modifie_le=12, approuve_le=12, approuve_par=20, verifie_le=12, verifie_par=20, note=58)
    wide = ('description', 'matieres', 'info1', 'info2', 'info3', 'note')
    first = None
    for key, label in LABELS:
        row, col = places[key]
        app.label(form, label).grid(row=row, column=col, sticky='w', padx=(0 if col == 0 else 14, 6), pady=3)
        field = app.entry(form, values[key], widths[key])
        field.grid(row=row, column=col + 1, columnspan=3 if key in wide else 1, sticky='w', pady=3)
        first = first or field
    # 0.19.14 « Image » : the photo of the model, at the top of every fiche beside its name
    image = [validate_model_image(old.get('image'))]
    app.label(form, 'Image').grid(row=13, column=0, sticky='w', pady=3)
    line = tk.Frame(form, bg=panel)
    line.grid(row=13, column=1, columnspan=3, sticky='w', pady=3)
    thumb = tk.Label(line, bg=panel, bd=0)
    shown = app.label(line, '')
    shown.pack(side='left', padx=(0, 8))

    def show_image():
        current = image[0]
        name = (current.get('name') or 'Image') if current else ''
        shown.configure(text=name if len(name) <= 40 else name[:39] + '…')
        photo = thumbnail(thumb, current) if current else None
        thumb.configure(image=photo or '')
        thumb.image = photo
        if photo:
            thumb.pack(side='left', padx=(0, 6), before=shown)
        else:
            thumb.pack_forget()
        drop.configure(state='normal' if current else 'disabled')

    def choose_image():
        from tkinter import filedialog
        import doc_files
        options = dict(parent=win, title='Image du modèle', filetypes=IMAGE_TYPES)
        folder = doc_files.initial_dir(app.prefs)
        if folder:
            options['initialdir'] = folder
        file = filedialog.askopenfilename(**options)
        if not file:
            return
        cursor = win.cget('cursor')
        win.configure(cursor='watch')
        win.update_idletasks()
        try:
            image[0] = read_image(file)
        except (OSError, ValueError, MemoryError) as exc:
            messagebox.showerror('Image du modèle', str(exc) or 'Image illisible.', parent=win)
        finally:
            win.configure(cursor=cursor)
        show_image()

    def drop_image():
        image[0] = None
        show_image()
    app.button(line, 'Choisir…', choose_image, kind='secondary').pack(side='left')   # « Valider » stays the main action
    drop = app.button(line, 'Retirer', drop_image)
    drop.pack(side='left', padx=6)
    show_image()
    app.label(win, 'Fournitures (nomenclature)', font=('Segoe UI', 10, 'bold')).pack(anchor='w', padx=16, pady=(10, 2))
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=16)
    table = ttk.Treeview(area, columns=[k for k, _, _ in SUPPLY_LABELS], show='headings', height=6, selectmode='browse')
    for key, label, width in SUPPLY_LABELS:
        table.heading(key, text=label)
        table.column(key, width=width * 8, anchor='center' if key == 'nb' else 'w', stretch=key in ('nom', 'info'))
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')
    rows = [dict(r) for r in old.get('fournitures', [])]

    def show_rows():
        table.delete(*table.get_children())
        for k, r in enumerate(rows):
            table.insert('', 'end', iid=str(k), values=[r.get(key, '') for key, _, _ in SUPPLY_LABELS])
    show_rows()
    edit = tk.Frame(win, bg=panel)
    edit.pack(fill='x', padx=16, pady=(4, 2))
    fields = {key: tk.StringVar() for key, _, _ in SUPPLY_LABELS}
    for k, (key, label, width) in enumerate(SUPPLY_LABELS):
        app.label(edit, label).grid(row=0, column=k, sticky='w', padx=(0, 4))
        app.entry(edit, fields[key], width).grid(row=1, column=k, sticky='w', padx=(0, 4))

    def chosen():
        picked = table.selection()
        return int(picked[0]) if picked else None

    def picked(e=None):
        k = chosen()
        if k is not None:
            for key, _, _ in SUPPLY_LABELS:
                fields[key].set(rows[k].get(key, ''))
    table.bind('<<TreeviewSelect>>', picked)

    def typed():
        return {key: fields[key].get().strip() for key, _, _ in SUPPLY_LABELS if fields[key].get().strip()}

    def add():
        row = typed()
        if not row.get('nom'):
            messagebox.showerror('Fournitures', 'Nom de la fourniture attendu.', parent=win)
            return
        rows.append(row)
        show_rows()
        for v in fields.values():
            v.set('')

    def change():
        k = chosen()
        row = typed()
        if k is None or not row.get('nom'):
            return
        rows[k] = row
        show_rows()
        table.selection_set(str(k))

    def remove():
        k = chosen()
        if k is None:
            return
        del rows[k]
        show_rows()
        for v in fields.values():
            v.set('')
    buttons = tk.Frame(win, bg=panel)
    buttons.pack(fill='x', padx=16, pady=(2, 6))
    app.button(buttons, 'Ajouter', add).pack(side='left')
    app.button(buttons, 'Modifier', change).pack(side='left', padx=6)
    app.button(buttons, 'Supprimer', remove).pack(side='left')
    end = tk.Frame(win, bg=panel)
    end.pack(fill='x', padx=16, pady=(6, 14))

    def valid(e=None):
        data = dict(old)   # what the window does not show (the last ID unique given) is kept
        data.update({key: values[key].get() for key, _ in LABELS})
        data['fournitures'] = rows
        data['image'] = image[0]   # None once « Retirer »
        new = validate_infos(data)
        win.destroy()
        app.canvas.focus_set()
        if new != (validate_infos(old) if old else None):
            app.snapshot()
            app.infos = new
            app.refresh()
            app.status.set('Infos du modèle mises à jour.')
        return 'break'
    app.button(end, 'Annuler', lambda: (win.destroy(), app.canvas.focus_set())).pack(side='right')
    app.button(end, 'Valider', valid).pack(side='right', padx=6)
    win.bind('<Escape>', lambda e: (win.destroy(), app.canvas.focus_set()))
    if first is not None:
        first.focus_set()
    win._infos_fields = values
    win._image = image
    win._supplies = rows
    win._supply_fields = fields
    win._valid = valid
    win._add_supply = add
    return win
