"""0.17.0 Préparations: zones of a piece to skive (Parage: rembord, pince…) or to dye (Teinte).

A zone is the closed region around a click (regions.region_at), kept as one closed polygon with
the role 'preparation', attached to its piece (owner_id): it moves, turns and is copied with it,
it is never cut nor exported to the cutting files. It is shown on the « Préparations » layer: a
light pink (parage) or light blue (teinte) fill under the lines, and a centred label such as
« PARAGE PINCE 8 à 6/10 », « PARAGE REMBORD 7 » or « TEINTE »."""
import math
from cad import polygon

KINDS=('parage','teinte')
TITLES={'parage':'Parage','teinte':'Teinte','surcoupe':'Surcoupe'}
# 0.18.1: « Surcoupe » is not skiving: it is its own zone, made by « Précoupe en série » (surcoupe.py)
# or read from Mozart (P_07); a zone typed Parage / Surcoupe before becomes one (doc_files.current_zones).
PARAGE_TYPES=('Rembord','Pince','Biseau')   # 0.19.14: Biseau (« il faudra prendre en compte si c'est un parage biseau ou un rembord »)
BASE={'parage':'#ff8cc6','teinte':'#86c8ff','surcoupe':'#a9b4ff','autre':'#c9b3ff'}
ALPHA=.5


def fmt(v):
    if v is None or v=='':return ''
    v=float(v);return f'{v:.1f}'.rstrip('0').rstrip('.').replace('.',',')


def label(kind,type_='',length=None,thickness=None):
    """« PARAGE PINCE 8 à 6/10 », « PARAGE REMBORD 7 », « TEINTE », « SURCOUPE 5 »."""
    if kind=='teinte':return ' '.join(['TEINTE']+([type_.upper()] if type_ else []))
    if kind=='surcoupe':return ' '.join(v for v in ('SURCOUPE',fmt(length)) if v)
    if kind!='parage':return (type_ or kind or '').upper()   # 0.19.9: a Mozart « autre » zone keeps its own name (its type holds its whole text), never « PARAGE »
    text=' '.join(v for v in ('PARAGE',(type_ or '').upper(),fmt(length)) if v)
    if thickness:text+=f' à {fmt(thickness)}/10'
    return text


def blend(color,background,alpha=ALPHA):
    """The fill as seen through: a pastel mixed with the canvas colour (Tk has no transparency;
    the lines are drawn over it)."""
    a=[int(color[i:i+2],16) for i in (1,3,5)];b=[int(background[i:i+2],16) for i in (1,3,5)]
    return '#'+''.join(f'{round(alpha*x+(1-alpha)*y):02x}' for x,y in zip(a,b))


def fill_colour(kind,background):
    try:return blend(BASE.get(kind,BASE['autre']),background)
    except (ValueError,TypeError,IndexError):return BASE.get(kind,BASE['autre'])


def keyhole(points,holes):
    """One ring for a region with islands: each island joined by a hairline bridge from its
    nearest vertex to the nearest vertex already in the ring (the fill then leaves the island
    empty). 0.18.1: the islands turn the other way round from the outline (a nonzero fill, the
    PDF of the fiches, leaves them empty too) and the nearest vertices are found in a grid: a
    précoupe of 100 pieces is joined at once (it took up to half a minute)."""
    ring=[tuple(p) for p in points]
    holes=[[tuple(p) for p in hole] for hole in holes or [] if len(hole)>=3]
    if not holes or len(ring)<3:return ring
    def signed(pts):return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1]))
    turn=signed(ring)>=0
    holes=[h if (signed(h)>=0)!=turn else h[::-1] for h in holes]
    xy=list(ring);nxt=list(range(1,len(ring)))+[0]   # the ring as linked nodes
    every=ring+[q for h in holes for q in h]
    x0=min(q[0] for q in every);y0=min(q[1] for q in every)
    span=max(max(q[0] for q in every)-x0,max(q[1] for q in every)-y0,1e-9)
    cell=span/max(1.,math.sqrt(len(every)));top=int(span/cell)+2;grid={}
    def key(q):return int((q[0]-x0)//cell),int((q[1]-y0)//cell)
    def add(k):grid.setdefault(key(xy[k]),[]).append(k)
    for k in range(len(xy)):add(k)
    def nearest(q,limit):
        cx,cy=key(q);best=(limit,None)
        for r in range(top+1):
            if r and (r-1)*cell>best[0]:break   # every further cell is farther than the best
            for gx in range(cx-r,cx+r+1):
                for gy in ((cy-r,cy+r) if r and cx-r<gx<cx+r else range(cy-r,cy+r+1)):
                    for k in grid.get((gx,gy),()):
                        d=math.dist(xy[k],q)
                        if d<best[0]:best=(d,k)
        return best
    for h in holes:
        best=(math.inf,None,0)
        for j,q in enumerate(h):
            d,k=nearest(q,best[0])
            if k is not None and d<best[0]:best=(d,k,j)
        _,k,j=best
        if k is None:continue
        loop=h[j:]+h[:j]+[h[j],xy[k]]   # around the island, then back to the ring's vertex
        start=len(xy);after=nxt[k];nxt[k]=start
        for n,q in enumerate(loop):
            xy.append(q);nxt.append(start+n+1 if n<len(loop)-1 else after)
        for n in range(len(h)):add(start+n)   # its vertices may take the next bridges
    out=[];k=0
    while True:
        out.append(xy[k]);k=nxt[k]
        if k==0 or len(out)>len(xy):break
    return out


def zone(region,prep,owner=None):
    """The zone item for a region (regions.region_at) and its preparation dict."""
    pts=keyhole(region['points'],region.get('holes'))
    z=polygon(pts,'Préparation',True)
    z['style']=dict(color=BASE.get(prep['kind'],BASE['autre']),width=.1,dash=[],role='preparation')
    z['preparation']=dict(prep,label=label(prep['kind'],prep.get('type',''),prep.get('length'),prep.get('thickness')))
    if owner:z['owner_id']=owner
    return z


def ring_points(s):
    """The outline of a zone (its arcs sampled, for zones read from Mozart)."""
    if s.get('bulges') and any(s['bulges']):
        from geometry import path
        return list(path(s)[0])
    return [(s['x']+x,s['y']+y) for x,y in s['points']]


def inside(pts,p):
    result=False;x,y=p
    for a,b in zip(pts,pts[1:]+pts[:1]):
        if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:result=not result
    return result


def area(pts):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1])))/2


_PLACES={}


def placement(s):
    """0.18.1: cached, the label place depends only on the zone (not on the view): zooming a
    Mozart pattern no longer recomputes every zone on every wheel notch."""
    from geometry import geometry_key
    key=(geometry_key(s),(s.get('preparation') or {}).get('width'))
    found=_PLACES.get(key)
    if found is None:
        if len(_PLACES)>2000:_PLACES.clear()
        found=_PLACES[key]=_placement(s)
    return found


def _placement(s):
    """Where the label goes: the centre of the zone along its long axis, and its height."""
    pts=ring_points(s);n=len(pts)
    A=0.;cx=cy=0.
    for a,b in zip(pts,pts[1:]+pts[:1]):
        c=a[0]*b[1]-b[0]*a[1];A+=c;cx+=(a[0]+b[0])*c;cy+=(a[1]+b[1])*c
    if abs(A)<1e-12:return pts[0],0.,1.
    cx/=3*A;cy/=3*A;A=abs(A)/2
    # Long axis from the second moments of the AREA (not of the outline points, denser on arcs).
    ixx=iyy=ixy=0.
    for a,b in zip(pts,pts[1:]+pts[:1]):
        c=a[0]*b[1]-b[0]*a[1]
        ixx+=(a[0]*a[0]+a[0]*b[0]+b[0]*b[0])*c;iyy+=(a[1]*a[1]+a[1]*b[1]+b[1]*b[1])*c
        ixy+=(a[0]*b[1]+2*a[0]*a[1]+2*b[0]*b[1]+b[0]*a[1])*c
    signed=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1]))/2
    sxx=ixx/12/signed-cx*cx;syy=iyy/12/signed-cy*cy;sxy=ixy/24/signed-cx*cy
    # Screen angle (y down): a band's label follows the band; a broad zone gets a level label.
    half=(sxx+syy)/2;root=math.sqrt(((sxx-syy)/2)**2+sxy**2)
    angle=-math.degrees(.5*math.atan2(2*sxy,sxx-syy)) if half-root<=1e-12 or (half+root)/(half-root)>6.25 else 0.
    if angle>90:angle-=180
    if angle<=-90:angle+=180
    width=(s.get('preparation') or {}).get('width')
    if not width:
        perimeter=sum(math.dist(a,b) for a,b in zip(pts,pts[1:]+pts[:1]));d=(perimeter/2)**2-4*A
        width=(perimeter/2-math.sqrt(d))/2 if d>0 else math.sqrt(A)
    centre=(cx,cy)
    if not inside(pts,centre):
        # A bent band (or a ring): the middle of the band nearest to the centroid. 0.18.1: the
        # places tried from the nearest, the first inside wins (the band of a large précoupe
        # has thousands of points: testing every place froze Craft for a minute).
        tried=[]
        for a,b in zip(pts,pts[1:]+pts[:1]):
            m=((a[0]+b[0])/2,(a[1]+b[1])/2);dx,dy=b[0]-a[0],b[1]-a[1];L=math.hypot(dx,dy)
            if L<1e-9:continue
            for sign in (1,-1):
                q=(m[0]-sign*dy/L*width/2,m[1]+sign*dx/L*width/2)
                tried.append((math.dist(q,(cx,cy)),q,math.degrees(math.atan2(-dy,dx))))
        tried.sort(key=lambda c:c[0])
        for _,q,turn in tried:
            if inside(pts,q):
                centre=q;angle=turn
                if angle>90:angle-=180
                if angle<=-90:angle+=180
                break
    return centre,angle,max(1.,min(4.,width*.55))


def zones_of(items,owner):
    return [s for s in items if s.get('preparation') and s.get('owner_id')==owner]


def rows(items,kind):
    """Lines of the Parage / Teinte fiche: piece, quantity, type, length, thickness."""
    from entity_rules import piece_labels,closed_piece
    pieces={s.get('piece_id'):i for i,s in enumerate(items) if s.get('piece_id') and closed_piece(s)}
    out=[]
    for s in items:
        prep=s.get('preparation')
        if not prep or prep.get('kind')!=kind:continue
        host=pieces.get(s.get('owner_id'));name,count,material='—','',''
        if host is not None:
            from export_check import piece_name
            name=piece_name(items,host);found=piece_labels(items,host).get('material')
            if found:
                data=items[found[0]].get('identification') or {};count=str(data.get('quantity','') or '');material=(data.get('values') or [''])[0]
        out.append(dict(piece=name,quantity=count,material=material,type=prep.get('type',''),length=prep.get('length'),thickness=prep.get('thickness'),label=prep.get('label','')))
    return sorted(out,key=lambda r:(r['piece'],r['type'],r['length'] or 0))
