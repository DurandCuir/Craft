"""0.18.5 (n° 6): zoom from 0,002 to 2 000 px/mm.

Past 80 px/mm the plan is drawn with its curves cut finer (about a quarter of a pixel, for the screen
only), every line and filled zone clipped to the screen plus a margin before Tk and the smoothing get
it (no coordinates in the millions), and the texts larger than the screen are not shown."""
import math

MIN_SCALE = .002    # ±100 m of drawing fit on a screen (Cadrer always shows everything)
MAX_SCALE = 2000
FINE_FROM = 80


def clamp(scale):
    return max(MIN_SCALE, min(MAX_SCALE, scale))


def tolerance(scale):
    """The cut of the curves on screen: 0,005 mm halved until it is about a quarter of a pixel."""
    k = max(1, math.ceil(math.log2(.005 * scale / .25)))
    return .005 / 2 ** k


def _numbers(args):
    out = []
    for a in args:
        if isinstance(a, (list, tuple)):
            out += _numbers(a)
        else:
            out.append(float(a))
    return out


def _segment(a, b, box):
    """Liang–Barsky: the part of a→b inside box, or None."""
    x0, y0, x1, y1 = box
    t0, t1 = 0., 1.
    dx, dy = b[0] - a[0], b[1] - a[1]
    for p, q in ((-dx, a[0] - x0), (dx, x1 - a[0]), (-dy, a[1] - y0), (dy, y1 - a[1])):
        if p == 0:
            if q < 0:
                return None
            continue
        r = q / p
        if p < 0:
            if r > t1:
                return None
            t0 = max(t0, r)
        else:
            if r < t0:
                return None
            t1 = min(t1, r)
    return (a[0] + t0 * dx, a[1] + t0 * dy), (a[0] + t1 * dx, a[1] + t1 * dy)


def runs(points, box):
    """The visible pieces of a polyline (lists of points), each inside box."""
    out, cur = [], []
    for a, b in zip(points, points[1:]):
        part = _segment(a, b, box)
        if part is None:
            if len(cur) >= 2:
                out.append(cur)
            cur = []
            continue
        p, q = part
        if cur and math.dist(cur[-1], p) < 1e-6:
            cur.append(q)
        else:
            if len(cur) >= 2:
                out.append(cur)
            cur = [p, q]
    if len(cur) >= 2:
        out.append(cur)
    return out


def polygon(points, box):
    """Sutherland–Hodgman: the polygon cut to box."""
    x0, y0, x1, y1 = box
    edges = ((lambda p: p[0] >= x0, lambda a, b: _at_x(a, b, x0)), (lambda p: p[0] <= x1, lambda a, b: _at_x(a, b, x1)),
             (lambda p: p[1] >= y0, lambda a, b: _at_y(a, b, y0)), (lambda p: p[1] <= y1, lambda a, b: _at_y(a, b, y1)))
    out = list(points)
    for inside, cut in edges:
        if not out:
            break
        pts, out = out, []
        for k, b in enumerate(pts):
            a = pts[k - 1]
            if inside(b):
                if not inside(a):
                    out.append(cut(a, b))
                out.append(b)
            elif inside(a):
                out.append(cut(a, b))
    return out


def _at_x(a, b, x):
    t = (x - a[0]) / (b[0] - a[0])
    return (x, a[1] + t * (b[1] - a[1]))


def _at_y(a, b, y):
    t = (y - a[1]) / (b[1] - a[1])
    return (a[0] + t * (b[0] - a[0]), y)


def _out_of_sight(kw):
    """An empty item far out of sight, hidden; 0.18.7: tagged « offscreen », never smoothed (so never
    shown again by show_raw)."""
    kw = dict(kw or {})
    tags = kw.get('tags', ())
    tags = (tags,) if isinstance(tags, str) else tuple(tags or ())
    return dict(kw, state='hidden', tags=tags + ('offscreen',))


class drawing:
    """Context of one full drawing of the plan past FINE_FROM px/mm."""

    def __init__(self, app, fine=True):
        self.app = app
        self.fine = fine   # False: clipping only, the computations keep the usual curves (pointer moves)
        self.active = app.scale > FINE_FROM and 'canvas' in app.__dict__

    def __enter__(self):
        if not self.active:
            return self
        import geometry
        c = self.app.canvas
        self.tolerance = geometry.display_tolerance(tolerance(self.app.scale) if self.fine else geometry._DISPLAY_TOL[0])
        self.tolerance.__enter__()
        self.wrapped = not c.__dict__.get('_deep_zoom')
        if not self.wrapped:   # already clipped by an outer drawing
            return self
        c._deep_zoom = True
        W, H = max(100, c.winfo_width()), max(100, c.winfo_height())
        m = max(W, H)
        box = (-m, -m, W + m, H + m)
        limit = 2 * max(W, H)
        self.previous = c.__dict__.get('_create')
        original = c._create

        def create(kind, args, kw, original=original):
            if kind in ('line', 'polygon'):
                try:
                    flat = _numbers(args)
                except (TypeError, ValueError):
                    return original(kind, args, kw)
                pts = list(zip(flat[0::2], flat[1::2]))
                if all(box[0] <= x <= box[2] and box[1] <= y <= box[3] for x, y in pts):
                    return original(kind, args, kw)
                if kind == 'polygon':
                    cut = polygon(pts, box)
                    if len(cut) >= 3:
                        return original(kind, tuple(v for p in cut for v in p), kw)
                else:
                    first = None
                    for run in runs(pts, box):
                        item = original(kind, tuple(v for p in run for v in p), kw)
                        first = item if first is None else first
                    if first is not None:
                        return first
                # Nothing on the screen: an empty item of the same kind far out of sight (callers may use its id).
                far = (box[0], box[1]) * (3 if kind == 'polygon' else 2)
                return original(kind, far, _out_of_sight(kw))
            if kind == 'oval':
                try:
                    x0, y0, x1, y1 = _numbers(args)[:4]
                except (TypeError, ValueError):
                    return original(kind, args, kw)
                if box[0] <= min(x0, x1) and max(x0, x1) <= box[2] and box[1] <= min(y0, y1) and max(y0, y1) <= box[3]:
                    return original(kind, args, kw)
                # A circle larger than the screen (mèche seen very close): drawn as its visible arcs.
                cx, cy, rx, ry = (x0 + x1) / 2, (y0 + y1) / 2, abs(x1 - x0) / 2, abs(y1 - y0) / 2
                n = max(64, min(4000, int(math.pi * max(rx, ry) / 2)))
                ring = [(cx + rx * math.cos(2 * math.pi * k / n), cy + ry * math.sin(2 * math.pi * k / n)) for k in range(n + 1)]
                opts = dict(kw or {})
                if opts.get('fill'):
                    cut = polygon(ring[:-1], box)
                    if len(cut) >= 3:
                        return original('polygon', tuple(v for p in cut for v in p), opts)
                    return original('polygon', (box[0], box[1]) * 3, _out_of_sight(opts))
                line = {k: v for k, v in opts.items() if k in ('width', 'tags', 'state', 'dash')}
                line['fill'] = opts.get('outline', 'black')
                first = None
                for run in runs(ring, box):
                    item = original('line', tuple(v for p in run for v in p), line)
                    first = item if first is None else first
                return first if first is not None else original('line', (box[0], box[1]) * 2, _out_of_sight(line))
            if kind == 'text':
                font = (kw or {}).get('font')
                try:
                    size = abs(int(font[1])) if isinstance(font, (tuple, list)) and len(font) > 1 else 0
                except (TypeError, ValueError):
                    size = 0
                if size > limit:
                    kw = dict(kw, state='hidden', font=(font[0], -limit) + tuple(font[2:]))
            return original(kind, args, kw)
        c._create = create
        return self

    def __exit__(self, *exc):
        if not self.active:
            return False
        self.tolerance.__exit__(*exc)
        if not self.wrapped:
            return False
        c = self.app.canvas
        c._deep_zoom = False
        if self.previous is None:
            c.__dict__.pop('_create', None)
        else:
            c._create = self.previous
        return False
