"""Native mirror, guided contour traversal and tangent circular raccords."""
import copy,math
from geometry import path,distance,clone,outline_chords,crossing_pairs,outline_area
from cad import polygon,shape,intersections
from curves import arc,decompose,compound,reverse,cubics,from_cubics,parts
from precision_geometry import canonical,primitives,at_primitive,contour_length,contour_location,contour_slice,ellipse
from editing import inherit,corner_lines,corner_poly,straight_ends,parallel,parallel_corner,STRAP,strap_lines,open_end_side,parallel_sides,close_open_end
EPS=1e-6

def mirror(s,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1];length=math.hypot(dx,dy)
    if length<EPS:raise ValueError('Définissez un axe avec deux points distincts.')
    ux,uy=dx/length,dy/length
    def point(p):
        x,y=p[0]-a[0],p[1]-a[1];t=x*ux+y*uy
        return a[0]+2*t*ux-x,a[1]+2*t*uy-y
    if s.get('components'):q=compound([mirror(c,a,b) for c in parts(s)],s['name'],s.get('closed',False))
    elif s.get('spline'):q=from_cubics([[point(p) for p in c] for c in cubics(s)],s.get('closed',False),s['name'])
    elif s.get('ellipse'):
        e=s['ellipse'];c=point((s['x'],s['y']));angle=2*math.atan2(dy,dx)-e['angle']
        q=ellipse(c,e['rx'],e['ry'],angle,-e['start']-e['sweep'],e['sweep'],s['name']);q['reversed']=not s.get('reversed',False)
    elif s['kind']=='circle':
        c=point((s['x']+s['w']/2,s['y']+s['h']/2));q=clone(s);q.update(x=c[0]-s['w']/2,y=c[1]-s['h']/2)
    elif s['kind']=='line':
        A,B=map(point,path(s)[0]);q=shape('line',s['name'],*A,B[0]-A[0],B[1]-A[1])
    else:
        native=canonical(s);pts,closed=path(native) if native['kind']!='poly' else ([(native['x']+x,native['y']+y) for x,y in native['points']],native.get('closed',False))
        q=polygon([point(p) for p in pts],s['name'],closed)
        if native.get('bulges'):q['bulges']=[-v for v in native['bulges']]
    inherit(q,s)
    if s.get('annotation'):
        q=clone(s);q['x'],q['y']=point((s['x'],s['y']));q['text_angle']=-s.get('text_angle',0)+2*math.degrees(math.atan2(dy,dx))
        if s.get('points'):q['points']=[[point((s['x']+x,s['y']+y))[0]-q['x'],point((s['x']+x,s['y']+y))[1]-q['y']] for x,y in s['points']]
        for run in q.get('text_runs',[]):run['dy']=-run['dy']
        if 'text_offset' in s:
            pos=point((s['x']+s['text_offset'][0],s['y']+s['text_offset'][1]));q['text_offset']=[pos[0]-q['x'],pos[1]-q['y']]
    if s.get('notches'):
        from craft_tools import at_distance
        q['notches']=[]
        for mark in s['notches']:
            pt,n=at_distance(s,mark['distance']);direction=mark.get('direction',[n[0]*mark.get('side',1),n[1]*mark.get('side',1)])
            origin=point((0,0));end=point(tuple(direction));direction=[end[0]-origin[0],end[1]-origin[1]]
            m=clone(mark);m.update(distance=contour_location(q,point(pt))[0],direction=direction)
            _,normal=at_distance(q,m['distance']);m['side']=1 if sum(a*b for a,b in zip(normal,direction))>=0 else -1;q['notches'].append(m)
    return q

def mirror_readable(s,a,b):
    """0.19.22 (found before installing: the names of a piece turned by Symétrie came out upside down, or their lines
    in the reverse order): Symétrie keeps a text readable, as AutoCAD (MIRRTEXT 0): the text itself, its lines in
    their order, along the mirrored direction turned the right way up, where its mirror image is (its middle there).
    (mirror() turns a text over: pdf_layout.rotate makes its turns of two of them.)"""
    q=mirror(s,a,b)
    if not s.get('annotation'):return q
    from geometry import bounds
    from transform import transform
    angle=q.get('text_angle',0)%360
    if 90<angle<=270:angle-=180
    elif angle>270:angle-=360
    r=transform(s,(s['x'],s['y']),s.get('text_angle',0)-angle)   # turned about its anchor to that direction
    r['text_angle']=round(angle,9)+0.
    x0,y0,x1,y1=bounds([q]);X0,Y0,X1,Y1=bounds([r])
    r['x']+=(x0+x1-X0-X1)/2;r['y']+=(y0+y1-Y0-Y1)/2
    return r


def side_parts(s):
    if not __import__('entity_rules').geometry_entity(s):raise ValueError('Sélectionner ligne/polyligne')
    if s.get('ellipse'):return [clone(s)]
    return decompose(s) if s.get('closed') or s.get('components') or s['kind']=='rect' else [clone(s)]

def selected_part(s,p):
    ps=side_parts(s)
    return ps,min(range(len(ps)),key=lambda i:math.dist(contour_location(ps[i],p)[1],p))

def loci(edge,r):
    if edge['sweep']:
        return [('circle',edge['c'],v) for v in (edge['r']+r,abs(edge['r']-r)) if v>EPS]
    a,b=edge['a'],edge['b'];n=math.dist(a,b);v=(-(b[1]-a[1])/n,(b[0]-a[0])/n)
    return [('line',(a[0]+sign*r*v[0],a[1]+sign*r*v[1]),(b[0]+sign*r*v[0],b[1]+sign*r*v[1])) for sign in (-1,1)]

def locus_hits(l,m):
    if l[0]=='line' and m[0]=='line':
        from editing import line_intersection
        try:return [line_intersection(l[1],l[2],m[1],m[2])]
        except ValueError:return []
    if l[0]=='circle' and m[0]=='line':return locus_hits(m,l)
    if l[0]=='line':
        a,b=l[1:];c,r=m[1:];u=(b[0]-a[0],b[1]-a[1]);n=math.hypot(*u);u=(u[0]/n,u[1]/n);t=(c[0]-a[0])*u[0]+(c[1]-a[1])*u[1];h=(a[0]+t*u[0],a[1]+t*u[1]);v=r*r-math.dist(h,c)**2
        if v< -EPS:return []
        d=math.sqrt(max(0,v));return [(h[0]+sign*d*u[0],h[1]+sign*d*u[1]) for sign in (-1,1)]
    c,r=l[1:];C,R=m[1:];d=math.dist(c,C)
    if d<EPS or d>r+R+EPS or d<abs(r-R)-EPS:return []
    x=(r*r-R*R+d*d)/(2*d);h=math.sqrt(max(0,r*r-x*x));u=((C[0]-c[0])/d,(C[1]-c[1])/d)
    return [(c[0]+x*u[0]-sign*h*u[1],c[1]+x*u[1]+sign*h*u[0]) for sign in (-1,1)]

def tangent(edge,c):
    if edge['sweep']:
        d=math.dist(edge['c'],c)
        return (edge['c'][0]+(c[0]-edge['c'][0])*edge['r']/d,edge['c'][1]+(c[1]-edge['c'][1])*edge['r']/d)
    a,b=edge['a'],edge['b'];dx,dy=b[0]-a[0],b[1]-a[1];t=((c[0]-a[0])*dx+(c[1]-a[1])*dy)/(dx*dx+dy*dy)
    return a[0]+t*dx,a[1]+t*dy

def cut_end(s,t,p,junction=None):
    total=contour_length(s);d=contour_location(s,t)[0];clicked=contour_location(s,p)[0]
    if min(d,total-d)<EPS:raise ValueError('Le raccord doit être à l’intérieur du tracé choisi.')
    # Pick the retained ray relative to the original intersection, never the
    # tangent: the click may lie inside the small span about to be removed.
    reference=contour_location(s,junction)[0] if junction is not None else d
    keep_start=clicked<reference if EPS<reference<total-EPS else reference>=total-EPS
    return contour_slice(s,0,d) if keep_start else contour_slice(s,d,total)

def raccord(s,t,p,q,mode,r,contacts=()):
    """Two independent entities stay independent; only the new raccord is added. 0.18.5:
    ``contacts``, the ends of the drawing's other lines with their direction (see raccord_parts)."""
    return raccord_parts(s,t,p,q,mode,r,contacts)[0]

def direction_at(v,d):
    """0.18.5: unit direction of travel of ``v`` at the distance ``d`` along it."""
    travel=0;es=primitives(v)
    for e in es:
        if d<=travel+e['length']+1e-9 or e is es[-1]:
            if not e['sweep']:n=e['length'];return (e['b'][0]-e['a'][0])/n,(e['b'][1]-e['a'][1])/n
            k=1 if e['sweep']>0 else -1;angle=e['start']+e['sweep']*max(0,min(1,(d-travel)/e['length']))
            return -k*math.sin(angle),k*math.cos(angle)
        travel+=e['length']
    raise ValueError('Contour vide.')

def beyond_end(v,e,X):
    """0.18.5 (n° 26): (end, piece, outward direction at X, length added) when X lies on the line or
    the circle of ``e`` beyond a free end of the open contour ``v`` whose end piece ``e`` belongs to
    (a line stopping before a circle is lengthened up to the raccord); None otherwise."""
    from precision_geometry import piece_runs
    es=primitives(v);runs=piece_runs(es);k=next((n for n,f in enumerate(es) if f is e or f==e),None)
    if k is None:return None
    out=None
    for which,run in (('start',runs[0]),('end',runs[-1])):
        if k not in run:continue
        g=es[run[0]] if which=='start' else es[run[-1]];found=None
        if not g['sweep']:
            end=g['a'] if which=='start' else g['b'];u=(g['a'][0]-g['b'][0],g['a'][1]-g['b'][1]) if which=='start' else (g['b'][0]-g['a'][0],g['b'][1]-g['a'][1])
            n=math.hypot(*u);u=(u[0]/n,u[1]/n);added=(X[0]-end[0])*u[0]+(X[1]-end[1])*u[1]
            if added>EPS and abs((X[0]-end[0])*u[1]-(X[1]-end[1])*u[0])<1e-6:found=(which,g,u,added)
        else:
            sweep=sum(es[n]['sweep'] for n in run);sigma=(1 if sweep>0 else -1)*(-1 if which=='start' else 1)
            edge=g['start'] if which=='start' else g['start']+g['sweep'];theta=math.atan2(X[1]-g['c'][1],X[0]-g['c'][0])
            delta=((theta-edge)*sigma)%(2*math.pi)
            if abs(math.dist(X,g['c'])-g['r'])<1e-6 and EPS<delta<2*math.pi-abs(sweep)-1e-3:
                found=(which,g,(-sigma*math.sin(theta),sigma*math.cos(theta)),delta*g['r'])
        # 0.19.20 (« le second est aberrant et énorme », 09/11/2026): a point just before the START of an arc is also
        # reachable from its END, the long way round its circle (308° instead of 2°): the shorter one is taken.
        if found and (out is None or found[3]<out[3]):out=found
    return out

def lengthened(v,reach,X):
    """0.18.5 (n° 26): the open contour ``v`` lengthened from one end up to X, on the line or the
    circle of its end piece (beyond_end); crans keep their place."""
    which,g,_,added=reach
    if v['kind']=='line':
        a,b=path(v)[0];q=copy.deepcopy(v);A,B=(X,b) if which=='start' else (a,X);q.update(x=A[0],y=A[1],w=B[0]-A[0],h=B[1]-A[1])
    else:
        V=[(v['x']+x,v['y']+y) for x,y in v['points']];bs=(list(v.get('bulges') or [])+[0]*len(V))[:len(V)]
        bulge=math.tan(math.copysign(added/g['r'],g['sweep'])/4) if g['sweep'] else 0
        if not g['sweep']:
            if which=='start':V[0]=X
            else:V[-1]=X
        elif which=='start':V=[X]+V;bs=[bulge]+bs
        else:V=V+[X];bs=bs[:-1]+[bulge,0.]
        q=polygon(V,v['name'],False);q.update({k:copy.deepcopy(w) for k,w in v.items() if k not in ('kind','x','y','w','h','r','points','closed','bulges','name')})
        if any(bs):q['bulges']=bs
    if which=='start' and q.get('notches'):q['notches']=[dict(m,distance=m['distance']+added) for m in q['notches']]
    return q

def raccord_parts(s,t,p,q,mode,r,contacts=(),extent=()):
    """The raccord (see raccord) and the portions of the two picked sides it removes.
    0.18.5 (n° 26): the forms need not cross. A line (or an open contour) may be lengthened up to
    the raccord, which is then tangent to its prolongation; a closed form the other one does not
    cross (a circle beside the line, or inside a rectangle) stays whole, unless ``contacts`` (ends
    of the drawing's other lines, (point, direction)) touch it tangentially (a first raccord): it is
    then cut there, the piece between the two raccords goes."""
    ends_s,ends_t=straight_ends(s),straight_ends(t)
    if ends_s and ends_t and parallel(*ends_s,*ends_t):
        # 0.19.2: two parallel sides (lines or cut lines): a quarter round, a perpendicular or a 45° side.
        # 0.19.3: or the end of a strap (half round, point). 0.19.6: the radius set (strap_lines: the tip of
        # an end done there before, ``extent``).
        return decompose(strap_lines(s,t,p,q,mode,r,extent) if mode in STRAP else parallel_corner(s,t,p,q,mode,r)),[]
    sides=parallel_sides(s,t,p,q,mode,r,extent)   # 0.19.5: one (or both) the straight end side of an open polyline
    if sides is not None:return sides,[]
    if mode not in STRAP:
        done=parallel_to_piece(s,t,p,q,mode,r)   # 0.19.6: a line and the parallel side of a piece
        if done is not None:return done,[]
    if mode in STRAP:raise ValueError('Bout de sangle : cliquez le petit côté d’une pièce, ou deux bords parallèles.')
    if mode=='fillet' and s['kind']=='circle' and ends_t:
        done=circle_to_side(s,t,p,q,r)
        if done is not None:return done
    if s['kind']=='line' and t['kind']=='line':
        joined=corner_lines(s,t,p,q,mode,r)
        return decompose(joined),[]
    if mode!='fillet' and (s.get('spline') or t.get('spline') or s.get('ellipse') or t.get('ellipse')):
        return curve_corner(s,t,p,q,mode,r),[]   # 0.19.7: Chanfrein / Angle droit with a spline or an oval
    if mode!='fillet':
        # 0.19.6: the side of a piece (a closed one, or a side between two others of an open polyline): the
        # piece opened (cut) at the end of that side the raccord moves; its other sides stay one contour.
        rest=[]
        if piece_like(s) or piece_like(t):
            if closed_form(s) and closed_form(t):raise ValueError('Choisir une ligne ou le côté au bout d’une polyligne.')
            from editing import straight_side_at,opened_at,line_intersection
            S,T=straight_side_at(s,p),straight_side_at(t,q)
            if S and T and not parallel(*S,*T):
                I=line_intersection(*S,*T)
                if piece_like(s):s,more=opened_at(s,p,I);rest+=[more] if more else []
                if piece_like(t):t,more=opened_at(t,q,I);rest+=[more] if more else []
        return straight_corner(s,t,p,q,mode,r)+rest,[]   # 0.16.31: cut lines, polyline ends
    ss,i=selected_part(s,p);tt,j=selected_part(t,q);S,T=ss[i],tt[j]
    # Circular quadrants of a closed circle must be considered as one full circle.
    if s['kind']=='circle':S=canonical(s);ss=[S];i=0
    if t['kind']=='circle':T=canonical(t);tt=[T];j=0
    # 0.19.7: a closed spline or oval too (it stays whole when the other side does not cross it, like a circle)
    if (s.get('spline') or s.get('ellipse')) and closed_form(s):S=s;ss=[S];i=0
    if (t.get('spline') or t.get('ellipse')) and closed_form(t):T=t;tt=[T];j=0
    def edge(v,click):
        es=primitives(v)
        return min(es,key=lambda e:min(math.dist(click,at_primitive(e,k/32)) for k in range(33)))
    # 0.18.5: only a whole open line, polyline or arc can be lengthened (never a side of a closed form).
    free=lambda v:not closed_form(v) and not v.get('components') and not v.get('spline') and not v.get('ellipse')
    reachS=reachT=None
    curved=lambda v:v.get('ellipse') or v.get('spline')
    if curved(S) or curved(T):
        from native_edit import tangent_fillet
        # 0.19.7: a spline too (« ça veut pas raccord arrondi avec spline »); the other side by its piece
        # nearest the click (the side of a polyline; a circle or one arc whole).
        pieces={}
        def solver(v,source,click,other):
            if curved(v):return v
            e=pieces[id(v)]=nearest_piece(v,click)
            if e is v or e['sweep'] or not free(source):return e
            # a free straight side may be lengthened up to the raccord (n° 26): its line, far enough both ways
            from geometry import bounds
            x0,y0,x1,y1=bounds([other]);far=math.dist(e['a'],((x0+x1)/2,(y0+y1)/2))+math.hypot(x1-x0,y1-y0)+4*r
            u=((e['b'][0]-e['a'][0])/e['length'],(e['b'][1]-e['a'][1])/e['length'])
            return dict(e,a=(e['a'][0]-u[0]*far,e['a'][1]-u[1]*far),b=(e['b'][0]+u[0]*far,e['b'][1]+u[1]*far),length=e['length']+2*far)
        try:c,A,B=tangent_fillet(solver(S,s,p,T),solver(T,t,q,S),p,q,r)
        except ValueError:raise ValueError('Aucun raccord possible à ce rayon sur ces portions.') from None
        for v,source,X in ((S,s,A),(T,t,B)):
            if curved(v) or math.dist(contour_location(v,X)[1],X)<=.005:continue
            reach=beyond_end(v,pieces[id(v)],X) if free(source) and pieces.get(id(v)) is not v else None
            if reach is None:raise ValueError('Aucun raccord possible à ce rayon sur ces portions.')
            if v is S:reachS=reach
            else:reachT=reach
    else:
        e,f=edge(S,p),edge(T,q);candidates=[];found=False
        for l in loci(e,r):
            for m in loci(f,r):
                for c in locus_hits(l,m):
                    A,B=tangent(e,c),tangent(f,c)
                    if math.dist(A,B)<EPS:continue
                    if abs(math.dist(A,c)-r)>.001 or abs(math.dist(B,c)-r)>.001:continue
                    found=True;start=math.atan2(A[1]-c[1],A[0]-c[0]);sweep=math.atan2((A[0]-c[0])*(B[1]-c[1])-(A[1]-c[1])*(B[0]-c[0]),(A[0]-c[0])*(B[0]-c[0])+(A[1]-c[1])*(B[1]-c[1]))
                    k=1 if sweep>0 else -1;end=start+sweep
                    tauA=(-k*math.sin(start),k*math.cos(start));tauB=(-k*math.sin(end),k*math.cos(end))
                    ra=rb=None
                    if math.dist(contour_location(S,A)[1],A)>.005:
                        # The outline comes along the lengthened side and goes on into the raccord.
                        ra=beyond_end(S,e,A) if free(s) else None
                        if ra is None or tauA[0]*ra[2][0]+tauA[1]*ra[2][1]<=0:continue
                    if math.dist(contour_location(T,B)[1],B)>.005:
                        rb=beyond_end(T,f,B) if free(t) else None
                        if rb is None or tauB[0]*rb[2][0]+tauB[1]*rb[2][1]>=0:continue
                    score=math.dist(p,A)+math.dist(q,B)
                    # A raccord on the drawn sides first, as before; else on their prolongation.
                    candidates.append((ra is not None or rb is not None,score,c,A,B,ra,rb))
        if not candidates:
            raise ValueError('Rayon trop grand pour ces tracés.' if found else 'Aucun raccord possible à ce rayon sur ces portions.')
        _,_,c,A,B,reachS,reachT=min(candidates,key=lambda v:v[:2])
    start=math.atan2(A[1]-c[1],A[0]-c[0]);sweep=math.atan2((A[0]-c[0])*(B[1]-c[1])-(A[1]-c[1])*(B[0]-c[0]),(A[0]-c[0])*(B[0]-c[0])+(A[1]-c[1])*(B[1]-c[1]))
    bridge=inherit(arc(c,r,start,sweep,''),s)
    if reachS:S=ss[i]=lengthened(S,reachS,A)
    if reachT:T=tt[j]=lengthened(T,reachT,B)
    # Where the outline goes from each tangency point: back along the first side, on along the second.
    k=1 if sweep>0 else -1;end=start+sweep
    headS=(k*math.sin(start),-k*math.cos(start));headT=(-k*math.sin(end),k*math.cos(end))
    def toward(v,tan,head):
        """0.18.5: v cut at the tangency, keeping the part the outline goes on with."""
        total=contour_length(v);d=contour_location(v,tan)[0];w=direction_at(v,d)
        if w[0]*head[0]+w[1]*head[1]>0:
            if total-d<EPS:raise ValueError('Le raccord doit être à l’intérieur du tracé choisi.')
            return v if d<EPS else contour_slice(v,d,total)
        if d<EPS:raise ValueError('Le raccord doit être à l’intérieur du tracé choisi.')
        return v if total-d<EPS else contour_slice(v,0,d)
    def trimmed(v,tan,click,other,source_closed,head):
        hits=intersections(v,other)
        if not v.get('closed'):
            # 0.18.0: a side that only TOUCHES the other one by its end (a line stopping on a circle)
            # meets it at that end, even when the crossing is not computed: the kept part is then
            # always the one beyond the raccord, wherever the side was clicked.
            from cad import distance_to_shape
            ends=[e for e in (path(v)[0][0],path(v)[0][-1]) if distance_to_shape(e,other)<.05]
            hits=list(hits)+[e for e in ends if all(math.dist(e,h)>1e-6 for h in hits)]
            junction=min(hits,key=lambda x:math.dist(x,tan)) if hits else None
            # 0.18.5 (n° 26): the forms do not meet: the side keeps what the outline goes on with.
            if junction is None:return [toward(v,tan,head)]
            kept=[cut_end(v,tan,click,junction)]
            # A side selected inside a closed form may cross another form in
            # its middle. Preserve the opposite, unselected part of that side.
            if source_closed and junction is not None:
                length=contour_length(v);dI=contour_location(v,junction)[0];clicked=contour_location(v,click)[0]
                if EPS<dI<length-EPS:
                    kept.append(contour_slice(v,dI,length) if clicked<dI else contour_slice(v,0,dI))
            return kept
        if not hits:
            # 0.18.5 (n° 26): a closed form the other one does not cross stays whole; the end of an
            # earlier raccord on it (its tangent contact) cuts it like a crossing: the piece between
            # the two raccords goes.
            from geometry import bounds
            x0,y0,x1,y1=bounds([v])
            for x,u in contacts:
                if not (x0-.01<=x[0]<=x1+.01 and y0-.01<=x[1]<=y1+.01) or math.dist(x,tan)<.01:continue
                d,pt=contour_location(v,x)
                if math.dist(pt,x)>.005 or v.get('ellipse') or v.get('spline'):continue
                w=direction_at(v,d)
                if abs(w[0]*u[1]-w[1]*u[0])<1e-3:hits.append(x)   # tangent contact only
            if not hits:return None
        I=min(hits,key=lambda x:math.dist(x,tan));length=contour_length(v);d=contour_location(v,tan)[0];end=contour_location(v,I)[0]
        if (end-d)%length<length/2:return [contour_slice(v,end,d+length if d<end else d)]
        return [contour_slice(v,d,end+length if end<d else end)]
    keepS=trimmed(S,A,p,T,s.get('closed',False) or s['kind'] in ('rect','circle'),headS)
    keepT=trimmed(T,B,q,S,t.get('closed',False) or t['kind'] in ('rect','circle'),headT)
    # 0.18.5: a circle kept whole stays a circle.
    if keepS is None:keepS=[copy.deepcopy(s) if s['kind']=='circle' else S]
    if keepT is None:keepT=[copy.deepcopy(t) if t['kind']=='circle' else T]
    from curves import removed_portions
    masks=removed_portions(S,keepS)+removed_portions(T,keepT)
    ss[i:i+1]=keepS;tt[j:j+1]=keepT
    if closed_form(s) and closed_form(t):
        # 0.16.15: two closed forms (e.g. circle + rectangle). The raccord tells
        # which outline is drawn: union, notch or common part. Portions on the
        # other side of the other form are no longer part of it and are removed.
        half=start+sweep/2;M=(c[0]+r*math.cos(half),c[1]+r*math.sin(half))
        from precision_geometry import inside
        sources_s,sources_t=list(ss),list(tt)
        sides_s=split_sides(ss,t,True);sides_t=split_sides(tt,s,True)
        # Only forms that really overlap (each enters the other); touching forms
        # sharing an edge keep all their sides.
        if any(k=='in' for _,k,_ in sides_s) and any(k=='in' for _,k,_ in sides_t):
            want_t='in' if inside(t,M) else 'out';want_s='in' if inside(s,M) else 'out'
            restored=absorb_touching(sides_s,sides_t,s,t,A,B) if want_t==want_s=='out' else dict(s=set(),t=set())
            ss=kept_sides(sides_s,('on',want_t),restored['s'],sources_s);tt=kept_sides(sides_t,('on',want_s),restored['t'],sources_t)
    return remove_collinear_spans(ss+tt,masks)+[bridge],masks


def circle_to_side(s,t,p,q,r):
    """0.19.2: Arrondi from a circle clicked first to a straight side too far for a round tangent to
    both (the gap between them more than the round's diameter), like two parallel sides: a quarter
    round whose radius is the gap leaves the circle at its foot, along it, and reaches the side at a
    right angle, on the side of the line's click; the line goes on from there away from the round
    (lengthened up to there if it stops before). The circle stays whole. 0.19.6 (« raccord direct entre
    haut du cercle et la ligne où ça finit en angle droit »): at the radius set, when it is not larger than
    the gap: equal, the quarter round from the circle's top; smaller, that round then a straight side to
    the line. None when the line touches or crosses the circle, or the radius is larger than the gap (a
    strap end round from a circle inside it, n° 26): the usual tangent raccord."""
    O=(s['x']+s['w']/2,s['y']+s['h']/2);R=s['w']/2;c,d=straight_ends(t)
    lv=math.dist(c,d);v=((d[0]-c[0])/lv,(d[1]-c[1])/lv);at=lambda X:(X[0]-c[0])*v[0]+(X[1]-c[1])*v[1]
    F=(c[0]+at(O)*v[0],c[1]+at(O)*v[1]);h=math.dist(O,F);g=h-R
    rr=r if r and r>0 else g
    if g<=1e-6 or rr>g+1e-9:return None
    tF,tq=at(F),at(q)
    e=1 if tq>tF+1e-9 else -1 if tq<tF-1e-9 else (1 if at(p)>=tF else -1)
    nrm=((F[0]-O[0])/h,(F[1]-O[1])/h);A=(O[0]+nrm[0]*R,O[1]+nrm[1]*R)   # the circle's point nearest the line
    rr=min(rr,g);C=(A[0]+nrm[0]*rr,A[1]+nrm[1]*rr);X=(C[0]+e*rr*v[0],C[1]+e*rr*v[1]);B=(F[0]+e*rr*v[0],F[1]+e*rr*v[1])
    cross=(A[0]-C[0])*(X[1]-C[1])-(A[1]-C[1])*(X[0]-C[0]);sweep=math.copysign(math.pi/2,cross)
    if math.dist(X,B)>1e-6:   # the round, then straight to the line
        bridge=inherit(polygon([A,X,B],'',False),s);bridge['bulges']=[math.tan(sweep/4),0.,0.]
    else:bridge=inherit(arc(C,rr,math.atan2(A[1]-C[1],A[0]-C[0]),sweep,''),s)
    tB=at(B)
    ends=[(0.,c),(lv,d)];side=[x for x in ends if (x[0]-tB)*e>1e-4]
    keep=max(side or ends,key=lambda x:abs(x[0]-tB))[1]
    if math.dist(keep,B)<=1e-4:raise ValueError('Côté trop court pour cet arrondi.')
    piece=inherit(shape('line',t.get('name') or 'Ligne',B[0],B[1],keep[0]-B[0],keep[1]-B[1]),t)
    from curves import removed_portions
    return [copy.deepcopy(s),piece,bridge],removed_portions(t,[piece])


def corner_side(s,click):
    """0.16.31: the straight side picked for Angle droit / Chanfrein on a line, a cut line or an
    open polyline: its two ends and the end allowed to move ('start' / 'end' of the polyline,
    None for a single side)."""
    if s.get('notches'):raise ValueError('Modifiez les angles avant de poser les crans.')
    if s.get('spline') or s.get('ellipse') or s.get('components') or s['kind'] in ('circle','rect') or path(s)[1]:
        raise ValueError('Choisir une ligne ou le côté au bout d’une polyligne.')
    edges=primitives(s)
    if not edges:raise ValueError('Côté trop court.')
    def gap(e):
        if not e['sweep']:return distance(click,e['a'],e['b'])
        return min(math.dist(click,at_primitive(e,k/32)) for k in range(33))
    k=min(range(len(edges)),key=lambda j:gap(edges[j]))
    if edges[k]['sweep']:raise ValueError('Pour une courbe, utilisez Arrondi avec un rayon.')
    if len(edges)==1:return edges[k]['a'],edges[k]['b'],None
    if k==0:return edges[0]['a'],edges[0]['b'],'start'
    if k==len(edges)-1:return edges[k]['a'],edges[k]['b'],'end'
    raise ValueError('Choisir le côté au bout de la polyligne.')


def moved_end(s,move,fixed,end):
    """The side rebuilt from its kept end to its new end; a polyline keeps its other sides and arcs."""
    if move is None:   # a line, or a cut line (two-point polyline), becomes a plain line
        return inherit(shape('line',s.get('name') or 'Ligne',fixed[0],fixed[1],end[0]-fixed[0],end[1]-fixed[1]),s)
    V=[(s['x']+x,s['y']+y) for x,y in s['points']];B=(list(s.get('bulges') or [])+[0]*len(V))[:len(V)]
    if move=='start':
        m=next(i for i in range(1,len(V)) if math.dist(V[i],fixed)<1e-9);V2=[end]+V[m:];B2=[0]+B[m:]
    else:
        m=next(i for i in range(len(V)-2,-1,-1) if math.dist(V[i],fixed)<1e-9);V2=V[:m+1]+[end];B2=B[:m]+[0,0]
    new=polygon(V2,s['name'],False)
    new.update({k:copy.deepcopy(v) for k,v in s.items() if k not in ('kind','x','y','w','h','r','points','closed','bulges','name')})
    if any(B2):new['bulges']=B2
    return new


def straight_corner(s,t,p,q,mode,value):
    """0.16.31: Angle droit / Chanfrein when a side is not a plain line (a cut line, or the side at
    the end of an open polyline): each side is lengthened or shortened up to the corner."""
    from editing import line_intersection,corner_points
    from precision_geometry import without_micro
    s,t=without_micro(s),without_micro(t)
    a1,b1,move1=corner_side(s,p);a2,b2,move2=corner_side(t,q);I=line_intersection(a1,b1,a2,b2)
    def kept(a,b,move,click):
        if move=='start':return b
        if move=='end':return a
        vx,vy=click[0]-I[0],click[1]-I[1]   # a single side keeps its end on the clicked side
        return max((a,b),key=lambda z:(z[0]-I[0])*vx+(z[1]-I[1])*vy)
    F1,F2=kept(a1,b1,move1,p),kept(a2,b2,move2,q)
    for a,b,move,F in ((a1,b1,move1,F1),(a2,b2,move2,F2)):
        free=a if move=='start' else b
        if move and (I[0]-F[0])*(free[0]-F[0])+(I[1]-F[1])*(free[1]-F[1])<=EPS:raise ValueError('Côté trop court pour cet angle.')
    pts,_=corner_points(F1,I,F2,mode,value);E1,E2=(I,I) if mode=='corner' else (pts[1],pts[2])
    out=[moved_end(s,move1,F1,E1),moved_end(t,move2,F2,E2)]
    if mode!='corner':out.append(inherit(shape('line','Chanfrein',E1[0],E1[1],E2[0]-E1[0],E2[1]-E1[1]),s))
    else:
        from editing import tidy_corner
        out=[tidy_corner(q,I) for q in out]   # 0.18.0: no « mini-ligne » next to the corner
    return out


def closed_form(s):
    return s['kind'] in ('rect','circle') or bool(s.get('closed'))


def nearest_piece(v,click):
    """0.19.7: the piece of ``v`` nearest the click for the curve raccord (a circle, or an arc stored in
    quarters, stays whole)."""
    if v['kind']=='circle':return v
    es=primitives(v)
    if len(es)>1 and all(e['sweep'] and math.dist(e['c'],es[0]['c'])<1e-6 and abs(e['r']-es[0]['r'])<1e-6 for e in es):return v
    return min(es,key=lambda e:min(math.dist(click,at_primitive(e,k/32)) for k in range(33)))


def curve_corner(s,t,p,q,mode,value):
    """0.19.7: Angle droit / Chanfrein when a side is a spline (or an oval): the corner where the two meet
    (or where a straight side's prolongation reaches the curve), each side kept on its clicked side up to
    it; Chanfrein: cut at the distance set along each, joined by a straight side."""
    from cad import distance_to_shape
    from editing import straight_ends as straight
    def ends(v):
        pts=path(v)[0];return (pts[0],pts[-1]) if not closed_form(v) else ()
    hits=list(intersections(s,t))
    for v,w in ((s,t),(t,s)):
        hits+=[e for e in ends(v) if distance_to_shape(e,w)<.05 and all(math.dist(e,h)>1e-6 for h in hits)]
    if not hits:
        # a straight side lengthened up to the curve: its whole line against the other
        for v,w in ((s,t),(t,s)):
            E=straight(v)
            if not E:continue
            a,b=E;n=math.dist(a,b);u=((b[0]-a[0])/n,(b[1]-a[1])/n);far=1e5
            probe=shape('line','',a[0]-u[0]*far,a[1]-u[1]*far,u[0]*(2*far+n),u[1]*(2*far+n))
            hits+=list(intersections(probe,w))
    # A piece (a rectangle, a closed polyline, a polyline of several sides) clicked on a straight side: the corner
    # is where the curve meets that side (or its line), as with a line (0.19.6).
    from editing import opened_at,straight_side_at
    carriers={}   # the line a straight side is on (the corner may be on its prolongation)
    for v,w,click in ((s,t,p),(t,s,q)):
        S=straight_side_at(v,click) if piece_like(v) else straight(v)
        if S:
            a,b=S;n=math.dist(a,b)
            if n<EPS:continue
            u=((b[0]-a[0])/n,(b[1]-a[1])/n);carriers[id(v)]=(a,u)
            if piece_like(v):
                far=1e5;hits=list(intersections(shape('line','',a[0]-u[0]*far,a[1]-u[1]*far,u[0]*(2*far+n),u[1]*(2*far+n)),w))
    if not hits:raise ValueError('Les deux tracés ne se rejoignent pas.')
    I=min(hits,key=lambda x:math.dist(x,p)+math.dist(x,q))
    from cad import circle_data
    from curves import derivative,cubic_location
    curves_of={}
    def local(v,X):
        """The point of v (a straight side: of its whole line) nearest X, and v's direction there (None: not known)."""
        if id(v) in carriers:
            a,u=carriers[id(v)];k=(X[0]-a[0])*u[0]+(X[1]-a[1])*u[1];return (a[0]+u[0]*k,a[1]+u[1]*k),u
        if v['kind']=='circle':
            (cx,cy),r=circle_data(v);n=math.hypot(X[0]-cx,X[1]-cy)
            if n<1e-12:return X,None
            w=((X[0]-cx)/n,(X[1]-cy)/n);return (cx+w[0]*r,cy+w[1]*r),(-w[1],w[0])
        if v.get('spline'):
            # its piece there only (found by its control points, its neighbours too)
            cs=curves_of.setdefault(id(v),cubics(v));m=len(cs);j=min(range(m),key=lambda k:min(math.dist(c,X) for c in cs[k]))
            best=min((cubic_location(cs[k],X)+(cs[k],) for k in {(j-1)%m,j,(j+1)%m}),key=lambda h:math.dist(h[1],X))
            tt,P,c=best;D=derivative(c,tt);n=math.hypot(*D)
            return P,((D[0]/n,D[1]/n) if n>1e-12 else None)
        return contour_location(v,X)[1],None
    found=I
    for _ in range(12):
        # The crossing made exact on both (it is found on flattened curves, within about 0.001 mm): where their
        # tangents cross (a few steps), or from one to the other when a direction is not known.
        (A,ua),(B,ub)=local(s,I),local(t,I)
        if ua and ub:
            den=ua[0]*ub[1]-ua[1]*ub[0]
            if abs(den)<1e-9:break
            k=((B[0]-A[0])*ub[1]-(B[1]-A[1])*ub[0])/den;J=(A[0]+ua[0]*k,A[1]+ua[1]*k)
        else:J=local(s,B)[0]
        done=math.dist(J,I)<1e-10;I=J
        if done:break
    if math.dist(I,found)>.05:I=found   # (two sides almost tangent: the crossing found stays)
    # That piece opened at the end of the side beyond the corner: its other sides stay, one contour.
    rest=[]
    if piece_like(s) and straight_side_at(s,p):s,more=opened_at(s,p,I);rest+=[more] if more else []
    if piece_like(t) and straight_side_at(t,q):t,more=opened_at(t,q,I);rest+=[more] if more else []
    def end_brought(v):
        """(vertices, its free end, the vertex before it, bulges) when I is on the line of the straight end side of
        the open polyline ``v``, beyond that end: the side is lengthened up to the corner (as Arrondi does)."""
        if v['kind']!='poly' or closed_form(v) or v.get('spline') or v.get('ellipse') or v.get('components'):return None
        V=[(v['x']+x,v['y']+y) for x,y in v['points']];n=len(V);B=(list(v.get('bulges') or [])+[0.]*n)[:n]
        for k,j in ((n-1,n-2),(0,1)):
            if n<2 or B[min(k,j)]:continue   # (an arc at that end)
            a,b=V[j],V[k];L=math.dist(a,b)
            if L<EPS:continue
            u=((b[0]-a[0])/L,(b[1]-a[1])/L)
            if abs((I[0]-a[0])*u[1]-(I[1]-a[1])*u[0])<.01 and (I[0]-a[0])*u[0]+(I[1]-a[1])*u[1]>L-EPS:return V,k,j,B
        return None
    def kept(v,click):
        """(the side from its kept end up to I, the end at I)."""
        E=straight(v)
        if E:
            a,b=E;F=max((a,b),key=lambda z:(z[0]-I[0])*(click[0]-I[0])+(z[1]-I[1])*(click[1]-I[1]))
            if math.dist(F,I)<EPS:raise ValueError('Côté trop court.')
            return ('line',(F,F==a)),None
        d,on=contour_location(v,I)
        if math.dist(on,I)>.01:
            brought=end_brought(v)
            if brought is None:raise ValueError('Les deux tracés ne se rejoignent pas.')
            return ('end',brought),None
        total=contour_length(v)
        if closed_form(v):
            # a loop (circle, closed spline or oval…): it stays whole, only the part a chamfer replaces goes, on
            # the side of the click (the nearer way round from the corner); never where it happens to start
            return ('loop',(d,total)),(contour_location(v,click)[0]-d)%total<=total/2
        clicked=contour_location(v,click)[0]
        if v.get('spline'):cs=cubics(v);P=(cs[0][0],cs[-1][-1])
        elif v['kind']=='poly' and v.get('points'):P=((v['x']+v['points'][0][0],v['y']+v['points'][0][1]),(v['x']+v['points'][-1][0],v['y']+v['points'][-1][1]))
        else:P=path(v)[0]
        if math.dist(P[0],I)<1e-6 and math.dist(P[-1],I)<1e-6:
            d=0. if clicked<total/2 else total   # a piece opened at the corner I itself: the end beside the side clicked
        start=clicked<d if EPS<d<total-EPS else d>=total-EPS
        return ('curve',(0.,d) if start else (d,total)),start
    def side(v,click,cut):
        (kind,data),start=kept(v,click)
        if kind=='line':
            F,first=data;L=math.dist(F,I)
            if cut>=L-EPS:raise ValueError('Distance trop grande pour les côtés.')
            X=(I[0]+(F[0]-I[0])*cut/L,I[1]+(F[1]-I[1])*cut/L);a,b=(F,X) if first else (X,F)   # its direction kept
            return inherit(shape('line',v['name'],a[0],a[1],b[0]-a[0],b[1]-a[1]),v),X
        if kind=='end':
            V,k,j,B=data;inner=V[j];L=math.dist(inner,I)
            if cut>=L-EPS:raise ValueError('Distance trop grande pour les côtés.')
            X=(I[0]+(inner[0]-I[0])*cut/L,I[1]+(inner[1]-I[1])*cut/L);W=list(V);W[k]=X
            out=polygon(W,v['name'],False);out.update({key:copy.deepcopy(val) for key,val in v.items() if key not in ('kind','x','y','w','h','r','points','closed','name','bulges')})
            if any(B):out['bulges']=B
            if out.get('notches'):
                added=math.dist(X,V[1])-math.dist(V[0],V[1]) if k==0 else 0.;length=contour_length(out)
                out['notches']=[dict(m,distance=m['distance']+added) for m in out['notches']]
                if any(not -1e-9<=m['distance']<=length+1e-9 for m in out['notches']):raise ValueError('La ligne devient trop courte pour ses crans.')
            return out,X
        if kind=='loop':
            d,total=data
            if cut<=EPS:return v,I   # Angle droit: the loop as it is, the other side brought to it
            if cut>=total/2:raise ValueError('Distance trop grande pour les côtés.')
            piece=contour_slice(v,d+cut,d+total) if start else contour_slice(v,d,d+total-cut)   # from the cut round to I
            pts=path(piece)[0];return piece,(pts[0] if start else pts[-1])
        a,b=data
        if b-a<=cut+EPS:raise ValueError('Distance trop grande pour les côtés.')
        if start:a,b=a,b-cut
        else:a,b=a+cut,b
        piece=v if a<EPS and b>contour_length(v)-EPS else contour_slice(v,a,b)
        pts=path(piece)[0];return piece,(pts[-1] if start else pts[0])
    cut=0. if mode=='corner' else value
    if mode!='corner' and cut<=0:raise ValueError('Distance du chanfrein à régler.')
    A,X=side(s,p,cut);B,Y=side(t,q,cut)
    out=[A,B]
    if mode!='corner':out.append(inherit(shape('line','Chanfrein',X[0],X[1],Y[0]-X[0],Y[1]-X[1]),s))
    return out+rest


def round_shape(s):
    """0.19.6: a circle, or an arc alone (no straight side)."""
    if s['kind']=='circle':return True
    es=primitives(s) if s['kind']=='poly' and not s.get('spline') and not s.get('ellipse') and not s.get('components') else []
    return bool(es) and all(e['sweep'] for e in es)


def piece_like(s):
    """0.19.6: a contour whose sides a raccord keeps together (chained): a closed piece, or an open
    polyline of several sides or with arcs (not a line, a cut line, an arc alone)."""
    if s.get('annotation') or s.get('drill') or s.get('is_notch') or s.get('spline') or s.get('ellipse'):return False
    if s['kind']=='rect' or s['kind']=='poly' and s.get('closed'):return True
    return s['kind']=='poly' and (len(s.get('points',()))>2 or any(s.get('bulges') or ()))


def parallel_to_piece(s,t,p,q,mode,r):
    """0.19.6: Arrondi / Angle droit / Chanfrein between a line (a cut line, the end side of an open
    polyline) and the parallel side of a piece, or a side in the middle of a polyline: as between two
    lines, from the free end of the line next to its click (whichever was clicked first) to that side,
    reached at a right angle; the piece stays as it is. None when it does not apply."""
    from editing import straight_side_at,side_of,_side_line
    S,T=straight_side_at(s,p),straight_side_at(t,q)
    if not S or not T or not parallel(*S,*T):return None
    fs,ft=side_of(s,p),side_of(t,q)
    if fs and ft:return None
    if not fs and not ft:
        if piece_like(s) and piece_like(t):raise ValueError('Côtés parallèles : l’un des deux doit être une ligne ou le bout d’une polyligne.')
        return None
    flip=not fs
    if flip:s,t,p,q,S,T,fs=t,s,q,p,T,S,ft
    if not piece_like(t) or s.get('notches'):return None   # (a line with crans: as before)
    (a,b),ws=fs
    if ws and math.dist(p,b)>math.dist(p,a):raise ValueError('Cliquer la polyligne près de son bout libre.')
    first,second=_side_line((a,b),s),_side_line(T,t)
    joined=parallel_corner(first,second,b if ws else p,q,mode,r)
    R=[(joined['x']+x,joined['y']+y) for x,y in joined['points']];RB=(list(joined.get('bulges') or [])+[0.]*len(R))[:len(R)]
    from editing import landing
    c,d=T;k=landing(R,c,d)   # where it reaches the side: the piece is not cut
    L2=math.dist(c,d)**2;t_=((R[k][0]-c[0])*(d[0]-c[0])+(R[k][1]-c[1])*(d[1]-c[1]))/L2
    if not -1e-6<=t_<=1+1e-6:raise ValueError('Le raccord n’arrive pas sur le côté de la pièce : cliquer la ligne plus près.')
    if ws:
        link=inherit(polygon(R[1:k+1],s['name'],False),s);link['bulges']=RB[1:k]+[0.];pieces=[s]+decompose(link)
    else:
        line=inherit(polygon(R[:k+1],s['name'],False),s);line['bulges']=RB[:k]+[0.];pieces=decompose(line)
    return [copy.deepcopy(t)]+pieces if flip else pieces+[copy.deepcopy(t)]


def split_sides(pieces,other,spans=False):
    """Cut `pieces` at their crossings with `other` (a closed form) and tell for
    each part whether it lies inside, outside or along that form's outline;
    ``spans`` (0.18.5): each part also carries (index of its piece, start, end)."""
    from cad import distance_to_shape
    from craft_tools import at_distance
    from precision_geometry import inside
    out=[]
    for n,v in enumerate(pieces):
        total=contour_length(v)
        if total<EPS:continue
        cuts=[] if v.get('notches') or path(v)[1] else sorted({contour_location(v,x)[0] for x in intersections(v,other)})
        # Crossings within 0.01 mm of an end are that end (no invisible slivers).
        marks=[0]+[d for d in cuts if .01<d<total-.01]+[total]
        for a,b in zip(marks,marks[1:]):
            if b-a<.01:continue
            part=v if (a,b)==(0,total) else inherit(contour_slice(v,a,b),v)
            point,_=at_distance(v,(a+b)/2)
            kind='on' if distance_to_shape(point,other)<1e-3 else 'in' if inside(other,point) else 'out'
            out.append((part,kind,(n,a,b)) if spans else (part,kind))
    return out


def absorb_touching(sides_s,sides_t,s,t,A,B,tol=.05,margin=.2):
    """0.18.5: raccord giving the joined outline of two closed forms. A part of one form that
    sticks out of the other away from the raccord and touches it between its two ends (the back
    corners of a rectangle whose back edge only touches, at its middle, a circle drawn from that
    middle) is no longer kept: the other form's outline behind it is kept instead (the back stays
    round). A part going away without touching again (a bar crossing the circle) stays.
    Changes the kinds in place; returns the indices of the restored parts (s=…, t=…)."""
    from cad import distance_to_shape
    from craft_tools import at_distance,perimeter
    from precision_geometry import inside
    restored=dict(s=set(),t=set())
    def ends(v):
        pts=path(v)[0];return pts[0],pts[-1]
    near=lambda p,q:math.dist(p,q)<=.02
    for mine,theirs,other,anchor,key in ((sides_t,sides_s,s,B,'s'),(sides_s,sides_t,t,A,'t')):
        def outside(n):
            v,k,_=mine[n]
            if k=='out':return True
            if k!='on':return False
            # A side only touching the other outline at its middle (tangent, not cut there) is
            # classed 'on' by its middle point: outside if its other points are.
            L=perimeter(v)
            return all(distance_to_shape(q,other)>1e-3 and not inside(other,q) for q in (at_distance(v,L*f)[0] for f in (.2,.4,.6,.8)))
        outs=[n for n in range(len(mine)) if outside(n)];seen=set()
        for n0 in outs:
            if n0 in seen:continue
            seen.add(n0);a,b=ends(mine[n0][0]);chain=[(n0,False)]
            grown=True
            while grown:
                grown=False
                for n in outs:
                    if n in seen:continue
                    c,d=ends(mine[n][0])
                    if near(b,c):chain.append((n,False));b=d
                    elif near(b,d):chain.append((n,True));b=c
                    elif near(a,d):chain.insert(0,(n,False));a=c
                    elif near(a,c):chain.insert(0,(n,True));a=d
                    else:continue
                    seen.add(n);grown=True
            if near(a,b) or any(near(e,anchor) for n,_ in chain for e in ends(mine[n][0])):continue
            if distance_to_shape(a,other)>tol or distance_to_shape(b,other)>tol:continue
            # Distance to the other form along the chain: going away, back to touch it, away again.
            gaps=[]
            for n,flip in chain:
                v=mine[n][0];L=perimeter(v);k=max(8,min(400,int(L/.25)))
                for i in range(k+1):gaps.append(distance_to_shape(at_distance(v,L*((k-i) if flip else i)/k)[0],other))
            touch=[i for i,g in enumerate(gaps) if g<=tol and max(gaps[:i],default=0)>=margin and max(gaps[i+1:],default=0)>=margin]
            if not touch:continue
            # The other form's parts inside this one, from one end of the chain to the other.
            cur=a;behind=[]
            for _ in range(len(theirs)):
                if near(cur,b):break
                step=None
                for m,(v,k,_) in enumerate(theirs):
                    if k!='in' or m in behind:continue
                    c,d=ends(v)
                    if near(cur,c):step=(m,d);break
                    if near(cur,d):step=(m,c);break
                if step is None:break
                behind.append(step[0]);cur=step[1]
            if not behind or not near(cur,b):continue
            for n,_ in chain:mine[n]=(mine[n][0],'in',mine[n][2])
            for m in behind:theirs[m]=(theirs[m][0],'out',theirs[m][2]);restored[key].add(m)
    return restored


def kept_sides(sides,want,restored,sources):
    """The parts of `sides` whose kind is in `want`; 0.18.5: consecutive kept parts of one piece
    that include a part restored by absorb_touching become one (one arc behind the dropped part)."""
    runs=[]
    for n,(v,k,(src,a,b)) in enumerate(sides):
        if k not in want:runs.append(None);continue
        if runs and runs[-1] and runs[-1]['src']==src and abs(runs[-1]['b']-a)<1e-9:runs[-1]['b']=b;runs[-1]['n'].append(n)
        else:runs.append(dict(src=src,a=a,b=b,n=[n]))
    out=[]
    for run in filter(None,runs):
        if len(run['n'])>1 and restored.intersection(run['n']):
            v=sources[run['src']];total=contour_length(v)
            out.append(v if run['a']<EPS and run['b']>total-EPS else inherit(contour_slice(v,run['a'],run['b']),v))
        else:out+=[sides[n][0] for n in run['n']]
    return out


def remove_collinear_spans(entities,masks):
    """Trim coincident copies too, so a shared rectangle edge cannot mask the raccord."""
    result=[]
    def straight(s):return not s.get('components') and not s.get('spline') and not s.get('ellipse') and not any(s.get('bulges',[])) and len(path(s)[0])==2
    lines=[path(m)[0] for m in masks if straight(m)]
    for entity in entities:
        if not straight(entity):result.append(entity);continue
        a,b=path(entity)[0];length=math.dist(a,b)
        if length<EPS:continue
        ux,uy=(b[0]-a[0])/length,(b[1]-a[1])/length;cuts=[]
        for A,B in lines:
            if max(abs((P[0]-a[0])*uy-(P[1]-a[1])*ux) for P in (A,B))>1e-5:continue
            x,X=sorted((sum((P[k]-a[k])*u for k,u in enumerate((ux,uy))) for P in (A,B)))
            lo,hi=max(0,x),min(length,X)
            if hi-lo>EPS:cuts.append((lo,hi))
        if not cuts:result.append(entity);continue
        cursor=0
        for lo,hi in sorted(cuts):
            if lo-cursor>EPS:result.append(contour_slice(entity,cursor,lo))
            cursor=max(cursor,hi)
        if length-cursor>EPS:result.append(contour_slice(entity,cursor,length))
    return result

def _straight_end(q,which):
    """0.19.8: the first (0) or last (-1) side of a line or polyline is straight."""
    if q.get('spline') or q.get('ellipse') or q.get('components'):return False
    if q['kind']=='line':return True
    if q['kind']!='poly':return False
    bulges=list(q.get('bulges') or [])
    n=len(q.get('points') or [])
    if n<2:return False
    b=bulges[0] if which==0 else (bulges[n-2] if len(bulges)>=n-1 else 0.)
    return not b if bulges else True

def _carry_marks(r,q,from_start):
    """0.19.8: the crans of ``q`` (marks along it) kept on ``r``, its other form: measured from its start, they move
    by the change of length when its start moved."""
    if not q.get('notches'):return r
    old,new=contour_length(q),contour_length(r);shift=new-old if from_start else 0.
    r['notches']=[dict(copy.deepcopy(m),distance=min(max(0.,m['distance']+shift),new)) for m in q['notches']]
    return r

def _slice_marks(s):
    """0.19.9: the crans of a closed ``s`` not measured from where contour_slice measures (a rounded rectangle is
    drawn from its first round, an oval turned over from its last point): (cran, its point, its place for
    contour_slice); None when contour_slice places them right."""
    if not s.get('notches') or not path(s)[1]:return None
    total=contour_length(s);x=contour_location(s,path(s)[0][0])[0]
    if min(x,total-x)<1e-6:return None
    from craft_tools import at_distance
    spots=[(m,at_distance(s,m['distance'])[0]) for m in s['notches']]
    return [(m,P,contour_location(s,P)[0]) for m,P in spots]

def _to_point(q,p):
    """0.19.8: a line or a polyline ending at ``p`` instead of its last point (its last side straight); else the shape."""
    if q.get('spline') or q.get('ellipse') or q.get('components') or q.get('annotation') or q.get('drill'):return q
    pts,closed=path(q)
    if closed or len(pts)<2 or math.dist(pts[-1],p)<1e-12:return q
    if q['kind']=='line':
        r=copy.deepcopy(q);r.update(w=p[0]-q['x'],h=p[1]-q['y']);return _carry_marks(r,q,False)
    if q['kind']!='poly':return q
    c=canonical(q);raw=[(c['x']+x,c['y']+y) for x,y in c['points']]
    if len(raw)<2 or math.dist(raw[-1],pts[-1])>1e-9:return q
    r=polygon(raw[:-1]+[p],q.get('name',''),False)
    if c.get('bulges'):r['bulges']=list(c['bulges'])
    return _carry_marks(inherit(r,q),q,False)

def _from_point(q,p):
    """0.19.8: a line or a polyline (arcs kept) starting at ``p`` instead of its first point; other shapes as they are."""
    if q.get('spline') or q.get('ellipse') or q.get('components') or q.get('annotation') or q.get('drill'):return q
    pts,closed=path(q)
    if closed or len(pts)<2 or math.dist(pts[0],p)<1e-12:return q
    if q['kind']=='line':
        end=pts[-1];r=copy.deepcopy(q);r.update(x=p[0],y=p[1],w=end[0]-p[0],h=end[1]-p[1]);return _carry_marks(r,q,True)
    if q['kind']!='poly':return q
    c=canonical(q);raw=[(c['x']+x,c['y']+y) for x,y in c['points']]
    if len(raw)<2 or math.dist(raw[0],pts[0])>1e-9:return q
    r=polygon([p]+raw[1:],q.get('name',''),False)
    if c.get('bulges'):r['bulges']=list(c['bulges'])
    return _carry_marks(inherit(r,q),q,True)

class ContourWalk:
    """Graph edges retain exact source slices; intersections are selectable nodes. 0.19.8 (« indiquer où est
    le problème ») : at a dead end, a free end of another trace within GAP (0,1 mm) is joined to it (the gap is
    closed and said: ``bridged``); farther, ``dead_end`` gives the place and the gap to the nearest end."""
    GAP=.1
    def __init__(self,items,tolerance=.02):
        self.items=items;self.edges=[];self.nodes=[];self.used=[];self.route=[];self.current=None;self.start=None;self.tolerance=tolerance;self.bridged=[]
        eligible=[i for i,s in enumerate(items) if __import__('entity_rules').geometry_entity(s)]
        cuts={i:[0,contour_length(items[i])] for i in eligible}
        # 0.19.9: each box once (with the boxes_apart margin), sorted by x and swept: only the pairs whose boxes
        # overlap are tested (every pair asked two boxes: 1.5 s at the first click on 2760 objects). Same graph.
        from geometry import bounds,_margin
        box={}
        for i in eligible:b=bounds([items[i]]);m=_margin(b);box[i]=(b[0]-m,b[1]-m,b[2]+m,b[3]+m)
        order=sorted(eligible,key=lambda i:box[i][0]);pairs=[]
        for a,i in enumerate(order):
            _,y0,x1,y1=box[i]
            for k in range(a+1,len(order)):
                j=order[k];b=box[j]
                if b[0]>x1:break
                if b[1]<=y1 and b[3]>=y0:pairs.append((i,j) if i<j else (j,i))
        for i,j in sorted(pairs):
            for p in intersections(items[i],items[j]):
                cuts[i].append(contour_location(items[i],p)[0]);cuts[j].append(contour_location(items[j],p)[0])
        def node(p):
            for i,q in enumerate(self.nodes):
                if math.dist(p,q)<=tolerance:return i
            self.nodes.append(p);return len(self.nodes)-1
        for i in eligible:
            ds=[]
            for d in sorted(cuts[i]):
                if not ds or d-ds[-1]>1e-5:ds.append(d)
            marks=_slice_marks(items[i])
            for a,b in zip(ds,ds[1:]):
                if b-a<EPS:continue
                v=contour_slice(items[i],a,b);pts,ring=path(v)
                if marks is not None:   # 0.19.9: crans not measured from where the slices are, placed by their point (they moved ~24 mm)
                    from craft_tools import locate
                    total=contour_length(items[i]);v.pop('notches',None)
                    kept=[dict(copy.deepcopy(m),distance=locate(v,P)[0]) for m,P,x in marks if (x-a)%total<=b-a+1e-7]
                    if kept:v['notches']=kept
                # 0.19.9: a whole closed oval is one closed piece, ending where it starts (its points stop a step before).
                self.edges.append(dict(source=i,lo=a,hi=b,shape=v,a=node(pts[0]),b=node(pts[0] if ring else pts[-1])))
    def choices(self):
        return [(k,e['a']==self.current) for k,e in enumerate(self.edges) if k not in self.used and self.current in (e['a'],e['b'])]
    def take(self,k,forward=True):
        e=self.edges[k]
        if self.start is None and e['a']==e['b']:forward=True   # 0.19.9: a lone closed contour keeps its way round (a cran on a corner kept its stem)
        if self.start is None:self.start=e['a'] if forward else e['b']
        self.current=e['b'] if forward else e['a'];self.used.append(k)
        q=copy.deepcopy(e['shape']) if forward else inherit(reverse(e['shape']),e['shape'])
        if not forward and e['shape'].get('notches'):
            from craft_tools import at_distance,locate,perimeter
            # 0.19.9: the drawn length, along which crans are measured (the exact one moved them up to 0,01 mm)
            length=perimeter(e['shape']);q['notches']=[dict(copy.deepcopy(m),distance=length-m['distance'],side=-m.get('side',1)) for m in e['shape']['notches']]
            if path(q)[1]:   # 0.19.9: a whole closed oval turned over starts a step back: its crans placed by their point
                for m,n in zip(q['notches'],e['shape']['notches']):m['distance']=locate(q,at_distance(e['shape'],n['distance'])[0])[0]
        self.route.append(q)
        return self.current==self.start
    def advance(self):
        while self.current!=self.start:
            choices=self.choices()
            if not choices and self.bridge():continue
            if len(choices)!=1:return False
            if self.take(*choices[0]):return True
        return True
    def nearest_end(self):
        """(gap, node) of the nearest point the walk could go on from (a node with a trace not taken, or its
        start), None when there is none. A point the route already went through is not one (a construction line
        crossing it just before the gap would take the walk back)."""
        here=self.nodes[self.current];best=None
        passed={n for k in self.used for n in (self.edges[k]['a'],self.edges[k]['b'])}
        free={n for k,e in enumerate(self.edges) if k not in self.used for n in (e['a'],e['b'])}-passed
        if self.start is not None and self.current!=self.start:free.add(self.start)
        for n in free-{self.current}:
            d=math.dist(here,self.nodes[n])
            if best is None or d<best[0]:best=(d,n)
        return best
    def bridge(self):
        """At a dead end: a point within GAP is joined to this one (its traces start here; the start closes the
        contour). True when the walk can go on. ``bridged``: (gap, point, index in the route of the piece that
        starts after the gap)."""
        if self.current is None or self.current==self.start:return False
        near=self.nearest_end()
        if near is None or near[0]>self.GAP:return False
        gap,n=near;self.bridged.append((gap,self.nodes[self.current],len(self.route)))
        if n==self.start:self.current=self.start;return True
        for e in self.edges:
            if e['a']==n:e['a']=self.current
            if e['b']==n:e['b']=self.current
        return True
    def closed_route(self):
        """The route with each gap Joindre closed made exact: a straight end is drawn out to the other end (the line
        before the gap, else the one after); two arcs: the one after starts where the one before ends (a spline or
        an ellipse keeps its gap)."""
        route=[copy.deepcopy(q) for q in self.route]
        for gap,_,j in self.bridged:
            k=j%len(route);before,after=route[j-1],route[k]
            end,start=path(before)[0][-1],path(after)[0][0]
            moved=_to_point(before,start) if _straight_end(before,-1) else None
            if moved is not None and moved is not before:route[j-1]=moved
            else:route[k]=_from_point(after,end)
        return route
    def dead_end(self):
        """Where the walk stops (no trace to follow): (point, gap to the nearest end or None)."""
        near=self.nearest_end()
        return self.nodes[self.current],(near[0] if near else None)
    def result(self):
        if self.current!=self.start:raise ValueError('Le contour n’est pas fermé.')
        route=self.closed_route()
        result=compound(route,'',True)
        # 0.19.9: also without a gap (a lone closed contour): its first point was repeated at the end.
        if len(route)==1 and result.get('kind')=='poly' and not (result.get('spline') or result.get('ellipse') or result.get('components')):
            # 0.19.8: ONE polyline whose ends Joindre brought together: its last point (now its first) goes, no tiny side.
            c=canonical(result);pts=[(c['x']+x,c['y']+y) for x,y in c['points']]   # its vertices (path would cut its arcs)
            bulges=list(c.get('bulges') or [0.]*len(pts))
            # 0.19.9: two points are enough when one side is an arc (a circle stored as two half arcs).
            if (len(pts)>3 or len(pts)==3 and any(bulges[:2])) and math.dist(pts[0],pts[-1])<1e-9:
                q=polygon(pts[:-1],'',True)
                if any(bulges):q['bulges']=(bulges+[0.]*len(pts))[:len(pts)-1]
                result=inherit(q,result)
        if len(route)>1 and all(not v.get('spline') and not v.get('ellipse') and not v.get('components') and not any(v.get('bulges',[])) for v in route):
            from editing import join_shapes
            # 0.19.9: the sides without their crans (carried below): join_shapes refused them (« Joignez les contours avant… »)
            result=join_shapes([{k:v for k,v in q.items() if k!='notches'} for q in route],self.tolerance)
        elif len(route)>1:
            # 0.16.28: lines and arcs become ONE polyline with true arcs (no assembled parts).
            from precision_geometry import bulged_polyline
            single=bulged_polyline(route,True)
            if single is not None:result=inherit(single,route[0])
        # 0.16.28: the whole polyline takes the colour and line type of the starting line.
        if route and 'style' in route[0]:
            result['style']=copy.deepcopy(route[0]['style'])
            for part in result.get('components',[]):part['style']=copy.deepcopy(route[0]['style'])
        if route and 'profile' in route[0]:result['profile']=route[0]['profile']
        result['name']='';result['closed']=True;remaining=[];selected=set(self.used)
        marks=[];travel=0
        from craft_tools import perimeter
        for s in route:   # 0.19.9: drawn lengths, along which crans are measured (exact ones moved them up to 0,01 mm)
            marks.extend(dict(copy.deepcopy(m),distance=m['distance']+travel) for m in s.get('notches',[]));travel+=perimeter(s)
        if marks:result['notches']=marks
        for k,e in enumerate(self.edges):
            if k not in selected:remaining.append(e['shape'])
        sources={e['source'] for e in self.edges};used_sources={self.edges[k]['source'] for k in self.used}
        # Preserve untouched entities rather than unnecessarily splitting them.
        remaining=[e['shape'] for k,e in enumerate(self.edges) if k not in selected and e['source'] in used_sources]
        return used_sources,remaining+[result]


def raccord_document(items,i,j,p,q,mode,value):
    """Replace a previous independent circular bridge at the selected corner. 0.18.5 (n° 26): the
    ends of the drawing's other lines near a closed form are given to the raccord (a circle already
    raccordé on one side is cut between the two raccords), and a line left behind the joined
    outline goes too (left_behind)."""
    if i==j:
        closed=close_open_end(items[i],p,q,mode,value)   # 0.19.5: the two parallel end sides of one open polyline
        if closed is not None:
            pts=path(items[i])[0];return {i}|links_between(items,{i},pts[0],pts[-1]),[closed]
        if mode in STRAP:raise ValueError('Bout de sangle : cliquez le petit côté d’une pièce, ou deux bords parallèles.')
        curved=curved_corner(items[i],p,q,mode,value)   # 0.19.21: a curved side of the piece
        return {i},[curved if curved is not None else corner_poly(items[i],p,q,mode,value)]
    ids={i,j};a,b=items[i],items[j]
    contacts=[]
    if mode=='fillet' and (closed_form(a) or closed_form(b)):
        from geometry import boxes_apart
        from entity_rules import geometry_entity
        contacts=[x for k,v in enumerate(items) if k not in ids and geometry_entity(v) and not (boxes_apart(v,a) and boxes_apart(v,b)) for x in end_directions(v)]
    # 0.19.4: between two straight sides (lines or cut lines; 0.19.5: or the end side of an open
    # polyline), only what joined them at THIS end goes (a round, chamfer, square side or strap end done
    # there before); the one at their other end stays (it went too: a second raccord on two parallel
    # lines removed the first). 0.19.6: a strap end done again has its tip where that one had it.
    links=corner_links(items,ids,a,b,p,q)
    new,masks=raccord_parts(a,b,p,q,mode,value,contacts,[items[k] for k in links] if mode in STRAP else ())
    ids|=left_behind(items,ids,new,masks)|links
    # 0.19.6: a piece (rectangle, polyline) is not taken apart: its sides, the raccord and the other line
    # are one contour (closed again when the outline is). (Not with a circle or an arc: the round end of
    # n° 26 / n° 8 is made by two raccords on its pieces.)
    if (piece_like(a) or piece_like(b)) and not (round_shape(a) or round_shape(b)):
        from editing import chained
        new=chained(new,a if piece_like(a) else b)
    # 0.19.7: a closed spline (or oval) is taken whole by the raccord (raccord_parts, curve_corner): it stays one
    # curve, and two different splines are never joined into one.
    return ids,new


def primitive_distance(P,e):
    """0.19.21: the distance from P to a side (straight or arc) of a contour, exact (no sampling)."""
    if not e['sweep']:return distance(P,e['a'],e['b'])
    c=e['c'];k=1 if e['sweep']>0 else -1
    if ((math.atan2(P[1]-c[1],P[0]-c[0])-e['start'])*k)%(2*math.pi)<=abs(e['sweep']):return abs(math.dist(P,c)-e['r'])
    return min(math.dist(P,e['a']),math.dist(P,e['b']))


def same_side(s,a,b):
    """0.19.21: the points a and b are nearest the same side of ``s`` (a line, a curve, an arc even stored in
    quarters, a circle: one side); two different sides of a piece: False."""
    if s['kind'] in ('line','circle') or s.get('spline') or s.get('ellipse') or s.get('components'):return True
    try:es=primitives(canonical(s))
    except (ValueError,KeyError,TypeError):return True
    if len(es)<2:return True
    e,f=(min(es,key=lambda e:primitive_distance(X,e)) for X in (a,b))
    if e is f:return True
    return bool(e['sweep'] and f['sweep'] and math.dist(e['c'],f['c'])<1e-6 and abs(e['r']-f['r'])<1e-6)


def curved_corner(s,p,q,mode,r):
    """0.19.21 (« comme AutoCAD », 09/11/2026): Arrondi between a curved side and a straight side of the SAME
    polyline, or two curved sides: the two sides (and a small round between them, done before) taken apart,
    raccordés as two objects, then joined again with the rest of the piece in one polyline, closed when it was.
    None when neither side clicked is curved (corner_poly's straight corner)."""
    from precision_geometry import without_micro
    from editing import chained
    if s.get('notches') or s.get('ellipse') or s.get('spline') or s.get('components') or s.get('annotation') or s.get('is_notch'):return None
    from editing import without_aligned
    native=canonical(without_aligned(without_micro(s)))
    if native['kind']!='poly':return None
    closed=bool(native.get('closed'));edges=primitives(native);n=len(edges)
    if n<2:return None
    def near(point):return min(range(n),key=lambda k:primitive_distance(point,edges[k]))
    i,j=near(p),near(q)
    def gap(a,b):return (b-a)%n if closed else b-a
    def turn(u,v):return abs(u[0]*v[1]-u[1]*v[0])<.02 and u[0]*v[0]+u[1]*v[1]>0
    def heading(e,end):
        if not e['sweep']:L=math.dist(e['a'],e['b']) or 1.;return ((e['b'][0]-e['a'][0])/L,(e['b'][1]-e['a'][1])/L)
        k=1 if e['sweep']>0 else -1;a=e['start']+(e['sweep'] if end else 0);return (-k*math.sin(a),k*math.cos(a))
    def is_round(k):
        """An arc tangent to the sides on both of its ends: a round done before (a raccord)."""
        if not edges[k]['sweep'] or not closed and k in (0,n-1):return False
        return turn(heading(edges[(k-1)%n],True),heading(edges[k],False)) and turn(heading(edges[k],True),heading(edges[(k+1)%n],False))
    # 0.19.21 (relecture): a click on a round done before, then on a side beside it: that corner done again
    for which in (0,1):
        a,b=(i,j) if which==0 else (j,i)
        if a!=b and is_round(a) and b in ((a-1)%n,(a+1)%n):
            beyond=(a+1)%n if b==(a-1)%n else (a-1)%n;X=at_primitive(edges[beyond],.05 if beyond==(a+1)%n else .95)
            if which==0:i,p=beyond,X
            else:j,q=beyond,X
    if i==j:return None
    if not (edges[i]['sweep'] or edges[j]['sweep']):return corner_poly(s,p,q,mode,r)   # two straight sides: as before
    def order(a,b):   # 1: neighbours; 2: a round done before between them; 0: not one corner
        g=gap(a,b)
        return 1 if g==1 else 2 if g==2 and edges[(a+1)%n]['sweep'] else 0
    if order(i,j)!=1 and (order(j,i)==1 or not order(i,j)):i,j,p,q=j,i,q,p   # (a piece of 3 sides: the neighbours first)
    g=order(i,j)
    if not g:raise ValueError('Choisir les deux côtés du même angle.')
    if mode!='fillet':raise ValueError('Chanfrein, angle droit : choisir deux côtés droits.')
    def alone(es):
        pts=[es[0]['a']]+[e['b'] for e in es];q=inherit(polygon(pts,s['name'],False),s)
        bs=[math.tan(e['sweep']/4) for e in es]
        if any(bs):q['bulges']=bs+[0.]
        return q
    first,second=alone([edges[i]]),alone([edges[j]])
    new,_=raccord_parts(first,second,p,q,mode,r)
    if closed:rest=[[edges[(j+k)%n] for k in range(1,n-g)]] if n-g-1>0 else []
    else:rest=[es for es in ([edges[k] for k in range(i)],[edges[k] for k in range(j+1,n)]) if es]
    joined=chained([alone(es) for es in rest]+new,s)
    outline=[v for v in joined if v['kind'] in ('line','poly')]
    if len(outline)!=1 or bool(path(outline[0])[1])!=closed or len(joined)!=1:raise ValueError('Aucun raccord possible à ce rayon sur ces portions.')
    out=outline[0]
    if out['kind']=='line':out=inherit(polygon(path(out)[0],s['name'],False),s)
    return out


ROUND_TANGENT=math.radians(1)   # 0.19.22: a round is tangent to its two sides within 1° (Mozart's are within 0.01°)
U_TURN=math.radians(170)        # a round turning more than this joins two (nearly) parallel sides: a strap's end
SLIDE=math.sin(math.radians(30))   # a side beyond at 30° or more keeps its line (the corner slides along it)
STRAIGHT=math.radians(.1)       # straight sides in line within this: one side (a point left inside it: Mozart, Couper)


def _unit(a,b):
    L=math.dist(a,b);return ((b[0]-a[0])/L,(b[1]-a[1])/L)


def _turn(u,w):
    return math.atan2(u[0]*w[1]-u[1]*w[0],u[0]*w[0]+u[1]*w[1])


def _meet(p,u,q,w):
    """Where the line through p along u meets the line through q along w (None when parallel)."""
    det=u[0]*w[1]-u[1]*w[0]
    if abs(det)<1e-12:return None
    k=((q[0]-p[0])*w[1]-(q[1]-p[1])*w[0])/det
    return (p[0]+u[0]*k,p[1]+u[1]*k)


def _sweep_like(c,A,Z,old):
    """The turn about c from A to Z, the same way as old and less than half a turn away from it; None otherwise
    (the arc would vanish or turn the other way)."""
    a=(A[0]-c[0],A[1]-c[1]);z=(Z[0]-c[0],Z[1]-c[1])
    s=math.atan2(a[0]*z[1]-a[1]*z[0],a[0]*z[0]+a[1]*z[1])
    if old>0 and s<=0:s+=2*math.pi
    if old<0 and s>=0:s-=2*math.pi
    return s if 1e-9<abs(s) and abs(s-old)<math.pi else None


def _arc_from(A,Z,ta=None,tb=None):
    """The sweep of the arc from A to Z leaving A along ta (or reaching Z along tb): twice the angle with its chord."""
    ch=(Z[0]-A[0],Z[1]-A[1])
    if ta is not None:return 2*math.atan2(ta[0]*ch[1]-ta[1]*ch[0],ta[0]*ch[0]+ta[1]*ch[1])
    return 2*math.atan2(ch[0]*tb[1]-ch[1]*tb[0],ch[0]*tb[0]+ch[1]*tb[1])


def _centre(A,Z,sweep):
    chord=math.dist(A,Z);mid=((A[0]+Z[0])/2,(A[1]+Z[1])/2);w=_unit(A,Z);h=chord/2/math.tan(sweep/2)
    return (mid[0]-w[1]*h,mid[1]+w[0]*h)


def side_elements(q):
    """0.19.22: the polyline q as its straight sides and its arcs (an arc stored in quarter turns: one; straight sides
    in line: one, the points between them in ``inner``), in order: dicts kind 'line' / 'arc', segs (indices of q's
    sides), a / b (ends), u (a line's direction), c / r / sweep and ta / tb (an arc's directions at its ends). A
    closed polyline starts at a straight side when it has one."""
    V=[(q['x']+x,q['y']+y) for x,y in q['points']];n=len(V);closed=bool(q.get('closed'))
    B=(list(q.get('bulges') or [])+[0]*n)[:n];m=n if closed else n-1
    first=next((i for i in range(m) if not B[i]),0) if closed else 0
    out=[]
    for step in range(m):
        i=(first+step)%n;a,b=V[i],V[(i+1)%n]
        if math.dist(a,b)<1e-9:continue
        last=out[-1] if out else None
        if not B[i]:
            u=_unit(a,b)
            if last and last['kind']=='line' and abs(_turn(last['u'],u))<STRAIGHT:   # (the run's first direction: no drift)
                last['segs'].append(i);last['inner'].append(a);last['b']=b;continue
            out.append(dict(kind='line',segs=[i],a=a,b=b,u=u,inner=[]));continue
        sweep=4*math.atan(B[i]);chord=math.dist(a,b);r=chord/2/abs(math.sin(sweep/2))
        mid=((a[0]+b[0])/2,(a[1]+b[1])/2);w=_unit(a,b);h=chord/2/math.tan(sweep/2)
        c=(mid[0]-w[1]*h,mid[1]+w[0]*h)
        ta=(w[0]*math.cos(-sweep/2)-w[1]*math.sin(-sweep/2),w[0]*math.sin(-sweep/2)+w[1]*math.cos(-sweep/2))
        tb=(w[0]*math.cos(sweep/2)-w[1]*math.sin(sweep/2),w[0]*math.sin(sweep/2)+w[1]*math.cos(sweep/2))
        if last and last['kind']=='arc' and (last['sweep']>0)==(sweep>0) and math.dist(last['c'],c)<=1e-6*(1+r) and abs(last['r']-r)<=1e-6*(1+r):
            last.update(segs=last['segs']+[i],b=b,sweep=last['sweep']+sweep,tb=tb);continue
        out.append(dict(kind='arc',segs=[i],a=a,b=b,c=c,r=r,sweep=sweep,ta=ta,tb=tb))
    if closed and len(out)>1 and out[0]['kind']==out[-1]['kind']=='line' and abs(_turn(out[-1]['u'],out[0]['u']))<STRAIGHT:
        z=out.pop();f=out[0];f.update(segs=z['segs']+f['segs'],inner=z['inner']+[f['a']]+f['inner'],a=z['a'])
    for e in out:
        if e['kind']=='line' and e['inner']:e['u']=_unit(e['a'],e['b'])
    return out


def side_moved(q,k,d,arcs=None):
    """0.19.22 (« milieux » : a grip at the middle of every side of a selected piece, OUI le 12/11/2026 ; « le côté se
    déplace parallèlement, un arc se bombe »): the straight side k of the polyline q (with arcs or not; straight sides
    in line with it: the same side) moved by d mm across itself, along (-uy, ux) (u its direction). Seen as its sharp
    polygon (a round corner: where the lines of its two straight sides meet), the piece changes as when the corners of
    that side move with it: the side keeps its length there, the straight sides beside it turn about their other
    corner, and every round at their ends keeps its radius, tangent to its two sides again (a rounded rectangle stays
    one). An arc beyond the side keeps every tangency it had: a round between the side and a curve keeps its radius
    (the curve its circle); met at a corner of 30° or more, it keeps its circle (the corner slides on it, as on a
    straight side beyond); else, tangent at one end, it keeps its far end and its tangents (its radius changes), met
    at corners, its shape (turned and scaled about its other end). A round making a half turn (the round end of
    a strap) stays tangent to the side beyond where it starts and to the side moved (a half circle between parallel
    sides). A side turned that goes on into a curve stays tangent to it (the curve keeps its circle). Returns
    (polyline, moved): moved, (old, new) of the points of the straight sides moved (their crans follow); ``arcs``, a
    list: given, it gets ((centre, radius, start, sweep) as it was, as it is) of every arc changed (the crans on it
    keep their place along it). ValueError when a side or a round no longer fits."""
    V=[(q['x']+x,q['y']+y) for x,y in q['points']];n=len(V);closed=bool(q.get('closed'))
    B=(list(q.get('bulges') or [])+[0]*n)[:n]
    if not 0<=k<(n if closed else n-1) or B[k] or math.dist(V[k],V[(k+1)%n])<1e-9:raise ValueError('Choisir un côté droit.')
    E=side_elements(q);N=len(E);S=next(i for i,e in enumerate(E) if e['kind']=='line' and k in e['segs'])
    def nb(i,step):
        j=i+step
        if closed:return j%N if N>1 else None
        return j if 0<=j<N else None
    def is_line(i):return i is not None and E[i]['kind']=='line'
    def heading(i,end):
        e=E[i];return e['u'] if e['kind']=='line' else e['ta' if end=='a' else 'tb']
    def smooth(i,j):
        """The element i reaches the element j after it without a corner."""
        return abs(_turn(heading(i,'b'),heading(j,'a')))<ROUND_TANGENT
    def round_at(i):
        """Arc i is a round: tangent to the straight sides on both of its ends."""
        if i is None or E[i]['kind']!='arc':return False
        p,f=nb(i,-1),nb(i,1)
        return is_line(p) and is_line(f) and p!=f and smooth(p,i) and smooth(i,f)
    u=E[S]['u'];t=(-u[1]*d,u[0]*d)
    def plus(p):return (p[0]+t[0],p[1]+t[1])
    lines={S:(plus(E[S]['a']),u)}   # the new lines of the straight sides moved or turned: (a point, the direction)
    ends={}                        # (element, 'a' | 'b'): its new end
    rebuilt={}                     # arc element remade: (its start, its end, centre, sweep)
    scaled={}                      # curve met at sharp corners: (its far end, which stays; its end at the side, old; new)
    pivots={}                      # straight side turned: its two ends as they were, and now (its inner points follow)
    changed={S}                    # elements reshaped, each from one end only
    circle={}                      # 0.19.23: curve keeping its circle, its ends slid on it: {'a': new start, 'b': new end}
    def take(i):
        if i in changed:raise ValueError('Ce côté ne peut pas être déplacé seul.')
        changed.add(i)
    def slide_end(i,end,p):
        """0.19.23: an end of the curve i slides on its circle to p; both may (a half moon: the curve from one end of
        the side to the other; a curve between the two rounds of the side)."""
        if (i in changed and i not in circle) or end in circle.get(i,()):raise ValueError('Ce côté ne peut pas être déplacé seul.')
        changed.add(i);circle.setdefault(i,{})[end]=p
    def line_of(i):return lines.get(i,(E[i]['a'],E[i]['u']))
    def corner(i,j):
        """Where the sides i and j meet now, the round between them seen as a sharp corner."""
        (p,a),(r,b)=line_of(i),line_of(j)
        return _meet(p,a,r,b)
    def inner_at(i,p):
        """A point inside the straight side i (in line with its ends), where it is now."""
        if i==S:return plus(p)
        if i in pivots:
            wa,wb,na,nb_=(complex(*x) for x in pivots[i]);z=na+(complex(*p)-wa)*(nb_-na)/(wb-wa)
            return (z.real,z.imag)
        return p
    def curve_moved(J,step,own,far):
        """The arc J beyond the end of the side, not a round between two straight sides."""
        e=E[J];K=nb(J,step);v=plus(E[S][own]);F=e[far]
        at_side=smooth(S,J) if step==1 else smooth(J,S)
        at_far=K is not None and K!=S and (smooth(J,K) if step==1 else smooth(K,J))
        if at_side and at_far and E[K]['kind']=='arc':
            # a round between the side and a curve: its radius kept, tangent to both again (the curve keeps its circle)
            take(J);f=E[K];c,ck=e['c'],f['c'];D=math.dist(c,ck)
            w=(c[0]+t[0]-ck[0],c[1]+t[1]-ck[1]);b=w[0]*u[0]+w[1]*u[1];disc=b*b-(w[0]**2+w[1]**2-D*D)
            if disc<0:raise ValueError('Un arrondi ne tient plus entre ses côtés.')
            lam=-b+math.copysign(math.sqrt(disc),b);c2=(c[0]+t[0]+u[0]*lam,c[1]+t[1]+u[1]*lam)
            a0=plus(E[S]['a']);h=(c2[0]-a0[0])*u[0]+(c2[1]-a0[1])*u[1];T1=(a0[0]+u[0]*h,a0[1]+u[1]*h)
            o=e[far];way=1 if (o[0]-ck[0])*(c[0]-ck[0])+(o[1]-ck[1])*(c[1]-ck[1])>=0 else -1   # where the circles touch
            L=math.dist(c2,ck)
            if L<1e-9:raise ValueError('Un arrondi ne tient plus entre ses côtés.')
            T2=(ck[0]+way*f['r']*(c2[0]-ck[0])/L,ck[1]+way*f['r']*(c2[1]-ck[1])/L)
            rebuilt[J]=(T1,T2,c2,_sweep_like(c2,T1,T2,e['sweep'])) if step==1 else (T2,T1,c2,_sweep_like(c2,T2,T1,e['sweep']))
            if rebuilt[J][3] is None:raise ValueError('Un arrondi ne tient plus entre ses côtés.')
            slide_end(K,'a' if step==1 else 'b',T2);ends[(S,own)]=T1;return
        ta=e['ta'] if step==1 else e['tb']
        if not at_side and (K==S or J in circle or abs(u[0]*ta[1]-u[1]*ta[0])>=SLIDE):
            # a corner of 30° or more: the curve keeps its circle (its other end and its tangents there), the corner
            # slides on it, as a straight side beyond keeps its line (0.19.23: at any corner when the curve goes back to
            # the side, a half moon, or keeps its circle at its other end already)
            c,r=e['c'],e['r'];X=plus(E[S]['a']);w=(X[0]-c[0],X[1]-c[1]);b=w[0]*u[0]+w[1]*u[1];disc=b*b-(w[0]**2+w[1]**2-r*r)
            if disc<0:raise ValueError('La courbe voisine ne tient plus.')
            C=min(((X[0]+u[0]*l,X[1]+u[1]*l) for l in (-b+math.sqrt(disc),-b-math.sqrt(disc))),key=lambda p:math.dist(p,v))
            slide_end(J,'a' if step==1 else 'b',C);ends[(S,own)]=C;return
        if K==S:raise ValueError('Ce côté ne peut pas être déplacé seul.')
        take(J);ends[(S,own)]=v
        if at_side or at_far:
            # tangent at one end only: the arc from the side's end moved to its far end, tangent where it was
            if step==1:A,Z=v,F;sweep=_arc_from(A,Z,ta=u) if at_side else _arc_from(A,Z,tb=e['tb'])
            else:A,Z=F,v;sweep=_arc_from(A,Z,tb=u) if at_side else _arc_from(A,Z,ta=e['ta'])
            if math.dist(A,Z)<1e-9 or abs(sweep)<1e-9 or (sweep>0)!=(e['sweep']>0) or abs(sweep-e['sweep'])>=math.pi:
                raise ValueError('La courbe voisine ne tient plus.')
            rebuilt[J]=(A,Z,_centre(A,Z,sweep),sweep);return
        scaled[J]=(F,E[S][own],v)   # met at shallow corners: its shape kept
    for step in (1,-1):   # the end of the side, then its start
        own='b' if step==1 else 'a'          # the end of the side on that way
        near,far=('a','b') if step==1 else ('b','a')   # the ends of the next element: at the side, away from it
        J=nb(S,step)
        if J is None:ends[(S,own)]=plus(E[S][own]);continue   # an open end
        if is_line(J):P=J   # a sharp corner
        elif round_at(J) and abs(E[J]['sweep'])>=U_TURN:
            # the round end of a strap: the arc tangent to the side beyond where it starts (that side stays) and to the
            # side moved: the half circle between them when they are parallel
            take(J);e=E[J];P=nb(J,step);T2=E[P][near];c0=e['c'];w=E[P]['u']
            nS=(-u[1],u[0]);nS=nS if (c0[0]-E[S]['a'][0])*nS[0]+(c0[1]-E[S]['a'][1])*nS[1]>0 else (-nS[0],-nS[1])   # towards its centre
            nP=(-w[1],w[0]);nP=nP if (c0[0]-T2[0])*nP[0]+(c0[1]-T2[1])*nP[1]>0 else (-nP[0],-nP[1])
            X=plus(E[S]['a']);den=1-(nP[0]*nS[0]+nP[1]*nS[1])
            rho=((T2[0]-X[0])*nS[0]+(T2[1]-X[1])*nS[1])/den if den>1e-9 else 0
            if rho<=1e-3:raise ValueError('La sangle devient trop étroite.')
            c=(T2[0]+nP[0]*rho,T2[1]+nP[1]*rho);T1=(c[0]-nS[0]*rho,c[1]-nS[1]*rho)
            rebuilt[J]=(T1,T2,c,_sweep_like(c,T1,T2,e['sweep'])) if step==1 else (T2,T1,c,_sweep_like(c,T2,T1,e['sweep']))
            if rebuilt[J][3] is None:raise ValueError('La sangle devient trop étroite.')
            ends[(S,own)]=T1;continue
        elif round_at(J):P=nb(J,step)   # a round: seen as the corner where its two sides meet
        else:curve_moved(J,step,own,far);continue
        w=E[P]['u']
        if abs(u[0]*w[1]-u[1]*w[0])>=SLIDE:
            # the side beyond keeps its line: the corner slides along it (the angle of the piece kept there)
            C=corner(S,P)
            if C is None:raise ValueError('Ce côté ne peut pas être déplacé ici.')
            if is_line(J):ends[(S,own)]=ends[(P,near)]=C
            continue
        # nearly in line with the side: the corner moves with the side, the side beyond turns about its other corner
        # (sharp, or the corner of its round)
        C=E[S][own] if is_line(J) else _meet(E[S]['a'],u,E[P]['a'],w)   # the corner as it was
        if C is None:raise ValueError('Ce côté ne peut pas être déplacé ici.')
        take(P);v=plus(C);K=nb(P,step);pivot=E[P][far]
        if K is not None and K!=S and round_at(K) and abs(E[K]['sweep'])<U_TURN:
            L=nb(K,step)
            if L is not None and L!=S:pivot=corner(P,L) or pivot
        elif K is not None and K!=S and E[K]['kind']=='arc' and (smooth(P,K) if step==1 else smooth(K,P)):
            # a curve going on from it (or the round end of a strap): the side turns staying tangent to it, the curve
            # keeps its circle (its end slides on it)
            f=E[K];c,r=f['c'],f['r'];D=math.dist(v,c)
            if D<=r*(1+1e-9):raise ValueError('La courbe voisine ne tient plus.')
            a=math.acos(r/D);phi=math.atan2(v[1]-c[1],v[0]-c[0]);best=None
            for way in (1,-1):
                T=(c[0]+r*math.cos(phi+way*a),c[1]+r*math.sin(phi+way*a));g=_unit(v,T) if step==1 else _unit(T,v)
                if best is None or g[0]*w[0]+g[1]*w[1]>best[0]:best=(g[0]*w[0]+g[1]*w[1],T,g)
            _,T,g=best;way=1 if f['sweep']>0 else -1;go=(-(T[1]-c[1])*way/r,(T[0]-c[0])*way/r)   # the curve's way at T
            if g[0]*go[0]+g[1]*go[1]<=0:raise ValueError('La courbe voisine ne tient plus.')
            lines[P]=(v,g);pivots[P]=(C,E[P][far],v,T) if step==1 else (E[P][far],C,T,v);ends[(P,far)]=T
            slide_end(K,'a' if step==1 else 'b',T)
            if g[0]*w[0]+g[1]*w[1]<=0:raise ValueError('Le côté voisin devient trop court.')
            if is_line(J):ends[(S,own)]=ends[(P,near)]=v
            continue
        if math.dist(pivot,v)<1e-6 or math.dist(pivot,C)<1e-6:raise ValueError('Le côté voisin devient trop court.')
        lines[P]=(v,_unit(v,pivot) if step==1 else _unit(pivot,v));pivots[P]=(C,pivot,v,pivot) if step==1 else (pivot,C,pivot,v)
        if lines[P][1][0]*w[0]+lines[P][1][1]*w[1]<=0:raise ValueError('Le côté voisin devient trop court.')
        if is_line(J):ends[(S,own)]=ends[(P,near)]=v
    for i,slid in circle.items():   # each curve keeping its circle, from its ends as they are now
        e=E[i];A,Z=slid.get('a',e['a']),slid.get('b',e['b']);sweep=_sweep_like(e['c'],A,Z,e['sweep'])
        if sweep is None or math.dist(A,Z)<1e-6:raise ValueError('La courbe voisine ne tient plus.')
        rebuilt[i]=(A,Z,e['c'],sweep)
    # every round between two straight sides of which one moved or turned: its radius kept, tangent to both again
    for i,e in enumerate(E):
        if not round_at(i) or i in rebuilt or abs(e['sweep'])>=U_TURN:continue
        A,Z=nb(i,-1),nb(i,1)
        if A not in lines and Z not in lines:continue
        C=corner(A,Z);ua,uz=line_of(A)[1],line_of(Z)[1];sweep=_turn(ua,uz)
        if C is None or abs(sweep)<1e-9 or (sweep>0)!=(e['sweep']>0):raise ValueError('Un arrondi ne tient plus entre ses côtés.')
        L=e['r']*math.tan(abs(sweep)/2);T1=(C[0]-ua[0]*L,C[1]-ua[1]*L);T2=(C[0]+uz[0]*L,C[1]+uz[1]*L)
        k=1 if sweep>0 else -1;centre=(T1[0]-ua[1]*e['r']*k,T1[1]+ua[0]*e['r']*k)
        rebuilt[i]=(T1,T2,centre,sweep);ends[(A,'b')]=T1;ends[(Z,'a')]=T2
    # each straight side changed still goes its way, long enough; 0.19.23: a point inside it (Mozart, Couper) is part
    # of it: one its ends went past is left out (its crans go to that end), it never stops the move
    inside={};gone={}   # straight side: its points inside kept ((index in q, as it was, as it is now)); those left out
    for i,e in enumerate(E):
        if e['kind']!='line':continue
        if (i,'a') not in ends and (i,'b') not in ends:inside[i]=[(j,p,p) for j,p in zip(e['segs'][1:],e['inner'])];continue
        a,b=ends.get((i,'a'),e['a']),ends.get((i,'b'),e['b']);w=line_of(i)[1]
        if (b[0]-a[0])*w[0]+(b[1]-a[1])*w[1]<=1e-3:raise ValueError('Le côté devient trop court.' if i==S else 'Le côté voisin devient trop court.')
        inside[i]=[];last=a
        for j,p in zip(e['segs'][1:],e['inner']):
            z=inner_at(i,p)
            if (z[0]-last[0])*w[0]+(z[1]-last[1])*w[1]>1e-3 and (b[0]-z[0])*w[0]+(b[1]-z[1])*w[1]>1e-3:inside[i].append((j,p,z));last=z
            else:gone.setdefault(i,[]).append((p,a if (z[0]-a[0])*w[0]+(z[1]-a[1])*w[1]<=(b[0]-z[0])*w[0]+(b[1]-z[1])*w[1] else b))
        # (a point nearly in line that an end came close to, turning the side there twice as much as it did: left out
        # too, the side stays one side)
        def bent(now,was):return abs(_turn(w,_unit(*now)))>=max(STRAIGHT/2,2*abs(_turn(e['u'],_unit(*was))))
        while inside[i] and bent((a,inside[i][0][2]),(e['a'],inside[i][0][1])):gone.setdefault(i,[]).append((inside[i].pop(0)[1],a))
        while inside[i] and bent((inside[i][-1][2],b),(inside[i][-1][1],e['b'])):gone.setdefault(i,[]).append((inside[i].pop()[1],b))
    # the polyline again, element after element (each gives its start and its points inside); src: the point of q
    # each one was (None: a point new on a round remade); tag: its element
    pts=[];bulges=[];src=[];tag=[]
    for i,e in enumerate(E):
        if e['kind']=='line':
            pts.append(ends.get((i,'a'),e['a']));bulges.append(0.);src.append(e['segs'][0]);tag.append(i)
            for j,_,z in inside[i]:pts.append(z);bulges.append(0.);src.append(j);tag.append(i)
            continue
        if i in rebuilt:
            T1,T2,c,sweep=rebuilt[i]
            parts=max(1,math.ceil(abs(sweep)/(math.pi/2)-1e-9));a0=math.atan2(T1[1]-c[1],T1[0]-c[0]);r=math.dist(T1,c)
            for j in range(parts):
                a=a0+sweep*j/parts;pts.append(T1 if j==0 else (c[0]+r*math.cos(a),c[1]+r*math.sin(a)));bulges.append(math.tan(sweep/parts/4))
                src.append(e['segs'][0] if j==0 else None);tag.append(i)
            continue
        old=[V[j] for j in e['segs']]
        if i in scaled:
            fixed,was,now=scaled[i];zf=complex(*fixed)
            zk=(complex(*now)-zf)/(complex(*was)-zf) if math.dist(was,fixed)>1e-9 else 1
            old=[(z.real,z.imag) for z in ((complex(*p)-zf)*zk+zf for p in old)]
        pts.extend(old);bulges.extend(B[j] for j in e['segs']);src.extend(e['segs']);tag.extend(i for _ in e['segs'])
    if not closed:pts.append(ends.get((N-1,'b'),E[N-1]['b']));bulges.append(0.);src.append(n-1);tag.append(N-1)
    clean,kept,origin,tags=[],[],[],[]
    for p,b,o,g in zip(pts,bulges,src,tag):
        if clean and math.dist(p,clean[-1])<1e-9:continue   # a side of no length left (never an arc's)
        clean.append(p);kept.append(b);origin.append(o);tags.append(g)
    if closed and len(clean)>2 and math.dist(clean[-1],clean[0])<1e-9:clean.pop();kept.pop();origin.pop();tags.pop()
    if len(clean)<(2 if not closed or any(kept) else 3):raise ValueError('Ce côté ne peut pas être déplacé ici.')
    if closed and outline_area(clean,kept)*outline_area(V,B)<=0:raise ValueError('Ligne/polyligne inversée')   # (0.19.23: its arcs too)
    # 0.19.23: what changed crosses no other part of the outline (unless it already did)
    hot=changed|{i for i,_ in ends}|set(rebuilt)|set(scaled)|set(pivots)
    crossed=crossing_pairs(outline_chords(clean,kept,closed,tags),hot)
    if crossed:
        of={j:i for i,e in enumerate(E) for j in e['segs']}
        if crossed-crossing_pairs(outline_chords(V,B,closed,[of.get(j,-1) for j in range(n)]),hot):raise ValueError('Le contour se croise.')
    if closed:   # the polyline starts where it started (its first point moved or not; left out: the next one kept)
        first_kept=min((o for o in origin if o is not None),default=None)
        if first_kept is not None:r=origin.index(first_kept);clean=clean[r:]+clean[:r];kept=kept[r:]+kept[:r]
    out=polygon(clean,q.get('name',''),closed)
    out.update({key:copy.deepcopy(v) for key,v in q.items() if key not in ('kind','x','y','w','h','r','points','closed','name','bulges')})
    if any(kept):out['bulges']=kept if closed else kept[:-1]+[0.]
    moved=[]
    def add(o,p):
        if math.dist(o,p)>1e-12 and not any(math.dist(o,x)<1e-9 for x,_ in moved):moved.append((o,p))
    for (i,end),p in ends.items():
        if E[i]['kind']=='line':add(E[i][end],p)
    for i,e in enumerate(E):
        if e['kind']=='line':
            for _,p,z in inside[i]:add(p,z)
            for p,z in gone.get(i,()):add(p,z)
        elif arcs is not None and (i in rebuilt or i in scaled):
            if i in rebuilt:T1,T2,c,sweep=rebuilt[i];now=(c,math.dist(T1,c),T1,sweep)
            else:
                fixed,was,at=scaled[i];zf=complex(*fixed);zk=(complex(*at)-zf)/(complex(*was)-zf) if math.dist(was,fixed)>1e-9 else 1
                c,a=((complex(*p)-zf)*zk+zf for p in (e['c'],e['a']));now=((c.real,c.imag),e['r']*abs(zk),(a.real,a.imag),e['sweep'])
            arcs.append(((e['c'],e['r'],e['a'],e['sweep']),now))
    return out,moved


def raccord_side(v,click):
    """0.19.5: the straight side of ``v`` at a raccord: (its two ends, the ends a raccord may join: both
    for a line or a cut line, the free one for the end side of an open polyline); None for anything else."""
    if v['kind']=='line' and not v.get('annotation'):E=_open_ends(v);return E,E
    E=straight_ends(v)
    if E:return E,E
    side=open_end_side(v,click)
    return ((side[0],side[1]),(side[1],)) if side else None


def _open_ends(v):
    """0.19.4: the two ends of an open line or polyline, read directly (no tessellation); None for
    anything else (a closed form, a circle, a curve, a text…)."""
    if v.get('spline') or v.get('ellipse') or v.get('components') or v.get('annotation') or v.get('is_notch'):return None
    if v['kind']=='line':return (v['x'],v['y']),(v['x']+v['w'],v['y']+v['h'])
    if v['kind']=='poly' and not v.get('closed') and v.get('points'):
        (x0,y0),(x1,y1)=v['points'][0],v['points'][-1];return (v['x']+x0,v['y']+y0),(v['x']+x1,v['y']+y1)
    return None


def corner_ends(a,b,p,q=None,other=False):
    """0.19.4: the end of each of two straight sides at the corner a raccord between them is made (the
    same rule as the raccord itself), where a raccord done there before attaches. Two parallel sides:
    the end of the first next to its click ``p``, and the end of the second on that side. Otherwise: the
    ends next to the crossing of the two lines. None when the sides cross or touch (nothing joins them
    at that corner yet)."""
    S,T=raccord_side(a,p),raccord_side(b,q if q is not None else p)
    if S is None or T is None:return None
    (A,fa),(B,fb)=S,T
    if math.dist(*A)<=EPS or math.dist(*B)<=EPS or _touching(A,B):return None
    if parallel(*A,*B):
        if len(fa)==1 and math.dist(p,fa[0])>math.dist(p,A[0]):return None   # (as parallel_sides: not at the polyline's end)
        E,far=(A if math.dist(p,A[0])<=math.dist(p,A[1]) else A[::-1]) if len(fa)==2 else ((fa[0],A[0]) if fa[0]==A[1] else (fa[0],A[1]))
        # 0.19.6 ``other``: the other end of the second side (with a radius smaller than the gap, the second
        # side may go on past the corner: the raccord is at its nearer end).
        u=(E[0]-far[0],E[1]-far[1]);ca,cb=E,max(B,key=lambda e:e[0]*u[0]+e[1]*u[1])
        if other:
            if len(fb)==1:return None
            cb=B[0] if cb==B[1] else B[1]
    else:
        from editing import line_intersection
        I=line_intersection(*A,*B);near=lambda P:min(P,key=lambda e:math.dist(e,I))
        ca,cb=near(A),near(B)
    if ca not in fa or cb not in fb:return None   # a polyline's end side turned away from that corner
    return None if math.dist(ca,cb)<=.02 else (ca,cb)


def _touching(A,B,tol=.02):
    """0.19.4: the segments A and B cross or touch."""
    def gap(x,P):
        (x0,y0),(x1,y1)=P;dx,dy=x1-x0,y1-y0;n=dx*dx+dy*dy
        k=0 if n<=EPS*EPS else max(0,min(1,((x[0]-x0)*dx+(x[1]-y0)*dy)/n))
        return math.dist(x,(x0+k*dx,y0+k*dy))
    if any(gap(x,B)<=tol for x in A) or any(gap(x,A)<=tol for x in B):return True
    side=lambda o,P,Q:(P[0]-o[0])*(Q[1]-o[1])-(P[1]-o[1])*(Q[0]-o[0])
    (p,q),(r,t)=A,B
    return side(r,t,p)*side(r,t,q)<0 and side(p,q,r)*side(p,q,t)<0


def corner_links(items,ids,a,b,p,q):
    """0.19.6: the pieces joining two sides at the corner of a raccord (corner_ends, links_between): at the
    second side's farther end, or else at its other one."""
    corner=corner_ends(a,b,p,q)
    found=links_between(items,ids,*corner) if corner else set()
    if not found:
        corner=corner_ends(a,b,p,q,other=True)
        if corner:found=links_between(items,ids,*corner)
    return found


def links_between(items,ids,ca,cb,tol=.02,most=40):
    """0.19.4: the drawing's pieces joining the corner ends ``ca`` and ``cb``: one piece (a round, a
    chamfer, a square side, a half round), or two pieces meeting (a point); never ``ids``. Only open
    lines and polylines are looked at, by their ends (fast on a big pattern: no tessellation).
    0.19.6: or a chain of pieces end to end (a belt end made on lines: its sides and its rounds), followed
    from ``ca`` while each junction joins two pieces only."""
    touch=lambda x,y:abs(x[0]-y[0])<tol and abs(x[1]-y[1])<tol and math.dist(x,y)<tol
    size=4*tol;ends={};grid={}
    for k,v in enumerate(items):
        if k in ids:continue
        E=_open_ends(v)
        if E is None:continue
        if math.dist(*E)<=tol:continue
        ends[k]=E
        for e in E:grid.setdefault((round(e[0]/size),round(e[1]/size)),[]).append(k)
    def near(x):
        cx,cy=round(x[0]/size),round(x[1]/size);out=[]
        for i in (-1,0,1):
            for j in (-1,0,1):
                for k in grid.get((cx+i,cy+j),()):
                    if k not in out and (touch(ends[k][0],x) or touch(ends[k][1],x)):out.append(k)
        return out
    found=set()
    for first in near(ca):
        chain=[first];at=ca;k=first
        while len(chain)<=most:
            e0,e1=ends[k];other=e1 if touch(e0,at) else e0
            if touch(other,cb):found|=set(chain);break
            nxt=[m for m in near(other) if m!=k]
            if len(nxt)!=1 or nxt[0] in chain:break   # a branch, a dead end, a loop
            k=nxt[0];chain.append(k);at=other
    return found


def end_directions(v):
    """0.18.5: the ends of an open contour with its direction there: [(point, unit vector)]."""
    from precision_geometry import open_ends
    if not open_ends(v):return []
    if v.get('spline') or v.get('ellipse') or v.get('components'):
        pts=path(v)[0];pairs=((pts[0],pts[1]),(pts[-2],pts[-1]))
        out=[]
        for (a,b),x in zip(pairs,(pts[0],pts[-1])):
            n=math.dist(a,b)
            if n>EPS:out.append((x,((b[0]-a[0])/n,(b[1]-a[1])/n)))
        return out
    L=contour_length(v)
    return [(x,direction_at(v,d)) for x,d in ((path(v)[0][0],0.),(path(v)[0][-1],L))] if L>EPS else []


def left_behind(items,ids,new,masks):
    """0.18.5 (n° 26): the drawing's lines left behind the joined outline. A line one end of which
    was on a portion this raccord removed, whose other end meets nothing, and which touches the
    kept outline between its ends (the back edge of a strap that only touches its round end, as
    in n° 8) is removed too."""
    from cad import distance_to_shape
    from craft_tools import at_distance,perimeter
    from geometry import bounds
    from entity_rules import geometry_entity
    from precision_geometry import open_ends
    stubs=[x for m in masks for x in open_ends(m)];out=set()
    if not stubs:return out
    def close(x,w,tol):
        x0,y0,x1,y1=bounds([w])
        return x0-tol<=x[0]<=x1+tol and y0-tol<=x[1]<=y1+tol and distance_to_shape(x,w)<=tol
    for k,v in enumerate(items):
        if k in ids or not geometry_entity(v):continue
        ends=open_ends(v)
        if len(ends)!=2:continue
        tied=[any(math.dist(x,y)<=.02 for y in stubs) for x in ends]
        if sum(tied)!=1:continue
        loose=ends[tied.index(False)]
        if any(close(loose,w,.02) for w in new) or any(close(loose,w,.02) for n,w in enumerate(items) if n not in ids and n!=k and geometry_entity(w)):continue
        L=perimeter(v);m=max(8,min(400,int(L/.25)))
        if any(.2<=L*n/m<=L-.2 and any(close(at_distance(v,L*n/m)[0],w,.05) for w in new) for n in range(m+1)):out.add(k)
    return out
