"""0.18.1 « ID unique » (Identification group, green icon with a 1): numbers on the pieces, in the
order the person chooses, for the nomenclature (RP) and the précoupe / surcoupe.

The number is a green badge placed where one clicks in the piece, attached to it (it moves, turns
and is copied with it) and moved afterwards like a text; a double click changes it. Entrée numbers
the pieces left in the order of the base's columns. A number is never given to another piece:
the last one given is kept in the Infos du modèle (« dernier_id »), a copied badge gets a new one.
0.18.2: a number already given, typed on another badge, is asked (« Le numéro 5 est déjà attribué
à RABAT 1… ») and, when confirmed, the numbers between it and the badge's old one move by one."""
import copy
import math

GREEN = '#2fa84f'
EDGE = '#1d6e33'
SIZE = 10.      # mm: diameter of the badge on the plan


def badge(number, p, owner=None, size=SIZE):
    """The badge of piece number ``number`` centred on ``p``."""
    from cad import polygon
    r = size / 2
    s = polygon([(p[0] - r, p[1] - r), (p[0] + r, p[1] - r), (p[0] + r, p[1] + r), (p[0] - r, p[1] + r)], f'ID {number}', True)
    s.update(annotation=True, label=str(number), text_height=round(size * .55, 3), piece_badge=int(number))
    s['style'] = dict(color=GREEN, width=.2, dash=[], role='badge')
    if owner:
        s['owner_id'] = owner
    return s


def centre(s):
    from geometry import bounds
    x, y, X, Y = bounds([s])
    return (x + X) / 2, (y + Y) / 2


def numbers(items):
    """{piece_id: number} of the numbered pieces (a badge copied alone on its piece: the first
    one is its number)."""
    out = {}
    for s in items:
        if s.get('piece_badge') and s.get('owner_id'):
            out.setdefault(s['owner_id'], s['piece_badge'])
    return out


def number_of(items, piece):
    owner = items[piece].get('piece_id') if 0 <= piece < len(items) else None
    return numbers(items).get(owner) if owner else None


def last_number(items, infos=None):
    known = [s['piece_badge'] for s in items if s.get('piece_badge')]
    try:
        kept = int((infos or {}).get('dernier_id', 0))
    except (TypeError, ValueError):
        kept = 0
    return max(known + [kept, 0])


def pieces(items):
    """The pieces that can be numbered: closed contours in Coupe externe."""
    from entity_rules import closed_piece
    from craft_tools import style
    return [i for i, s in enumerate(items) if closed_piece(s) and style(s)['role'] == 'external']


def column(workspace, x):
    """Index of the base column at ``x`` (0 without base)."""
    if not workspace:
        return 0
    edge = workspace.get('origin_x', 0.)
    for k, w in enumerate(workspace.get('widths', [])):
        if x < edge + w:
            return k
        edge += w
    return len(workspace.get('widths', []))


def ordered(items, ids, workspace=None):
    """``ids`` in the order of the base: columns from left to right, then from top to bottom."""
    from geometry import bounds
    def key(i):
        x, y, X, Y = bounds([items[i]])
        return column(workspace, (x + X) / 2), round(y, 1), round(x, 1)
    return sorted(ids, key=key)


def inner_point(s):
    """A point inside a closed piece, near its middle (the badge of a piece numbered by Entrée)."""
    from geometry import bounds
    from precision_geometry import inside
    x, y, X, Y = bounds([s])
    c = ((x + X) / 2, (y + Y) / 2)
    if inside(s, c):
        return c
    best = None
    for i in range(1, 20):
        for j in range(1, 20):
            p = (x + (X - x) * i / 20, y + (Y - y) * j / 20)
            if inside(s, p):
                d = math.dist(p, c)
                if best is None or d < best[0]:
                    best = (d, p)
    return best[1] if best else c


def badge_point(items, i):
    """Where Entrée puts the badge of piece ``i``: near its middle; for a précoupe, in its first
    piece to recut (its middle is often the band between them)."""
    import surcoupe as sc
    if sc.is_precut(items[i]):
        inner = sc.inner_contours(items, i)
        if inner:
            return inner_point(items[inner[0]])
    return inner_point(items[i])


def host_at(items, p):
    """The piece clicked: the smallest piece in Coupe externe around ``p``."""
    from geometry import bounds
    from precision_geometry import inside
    best = None
    for i in pieces(items):
        x, y, X, Y = bounds([items[i]])
        if x <= p[0] <= X and y <= p[1] <= Y and inside(items[i], p):
            area = (X - x) * (Y - y)
            if best is None or area < best[0]:
                best = (area, i)
    return None if best is None else best[1]


def badge_index(items, owner):
    return next((k for k, s in enumerate(items) if s.get('piece_badge') and s.get('owner_id') == owner), None)


def owner_name(items, k):
    """The name of the piece of badge ``k`` (None without name)."""
    from export_check import piece_name
    owner = items[k].get('owner_id')
    i = next((j for j, s in enumerate(items) if owner and s.get('piece_id') == owner and not s.get('piece_badge')), None)
    if i is None:
        return None
    name = piece_name(items, i)
    return None if name.startswith('pièce n°') else name


def shifted(items, k, n):
    """{badge index: number} when badge ``k`` takes number ``n``: the badges numbered from ``n``
    towards its old number move by one, up to the first number free (its old one at the latest):
    no gap made, no number twice. ``n`` free: only badge ``k`` changes."""
    old = items[k]['piece_badge']
    used = {s['piece_badge']: j for j, s in enumerate(items) if s.get('piece_badge') and j != k}
    out = {k: n}
    step = 1 if n < old else -1
    m = n
    while m in used and m != old:
        out[used[m]] = m + step
        m += step
    return out


def shift_question(items, k, n):
    """« Le numéro 5 est déjà attribué à RABAT 1. / Êtes-vous sûr de vouloir l'attribuer à DOS ? /
    Les numéros 5 à 7 deviendront 6 à 8. »"""
    other = next((j for j, s in enumerate(items) if j != k and s.get('piece_badge') == n), None)
    moved = sorted((items[j]['piece_badge'], m) for j, m in shifted(items, k, n).items() if j != k)
    text = f'Le numéro {n} est déjà attribué à {(owner_name(items, other) if other is not None else None) or "une autre pièce"}.\n'
    text += f'Êtes-vous sûr de vouloir l’attribuer à {owner_name(items, k) or "cette pièce"} ?'
    if len(moved) == 1:
        text += f'\nLe numéro {moved[0][0]} deviendra {moved[0][1]}.'
    elif len(moved) == 2:
        text += f'\nLes numéros {moved[0][0]} et {moved[1][0]} deviendront {moved[0][1]} et {moved[1][1]}.'
    elif moved:
        text += f'\nLes numéros {moved[0][0]} à {moved[-1][0]} deviendront {moved[0][1]} à {moved[-1][1]}.'
    return text


def renumbered_copies(items, infos=None):
    """A badge copied with its piece (Copier, Miroir…) gets a new number; the first one keeps
    it. Returns the new last number, or None when nothing changed."""
    seen = set()
    last = last_number(items, infos)
    changed = False
    for s in items:
        n = s.get('piece_badge')
        if not n:
            continue
        if n in seen:
            last += 1
            s['piece_badge'] = last
            s['label'] = str(last)
            s['name'] = f'ID {last}'
            changed = True
        seen.add(s['piece_badge'])
    return last if changed else None


# ------------------------------------------------------------------ the tool
def start(app):
    app.finish_action()
    app.cancel()
    app.tool.set('piece_id')
    app.last_command = ('tool', 'piece_id')
    app.selected = None
    app.selected_set = set()
    app.id_state = dict(given=0)
    app.highlight_tools()
    app.refresh()
    app.status.set('Cliquer dans les pièces dans l’ordre (1, 2, 3…) · Entrée : numéroter les autres.')


def cancel(app):
    app.id_state = None


def remember_last(app, last):
    infos = dict(app.__dict__.get('infos') or {})
    infos['dernier_id'] = str(last)
    app.infos = infos


def click(app, e):
    """A click in a piece: its badge goes there (a new number when it has none)."""
    from entity_rules import ensure_piece_id
    p = app.raw(e)
    i = host_at(app.items, p)
    if i is None:
        app.invalid_at(e, 'Cliquer dans une pièce en Coupe externe.')
        return
    app.snapshot()   # before the piece is given an id: Annuler leaves it as it was
    owner = ensure_piece_id(app.items[i])
    k = badge_index(app.items, owner)
    if k is not None:
        old = app.items[k]
        new = badge(old['piece_badge'], p, owner)
        for key in ('style', 'text_height'):
            new[key] = copy.deepcopy(old.get(key, new[key]))
        app.items[k] = new
        app.status.set(f'Pièce n° {old["piece_badge"]} : pastille déplacée.')
    else:
        number = last_number(app.items, app.__dict__.get('infos')) + 1
        app.items.append(badge(number, p, owner))
        remember_last(app, number)
        st = app.__dict__.get('id_state') or {}
        st['given'] = st.get('given', 0) + 1
        app.status.set(f'Pièce n° {number} · cliquer la suivante · Entrée : numéroter les autres.')
    app.refresh()


def enter(app):
    """Entrée: the pieces still without number, in the order of the base's columns."""
    from entity_rules import ensure_piece_id
    known = numbers(app.items)
    left = [i for i in pieces(app.items) if app.items[i].get('piece_id') not in known]
    if left:
        app.snapshot()
        last = last_number(app.items, app.__dict__.get('infos'))
        for i in ordered(app.items, left, app.workspace):
            last += 1
            app.items.append(badge(last, badge_point(app.items, i), ensure_piece_id(app.items[i])))
        remember_last(app, last)
    app.id_state = None
    app.complete_command('piece_id')
    app.highlight_tools()
    app.refresh()
    app.status.set(f'{len(left)} pièce(s) numérotée(s).' if left else 'Toutes les pièces sont numérotées.')
    return 'break'


def edit_number(app, i):
    """Double click on a badge: its number; one already given is asked (0.18.2), then the others
    move by one (shifted)."""
    import tkinter as tk
    from tkinter import messagebox
    s = app.items[i]
    value = tk.StringVar(value=str(s['piece_badge']))
    win = app.dialog('ID unique')
    row = tk.Frame(win, bg=app.p['panel'])
    row.pack(fill='x', padx=16, pady=(14, 8))
    app.label(row, 'Numéro de la pièce').pack(side='left')
    field = app.entry(row, value, 6)
    field.pack(side='left', padx=8)

    def valid(e=None):
        try:
            n = int(value.get().strip())
            if not 1 <= n <= 9999:
                raise ValueError
        except ValueError:
            messagebox.showerror('ID unique', 'Numéro de 1 à 9999.', parent=win)
            return 'break'
        if i < len(app.items) and app.items[i] is s and n != s['piece_badge'] and any(k != i and q.get('piece_badge') == n for k, q in enumerate(app.items)):
            # 0.18.2: a number already given is asked, then the others move by one
            if not messagebox.askyesno('ID unique', shift_question(app.items, i, n), parent=win):
                field.focus_set()
                field.select_range(0, 'end')
                return 'break'
        win.destroy()
        if i < len(app.items) and app.items[i] is s and n != s['piece_badge']:
            app.snapshot()
            for k, m in shifted(app.items, i, n).items():
                q = copy.deepcopy(app.items[k])
                q.update(piece_badge=m, label=str(m), name=f'ID {m}')
                app.items[k] = q
            remember_last(app, last_number(app.items, app.__dict__.get('infos')))
            app.refresh()
            app.status.set(f'Pièce n° {n}.')
        app.canvas.focus_set()
        return 'break'
    app.button(win, 'Valider', valid).pack(anchor='e', padx=16, pady=(2, 12))
    win.bind('<Escape>', lambda e: (win.destroy(), app.canvas.focus_set()))
    field.bind('<Return>', valid)
    field.select_range(0, 'end')
    field.focus_set()
    return True


def draw_badge(app, s, tags, chosen):
    """The green badge and its number (a preview: its outline only)."""
    c = app.canvas
    x, y = app.to_screen(centre(s))
    from geometry import path
    pts = path(s)[0]
    side = math.dist(pts[0], pts[1]) if len(pts) > 1 else SIZE   # turned with its piece: the same size
    r = max(3., side / 2 * app.scale)
    if tags:
        return c.create_oval(x - r, y - r, x + r, y + r, outline=app.p['accent'], width=1, tags=tags)
    item = c.create_oval(x - r, y - r, x + r, y + r, fill=GREEN, outline=app.p['accent'] if chosen else EDGE, width=2 if chosen else 1, tags='piece_badge')
    factor = 1.1 if len(s.get('label', '')) < 3 else .85
    size = round(r * factor)
    if size >= 5:
        from ui_widgets import zoom_tag   # 0.18.3: its size in mm, for the wheel zoom (unless held at its smallest)
        c.create_text(x, y, text=s.get('label', ''), fill='#ffffff', font=('Segoe UI', -size, 'bold'),
                      tags=zoom_tag('piece_badge', 't', side / 2 * factor) if side / 2 * app.scale > 3 else 'piece_badge')
    return item
