"""0.19.15 Mises à jour par Internet de l'édition partagée (pour ses amis : « qu'ils puissent installer via internet
et obtenir les maj sans que j'ai à renvoyer à chaque fois », 08/11/2026).

Only with craft_distribution.py, which only the shared edition has (never his own Craft): at Craft's start (a few
seconds after the window, once a day at most) and by Aide › Rechercher une mise à jour, the small file published
with each version (craft_distribution.MANIFESTE: version, link, size and fingerprint of the update ZIP, signed with
the update key whose public part is craft_distribution.CLE) is read. A newer version is downloaded in the background
into the data folder (Mises_a_jour); its size and fingerprint are checked, then the ZIP as any update
(updater.read_bundle) and as the shared edition (licence_cle.py and craft_distribution.py in it). « Mise à jour
disponible › Redémarrer » then closes Craft the normal way (« Enregistrer ? »), installs it and reopens it: the path
of Aide › Mettre à jour Craft depuis un ZIP. Nothing about the user is sent: a plain download, « Craft/<version> » as
its User-Agent. No connection: nothing said, tried again at the next start; a server's refusal or a certificate
refused is kept (mises_a_jour.json) and said when asked. The secure connection trusts Windows' certificates and,
when the shared edition carries them (craft_certificats), Mozilla's."""
import hashlib
import json
import os
import queue
import re
import threading
import time
from pathlib import Path

from craft_version import VERSION

DOMAINE = b'craft-mise-a-jour-v1\x00'
CHAMPS = ('app_id', 'version', 'zip', 'taille', 'sha256', 'publiee', 'signature')
LIEN = re.compile(r'https://[^\s"<>\\]{1,500}')
MAX_MANIFESTE = 20000
MAX_ZIP = 150 * 1024 * 1024
DELAI = 15000          # ms after the window, the automatic check
JOUR = 86400           # s between two automatic checks
TIMEOUT = 30           # s without an answer from the server
ETAT = 'mises_a_jour.json'
DOSSIER = 'Mises_a_jour'
PREFIXE = 'Craft_Partage_v'   # the shared edition's update ZIP (his own are Craft_Mise_a_jour_v…)
NOM = re.compile(r'Craft_Partage_v(\d{1,4}\.\d{1,4}\.\d{1,4})\.zip')
LIBELLE_MENU = 'Rechercher une mise à jour'
UNINSTALL_KEY = r'Software\Microsoft\Windows\CurrentVersion\Uninstall\Craft'


class Refus(ValueError):
    """The server answered but refused (an HTTP error) or the secure connection was refused: not « no connection »."""


def configuration():
    """{'url', 'cle'} of the shared edition; None for his own Craft (no craft_distribution) or a broken one."""
    try:
        import craft_distribution as distribution
    except ImportError:
        return None
    url, cle = getattr(distribution, 'MANIFESTE', None), getattr(distribution, 'CLE', None)
    if not isinstance(url, str) or not LIEN.fullmatch(url):
        return None
    try:
        import licence
        publique = licence.unb64(cle)
    except Exception:
        return None
    return dict(url=url, cle=publique) if len(publique) == 32 else None


def version_cle(texte):
    from updater import version_tuple
    return version_tuple(texte)


def plus_recente(version, actuelle=VERSION):
    try:
        return version_cle(version) > version_cle(actuelle)
    except (ValueError, TypeError):
        return False


# --------------------------------------------------------------------------------- the signed manifest
def message(doc):
    import licence
    return DOMAINE + licence.canonique({k: v for k, v in doc.items() if k != 'signature'})


def signer(doc, graine):
    """The manifest signed (tools/build_share.py, with the seed kept on his PC)."""
    import licence
    doc = {k: v for k, v in doc.items() if k != 'signature'}
    doc['signature'] = licence.b64(licence.signer(graine, message(doc)))
    return doc


def lire_manifeste(data, publique):
    """The published file checked: its fields, then its signature; ValueError otherwise."""
    if not isinstance(data, (bytes, bytearray)) or len(data) > MAX_MANIFESTE:
        raise ValueError('Fichier de mise à jour invalide.')
    try:
        doc = json.loads(bytes(data).decode('utf-8'))
    except (UnicodeDecodeError, ValueError) as exc:
        raise ValueError('Fichier de mise à jour illisible.') from exc
    if not isinstance(doc, dict) or set(doc) != set(CHAMPS):
        raise ValueError('Fichier de mise à jour invalide.')
    from updater import APP_ID
    version_cle(doc['version'])
    if (doc['app_id'] != APP_ID or not isinstance(doc['zip'], str) or not LIEN.fullmatch(doc['zip'])
            or type(doc['taille']) is not int or not 0 < doc['taille'] <= MAX_ZIP
            or not isinstance(doc['sha256'], str) or not re.fullmatch(r'[0-9a-f]{64}', doc['sha256'])
            or not isinstance(doc['publiee'], str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', doc['publiee'])):
        raise ValueError('Fichier de mise à jour invalide.')
    import licence
    try:
        signature = licence.unb64(doc['signature'])
    except (licence.LicenceInvalide, TypeError) as exc:
        raise ValueError('Signature de la mise à jour illisible.') from exc
    if not licence.verifier(publique, message(doc), signature):
        raise ValueError('Mise à jour refusée : elle n’est pas signée par l’auteur de Craft.')
    return doc


# --------------------------------------------------------------------------------- downloads
def contexte():
    """The secure connection: Windows' certificates, and Mozilla's when this edition carries them (a Windows
    installed afresh may not have yet the certificate a server uses)."""
    import ssl
    ctx = ssl.create_default_context()
    try:
        import craft_certificats
        ctx.load_verify_locations(cadata=craft_certificats.CERTIFICATS)
    except ImportError:
        pass
    except (ssl.SSLError, ValueError, AttributeError):
        pass
    return ctx


def _ouvrir(url, timeout):
    """urlopen with Craft's User-Agent and the secure context; a refusal (HTTP error, certificate) is a Refus, no
    connection stays an OSError."""
    import ssl
    import urllib.error
    import urllib.request   # only when Craft looks (his own Craft never imports it)
    requete = urllib.request.Request(url, headers={'User-Agent': 'Craft/' + VERSION, 'Accept': '*/*'})
    try:
        return urllib.request.urlopen(requete, timeout=timeout, context=contexte())
    except urllib.error.HTTPError as exc:
        exc.close()   # its answer is not read
        raise Refus('Le serveur des mises à jour répond : erreur %d.' % exc.code) from exc
    except urllib.error.URLError as exc:
        if isinstance(exc.reason, ssl.SSLError):
            raise Refus('Connexion sécurisée refusée (%s).' % exc.reason) from exc
        raise


def lire(url, limite=MAX_MANIFESTE, timeout=TIMEOUT):
    with _ouvrir(url, timeout) as reponse:
        data = reponse.read(limite + 1)
    if len(data) > limite:
        raise ValueError('Fichier de mise à jour trop volumineux.')
    return data


def empreinte(chemin):
    h = hashlib.sha256()
    with open(chemin, 'rb') as flux:
        for bloc in iter(lambda: flux.read(1 << 20), b''):
            h.update(bloc)
    return h.hexdigest()


def telecharger(url, chemin, taille, sha256, timeout=TIMEOUT):
    """The ZIP written beside (« …zip.<pid>.part »), put in place only with its announced size and fingerprint."""
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    partiel = chemin.with_name('%s.%d.part' % (chemin.name, os.getpid()))
    h = hashlib.sha256()
    recu = 0
    try:
        with _ouvrir(url, timeout) as reponse, open(partiel, 'wb') as flux:
            for bloc in iter(lambda: reponse.read(1 << 16), b''):
                recu += len(bloc)
                if recu > taille:
                    raise ValueError('Mise à jour plus volumineuse qu’annoncé : refusée.')
                h.update(bloc)
                flux.write(bloc)
        if recu != taille or h.hexdigest() != sha256:
            raise ValueError('Mise à jour abîmée pendant le téléchargement : elle sera reprise plus tard.')
        os.replace(partiel, chemin)
    finally:
        try:
            partiel.unlink()
        except OSError:
            pass
    return chemin


def controler(chemin, version):
    """The ZIP checked as Craft checks any update, and as this edition's (with its licence and its link)."""
    from updater import read_bundle
    manifest, payload = read_bundle(chemin)
    if manifest['version'] != version:
        raise ValueError('Mise à jour incohérente : refusée.')
    if not {'licence_cle.py', 'craft_distribution.py'} <= set(payload):
        raise ValueError('Cette mise à jour n’est pas celle de cette édition de Craft : refusée.')
    return manifest


def dossier_maj():
    from app_paths import user_data_directory
    return user_data_directory() / DOSSIER


def chemin_zip(version, dossier=None):
    return Path(dossier or dossier_maj()) / ('%s%s.zip' % (PREFIXE, version))


def chercher(conf, actuelle=VERSION, dossier=None, informer=lambda texte: None):
    """One check (in a thread): ('a_jour', version) or ('pret', version, chemin of the checked ZIP, its sha256).
    OSError: no connection; Refus: the server or the secure connection refused; ValueError: the update refused."""
    doc = lire_manifeste(lire(conf['url']), conf['cle'])
    if not plus_recente(doc['version'], actuelle):
        return ('a_jour', doc['version'])
    chemin = chemin_zip(doc['version'], dossier)
    deja = chemin.is_file() and chemin.stat().st_size == doc['taille'] and empreinte(chemin) == doc['sha256']
    if not deja:
        informer('Téléchargement de Craft %s…' % doc['version'])
        telecharger(doc['zip'], chemin, doc['taille'], doc['sha256'])
    controler(chemin, doc['version'])
    return ('pret', doc['version'], str(chemin), doc['sha256'])


def nettoyer(dossier=None, actuelle=VERSION, age=JOUR):
    """The ZIPs of versions already installed (or older), and the pieces of a download cut short a day ago."""
    dossier = Path(dossier or dossier_maj())
    retires = []
    try:
        fichiers = [p for p in dossier.iterdir() if p.is_file() and not p.is_symlink()]
    except OSError:
        return retires
    limite = time.time() - age
    for p in fichiers:
        trouve = NOM.fullmatch(p.name)
        morceau = re.fullmatch(r'Craft_Partage_v\d{1,4}\.\d{1,4}\.\d{1,4}\.zip\.\d+\.part', p.name)
        try:
            if (trouve and not plus_recente(trouve[1], actuelle)) or (morceau and p.stat().st_mtime < limite):
                p.unlink()
                retires.append(p.name)
        except OSError:
            continue
    return retires


# --------------------------------------------------------------------------------- what was found, between starts
def chemin_etat():
    from app_paths import user_data_directory
    return user_data_directory() / ETAT


def lire_etat(chemin=None):
    try:
        doc = json.loads(Path(chemin or chemin_etat()).read_text(encoding='utf-8'))
        return doc if isinstance(doc, dict) else {}
    except (OSError, ValueError):
        return {}


def ecrire_etat(etat, chemin=None):
    chemin = Path(chemin or chemin_etat())
    try:
        chemin.parent.mkdir(parents=True, exist_ok=True)
        temporaire = chemin.with_name(chemin.name + '.%d.tmp' % os.getpid())
        temporaire.write_text(json.dumps(etat, ensure_ascii=False, indent=1), encoding='utf-8')
        os.replace(temporaire, chemin)
        return True
    except OSError:
        return False


def recente(etat, maintenant=None):
    try:
        return 0 <= (maintenant or time.time()) - float(etat.get('verifie') or 0) < JOUR
    except (TypeError, ValueError):
        return False


def deja_pret(etat):
    """The update found and checked earlier (same day), still there and still the same bytes: (version, chemin, sha256)."""
    pret = etat.get('pret') if isinstance(etat.get('pret'), dict) else {}
    version, chemin, sha256 = pret.get('version'), pret.get('chemin'), pret.get('sha256')
    if not (isinstance(version, str) and isinstance(chemin, str) and isinstance(sha256, str) and plus_recente(version)):
        return None
    try:
        if not Path(chemin).is_file() or empreinte(chemin) != sha256:
            return None
        controler(chemin, version)
    except (OSError, ValueError):
        return None
    return version, chemin, sha256


def inscrire_version(version=VERSION):
    """Windows: the version shown in « Applications installées » (the line written by the installer)."""
    if os.name != 'nt':
        return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, UNINSTALL_KEY, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as key:
            if winreg.QueryValueEx(key, 'DisplayVersion')[0] == version:
                return False
            winreg.SetValueEx(key, 'DisplayVersion', 0, winreg.REG_SZ, version)
            return True
    except OSError:
        return False


def autre_fenetre():
    """Another Craft of this installation is open (the update could not replace its files)."""
    try:
        import doc_files
        from app_paths import running_directory
        return doc_files.other_craft(running_directory())
    except Exception:
        return False


# --------------------------------------------------------------------------------- in Craft
class MisesAJour:
    def __init__(self, app, conf, chercher=chercher):
        self.app = app
        self.conf = conf
        self.chercher = chercher
        self.file = queue.Queue()
        self.occupe = False
        self.manuel = False
        self.cadre = None
        self.pret = None

    def demarrer(self, manuel=False):
        """In the background: the published file (automatic: once a day; a ZIP already checked is offered again)."""
        if self.occupe:
            if manuel:
                self._statut('Recherche de mise à jour déjà en cours…')
            return False
        self.occupe, self.manuel = True, manuel
        etat = lire_etat()
        if manuel:
            self._statut('Recherche d’une mise à jour…')
        threading.Thread(target=self._travail, args=(manuel, etat), daemon=True).start()
        self._relever()
        return True

    def _travail(self, manuel, etat):
        try:
            if not manuel and recente(etat):
                trouve = deja_pret(etat)
                self.file.put(('pret_garde',) + trouve if trouve else ('rien',))
                return
            self.file.put(self.chercher(self.conf, informer=lambda texte: self.file.put(('info', texte))))
        except Refus as exc:
            self.file.put(('refus', str(exc)))
        except OSError as exc:
            self.file.put(('hors_ligne', str(exc)))
        except Exception as exc:
            self.file.put(('erreur', str(exc)))

    def _relever(self):
        import tkinter as tk
        while True:
            try:
                resultat = self.file.get_nowait()
            except queue.Empty:
                try:
                    self.app.after(250, self._relever)
                except tk.TclError:
                    pass
                return
            if resultat[0] == 'info':
                if self.manuel:
                    self._statut(resultat[1])
                continue
            break
        self.occupe = False
        genre = resultat[0]
        etat = lire_etat()
        if genre == 'a_jour':
            etat.update(verifie=time.time(), pret=None, erreur=None)
            ecrire_etat(etat)
            if self.manuel:
                self._statut('Craft est à jour (%s).' % VERSION)
        elif genre == 'pret':
            etat.update(verifie=time.time(), pret=dict(version=resultat[1], chemin=resultat[2], sha256=resultat[3]), erreur=None)
            ecrire_etat(etat)
            self.montrer(resultat[1], resultat[2])
        elif genre == 'pret_garde':   # offered again: the day's check is not renewed (a newer one would be missed)
            self.montrer(resultat[1], resultat[2])
        elif genre == 'hors_ligne':
            if self.manuel:
                self._statut('Pas de connexion à Internet : réessayez plus tard.')
        elif genre in ('refus', 'erreur'):
            etat.update(verifie=time.time(), erreur=dict(quand=time.strftime('%Y-%m-%d %H:%M'), texte=resultat[1]))
            ecrire_etat(etat)
            if self.manuel:
                from tkinter import messagebox
                messagebox.showerror('Mise à jour', resultat[1], parent=self.app)

    def _statut(self, texte):
        variable = self.app.__dict__.get('status')
        if variable is not None:
            try:
                variable.set(texte)
            except Exception:
                pass

    def montrer(self, version, chemin):
        """« Mise à jour disponible », as when a newer Craft is installed while it is open (update_notice)."""
        import tkinter as tk
        self.cacher()
        self.pret = (version, chemin)
        app = self.app
        p = app.p
        cadre = tk.Frame(app, bg=p['panel'], highlightthickness=1, highlightbackground=p['accent'], padx=12, pady=10)
        tk.Label(cadre, text='Mise à jour disponible', bg=p['panel'], fg=p['ui_ink'], font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        tk.Label(cadre, text='Craft %s est prête.\nRedémarrez Craft pour l’installer.' % version, justify='left',
                 bg=p['panel'], fg=p['ui_ink'], font=('Segoe UI', 9)).pack(anchor='w', pady=(3, 8))
        rangee = tk.Frame(cadre, bg=p['panel'])
        rangee.pack(anchor='e')
        app.button(rangee, 'Plus tard', self.cacher).pack(side='left', padx=(0, 6))
        app.button(rangee, 'Redémarrer', self.installer).pack(side='left')
        cadre.place(relx=1, rely=1, x=-18, y=-48, anchor='se')
        cadre.lift()
        self.cadre = cadre

    def cacher(self):
        if self.cadre is not None:
            try:
                self.cadre.destroy()
            except Exception:
                pass
        self.cadre = None

    def installer(self):
        """The normal close first (« Enregistrer ? » for each drawing), then the update and Craft again. Another
        Craft window open: said first (the update could not replace its files). Annuler: the notice stays."""
        if not self.pret:
            return False
        if autre_fenetre():
            from tkinter import messagebox
            messagebox.showinfo('Mise à jour', 'Une autre fenêtre Craft est ouverte : fermez-la d’abord, puis Redémarrer.',
                                parent=self.app)
            return False
        version, chemin = self.pret
        self.cacher()
        self.app.update_from_zip(file=chemin)
        try:
            ouvert = self.app.winfo_exists()
        except Exception:
            ouvert = False
        if ouvert:   # Annuler on « Enregistrer ? »: Craft stays, the update is offered again
            self.montrer(version, chemin)
        return True


def ajouter_menu(app):
    """Aide › Rechercher une mise à jour, after « Mettre à jour Craft depuis un ZIP… » (shared edition only)."""
    if configuration() is None:
        return False
    from licence_ui import _menu_aide
    menu = _menu_aide(app)
    if menu is None:
        return False
    fin = menu.index('end')
    fin = -1 if fin is None else fin
    position = fin + 1
    for i in range(fin + 1):
        if menu.type(i) == 'command':
            libelle = menu.entrycget(i, 'label')
            if libelle == LIBELLE_MENU:
                return True
            if libelle.startswith('Mettre à jour Craft'):
                position = i + 1
    menu.insert_command(position, label=LIBELLE_MENU, command=lambda: rechercher(app))
    return True


def rechercher(app):
    maj = app.__dict__.get('_mises_a_jour')
    if maj is not None:
        maj.demarrer(manuel=True)


def install(app):
    """Called once the window is built: the automatic check a few seconds later. None for his own Craft."""
    conf = configuration()
    if conf is None:
        return None
    maj = MisesAJour(app, conf)
    app._mises_a_jour = maj
    app.after(DELAI, maj.demarrer)
    threading.Thread(target=lambda: (nettoyer(), inscrire_version()), daemon=True).start()
    return maj
