"""Exact circular contour lengths and native ellipse geometry, in millimetres."""
import math,copy
from geometry import path
from cad import polygon,shape,project
from editing import inherit
TAU=2*math.pi
MICRO=1e-6   # mm: shorter sides are float noise, never geometry

def without_micro(s):
    """0.17.0: the same polyline without sides shorter than a millionth of a mm (left by
    older cuts at a corner); any other shape, or a clean polyline, is returned as is."""
    if s.get('kind')!='poly' or s.get('components') or s.get('spline') or s.get('ellipse') or len(s.get('points') or [])<2:return s
    V=[(s['x']+x,s['y']+y) for x,y in s['points']];n=len(V);closed=bool(s.get('closed'))
    B=(list(s.get('bulges') or [])+[0]*n)[:n];pts=[V[0]];bs=[]
    for i in range(1,n):
        if math.dist(V[i],pts[-1])<=MICRO:continue
        bs.append(B[i-1]);pts.append(V[i])
    closing=B[n-1] if closed else 0
    if closed and len(pts)>2 and math.dist(pts[-1],V[0])<=MICRO:pts.pop();closing=bs.pop()
    if len(pts)==n or len(pts)<2:return s
    q=polygon(pts,s['name'],closed)
    q.update({k:copy.deepcopy(v) for k,v in s.items() if k not in ('kind','x','y','w','h','r','points','closed','bulges','name')})
    q.pop('bulges',None)
    if any(bs+[closing]):q['bulges']=bs+[closing]
    return q

def ellipse(center,rx,ry,angle=0,start=0,sweep=TAU,name='Ovale'):
    if min(rx,ry)<1e-6:raise ValueError('Les deux axes doivent être positifs.')
    if ry>rx:rx,ry=ry,rx;angle+=math.pi/2;start-=math.pi/2
    s=polygon([(center[0]+rx,center[1]),(center[0],center[1]+ry)],name,abs(sweep-TAU)<1e-8)
    s.update(x=center[0],y=center[1],w=rx*2,h=ry*2,points=[[rx,0],[0,ry]],ellipse=dict(rx=rx,ry=ry,angle=angle,start=start,sweep=sweep))
    return s

def ellipse_point(s,t):
    e=s['ellipse'];a=e['angle'];x=e['rx']*math.cos(t);y=e['ry']*math.sin(t)
    return s['x']+x*math.cos(a)-y*math.sin(a),s['y']+x*math.sin(a)+y*math.cos(a)

def ellipse_path(s,tol=.003):
    e=s['ellipse'];n=min(15000,max(32,math.ceil(abs(e['sweep'])/max(.001 if tol>=.003 else .0001,2*math.acos(max(-1,1-min(tol/e['rx'],1)))))))
    closed=bool(s.get('closed'));pts=[ellipse_point(s,e['start']+e['sweep']*i/n) for i in range(n if closed else n+1)]
    return (list(reversed(pts)) if s.get('reversed') else pts),closed

def integral(f,a,b,tol=1e-8):
    def step(a,b,fa,fm,fb,whole,eps,depth):
        m=(a+b)/2;l=(a+m)/2;r=(m+b)/2;fl,fr=f(l),f(r)
        left=(m-a)*(fa+4*fl+fm)/6;right=(b-m)*(fm+4*fr+fb)/6;delta=left+right-whole
        if depth<=0 or abs(delta)<15*eps:return left+right+delta/15
        return step(a,m,fa,fl,fm,left,eps/2,depth-1)+step(m,b,fm,fr,fb,right,eps/2,depth-1)
    fa,fm,fb=f(a),f((a+b)/2),f(b)
    # Split quadrants to avoid symmetry hiding integration error.
    count=max(1,math.ceil(abs(b-a)/(math.pi/2)));result=0
    for i in range(count):
        A=a+(b-a)*i/count;B=a+(b-a)*(i+1)/count;M=(A+B)/2;F,G,H=f(A),f(M),f(B)
        result+=step(A,B,F,G,H,(B-A)*(F+4*G+H)/6,tol/count,18)
    return abs(result)

def ellipse_length(s,t=1):
    e=s['ellipse'];return integral(lambda x:math.hypot(e['rx']*math.sin(x),e['ry']*math.cos(x)),e['start'],e['start']+e['sweep']*t)

def canonical(s):
    if s['kind']=='circle':
        x,y,r=s['x'],s['y'],s['w']/2;c=(x+r,y+r);q=polygon([(c[0]+r,c[1]),(c[0],c[1]+r),(c[0]-r,c[1]),(c[0],c[1]-r)],s['name'],True);q['bulges']=[math.tan(math.pi/8)]*4;return q
    if s['kind']=='rect':
        x,y,w,h,r=[s[k] for k in ('x','y','w','h','r')]
        if not r:return polygon([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],s['name'],True)
        q=polygon([(x+r,y),(x+w-r,y),(x+w,y+r),(x+w,y+h-r),(x+w-r,y+h),(x+r,y+h),(x,y+h-r),(x,y+r)],s['name'],True)
        q['bulges']=[0,math.tan(math.pi/8)]*4;return q
    return s

def primitives(s):
    s=canonical(s);pts=[(s['x']+x,s['y']+y) for x,y in s['points']] if s['kind']=='poly' else path(s)[0]
    out=[];bs=s.get('bulges',[])
    for i,(a,b) in enumerate(zip(pts,pts[1:]+pts[:1] if s.get('closed') else pts[1:])):
        bulge=bs[i] if bs else 0;chord=math.dist(a,b)
        if chord<1e-10:continue
        if not bulge:out.append(dict(a=a,b=b,length=chord,sweep=0));continue
        c=((a[0]+b[0])/2-(b[1]-a[1])*(1-bulge*bulge)/(4*bulge),(a[1]+b[1])/2+(b[0]-a[0])*(1-bulge*bulge)/(4*bulge));r=math.dist(a,c);sweep=4*math.atan(bulge)
        out.append(dict(a=a,b=b,c=c,r=r,start=math.atan2(a[1]-c[1],a[0]-c[0]),sweep=sweep,length=abs(sweep)*r))
    return out

def at_primitive(q,t):
    if not q['sweep']:return q['a'][0]+(q['b'][0]-q['a'][0])*t,q['a'][1]+(q['b'][1]-q['a'][1])*t
    a=q['start']+q['sweep']*t;return q['c'][0]+q['r']*math.cos(a),q['c'][1]+q['r']*math.sin(a)

def same_piece(e,f):
    """0.18.5: two consecutive primitives (see primitives) drawn as ONE piece: the same straight line
    in the same direction, or the same circle (centre, radius and turn). Décomposer joins them;
    Couper and Rallonger never stop between them. None (an opaque spline or oval part) is a piece
    of its own."""
    if e is None or f is None or bool(e['sweep'])!=bool(f['sweep']):return False
    if e['sweep']:
        tol=1e-6*max(1.,e['r'],f['r'])
        return e['sweep']*f['sweep']>0 and math.dist(e['c'],f['c'])<=tol and abs(e['r']-f['r'])<=tol
    u=(e['b'][0]-e['a'][0],e['b'][1]-e['a'][1]);v=(f['b'][0]-f['a'][0],f['b'][1]-f['a'][1]);n=math.hypot(*u)*math.hypot(*v)
    return n>0 and abs(u[0]*v[1]-u[1]*v[0])<=1e-7*n and u[0]*v[0]+u[1]*v[1]>0

def piece_runs(es,closed=False):
    """0.18.5: indices of consecutive primitives grouped by piece (same_piece); on a closed contour
    the last run goes on into the first one (that run starts at its last part)."""
    runs=[]
    for k,e in enumerate(es):
        if runs and same_piece(es[runs[-1][-1]],e):runs[-1].append(k)
        else:runs.append([k])
    if closed and len(runs)>1 and same_piece(es[runs[-1][-1]],es[runs[0][0]]):runs[0]=runs.pop()+runs[0]
    return runs

def piece_edges(s):
    """0.18.5: (primitive, length) along a contour in its travel order; a spline, an oval or a
    nested compound is ONE opaque edge (primitive None)."""
    if s.get('components'):
        from curves import parts
        out=[]
        for q in parts(s):
            n=contour_length(q)
            if n<=MICRO:continue
            if q.get('spline') or q.get('ellipse') or q.get('components'):out.append((None,n))
            else:out+=[(e,e['length']) for e in primitives(without_micro(q))]
        return out
    if s.get('spline') or s.get('ellipse'):return [(None,contour_length(s))]
    return [(e,e['length']) for e in primitives(without_micro(s))]

def piece_stops(s):
    """0.18.5: distances along ``s`` where one piece of its drawing ends and a different one begins
    (line / arc, arcs of different circles, even when they meet tangentially); none between two
    parts of one line or one circle, none at the two ends of an open contour."""
    es=piece_edges(s);closed=bool(path(s)[1]);runs=piece_runs([e for e,_ in es],closed)
    if len(runs)<2:return []
    starts=[0.]
    for _,n in es:starts.append(starts[-1]+n)
    return sorted(starts[run[0]] for run in runs if closed or run[0])

def open_ends(s):
    """0.18.5: the two ends of an open contour (nothing for a closed one), cheaply."""
    if s.get('closed') or s['kind'] in ('rect','circle'):return []
    if s['kind']=='line':return [(s['x'],s['y']),(s['x']+s['w'],s['y']+s['h'])]
    if s['kind']=='poly' and s.get('points') and not (s.get('spline') or s.get('ellipse') or s.get('components')):
        a,b=s['points'][0],s['points'][-1];return [(s['x']+a[0],s['y']+a[1]),(s['x']+b[0],s['y']+b[1])]
    pts=path(s)[0];return [pts[0],pts[-1]] if pts else []

def contour_length(s):
    if s.get('components'):
        from curves import parts
        return sum(contour_length(q) for q in parts(s))
    if s.get('spline'):
        from curves import spline_length
        return spline_length(s)
    return ellipse_length(s) if s.get('ellipse') else sum(q['length'] for q in primitives(s))

def contour_location(s,p):
    if s.get('components'):
        from curves import parts
        options=[];travel=0
        for q in parts(s):
            d,pt=contour_location(q,p);options.append((math.dist(pt,p),travel+d,pt));travel+=contour_length(q)
        _,d,pt=min(options);return d,pt
    if s.get('spline'):
        from curves import spline_location
        return spline_location(s,p)
    if s.get('ellipse'):
        e=s['ellipse'];count=128;best=min(range(count+1),key=lambda i:math.dist(ellipse_point(s,e['start']+e['sweep']*i/count),p));lo=max(0,(best-1)/count);hi=min(1,(best+1)/count)
        # 0.19.9: a closed oval is searched across its start too (a point just before it was put at the start)
        ring=bool(s.get('closed'))
        if ring:lo,hi=(best-1)/count,(best+1)/count
        for _ in range(45):
            a=lo+(hi-lo)/3;b=hi-(hi-lo)/3
            if math.dist(ellipse_point(s,e['start']+e['sweep']*a),p)<math.dist(ellipse_point(s,e['start']+e['sweep']*b),p):hi=b
            else:lo=a
        t=((lo+hi)/2)%1 if ring else (lo+hi)/2;d=ellipse_length(s,t);return (ellipse_length(s)-d if s.get('reversed') else d),ellipse_point(s,e['start']+e['sweep']*t)
    travel=0;candidates=[]
    for q in primitives(s):
        if not q['sweep']:t=math.dist(q['a'],project(p,q['a'],q['b']))/q['length']
        else:
            angle=math.atan2(p[1]-q['c'][1],p[0]-q['c'][0]);ts=[max(0,min(1,(angle-q['start']+k*TAU)/q['sweep'])) for k in range(-2,3)];t=min(ts,key=lambda t:math.dist(at_primitive(q,t),p))
        pt=at_primitive(q,t);candidates.append((math.dist(pt,p),travel+t*q['length'],pt));travel+=q['length']
    if not candidates:raise ValueError('Contour vide.')
    _,d,pt=min(candidates);return d,pt

def ellipse_fraction(s,d):
    lo,hi=0.,1.
    for _ in range(42):
        mid=(lo+hi)/2
        if ellipse_length(s,mid)<d:lo=mid
        else:hi=mid
    return (lo+hi)/2

def _slice_geometry(s,start,end):
    total=contour_length(s)
    if end-start<1e-7:raise ValueError('Les deux points doivent être différents.')
    if s.get('reversed'):
        from curves import reverse
        original=copy.deepcopy(s);original.pop('reversed');begin=(total-end)%total
        return reverse(contour_slice(original,begin,begin+end-start))
    if s.get('spline'):
        from curves import spline_slice
        return spline_slice(s,start,end)
    if s.get('components'):
        from curves import parts,compound
        spans=[]
        for cycle in range(2 if end>total+1e-7 else 1):
            travel=cycle*total
            for q in parts(s):
                n=contour_length(q);lo=max(0,start-travel);hi=min(n,end-travel)
                if hi-lo>1e-7:spans.append((q,lo,hi))
                travel+=n
        spans=[v for v in spans if v[2]-v[1]>MICRO] or spans
        return inherit(compound([contour_slice(q,lo,hi) for q,lo,hi in spans],s['name'],False),s)
    if s.get('ellipse'):
        first=ellipse_fraction(s,start%total);remaining=end-start;e=s['ellipse'];begin=e['start']+e['sweep']*first
        tail=copy.deepcopy(s);tail['ellipse']['start']=begin;tail['ellipse']['sweep']=TAU
        stop=ellipse_fraction(tail,remaining);q=ellipse((s['x'],s['y']),e['rx'],e['ry'],e['angle'],begin,TAU*stop,s['name']);return inherit(q,s)
    pieces=[];parts=primitives(s)
    for cycle in range(2 if end>total+1e-7 else 1):
        travel=cycle*total
        for primitive in parts:
            n=primitive['length'];lo=max(0,(start-travel)/n);hi=min(1,(end-travel)/n)
            if hi>lo+1e-10:pieces.append((primitive,lo,hi))
            travel+=n
    # 0.17.0: a cut at a corner left a 4e-8 mm side that Décomposer, Raccord and Rallonger
    # tripped over; pieces shorter than a millionth of a mm are dropped.
    kept=[q for q in pieces if (q[2]-q[1])*q[0]['length']>MICRO] or pieces
    pts=[];bulges=[]
    for primitive,lo,hi in kept:
        a,b=at_primitive(primitive,lo),at_primitive(primitive,hi)
        if not pts:pts.append(a)
        pts.append(b);bulges.append(math.tan(primitive['sweep']*(hi-lo)/4))
    q=polygon(pts,s['name'],False);q['bulges']=bulges+[0];return inherit(q,s)

def contour_slice(s,start,end):
    q=_slice_geometry(s,start,end)
    if s.get('notches'):
        total=contour_length(s);closed=path(s)[1];marks=[]
        for mark in s['notches']:
            d=(mark['distance']-start)%total if closed else mark['distance']-start
            if -1e-7<=d<=end-start+1e-7:marks.append(dict(copy.deepcopy(mark),distance=max(0,d)))
        if marks:q['notches']=marks
    return q

def routes(s,a,b):
    da,A=contour_location(s,a);db,B=contour_location(s,b);total=contour_length(s)
    if math.dist(A,B)<1e-5:raise ValueError('Choisissez deux points différents.')
    if not path(s)[1]:return [(contour_slice(s,min(da,db),max(da,db)),abs(db-da))]
    d=(db-da)%total;return [(contour_slice(s,da,da+d),d),(contour_slice(s,db,db+total-d),total-d)]

def is_contour(s):return s['kind'] in ('poly','rect','circle') and __import__('entity_rules').geometry_entity(s)

def inside(s,p):
    pts,closed=path(s)
    if not closed:return False
    result=False;x,y=p
    for a,b in zip(pts,pts[1:]+pts[:1]):
        if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:result=not result
    return result

def _circle_meets(c,r,p,u):
    """Intersections of the circle (c,r) with the line through p, direction u (unit)."""
    fx,fy=p[0]-c[0],p[1]-c[1];b=fx*u[0]+fy*u[1];k=fx*fx+fy*fy-r*r;disc=b*b-k
    if disc<-1e-12:return []
    root=math.sqrt(max(0,disc));return [(p[0]+u[0]*t,p[1]+u[1]*t) for t in (-b-root,-b+root)]

def _circles_meet(c1,r1,c2,r2):
    dist=math.dist(c1,c2)
    if dist<1e-12 or dist>r1+r2+1e-9 or dist<abs(r1-r2)-1e-9:return []
    a=(r1*r1-r2*r2+dist*dist)/(2*dist);h=math.sqrt(max(0,r1*r1-a*a));ux,uy=(c2[0]-c1[0])/dist,(c2[1]-c1[1])/dist
    m=(c1[0]+ux*a,c1[1]+uy*a);return [(m[0]-uy*h,m[1]+ux*h),(m[0]+uy*h,m[1]-ux*h)]

def bulged_polyline(shapes,closed,name='',tolerance=.05):
    """0.16.28: lines and arc polylines joined end to end as ONE polyline with true arcs
    (bulges); None when a part is a spline/ellipse or the parts do not follow each other
    (0.19.8: ``tolerance``, the gaps Joindre closed)."""
    pts=[];bulges=[]
    for q in shapes:
        if q.get('spline') or q.get('ellipse') or q.get('components') or q.get('drill') or q.get('annotation'):return None
        for p in primitives(q):
            if pts and math.dist(pts[-1],p['a'])>tolerance:return None
            if not pts:pts.append(p['a'])
            pts.append(p['b']);bulges.append(math.tan(p['sweep']/4) if p['sweep'] else 0)
    if len(pts)<2:return None
    if closed:
        if math.dist(pts[-1],pts[0])>tolerance:return None
        pts.pop()
        if len(pts)<2:return None
    else:bulges.append(0)
    q=polygon(pts,name,closed);q['bulges']=bulges;return q

def offset_with_arcs(s,d):
    """Sharp corners where the offset sides can be extended to meet; if that gives a wrong
    shape around an arc, the corners next to arcs are rounded instead."""
    try:return _offset_with_arcs(s,d,False)
    except ValueError:return _offset_with_arcs(s,d,True)

def _offset_with_arcs(s,d,round_arcs):
    """0.16.27: offset of a polyline that contains arcs, keeping true arcs.
    Lines move along their left normal by d (craft_tools.offset convention); arcs keep
    their centre and change radius; corners meet at the curves' intersection, or a round
    join is added around the original corner. Before, every arc became ~160 tiny segments.
    0.16.28: an arc that becomes too small (corner rounding smaller than the offset) is
    removed and its neighbours meet in a corner; only a vanishing line is refused."""
    closed=bool(path(s)[1]);base=[]
    for q in primitives(s):
        if not q['sweep']:
            a,b=q['a'],q['b'];n=math.dist(a,b);u=(-(b[1]-a[1])/n,(b[0]-a[0])/n)
            t=((b[0]-a[0])/n,(b[1]-a[1])/n)
            base.append(dict(arc=False,a=(a[0]+u[0]*d,a[1]+u[1]*d),b=(b[0]+u[0]*d,b[1]+u[1]*d),dir=t,t0=t,t1=t,corner=b,start_corner=a,sweep=0))
        else:
            r=q['r']-d*(1 if q['sweep']>0 else -1);c=q['c']
            sign=1 if q['sweep']>0 else -1;tangent=lambda v,c=c,q=q,sign=sign:(-(v[1]-c[1])/q['r']*sign,(v[0]-c[0])/q['r']*sign)
            if r<=1e-6:continue          # the rounding disappears: neighbours meet in a corner
            k=r/q['r'];scale=lambda v,c=c,k=k:(c[0]+(v[0]-c[0])*k,c[1]+(v[1]-c[1])*k)
            base.append(dict(arc=True,a=scale(q['a']),b=scale(q['b']),c=c,r=r,sweep=q['sweep'],corner=q['b'],start_corner=q['a'],t0=tangent(q['a']),t1=tangent(q['b'])))
    if not base or not any(not seg['arc'] for seg in base) and not any(seg['arc'] for seg in base):raise ValueError('Contour non décalable.')
    reach=abs(d)*20+1
    def candidates(one,two):
        if not one['arc'] and not two['arc']:
            u,v=one['dir'],two['dir'];den=u[0]*v[1]-u[1]*v[0]
            if abs(den)<1e-12:return []
            t=((two['a'][0]-one['a'][0])*v[1]-(two['a'][1]-one['a'][1])*v[0])/den;return [(one['a'][0]+u[0]*t,one['a'][1]+u[1]*t)]
        if one['arc'] and two['arc']:return _circles_meet(one['c'],one['r'],two['c'],two['r'])
        line,circle=(two,one) if one['arc'] else (one,two);return _circle_meets(circle['c'],circle['r'],line['a'],line['dir'])
    def along(seg,x):
        """Position of x along the (extended) segment from its start, and the segment length."""
        if not seg['arc']:
            return (x[0]-seg['a'][0])*seg['dir'][0]+(x[1]-seg['a'][1])*seg['dir'][1],math.dist(seg['a'],seg['b'])
        c=seg['c'];sign=1 if seg['sweep']>0 else -1
        delta=sign*(math.atan2(x[1]-c[1],x[0]-c[0])-math.atan2(seg['a'][1]-c[1],seg['a'][0]-c[0]))
        delta=(delta+math.pi)%TAU-math.pi
        span=sign*(math.atan2(seg['b'][1]-c[1],seg['b'][0]-c[0])-math.atan2(seg['a'][1]-c[1],seg['a'][0]-c[0]));span%=TAU
        if span<1e-12:span=TAU
        if delta<-math.pi/2 and delta+TAU<=span+math.pi/2:delta+=TAU
        return delta*seg['r'],span*seg['r']
    eps=1e-7
    class Drop(Exception):
        def __init__(self,index):self.index=index
    def attempt(base):
        segs=[dict(seg) for seg in base]
        joints=range(len(segs)) if closed else range(len(segs)-1)
        joins={}
        for i in joints:
            j=(i+1)%len(segs);one,two=segs[i],segs[j];end,start=one['b'],two['a']
            if math.dist(end,start)<1e-7:point=((end[0]+start[0])/2,(end[1]+start[1])/2);one['b']=two['a']=point;continue
            t1,t2=one['t1'],two['t0'];turn=math.atan2(t1[0]*t2[1]-t1[1]*t2[0],t1[0]*t2[0]+t1[1]*t2[1])
            gap=abs(turn)>1e-9 and (turn>0)!=(d>0)
            valid=[]
            # Diverging corners are extended to a sharp point; with round_arcs, corners next to an
            # arc are rounded instead (an extended arc can swing back next to the original contour).
            for x in (candidates(one,two) if not (round_arcs and gap and (one['arc'] or two['arc'])) else []):
                if math.dist(x,one['corner'])>reach:continue
                p1,l1=along(one,x);p2,l2=along(two,x)
                if gap and p1>=l1-eps and p2<=eps:valid.append(x)          # both extended to meet
                if not gap and -eps<=p1<=l1+eps and -eps<=p2<=l2+eps:valid.append(x)   # both trimmed
            if valid:
                point=min(valid,key=lambda x:math.dist(x,one['corner']));one['b']=two['a']=point;continue
            if not gap:
                # Overlapping neighbours that do not meet: a too small arc between them goes.
                arcs=[k for k in (i,j) if segs[k]['arc']]
                if arcs:raise Drop(min(arcs,key=lambda k:abs(base[k]['sweep'])*base[k]['r']))
                raise ValueError('Ce décalage ferait disparaître une ligne ; réduisez la distance.')
            joins[i]=dict(arc=True,a=end,b=start,c=one['corner'],r=abs(d),sweep=turn,corner=start,join=True)
        ordered=[]
        for i,seg in enumerate(segs):
            seg['index']=i;ordered.append(seg)
            if i in joins:ordered.append(joins[i])
        for seg in ordered:
            if not seg['arc']:
                if (seg['b'][0]-seg['a'][0])*seg['dir'][0]+(seg['b'][1]-seg['a'][1])*seg['dir'][1]<=1e-9:
                    raise ValueError('Ce décalage ferait disparaître une ligne ; réduisez la distance.')
                continue
            c=seg['c'];alpha=math.atan2(seg['a'][1]-c[1],seg['a'][0]-c[0]);beta=math.atan2(seg['b'][1]-c[1],seg['b'][0]-c[0]);sweep=beta-alpha
            if seg['sweep']>0:
                while sweep<=1e-12:sweep+=TAU
            else:
                while sweep>=-1e-12:sweep-=TAU
            if abs(sweep)>abs(seg['sweep'])+math.pi/2 or abs(sweep)>=TAU-1e-9:
                if seg.get('join'):raise ValueError('Ce décalage se croise ; réduisez la distance.')
                raise Drop(seg['index'])                        # the arc was trimmed away: remove it
            seg['sweep']=sweep
        return ordered
    for _ in range(len(base)+1):
        if not base:raise ValueError('Contour non décalable.')
        try:ordered=attempt(base);break
        except Drop as drop:base=[seg for k,seg in enumerate(base) if k!=drop.index]
    else:raise ValueError('Ce décalage se croise ; réduisez la distance.')
    pts=[seg['a'] for seg in ordered] if closed else [ordered[0]['a']]+[seg['b'] for seg in ordered]
    bulges=[math.tan(seg['sweep']/4) if seg['arc'] else 0 for seg in ordered]+([] if closed else [0])
    q=polygon(pts,'Décalage',closed);q['bulges']=bulges
    tess,_=path(q);pairs=[(a,b) for a,b in zip(tess,tess[1:]+(tess[:1] if closed else [])) if math.dist(a,b)>1e-9]
    from cad import segment_intersection
    for i,(a,b) in enumerate(pairs):
        for j in range(i+2,len(pairs)):
            if closed and i==0 and j==len(pairs)-1:continue
            c,e=pairs[j]
            if min(math.dist(a,c),math.dist(a,e),math.dist(b,c),math.dist(b,e))<1e-7:continue
            if segment_intersection(a,b,c,e):raise ValueError('Ce décalage se croise ; réduisez la distance.')
    # A true offset stays at the distance from the whole original contour; a part that comes
    # closer (narrow place, opposite side) would be wrong geometry: refuse it.
    if any(math.dist(contour_location(s,p)[1],p)<abs(d)-1e-4 for p in tess):raise ValueError('Ce décalage se croise ; réduisez la distance.')
    return q

def shifted(s,d):
    """Positive distance is exterior on closed contours, left normal on open ones. 0.19.22: an offset is never itself
    a Piqûre, a zone or a précoupe (editing.inherit now keeps them through the other tools)."""
    q=_shifted(s,d)
    for key in ('stitch','preparation','surcoupe'):q.pop(key,None)
    return q

def _shifted(s,d):
    if not __import__('entity_rules').geometry_entity(s):raise ValueError('Sélectionner ligne/polyligne')
    from craft_tools import offset
    if s['kind']=='rect':
        x,y,w,h,r=[s[k] for k in ('x','y','w','h','r')]
        if min(w+2*d,h+2*d)<=1e-6:raise ValueError('Le décalage intérieur est trop grand.')
        return inherit(shape('rect','Décalage',x-d,y-d,w+2*d,h+2*d,max(0,r+d) if r else 0),s)
    if s.get('ellipse'):
        pts,closed=path(s);e=s['ellipse'];out=[];back=bool(s.get('reversed'))
        # 0.19.9: a reversed oval (Symétrie) is drawn backwards: each point gets its own angle. An open arc
        # follows the left normal like the other open contours (when it turns anticlockwise, that is inward).
        if not closed and (e['sweep']>0)!=back:d=-d
        for i,p in enumerate(pts):
            t=e['start']+e['sweep']*(len(pts)-1-i if back else i)/(len(pts) if closed else len(pts)-1);nx,ny=math.cos(t)/e['rx'],math.sin(t)/e['ry'];a=e['angle'];u,v=nx*math.cos(a)-ny*math.sin(a),nx*math.sin(a)+ny*math.cos(a);n=math.hypot(u,v);out.append((p[0]+d*u/n,p[1]+d*v/n))
        if d<0 and abs(d)>=e['ry']**2/e['rx']:raise ValueError('Le décalage dépasse le rayon de courbure minimal de cet ovale.')
        return inherit(polygon(out,'Décalage ovale',closed),s)
    pts,closed=path(s)
    if closed and s['kind']!='circle':
        area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1]));d*= -1 if area>0 else 1
    if s['kind']=='poly' and not s.get('spline') and not s.get('components') and any(abs(b)>1e-12 for b in s.get('bulges',[])):
        return inherit(offset_with_arcs(s,d),s)
    if s.get('components'):
        # 0.16.28: a shape made with « Joindre » (assembled parts) is offset with true arcs too.
        from curves import parts
        single=bulged_polyline(parts(s),closed,s.get('name',''))
        if single is not None:return inherit(offset_with_arcs(single,d),s)
    return inherit(offset(s,d),s)
