"""0.18.5 (n° 12): dashed lines of the plan drawn dash by dash.

Tk under Windows ignores the lengths of -dash (it draws its own fixed dots), so a piqûre looked dotted
while the view moved and dashed once smoothed. Every plan line whose dash is given in mm (its
« zoom:d= » tag, ui_widgets.zoom_tag) is now made of plain pieces, one per dash, with a continuous phase
along the line, as display_render.segments draws them: the same on every system, at every moment, and
the wheel zoom (canvas.scale) makes them grow with the drawing. A pattern shorter than 3 px on the screen
is drawn plain; only the dashes within the screen and a margin are made, their phase kept from the
line's start; beyond MAX_DASHES for a line, or BUDGET for a whole drawing, Tk's dash is kept."""
import math

MIN_PERIOD = 4      # a pattern shorter than this on the screen: drawn plain
MAX_DASHES = 4000
BUDGET = 6000       # dashes made by one full drawing (or one pointer move): a big drawing stays quick


def pattern(tags, scale):
    for tag in tags:
        if isinstance(tag, str) and tag.startswith('zoom:d='):
            try:
                mm = [float(v) for v in tag[7:].split(',') if v]
            except ValueError:
                return None
            return [v * scale for v in mm] if mm else None
    return None


def dash_runs(points, dash, offset=0.):
    """Continuous phase along the polyline: each dash as a list of points (it may turn a corner).
    ``offset``: the length of line before ``points[0]`` (a line cut at the screen keeps its dashes)."""
    pat = list(dash) * (2 if len(dash) % 2 else 1)
    phase, remaining, out, cur = 0, pat[0], [], None
    left = offset % sum(pat) if offset else 0.
    while left > 1e-9:
        step = min(remaining, left)
        remaining -= step
        left -= step
        if remaining < 1e-9:
            phase = (phase + 1) % len(pat)
            remaining = pat[phase]
    for a, b in zip(points, points[1:]):
        length = math.dist(a, b)
        if length < 1e-10:
            continue
        pos = 0.
        while pos < length - 1e-10:
            step = min(remaining, length - pos)
            if phase % 2 == 0:
                p = (a[0] + (b[0] - a[0]) * pos / length, a[1] + (b[1] - a[1]) * pos / length)
                q = (a[0] + (b[0] - a[0]) * (pos + step) / length, a[1] + (b[1] - a[1]) * (pos + step) / length)
                if cur is None:
                    cur = [p]
                cur.append(q)
            pos += step
            remaining -= step
            if remaining < 1e-9:
                if phase % 2 == 0 and cur is not None:
                    out.append(cur)
                    cur = None
                    if len(out) > MAX_DASHES:
                        return None
                phase = (phase + 1) % len(pat)
                remaining = pat[phase]
    if cur is not None and len(cur) >= 2:
        out.append(cur)
    return out


def clipped(points, box):
    """The parts of a polyline inside box, each with the length of line before it."""
    from deep_zoom import _segment
    out, cur, start, done = [], None, 0., 0.
    for a, b in zip(points, points[1:]):
        part = _segment(a, b, box)
        if part is None:
            if cur:
                out.append((cur, start))
            cur = None
        else:
            p, q = part
            if cur and math.dist(cur[-1], p) < 1e-6:
                cur.append(q)
            else:
                if cur:
                    out.append((cur, start))
                cur, start = [p, q], done + math.dist(a, p)
        done += math.dist(a, b)
    if cur:
        out.append((cur, start))
    return out


def reset(canvas):
    canvas._dash_used = 0


def _tags(kw):
    tags = (kw or {}).get('tags', ())
    return (tags,) if isinstance(tags, str) else tuple(tags or ())


def install(app):
    c = app.canvas
    if c.__dict__.get('_dash_lines'):
        return
    c._dash_lines = True
    original = c._create

    def create(kind, args, kw, original=original):
        if kind != 'line' or not kw or not kw.get('dash'):
            return original(kind, args, kw)
        tags = _tags(kw)
        pat = pattern(tags, getattr(app, 'scale', 1))
        if pat is None:
            return original(kind, args, kw)
        from deep_zoom import _numbers
        try:
            flat = _numbers(args)
        except (TypeError, ValueError):
            return original(kind, args, kw)
        plain = dict(kw)
        plain.pop('dash', None)
        plain.pop('dashoffset', None)
        if sum(pat) < MIN_PERIOD or min(pat) <= 0:
            return original(kind, tuple(flat), plain)
        pts = list(zip(flat[0::2], flat[1::2]))
        W, H = max(100, c.winfo_width()), max(100, c.winfo_height())
        m = max(W, H)
        box = (-m, -m, W + m, H + m)
        inside = all(box[0] <= x <= box[2] and box[1] <= y <= box[3] for x, y in pts)
        first = None
        for run, offset in ([(pts, 0.)] if inside else clipped(pts, box)):
            pieces = dash_runs(run, pat, offset) if c.__dict__.get('_dash_used', 0) < BUDGET else None
            if pieces is None:   # too many dashes: Tk's dash for this run
                c._dash_left = c.__dict__.get('_dash_left', 0) + 1   # 0.18.7: for draw_cache
                item = original(kind, tuple(v for p in run for v in p), kw)
                first = item if first is None else first
                continue
            c._dash_used = c.__dict__.get('_dash_used', 0) + len(pieces)
            for piece in pieces:
                item = original(kind, tuple(v for p in piece for v in p), plain)
                first = item if first is None else first
        if first is None:   # 0.18.7: tagged « offscreen »: never smoothed, so never shown again by show_raw
            first = original('line', (box[0], box[1], box[0], box[1]), dict(plain, state='hidden', tags=_tags(plain) + ('offscreen',)))
        return first
    c._create = create
