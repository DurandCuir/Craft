"""0.19.13 Bases libres (05/11: « laisser les gens gérer leurs colonnes », « la personne choisit ou non de mettre des
colonnes, des rangées… pour avoir ensuite une base comme elle le souhaite », « définir un premier profil et en ajouter
d'autres au fur et à mesure »): base profiles. A profile: its columns (name, width, what each holds: Cuir, Tissu…, for
the Matière window and Mozart's A- / F- / I-), its rows (name, height), the height of the base and of the titles.

The lycée's two bases are always there; one's own profiles live in the preferences (``base_profiles``), the one
« Nouveau » starts with in ``base_default``; each pattern keeps its own base (its .crft). Réglages › Base, the base
menu of the bottom bar and Nouveau ▸ open them."""
import copy

from cad import COLUMN_KINDS, column_kinds, column_labels, default_workspace, validate_workspace

LYCEE = ('Lycée · maro', 'Lycée · petite maro')
FREE = 'Libre'   # 0.19.14 (« mets juste libre »): no line at all until columns or rows are added
OLD_FREE = 'Libre · sans colonnes'
BUILTIN = LYCEE + (FREE,)
FREE_PROFILE = dict(labels=[''], widths=[3000.], types=[''], rows=[], height=2000., header=60.)   # one column without a name


def builtin(name):
    name = FREE if name == OLD_FREE else name
    if name == LYCEE[0]:
        return default_workspace('maro')
    if name == LYCEE[1]:
        return default_workspace('petite')
    if name == FREE:
        return workspace_of(FREE_PROFILE, FREE)
    return None


def profile_of(workspace):
    """What a profile keeps of a base."""
    w = workspace
    return dict(labels=column_labels(w), widths=[float(v) for v in w['widths']], types=column_kinds(w),
                rows=copy.deepcopy(w.get('rows') or []), height=float(w['height']), header=float(w['header']))


def workspace_of(profile, name=''):
    """The base of a profile, checked (ValueError with a French message)."""
    data = dict(kind='libre', visible=True, origin_x=0., **{k: copy.deepcopy(profile[k]) for k in ('labels', 'widths', 'types', 'rows', 'height', 'header') if k in profile})
    if name:
        data['profile'] = name
    return validate_workspace(data)


def clean(profiles):
    """The profiles of the preferences that make a base (the others left out)."""
    out = {}
    if not isinstance(profiles, dict):
        return out
    for name, profile in list(profiles.items())[:50]:
        if not isinstance(name, str) or not 0 < len(name.strip()) <= 40 or name in BUILTIN or not isinstance(profile, dict):
            continue
        try:
            out[name] = profile_of(workspace_of(profile))
        except (ValueError, TypeError, KeyError):
            continue
    return out


def names(prefs):
    return list(BUILTIN) + sorted(clean(prefs.get('base_profiles')), key=str.casefold)


def same_as_lycee(workspace):
    """The lycée's base (maro or petite maro) when ``workspace`` has exactly its columns and heights, else None: such a
    base keeps its kind (its title « BASES maro »)."""
    for name in LYCEE:
        base = builtin(name)
        if profile_of(base) == profile_of(workspace):
            out = dict(base, origin_x=workspace.get('origin_x', 0.), visible=workspace.get('visible', True))
            return out
    return None


def workspace_for(prefs, name):
    """The base of the profile ``name`` (the lycée's maro when it is not known)."""
    found = builtin(name)
    if found is not None:
        return found
    own = clean(prefs.get('base_profiles')).get(name)
    return workspace_of(own, name) if own else default_workspace('maro')


def default_name(prefs):
    name = prefs.get('base_default')
    name = FREE if name == OLD_FREE else name
    return name if name in names(prefs) else LYCEE[0]


def more_menu(app, parent, entries):
    """0.19.14 « … » beside a profile (« tu peux mettre … à côté et option renommer »): its menu of (label, command,
    enabled) — Enregistrer sous…, Renommer…, Supprimer… — so the window keeps a single small button."""
    def show():
        m = app.menu(parent)
        for label, command, enabled in entries():
            if label is None:
                m.add_separator()
            else:
                m.add_command(label=label, command=command, state='normal' if enabled else 'disabled')
        x, y = button.winfo_rootx(), button.winfo_rooty() + button.winfo_height()
        try:
            m.tk_popup(x, y)
        finally:
            m.grab_release()
        return m
    button = app.button(parent, '…', show, padx=10)
    button._entries = entries
    return button


def renamed(app, parent, title, old, taken):
    """The new name of a profile (None: unchanged or refused, said in a message)."""
    from tkinter import simpledialog, messagebox
    name = simpledialog.askstring(title, 'Nouveau nom :', initialvalue=old, parent=parent)
    name = (name or '').strip()[:40]
    if not name or name == old:
        return None
    if name in taken:
        messagebox.showerror(title, f'Le nom « {name} » est déjà pris : en choisir un autre.', parent=parent)
        return None
    return name


def dialog(app):
    """Réglages › Base: the base of the drawing, column by column and row by row, from a profile or saved as one."""
    import tkinter as tk
    from tkinter import ttk, messagebox, simpledialog
    panel = app.p['panel']
    win = app.dialog('Base : colonnes et rangées')
    state = dict(columns=[], rows=[])
    start = app.workspace or default_workspace('maro')

    def load(workspace):
        state['columns'] = [dict(name=n, width=float(w), kind=k) for n, w, k in zip(column_labels(workspace), workspace['widths'], column_kinds(workspace))]
        state['rows'] = [dict(name=r['name'], height=float(r['height'])) for r in workspace.get('rows') or []]
        height.set(app.format_length(workspace['height']))
        header.set(app.format_length(workspace['header']))
        show()
    top = tk.Frame(win, bg=panel)
    top.pack(fill='x', padx=16, pady=(14, 4))
    app.label(top, 'Profil').pack(side='left')
    choice = tk.StringVar(value=start.get('profile') or (LYCEE[1] if start.get('kind') == 'petite' and 'labels' not in start else LYCEE[0] if 'labels' not in start else ''))
    if choice.get() not in names(app.prefs):
        choice.set('')
    chooser = ttk.Combobox(top, textvariable=choice, values=names(app.prefs), state='readonly', width=28)
    chooser.pack(side='left', padx=8)

    def picked(e=None):
        load(workspace_for(app.prefs, choice.get()))
    chooser.bind('<<ComboboxSelected>>', picked)
    app.label(win, f"Dimensions en {app.units.get()} · une colonne sans nom n'a pas de titre · ce qu'elle contient coche ses matières").pack(anchor='w', padx=16)

    def table(title, columns, widths, row):
        frame = tk.Frame(win, bg=panel)
        frame.pack(fill='both', expand=True, padx=16, pady=(8, 2))
        app.label(frame, title, font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        area = tk.Frame(frame, bg=panel)
        area.pack(fill='both', expand=True)
        tree = ttk.Treeview(area, columns=columns, show='headings', height=row, selectmode='browse')
        for key, width in zip(columns, widths):
            tree.heading(key, text=key)
            tree.column(key, width=width, anchor='w', stretch=key == columns[0])
        tree.pack(side='left', fill='both', expand=True)
        bar = ttk.Scrollbar(area, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=bar.set)
        bar.pack(side='right', fill='y')
        return frame, tree
    cframe, ctree = table('Colonnes (de gauche à droite)', ('Nom', 'Largeur', 'Contient'), (180, 90, 120), 6)
    cedit = tk.Frame(cframe, bg=panel)
    cedit.pack(fill='x', pady=(4, 0))
    cname, cwidth, ckind = tk.StringVar(), tk.StringVar(), tk.StringVar(value='')
    app.label(cedit, 'Nom').grid(row=0, column=0, sticky='w')
    app.entry(cedit, cname, 18).grid(row=1, column=0, sticky='w', padx=(0, 6))
    app.label(cedit, 'Largeur').grid(row=0, column=1, sticky='w')
    app.entry(cedit, cwidth, 8).grid(row=1, column=1, sticky='w', padx=(0, 6))
    app.label(cedit, 'Contient').grid(row=0, column=2, sticky='w')
    ttk.Combobox(cedit, textvariable=ckind, values=[k or '—' for k in COLUMN_KINDS], state='readonly', width=13).grid(row=1, column=2, sticky='w')
    rframe, rtree = table('Rangées (de haut en bas ; aucune : une seule hauteur)', ('Nom', 'Hauteur'), (180, 90), 4)
    redit = tk.Frame(rframe, bg=panel)
    redit.pack(fill='x', pady=(4, 0))
    rname, rheight = tk.StringVar(), tk.StringVar()
    app.label(redit, 'Nom').grid(row=0, column=0, sticky='w')
    app.entry(redit, rname, 18).grid(row=1, column=0, sticky='w', padx=(0, 6))
    app.label(redit, 'Hauteur').grid(row=0, column=1, sticky='w')
    app.entry(redit, rheight, 8).grid(row=1, column=1, sticky='w', padx=(0, 6))
    sizes = tk.Frame(win, bg=panel)
    sizes.pack(fill='x', padx=16, pady=(8, 2))
    height, header = tk.StringVar(), tk.StringVar()
    app.label(sizes, 'Hauteur de la base (sans rangées)').grid(row=0, column=0, sticky='w')
    app.entry(sizes, height, 10).grid(row=0, column=1, sticky='w', padx=8)
    app.label(sizes, 'Hauteur des titres').grid(row=0, column=2, sticky='w', padx=(14, 0))
    app.entry(sizes, header, 10).grid(row=0, column=3, sticky='w', padx=8)

    def show():
        for tree, rows, cells in ((ctree, state['columns'], lambda c: (c['name'] or '—', app.format_length(c['width']), c['kind'] or '—')),
                                  (rtree, state['rows'], lambda r: (r['name'] or '—', app.format_length(r['height'])))):
            tree.delete(*(tree.get_children() or ()))
            for k, r in enumerate(rows):
                tree.insert('', 'end', iid=str(k), values=cells(r))

    def chosen(tree):
        picked = tree.selection()
        return int(picked[0]) if picked else None

    def column_picked(e=None):
        k = chosen(ctree)
        if k is not None:
            c = state['columns'][k]
            cname.set(c['name'])
            cwidth.set(app.format_length(c['width']))
            ckind.set(c['kind'] or '—')

    def row_picked(e=None):
        k = chosen(rtree)
        if k is not None:
            rname.set(state['rows'][k]['name'])
            rheight.set(app.format_length(state['rows'][k]['height']))
    ctree.bind('<<TreeviewSelect>>', column_picked)
    rtree.bind('<<TreeviewSelect>>', row_picked)

    def length(text, label):
        try:
            value = app.to_mm(text)
        except (ValueError, TypeError):
            raise ValueError(f'{label} : nombre attendu.') from None
        if not 10 <= value <= 20000:
            raise ValueError(f'{label} : 10 à 20 000 mm.')
        return value

    def typed_column():
        kind = ckind.get().replace('—', '')
        return dict(name=cname.get().strip().upper()[:40], width=length(cwidth.get(), 'Largeur'), kind=kind if kind in COLUMN_KINDS else '')

    def typed_row():
        return dict(name=rname.get().strip().upper()[:40], height=length(rheight.get(), 'Hauteur'))

    def edit(kind, how):
        tree, rows, read = (ctree, state['columns'], typed_column) if kind == 'column' else (rtree, state['rows'], typed_row)
        k = chosen(tree)
        try:
            if how == 'add':
                if len(rows) >= 30:
                    raise ValueError('30 au plus.')
                rows.insert(k + 1 if k is not None else len(rows), read())
                k = k + 1 if k is not None else len(rows) - 1
            elif k is None:
                return
            elif how == 'change':
                rows[k] = read()
            elif how == 'remove':
                if kind == 'column' and len(rows) == 1:
                    raise ValueError('Une base a au moins une colonne (sans nom : pas de titre).')
                del rows[k]
                k = min(k, len(rows) - 1) if rows else None
            elif how in ('up', 'down'):
                j = k - 1 if how == 'up' else k + 1
                if not 0 <= j < len(rows):
                    return
                rows[k], rows[j] = rows[j], rows[k]
                k = j
        except ValueError as exc:
            messagebox.showerror('Base', str(exc), parent=win)
            return
        show()
        if k is not None and rows:
            tree.selection_set(str(k))
    for frame, kind in ((cedit, 'column'), (redit, 'row')):
        buttons = tk.Frame(frame, bg=panel)
        buttons.grid(row=1, column=3, sticky='w', padx=(10, 0))
        for text, how in (('Ajouter', 'add'), ('Modifier', 'change'), ('Supprimer', 'remove'), ('↑', 'up'), ('↓', 'down')):
            app.button(buttons, text, lambda k=kind, h=how: edit(k, h)).pack(side='left', padx=1)

    def built(name=''):
        """The base as set in the window (its drawing stays where it is: the base keeps its left edge)."""
        profile = dict(labels=[c['name'] for c in state['columns']], widths=[c['width'] for c in state['columns']], types=[c['kind'] for c in state['columns']],
                       rows=[dict(r) for r in state['rows']], header=app.to_mm(header.get()) if header.get().strip() else 0.)
        if not state['rows']:
            profile['height'] = app.to_mm(height.get())
        out = workspace_of(profile, name)
        if app.workspace:
            out['origin_x'] = app.workspace.get('origin_x', 0.)
            out['visible'] = app.workspace.get('visible', True)
        return out

    def apply():
        try:
            data = built(choice.get() if choice.get() not in BUILTIN else '')
        except (ValueError, TypeError) as exc:
            messagebox.showerror('Base', str(exc), parent=win)
            return
        data = same_as_lycee(data) or data
        app.snapshot()
        app.workspace = data
        win.destroy()
        app.cancel()
        app.refresh()
        app.fit_workspace()
        app.status.set('Base du patron changée.')

    def save_as():
        name = simpledialog.askstring('Profil de base', 'Nom du profil :', initialvalue=choice.get() if choice.get() not in BUILTIN else '', parent=win)
        if not name or not name.strip():
            return
        name = name.strip()[:40]
        if name in BUILTIN:
            messagebox.showerror('Profil de base', 'Ce nom est celui d’une base de Craft : choisir un autre nom.', parent=win)
            return
        try:
            profile = profile_of(built(name))
        except (ValueError, TypeError) as exc:
            messagebox.showerror('Base', str(exc), parent=win)
            return
        own = clean(app.prefs.get('base_profiles'))
        own[name] = profile
        app.prefs['base_profiles'] = own
        app.persist_preferences()
        chooser.configure(values=names(app.prefs))
        choice.set(name)
        app.status.set(f'Profil de base « {name} » enregistré.')

    def remove():
        name = choice.get()
        if name in BUILTIN or name not in clean(app.prefs.get('base_profiles')):
            return
        if not messagebox.askokcancel('Profil de base', f'Supprimer le profil « {name} » ? (les patrons faits avec gardent leur base)', parent=win):
            return
        own = clean(app.prefs.get('base_profiles'))
        own.pop(name, None)
        app.prefs['base_profiles'] = own
        if app.prefs.get('base_default') == name:
            app.prefs.pop('base_default', None)
        app.persist_preferences()
        chooser.configure(values=names(app.prefs))
        choice.set(LYCEE[0])
        picked()

    def make_default():
        name = choice.get()
        if name not in names(app.prefs):
            return
        app.prefs['base_default'] = name
        app.persist_preferences()
        app.status.set(f'Nouveau commence par la base « {name} ».')
        if hasattr(app, 'rebuild_new_menu'):
            app.rebuild_new_menu()

    def rename():
        old = choice.get()
        own = clean(app.prefs.get('base_profiles'))
        if old not in own:
            return
        name = renamed(app, win, 'Profil de base', old, set(names(app.prefs)) | {OLD_FREE})
        if not name:
            return
        app.prefs['base_profiles'] = {(name if k == old else k): v for k, v in own.items()}
        if app.prefs.get('base_default') == old:
            app.prefs['base_default'] = name
        if app.workspace and app.workspace.get('profile') == old:
            app.workspace['profile'] = name
        app.persist_preferences()
        chooser.configure(values=names(app.prefs))
        choice.set(name)
        if hasattr(app, 'rebuild_new_menu'):
            app.rebuild_new_menu()
        app.status.set(f'Profil de base renommé « {name} ».')

    def entries():
        own = choice.get() in clean(app.prefs.get('base_profiles'))
        return [('Enregistrer le profil sous…', save_as, True), ('Renommer…', rename, own), ('Supprimer…', remove, own), (None, None, None),
                ('Profil de Nouveau (Ctrl+N)', make_default, choice.get() in names(app.prefs))]
    more_menu(app, top, entries).pack(side='left')
    end = tk.Frame(win, bg=panel)
    end.pack(fill='x', padx=16, pady=(10, 14))
    app.button(end, 'Annuler', win.destroy).pack(side='right')
    app.button(end, 'Appliquer au patron', apply).pack(side='right', padx=6)
    win.bind('<Escape>', lambda e: win.destroy())
    load(start)
    win._base = dict(state=state, choice=choice, chooser=chooser, picked=picked, edit=edit, apply=apply, save_as=save_as, remove=remove,
                     make_default=make_default, rename=rename, entries=entries, fields=dict(cname=cname, cwidth=cwidth, ckind=ckind, rname=rname, rheight=rheight, height=height, header=header),
                     columns=ctree, rows=rtree)
    return win
