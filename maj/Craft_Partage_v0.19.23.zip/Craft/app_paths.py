"""Paths shared by source and frozen distributions; never change the working directory."""
import os
import sys
from pathlib import Path


def is_frozen():
    return bool(getattr(sys, 'frozen', False))


def resource_directory():
    return Path(__file__).resolve().parent


def application_directory():
    return Path(sys.executable).resolve().parent if is_frozen() else resource_directory()


def user_data_directory():
    # Same location as 0.12.1: preferences and archives do not need migration.
    return Path(os.environ.get('LOCALAPPDATA', str(Path.home() / '.config'))) / 'Craft'


def settings_path():
    return user_data_directory() / 'preferences.json'


def icon_directory():
    return user_data_directory() / 'cache' if is_frozen() else application_directory()


def running_directory():
    return (user_data_directory() if is_frozen() else application_directory()) / 'running'
