"""Entity roles and explicit piece/identification ownership. Standard library only."""
import math,uuid
from geometry import path,bounds

def geometry_entity(s):
    # 0.17.0: a preparation zone is not geometry either: never cut, offset or used as a contour.
    return not(s.get('is_notch') or s.get('annotation') or s.get('drill') or s.get('dimension_group') or s.get('filled') or s.get('preparation'))

def closed_piece(s):
    # 0.16.20: rectangles, circles and ovals are closed pieces too, not only closed polylines.
    # 0.18.0: a closed stitch (Piqûre) is a line of its piece, never a piece.
    if not geometry_entity(s) or s.get('kind')=='line' or s.get('stitch'):return False
    if s.get('kind')=='poly':return bool(s.get('closed'))
    try:return bool(path(s)[1])
    except (ValueError,KeyError,TypeError):return False

def ensure_piece_id(s):
    if not s.get('piece_id'):s['piece_id']=uuid.uuid4().hex
    return s['piece_id']

def text_inside(piece,label):
    from precision_geometry import inside,contour_location
    from cad import intersections,project
    pts,_=path(label)
    if not pts:return False
    contained=lambda p:inside(piece,p) or math.dist(contour_location(piece,p)[1],p)<.01
    if not all(contained(p) for p in pts):return False
    # Split every label edge at boundary crossings, including narrow concavities.
    hits=intersections(label,piece)
    for a,b in zip(pts,pts[1:]+pts[:1]):
        length=math.dist(a,b)
        if length<1e-8:continue
        cuts=[0.,1.]
        for p in hits:
            if math.dist(project(p,a,b),p)<.01:cuts.append(max(0,min(1,((p[0]-a[0])*(b[0]-a[0])+(p[1]-a[1])*(b[1]-a[1]))/length**2)))
        cuts=sorted(set(cuts))
        for lo,hi in zip(cuts,cuts[1:]):
            t=(lo+hi)/2
            if not contained((a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]))):return False
    return True

def identification_kind(s):
    data=s.get('identification',{})
    if not s.get('annotation') or not any(str(v).strip() for v in data.get('values',[])):return None
    return data.get('kind') if data.get('kind') in ('part_name','material') else None

def piece_labels(items,index):
    piece=items[index];owner=piece.get('piece_id');found={}
    for i,label in enumerate(items):
        kind=identification_kind(label)
        if not kind:continue
        if label.get('owner_id'):
            # 0.16.28: an attached label belongs to its piece even if it goes a little outside.
            if not owner or label['owner_id']!=owner:continue
        else:
            if not text_inside(piece,label):continue
            # Existing documents have no links. Accept only unambiguous containment.
            possible=[j for j,s in enumerate(items) if closed_piece(s) and text_inside(s,label)]
            if possible!=[index]:continue
        found.setdefault(kind,[]).append(i)
    return found

def piece_count(items):
    """0.18.1: finished pieces among the items of an export (closed, Coupe externe): the export
    windows count pieces, not objects (the items already carry a name and a material)."""
    from craft_tools import style
    return sum(1 for s in items if closed_piece(s) and style(s)['role']=='external')

def fabrication_ids(items,selected=None,points=False):
    """Valid pieces with what goes with them; ``points``: pointés too (PDF, 0.17.0)."""
    from craft_tools import style
    from precision_geometry import inside,contour_location
    from geometry import bounds
    from curves import parts_view
    roots=[];labels={}
    for i,s in enumerate(items):
        if not closed_piece(s) or style(s)['role']!='external':continue
        if selected is not None and i not in selected:continue
        owned=piece_labels(items,i)
        if not all(owned.get(k) for k in ('part_name','material')):continue
        roots.append(i);labels[i]=owned
    keep=set(roots)
    # 0.17.0: crans and inner cuts sorted once (80 pieces: 3 s → a few tenths), a cran is only
    # read for its own piece, and the piece's box is checked before measuring.
    crans=[];inner=[]
    for i,s in enumerate(items):
        if s.get('dimension_group') or s.get('annotation'):continue
        if s.get('is_notch'):crans.append(i)
        elif style(s)['role']=='internal' or s.get('drill') and (points or not s.get('drill_point')) or s.get('stitch'):inner.append(i)   # 0.18.0: stitches too
    origins={};points={}
    for j in roots:
        piece=items[j];owner=piece.get('piece_id');x,y,X,Y=bounds([piece])
        keep.update(i for indices in labels[j].values() for i in indices)
        for i in crans:
            s=items[i]
            if s.get('owner_id') and s['owner_id']!=owner:continue
            if i not in origins:origins[i]=path(parts_view(s)[0])[0][0] if s.get('components') else path(s)[0][0]
            origin=origins[i]
            if not(x-.03<=origin[0]<=X+.03 and y-.03<=origin[1]<=Y+.03):continue
            if math.dist(contour_location(piece,origin)[1],origin)<.03:keep.add(i)
        # 0.18.1: a précoupe is cut on its contour only; what is inside goes with the pieces
        # recut at the 2nd step (surcoupe.second_step).
        if piece.get('surcoupe'):continue
        for i in inner:
            if owner and items[i].get('stitch') and items[i].get('owner_id')==owner:keep.add(i);continue
            if i not in points:points[i]=path(items[i])[0]
            pts=points[i]
            if not pts or not all(x-.01<=p[0]<=X+.01 and y-.01<=p[1]<=Y+.01 for p in pts):continue
            if all(inside(piece,p) or math.dist(contour_location(piece,p)[1],p)<.01 for p in pts):keep.add(i)
    return sorted(keep)

def linked_selection(items,ids):
    ids={i for i in ids if 0<=i<len(items)};owners={items[i].get('piece_id') for i in ids if closed_piece(items[i])};owners.discard(None)
    # 0.16.26: a dimension (cote) is one object: its lines, arrows and text go together.
    groups={items[i].get('dimension_group') for i in ids};groups.discard(None)
    return sorted(ids|{i for i,s in enumerate(items) if s.get('owner_id') in owners or (groups and s.get('dimension_group') in groups)})

def dimension_members(items,ids):
    """Selected ids completed with every part of the selected dimensions."""
    ids={i for i in ids if 0<=i<len(items)};groups={items[i].get('dimension_group') for i in ids};groups.discard(None)
    if not groups:return ids
    return ids|{i for i,s in enumerate(items) if s.get('dimension_group') in groups}

def fresh_copy_ids(items):
    """A copied piece owns its copied labels, never the original piece's labels."""
    mapping={s['piece_id']:uuid.uuid4().hex for s in items if s.get('piece_id')}
    for s in items:
        if s.get('piece_id') in mapping:s['piece_id']=mapping[s['piece_id']]
        if s.get('owner_id') in mapping:s['owner_id']=mapping[s['owner_id']]
    return items

def tool_accepts(tool,s):
    if tool in ('move_anchor','mirror','copy','select','delete','rotate','scale','array'):return True   # 0.19.13 Réseau: what is selected
    if tool=='copy_notch':return bool(s.get('is_notch'))
    if tool=='notch':return geometry_entity(s)
    if tool in ('part_name','material','surcoupe','surcoupe_simple'):return closed_piece(s)   # 0.18.1: the piece chosen before « Précoupe »
    if tool.startswith('paint_'):return geometry_entity(s)
    if tool in ('join','explode','trim','extend','fillet','chamfer','corner','strap_round','strap_point','strap_belt','offset_all','offset_part','offset_vertex'):return geometry_entity(s)
    return False


def update_style(s,**changes):
    """Apply a line style through nested geometry without changing crans."""
    if s.get('is_notch'):return
    from craft_tools import style
    s['style']=dict(style(s),**changes)
    for child in s.get('components',[]):update_style(child,**changes)
