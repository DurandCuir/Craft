"""Construction, object snapping, and reusable workspaces (all dimensions in mm)."""
import math
import json
import copy
from pathlib import Path
from geometry import number, path, bounds, distance, validate, boxes_apart, segments_near, frame_cache, geometry_key

EPS = 1e-8
LABELS = ['BROUILLON', 'BASES', 'DESSUS', 'DOUBLURES', 'RENFORTS', 'AIDES']
# 0.19.13 bases libres: what a column holds (the Matière window ticks those types; Mozart's prefix A-, F-, I-)
COLUMN_KINDS = ('', 'Cuir', 'Tissu', 'Tissu et cuir', 'Renfort', 'Gabarit')
KIND_TYPES = {'Cuir': ('Cuir',), 'Tissu': ('Tissu',), 'Tissu et cuir': ('Tissu', 'Cuir'), 'Renfort': ('Renfort',), 'Gabarit': ('Gabarit',)}
DEFAULT_KINDS = ['', '', 'Cuir', 'Tissu et cuir', 'Renfort', 'Gabarit']   # the lycée's six columns
SNAPS = ('endpoint','midpoint','quarter','center','intersection','quadrant','nearest','guides')   # 0.18.1: quarter = 1/4 and 3/4 of a straight line
# 0.19.13 the accroches of his AutoCAD that Craft lacked (snap_point: construction_snaps)
SNAPS += ('extension','perpendicular','tangent','parallel','centroid','node')


def default_workspace(kind='maro'):
    small=kind=='petite'
    # 0.18.1: the maro base has Mozart's columns (DIFORME): Brouillon 1000, Bases 800, Dessus
    # 1200, Doublures, Renforts and Aides 1000 mm, 2450 mm high, titles 170 mm.
    return dict(kind='petite' if small else 'maro',visible=True,
                widths=[450.,500.,650.,650.,650.,600.] if small else [1000.,800.,1200.,1000.,1000.,1000.],
                height=1500. if small else 2450.,header=130. if small else 170.,origin_x=0.)


def former_workspace(kind='maro'):
    """The base as it was before 0.18.1: what a saved file without these values had."""
    out=default_workspace(kind)
    if out['kind']=='maro':out.update(widths=[600.,700.,900.,900.,900.,600.],height=1500.,header=130.)
    return out


def column_labels(w):
    """0.19.13: the names of the base's columns (the lycée's six when the base has none of its own)."""
    n=len((w or {}).get('widths') or [])
    labels=(w or {}).get('labels')
    if isinstance(labels,list) and len(labels)==n:return [str(v) for v in labels]
    return [LABELS[i] if i<len(LABELS) else f'COLONNE {i+1}' for i in range(n)]


def column_kinds(w):
    """What each column holds ('' : anything); the lycée's base: Dessus cuir, Doublures tissu et cuir, Renforts, Aides."""
    n=len((w or {}).get('widths') or [])
    kinds=(w or {}).get('types')
    if isinstance(kinds,list) and len(kinds)==n:return [k if k in COLUMN_KINDS else '' for k in kinds]
    return list(DEFAULT_KINDS) if n==6 else ['']*n


def column_types(w,i):
    """The material types of column ``i`` (() for anything or outside the base)."""
    kinds=column_kinds(w)
    return KIND_TYPES.get(kinds[i],()) if i is not None and 0<=i<len(kinds) else ()


def title_suffix(w):
    """« maro » / « petite maro » after the 2nd title of the lycée's bases (not for a base of one's own)."""
    if not w or 'labels' in w or w.get('kind') not in ('maro','petite'):return ''
    return 'petite maro' if w['kind']=='petite' else 'maro'


def rows_of(w):
    """[(name, top, bottom)] of the base's rows (rangées), from under the titles."""
    out=[];y=(w or {}).get('header',0.)
    for r in (w or {}).get('rows') or []:
        out.append((r['name'],y,y+r['height']));y+=r['height']
    return out


def free_workspace(w):
    """0.19.13 base libre: columns (name, width, what they hold) and rows (name, height); a single column without a
    name for a base without columns."""
    widths=w.get('widths')
    if not isinstance(widths,list) or not 1<=len(widths)<=30:raise ValueError('Base : 1 à 30 colonnes.')
    widths=[number(v) for v in widths]
    if any(not 10<=v<=20000 for v in widths):raise ValueError('Largeur de colonne : 10 à 20 000 mm.')
    labels=w.get('labels',column_labels(dict(widths=widths)))
    if not isinstance(labels,list) or len(labels)!=len(widths):raise ValueError('Un nom par colonne.')
    kinds=w.get('types',['']*len(widths))
    if not isinstance(kinds,list) or len(kinds)!=len(widths) or any(k not in COLUMN_KINDS for k in kinds):raise ValueError('Contenu de colonne inconnu.')
    rows=w.get('rows') or []
    if not isinstance(rows,list) or len(rows)>30:raise ValueError('Base : 30 rangées au plus.')
    clean=[]
    for r in rows:
        if not isinstance(r,dict):raise ValueError('Rangée invalide.')
        h=number(r.get('height'))
        if not 10<=h<=20000:raise ValueError('Hauteur de rangée : 10 à 20 000 mm.')
        clean.append(dict(name=str(r.get('name','')).strip()[:40],height=h))
    header=number(w.get('header',170.))
    height=sum(r['height'] for r in clean) if clean else number(w.get('height',2450.))
    if not 20<=height<=50000 or not 0<=header<=5000:raise ValueError('Hauteur de base ou des titres hors limites.')
    out=dict(kind=w['kind'],visible=bool(w.get('visible',True)),widths=widths,labels=[str(v).strip()[:40] for v in labels],types=list(kinds),
             rows=clean,height=height,header=header,origin_x=number(w.get('origin_x',0.)))
    if isinstance(w.get('profile'),str) and w['profile'].strip():out['profile']=w['profile'].strip()[:60]
    # 0.19.14: « Libre » is Craft's base without columns; a base of one's own profile of that name (0.19.13) keeps its
    # name as the preferences now call it
    if out.get('profile')=='Libre' and not (len(out['widths'])==1 and not any(out['labels']) and not out['rows']):out['profile']='Libre (mon profil)'
    return out


def validate_workspace(w):
    if w is None:return None
    if not isinstance(w,dict) or w.get('kind') not in ('maro','petite','libre'):raise ValueError('Base inconnue.')
    if w['kind']=='libre' or 'labels' in w or 'types' in w or isinstance(w.get('rows'),list):return free_workspace(w)   # 0.19.13 (an old base has rows=3)
    # 0.18.1: a saved base keeps its own columns (missing values: the base of before).
    out=former_workspace(w['kind']);widths=w.get('widths',out['widths'])
    if not isinstance(widths,list) or len(widths) not in (5,6):raise ValueError('La base doit avoir six colonnes.')
    # Old bases gain Brouillon to the left without moving any existing drawing.
    old=len(widths)==5
    out['widths']=([out['widths'][0]] if old else [])+[number(v) for v in widths]
    if any(not 50<=v<=5000 for v in out['widths']):raise ValueError('Largeur de colonne : 50 à 5 000 mm.')
    out['origin_x']=number(w.get('origin_x',-out['widths'][0] if old else 0))
    legacy_height=number(w.get('row_height',200))*number(w.get('rows',3))
    out['height']=number(w.get('height',legacy_height));out['header']=number(w.get('header',out['header']))
    if not 20<=out['height']<=50000 or not 20<=out['header']<=5000:raise ValueError('Hauteur de base ou des titres hors limites.')
    out['visible']=bool(w.get('visible',True));return out


def guide_segments(w):
    if not w or not w.get('visible',True):return []
    total=sum(w['widths']);bottom=w['header']+w['height'];origin=w.get('origin_x',0.)
    xs=[origin]
    for v in w['widths']:xs.append(xs[-1]+v)
    # Only vertical separators and the single header rule; no drawing grid. 0.19.13: a rule between two rows.
    # 0.19.14: a base without any title nor row (« Libre ») draws nothing (« sans colonnes j'ai quand même une ligne »)
    out=[((x,w['header']*.30),(x,bottom)) for x in xs[1:-1]]
    if any(column_labels(w)) or len(xs)>2 or rows_of(w):out.append(((origin,w['header']),(origin+total,w['header'])))
    return out+[((origin,end),(origin+total,end)) for _,_,end in rows_of(w)[:-1]]


def segment_intersection(a,b,c,d):
    ux,uy=b[0]-a[0],b[1]-a[1];vx,vy=d[0]-c[0],d[1]-c[1]
    den=ux*vy-uy*vx
    if abs(den)<EPS:return []
    wx,wy=c[0]-a[0],c[1]-a[1]
    t=(wx*vy-wy*vx)/den;u=(wx*uy-wy*ux)/den
    return [(a[0]+t*ux,a[1]+t*uy)] if -EPS<=t<=1+EPS and -EPS<=u<=1+EPS else []


def circle_data(s):return (s['x']+s['w']/2,s['y']+s['w']/2),s['w']/2


def segment_circle(a,b,s):
    c,r=circle_data(s);dx,dy=b[0]-a[0],b[1]-a[1];fx,fy=a[0]-c[0],a[1]-c[1]
    A=dx*dx+dy*dy
    if A<EPS:return []
    B=2*(fx*dx+fy*dy);C=fx*fx+fy*fy-r*r;D=B*B-4*A*C
    if D<-EPS:return []
    ts={(-B-math.sqrt(max(0,D)))/(2*A),(-B+math.sqrt(max(0,D)))/(2*A)}
    return [(a[0]+t*dx,a[1]+t*dy) for t in ts if -EPS<=t<=1+EPS]


def circles_intersect(s,t):
    a,r=circle_data(s);b,R=circle_data(t);d=math.dist(a,b)
    if d<EPS or d>r+R+EPS or d<abs(r-R)-EPS:return []
    u=(r*r-R*R+d*d)/(2*d);h=math.sqrt(max(0,r*r-u*u))
    dx,dy=(b[0]-a[0])/d,(b[1]-a[1])/d
    return [(a[0]+u*dx-h*dy,a[1]+u*dy+h*dx),(a[0]+u*dx+h*dy,a[1]+u*dy-h*dx)]


def segments(s):
    pts,closed=path(s)
    return list(zip(pts,pts[1:]+pts[:1] if closed else pts[1:]))


def intersections(s,t,box=None):
    # Distant contours cannot cross: skip the exact search (see geometry._margin).
    if boxes_apart(s,t):return []
    # 0.19.9: box (x0, y0, x1, y1): only the crossings inside it are wanted (a snap under the pointer): the
    # parts, segments and curves away from it are not read; those inside come out the same, in the same order.
    near=(lambda v:segments_near(v,box)) if box else segments
    if s.get('components') or t.get('components'):
        from curves import parts
        A,B=[[q for q in (parts(v) if v.get('components') else [v]) if not box or _reaches(q,box)] for v in (s,t)]
        return [p for a in A for b in B for p in intersections(a,b,box)]
    if s['kind']=='line' and t.get('ellipse') or t['kind']=='line' and s.get('ellipse'):
        from curves import ellipse_line_intersections
        return ellipse_line_intersections(t,s) if s['kind']=='line' else ellipse_line_intersections(s,t)
    if s['kind']=='line' and t.get('spline') or t['kind']=='line' and s.get('spline'):
        from curves import spline_line_intersections
        return spline_line_intersections(t,s,box) if s['kind']=='line' else spline_line_intersections(s,t,box)
    if s['kind']=='circle' and t['kind']=='circle':return circles_intersect(s,t)
    if s['kind']=='circle':s,t=t,s
    if t['kind']=='circle':return [p for a,b in near(s) for p in segment_circle(a,b,t)]
    return _crossings(near(s),near(t))


def _reaches(s,box):
    b=bounds([s]);return b[0]<=box[2] and b[2]>=box[0] and b[1]<=box[3] and b[3]>=box[1]


def _crossings(S,T):
    # 0.19.9: the crossings of segments S and T exactly as before (S in order, T by smallest x, a point within
    # 1e-6 mm of an earlier one left out), computed only for pairs whose boxes overlap: a sweep along x stopping
    # at both bounds (was n·m/2 for a contour and its stitch line), or a plain scan when one side is short.
    edges=[(min(c[0],d[0]),max(c[0],d[0]),min(c[1],d[1]),max(c[1],d[1]),c,d) for c,d in T];hits=[]
    if len(S)<=8 or len(edges)<=8:
        for i,(a,b) in enumerate(S):
            x,X=min(a[0],b[0])-EPS,max(a[0],b[0])+EPS;y,Y=min(a[1],b[1])-EPS,max(a[1],b[1])+EPS
            for e in edges:
                if e[0]<=X and e[1]>=x and e[3]>=y and e[2]<=Y:hits+=[(i,e,p) for p in segment_intersection(a,b,e[4],e[5])]
    else:
        boxes=[(min(a[0],b[0])-EPS,max(a[0],b[0])+EPS,min(a[1],b[1])-EPS,max(a[1],b[1])+EPS) for a,b in S];open_s=[];open_t=[]
        # Each pair is met once, when the later of its two segments starts: the other is still open then.
        for _,side,k in sorted([(v[0],0,i) for i,v in enumerate(boxes)]+[(e[0],1,j) for j,e in enumerate(edges)]):
            if side:
                e=edges[k];keep=[]
                for i in open_s:
                    x,X,y,Y=boxes[i]
                    if X<e[0]:continue   # ended on the left: no later segment of T reaches it
                    keep.append(i)
                    if y<=e[3] and Y>=e[2]:hits+=[(i,e,p) for p in segment_intersection(*S[i],e[4],e[5])]
                open_s=keep;open_t.append(k)
            else:
                x,X,y,Y=boxes[k];keep=[]
                for j in open_t:
                    e=edges[j]
                    if e[1]<x:continue
                    keep.append(j)
                    if e[3]>=y and e[2]<=Y:hits+=[(k,e,p) for p in segment_intersection(*S[k],e[4],e[5])]
                open_t=keep;open_s.append(k)
    hits.sort();out=[]
    for _,_,p in hits:
        if not any(math.dist(p,q)<1e-6 for q in out):out.append(p)
    return out


def quarters(a,b):
    """0.18.1 « Quarts »: 1/4 and 3/4 of a straight line."""
    return [((3*a[0]+b[0])/4,(3*a[1]+b[1])/4),((a[0]+3*b[0])/4,(a[1]+3*b[1])/4)]


_ANCHORS={}


def object_anchors(s):
    """The snap points of s ((point, kind) in a fresh list). 0.19.9: worked out once per geometry and kept by
    its key, like boxes and paths: the pointer asked for them up to 5 times per move (two snaps, the anchor
    stack, the marks on the piece under the mouse), 90 ms per move by a 200-vertex rounded piece."""
    try:key=geometry_key(s)
    except (TypeError,ValueError):return _object_anchors(s)
    hit=_ANCHORS.get(key)
    if hit is None:
        hit=tuple(_object_anchors(s))
        if len(_ANCHORS)>=4096:_ANCHORS.pop(next(iter(_ANCHORS)))
        _ANCHORS[key]=hit
    return list(hit)


def _unique(result,tol=1e-7):
    """0.19.9: the anchors without a repeat of the same kind closer than tol, the first one kept: exactly as
    comparing each with every one kept, but by cells of tol (it was quadratic: 15 ms for 200 vertices)."""
    kept=[];cells={}
    for pt,kind in result:
        if not (math.isfinite(pt[0]) and math.isfinite(pt[1])):
            if not any(k==kind and math.dist(pt,q)<tol for q,k in kept):kept.append((pt,kind))
            continue
        cx,cy=math.floor(pt[0]/tol),math.floor(pt[1]/tol)
        if any(math.dist(pt,q)<tol for i in (-1,0,1) for j in (-1,0,1) for q in cells.get((kind,cx+i,cy+j),())):continue
        kept.append((pt,kind));cells.setdefault((kind,cx,cy),[]).append(pt)
    return kept


def _object_anchors(s):
    result=[];kind=s['kind']
    if s.get('components'):
        from curves import parts
        return [p for q in parts(s) for p in object_anchors(q)]
    if s.get('spline'):
        from curves import cubics,bezier
        sp=s['spline'];cs=cubics(s)
        result=[((s['x']+x,s['y']+y),'endpoint') for x,y in sp.get('fit',[])]
        if not result:result=[(c[0],'endpoint') for c in cs]+[(cs[-1][-1],'endpoint')]
        return result+[(bezier(c,.5),'midpoint') for c in cs]
    if s.get('ellipse'):
        from precision_geometry import ellipse_point
        e=s['ellipse'];result=[((s['x'],s['y']),'center')]
        if s.get('closed'):result += [(ellipse_point(s,t),'quadrant') for t in (0,math.pi/2,math.pi,3*math.pi/2)]
        else:result += [(ellipse_point(s,t),'endpoint') for t in (e['start'],e['start']+e['sweep'])]
        return result
    if kind=='circle':
        c,r=circle_data(s);result.append((c,'center'))
        result += [((c[0]+r*math.cos(t),c[1]+r*math.sin(t)),'quadrant') for t in (0,math.pi/2,math.pi,3*math.pi/2)]
        return result
    pts,closed=path(s)
    if kind=='rect':
        x,y,w,h,r=[s[k] for k in ('x','y','w','h','r')]
        result.append(((x+w/2,y+h/2),'center'))
        if not r:
            corners=[(x,y),(x+w,y),(x+w,y+h),(x,y+h)]
            result += [(p,'endpoint') for p in corners]
        else:
            result += [((cx,cy),'center') for cx,cy in ((x+r,y+r),(x+w-r,y+r),(x+w-r,y+h-r),(x+r,y+h-r))]
            # Tangency points are on the actual rounded contour, not its virtual corners.
            result += [(p,'endpoint') for p in [(x+r,y),(x+w-r,y),(x+w,y+r),(x+w,y+h-r),
                                               (x+w-r,y+h),(x+r,y+h),(x,y+h-r),(x,y+r)]]
        result += [(p,'midpoint') for p in [(x+w/2,y),(x+w,y+h/2),(x+w/2,y+h),(x,y+h/2)]]
        r=min(abs(r),abs(w)/2,abs(h)/2) if r else 0
        for a,b in [((x+r,y),(x+w-r,y)),((x+w,y+r),(x+w,y+h-r)),((x+w-r,y+h),(x+r,y+h)),((x,y+h-r),(x,y+r))]:
            if math.dist(a,b)>1e-7:result += [(p,'quarter') for p in quarters(a,b)]
        return result
    if kind=='poly' and any(s.get('bulges',[])):
        from precision_geometry import primitives,at_primitive
        arcs=primitives(s)
        result += [(q['a'],'endpoint') for q in arcs]
        if not closed and arcs:result.append((arcs[-1]['b'],'endpoint'))
        result += [(at_primitive(q,.5),'midpoint') for q in arcs]
        result += [(at_primitive(q,t),'quarter') for q in arcs if not q['sweep'] for t in (.25,.75)]
        for q in arcs:
            if not q['sweep']:continue
            result.append((q['c'],'center'))
            for angle in (0,math.pi/2,math.pi,3*math.pi/2):
                delta=(angle-q['start'])%(2*math.pi) if q['sweep']>0 else (q['start']-angle)%(2*math.pi)
                if delta<=abs(q['sweep'])+1e-8:result.append(((q['c'][0]+q['r']*math.cos(angle),q['c'][1]+q['r']*math.sin(angle)),'quadrant'))
        return _unique(result)
    result += [(p,'endpoint') for p in pts]
    pairs=segments(s)
    result += [(((a[0]+b[0])/2,(a[1]+b[1])/2),'midpoint') for a,b in pairs]
    result += [(p,'quarter') for a,b in pairs if math.dist(a,b)>1e-7 for p in quarters(a,b)]
    return result


def project(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1];den=dx*dx+dy*dy
    t=max(0,min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/den)) if den else 0
    return a[0]+t*dx,a[1]+t*dy


def nearest(p,s):
    if s.get('components'):
        from curves import parts
        return min((nearest(p,q) for q in parts(s)),key=lambda q:math.dist(p,q))
    if s['kind']=='circle':
        c,r=circle_data(s);d=math.dist(c,p)
        return (c[0]+r,c[1]) if d<EPS else (c[0]+(p[0]-c[0])*r/d,c[1]+(p[1]-c[1])*r/d)
    return min((project(p,a,b) for a,b in segments(s)),key=lambda q:math.dist(q,p))


_PRIMITIVES={}


def construction_snaps(p,items,modes,tol,base=None,reach=None):
    """0.19.13 the accroches of AutoCAD that Craft lacked: Extension (a line or an arc continued past its end, near
    that end), Perpendiculaire and Tangente (from the point the drawing comes from: ``base``), Parallèle (from
    ``base``, along a line of the drawing), Centre géométrique (of a closed outline). [(point, kind)] within ``tol``
    of ``p``; ``reach``: how far from an end its extension, or from the mouse the line of a parallel, is looked for."""
    out=[];reach=reach if reach is not None else 15*tol
    try:from precision_geometry import primitives
    except ImportError:return out
    def on_arc(q,c,start,sweep):
        a=math.atan2(q[1]-c[1],q[0]-c[0]);d=(a-start)%(2*math.pi) if sweep>0 else (start-a)%(2*math.pi)
        return d<=abs(sweep)+1e-9
    v=(p[0]-base[0],p[1]-base[1]) if base is not None else None
    nv=math.hypot(*v) if v else 0
    for s in items:
        hit=_PRIMITIVES.get(id(s))
        if hit is not None and hit[0] is s:prims=hit[1]
        else:
            try:prims=primitives(s)
            except (ValueError,KeyError,TypeError,ZeroDivisionError):continue
            if len(_PRIMITIVES)>2000:_PRIMITIVES.clear()
            _PRIMITIVES[id(s)]=(s,prims)   # (the same object at each move of the mouse: computed once)
        if 'centroid' in modes:
            try:pts,closed=path(s)
            except (ValueError,KeyError,TypeError):pts,closed=[],False
            if closed and len(pts)>2:
                area=cx=cy=0.
                for (x0,y0),(x1,y1) in zip(pts,pts[1:]+pts[:1]):
                    k=x0*y1-x1*y0;area+=k;cx+=(x0+x1)*k;cy+=(y0+y1)*k
                if abs(area)>1e-9:
                    q=(cx/(3*area),cy/(3*area))
                    if math.dist(q,p)<=tol:out.append((q,'centroid'))
        for q in prims:
            if not q['sweep']:
                a,b=q['a'],q['b'];L=q['length'];u=((b[0]-a[0])/L,(b[1]-a[1])/L)
                if 'extension' in modes:
                    for end,sign in ((b,1),(a,-1)):
                        if math.dist(end,p)>reach:continue
                        k=((p[0]-end[0])*u[0]+(p[1]-end[1])*u[1])*sign
                        if k>1e-6:
                            e=(end[0]+sign*k*u[0],end[1]+sign*k*u[1])
                            if math.dist(e,p)<=tol:out.append((e,'extension'))
                if base is not None and 'perpendicular' in modes:
                    k=(base[0]-a[0])*u[0]+(base[1]-a[1])*u[1]
                    if -1e-9<=k<=L+1e-9:
                        f=(a[0]+k*u[0],a[1]+k*u[1])
                        if math.dist(f,p)<=tol and math.dist(f,base)>1e-6:out.append((f,'perpendicular'))
                if base is not None and 'parallel' in modes and nv>1e-6 and math.dist(base,p)>tol:
                    cross=(v[0]*u[1]-v[1]*u[0])/nv
                    near=min(math.dist(a,p),math.dist(b,p),math.dist(a,base),math.dist(b,base))<=reach
                    if near and abs(cross)<=math.sin(math.radians(2)) and math.dist(a,b)>tol:
                        k=v[0]*u[0]+v[1]*u[1];e=(base[0]+k*u[0],base[1]+k*u[1])
                        if math.dist(e,p)<=tol:out.append((e,'parallel'))
            else:
                c,r=q['c'],q['r']
                if 'extension' in modes and abs(math.dist(c,p)-r)<=tol:
                    a=math.atan2(p[1]-c[1],p[0]-c[0]);e=(c[0]+r*math.cos(a),c[1]+r*math.sin(a))
                    end=q['b'] if math.dist(q['b'],p)<=math.dist(q['a'],p) else q['a']
                    if not on_arc(e,c,q['start'],q['sweep']) and math.dist(end,p)<=reach:out.append((e,'extension'))
                if base is not None and ('perpendicular' in modes or 'tangent' in modes):
                    d=math.dist(c,base)
                    if d>1e-9:
                        phi=math.atan2(base[1]-c[1],base[0]-c[0]);found=[]
                        if 'perpendicular' in modes:found+=[(phi,'perpendicular'),(phi+math.pi,'perpendicular')]
                        if 'tangent' in modes and d>r+1e-9:
                            al=math.acos(r/d);found+=[(phi+al,'tangent'),(phi-al,'tangent')]
                        for ang,kind in found:
                            e=(c[0]+r*math.cos(ang),c[1]+r*math.sin(ang))
                            if math.dist(e,p)<=tol and on_arc(e,c,q['start'],q['sweep']):out.append((e,kind))
    return out


def snap_point(p,items,modes,tol,workspace=None,exclude=None,base=None):
    active=[s for i,s in enumerate(items) if i!=exclude]
    # Bounding-box filtering keeps intersection search local to the pointer.
    nearby=[];candidates=[];wide=[]
    building={'extension','perpendicular','tangent','parallel','centroid'}&set(modes)
    reach=15*tol
    for s in active:
        b=bounds([s])
        if b[0]-tol<=p[0]<=b[2]+tol and b[1]-tol<=p[1]<=b[3]+tol:
            nearby.append(s)
            candidates += [(q,typ) for q,typ in object_anchors(s) if typ in modes and math.dist(q,p)<=tol]
        if building and (b[0]-reach<=p[0]<=b[2]+reach and b[1]-reach<=p[1]<=b[3]+reach or
                         base is not None and 'parallel' in modes and b[0]-reach<=base[0]<=b[2]+reach and b[1]-reach<=base[1]<=b[3]+reach):
            wide.append(s)
    soft=[]
    if building:
        for q,typ in construction_snaps(p,wide,modes,tol,base,reach):
            (soft if typ in ('extension','parallel') else candidates).append((q,typ))
    if 'intersection' in modes:
        # 0.19.9: only the crossings near the pointer (the same ones), found once per pointer event: the 10 px
        # snap that follows the 18 px one reads what that one found (every crossing was computed, twice).
        memo=frame_cache();box=(p[0]-tol-1,p[1]-tol-1,p[0]+tol+1,p[1]+tol+1)
        for i,s in enumerate(nearby):
            for t in nearby[i+1:]:
                hit=memo.get(('crossings',id(s),id(t))) if memo is not None else None
                if not (hit and hit[0] is s and hit[1] is t and hit[2]==p and hit[3]>=tol):
                    hit=(s,t,p,tol,intersections(s,t,box))
                    if memo is not None:memo[('crossings',id(s),id(t))]=hit
                candidates += [(q,'intersection') for q in hit[4] if math.dist(q,p)<=tol]
    if 'guides' in modes:
        for a,b in guide_segments(workspace):
            q=project(p,a,b)
            if math.dist(q,p)<=tol:candidates.append((q,'guides'))
    # Deliberate priority: precise object anchors before projections on a curve/guide (0.19.13: and on an
    # extension or a parallel).
    precise=[c for c in candidates if c[1]!='guides']
    if precise:return min(precise,key=lambda c:math.dist(c[0],p))
    candidates+=soft
    if 'nearest' in modes:
        candidates += [(nearest(p,s),'nearest') for s in nearby if distance_to_shape(p,s)<=tol]
    return min(candidates,key=lambda c:math.dist(c[0],p)) if candidates else (p,None)


def distance_to_shape(p,s):return math.dist(p,nearest(p,s))


def directed(a,b,length,ortho=False):
    length=number(length)
    if length<=0:raise ValueError('La longueur doit être positive.')
    dx,dy=b[0]-a[0],b[1]-a[1]
    if ortho:
        if abs(dx)>=abs(dy):dx,dy=(-1 if dx<0 else 1),0
        else:dx,dy=0,(-1 if dy<0 else 1)
    n=math.hypot(dx,dy)
    if n<EPS:dx,dy,n=1,0,1
    return a[0]+length*dx/n,a[1]+length*dy/n


def shape(kind,name='Pièce',x=0,y=0,w=0,h=0,r=0,**more):
    return dict(kind=kind,name=name,x=x,y=y,w=w,h=h,r=r,**more)


def polygon(points,name='Pièce',closed=True):
    x,y=points[0];xs=[p[0] for p in points];ys=[p[1] for p in points]
    return shape('poly',name,x,y,max(xs)-min(xs),max(ys)-min(ys),points=[[a-x,b-y] for a,b in points],closed=closed)


def circle_three(a,b,c,name='Cercle'):
    # Translate to A to reduce cancellation for drawings far from the origin.
    bx,by=b[0]-a[0],b[1]-a[1];cx,cy=c[0]-a[0],c[1]-a[1]
    D=2*(bx*cy-by*cx)
    if abs(D)<EPS:raise ValueError('Les trois points du cercle sont alignés ou trop proches.')
    ux=((bx*bx+by*by)*cy-(cx*cx+cy*cy)*by)/D
    uy=(bx*(cx*cx+cy*cy)-cx*(bx*bx+by*by))/D
    radius=math.hypot(ux,uy);x,y=a[0]+ux,a[1]+uy
    return shape('circle',name,x-radius,y-radius,radius*2,radius*2)


def construct(tool,pts,name='Pièce',radius=0):
    a,b=pts[:2];dx,dy=b[0]-a[0],b[1]-a[1]
    if tool=='line':return shape('line',name,*a,dx,dy)
    if tool in ('rect','rect_round','rect_center'):
        if tool=='rect_center':x,y=a[0]-abs(dx),a[1]-abs(dy);w,h=2*abs(dx),2*abs(dy)
        else:x,y=min(a[0],b[0]),min(a[1],b[1]);w,h=abs(dx),abs(dy)
        r=max(0,min(radius,w/2,h/2)) if tool=='rect_round' else 0
        return shape('rect',name,x,y,w,h,r)
    if tool in ('circle_radius','circle_diameter'):
        rad=math.dist(a,b)/(2 if tool=='circle_diameter' else 1)
        return shape('circle',name,a[0]-rad,a[1]-rad,2*rad,2*rad)
    if tool=='circle_2p':
        rad=math.dist(a,b)/2;cx,cy=(a[0]+b[0])/2,(a[1]+b[1])/2
        return shape('circle',name,cx-rad,cy-rad,rad*2,rad*2)
    if tool=='circle_3p':return circle_three(a,b,pts[2],name)
    if tool=='para':
        c=pts[2];return polygon([a,b,c,(a[0]+c[0]-b[0],a[1]+c[1]-b[1])],name)
    if tool=='rect_rot':
        c=pts[2];n=math.hypot(dx,dy)
        if n<EPS:raise ValueError('La base du rectangle est trop courte.')
        ux,uy=-dy/n,dx/n;h=(c[0]-b[0])*ux+(c[1]-b[1])*uy
        return polygon([a,b,(b[0]+ux*h,b[1]+uy*h),(a[0]+ux*h,a[1]+uy*h)],name)
    raise ValueError('Outil inconnu.')


def read_document(file,background=False,infos=False,meta=False):
    """(items, workspace), or (items, workspace, background) with ``background=True`` (0.18.0:
    the picture kept under the plan, None when there is none or it is not usable); ``infos``
    (0.18.1): (items, workspace, background, infos), the « Infos du modèle » or None; ``meta``:
    the same and a dict(crans=…), 'mozart' when the file was written with Mozart's crans."""
    p=Path(file)
    if p.stat().st_size>30000000:raise ValueError('Document trop volumineux.')
    doc=json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(doc,dict) or doc.get('format')!='atelier-patron' or doc.get('version') not in (1,2) or doc.get('units')!='mm':raise ValueError('Format non reconnu.')
    from craft_tools import separate_notches
    items,workspace=validate(separate_notches(validate(doc['shapes']))),validate_workspace(doc.get('workspace'))
    if meta:return items,workspace,validate_background(doc.get('background')),validate_infos(doc.get('infos')),dict(crans=doc.get('crans'))
    if infos:return items,workspace,validate_background(doc.get('background')),validate_infos(doc.get('infos'))
    if not background:return items,workspace
    return items,workspace,validate_background(doc.get('background'))


# 0.18.1 « Infos du modèle »: what the person writes about the model (all optional), the two
# dates Craft fills in (still editable) and the fournitures of the nomenclature.
INFO_FIELDS=('modele','description','createur','atelier','saison','indice','cree_le','modifie_le','dernier_id',   # dernier_id: piece_ids
             # 0.19.13: as Mozart's Infos du modèle
             'version','ligne','matieres','clients','info1','info2','info3','approuve_le','approuve_par','verifie_le','verifie_par','note')
SUPPLY_FIELDS=('nom','nb','matiere','info')


def validate_infos(d):
    """The model's infos read from a document: checked, or None when there is nothing."""
    if not isinstance(d,dict):return None
    out={}
    for key in INFO_FIELDS:
        value=d.get(key)
        if isinstance(value,(int,float)) and not isinstance(value,bool):value=f'{value:g}'
        if isinstance(value,str) and value.strip():out[key]=value.strip()[:1000]
    supplies=[]
    rows=d.get('fournitures');rows=rows if isinstance(rows,list) else []
    for row in rows:
        if not isinstance(row,dict):continue
        clean={k:str(row.get(k,'')).strip()[:1000] for k in SUPPLY_FIELDS if str(row.get(k,'')).strip()}
        if clean.get('nom'):supplies.append(clean)
        if len(supplies)>=300:break
    if supplies:out['fournitures']=supplies
    # 0.19.13: the model sheet of a Mozart file as it was (its 21 values), written back where Craft has nothing
    raw=d.get('mozart_info')
    if isinstance(raw,list) and 0<len(raw)<=50 and all(isinstance(v,str) for v in raw) and any(v.strip() for v in raw):out['mozart_info']=[v[:1000] for v in raw]
    image=validate_model_image(d.get('image'))
    if image:out['image']=image   # 0.19.14 « Image du modèle »
    return out or None


def validate_model_image(m):
    """0.19.14 « Image du modèle » (on the fiches): dict(format 'jpeg' or 'png', data in base64, pixels [w, h], name)
    checked, or None when it is not usable (the infos are kept without it)."""
    if not isinstance(m,dict):return None
    try:out=dict(format=m['format'],data=m['data'],pixels=[int(v) for v in m['pixels']],name=str(m.get('name',''))[:200])
    except (KeyError,TypeError,ValueError,OverflowError):return None
    if out['format'] not in ('jpeg','png') or not isinstance(out['data'],str) or not 0<len(out['data'])<=8_000_000:return None
    if len(out['pixels'])!=2 or not all(1<=v<=20000 for v in out['pixels']):return None
    return out


def validate_background(b):
    """0.18.0 Image de fond read from a document: checked, or None when it is not usable."""
    if not isinstance(b,dict):return None
    try:
        out=dict(name=str(b.get('name',''))[:200],format=b['format'],data=b['data'],pixels=[int(v) for v in b['pixels']],
                 x=float(b['x']),y=float(b['y']),w=float(b['w']),h=float(b['h']),
                 opacity=float(b.get('opacity',.4)),visible=bool(b.get('visible',True)))
    except (KeyError,TypeError,ValueError):return None
    if out['format'] not in ('jpeg','png') or not isinstance(out['data'],str) or not 0<len(out['data'])<=28_000_000:return None
    if len(out['pixels'])!=2 or not all(1<=v<=20000 for v in out['pixels']):return None
    if not all(math.isfinite(out[k]) for k in ('x','y','w','h','opacity')) or not (0<out['w']<=100000 and 0<out['h']<=100000):return None
    if not all(abs(out[k])<=1e6 for k in ('x','y')):return None
    out['opacity']=max(.05,min(1.,out['opacity']))
    crop=valid_crop(b.get('crop'))
    if crop:out['crop']=crop   # 0.19.7 « Recadrer »
    return out


def valid_crop(c):
    """0.19.7: the part of a background picture kept by « Recadrer »: [left, top, right, bottom] as fractions
    of the picture (at least 1 % each way); None for the whole picture or anything unusable."""
    try:c=[float(v) for v in c]
    except (TypeError,ValueError):return None
    if len(c)!=4 or not all(math.isfinite(v) for v in c):return None
    l,t,r,b=c
    if not (0<=l and r<=1 and 0<=t and b<=1 and r-l>=.01-1e-9 and b-t>=.01-1e-9):return None   # (1 % as computed: r - .01 can come out a hair under)
    return None if c==[0.,0.,1.,1.] else c


def write_document(file,items,workspace,background=None,infos=None):
    validate(items);w=validate_workspace(workspace)
    version=2 if any(s.get('spline') or s.get('components') for s in items) else 1
    # 0.18.1: crans='mozart': the crans are drawn like Mozart's (doc_files.current_crans is not
    # applied again when the file is opened).
    data=dict(format='atelier-patron',version=version,units='mm',shapes=items,workspace=w,crans='mozart')
    if background:data['background']=validate_background(background)   # 0.18.0 image de fond
    infos=validate_infos(infos)
    if infos:data['infos']=infos   # 0.18.1 Infos du modèle
    p=Path(file);temp=p.with_suffix(p.suffix+'.tmp')
    # 0.19.17: written compact (no indent): Python's fast JSON writer, 4 to 5 times faster, a file half the size
    temp.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8');temp.replace(p)
