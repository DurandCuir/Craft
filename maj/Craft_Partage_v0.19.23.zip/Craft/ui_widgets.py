"""Small code-drawn toolbar icons: scalable, recolorable, no external image assets."""
import tkinter as tk
import math
from collections import OrderedDict


def bind_own(window,sequence,func):
    """0.19.3: an event of ``window`` itself only. A binding on a window's path also runs for every
    widget inside it (its Configure, Map, Destroy…): hundreds of Python calls each time the toolbars,
    the tabs or a window are built, all of them returning at once."""
    try:
        tag='Own'+str(window);tags=tuple(window.bindtags())
        if tag not in tags:window.bindtags((tag,)+tags)
        return window.bind_class(tag,sequence,func,add='+')
    except (TypeError,AttributeError,tk.TclError):
        return window.bind(sequence,func,add='+')   # a stand-in window (tests)


def keep_fonts_alive(canvas,limit=96):
    """Tk frees a font when its last text item is deleted and loads it again on
    the next create_text (0.3 ms or more each). An unmapped label per font keeps
    it cached, so redraws and pointer feedback do not reload fonts (0.16.15)."""
    keep=OrderedDict();original=canvas.create_text
    def create_text(*args,**kw):
        font=kw.get('font')
        if font is not None:
            try:
                key=tuple(font) if isinstance(font,list) else font
                if key in keep:keep.move_to_end(key)
                else:
                    keep[key]=tk.Label(canvas,font=font)
                    if len(keep)>limit:keep.popitem(last=False)[1].destroy()
            except (tk.TclError,TypeError):pass
        return original(*args,**kw)
    canvas.create_text=create_text
    return keep


def forget_zoom_marks(canvas):
    """0.18.3: after a full drawing (or pieces drawn around the screen), the wheel zoom looks again
    for the texts and dashes it resizes (advanced_ui.zoom_marks)."""
    try:canvas.tk.eval('catch {unset ::craft_zoom_ids}')
    except (AttributeError,tk.TclError):pass


def dash_px(dash,scale):
    """A dash pattern given in mm, in screen pixels at this zoom (Tk takes 1 to 255 px; closer than
    42 px per mm, the 6 mm dash of an Aide line broke the drawing before 0.18.3)."""
    return tuple(min(255,max(1,round(d*scale))) for d in dash)


def refill_list(box,names,select=None):
    """0.18.5: a Listbox filled with `names` without jumping back to the top: rebuilt only when its
    content changes (its scrolling kept), the chosen row selected and shown only when out of view."""
    names=[str(n) for n in names]
    current=box.get(0,'end')
    if list(current or ())!=names:
        view=box.yview();top=view[0] if view else 0;box.delete(0,'end')
        for n in names:box.insert('end',n)
        if top:box.yview_moveto(top)
    box.selection_clear(0,'end')
    if select is not None and 0<=select<len(names):
        box.selection_set(select);box.see(select)


def zoom_tag(tags,kind,value):
    """0.18.3: the size on the plan of a text (kind 't', its height in mm) or of a dash pattern ('d',
    in mm) kept in a tag: the wheel zoom (advanced_ui.zoom_marks) gives it, at each notch, exactly the
    size the next full drawing will give it."""
    tags=(tags,) if isinstance(tags,str) else tuple(tags or ())
    text=','.join(repr(float(v)) for v in value) if kind=='d' else repr(float(value))
    return tags+(f'zoom:{kind}={text}',)


def tag_created(canvas,tag):
    """Context: every canvas item created inside gets an extra tag."""
    class Tagging:
        def __enter__(self):
            self.previous=canvas.__dict__.get('_create');original=canvas._create;self.count=0
            def create(itemType,args,kw,original=original):
                self.count+=1;kw=dict(kw or {});existing=kw.get('tags',())
                existing=(existing,) if isinstance(existing,str) else tuple(existing or ())
                kw['tags']=existing+(tag,)
                return original(itemType,args,kw)
            canvas._create=create;return self
        def __exit__(self,*exc):
            if self.previous is None:canvas.__dict__.pop('_create',None)
            else:canvas._create=self.previous
            return False
    return Tagging()

def action_feedback(widget,accent):
    """Add hover/pressed feedback without replacing the action or tooltip bindings.
    0.19.0: flat, no raised / sunken edge: an icon (canvas) gets a rounded tile, a widget drawn by
    modern_style shows its own states, any other widget takes the hover colour."""
    if getattr(widget,'_action_feedback',False) or getattr(widget,'_modern_hover',False):return widget
    widget._action_feedback=True;state={}
    import modern_style
    try:
        if widget.winfo_class()=='Canvas':return modern_style.hover_tile(widget)
    except Exception:pass
    def enabled():return widget.winfo_exists() and ('state' not in widget.keys() or widget.cget('state')!='disabled')
    def enter(e):
        if not enabled():return
        state['bg']=widget.cget('bg')
        widget.configure(bg=modern_style.theme(widget)['hover'])
    def leave(e):
        if not widget.winfo_exists():return
        if 'bg' in state:widget.configure(bg=state.pop('bg'))
    for sequence,fn in [('<Enter>',enter),('<Leave>',leave)]:widget.bind(sequence,fn,add='+')
    return widget


def windows():
    import os
    return os.name=='nt'


def open_security_settings():
    """0.19.19: Windows Security on « Contrôle intelligent des applications » (on « Contrôle des applications et du
    navigateur » when that page is missing). Nothing is changed by Craft: the person decides there."""
    import os
    for page in ('windowsdefender://smartapp/','windowsdefender://appbrowser/'):
        try:os.startfile(page);return True
        except (OSError,AttributeError):continue
    return False


def show_error(title,text,parent=None):
    """0.19.19: an error box. Windows blocked the DWG converter (exchange.blocked_message: « Contrôle intelligent
    des applications »): the same explanation and « Ouvrir ces réglages maintenant ? » (09/11/2026)."""
    from tkinter import messagebox
    text=str(text)
    if 'Contrôle intelligent des applications' in text and windows():
        if messagebox.askyesno(title,text+'\n\nOuvrir ces réglages maintenant ?',icon='warning',parent=parent):open_security_settings()
        return
    messagebox.showerror(title,text,parent=parent)


def contrast_color(hexcolor):
    rgb=[int(hexcolor[i:i+2],16)/255 for i in (1,3,5)]
    linear=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in rgb]
    luminance=sum(v*w for v,w in zip(linear,(.2126,.7152,.0722)))
    return '#000000' if (luminance+.05)/.05 >= 1.05/(luminance+.05) else '#ffffff'


def auto_palette(p):
    p['ink']=contrast_color(p['canvas'])
    p['ui_ink']=contrast_color(p['panel'])
    return p


def draw_icon(c,name,size,color):
    u=size/24
    def line(*xy,**kw):c.create_line(*[v*u for v in xy],fill=color,width=1.4,**kw)
    def rect(a,b,d,e):c.create_rectangle(a*u,b*u,d*u,e*u,outline=color,width=1.4)
    def oval(a,b,d,e):c.create_oval(a*u,b*u,d*u,e*u,outline=color,width=1.4)
    if name=='select':line(5,3,5,19,9,15,13,22,16,20,12,13,18,13,5,3)
    elif name=='line':
        line(4,19,20,5);rect(2,17,6,21);rect(18,3,22,7)
    elif name=='rect':rect(3,5,21,19)
    elif name=='circle':oval(3,3,21,21);line(10,12,14,12);line(12,10,12,14)
    elif name=='poly':line(3,18,8,4,15,16,21,5)
    elif name=='new':rect(5,3,19,22);line(9,10,15,10);line(12,7,12,13)
    elif name=='open':line(2,19,2,6,10,6,12,9,22,9,19,20,2,20,6,11,21,11)
    elif name=='save':rect(3,3,21,21);rect(7,3,17,10);rect(7,14,17,21)
    elif name=='pdf':rect(4,2,20,22);line(8,7,16,7);line(8,11,16,11);line(8,15,14,15)
    elif name=='undo':line(8,5,3,10,9,14);line(3,10,15,10,20,15,19,20)
    elif name=='redo':line(16,5,21,10,15,14);line(21,10,9,10,4,15,5,20)
    elif name=='fit':
        for a,b,sx,sy in [(3,3,1,1),(21,3,-1,1),(3,21,1,-1),(21,21,-1,-1)]:
            line(a+6*sx,b,a,b,a,b+6*sy)
    elif name=='palette':
        oval(3,3,21,21);oval(6,7,9,10);oval(12,5,15,8);oval(16,10,19,13);oval(8,14,11,17)
    elif name=='pieces':rect(3,3,10,10);rect(14,3,21,10);rect(3,14,10,21);rect(14,14,21,21)
    elif name=='base':rect(2,3,22,21);line(2,8,22,8);line(8,3,8,21);line(15,3,15,21)
    elif name=='gear':
        points=[]
        for i in range(48):
            a=math.pi*i/24;r=10 if i%6 in (1,2,3) else 7.5
            points.extend([(12+r*math.cos(a))*u,(12+r*math.sin(a))*u])
        c.create_polygon(*points,fill='',outline=color,width=1.4);oval(9,9,15,15)
    elif name=='delete':line(5,7,19,7);line(9,4,15,4);rect(7,7,17,21);line(10,10,10,18);line(14,10,14,18)
    elif name=='duplicate':rect(3,3,16,16);rect(8,8,21,21)
    elif name=='close':line(5,5,19,19);line(19,5,5,19)
    else:oval(4,4,20,20)


class IconButton(tk.Frame):
    def __init__(self,parent,icon,command,tip,palette,size=24,dropdown=False,status=None):
        super().__init__(parent,bg=palette['panel'],highlightthickness=1,highlightbackground=palette['panel'])
        self.p=palette;self.status=status;self.tip=tip;self.command=command
        self.canvas=tk.Canvas(self,width=size+8+(7 if dropdown else 0),height=size+8,
                              bg=palette['panel'],highlightthickness=0,cursor='hand2')
        self.canvas.pack()
        self.canvas.create_rectangle(0,0,1,1,outline='')
        # Translate the canvas origin using a small inset.
        draw_icon(self.canvas,icon,size,contrast_color(palette['panel']))
        self.canvas.move('all',4,4)
        if dropdown:
            self.canvas.create_polygon(size+7,size/2+4,size+13,size/2+4,size+10,size/2+7,fill=contrast_color(palette['panel']),outline='')
        self.canvas.bind('<Button-1>',lambda e:command())
        self.canvas.bind('<Enter>',self.enter);self.canvas.bind('<Leave>',self.leave)
        self.tooltip=None;self.timer=None

    def enter(self,e):
        self.configure(highlightbackground=self.p['accent'])
        if self.status:self.status.set(self.tip)
        self.timer=self.after(600,self.show_tip)

    def leave(self,e):
        self.configure(highlightbackground=self.p['panel'])
        if self.timer:self.after_cancel(self.timer);self.timer=None
        if self.tooltip:self.tooltip.destroy();self.tooltip=None

    def show_tip(self):
        self.tooltip=tk.Toplevel(self);self.tooltip.overrideredirect(True)
        self.tooltip.geometry(f'+{self.winfo_rootx()+self.winfo_width()+4}+{self.winfo_rooty()+8}')
        tk.Label(self.tooltip,text=self.tip,bg=self.p['panel'],fg=contrast_color(self.p['panel']),padx=8,pady=5).pack()
