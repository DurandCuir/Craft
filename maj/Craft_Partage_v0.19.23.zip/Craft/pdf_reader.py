"""0.18.0 Image de fond from a PDF page: what is drawn on it, at its real size, without any
installed package.

``page_count(data)`` and ``read_page(data, index)`` read a PDF file (bytes): its pages (page tree),
the vector paths of a page (lines and curves, flattened) and the images placed on it (JPEG or
uncompressed / Flate pixels), all in millimetres from the top-left corner of the page, y down.
Text is not read (no fonts): a page made of text only gives nothing. An encrypted PDF is refused."""
import math
import re
import zlib

PT=25.4/72          # one PDF point in millimetres
MAX_SEGMENTS=400000
MAX_DEPTH=12


class PdfError(ValueError):
    pass


class Ref:
    __slots__=('num','gen')
    def __init__(self,num,gen):self.num=num;self.gen=gen
    def __repr__(self):return f'Ref({self.num},{self.gen})'


class Name(str):
    pass


class Op(str):
    """A bare keyword: an operator of a content stream."""


class Stream:
    __slots__=('dict','raw')
    def __init__(self,d,raw):self.dict=d;self.raw=raw


_WS=b' \t\r\n\x0c\x00'
_DELIM=b'()<>[]{}/%'
_TOKEN=re.compile(rb'[^ \t\r\n\x0c\x00()<>\[\]{}/%]+')


class Lexer:
    def __init__(self,data,pos=0):self.data=data;self.pos=pos

    def skip(self):
        d=self.data;n=len(d);p=self.pos
        while p<n:
            c=d[p]
            if c in _WS:p+=1
            elif c==0x25:   # % comment
                while p<n and d[p] not in b'\r\n':p+=1
            else:break
        self.pos=p

    def value(self,resolve_refs=True):
        """One PDF object at the current position (``N G R`` gives a Ref)."""
        self.skip();d=self.data;p=self.pos
        if p>=len(d):raise PdfError('PDF tronqué.')
        c=d[p:p+1]
        if c==b'<':
            if d[p:p+2]==b'<<':
                self.pos=p+2;out={}
                while True:
                    self.skip()
                    if self.data[self.pos:self.pos+2]==b'>>':self.pos+=2;break
                    if self.pos>=len(self.data):raise PdfError('Dictionnaire PDF non fermé.')
                    key=self.value()
                    if not isinstance(key,Name):raise PdfError('Clé PDF invalide.')
                    out[str(key)]=self.value()
                return out
            end=d.find(b'>',p)
            if end<0:raise PdfError('Chaîne PDF non fermée.')
            hexa=re.sub(rb'\s',b'',d[p+1:end]);self.pos=end+1
            if len(hexa)%2:hexa+=b'0'
            try:return bytes.fromhex(hexa.decode('ascii'))
            except ValueError:return b''
        if c==b'[':
            self.pos=p+1;out=[]
            while True:
                self.skip()
                if self.data[self.pos:self.pos+1]==b']':self.pos+=1;break
                if self.pos>=len(self.data):raise PdfError('Tableau PDF non fermé.')
                out.append(self.value())
            return out
        if c==b'(':return self.string()
        if c==b'/':
            m=_TOKEN.match(d,p+1);raw=m.group(0) if m else b'';self.pos=p+1+len(raw)
            return Name(re.sub(rb'#([0-9A-Fa-f]{2})',lambda g:bytes([int(g.group(1),16)]),raw).decode('latin-1'))
        m=_TOKEN.match(d,p)
        if not m:self.pos=p+1;return None
        word=m.group(0);self.pos=m.end()
        if word==b'true':return True
        if word==b'false':return False
        if word==b'null':return None
        try:number=int(word)
        except ValueError:
            try:return float(word)
            except ValueError:return Op(word.decode('latin-1'))   # an operator inside a content stream
        if resolve_refs:
            save=self.pos;self.skip();m2=_TOKEN.match(d,self.pos)
            if m2 and m2.group(0).isdigit():
                after=m2.end();self.pos=after;self.skip();m3=_TOKEN.match(d,self.pos)
                if m3 and m3.group(0)==b'R':self.pos=m3.end();return Ref(number,int(m2.group(0)))
            self.pos=save
        return number

    def string(self):
        d=self.data;p=self.pos+1;depth=1;out=bytearray();n=len(d)
        while p<n and depth:
            c=d[p]
            if c==0x5c and p+1<n:   # backslash
                e=d[p+1];p+=2
                table={0x6e:10,0x72:13,0x74:9,0x62:8,0x66:12,0x28:40,0x29:41,0x5c:92}
                if e in table:out.append(table[e])
                elif 0x30<=e<=0x37:
                    digits=bytes([e])
                    while len(digits)<3 and p<n and 0x30<=d[p]<=0x37:digits+=d[p:p+1];p+=1
                    out.append(int(digits,8)&255)
                elif e in (10,13):
                    if e==13 and p<n and d[p]==10:p+=1
                else:out.append(e)
                continue
            if c==0x28:depth+=1
            elif c==0x29:
                depth-=1
                if not depth:p+=1;break
            out.append(c);p+=1
        self.pos=p;return bytes(out)


def _ascii85(raw):
    raw=re.sub(rb'\s',b'',raw)
    if raw.startswith(b'<~'):raw=raw[2:]
    end=raw.find(b'~>')
    if end>=0:raw=raw[:end]
    out=bytearray();group=[]
    for c in raw:
        if c==0x7a and not group:out+=b'\0\0\0\0';continue
        group.append(c-33)
        if len(group)==5:
            v=0
            for g in group:v=v*85+g
            out+=v.to_bytes(4,'big');group=[]
    if group:
        n=len(group);group+=[84]*(5-n);v=0
        for g in group:v=v*85+g
        out+=v.to_bytes(4,'big')[:n-1]
    return bytes(out)


def _predict(data,params):
    """PNG / TIFF predictors of a FlateDecode stream."""
    if not isinstance(params,dict):return data
    predictor=params.get('Predictor',1)
    if not isinstance(predictor,int) or predictor<10:return data
    colors=params.get('Colors',1) or 1;bits=params.get('BitsPerComponent',8) or 8;columns=params.get('Columns',1) or 1
    bpp=max(1,colors*bits//8);row=(colors*bits*columns+7)//8;out=bytearray();prev=bytearray(row);p=0
    while p<len(data):
        kind=data[p];line=bytearray(data[p+1:p+1+row]);p+=1+row
        if len(line)<row:line+=bytes(row-len(line))
        if kind==1:
            for i in range(bpp,row):line[i]=(line[i]+line[i-bpp])&255
        elif kind==2:
            for i in range(row):line[i]=(line[i]+prev[i])&255
        elif kind==3:
            for i in range(row):line[i]=(line[i]+((line[i-bpp] if i>=bpp else 0)+prev[i])//2)&255
        elif kind==4:
            for i in range(row):
                a=line[i-bpp] if i>=bpp else 0;b=prev[i];c=prev[i-bpp] if i>=bpp else 0;pa,pb,pc=abs(b-c),abs(a-c),abs(a+b-2*c)
                line[i]=(line[i]+(a if pa<=pb and pa<=pc else b if pb<=pc else c))&255
        out+=line;prev=line
    return bytes(out)


class Document:
    def __init__(self,data):
        if not data.startswith(b'%PDF') and b'%PDF' not in data[:1024]:raise PdfError('Ce fichier n’est pas un PDF.')
        self.data=data;self.offsets={};self.cache={};self.packed={}
        for m in re.finditer(rb'(?<![0-9])(\d{1,10})\s+(\d{1,5})\s+obj\b',data):self.offsets[int(m.group(1))]=m.end()   # the last definition wins (updates)
        if not self.offsets:raise PdfError('PDF illisible.')
        self.trailer={}
        for m in re.finditer(rb'trailer\s*<<',data):
            try:self.trailer.update(Lexer(data,m.end()-2).value())
            except PdfError:pass
        for num,pos in list(self.offsets.items()):
            head=data[pos:pos+400]
            if b'/ObjStm' in head or b'/XRef' in head:
                try:obj=self.get(num)
                except (PdfError,ValueError,zlib.error):continue
                if isinstance(obj,Stream):
                    t=obj.dict.get('Type')
                    if t=='ObjStm':self._unpack(num,obj)
                    elif t=='XRef':
                        for k in ('Root','Encrypt','Info'):
                            if k in obj.dict and k not in self.trailer:self.trailer[k]=obj.dict[k]
        if 'Encrypt' in self.trailer:raise PdfError('PDF protégé : enregistrez la page en image (JPG ou PNG).')

    def _unpack(self,num,stream):
        try:
            data=self.decode(stream);n=int(self.resolve(stream.dict.get('N',0)));first=int(self.resolve(stream.dict.get('First',0)))
            head=Lexer(data);pairs=[]
            for _ in range(n):pairs.append((head.value(False),head.value(False)))
            for obj_num,offset in pairs:
                if isinstance(obj_num,int) and obj_num not in self.offsets:self.packed[obj_num]=(data,first+int(offset))
        except (PdfError,ValueError,TypeError,zlib.error):pass

    def get(self,num):
        if num in self.cache:return self.cache[num]
        self.cache[num]=None   # a reference to itself gives null
        if num in self.offsets:
            lex=Lexer(self.data,self.offsets[num]);obj=lex.value()
            if isinstance(obj,dict):
                save=lex.pos;lex.skip()
                if self.data[lex.pos:lex.pos+6]==b'stream':
                    start=lex.pos+6
                    if self.data[start:start+2]==b'\r\n':start+=2
                    elif self.data[start:start+1] in (b'\n',b'\r'):start+=1
                    length=obj.get('Length')
                    if isinstance(length,Ref):length=self.get(length.num)
                    end=start+length if isinstance(length,int) and length>=0 and self.data[start+length:start+length+40].lstrip().startswith(b'endstream') else self.data.find(b'endstream',start)
                    if end<0:end=len(self.data)
                    obj=Stream(obj,self.data[start:end])
                else:lex.pos=save
        elif num in self.packed:
            data,offset=self.packed[num];obj=Lexer(data,offset).value()
        else:obj=None
        self.cache[num]=obj;return obj

    def resolve(self,v):
        seen=0
        while isinstance(v,Ref) and seen<32:v=self.get(v.num);seen+=1
        return v

    def decode(self,stream,last=False):
        """The bytes of a stream through its filters; ``last``: stop before DCTDecode (JPEG kept)."""
        data=stream.raw;filters=self.resolve(stream.dict.get('Filter'));params=self.resolve(stream.dict.get('DecodeParms'))
        if filters is None:return data
        if not isinstance(filters,list):filters=[filters];params=[params]
        if not isinstance(params,list):params=[params]*len(filters)
        for f,p in zip(filters,params+[None]*len(filters)):
            f=str(self.resolve(f));p=self.resolve(p)
            if f in ('FlateDecode','Fl'):
                try:data=zlib.decompress(data)
                except zlib.error:
                    try:data=zlib.decompressobj().decompress(data)
                    except zlib.error:raise PdfError('PDF endommagé : contenu illisible.') from None   # 0.19.9: was a raw zlib error
                data=_predict(data,p)
            elif f in ('ASCIIHexDecode','AHx'):
                hexa=re.sub(rb'\s',b'',data).split(b'>')[0]
                try:data=bytes.fromhex((hexa+(b'0' if len(hexa)%2 else b'')).decode('ascii'))
                except (ValueError,UnicodeDecodeError):raise PdfError('PDF endommagé : contenu illisible.') from None   # 0.19.9: was a raw English error
            elif f in ('ASCII85Decode','A85'):data=_ascii85(data)
            elif f in ('DCTDecode','DCT','JPXDecode','CCITTFaxDecode','JBIG2Decode') and last:return data
            else:raise PdfError('Codage PDF non pris en charge : '+f+'.')
        return data

    def pages(self):
        root=self.resolve(self.trailer.get('Root'))
        if not isinstance(root,dict):
            root=next((o for o in (self.get(n) for n in self.offsets) if isinstance(o,dict) and o.get('Type')=='Catalog'),None)
        if not isinstance(root,dict):raise PdfError('PDF sans pages.')
        out=[]
        def walk(node,inherited,depth):
            node=self.resolve(node)
            if not isinstance(node,dict) or depth>50 or len(out)>5000:return
            inh=dict(inherited)
            for k in ('MediaBox','CropBox','Resources','Rotate'):
                if k in node:inh[k]=node[k]
            kids=self.resolve(node.get('Kids'))
            if node.get('Type')=='Pages' or isinstance(kids,list):
                for kid in kids or []:walk(kid,inh,depth+1)
            else:
                page=dict(node);page.update({k:v for k,v in inh.items() if k not in node});out.append(page)
        walk(root.get('Pages'),{},0)
        if not out:raise PdfError('PDF sans pages.')
        return out


def page_count(data):
    return len(Document(data).pages())


def _numbers(values):
    return [float(v) for v in values]


def _box(doc,page):
    box=doc.resolve(page.get('CropBox') or page.get('MediaBox'))
    try:
        x0,y0,x1,y1=_numbers([doc.resolve(v) for v in box])
    except (TypeError,ValueError):x0,y0,x1,y1=0.,0.,595.,842.   # A4
    return min(x0,x1),min(y0,y1),max(x0,x1),max(y0,y1)


def _mul(a,b):
    """PDF matrices [a b c d e f]: a then b."""
    return [a[0]*b[0]+a[1]*b[2],a[0]*b[1]+a[1]*b[3],a[2]*b[0]+a[3]*b[2],a[2]*b[1]+a[3]*b[3],a[4]*b[0]+a[5]*b[2]+b[4],a[4]*b[1]+a[5]*b[3]+b[5]]


def _apply(m,x,y):return (m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5])


def _bezier(p0,p1,p2,p3,steps):
    out=[]
    for k in range(1,steps+1):
        t=k/steps;u=1-t
        out.append((u*u*u*p0[0]+3*u*u*t*p1[0]+3*u*t*t*p2[0]+t*t*t*p3[0],u*u*u*p0[1]+3*u*u*t*p1[1]+3*u*t*t*p2[1]+t*t*t*p3[1]))
    return out


def _skip_inline_image(data,pos):
    """After « ID »: the end of an inline image (« EI » between white spaces)."""
    m=re.compile(rb'\sEI(?=[\s]|$)').search(data,pos)
    return m.end() if m else len(data)


def read_page(data,index=0):
    """{'width','height' (mm), 'paths': [[(x,y),…],…] (mm, y down), 'images': [dict(stream, matrix)]}.
    ``matrix`` maps the image's unit square (0,0)-(1,1) to page millimetres (y down)."""
    doc=Document(data);pages=doc.pages()
    if not 0<=index<len(pages):raise PdfError('Page inexistante.')
    page=pages[index];x0,y0,x1,y1=_box(doc,page);rotate=int(doc.resolve(page.get('Rotate',0)) or 0)%360
    w,h=(x1-x0),(y1-y0)
    # Page space (points, y up) → millimetres, y down, page rotation included.
    base=[PT,0,0,-PT,-x0*PT,y1*PT]
    W,H=w*PT,h*PT
    if rotate==90:base=_mul(base,[0,1,-1,0,H,0]);W,H=H,W
    elif rotate==180:base=_mul(base,[-1,0,0,-1,W,H])
    elif rotate==270:base=_mul(base,[0,-1,1,0,0,W]);W,H=H,W
    paths=[];images=[];count=[0]

    def run(content,resources,ctm,depth):
        if depth>MAX_DEPTH:return
        resources=doc.resolve(resources) or {}
        xobjects=doc.resolve(resources.get('XObject')) if isinstance(resources,dict) else {}
        lex=Lexer(content);stack=[];args=[];current=[];subpaths=[];point=None;start=None
        def flush(paint):
            nonlocal current,subpaths
            if current:subpaths.append(current)
            if paint:
                for sp in subpaths:
                    if len(sp)>1 and count[0]<MAX_SEGMENTS:
                        paths.append([_apply(ctm,*p) for p in sp]);count[0]+=len(sp)
            current=[];subpaths=[]
        while True:
            lex.skip()
            if lex.pos>=len(content):break
            try:tok=lex.value(resolve_refs=False)
            except PdfError:break
            if not isinstance(tok,Op):
                args.append(tok)
                if len(args)>64:args=args[-64:]
                continue
            op=str(tok)
            try:
                if op=='q':stack.append(ctm)
                elif op=='Q':ctm=stack.pop() if stack else ctm
                elif op=='cm' and len(args)>=6:ctm=_mul(_numbers(args[-6:]),ctm)
                elif op=='m' and len(args)>=2:
                    if current:subpaths.append(current)
                    point=tuple(_numbers(args[-2:]));current=[point];start=point
                elif op=='l' and len(args)>=2 and current:
                    point=tuple(_numbers(args[-2:]));current.append(point)
                elif op in ('c','v','y') and current:
                    n=_numbers(args[-6:] if op=='c' else args[-4:])
                    if op=='c':p1,p2,p3=(n[0],n[1]),(n[2],n[3]),(n[4],n[5])
                    elif op=='v':p1,p2,p3=point,(n[0],n[1]),(n[2],n[3])
                    else:p1,p2,p3=(n[0],n[1]),(n[2],n[3]),(n[2],n[3])
                    span=max(math.dist(point,p1),math.dist(p1,p2),math.dist(p2,p3),math.dist(point,p3))
                    size=span*math.sqrt(abs(ctm[0]*ctm[3]-ctm[1]*ctm[2]))   # millimetres on the page
                    current+=_bezier(point,p1,p2,p3,max(4,min(32,int(size*2))));point=p3
                elif op=='h' and current:
                    current.append(start);point=start
                elif op=='re' and len(args)>=4:
                    if current:subpaths.append(current)
                    x,y,ww,hh=_numbers(args[-4:]);current=[(x,y),(x+ww,y),(x+ww,y+hh),(x,y+hh),(x,y)];subpaths.append(current);current=[];point=(x,y)
                elif op in ('S','s','f','F','f*','B','B*','b','b*'):
                    if op in ('s','b','b*') and current and start:current.append(start)
                    flush(True)
                elif op=='n':flush(False)
                elif op=='Do' and args and isinstance(xobjects,dict):
                    xo=doc.resolve(xobjects.get(str(args[-1])))
                    if isinstance(xo,Stream):
                        kind=xo.dict.get('Subtype')
                        if kind=='Image':images.append(dict(stream=xo,matrix=_mul([1,0,0,1,0,0],ctm)))
                        elif kind=='Form':
                            matrix=_numbers(doc.resolve(xo.dict.get('Matrix',[1,0,0,1,0,0])))
                            try:inner=doc.decode(xo)
                            except PdfError:inner=b''
                            run(inner,xo.dict.get('Resources',resources),_mul(matrix,ctm),depth+1)
                elif op=='BI':
                    end=content.find(b'ID',lex.pos)
                    lex.pos=_skip_inline_image(content,end+2) if end>=0 else len(content)
            except (TypeError,ValueError,IndexError):pass
            args=[]
    contents=doc.resolve(page.get('Contents'))
    streams=contents if isinstance(contents,list) else [contents]
    data_parts=[];failed=None
    for s in streams:
        s=doc.resolve(s)
        if isinstance(s,Stream):
            try:data_parts.append(doc.decode(s))
            except PdfError as exc:failed=exc
    if failed and not data_parts:raise failed   # 0.19.9: nothing of the page readable: say why (not « texte seul »)
    run(b'\n'.join(data_parts),page.get('Resources'),base,0)
    return dict(width=W,height=H,paths=paths,images=[dict(image_data(doc,i['stream']),matrix=i['matrix']) for i in images],doc=doc)


def image_data(doc,stream):
    """What an image XObject holds: a JPEG to decode, or raw pixels (8-bit grey / RGB, 1-bit)."""
    d=stream.dict;w=int(doc.resolve(d.get('Width',0)) or 0);h=int(doc.resolve(d.get('Height',0)) or 0)
    filters=doc.resolve(d.get('Filter'));filters=filters if isinstance(filters,list) else [filters] if filters else []
    names=[str(doc.resolve(f)) for f in filters]
    if names and names[-1] in ('DCTDecode','DCT'):return dict(kind='jpeg',width=w,height=h,data=doc.decode(stream,last=True))
    if names and names[-1] in ('JPXDecode','CCITTFaxDecode','JBIG2Decode'):return dict(kind='unsupported',width=w,height=h,data=b'',filter=names[-1])
    try:raw=doc.decode(stream)
    except PdfError:return dict(kind='unsupported',width=w,height=h,data=b'')
    space=doc.resolve(d.get('ColorSpace'));bits=int(doc.resolve(d.get('BitsPerComponent',8)) or 8)
    if isinstance(space,list) and space and str(space[0])=='ICCBased':
        info=doc.resolve(space[1]);n=int(doc.resolve(info.dict.get('N',3))) if isinstance(info,Stream) else 3
        space='DeviceGray' if n==1 else 'DeviceRGB' if n==3 else 'DeviceCMYK'
    if isinstance(space,list) and space and str(space[0])=='Indexed':
        base,hival,lookup=space[1],space[2],doc.resolve(space[3])
        table=doc.decode(lookup) if isinstance(lookup,Stream) else lookup if isinstance(lookup,bytes) else b''
        base=doc.resolve(base);comps=1 if str(base)=='DeviceGray' else 4 if str(base)=='DeviceCMYK' else 3
        if bits!=8 or comps!=3:return dict(kind='unsupported',width=w,height=h,data=b'')
        table=bytes(table)+bytes(max(0,768-len(table)));index=bytes(raw[:w*h]).ljust(w*h,b'\0')
        rgb=bytearray(w*h*3)
        for k in range(3):rgb[k::3]=index.translate(bytes(table[3*v+k] for v in range(256)))
        return dict(kind='rgb',width=w,height=h,data=bytes(rgb))
    space=str(space)
    if bits==8 and space in ('DeviceRGB','RGB','CalRGB'):return dict(kind='rgb',width=w,height=h,data=raw[:w*h*3])
    if bits==8 and space in ('DeviceGray','G','CalGray'):return dict(kind='gray',width=w,height=h,data=raw[:w*h])
    if bits==1 and space in ('DeviceGray','G','None') or d.get('ImageMask') is True:
        # 1 = white, 0 = black (for a mask: 0 = painted), unless Decode says [1 0].
        row=(w+7)//8;decode=doc.resolve(d.get('Decode'));invert=isinstance(decode,list) and decode[:1]==[1]
        expand=[bytes((0 if invert else 255) if (b>>(7-i))&1 else (255 if invert else 0) for i in range(8)) for b in range(256)]
        grey=b''.join(b''.join(expand[c] for c in raw[y*row:(y+1)*row].ljust(row,b'\xff'))[:w] for y in range(h))
        return dict(kind='gray',width=w,height=h,data=grey)
    return dict(kind='unsupported',width=w,height=h,data=b'')
