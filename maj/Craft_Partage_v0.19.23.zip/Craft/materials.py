"""0.17.0 Matières: the materials archive organised by type, the Matière window filters, the label
written on the piece and the costs of the fiche de coupe.

archives.json keeps its list of names (``materials``) as before; what is known about each material
lives beside it in ``material_info`` (type, épaisseur in tenths of mm, prix au m², taux de chute,
0.18.1 couleur / référence shown on the fiches like Mozart's: « 2024 », « BLANCHE »…).
A material without information is shown as « Autre » and nothing is ever rewritten by force."""
import math
import unicodedata

TYPES=('Cuir','Tissu','Renfort','Gabarit','Autre')
# 0.18.0: « Doublure » became « Tissu » (a lining may be in leather). A material archived before as
# « Doublure » is read as Tissu; the archive itself is not rewritten.
OLD_TYPES={'Doublure':'Tissu'}
WASTE=15.
# Base columns (cad.LABELS): BROUILLON, BASES, DESSUS, DOUBLURES, RENFORTS, AIDES. The lining column
# shows Tissu and Cuir.
COLUMN_TYPES={2:('Cuir',),3:('Tissu','Cuir'),4:('Renfort',),5:('Gabarit',)}
# 0.18.0: the Refente list, in tenths of a millimetre (another value may be typed).
REFENTES=tuple(str(k) for k in range(4,21))


def number(text,low=None,high=None,label='Valeur'):
    """'7' / '7,5' → 7.5; '' → None. Raises ValueError with a short French message."""
    text=str(text if text is not None else '').strip().replace(',','.')
    if not text:return None
    try:value=float(text)
    except ValueError:raise ValueError(f'{label} : nombre attendu.') from None
    if not math.isfinite(value) or (low is not None and value<low) or (high is not None and value>high):
        raise ValueError(f'{label} : {fmt(low)} à {fmt(high)}.' if low is not None and high is not None else f'{label} invalide.')
    return value


def fmt(value):
    """7.0 → '7', 7.5 → '7,5' (French decimal comma)."""
    if value is None:return ''
    return f'{value:.2f}'.rstrip('0').rstrip('.').replace('.',',')


def thickness_label(value):
    return f'{fmt(value)}/10e' if value else ''


def refente_label(value):
    text=fmt(value) if isinstance(value,(int,float)) else str(value or '').strip().replace('.',',')
    return f'refente {text}/10' if text else ''


def label_text(quantity,name,refente=''):
    """The text written on the piece: « 2 VEAU refente 7/10 » or « 2 VEAU »."""
    extra=refente_label(refente)
    return f'{quantity} {name}'+(f' {extra}' if extra else '')


def info(archives,name):
    """What is known about a material, with defaults (type Autre, chute 15 %)."""
    data=(archives or {}).get('material_info',{}).get(name) or {}
    kind=OLD_TYPES.get(data.get('type'),data.get('type'));kind=kind if kind in TYPES else 'Autre'
    color=data.get('color');color=color.strip()[:60] if isinstance(color,str) else ''
    return dict(type=kind,thickness=data.get('thickness'),price=data.get('price'),waste=data.get('waste',WASTE) if data.get('waste') is not None else WASTE,color=color,
                hidden=data.get('hidden') is True)   # 0.19.13: a material « cachée » (Mozart's Cachés)


def describe(archives,name):
    """« Cuir · 7/10e · 45 €/m² · chute 15 % » for the selected line of a list."""
    d=info(archives,name);parts=[d['type']]
    if d['color']:parts.append(d['color'])
    if d['thickness']:parts.append(thickness_label(d['thickness']))
    if d['price'] is not None:parts.append(f'{fmt(d["price"])} €/m²')
    parts.append(f'chute {fmt(d["waste"])} %')
    if d['hidden']:parts.append('cachée')
    return ' · '.join(parts)


def store(archives,name,kind,thickness=None,price=None,waste=WASTE,old_name=None,color=None,hidden=False):
    """Adds or updates a material (rename included) in the archive dict, in place."""
    names=archives.setdefault('materials',[]);table=archives.setdefault('material_info',{})
    if kind not in TYPES:raise ValueError('Type de matière inconnu.')
    if old_name and old_name in names and old_name!=name:
        if name in names:raise ValueError('Cette matière existe déjà.')
        names[names.index(old_name)]=name;table.pop(old_name,None)
    elif name not in names:names.append(name)
    entry=dict(type=kind,waste=WASTE if waste is None else waste)
    if thickness:entry['thickness']=thickness
    if price is not None:entry['price']=price
    if color and str(color).strip():entry['color']=str(color).strip()[:60]
    if hidden:entry['hidden']=True
    table[name]=entry
    return archives


def remove(archives,name):
    if name in archives.get('materials',[]):archives['materials'].remove(name)
    archives.get('material_info',{}).pop(name,None)


def sort_key(text):
    """Alphabetical order without case or accents (É with E)."""
    return ''.join(c for c in unicodedata.normalize('NFD',str(text).casefold()) if unicodedata.category(c)!='Mn')


def sorted_names(names):
    return sorted(names,key=sort_key)


ORDERS=('Nom','Classe','Code')   # 0.19.13: as Mozart's list (classe = type, code = couleur / référence)


def filtered(archives,kinds,hidden=False,search='',order='Nom'):
    """Material names of the ticked types, sorted by name (or by type, or by couleur / référence, then name); 0.19.13:
    the « cachées » only when asked, those containing ``search`` (without case or accents) only."""
    key=sort_key(search.strip())
    names=[n for n in archives.get('materials',[]) if info(archives,n)['type'] in kinds and (hidden or not info(archives,n)['hidden']) and key in sort_key(n)]
    if order=='Classe':return sorted(names,key=lambda n:(TYPES.index(info(archives,n)['type']),sort_key(n)))
    if order=='Code':return sorted(names,key=lambda n:(not info(archives,n)['color'],sort_key(info(archives,n)['color']),sort_key(n)))
    return sorted_names(names)


def column_at(workspace,x):
    """Index of the base column under x (piece centre), None outside the base."""
    if not workspace:return None
    left=workspace.get('origin_x',0.)
    for i,w in enumerate(workspace.get('widths',[])):
        if left<=x<left+w:return i
        left+=w
    return None


def default_kinds(workspace,x):
    """The types ticked when the Matière window opens for a piece centred at x: Dessus → Cuir,
    Doublures → Tissu and Cuir, Renforts → Renfort, Aides → Gabarit, elsewhere every type."""
    from cad import column_types   # 0.19.13: what the base's column holds (bases libres)
    kinds=column_types(workspace,column_at(workspace,x)) if x is not None and workspace else None
    return set(kinds) if kinds else set(TYPES)


def has_refente(archives,name):
    """0.18.0: a Tissu is not split (no Refente); any other or unknown material may be."""
    return not (name in (archives or {}).get('materials',[]) and info(archives,name)['type']=='Tissu')


def next_match(values,char,current=None):
    """Letter jump in a list: the first value starting with ``char``, or the next one after
    ``current`` when it already starts with it (a second press goes to the next word)."""
    key=sort_key(char)
    if not key:return None
    hits=[i for i,v in enumerate(values) if sort_key(v).startswith(key)]
    if not hits:return None
    if current is not None and current in hits:
        later=[i for i in hits if i>current]
        return later[0] if later else hits[0]
    return hits[0]


def bind_letter_jump(box,on_pick=None):
    """A key pressed in the list goes to the next word starting with that letter."""
    def jump(e):
        if not e.char or not e.char.isprintable() or e.char.isspace() or e.state & 0x4:return None
        values=list(box.get(0,'end'));sel=box.curselection();i=next_match(values,e.char,sel[0] if sel else None)
        if i is None:return 'break'
        box.selection_clear(0,'end');box.selection_set(i);box.activate(i);box.see(i)
        if on_pick:on_pick(i)
        else:box.event_generate('<<ListboxSelect>>')
        return 'break'
    box.bind('<KeyPress>',jump,add='+')
    return jump


# --- Fiche de coupe ------------------------------------------------------------------------

def surface_mm2(s):
    """Surface of a piece: its outer contour (holes are NOT deducted, as asked)."""
    from geometry import path
    pts,_=path(s)
    if len(pts)<3:return 0.
    return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1])))/2


def cost(surface_m2,quantity,price,waste):
    """surface × quantité × prix/m² × (1 + chute %); None without a price."""
    if price is None:return None
    return surface_m2*quantity*price*(1+(waste or 0)/100)
