"""0.18.1 « Précoupe / surcoupe en série » (Préparations group): the piece is asked first (a click
in it, its ID unique number typed, or the piece already selected), then the window: colonnes, rangées, écart (the same between
the pieces and at the edge), forme (rectangle, or the contours moved out by the écart).
The précoupe replaces the piece where it is (see surcoupe.make_precut)."""
import tkinter as tk
from tkinter import messagebox
import surcoupe as sc


def start(app, simple=False):
    from entity_rules import closed_piece
    from craft_tools import style
    chosen = [i for i in app.selected_ids() if i < len(app.items) and closed_piece(app.items[i]) and style(app.items[i])['role'] == 'external'
              and not sc.is_precut(app.items[i])]
    app.finish_action()
    app.cancel()
    app.tool.set('surcoupe')
    app.last_command = ('tool', 'surcoupe_simple' if simple else 'surcoupe')
    app.selected = None
    app.selected_set = set()
    app.surcoupe_state = dict(piece=None, simple=simple)
    app.highlight_tools()
    app.refresh()
    if len(chosen) == 1:
        return choose(app, chosen[0])
    app.status.set(('Précoupe simple : choisir' if simple else 'Choisir') + ' la pièce à surcouper : clic dans la pièce, ou son n° d’ID unique puis Entrée.')
    return None


def cancel(app):
    app.surcoupe_state = None


def click(app, e):
    import piece_ids
    if app.__dict__.get('surcoupe_state') is None:
        return None
    i = piece_ids.host_at(app.items, app.raw(e))
    if i is None:
        app.invalid_at(e, 'Cliquer dans une pièce fermée en Coupe externe.')
        return None
    if sc.is_precut(app.items[i]):
        app.invalid_at(e, 'Cette pièce est déjà une précoupe.')
        return None
    return choose(app, i)


def enter(app):
    """Entrée: the piece whose ID unique number was typed."""
    import piece_ids
    from entity_rules import closed_piece
    from craft_tools import style
    text = app.command_value.get().strip()
    app.command_value.set('')
    try:
        app.command_entry.place_forget()
    except (AttributeError, tk.TclError):
        pass
    app.canvas.focus_set()
    if not text:
        return 'break'
    try:
        n = int(text)
    except ValueError:
        app.status.set('Taper le n° d’ID unique de la pièce, puis Entrée.')
        return 'break'
    owner = next((o for o, k in piece_ids.numbers(app.items).items() if k == n), None)
    i = next((k for k, s in enumerate(app.items) if owner and s.get('piece_id') == owner and closed_piece(s) and style(s)['role'] == 'external'), None)
    if i is None:
        app.status.set(f'Aucune pièce n° {n}.')
        return 'break'
    if sc.is_precut(app.items[i]):
        app.status.set('Cette pièce est déjà une précoupe.')
        return 'break'
    choose(app, i)
    return 'break'


def choose(app, i):
    """0.19.11 « Précoupe simple »: one piece, at once, with the écart and the forme of the last précoupe (no window);
    the series asks its window."""
    if not (app.__dict__.get('surcoupe_state') or {}).get('simple'):
        return dialog(app, i)
    saved = app.prefs.get('precut') or {}
    try:
        gap = float(saved.get('gap', 5.))
        new, k = sc.make_precut(app.items, i, 1, 1, gap, bool(saved.get('follow', False)))
    except (ValueError, TypeError) as exc:
        messagebox.showerror('Précoupe simple', str(exc), parent=app)
        return None
    app.snapshot()
    app.items = new
    app.surcoupe_state = None
    app.complete_command('surcoupe')
    app.selected = k
    app.selected_set = {k}
    app.highlight_tools()
    app.refresh()
    gap_text = f'{gap:g}'.replace('.', ',')
    app.status.set(f'Précoupe simple : 1 pièce à surcouper, écart {gap_text} mm.')
    app.canvas.focus_set()
    return k


def quantity(app, i):
    """The quantity written on the piece (its Matière label), 1 when there is none."""
    from entity_rules import piece_labels
    try:
        found = piece_labels(app.items, i).get('material')
        data = (app.items[found[0]].get('identification') or {}) if found else {}
        return max(1, int(str(data.get('quantity', '1')).strip() or 1))
    except (ValueError, TypeError, IndexError, KeyError):
        return 1


def dialog(app, i):
    from export_check import piece_name
    app.selected = i
    app.selected_set = {i}
    app.refresh()
    saved = app.prefs.get('precut') or {}
    win = app.dialog('Précoupe en série')
    panel = app.p['panel']
    name = piece_name(app.items, i)
    count = quantity(app, i)
    app.label(win, f'{name} · {count} pièce{"s" if count > 1 else ""} à obtenir').pack(anchor='w', padx=16, pady=(14, 6))
    form = tk.Frame(win, bg=panel)
    form.pack(fill='x', padx=16)
    columns = tk.StringVar(value=str(saved.get('columns', 1)))
    rows = tk.StringVar(value=str(saved.get('rows', 1)))
    gap = tk.StringVar(value=f'{saved.get("gap", 5.):g}'.replace('.', ','))
    follow = tk.BooleanVar(value=bool(saved.get('follow', False)))
    fields = []
    for r, (label, var) in enumerate((('Colonnes', columns), ('Rangées', rows), ('Écart (mm, entre les pièces et au bord)', gap))):
        app.label(form, label).grid(row=r, column=0, sticky='w', pady=3)
        field = app.entry(form, var, 8)
        field.grid(row=r, column=1, sticky='w', padx=8, pady=3)
        fields.append(field)
    options = dict(bg=panel, fg=app.p['ui_ink'], selectcolor=app.field_background(), activebackground=panel, font=('Segoe UI', 10))
    shape = tk.Frame(win, bg=panel)
    shape.pack(fill='x', padx=16, pady=(6, 0))
    app.label(shape, 'Forme').pack(side='left', padx=(0, 10))
    __import__('modern_style').make_radio(shape, text='Rectangle', variable=follow, value=False, **options).pack(side='left')
    __import__('modern_style').make_radio(shape, text='Suit la forme', variable=follow, value=True, **options).pack(side='left', padx=(10, 0))
    info = app.label(win, '')
    info.pack(anchor='w', padx=16, pady=(8, 2))

    def read():
        c = int(columns.get().strip())
        r = int(rows.get().strip())
        g = float(gap.get().strip().replace(',', '.'))
        return c, r, g

    def update(*args):
        try:
            c, r, g = read()
            per = max(1, c * r)
            n = sc.precuts_needed(count, per)
            info.configure(text=f'{per} pièce{"s" if per > 1 else ""} par précoupe · {n} précoupe{"s" if n > 1 else ""} pour {count} pièce{"s" if count > 1 else ""}')
        except ValueError:
            info.configure(text='Nombres entiers pour colonnes et rangées, écart en mm.')
    for var in (columns, rows, gap):
        var.trace_add('write', update)
    update()

    def valid(e=None):
        try:
            c, r, g = read()
            new, k = sc.make_precut(app.items, i, c, r, g, follow.get())
        except ValueError as exc:
            messagebox.showerror('Précoupe en série', str(exc), parent=win)
            return 'break'
        win.destroy()
        app.prefs['precut'] = dict(columns=c, rows=r, gap=g, follow=bool(follow.get()))
        try:
            app.persist_preferences()
        except OSError:
            pass
        app.snapshot()
        app.items = new
        app.surcoupe_state = None
        app.complete_command('surcoupe')
        app.selected = k
        app.selected_set = {k}
        app.highlight_tools()
        app.refresh()
        per = c * r
        gap_text = f'{g:g}'.replace('.', ',')
        app.status.set(f'Précoupe : {per} pièce{"s" if per > 1 else ""} à surcouper, écart {gap_text} mm.')
        app.canvas.focus_set()
        return 'break'

    def close(e=None):
        win.destroy()
        app.cancel()
        app.canvas.focus_set()
    end = tk.Frame(win, bg=panel)
    end.pack(fill='x', padx=16, pady=(8, 14))
    app.button(end, 'Annuler', close).pack(side='right')
    app.button(end, 'Valider', valid).pack(side='right', padx=6)
    win.bind('<Return>', valid)
    win.bind('<Escape>', close)
    fields[0].focus_set()
    fields[0].select_range(0, 'end')
    win._precut = dict(columns=columns, rows=rows, gap=gap, follow=follow, valid=valid, info=info)
    return win
