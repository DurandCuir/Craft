"""Editable interpolating cubic splines and lossless contour editing (stdlib only)."""
import copy,math
from functools import lru_cache
from cad import polygon,shape,project
from geometry import distance,path,clone
EPS=1e-7

def bezier(c,t):
 u=1-t
 return tuple(u**3*c[0][k]+3*u*u*t*c[1][k]+3*u*t*t*c[2][k]+t**3*c[3][k] for k in (0,1))

def derivative(c,t):
 return tuple(3*((1-t)**2*(c[1][k]-c[0][k])+2*(1-t)*t*(c[2][k]-c[1][k])+t*t*(c[3][k]-c[2][k])) for k in (0,1))

def split(c,t):
 def mix(a,b):return tuple((1-t)*x+t*y for x,y in zip(a,b))
 a,b,d=[mix(x,y) for x,y in zip(c,c[1:])];e,f=mix(a,b),mix(b,d);g=mix(e,f)
 return [c[0],a,e,g],[g,f,d,c[3]]

def subcurve(c,a,b):
 first=split(c,b)[0]
 return split(first,a/b)[1] if a>0 else first

def _tridiagonal(a,b,c,r):
 """Thomas: a below the diagonal (a[0] unused), b on it, c above (c[-1] unused)."""
 n=len(b);cc=[0.]*n;rr=[0.]*n;m=b[0];cc[0]=c[0]/m if n>1 else 0.;rr[0]=r[0]/m
 for i in range(1,n):
  m=b[i]-a[i]*cc[i-1];cc[i]=c[i]/m if i<n-1 else 0.;rr[i]=(r[i]-a[i]*rr[i-1])/m
 x=[0.]*n;x[-1]=rr[-1]
 for i in range(n-2,-1,-1):x[i]=rr[i]-cc[i]*x[i+1]
 return x

def _cyclic(a,b,c,r):
 """The same with the corners of a closed curve: a[0] (row 0, last column), c[-1] (last row, column 0)."""
 n=len(b);alpha,beta=c[-1],a[0];gamma=-b[0];bb=list(b);bb[0]=b[0]-gamma;bb[-1]=b[-1]-alpha*beta/gamma
 x=_tridiagonal(a,bb,c,r);u=[0.]*n;u[0]=gamma;u[-1]=alpha;z=_tridiagonal(a,bb,c,u)
 f=(x[0]+beta*x[-1]/gamma)/(1+z[0]+beta*z[-1]/gamma)
 return [x[i]-f*z[i] for i in range(n)]

def spline(points,closed=False,name='Spline',tangents=None):
 """0.19.7 « on voit trop le point d'ancrage milieu alors que ça devrait se lisser »: through the points
 with a continuous curvature, like AutoCAD (C2, parameters by chord length; open: free ends, or the
 start / end tangent when one is set; closed: periodic). Before, the tangent at each point was an average
 of its neighbours' directions: the curvature jumped at the points (a knee where the curve turns over)."""
 pts=[tuple(p) for p in points]
 if len(pts)<2 or (closed and len(pts)<3):raise ValueError('Choisissez au moins deux points, trois pour fermer.')
 if any(math.dist(a,b)<1e-6 for a,b in zip(pts,pts[1:]+pts[:1] if closed else pts[1:])):raise ValueError('Deux points consécutifs se confondent.')
 n=len(pts);m=n if closed else n-1;h=[math.dist(pts[i],pts[(i+1)%n]) for i in range(m)]
 fixed={}
 if tangents and not closed:
  for key,vec in tangents.items():
   norm=math.hypot(*vec)
   if norm>EPS:fixed[0 if key=='start' else n-1]=tuple(x/norm for x in vec)
 a=[0.]*n;b=[0.]*n;c=[0.]*n;rows=[None]*n
 for i in range(n):
  if i in fixed:b[i]=1.;rows[i]=fixed[i];continue
  if not closed and i==0:b[i]=2.;c[i]=1.;rows[i]=tuple(3*(pts[1][k]-pts[0][k])/h[0] for k in (0,1));continue
  if not closed and i==n-1:a[i]=1.;b[i]=2.;rows[i]=tuple(3*(pts[i][k]-pts[i-1][k])/h[i-1] for k in (0,1));continue
  before,after=h[(i-1)%n],h[i%m];p,q,r=pts[(i-1)%n],pts[i],pts[(i+1)%n]
  a[i]=after;b[i]=2*(before+after);c[i]=before
  rows[i]=tuple(3*(after*(q[k]-p[k])/before+before*(r[k]-q[k])/after) for k in (0,1))
 solve=_cyclic if closed else _tridiagonal
 xs,ys=solve(a,b,c,[v[0] for v in rows]),solve(a,b,c,[v[1] for v in rows])
 segments=[]
 for i in range(m):
  j=(i+1)%n;p,q,d=pts[i],pts[j],h[i]
  segments.append([p,(p[0]+xs[i]*d/3,p[1]+ys[i]*d/3),(q[0]-xs[j]*d/3,q[1]-ys[j]*d/3),q])
 s=from_cubics(segments,closed,name);s['spline']['fit']=[[p[0]-s['x'],p[1]-s['y']] for p in pts]
 if tangents:s['spline']['tangents']=copy.deepcopy(tangents)
 return s

def from_cubics(segments,closed=False,name='Spline'):
 origin=segments[0][0];s=polygon([origin,segments[-1][-1]],name,closed)
 s['spline']={'segments':[[[p[0]-origin[0],p[1]-origin[1]] for p in c] for c in segments]}
 flat=[p for c in segments for p in c];s['w']=max(p[0] for p in flat)-min(p[0] for p in flat);s['h']=max(p[1] for p in flat)-min(p[1] for p in flat)
 return s

def cubics(s):return [[(s['x']+p[0],s['y']+p[1]) for p in c] for c in s['spline']['segments']]

def flatten(c,tol=.003,depth=0):
 if depth>=20 or max(distance(p,c[0],c[3]) for p in c[1:3])<=tol:return [c[0],c[3]]
 a,b=split(c,.5);return flatten(a,tol,depth+1)[:-1]+flatten(b,tol,depth+1)

def spline_path(s,tol=.003):
 out=[]
 for c in cubics(s):out+=flatten(c,tol)[:-1]
 if not s.get('closed'):out.append(cubics(s)[-1][-1])
 return out,bool(s.get('closed'))

def cubic_length(c,t=1):return _cubic_length(tuple(tuple(p) for p in c),t)

@lru_cache(maxsize=32768)
def _cubic_length(c,t):
 from precision_geometry import integral
 return integral(lambda v:math.hypot(*derivative(c,v)),0,t,tol=1e-7)

def spline_length(s):return sum(cubic_length(c) for c in cubics(s))

def cubic_location(c,p):
 samples=[math.dist(bezier(c,i/64),p) for i in range(65)];candidates=[0.,1.]
 # 0.19.7: the first and last samples too (a nearest point just before an end was taken as the end itself).
 for i in range(65):
  if i>0 and samples[i]>samples[i-1] or i<64 and samples[i]>samples[i+1]:continue
  lo,hi=max(0,i-1)/64,min(64,i+1)/64
  for _ in range(40):
   u=lo+(hi-lo)/3;v=hi-(hi-lo)/3
   if math.dist(bezier(c,u),p)<math.dist(bezier(c,v),p):hi=v
   else:lo=u
  candidates.append((lo+hi)/2)
 t=min(candidates,key=lambda t:math.dist(bezier(c,t),p));return t,bezier(c,t)

def spline_location(s,p):
 travel=0;options=[]
 for c in cubics(s):
  t,q=cubic_location(c,p);options.append((math.dist(p,q),travel+cubic_length(c,t),q));travel+=cubic_length(c)
 _,d,q=min(options);return d,q

def cubic_fraction(c,d):
 lo,hi=0.,1.
 for _ in range(32):
  m=(lo+hi)/2
  if cubic_length(c,m)<d:lo=m
  else:hi=m
 return (lo+hi)/2

def spline_slice(s,start,end):
 total=spline_length(s);out=[]
 for cycle in range(2 if end>total+EPS else 1):
  travel=total*cycle
  for c in cubics(s):
   n=cubic_length(c);a=max(0,start-travel);b=min(n,end-travel)
   # 0.19.7: a curve's own ends exactly (the far end of a spline cut by a raccord stayed where it was)
   if b-a>EPS:out.append(subcurve(c,0. if a<=EPS else cubic_fraction(c,a),1. if b>=n-EPS else cubic_fraction(c,b)))
   travel+=n
 if not out:raise ValueError('Portion trop courte.')
 from editing import inherit
 return inherit(from_cubics(out,False,s['name']),s)

def arc(center,r,start,sweep,name='Arc'):
 if r<=EPS or abs(sweep)<EPS or abs(sweep)>2*math.pi+EPS:raise ValueError('Arc invalide.')
 count=max(1,math.ceil(abs(sweep)/(math.pi/2)));pts=[(center[0]+r*math.cos(start+sweep*i/count),center[1]+r*math.sin(start+sweep*i/count)) for i in range(count+1)]
 s=polygon(pts,name,False);s['bulges']=[math.tan(sweep/count/4)]*count+[0.];return s

def arc_three(a,b,c):
 from cad import circle_three,circle_data
 center,r=circle_data(circle_three(a,b,c));A,B,C=[math.atan2(p[1]-center[1],p[0]-center[0]) for p in (a,b,c)];sweep=(C-A)%(2*math.pi)
 if (B-A)%(2*math.pi)>sweep:sweep-=2*math.pi
 return arc(center,r,A,sweep)

def bulge_arc(a,b,p):
 """0.16.29 « Arc : départ, fin et bombé »: through a and b, its middle at the pointer's
 distance from the chord, on the pointer's side."""
 chord=math.dist(a,b)
 if chord<EPS:raise ValueError('Choisir une fin différente du départ.')
 ux,uy=(b[0]-a[0])/chord,(b[1]-a[1])/chord;s=(p[0]-a[0])*-uy+(p[1]-a[1])*ux
 if abs(s)<max(EPS,chord*1e-4):raise ValueError('Écarter la souris du trait pour bomber l’arc.')
 return arc_three(a,((a[0]+b[0])/2-uy*s,(a[1]+b[1])/2+ux*s),b)

def pointer_side(a,b,p):
 """Side of the chord a-b where the pointer is, as the side argument of arc_radius."""
 return -1 if (b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])>0 else 1

def arc_radius(a,b,r,side=1):
 chord=math.dist(a,b)
 if chord<EPS or r<chord/2-EPS:raise ValueError('Le rayon doit être au moins égal à la moitié de la corde.')
 h=math.sqrt(max(0,r*r-chord*chord/4));c=((a[0]+b[0])/2-side*(b[1]-a[1])*h/chord,(a[1]+b[1])/2+side*(b[0]-a[0])*h/chord)
 A=math.atan2(a[1]-c[1],a[0]-c[0]);B=math.atan2(b[1]-c[1],b[0]-c[0]);sweep=(B-A)%(2*math.pi)
 if sweep>math.pi:sweep-=2*math.pi
 if h<EPS:sweep=side*math.pi   # 0.19.9: a half circle (r = half the chord) goes on the pointer side too
 return arc(c,r,A,sweep)

def parts(s):
 result=[]
 for child in s['components']:   # 0.19.18: fast copies (clone)
  q=clone(child);q['x']+=s['x'];q['y']+=s['y']
  if 'style' in s and 'style' not in q:q['style']=clone(s['style'])
  result.append(q)
 return result

def parts_view(s):
    """0.17.0: the children of a compound for DISPLAY only (crans are compounds): plain copies
    instead of deep copies at every redraw. Never modify what this returns."""
    out=[]
    for child in s['components']:
        q=dict(child);q['x']=child['x']+s['x'];q['y']=child['y']+s['y']
        if 'style' in s and 'style' not in q:q['style']=s['style']
        out.append(q)
    return out

def compound(items,name=None,closed=False):
 # 0.19.16: clone (marshal) instead of copy.deepcopy: each cran is built through here (reading DIFORME: 712 copies)
 if len(items)==1:return clone(items[0])
 flat=[q for s in items for q in (parts(s) if s.get('components') else [s])];origin=path(flat[0])[0][0];s=polygon([origin,path(flat[-1])[0][-1]],name or items[0]['name'],closed)
 s['components']=[]
 for q in clone(flat):
  q['x']-=origin[0];q['y']-=origin[1];q.pop('notches',None);s['components'].append(q)
 return s

def reverse(s):
 q=copy.deepcopy(s)
 if s.get('spline'):return from_cubics([list(reversed(c)) for c in reversed(cubics(s))],s.get('closed',False),s['name'])
 if s.get('components'):return compound([reverse(c) for c in reversed(parts(s))],s['name'],s.get('closed',False))
 if s.get('ellipse'):
  q['reversed']=not q.get('reversed',False);return q
 if s['kind']=='line':q.update(x=s['x']+s['w'],y=s['y']+s['h'],w=-s['w'],h=-s['h']);return q
 from precision_geometry import canonical
 q=canonical(s);pts=[(q['x']+x,q['y']+y) for x,y in q['points']];bs=q.get('bulges',[0.]*len(pts));out=polygon(list(reversed(pts)),s['name'],q.get('closed',False));out['bulges']=[-bs[len(bs)-2-i] if i<len(bs)-1 else 0. for i in range(len(bs))];return out

def join(items,tolerance=.02):
 items=[s for s in items if __import__('entity_rules').geometry_entity(s)]
 from editing import inherit
 if len(items)<2:raise ValueError('Sélectionnez au moins deux tracés ouverts.')
 ends=[]
 for s in items:
  pts,closed=path(s)
  if closed or s.get('annotation') or s.get('drill') or s.get('notches'):raise ValueError('Joignez des tracés ouverts avant de poser les crans.')
  ends += [pts[0],pts[-1]]
 if any(sum(math.dist(p,q)<=tolerance for q in ends)>2 for p in ends):raise ValueError('Jonction ambiguë.')
 remaining=list(items[1:]);chain=[items[0]]
 while remaining:
  a,b=path(chain[0])[0][0],path(chain[-1])[0][-1]
  for i,s in enumerate(remaining):
   c,d=path(s)[0][0],path(s)[0][-1]
   if math.dist(b,c)<=tolerance:chain.append(s)
   elif math.dist(b,d)<=tolerance:chain.append(reverse(s))
   elif math.dist(a,d)<=tolerance:chain.insert(0,s)
   elif math.dist(a,c)<=tolerance:chain.insert(0,reverse(s))
   else:continue
   remaining.pop(i);break
  else:raise ValueError('Les extrémités ne se rejoignent pas (tolérance 0,02 mm).')
 closed=math.dist(path(chain[0])[0][0],path(chain[-1])[0][-1])<=tolerance
 return inherit(compound(chain,items[0]['name'],closed),items[0])

def _decompose(s):
 from editing import inherit
 from precision_geometry import contour_length,contour_slice,primitives,without_micro,MICRO
 if not __import__('entity_rules').geometry_entity(s):raise ValueError('Sélectionner ligne/polyligne')
 s=without_micro(s)
 if s.get('components'):return [q for q in parts(s) if contour_length(q)>MICRO] or parts(s)
 if s.get('ellipse') or s['kind']=='circle':
  total=contour_length(s);count=4 if path(s)[1] else 1
  return [contour_slice(s,total*i/count,total*(i+1)/count) for i in range(count)]
 if s.get('spline'):return [inherit(from_cubics([c],False,s['name']),s) for c in cubics(s)]
 result=[];travel=0
 for q in primitives(s):
  item=contour_slice(s,travel,travel+q['length']);travel+=q['length']
  if not q['sweep']:item=inherit(shape('line',s['name'],*q['a'],q['b'][0]-q['a'][0],q['b'][1]-q['a'][1]),s)
  result.append(item)
 return result

def marks_on(s,pieces,reach=None):
 """0.19.9: the crans of ``s`` put back on ``pieces``, parts of its contour (Couper, Décomposer, a raccord's sides),
 each at its point. They are measured along the drawn contour from where it is drawn; contour_slice measured them
 from where the exact contour starts (a rounded rectangle's moved ~24 mm, a closed oval turned over's ~1 mm, some
 went past the end of their piece). A cran goes on ONE piece through its point (at a joint, the one it is drawn the
 same way on), same side (turned over only where that piece runs the other way). ``reach``: a cran farther than that
 from every piece (on a part cut away) goes; None: on the nearest piece."""
 import bisect
 from cad import project
 from craft_tools import segments
 marks=s.get('notches') or []
 if not marks:return pieces
 def table(q):
  # its sides (craft_tools.segments) with where each ends along q, and in runs of 32 with their box: at() and near()
  # below go along the sides near a point only (along the whole contour for each cran, Couper's preview took 0.1 s at
  # each move over a piece of 2 000 points with 40 crans)
  rows=[];ends=[];t=0.
  for a,b in segments(q):n=math.dist(a,b);rows.append((a,b,n,t));t+=n;ends.append(t)
  runs=[]
  for k in range(0,len(rows),32):
   part=rows[k:k+32];xs=[v for a,b,_,_ in part for v in (a[0],b[0])];ys=[v for a,b,_,_ in part for v in (a[1],b[1])]
   runs.append((min(xs),min(ys),max(xs),max(ys),part))
  return (rows,ends,t,runs,path(q)[1]) if t>=1e-8 and any(r[2]>=1e-9 for r in rows) else None
 def at(T,d):
  # craft_tools.at_distance: the point at d along the contour and the left normal of its side (the one before a corner)
  rows,ends,t,_,closed=T;d=d%t if closed else max(0.,min(d,t));k=bisect.bisect_left(ends,d-1e-8)
  while k<len(rows) and rows[k][2]<1e-9:k+=1
  if k==len(rows):k=max(j for j,r in enumerate(rows) if r[2]>=1e-9);d=ends[k]
  a,b,n,start=rows[k];u=(d-start)/n
  return (a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u),(-(b[1]-a[1])/n,(b[0]-a[0])/n)
 def near(T,P):
  # craft_tools.locate: the nearest point (on the first of equally near sides) and its distance along the contour; the
  # runs farther than a point already found are passed
  gap=lambda r:math.hypot(max(r[0]-P[0],0.,P[0]-r[2]),max(r[1]-P[1],0.,P[1]-r[3]))
  bound=min(math.dist(project(P,a,b),P) for a,b,_,_ in min(T[3],key=gap)[4])+1e-9;best=None
  for r in T[3]:
   if gap(r)>bound:continue
   for a,b,_,start in r[4]:
    x=project(P,a,b);g=math.dist(x,P)
    if best is None or g<best[0]:best=(g,start+math.dist(a,x),x)
  return best[1],best[2]
 S=table(s)
 if S is None:return pieces
 tables=[]
 for q in pieces:q.pop('notches',None);tables.append(table(q))
 boxes=[(min(r[0] for r in T[3])-.02,min(r[1] for r in T[3])-.02,max(r[2] for r in T[3])+.02,max(r[3] for r in T[3])+.02) if T else None for T in tables]
 def placed(P,n0,js):
  best=None
  for j in js:
   T=tables[j]
   if T is None:continue
   d,foot=near(T,P);n1=at(T,d)[1]
   if abs(n0[0]*n1[0]+n0[1]*n1[1])<.9:
    # at a corner inside a piece a cran is drawn on the side before it; a hair on, on the side after (as at the start
    # of a closed contour)
    e=min(d+1e-6,T[2]);n2=at(T,e)[1]
    if abs(n0[0]*n2[0]+n0[1]*n2[1])>.9:d,n1=e,n2
   gap=math.dist(foot,P);dot=n0[0]*n1[0]+n0[1]*n1[1];key=(gap<=.02 and abs(dot)>.9,-round(gap,6),abs(dot))
   if best is None or key>best[0]:best=(key,j,d,dot,gap)
  return best
 for mark in marks:
  P,n0=at(S,mark['distance'])
  # only the pieces whose box is near its point are measured
  best=placed(P,n0,[j for j,b in enumerate(boxes) if b and b[0]<=P[0]<=b[2] and b[1]<=P[1]<=b[3]])
  if reach is None and (best is None or best[4]>.02):best=placed(P,n0,range(len(pieces)))
  if best is None or reach is not None and best[4]>reach:continue
  _,j,d,dot,_=best;m=dict(copy.deepcopy(mark),distance=d)
  if dot<-.5:m['side']=-mark.get('side',1)
  pieces[j].setdefault('notches',[]).append(m)
 return pieces

def decompose(s):
 result=_decompose(s)
 # 0.19.9: the crans at their point (marks_on), not by the exact lengths from the exact start (moved ~24 mm on a
 # rounded rectangle; one at a corner went on the next side, its stem turned).
 if s.get('notches'):marks_on(s,result)
 return result

def trim_stops(s,others,vertices=True):
 """Distances along ``s`` where Couper stops: its crossings with ``others``; 0.18.5: also the ends
 of the others lying on it (a raccord only touching it, tangent, cuts it there) and, with
 ``vertices``, every vertex between two different pieces of its drawing (line / arc, arcs of
 different circles) even when they meet tangentially, never between two parts of one line or one
 circle (precision_geometry.piece_stops)."""
 from cad import intersections
 from geometry import boxes_apart
 from precision_geometry import contour_length,contour_location,piece_stops,open_ends,without_micro
 s=without_micro(s);total=contour_length(s);closed=path(s)[1];cuts=[]
 for other in others:
  if not __import__('entity_rules').geometry_entity(other) or boxes_apart(s,other):continue
  cuts += [contour_location(s,q)[0] for q in intersections(s,other)]
  for q in open_ends(other):
   d,pt=contour_location(s,q)
   if math.dist(pt,q)<=1e-3:cuts.append(d)
 if vertices and not(s.get('spline') or s.get('ellipse') or s['kind']=='circle'):cuts+=piece_stops(s)
 if closed:cuts=[d%total for d in cuts]
 out=[]
 for d in sorted(cuts):
  if closed and (d<1e-7 or total-d<1e-7):d=0.
  if not out or d-out[-1]>1e-7:out.append(d)
 if closed and len(out)>1 and out[0]<1e-7 and total-out[-1]<1e-7:out.pop()
 return out

def trim(s,others,p,vertices=True,fence=None):
 """Couper: what is left of ``s`` (_trim)."""
 # 0.19.9: the crans of the parts kept at their point (marks_on), those of the part that goes with it (one on a
 # part kept was lost or moved on a rounded rectangle or an oval turned over).
 out=_trim(s,others,p,vertices,fence)
 return marks_on(s,out,.02) if s.get('notches') else out

def _trim(s,others,p,vertices=True,fence=None):
 if not __import__('entity_rules').geometry_entity(s):raise ValueError('Sélectionner ligne/polyligne')
 from precision_geometry import contour_length,contour_location,contour_slice
 from editing import inherit
 from precision_geometry import without_micro
 s=without_micro(s);total=contour_length(s);at=contour_location(s,p)[0];closed=path(s)[1]
 # 0.18.5 (n° 32): a polyline drawn with tangent pieces (rounds, raccords, straight sides) is cut
 # piece by piece, never all at once.
 cuts=trim_stops(s,others,vertices)
 if not cuts and fence:
  ds=sorted(set(round(contour_location(s,q)[0]%total if closed else contour_location(s,q)[0],7) for q in fence))
  if not closed:
   if len(ds)<2:return []
   return ([contour_slice(s,0,ds[0])] if ds[0]>EPS else [])+([contour_slice(s,ds[-1],total)] if ds[-1]<total-EPS else [])
  if len(ds)==1:return [inherit(contour_slice(s,ds[0],ds[0]+total),s)]
  if len(ds)>1:
   gaps=[((ds[(i+1)%len(ds)]-d)%total,d) for i,d in enumerate(ds)];gap,lo=min(gaps);begin=(lo+gap)%total;return [inherit(contour_slice(s,begin,begin+total-gap),s)]
 if not cuts:return []
 if closed:
  if len(cuts)==1:return [inherit(contour_slice(s,cuts[0],cuts[0]+total),s)]
  lo=max((d for d in cuts if d<=at+EPS),default=cuts[-1]-total);hi=min((d for d in cuts if d>at+EPS),default=cuts[0]+total)
  return [inherit(contour_slice(s,hi%total,hi%total+(total-(hi-lo))),s)]
 # 0.19.9: a click at or past the end is in the last piece (lo and hi were both the end: nothing went).
 cuts=sorted(set([0.,total]+cuts));lo=max((d for d in cuts if d<=at+EPS and d<total-EPS),default=0.);hi=min((d for d in cuts if d>at+EPS),default=total)
 return ([contour_slice(s,0,lo)] if lo>EPS else [])+([contour_slice(s,hi,total)] if hi<total-EPS else [])

def ellipse_line_intersections(s,line):
 e=s['ellipse'];a=e['angle'];ca,sa=math.cos(a),math.sin(a)
 def local(p):
  x,y=p[0]-s['x'],p[1]-s['y'];return (x*ca+y*sa)/e['rx'],(-x*sa+y*ca)/e['ry']
 A,B=path(line)[0];p,q=local(A),local(B);dx,dy=q[0]-p[0],q[1]-p[1];aa=dx*dx+dy*dy;bb=2*(p[0]*dx+p[1]*dy);cc=p[0]**2+p[1]**2-1;disc=bb*bb-4*aa*cc
 if aa<EPS or disc< -1e-10:return []
 out=[]
 for t in set(((-bb-math.sqrt(max(0,disc)))/(2*aa),(-bb+math.sqrt(max(0,disc)))/(2*aa))):
  if not -EPS<=t<=1+EPS:continue
  angle=math.atan2(p[1]+dy*t,p[0]+dx*t)
  if e['sweep']<2*math.pi-1e-7 and (angle-e['start'])%(2*math.pi)>e['sweep']+EPS:continue
  out.append((A[0]+t*(B[0]-A[0]),A[1]+t*(B[1]-A[1])))
 return out

def spline_line_intersections(s,line,box=None):
 A,B=path(line)[0];dx,dy=B[0]-A[0],B[1]-A[1];n=math.hypot(dx,dy)
 if n<EPS:return []
 out=[]
 for c in cubics(s):
  # 0.19.9: with a box (cad.intersections, a snap), only the curves reaching it (a curve stays in the box of its points).
  if box and (min(p[0] for p in c)>box[2] or max(p[0] for p in c)<box[0] or min(p[1] for p in c)>box[3] or max(p[1] for p in c)<box[1]):continue
  # Cubic signed distance: isolate with extrema of its quadratic derivative.
  vs=[(p[0]-A[0])*dy-(p[1]-A[1])*dx for p in c];d=[3*(vs[i+1]-vs[i]) for i in range(3)];aa=d[0]-2*d[1]+d[2];bb=2*(d[1]-d[0]);cc=d[0];roots=[]
  if abs(aa)<1e-12:
   if abs(bb)>1e-12:roots=[-cc/bb]
  elif bb*bb-4*aa*cc>=0:roots=[(-bb+sign*math.sqrt(bb*bb-4*aa*cc))/(2*aa) for sign in (-1,1)]
  steps=sorted([0.,1.]+[t for t in roots if 0<t<1])
  def f(t):u=1-t;return u**3*vs[0]+3*u*u*t*vs[1]+3*u*t*t*vs[2]+t**3*vs[3]
  ts=[t for t in steps if abs(f(t))<1e-8]
  for lo,hi in zip(steps,steps[1:]):
   flo,fhi=f(lo),f(hi)
   if flo*fhi>=0:continue
   for _ in range(42):
    m=(lo+hi)/2;fm=f(m)
    if flo*fm<=0:hi=m
    else:lo=m;flo=fm
   ts.append((lo+hi)/2)
  for t in ts:
   q=bezier(c,t);v=((q[0]-A[0])*dx+(q[1]-A[1])*dy)/(n*n)
   if -EPS<=v<=1+EPS and not any(math.dist(q,p)<1e-6 for p in out):out.append(q)
 return out


def removed_portions(original,remaining):
 """Exact complement of retained arclength intervals, shared by edit previews."""
 from precision_geometry import contour_length,contour_location,contour_slice
 total=contour_length(original);closed=path(original)[1];intervals=[]
 if total<EPS:return []
 for fragment in remaining:
  length=contour_length(fragment)
  if length>=total-1e-5:return []
  begin=contour_location(original,path(fragment)[0][0])[0];end=begin+length
  if closed and end>total+1e-6:intervals.extend([(begin,total),(0,end-total)])
  else:intervals.append((max(0,begin),min(total,end)))
 result=[];cursor=0
 for begin,end in sorted(intervals):
  if begin-cursor>1e-5:result.append(contour_slice(original,cursor,begin))
  cursor=max(cursor,end)
 if total-cursor>1e-5:result.append(contour_slice(original,cursor,total))
 return result
