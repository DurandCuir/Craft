"""Native circular grips and tangent offsets, without display tessellation edits."""
import copy,heapq,math
from itertools import repeat
from geometry import path,distance
from cad import polygon
from curves import arc_three,parts,compound
from precision_geometry import canonical,primitives,at_primitive,ellipse_point
from editing import inherit

def circular_edges(s):
    if not __import__('entity_rules').geometry_entity(s) or s.get('spline') or s.get('ellipse'):return []
    children=parts(s) if s.get('components') else [s];out=[]
    for k,child in enumerate(children):
        if child.get('spline') or child.get('ellipse'):continue
        es=primitives(child)
        if not child.get('closed') and len(es)>1 and all(e['sweep'] and math.dist(e['c'],es[0]['c'])<1e-6 and abs(e['r']-es[0]['r'])<1e-6 for e in es):
            e=dict(es[0],b=es[-1]['b'],sweep=sum(e['sweep'] for e in es))
            out.append((k if s.get('components') else None,'whole',e));continue
        # 0.16.28: consecutive pieces of the same arc (arcs are stored in quarter turns) form
        # ONE arc with one middle grip; dragging it reshapes the whole arc through the pointer.
        runs=[]
        for j,e in enumerate(es):
            if not e['sweep']:continue
            last=runs[-1] if runs else None
            if last and last[1]==j-1 and _same_circle(es[last[1]],e):last[1]=j
            else:runs.append([j,j])
        for j0,j1 in runs:
            if j0==j1:out.append((k if s.get('components') else None,j0,es[j0]))
            else:out.append((k if s.get('components') else None,(j0,j1),dict(es[j0],b=es[j1]['b'],sweep=sum(es[j]['sweep'] for j in range(j0,j1+1)))))
    return out

def _same_circle(e,f):
    tol=1e-6+1e-6*max(e['r'],f['r'])
    return math.dist(e['c'],f['c'])<=tol and abs(e['r']-f['r'])<=tol and (e['sweep']>0)==(f['sweep']>0) and math.dist(e['b'],f['a'])<1e-6

def circular_grips(s):
    result=[]
    for k,j,e in circular_edges(s):
        for which,p in [('middle',at_primitive(e,.5)),('center',e['c']),('start',e['a']),('end',e['b'])]:
            # 0.19.9: the centre of a round piece (arcs of one circle all round) moves it like a circle's, crans included
            if which=='center' and k is None and _round(s,j):result.append(('move',p));continue
            result.append((('arc',k,j,which),p))
    return result

def _round(s,run):
    """0.19.9: the run covers a closed polyline all round: arcs of one circle only (Mozart round pieces)."""
    return isinstance(run,tuple) and run[0]==0 and s.get('kind')=='poly' and bool(s.get('closed')) and run[1]==len(primitives(s))-1

def edit_arc(s,mode,p):
    _,component,j,which=mode
    children=parts(s) if s.get('components') else None;source=children[component] if children is not None else s
    if j=='whole':
        es=primitives(source);e=dict(es[0],b=es[-1]['b'],sweep=sum(e['sweep'] for e in es))
        if which=='center':
            out=copy.deepcopy(source);out['x']+=p[0]-e['c'][0];out['y']+=p[1]-e['c'][1]
        else:out=inherit(arc_three(p if which=='start' else e['a'],p if which=='middle' else at_primitive(e,.5),p if which=='end' else e['b']),source)
        if children is None:return out
        children[component]=out;return inherit(compound(children,s['name'],s.get('closed',False)),s)
    q=canonical(source);es=primitives(source)
    if isinstance(j,tuple):out=_edit_run(source,q,es,j,which,p)
    else:out=_edit_piece(source,q,es,j,which,p)
    if children is None:return out
    children[component]=out
    return inherit(compound(children,s['name'],s.get('closed',False)),s)

def _edit_run(source,q,es,run,which,p):
    """Several quarter pieces of one arc edited as one arc (0.16.28)."""
    j0,j1=run;e=dict(es[j0],b=es[j1]['b'],sweep=sum(es[j]['sweep'] for j in range(j0,j1+1)))
    if _round(source,run):return _edit_round(source,e,which,p)   # 0.19.9: a whole circle (its end is its start)
    pts=[(q['x']+x,q['y']+y) for x,y in q['points']];n=len(pts);bs=list(q.get('bulges',[0]*n));end=(j1+1)%n
    if which=='center':
        dx,dy=p[0]-e['c'][0],p[1]-e['c'][1]
        for k in list(range(j0,j1+1))+[end]:pts[k]=(pts[k][0]+dx,pts[k][1]+dy)
        out=inherit(polygon(pts,source['name'],q.get('closed',False)),source);out['bulges']=bs;return out
    a=p if which=='start' else e['a'];b=p if which=='end' else e['b'];middle=p if which=='middle' else at_primitive(e,.5)
    pieces=primitives(arc_three(a,middle,b))
    if not pieces:raise ValueError('Arc impossible : choisissez un autre point.')
    pts[j0]=a;pts[end]=b
    inner=[piece['b'] for piece in pieces[:-1]]
    new_pts=pts[:j0+1]+inner+pts[j1+1:];new_bs=bs[:j0]+[math.tan(piece['sweep']/4) for piece in pieces]+bs[j1+1:]
    out=inherit(polygon(new_pts,source['name'],q.get('closed',False)),source);out['bulges']=new_bs;return out

def _edit_round(source,e,which,p):
    """0.19.9: a round piece edited like a circle: the centre moves it, the other grips set its radius
    (about its centre). It stays the same circle with its name, style, crans and other keys."""
    out=copy.deepcopy(source);c=e['c']
    if which=='center':out['x']+=p[0]-c[0];out['y']+=p[1]-c[1];return out
    r=math.dist(c,p)
    if r<.001:raise ValueError('Rayon trop petit.')
    k=r/e['r'];out.update(x=c[0]+(source['x']-c[0])*k,y=c[1]+(source['y']-c[1])*k,w=source['w']*k,h=source['h']*k,points=[[x*k,y*k] for x,y in source['points']])
    for mark in out.get('notches',[]):mark['distance']*=k   # its crans keep their place on the circle
    return out

def _edit_piece(source,q,es,j,which,p):
    e=es[j]
    if which=='center':
        dx,dy=p[0]-e['c'][0],p[1]-e['c'][1]
        if len(es)==1:
            out=copy.deepcopy(source);out['x']+=dx;out['y']+=dy
        else:
            pts=[(q['x']+x,q['y']+y) for x,y in q['points']];pts[j]=(e['a'][0]+dx,e['a'][1]+dy);pts[(j+1)%len(pts)]=(e['b'][0]+dx,e['b'][1]+dy)
            out=inherit(polygon(pts,source['name'],q.get('closed',False)),source);out['bulges']=list(q.get('bulges',[0]*len(pts)))
    else:
        a=p if which=='start' else e['a'];b=p if which=='end' else e['b'];middle=p if which=='middle' else at_primitive(e,.5)
        replacement=primitives(arc_three(a,middle,b))
        pts=[(q['x']+x,q['y']+y) for x,y in q['points']];pts[j]=a;pts[(j+1)%len(pts)]=b
        bs=list(q.get('bulges',[0]*len(pts)));bs[j]=math.tan(sum(e['sweep'] for e in replacement)/4)
        out=inherit(polygon(pts,source['name'],q.get('closed',False)),source);out['bulges']=bs
    return out

def _frame(s,t,cs=None):
    if s.get('ellipse'):
        e=s['ellipse'];a=e['start']+e['sweep']*t;c,si=math.cos(e['angle']),math.sin(e['angle'])
        point=ellipse_point(s,a);u,v=-e['rx']*math.sin(a)*e['sweep'],e['ry']*math.cos(a)*e['sweep']
        return point,(u*c-v*si,u*si+v*c)
    if s.get('spline'):
        # 0.19.7: a spline, t from 0 to 1 over its curves (an equal share each; beyond: its end curves go on)
        from curves import cubics,bezier,derivative
        if cs is None:cs=cubics(s)   # 0.19.9: or its curves already built by the caller
        m=len(cs);j=min(m-1,max(0,math.floor(t*m)));u=t*m-j;d=derivative(cs[j],u)
        return bezier(cs[j],u),(d[0]*m,d[1]*m)
    if 'sweep' in s and 'a' in s:e=s   # 0.19.7: one piece (the side clicked of a polyline)
    else:
        es=primitives(s);e=es[0]
        if len(es)>1 and all(v['sweep'] and math.dist(v['c'],e['c'])<1e-6 and abs(v['r']-e['r'])<1e-6 for v in es):e=dict(e,b=es[-1]['b'],sweep=sum(v['sweep'] for v in es))
    if not e['sweep']:return (e['a'][0]+(e['b'][0]-e['a'][0])*t,e['a'][1]+(e['b'][1]-e['a'][1])*t),(e['b'][0]-e['a'][0],e['b'][1]-e['a'][1])
    a=e['start']+e['sweep']*t
    return at_primitive(e,t),(-math.sin(a)*e['r']*e['sweep'],math.cos(a)*e['r']*e['sweep'])

def _nearest_pairs(A,B,k):
    """0.19.9: the k nearest pairs (distance, i, j) of points of A and B, in the order of a full sort, without
    sorting all of them: only the rows whose nearest point can be among them are read again."""
    dist=math.dist;near=[min(map(dist,repeat(a),B)) for a in A]
    limit=sorted(near)[k-1] if len(near)>=k else math.inf   # k pairs (one per row) are this near: the k nearest are not farther
    return heapq.nsmallest(k,((d,i,j) for i,a in enumerate(A) if near[i]<=limit for j,d in enumerate(map(dist,repeat(a),B)) if d<=limit))

def tangent_fillet(s,t,p,q,r):
    """Intersect exact normal-offset loci using bounded multistart Newton solves."""
    if r<=0:raise ValueError('Rayon incompatible')
    # 0.19.9: run at each mouse move of the Arrondi preview: a spline's curves are built once per call, not
    # at every point; the offset points of each side once; the 12 seeds found without sorting every pair.
    from curves import cubics
    built={id(v):cubics(v) for v in (s,t) if v.get('spline')}
    def offset(v,a,side):
        point,d=_frame(v,a,built.get(id(v)));n=math.hypot(*d)
        return point[0]-side*r*d[1]/n,point[1]+side*r*d[0]/n
    cross=lambda a,b:a[0]*b[1]-a[1]*b[0]
    def samples(v):
        n=max(24,8*len(v['spline']['segments'])) if v.get('spline') else 24   # 0.19.7: 8 per curve of a spline
        return [i/n for i in range(n+1)]
    result=[];at_s,at_t=samples(s),samples(t)
    As={side:[offset(s,a,side) for a in at_s] for side in (-1,1)};Bs={side:[offset(t,b,side) for b in at_t] for side in (-1,1)}
    for left in (-1,1):
        for right in (-1,1):
            A=As[left];B=Bs[right]
            seeds=_nearest_pairs(A,B,12)
            for _,i,j in seeds:
                u,v=at_s[i],at_t[j]
                for _ in range(24):
                    a,b=offset(s,u,left),offset(t,v,right);f=(a[0]-b[0],a[1]-b[1])
                    if math.hypot(*f)<1e-7:break
                    h=1e-5;aa,ab=offset(s,u+h,left),offset(s,u-h,left);ba,bb=offset(t,v+h,right),offset(t,v-h,right)
                    du=((aa[0]-ab[0])/(2*h),(aa[1]-ab[1])/(2*h));dv=((ba[0]-bb[0])/(2*h),(ba[1]-bb[1])/(2*h));den=cross(du,dv)
                    if abs(den)<1e-12:break
                    x,y=-cross(f,dv)/den,-cross(f,du)/den;factor=max(1,abs(x)/.3,abs(y)/.3);u+=x/factor;v+=y/factor
                    if not(-.3<=u<=1.3 and -.3<=v<=1.3):break
                if not(-1e-6<=u<=1+1e-6 and -1e-6<=v<=1+1e-6):continue
                c,d=offset(s,u,left),offset(t,v,right)
                if math.dist(c,d)>.0001:continue
                a,_=_frame(s,u,built.get(id(s)));b,_=_frame(t,v,built.get(id(t)))
                if math.dist(a,b)<1e-5:continue
                if abs(math.dist(a,c)-r)>.0001 or abs(math.dist(b,c)-r)>.0001:continue
                result.append((math.dist(p,a)+math.dist(q,b),c,a,b))
    if not result:raise ValueError('Rayon incompatible')
    return min(result,key=lambda x:x[0])[1:]
