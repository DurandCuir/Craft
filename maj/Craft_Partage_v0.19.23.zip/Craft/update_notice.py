"""0.16.16: tell the user when a newer Craft has been installed while Craft is open.

The installation writes installed_version.json last, so a newer version number
there means every module is already in place. Nothing is closed automatically:
« Redémarrer » goes through the normal close (which offers to save every
document) and Craft is started again only once it has really closed.
"""
import json
import os
import subprocess
import sys
import tkinter as tk
from pathlib import Path

VERSION_FILE = 'installed_version.json'


def version_key(text):
    try:
        parts = tuple(int(v) for v in str(text).split('.'))
        return parts if len(parts) == 3 else None
    except ValueError:
        return None


def installed_version(folder):
    try:
        return json.loads((Path(folder) / VERSION_FILE).read_text(encoding='utf-8'))['version']
    except (OSError, ValueError, KeyError, TypeError):
        return None


def relaunch_command(folder):
    from app_paths import is_frozen
    return [sys.executable] if is_frozen() else [sys.executable, str(Path(folder) / 'Lancer.pyw')]


def relaunch(folder, document=None):
    command = relaunch_command(folder)
    if document and Path(document).is_file():
        command += ['--reopen', str(document)]
    flags = 0x00000008 | 0x00000200 if os.name == 'nt' else 0  # detached, own process group
    subprocess.Popen(command, cwd=str(folder), close_fds=True, creationflags=flags)


class UpdateNotice:
    def __init__(self, app, folder, running, interval=3000):
        self.app = app
        self.folder = Path(folder)
        self.running = running
        self.interval = interval
        self.stamp = None
        self.announced = None
        self.frame = None
        self.job = app.after(interval, self.poll)

    def poll(self):
        self.job = None
        try:
            path = self.folder / VERSION_FILE
            stamp = path.stat().st_mtime_ns if path.is_file() else None
            if stamp != self.stamp:
                self.stamp = stamp
                version = installed_version(self.folder)
                newer = version_key(version) and version_key(self.running) and version_key(version) > version_key(self.running)
                if newer and version != self.announced:
                    self.show(version)
        except (OSError, tk.TclError):
            pass
        try:
            if self.app.winfo_exists():
                self.job = self.app.after(self.interval, self.poll)
        except tk.TclError:
            pass

    def show(self, version):
        self.hide()
        self.announced = version
        # 0.19.6: the new modules compiled now, in the background (a little at a time): the restart is faster.
        try:
            import threading
            from updater import precompile
            threading.Thread(target=precompile, args=(self.folder, .05), daemon=True).start()
        except Exception:
            pass
        app = self.app
        p = app.p
        frame = tk.Frame(app, bg=p['panel'], highlightthickness=1, highlightbackground=p['accent'], padx=12, pady=10)
        tk.Label(frame, text='Mise à jour disponible', bg=p['panel'], fg=p['ui_ink'], font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        tk.Label(frame, text=f'Craft {version} est installé.\nRedémarrez Craft pour l’utiliser.', justify='left',
                 bg=p['panel'], fg=p['ui_ink'], font=('Segoe UI', 9)).pack(anchor='w', pady=(3, 8))
        row = tk.Frame(frame, bg=p['panel'])
        row.pack(anchor='e')
        app.button(row, 'Plus tard', self.hide).pack(side='left', padx=(0, 6))
        app.button(row, 'Redémarrer', self.restart).pack(side='left')
        frame.place(relx=1, rely=1, x=-18, y=-48, anchor='se')
        frame.lift()
        self.frame = frame

    def hide(self):
        if self.frame is not None:
            try:
                self.frame.destroy()
            except tk.TclError:
                pass
        self.frame = None

    def restart(self):
        """Normal close first (it offers to save); relaunch only if Craft really closed."""
        self.hide()
        app = self.app
        document = getattr(app, 'filename', None)
        app.close()
        try:
            closed = not app.winfo_exists()
        except tk.TclError:
            closed = True
        if closed:
            relaunch(self.folder, document)


def watch(app):
    """Start watching the installed version; None when Craft runs from sources."""
    from app_paths import application_directory
    from craft_version import VERSION
    folder = application_directory()
    if not (folder / VERSION_FILE).is_file():
        return None
    return UpdateNotice(app, folder, VERSION)
