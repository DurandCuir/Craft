"""0.19.13 Poignée toron, after the school's pattern (TILTED « POIGNÉE TORON », Mme Jaminais, read on 07/11:
410 × 75 mm, 2 VACHETTE LISSE BORDEAUX refente 10/10).

The roll is bowed (its middle ``bow`` above its tips), its width the circumference at the leather's middle
(π × (Ø toron + épaisseur)). At each end a notch, an arc of radius ``notch`` tangent to the attache and cutting into
the roll, narrows it to the attache (``tab_width`` × ``tab_length``, from its tip to the root of the notch). The
attache ends:
- « sur anneau »: in an ogive (two arcs of radius ``tip`` meeting on the axis), with the perforations of the return
  sewn by hand round the ring (« les points roses étaient des perfos faits pour coudre à la main le retour sur
  anneau »): ``perfos_tip`` holes on each side towards the tip, the last one at the middle of the attache, and
  ``perfos_notch`` holes on each side from the root of the notch towards the roll; Ø 1 mm, ``distance`` from the
  edge, ``points`` per cm;
- or round, straight or pointed, sewn on the bag: a hand stitch round the attache.
The précoupe (« pied presseur ») is the finished outline + ``precut`` all round, the finished contour inside
(surcoupe.make_precut, as Précoupe simple), or none (« pas forcément de précoupe si c'est un cuir tannage végétal et
qu'il n'y a pas de renfort »). No crans (« inutile les crans »). Pieces named like Mozart's: POIGNÉE TORON × 2,
RENFORT POIGNÉE × 2, ENCHAPE × 4 (with its renfort and doublure if asked).
Everything is built in the handle's own axes: x along it from its first tip, y across (Craft's y, downwards).

0.19.14, after his explanations on TILTED (07/11): the roll is wider than the leather round the toron: π × (Ø +
épaisseur) + 2 × « surcoupe piqûre » (``roll_allowance``, « je recoupe une fois la poignée piquée et montée »,
only along the roll, « seulement au niveau du toron »); the « surcoupe encollage » (``precut``) goes round the whole
piece when a renfort is glued (« si j'encolle cuir avec renfort pour être nickel »). TILTED is a toron of 5 mm with
21,4 mm a side (its 61,6 mm), not a toron of 18,6 mm. The pattes may be wider than the roll (a thin toron): the
arrondi then widens the roll up to the patte. The toron is cut longer than the roll: its biseau goes into each
patte « à peu près jusqu'au point à cheval fait à la main proche de l'anneau » (the middle of the patte).
Words (« on s'y perd avec autant de termes bizarres »): Toron, Roulé, Pattes, Arrondi roulé → patte."""
import math
import uuid

TORON = dict(diameter=5., thickness=1., length=244., roll_allowance=21.4, precut=10., end='ring', tab_length=50.,
             tab_width=20., notch=36.5, tip=24.4, bow=29., points=2.2, distance=3., perfos_tip=4, perfos_notch=6,
             renfort=0., enchape=15., enchape_length=30., enchape_end='point', enchape_renfort=True,
             enchape_doublure=False, ring_gap=0., height=0.)
ALLOWANCE = 10.   # 0.19.14: the surcoupe piqûre of his own handles (« sûrement 10 mm par côté »); TILTED's is 21,4
PROFILE = 'TILTED (lycée)'
ENDS = [('ring', 'Sur anneau (perfos)'), ('round', 'Rondes, cousues'), ('straight', 'Droites, cousues'), ('point', 'Pointues, cousues')]
ENCHAPE_ENDS = [('point', 'Pointu'), ('straight', 'Droit')]
HOLE = 1.
GUIDES = '#e3df32'


def wrap_width(st):
    """The leather round the toron: the circumference at the leather's middle."""
    return math.pi * (st['diameter'] + st['thickness'])


def roll_width(st):
    """The roll as cut: the leather round the toron and the surcoupe piqûre on each side (0.19.14)."""
    return wrap_width(st) + 2 * st.get('roll_allowance', 0.)


def pitch(st):
    return 10. / st['points']


def notch_reach(st):
    """(how far the notch goes along the attache's axis, its arc's angle, the straight bit after it when the roll is
    wider than the arc can reach). 0.19.14: a patte wider than the roll the same way (the arrondi then widens the
    roll up to the patte)."""
    h, r, w = st['tab_width'] / 2, st['notch'], roll_width(st) / 2
    d = abs(w - h)
    if st['tab_length'] <= 0 or d <= 1e-9 or r <= 0:
        return 0., 0., 0.
    if d < r:
        phi = math.acos(1 - d / r)
        return r * math.sin(phi), phi, 0.
    return r, math.pi / 2, d - r


def tip_length(st):
    """From the tip to where the attache's sides start."""
    h = st['tab_width'] / 2
    if st['tab_length'] <= 0:
        return 0.
    if st['end'] == 'ring':
        r = max(st['tip'], h)
        return math.sqrt(r * r - (r - h) ** 2)
    return h if st['end'] in ('round', 'point') else 0.


def total_length(st):
    return 2 * st['tab_length'] + 2 * notch_reach(st)[0] + st['length']


def toron_length(st):
    """0.19.14: the toron to cut for one handle: the roll and, into each patte, its biseau « à peu près jusqu'au point à
    cheval fait à la main proche de l'anneau » (the middle of the patte), from the end of the roll."""
    if st['tab_length'] <= 0:
        return st['length']
    return st['length'] + 2 * (notch_reach(st)[0] + st['tab_length'] / 2)


def length_for_rings(st, gap, height):
    """0.19.13 « Longueur de poignée calculée »: the roll that makes a handle ``height`` mm high between two rings ``gap``
    mm apart (half an ellipse, Ramanujan), at the toron's middle; on rings the attaches are folded at their middle
    and the notches are not rolled, sewn on the bag only the notches are not rolled."""
    a, b = gap / 2, height
    if a <= 0 or b <= 0:
        raise ValueError('Écart entre les anneaux et hauteur : plus de 0 mm.')
    arc = math.pi * (3 * (a + b) - math.sqrt((3 * a + b) * (a + 3 * b))) / 2
    flat = 2 * notch_reach(st)[0] + (st['tab_length'] if st['end'] == 'ring' else 0.)
    if arc - flat <= 5:
        raise ValueError('Poignée trop petite pour ses pattes.')
    return arc - flat


class Band:
    """The handle's geometry in its own axes."""

    def __init__(self, st):
        self.st = st
        self.T = total_length(st)
        self.h = st['tab_width'] / 2
        self.w = roll_width(st) / 2
        self.tab = st['tab_length']
        self.reach, self.phi, self.radial = notch_reach(st)
        self.ell = tip_length(st)
        self.wide = self.h > self.w + 1e-9   # 0.19.14: a patte wider than the roll

    # the middle line: a parabola between the roots of the attaches, the attaches straight and tangent to it (as the
    # school's pattern: its attaches at 13°); ``bow``: the middle's height above the tips; the normal towards +y
    def _bend(self):
        lb = self.T - 2 * self.tab if self.tab > 0 else self.T
        b = self.st['bow'] / (1 + 4 * self.tab / lb) if self.tab > 0 else self.st['bow']
        return lb, b, 4 * b / lb

    def centre(self, x):
        lb, b, k = self._bend()
        u = x - self.T / 2
        if abs(u) <= lb / 2:
            return (x, -(b * (1 - (2 * u / lb) ** 2) + self.tab * k))
        return (x, -k * (x if u < 0 else self.T - x))

    def tangent(self, x):
        lb, b, k = self._bend()
        u = x - self.T / 2
        slope = 8 * b * u / lb ** 2 if abs(u) <= lb / 2 else (-k if u < 0 else k)
        n = math.hypot(1, slope)
        return (1 / n, slope / n)

    def normal(self, x):
        t = self.tangent(x)
        return (-t[1], t[0])

    def edge(self, x, side, off):
        c, n = self.centre(x), self.normal(x)
        return (c[0] + side * off * n[0], c[1] + side * off * n[1])

    def frame(self, end):
        """The straight axes of an attache: (root, u towards the roll, the band's normal there)."""
        x = self.tab if end == 0 else self.T - self.tab
        t = self.tangent(x)
        u = t if end == 0 else (-t[0], -t[1])
        return self.centre(x), u, self.normal(x)

    @staticmethod
    def at(o, u, n, a, off):
        return (o[0] + a * u[0] + off * n[0], o[1] + a * u[1] + off * n[1])

    def notch_centre(self, end, side):
        o, u, n = self.frame(end)
        return self.at(o, u, n, 0., side * (self.h + self.st['notch']))

    def corner(self, end, side):
        """Where the notch meets the roll's edge: its x on the band and the angle reached on the notch's arc."""
        if self.wide or self.reach <= 0:
            return self.tab + self.reach if end == 0 else self.T - self.tab - self.reach
        o, u, n = self.frame(end)
        r = self.st['notch']
        c = self.notch_centre(end, side)
        if self.radial > 0:
            f = lambda x: (self.edge(x, side, self.w)[0] - o[0]) * u[0] + (self.edge(x, side, self.w)[1] - o[1]) * u[1] - r
        else:
            f = lambda x: math.dist(self.edge(x, side, self.w), c) - r
        lo, hi = (self.tab, self.tab + 2.5 * self.reach + 1) if end == 0 else (self.T - self.tab - 2.5 * self.reach - 1, self.T - self.tab)
        a, b = (lo, hi) if f(lo) * f(hi) <= 0 else (lo, lo)
        if a != b:
            for _ in range(60):
                m = (a + b) / 2
                if (f(a) <= 0) == (f(m) <= 0):
                    a = m
                else:
                    b = m
        x = (a + b) / 2 if a != b else (self.tab + self.reach if end == 0 else self.T - self.tab - self.reach)
        return x

    def notch_points(self, end, side, inset=0.):
        """The notch from the root of the attache to the roll (``inset``: the same line that far inside the piece)."""
        if self.reach <= 0:
            return self._step(end, side, inset), 0.
        if self.wide:
            return self._widening(end, side, inset)
        o, u, n = self.frame(end)
        r = self.st['notch']
        c = self.notch_centre(end, side)
        x = self.corner(end, side)
        e = self.edge(x, side, self.w)
        v = (e[0] - c[0], e[1] - c[1])
        far = math.atan2(v[0] * u[0] + v[1] * u[1], -(v[0] * n[0] + v[1] * n[1]) * side)
        if self.radial > 0:
            far = math.pi / 2
        if inset > 0 and r - (self.w - self.h) + inset > 0:
            # 0.19.14: that far inside, the arc ends where it meets the roll's edge that far inside too (it went on
            # beyond, nearer the edge than ``inset``: perfos 2,3 mm from it instead of 3 with a small arrondi)
            far = min(far, math.acos(max(-1., min(1., (r - (self.w - self.h) + inset) / (r + inset)))))
        steps = max(4, int(abs(far) / math.radians(6)) + 1)
        rr = r + inset
        pts = [(c[0] - side * rr * math.cos(far * k / steps) * n[0] + rr * math.sin(far * k / steps) * u[0],
                c[1] - side * rr * math.cos(far * k / steps) * n[1] + rr * math.sin(far * k / steps) * u[1]) for k in range(steps + 1)]
        if inset == 0.:
            if self.radial > 0:
                pts.append(e)
            else:
                pts[-1] = e
        elif self.radial > 0 and far >= math.pi / 2 - 1e-12 and self.w - inset > self.h + r:
            pts.append(self.at(o, u, n, rr, side * (self.w - inset)))   # 0.19.14: along the straight bit, inside too
        return pts, far

    def _step(self, end, side, inset):
        """0.19.14: no arrondi (radius 0, or the patte as wide as the roll): straight from the patte to the roll, across
        the band at the root of the patte; ``inset`` inside the piece: that far into the patte (a wider patte) or into
        the roll (a narrower one)."""
        o, u, n = self.frame(end)
        if inset == 0.:
            e = self.edge(self.corner(end, side), side, self.w)
            start = self.at(o, u, n, 0., side * self.h)
        else:
            a = -inset if self.wide else inset
            start = self.at(o, u, n, a, side * (self.h - inset))
            e = self.at(o, u, n, a, side * (self.w - inset))
        return [start, e] if math.dist(start, e) > 1e-9 else [start]

    def _widening(self, end, side, inset):
        """0.19.14, a patte wider than the roll (thin toron): an arc of the arrondi's radius, tangent to the roll's edge
        where the roll ends, from the patte's side (from its root) to the roll; when the patte is wider than the radius
        can reach, a straight bit along the root first. From the patte to the roll, ``inset`` inside the piece."""
        o, u, n = self.frame(end)
        r, d = self.st['notch'], self.h - self.w
        c = self.at(o, u, n, self.reach, side * (self.w + r))
        rr = r + inset
        pts = []
        if d - r >= inset:   # (that far inside, the straight bit is still there)
            far = math.pi / 2
            pts.append(self.at(o, u, n, -inset, side * (self.h - inset)))
        else:
            far = math.acos(max(-1., min(1., (r - d + inset) / rr)))
        steps = max(4, int(far / math.radians(6)) + 1)
        for k in range(steps + 1):
            a = far * (1 - k / steps)
            pts.append((c[0] - rr * math.sin(a) * u[0] - side * rr * math.cos(a) * n[0],
                        c[1] - rr * math.sin(a) * u[1] - side * rr * math.cos(a) * n[1]))
        if inset == 0.:
            pts[-1] = self.edge(self.corner(end, side), side, self.w)
        return pts, far

    def tip_points(self, end, side, inset=0.):
        """From the start of the attache's side (``side``) to the tip on the axis (or, straight, the end's corner)."""
        o, u, n = self.frame(end)
        h, ell, tab, kind = self.h - inset, self.ell, self.tab, self.st['end']
        if kind == 'ring':
            r = max(self.st['tip'], self.h)
            c = self.at(o, u, n, ell - tab, side * (self.h - r))
            rr = r - inset
            start = self.at(o, u, n, ell - tab, side * h)
            # the tip: where this arc (``inset`` inside) meets the axis
            dy = self.h - r
            reach = math.sqrt(max(0., rr * rr - dy * dy))
            tip = self.at(o, u, n, ell - tab - reach, 0.)
            a0 = math.atan2((start[1] - c[1]), (start[0] - c[0]))
            a1 = math.atan2((tip[1] - c[1]), (tip[0] - c[0]))
            da = (a1 - a0 + math.pi) % (2 * math.pi) - math.pi
            return [(c[0] + rr * math.cos(a0 + da * k / 8), c[1] + rr * math.sin(a0 + da * k / 8)) for k in range(9)]
        if kind == 'round':
            c = self.at(o, u, n, ell - tab, 0.)
            return [self.at(o, u, n, ell - tab - h * math.sin(math.pi / 2 * k / 8), side * h * math.cos(math.pi / 2 * k / 8)) for k in range(9)] if h > 0 else [c]
        if kind == 'point':
            # (``inset`` inside: where the side meets the point's edge, both that far inside)
            return [self.at(o, u, n, ell - tab + inset * (math.sqrt(2) - 1), side * h), self.at(o, u, n, -tab + inset * math.sqrt(2), 0.)]
        return [self.at(o, u, n, -tab + inset, side * h)]

    def side(self, sign):
        """One side of the outline, from the first tip to the second."""
        out = []
        if self.tab > 0:
            o, u, n = self.frame(0)
            out += list(reversed(self.tip_points(0, sign)))[1:] if self.st['end'] != 'straight' else self.tip_points(0, sign)[:1]
            out.append(self.at(o, u, n, 0., sign * self.h))
            out += self.notch_points(0, sign)[0][1:]
            a, b = self.corner(0, sign), self.corner(1, sign)
        else:
            a, b = 0., self.T
        xs = sorted({a, b, self.T / 2} | {a + 2. * k for k in range(int((b - a) / 2.) + 1)})
        out += [self.edge(x, sign, self.w) for x in xs if a - 1e-9 <= x <= b + 1e-9][1 if self.tab > 0 else 0:]
        if self.tab > 0:
            o, u, n = self.frame(1)
            out += list(reversed(self.notch_points(1, sign)[0][:-1]))
            out += self.tip_points(1, sign)[:-1] if self.st['end'] != 'straight' else self.tip_points(1, sign)[:1]
        return out

    def outline(self):
        upper, lower = self.side(-1), self.side(1)
        if self.tab > 0 and self.st['end'] != 'straight':
            tip0 = self.tip_points(0, -1)[-1]
            tip1 = self.tip_points(1, -1)[-1]
            return [tip0] + upper + [tip1] + list(reversed(lower))
        return upper + list(reversed(lower))

    def _walk(self, path, start, step, count):
        """``count`` points every ``step`` mm along ``path`` (a list of points) from ``start`` mm."""
        out, travel, k = [], 0., 0
        want = start
        for a, b in zip(path, path[1:]):
            seg = math.dist(a, b)
            while k < count and travel + seg >= want - 1e-9:
                t = (want - travel) / seg if seg > 1e-12 else 0.
                out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t))
                k += 1
                want += step
            travel += seg
        return out

    def perforations(self):
        """« Sur anneau »: the holes of the return sewn by hand round the ring."""
        st, d = self.st, self.st['distance']
        if self.tab <= 0 or st['end'] != 'ring' or self.h <= d:
            return []
        p, out = pitch(st), []
        for end in (0, 1):
            o, u, n = self.frame(end)
            for side in (-1, 1):
                # towards the tip: from the middle of the attache, along its side then round the ogive
                towards_tip = [self.at(o, u, n, -self.tab / 2, side * (self.h - d))]
                if self.tab / 2 > self.ell:
                    towards_tip.append(self.at(o, u, n, self.ell - self.tab, side * (self.h - d)))
                towards_tip += self.tip_points(end, side, d)[1:] if self.tab / 2 > self.ell else []
                out += self._walk(towards_tip, 0., p, int(st['perfos_tip']))
                # towards the roll: from the root of the notch along the notch, inside
                pts, far = self.notch_points(end, side, d)
                out += self._walk(pts, 0., p, int(st['perfos_notch']))
        return out

    def stitches(self):
        """Attaches sewn on the bag: round each attache, ``distance`` inside, from one root to the other."""
        st, d = self.st, self.st['distance']
        if self.tab <= 0 or st['end'] == 'ring' or d <= 0 or self.h <= d:
            return []
        runs = []
        for end in (0, 1):
            o, u, n = self.frame(end)
            # 0.19.14: from where the arrondi starts, ``d`` inside (on a patte wider than the roll the root is a corner)
            run = [self.notch_points(end, -1, d)[0][0]]
            run += self.tip_points(end, -1, d)
            back = list(reversed(self.tip_points(end, 1, d)))
            if st['end'] == 'straight':
                run += back
            else:
                run += back[1:]
            run.append(self.notch_points(end, 1, d)[0][0])
            runs.append(run)
        return runs


# --- the pieces -------------------------------------------------------------------------------------------------

def _named(piece, name, quantity, height, model='', more=''):
    """The piece named like the « Nommer une pièce » tool does (its identification text owned by it)."""
    from craft_tools import text_bundle
    from geometry import bounds
    meta = dict(kind='part_name', model=model, values=[name], height=height, quantity=str(quantity), details='')
    piece['piece_info'] = {'part_name': meta}
    runs = []
    if model:
        runs.append(dict(text=model, height=height * .85, dy=0, color=GUIDES, weight='bold', underline=True))
    runs.append(dict(text=name, height=height, dy=height * 1.8 if model else 0, color='auto', weight='normal'))
    if more:
        runs.append(dict(text=more, height=height * .7, dy=runs[-1]['dy'] + height * 1.5, color='auto', weight='normal'))
    x, y, X, Y = bounds([piece])
    width = max(len(r['text']) * r['height'] * .65 for r in runs)
    text = text_bundle(((x + X - width) / 2, (y + Y) / 2 - height), runs, 0, meta)
    text['owner_id'] = piece['piece_id']
    return text


def _piece(points, name, profile='Coupe extérieure'):
    from cad import polygon
    from craft_tools import PROFILES
    s = polygon(points, name, True)
    s.update(profile=profile, style=dict(PROFILES[profile]), piece_id=uuid.uuid4().hex)
    return s


def _stitch(points, owner, pitch_mm):
    import copy
    import stitching
    from cad import polygon
    line = polygon(points, 'Piqûre patte', False)
    line.update(owner_id=owner, stitch=dict(kind='hand', pitch=pitch_mm), style=copy.deepcopy(stitching.STYLES['hand']), profile='Couture')
    return line


def handle_items(st, model=''):
    """The handle (its précoupe if any) in its own axes, with its perforations or stitches and its name."""
    from editing import drill_mark
    from geometry import bounds
    band = Band(st)
    piece = _piece(band.outline(), 'Poignée toron')
    out = [piece]
    for p in band.perforations():
        hole = drill_mark(p, HOLE)
        hole['owner_id'] = piece['piece_id']
        out.append(hole)
    for run in band.stitches():
        out.append(_stitch(run, piece['piece_id'], pitch(st)))
    cut = round(toron_length(st), 1)
    piece['toron'] = dict(diameter=st['diameter'], length=cut, count=2)   # 0.19.14: for the nomenclature
    out.append(_named(piece, 'POIGNÉE TORON', 2, 3., model, f'Toron Ø {_mm(st["diameter"])} · coupe 2 × {_mm(cut)} mm'))
    if st.get('precut', 0) > 0:
        import surcoupe
        try:
            out, _ = surcoupe.make_precut(out, 0, 1, 1, st['precut'], True)
        except ValueError:
            raise ValueError('Surcoupe encollage impossible avec cette forme : la réduire, ou 0 (sans).') from None
    return out


def _mm(v):
    return f'{round(v, 1):g}'.replace('.', ',')


def enchape_outline(st):
    """The enchape laid flat: folded round the ring at x = its length on the bag (``v``)."""
    w, v = st['enchape'], st['enchape_length']
    h, p = w / 2, (w / 2 if st['enchape_end'] == 'point' else 0.)
    if p:
        return [(p, -h), (v, -h), (2 * v - p, -h), (2 * v, 0.), (2 * v - p, h), (v, h), (p, h), (0., 0.)], v
    return [(0., -h), (v, -h), (2 * v, -h), (2 * v, h), (v, h), (0., h)], v


def _inset_convex(poly, offsets):
    n = len(poly)
    sign = 1 if sum(poly[k][0] * poly[(k + 1) % n][1] - poly[(k + 1) % n][0] * poly[k][1] for k in range(n)) > 0 else -1
    lines = []
    for k in range(n):
        (x1, y1), (x2, y2) = poly[k], poly[(k + 1) % n]
        d = math.hypot(x2 - x1, y2 - y1)
        lines.append(((x1 - (y2 - y1) / d * sign * offsets[k], y1 + (x2 - x1) / d * sign * offsets[k]), (x2 - x1, y2 - y1)))
    out = []
    for k in range(n):
        (p, r), (q, s) = lines[k - 1], lines[k]
        t = ((q[0] - p[0]) * s[1] - (q[1] - p[1]) * s[0]) / (r[0] * s[1] - r[1] * s[0])
        out.append((p[0] + t * r[0], p[1] + t * r[1]))
    return out


def _half(st, x0=None):
    w, v = st['enchape'], st['enchape_length']
    h, p = w / 2, (w / 2 if st['enchape_end'] == 'point' else 0.)
    x0 = v if x0 is None else x0
    if x0 >= 2 * v - 1e-6:
        return []
    if not p:
        return [(x0, -h), (2 * v, -h), (2 * v, h), (x0, h)]
    if x0 < 2 * v - p - 1e-6:
        return [(x0, -h), (2 * v - p, -h), (2 * v, 0.), (2 * v - p, h), (x0, h)]
    y = h * (2 * v - x0) / p
    return [(x0, -y), (2 * v, 0.), (x0, y)]


def _area(q):
    return sum(q[k][0] * q[(k + 1) % len(q)][1] - q[(k + 1) % len(q)][0] * q[k][1] for k in range(len(q))) / 2


def enchape_stitches(st, inset):
    """Round each half from 2 × ``inset`` below the ring: the same holes on both layers once folded."""
    w, v = st['enchape'], st['enchape_length']
    p = w / 2 if st['enchape_end'] == 'point' else 0.
    if inset <= 0 or w <= 2 * inset or v <= 3 * inset + p:
        return []
    half = _half(st)
    run = _inset_convex(half, [inset] * (len(half) - 1) + [2 * inset])
    return [run, [(2 * v - x, y) for x, y in reversed(run)]]


def enchape_renfort(st, inset):
    """One half, from the start of the stitches (3 mm from the fold at least) to the tip, 1 mm in from the edges."""
    half = _half(st, st['enchape_length'] + max(2 * inset, 3.))
    if len(half) < 3:
        return []
    out = _inset_convex(half, [1.] * (len(half) - 1) + [0.])
    return out if _area(out) * _area(half) > 0 and abs(_area(out)) > 1 else []


def enchape_items(st, top, model=''):
    """An enchape below ``top`` (y in the handle's axes), folded round the ring, its crans at the fold, its stitches,
    and beside it its renfort and its doublure (the whole enchape, 1 mm in) if asked."""
    from craft_tools import new_cran, standalone_notch, at_distance
    outline, v = enchape_outline(st)
    h = st['enchape'] / 2
    place = lambda q: (q[0], q[1] + top + h)
    pts = [place(q) for q in outline]
    e = _piece(pts, 'Enchape')
    out = [e]
    along = [0.]
    for a, b in zip(pts, pts[1:]):
        along.append(along[-1] + math.dist(a, b))
    for foot, inward in ((place((v, -h)), (0., 1.)), (place((v, h)), (0., -1.))):
        k = min(range(len(pts)), key=lambda i: math.dist(pts[i], foot))
        p, normal = at_distance(e, along[k])
        cran = standalone_notch(e, new_cran(along[k], 1 if normal[0] * inward[0] + normal[1] * inward[1] > 0 else -1))
        cran['owner_id'] = e['piece_id']
        out.append(cran)
    for run in enchape_stitches(st, st.get('distance', 0)):
        line = _stitch([place(q) for q in run], e['piece_id'], pitch(st))
        line['name'] = 'Piqûre enchape'
        out.append(line)
    out.append(_named(e, 'ENCHAPE', 4, 2.5, model))
    x = 2 * v + 10
    if st.get('enchape_renfort'):
        renfort = enchape_renfort(st, st.get('distance', 0))
        if renfort:
            dx = x - min(q[0] for q in renfort)
            r = _piece([place((q[0] + dx, q[1])) for q in renfort], 'Renfort enchape')
            out += [r, _named(r, 'RENFORT ENCHAPE', 4, 2., model)]
            x = max(q[0] for q in renfort) + dx + 10
    if st.get('enchape_doublure'):
        base = [q for q in outline if q not in ((v, -h), (v, h))]   # (the fold's points: no corner there)
        lining = _inset_convex(base, [1.] * len(base))
        if _area(lining) * _area(base) > 0:
            dx = x - min(q[0] for q in lining)
            d = _piece([place((q[0] + dx, q[1])) for q in lining], 'Doublure enchape')
            out += [d, _named(d, 'DOUBLURE ENCHAPE', 4, 2., model)]
    return out


def items(st, model=''):
    """Everything the tool draws, in the handle's own axes: the handle, its renfort, its enchapes (on rings)."""
    from cad import polygon
    from geometry import bounds
    out = handle_items(st, model)
    below = max(bounds([s])[3] for s in out if not s.get('annotation')) + 10
    if st.get('renfort', 0) > 0:
        r, T = st['renfort'], total_length(st)
        piece = _piece([(0., below), (T, below), (T, below + r), (0., below + r)], 'Renfort poignée')
        out += [piece, _named(piece, 'RENFORT POIGNÉE', 2, 2.5, model)]
        below += r + 10
    if st['end'] == 'ring' and st['tab_length'] > 0 and st.get('enchape', 0) > 0:
        out += enchape_items(st, below, model)
    return out


def check(st):
    """The settings a handle can be made with (ValueError: what to change)."""
    if st['diameter'] <= 0 or st['thickness'] <= 0 or st['length'] <= 0:
        raise ValueError('Toron, cuir et roulé : plus de 0 mm.')
    if st.get('roll_allowance', 0) < 0:
        raise ValueError('Surcoupe piqûre : 0 mm ou plus.')
    if st['tab_length'] > 0:
        if st['tab_width'] <= 0:
            raise ValueError('Largeur des pattes : plus de 0 mm.')
        if st['tab_length'] <= tip_length(st) + .5:
            raise ValueError(f'Pattes : plus longues que leur bout ({_mm(tip_length(st))} mm).')
    if st['points'] <= 0:
        raise ValueError('Points par cm : plus de 0.')
    if st['end'] == 'ring' and st.get('enchape', 0) > 0 and st['enchape_end'] == 'point' and st['enchape_length'] <= st['enchape'] / 2:
        raise ValueError('Enchapes : longueur sur le sac plus grande que la moitié de la largeur (bout pointu).')
    return st
