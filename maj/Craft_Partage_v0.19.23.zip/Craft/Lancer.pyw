"""Craft desktop launcher. No application composition or installation logic here."""
from bootstrap import main

if __name__ == '__main__':
    raise SystemExit(main())
