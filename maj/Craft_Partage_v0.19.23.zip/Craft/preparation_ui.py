"""0.17.0 « Préparation » tool and « Préparations » layer (see preparations.py).

Click inside a zone: the first click asks Parage (type, longueur pre-filled with the measured
width of the zone, épaisseur in tenths) or Teinte; the next clicks apply the same preparation to
other zones (each with its own width, unless a length was typed); Entrée ends. A click inside a
zone already prepared opens it again (to change it or « Supprimer »)."""
import math
import tkinter as tk
from tkinter import ttk,messagebox
import preparations as prep
from regions import region_at

FILL_TAG='prep_fill'


def visible(app):return bool(app.prefs.get('show_preparations',True))


def toggle(app):
    """« Afficher / masquer les préparations »: hidden, only the construction lines remain."""
    app.prefs['show_preparations']=not visible(app)
    try:app.persist_preferences()
    except OSError:pass
    if not visible(app):
        zones={i for i in app.selected_ids() if app.items[i].get('preparation')}
        if zones:app.selected_set=set(app.selected_set)-zones;app.selected=min(app.selected_set) if app.selected_set else None
        if app.tool.get()=='preparation':app.set_tool('select')
    app.status.set('Préparations affichées.' if visible(app) else 'Préparations masquées.');app.refresh();app.highlight_tools()


# 0.19.14 « un genre de calque qui fait voir ou non les précoupes ou surcoupes » (in Préparations): hidden, they are
# neither drawn nor clicked nor snapped to; the exports, the PDF and the fiches keep them.
CUT_KEYS={'precut':'show_precuts','recut':'show_recuts'}


def cut_visible(app,which):return bool(app.prefs.get(CUT_KEYS[which],True))


def hidden_cut(app,s):
    """A précoupe (and its band) while « Précoupes » is hidden, a piece surcoupée (inside its précoupe) while
    « Surcoupes » is hidden."""
    prefs=getattr(app,'prefs',None) or {}
    if prefs.get('show_precuts',True) and prefs.get('show_recuts',True):return False
    if s.get('annotation'):return False
    if not prefs.get('show_precuts',True) and (s.get('surcoupe') or (s.get('preparation') or {}).get('kind')=='surcoupe'):return True
    return not prefs.get('show_recuts',True) and bool(s.get('owner_id')) and (s.get('style') or {}).get('role')=='surcoupe'


def hidden_ids(app):
    prefs=getattr(app,'prefs',None) or {}
    if prefs.get('show_precuts',True) and prefs.get('show_recuts',True):return set()
    return {i for i,s in enumerate(app.items) if hidden_cut(app,s)}


def toggle_cut(app,which):
    key=CUT_KEYS[which];app.prefs[key]=not cut_visible(app,which)
    try:app.persist_preferences()
    except OSError:pass
    hidden=hidden_ids(app)
    if hidden and app.selected_set&hidden:
        app.selected_set=set(app.selected_set)-hidden;app.selected=min(app.selected_set) if app.selected_set else None
    name='Précoupes' if which=='precut' else 'Surcoupes'
    app.status.set(f'{name} affichées.' if cut_visible(app,which) else f'{name} masquées (exports, PDF et fiches les gardent).');app.refresh();app.highlight_tools()


def start(app):
    app.finish_action();app.cancel();app.tool.set('preparation');app.last_command=('tool','preparation')
    app.selected=None;app.selected_set=set();app.prep_state=dict(settings=None,hover=None)
    if not visible(app):app.prefs['show_preparations']=True   # one sees the zones one prepares
    app.highlight_tools();app.refresh();app.status.set('Cliquer dans la zone à préparer.')


def cancel(app):
    app.prep_state=None
    try:app.canvas.delete('prep_hover')
    except Exception:pass


def host_of(items,p):
    """The piece holding the click: the smallest piece in Coupe externe around it, else the
    smallest closed shape (zones excluded)."""
    from entity_rules import closed_piece
    from precision_geometry import inside
    from geometry import bounds
    from craft_tools import style
    best=None
    for i,s in enumerate(items):
        if not closed_piece(s):continue
        x,y,X,Y=bounds([s])
        if not(x<=p[0]<=X and y<=p[1]<=Y) or not inside(s,p):continue
        key=(style(s)['role']!='external',(X-x)*(Y-y))
        if best is None or key<best[0]:best=(key,i)
    return None if best is None else best[1]


def attach_loose(items,ids):
    """0.18.1: a zone without piece (a Mozart zone left beside its piece) moved onto a piece is
    attached to it: it then moves, turns and is copied with it. Returns how many were attached."""
    from entity_rules import ensure_piece_id
    count=0
    for i in ids:
        if not 0<=i<len(items):continue
        s=items[i]
        if not s.get('preparation') or s.get('owner_id'):continue
        try:centre=prep.placement(s)[0]
        except (ValueError,ZeroDivisionError,IndexError,TypeError):continue
        host=host_of(items,centre)
        if host is None:continue
        s['owner_id']=ensure_piece_id(items[host]);count+=1
    return count


def zone_at(items,p):
    """Index of the prepared zone under p (the smallest), or None."""
    best=None
    for i,s in enumerate(items):
        if not s.get('preparation'):continue
        pts=prep.ring_points(s)
        if prep.inside(pts,p):
            a=prep.area(pts)
            if best is None or a<best[0]:best=(a,i)
    return None if best is None else best[1]


def shown_items(app):
    """0.19.14: the objects the Préparation tool sees (not the précoupes / surcoupes hidden)."""
    hidden=hidden_ids(app)
    return [s for i,s in enumerate(app.items) if i not in hidden] if hidden else app.items


def region(app,p):
    try:return region_at(shown_items(app),p,app.scale)
    except (ValueError,KeyError,TypeError,ZeroDivisionError,IndexError):return None


def zone_width(s):
    """0.19.9: the width of a zone already there: the one measured when it was made, else w of the band
    of its area and outline (A = w·L, P = 2L + 2w, as regions.region_at)."""
    width=(s.get('preparation') or {}).get('width')
    if width:return float(width)
    pts=prep.ring_points(s);A=prep.area(pts);half=sum(math.dist(a,b) for a,b in zip(pts,pts[1:]+pts[:1]))/2;disc=half*half-4*A
    return round(2*A/(half+math.sqrt(disc)) if disc>=0 and half>0 else math.sqrt(max(A,0)),1)


def click(app,e):
    st=app.prep_state;p=app.raw(e)
    if st is None:return
    # 0.19.9: a zone already there first (reopened with its own outline, even where no region closes around
    # the click: 6 of the 20 zones of DIFORME, every Teinte); else the region of a new zone.
    existing=zone_at(app.items,p);found=None
    if existing is not None and hidden_cut(app,app.items[existing]):existing=None   # 0.19.14: a hidden précoupe's band
    if existing is None:
        found=region(app,p)
        if found is None:app.invalid_at(e,'Aucune zone fermée ici : cliquer entre des lignes qui se touchent.');return
    host=None
    if existing is None:
        shown=shown_items(app);k=host_of(shown,p)
        host=None if k is None else next(i for i,s in enumerate(app.items) if s is shown[k])
    if st['settings'] is None:return dialog(app,found,host,existing)   # first zone of the series
    if existing is not None and (app.items[existing].get('preparation') or {}).get('kind') not in prep.KINDS:
        return dialog(app,found,host,existing)   # 0.19.9: a zone with no button (« autre », précoupe) is asked, not changed by the series
    apply(app,found,host,existing,st['settings'])


def apply(app,found,host,existing,settings):
    from entity_rules import ensure_piece_id
    zone=app.items[existing] if existing is not None and existing<len(app.items) else None   # 0.19.9
    if zone is None and found is None:return   # 0.19.9: the zone reopened is no longer there
    width=found['width'] if zone is None else zone_width(zone)
    own=(zone.get('preparation') or {}).get('length') if zone is not None else None   # 0.19.9: its own length, as the window shows it
    data=dict(kind=settings['kind'],type=settings.get('type',''),thickness=settings.get('thickness'),width=width)
    if settings['kind']=='parage':data['length']=settings['length'] if settings.get('typed') else own or round(width,1)
    if settings['kind']=='teinte':data['couches']=settings.get('couches',1)   # 0.18.1 « Couche(s) » of the fiche
    app.snapshot()
    if zone is not None:z=zone;edit_zone(z,data)
    else:
        owner=ensure_piece_id(app.items[host]) if host is not None else None
        z=prep.zone(found,data,owner);app.items.append(z)
    app.canvas.delete('prep_hover');app.refresh()
    app.status.set(f'{z["preparation"]["label"].capitalize()} · cliquer la zone suivante.')


def edit_zone(s,data):
    """0.19.9: a zone already there keeps its outline and its piece, only what it prepares changes (it took
    the region found under the click: a rembord of DIFORME, 420 mm², became its whole piece, 34 180 mm²).
    What the window does not show stays (the width measured, the type of a Mozart teinte)."""
    old=s.get('preparation') or {};kind=data['kind']
    new=dict(old) if old.get('kind')==kind else {k:v for k,v in data.items() if k!='width'}
    new.update((k,data[k]) for k in {'parage':('type','length','thickness'),'teinte':('couches',)}.get(kind,()))
    if old.get('width') is not None:new['width']=old['width']
    new['label']=prep.label(kind,'' if kind=='teinte' else new.get('type',''),new.get('length'),new.get('thickness'))   # as an import (show_mozart)
    s['preparation']=new
    if old.get('kind')!=kind:s['style']=dict(s.get('style') or {},color=prep.BASE.get(kind,prep.BASE['autre']),role='preparation')


def remove(app,existing):
    if existing is None or existing>=len(app.items):return
    app.snapshot();del app.items[existing];app.refresh();app.status.set('Préparation supprimée · cliquer une autre zone.')


def dialog(app,found,host,existing):
    """Parage (type, longueur, épaisseur) or Teinte; filled in from the zone already there."""
    old=app.items[existing]['preparation'] if existing is not None else {}
    win=app.dialog('Préparation');panel=app.p['panel'];measured=round(found['width'],1) if found is not None else zone_width(app.items[existing])   # 0.19.9
    kind=tk.StringVar(value=old.get('kind','parage'));kind_type=tk.StringVar(value=old.get('type','Rembord') if old.get('kind','parage')=='parage' else 'Rembord')
    length=tk.StringVar(value=prep.fmt(old.get('length') if old.get('length') else measured));thick=tk.StringVar(value=prep.fmt(old.get('thickness')))
    coats=tk.StringVar(value=str(old.get('couches',1)) if old.get('kind')=='teinte' else '1')
    options=dict(bg=panel,fg=app.p['ui_ink'],selectcolor=app.field_background(),activebackground=panel,font=('Segoe UI',10))
    row=tk.Frame(win,bg=panel);row.pack(fill='x',padx=16,pady=(14,6))
    form=tk.Frame(win,bg=panel);form.pack(fill='x',padx=16)
    dye=tk.Frame(win,bg=panel);dye.pack(fill='x',padx=16)
    def refresh_form():
        for w in form.winfo_children():
            w.grid() if kind.get()=='parage' else w.grid_remove()
        for w in dye.winfo_children():
            w.grid() if kind.get()=='teinte' else w.grid_remove()
    for value,text in (('parage','Parage'),('teinte','Teinte')):__import__('modern_style').make_radio(row,text=text,variable=kind,value=value,command=refresh_form,**options).pack(side='left',padx=(0,12))
    app.label(form,'Type').grid(row=0,column=0,sticky='w',pady=3);ttk.Combobox(form,textvariable=kind_type,values=list(prep.PARAGE_TYPES),width=14).grid(row=0,column=1,sticky='w',padx=8)
    app.label(form,f'Longueur (mm) · zone {prep.fmt(measured)}').grid(row=1,column=0,sticky='w',pady=3);field=app.entry(form,length,8);field.grid(row=1,column=1,sticky='w',padx=8)
    app.label(form,'Épaisseur (/10, facultatif)').grid(row=2,column=0,sticky='w',pady=3);app.entry(form,thick,8).grid(row=2,column=1,sticky='w',padx=8)
    app.label(dye,'Couche(s)').grid(row=0,column=0,sticky='w',pady=3);app.entry(dye,coats,4).grid(row=0,column=1,sticky='w',padx=8)
    refresh_form()
    def number(text,label,low,high):
        text=text.strip().replace(',','.')
        if not text:return None
        try:v=float(text)
        except ValueError:raise ValueError(f'{label} : nombre attendu.') from None
        if not low<=v<=high:raise ValueError(f'{label} : {prep.fmt(low)} à {prep.fmt(high)}.')
        return v
    def valid(e=None):
        if kind.get() not in prep.KINDS:
            # 0.19.9: a kind without its button (a Mozart « autre » zone, a surcoupe) is kept as it is (it became
            # « PARAGE » and lost its type); the next click asks again.
            win.destroy();app.canvas.focus_set();return 'break'
        try:
            settings=dict(kind=kind.get())
            if kind.get()=='teinte':settings['couches']=int(number(coats.get(),'Couche(s)',1,20) or 1)
            if kind.get()=='parage':
                value=number(length.get(),'Longueur',.1,500)
                settings.update(type=kind_type.get().strip(),thickness=number(thick.get(),'Épaisseur',.1,99),length=value if value is not None else measured,typed=value is not None and abs(value-measured)>.05)
        except ValueError as exc:messagebox.showerror('Préparation',str(exc),parent=win);return 'break'
        win.destroy();app.canvas.focus_set()
        if app.prep_state is None:return 'break'
        app.prep_state['settings']=settings;apply(app,found,host,existing,settings);return 'break'
    buttons=tk.Frame(win,bg=panel);buttons.pack(fill='x',padx=16,pady=(10,14))
    if existing is not None:app.button(buttons,'Supprimer',lambda:(win.destroy(),remove(app,existing))).pack(side='left')
    app.button(buttons,'Valider',valid).pack(side='right')
    win.bind('<Return>',valid);field.focus_set();field.select_range(0,'end')
    win.protocol('WM_DELETE_WINDOW',lambda:(win.destroy(),app.canvas.focus_set()))
    return win


def enter(app):
    """Entrée: the series of zones is over."""
    app.prep_state=None;app.canvas.delete('prep_hover');app.complete_command('preparation');app.highlight_tools();app.refresh()
    app.status.set('Préparations terminées.');return 'break'


def motion(app,e):
    """The zone under the pointer is outlined before the click (like a hatch preview)."""
    app.cursor_screen=(e.x,e.y);app._inside_plan=True;st=app.prep_state;p=app.raw(e)
    c=app.canvas;key=(round(e.x/3),round(e.y/3))
    if st.get('hover_key')!=key:
        st['hover_key']=key;c.delete('prep_hover');existing=zone_at(app.items,p)
        if existing is not None and hidden_cut(app,app.items[existing]):existing=None   # 0.19.14
        found=region(app,p) if existing is None else None   # 0.19.9: the zone a click reopens, else the new region
        pts=prep.ring_points(app.items[existing]) if existing is not None else prep.keyhole(found['points'],found.get('holes')) if found else None
        if pts:
            c.create_polygon(*[v for q in pts for v in app.to_screen(q)],fill='',outline=app.p['accent'],width=2,dash=(4,3),tags='prep_hover')
    app.draw_crosshair()


def draw_zone(app,s,tags,chosen):
    """The zone: its fill under the lines and its label in the middle; hidden with the layer."""
    if not visible(app):return None
    c=app.canvas;pts=prep.ring_points(s)
    if len(pts)<3:return None
    flat=[v for p in pts for v in app.to_screen(p)];kind=(s.get('preparation') or {}).get('kind','autre')
    if tags:return c.create_polygon(*flat,fill='',outline=app.p['accent'],width=1,tags=tags)   # a preview: outline only
    fill=prep.fill_colour(kind,app.p.get('canvas','#484b50'))
    item=c.create_polygon(*flat,fill=fill,outline=app.p['accent'] if chosen else '',width=2 if chosen else 0,tags=FILL_TAG)
    text=(s.get('preparation') or {}).get('label','')
    if text:
        (x,y),angle,height=prep.placement(s);px=height*app.scale
        if px>=5:
            from ui_widgets import contrast_color,zoom_tag
            c.create_text(*app.to_screen((x,y)),text=text,angle=angle,fill=contrast_color(fill),font=('Segoe UI',-max(1,round(px)),'bold'),tags=zoom_tag('prep_label','t',height))
    return item


def lower_fills(app):
    """Fills under every line, above the smooth picture."""
    c=app.canvas
    if c.find_withtag(FILL_TAG):c.tag_lower(FILL_TAG);c.tag_lower('_smooth_display')
