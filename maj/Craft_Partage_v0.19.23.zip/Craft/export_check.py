"""0.17.0 Contrôle avant export.

Every export needs at least one valid piece (closed, Coupe externe, with a name and a material).
For the cutting machine (DXF, SVG, DWG) the pieces must stay 30 mm apart, crans included: a pair
closer than that stops the export, the plan zooms on it with the distance marked. The window lists
everything that will not be exported (open contour, missing name or material, cran off its
contour, internal cut outside any piece); a click on a line zooms on it. PDF (hand cutting): no
spacing check. 0.18.1: a Coupe externe line inside a piece or on its contour (a double cut line,
that the cutting machine may misread) stops the export too; a piece to cut in the « Bases »
column is pointed out. 0.18.2: the double line stops the PDF and the printing of the plan too
(the same pattern everywhere, a clean one); the 30 mm and the Bases stay for the machine."""
import math
from geometry import path,bounds

GAP=30.
NO_PIECE='Aucune pièce valide : une pièce doit être fermée, en Coupe externe, avec un nom et une matière.'
MARK='#ff7a1a'


def fmt(v):return f'{v:.1f}'.replace('.',',')


def piece_name(items,i):
    """« DOUBLURE RABAT 1 » from the piece's name label, else « pièce n° 12 »."""
    from entity_rules import piece_labels
    try:found=piece_labels(items,i).get('part_name')
    except (ValueError,KeyError,TypeError,IndexError):found=None
    if found:
        data=items[found[0]].get('identification') or {}
        values=[v for v in data.get('values',[]) if v]
        if values:return ' '.join(values)
        runs=items[found[0]].get('text_runs') or []
        if runs:return runs[-1].get('text','').strip() or f'pièce n° {i+1}'
    return f'pièce n° {i+1}'


def _strokes(s):
    from curves import parts
    return parts(s) if s.get('components') else [s]


def segments(items,ids):
    out=[]
    for i in ids:
        s=items[i]
        if s.get('annotation') or s.get('dimension_group'):continue
        for q in _strokes(s):
            try:pts,closed=path(q)
            except (ValueError,KeyError,TypeError):continue
            if closed and len(pts)>2:pts=pts+pts[:1]
            out+=[(a,b) for a,b in zip(pts,pts[1:]) if a!=b]
    return out


def _point_segment(p,a,b):
    dx,dy=b[0]-a[0],b[1]-a[1];n=dx*dx+dy*dy
    t=0. if n<1e-18 else max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/n))
    q=(a[0]+t*dx,a[1]+t*dy);return math.dist(p,q),q


def _cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])


def segment_distance(a,b,c,d):
    """Shortest distance between segments ab and cd, with the two closest points."""
    d1,d2,d3,d4=_cross(c,d,a),_cross(c,d,b),_cross(a,b,c),_cross(a,b,d)
    if (d1>0)!=(d2>0) and (d3>0)!=(d4>0) and d1 and d2 and d3 and d4:
        t=d1/(d1-d2);p=(a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t);return 0.,p,p
    best=None
    for p,(u,v),first in ((a,(c,d),True),(b,(c,d),True),(c,(a,b),False),(d,(a,b),False)):
        dist,q=_point_segment(p,u,v)
        if best is None or dist<best[0]:best=(dist,p,q) if first else (dist,q,p)
    return best


def _grid(segs,cell):
    grid={}
    for k,(a,b) in enumerate(segs):
        for gx in range(math.floor(min(a[0],b[0])/cell),math.floor(max(a[0],b[0])/cell)+1):
            for gy in range(math.floor(min(a[1],b[1])/cell),math.floor(max(a[1],b[1])/cell)+1):grid.setdefault((gx,gy),[]).append(k)
    return grid


def _box(segs):
    xs=[v for a,b in segs for v in (a[0],b[0])];ys=[v for a,b in segs for v in (a[1],b[1])]
    return min(xs),min(ys),max(xs),max(ys)


def closest(A,B,gridB,gap):
    """Shortest distance (< gap) between two sets of segments, else None."""
    best=None;cell=gap
    bx,by,BX,BY=_box(B)
    for a,b in A:
        x0,y0,x1,y1=min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1])
        if x0>BX+gap or x1<bx-gap or y0>BY+gap or y1<by-gap:continue
        seen=set()
        for gx in range(math.floor((x0-gap)/cell),math.floor((x1+gap)/cell)+1):
            for gy in range(math.floor((y0-gap)/cell),math.floor((y1+gap)/cell)+1):
                for k in gridB.get((gx,gy),()):
                    if k in seen:continue
                    seen.add(k);c,d=B[k];r=segment_distance(a,b,c,d)
                    if r[0]<gap and (best is None or r[0]<best[0]):
                        best=r
                        if r[0]==0:return best
    return best


def groups(items,ids):
    """Exported pieces → their exported members (the piece, its crans, its internal cuts)."""
    from entity_rules import closed_piece
    from craft_tools import style
    from precision_geometry import inside
    roots=[i for i in ids if closed_piece(items[i]) and style(items[i])['role']=='external']
    members={r:[r] for r in roots};owners={items[r].get('piece_id'):r for r in roots if items[r].get('piece_id')}
    for i in ids:
        if i in members:continue
        s=items[i]
        if s.get('annotation') or s.get('dimension_group'):continue
        r=owners.get(s.get('owner_id'))
        if r is None:
            try:p=path(_strokes(s)[0])[0][0]
            except (ValueError,KeyError,TypeError,IndexError):continue
            r=next((k for k in roots if inside(items[k],p)),None)
            if r is None:r=min(roots,key=lambda k:_near(items[k],p),default=None)
        if r is not None:members[r].append(i)
    return members


def _near(s,p):
    from precision_geometry import contour_location
    try:return math.dist(contour_location(s,p)[1],p)
    except (ValueError,KeyError,TypeError):return math.inf


def spacing(items,ids,gap=GAP):
    """Pairs of exported pieces closer than ``gap`` (crans included), closest first."""
    from precision_geometry import inside
    members=groups(items,ids);roots=list(members);segs={r:segments(items,members[r]) for r in roots}
    boxes={r:_box(segs[r]) for r in roots if segs[r]};grids={}
    found=[]
    for n,i in enumerate(roots):
        if i not in boxes:continue
        for j in roots[n+1:]:
            if j not in boxes:continue
            a,b=boxes[i],boxes[j]
            if a[0]>b[2]+gap or b[0]>a[2]+gap or a[1]>b[3]+gap or b[1]>a[3]+gap:continue
            if j not in grids:grids[j]=_grid(segs[j],gap)
            r=closest(segs[i],segs[j],grids[j],gap);over=False
            if r is None:
                # No line within 30 mm but one piece over the other: they overlap.
                inner=[(x,y) for x,y in ((i,j),(j,i)) if inside(items[y],path(items[x])[0][0]) and not _in_hole(items,members[y],path(items[x])[0][0])]
                if inner:p=path(items[inner[0][0]])[0][0];r=(0.,p,p);over=True
            if r is not None:found.append(dict(pair=(i,j),distance=r[0],points=(r[1],r[2]),overlap=over))
    return sorted(found,key=lambda f:f['distance'])


def _in_hole(items,ids,p):
    from craft_tools import style
    from entity_rules import closed_piece
    from precision_geometry import inside
    return any(closed_piece(items[k]) and style(items[k])['role']=='internal' and inside(items[k],p) for k in ids)


def doubled(items,ids,roots):
    """0.18.1: Coupe externe strokes lying inside an exported piece or on its contour (a double
    cut line): {stroke: piece}."""
    from entity_rules import geometry_entity
    from craft_tools import style
    from precision_geometry import inside,contour_location
    boxes={r:bounds([items[r]]) for r in roots};out={}
    for i in sorted(ids):
        s=items[i]
        if i in roots or not geometry_entity(s) or s.get('preparation') or style(s)['role']!='external':continue
        try:
            pts,closed=path(s);pts=pts+pts[:1] if closed else pts
            probe=pts+[((a[0]+b[0])/2,(a[1]+b[1])/2) for a,b in zip(pts,pts[1:])]
        except (ValueError,KeyError,TypeError):continue
        if not probe:continue
        x,y,X,Y=bounds([s])
        for r in roots:
            a,b,A,B=boxes[r]
            if x<a-.1 or y<b-.1 or X>A+.1 or Y>B+.1:continue
            host=items[r]
            if all(inside(host,q) or math.dist(contour_location(host,q)[1],q)<=.05 for q in probe):out[i]=r;break
    return out


def problems(items,scope=None,machine=True,workspace=None):
    """Everything that blocks or will not be exported, as lines for the Contrôle window."""
    from entity_rules import fabrication_ids,closed_piece,piece_labels,geometry_entity
    from craft_tools import style
    from precision_geometry import inside
    ids=set(range(len(items))) if scope is None else {i for i in scope if 0<=i<len(items)}
    kept=fabrication_ids(items,sorted(ids) if scope is not None else None);out=[]
    exported=[i for i in kept if closed_piece(items[i]) and style(items[i])['role']=='external'];twice={}
    if machine:
        for f in spacing(items,kept):
            i,j=f['pair'];d=f['distance']
            state='superposées' if f['overlap'] else 'se touchent' if d==0 else f'{fmt(d)} mm (minimum {GAP:g} mm)'
            text=f'{piece_name(items,i)} ↔ {piece_name(items,j)} : {state}'
            out.append(dict(kind='spacing',text=text,ids=[i,j],points=f['points'],distance=d,blocking=True))
        twice=doubled(items,ids,exported)
        for i,r in twice.items():
            out.append(dict(kind='double',text=f'{piece_name(items,r)} : double ligne de coupe externe',ids=[r,i],blocking=True))
        if workspace:
            from pdf_layout import zone_at
            for r in exported:
                x,y,X,Y=bounds([items[r]])
                if zone_at(((x+X)/2,(y+Y)/2),workspace)=='Bases':
                    out.append(dict(kind='bases',text=f'{piece_name(items,r)} : pièce à couper dans la colonne Bases',ids=[r],blocking=False))
    kept=set(kept);pieces=[i for i in ids if closed_piece(items[i]) and style(items[i])['role']=='external']
    for i in sorted(ids):
        s=items[i]
        if i in kept or i in twice or not geometry_entity(s) or s.get('preparation'):continue
        role=style(s)['role']
        if role=='external' and not closed_piece(s):
            try:ends=path(s)[0];gap=math.dist(ends[0],ends[-1]) if len(ends)>1 else None
            except (ValueError,KeyError,TypeError,IndexError):gap=None
            said=f' (bouts à {gap:.2f} mm)'.replace('.',',') if gap is not None and gap<10 else ''   # 0.19.13
            out.append(dict(kind='open',text='Coupe externe non fermée'+said,ids=[i],blocking=False))
        elif role=='external':
            owned=piece_labels(items,i);missing=[label for key,label in (('part_name','nom'),('material','matière')) if not owned.get(key)]
            if missing:out.append(dict(kind='label',text=f'{piece_name(items,i)} : sans '+' ni '.join(missing),ids=[i],blocking=False))
        elif role=='internal':
            try:p=path(s)[0][0]
            except (ValueError,KeyError,TypeError,IndexError):continue
            if not any(inside(items[k],p) for k in pieces):out.append(dict(kind='internal',text='Coupe interne hors pièce',ids=[i],blocking=False))
    roots={items[i].get('piece_id'):i for i in kept if items[i].get('piece_id') and closed_piece(items[i]) and style(items[i])['role']=='external'}
    for i in sorted(ids):
        s=items[i]
        if s.get('is_notch') and i not in kept and s.get('owner_id') in roots and not items[roots[s['owner_id']]].get('surcoupe'):   # 0.18.1: a précoupe's crans are cut at the 2nd step
            out.append(dict(kind='cran',text=f'Cran hors contour ({piece_name(items,roots[s["owner_id"]])})',ids=[i],blocking=False))
    return out


def doubles(items,scope=None):
    """0.18.2: only the double Coupe externe lines of the pieces exported (PDF and printing)."""
    from entity_rules import fabrication_ids,closed_piece
    from craft_tools import style
    ids=set(range(len(items))) if scope is None else {i for i in scope if 0<=i<len(items)}
    kept=fabrication_ids(items,sorted(ids) if scope is not None else None)
    exported=[i for i in kept if closed_piece(items[i]) and style(items[i])['role']=='external']
    return [dict(kind='double',text=f'{piece_name(items,r)} : double ligne de coupe externe',ids=[r,i],blocking=True) for i,r in doubled(items,ids,exported).items()]


def box_of(items,problem):
    pts=[]
    for i in problem['ids']:
        if i<len(items):
            try:x,y,X,Y=bounds([items[i]]);pts+=[(x,y),(X,Y)]
            except (ValueError,KeyError,TypeError):pass
    if problem.get('points'):pts+=list(problem['points'])
    if not pts:return None
    return min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts)


def zoom_on(app,problem):
    """The plan framed on the problem (both pieces for a spacing), marked until the next change."""
    box=box_of(app.items,problem)
    app._export_marks=problem
    if box is None:app.redraw();return
    x,y,X,Y=box;W=max(100,app.canvas.winfo_width());H=max(100,app.canvas.winfo_height())
    pad=max(20.,.15*max(X-x,Y-y));x-=pad;y-=pad;X+=pad;Y+=pad
    app.scale=max(.002,min(20,W/max(1,X-x),H/max(1,Y-y)));app.ox=(W-(X-x)*app.scale)/2-x*app.scale;app.oy=(H-(Y-y)*app.scale)/2-y*app.scale
    app._view_moved=0;app.redraw()


def draw_marks(app):
    """Orange outline of the pieces concerned and the distance between the two closest points."""
    c=app.canvas;c.delete('export_check');problem=app.__dict__.get('_export_marks')
    if not problem:return
    for i in problem['ids']:
        if i>=len(app.items):continue
        for q in _strokes(app.items[i]):
            try:pts,closed=path(q)
            except (ValueError,KeyError,TypeError):continue
            pts=pts+pts[:1] if closed else pts
            if len(pts)>1:c.create_line(*[v for p in pts for v in app.to_screen(p)],fill=MARK,width=3,tags='export_check')
    if problem.get('points'):
        p,q=problem['points'];a,b=app.to_screen(p),app.to_screen(q)
        c.create_line(*a,*b,fill=MARK,width=2,arrow='both' if math.dist(a,b)>12 else None,tags='export_check')
        for x,y in (a,b):c.create_oval(x-3,y-3,x+3,y+3,fill=MARK,outline=MARK,tags='export_check')
        mx,my=(a[0]+b[0])/2,(a[1]+b[1])/2
        c.create_text(mx+8,my-8,text=f'{fmt(problem["distance"])} mm',anchor='sw',fill=MARK,font=('Segoe UI',11,'bold'),tags='export_check')
    c.tag_raise('export_check')


def clear_marks(app):
    if app.__dict__.pop('_export_marks',None) is not None:
        try:app.canvas.delete('export_check')
        except Exception:pass


def ready(app,kind,scope=None,warnings=True):
    """True when the export may go on. Shows « Aucune pièce valide… » or the Contrôle window."""
    from tkinter import messagebox
    from entity_rules import fabrication_ids,closed_piece
    from craft_tools import style
    ids=fabrication_ids(app.items,scope)
    if not any(closed_piece(app.items[i]) and style(app.items[i])['role']=='external' for i in ids):
        messagebox.showinfo('Export',NO_PIECE,parent=app);return False
    try:found=doubles(app.items,scope) if kind=='pdf' else problems(app.items,scope,machine=True,workspace=getattr(app,'workspace',None))
    except (ValueError,KeyError,TypeError,IndexError,ZeroDivisionError):found=[]   # a check never blocks an export by itself
    if not warnings:found=[f for f in found if f['blocking']]
    if not found:clear_marks(app);return True
    return show(app,found,kind)


def show(app,found,kind=None):
    """The Contrôle avant export window; returns True for « Exporter quand même »."""
    import tkinter as tk
    from tkinter import ttk
    blocking=any(f['blocking'] for f in found);answer=[False]
    win=app.dialog('Contrôle avant export');panel=app.p['panel']
    kinds={f['kind'] for f in found if f['blocking']}
    if kinds=={'spacing'}:heading=f'Écart minimum entre pièces : {GAP:g} mm. Espacer les pièces indiquées.'
    elif kinds=={'double'} and kind=='pdf':heading='Double ligne de coupe externe : supprimer le trait en trop avant d’imprimer.'
    elif kinds=={'double'}:heading='Double ligne de coupe externe : la découpe numérique peut mal la lire. Supprimer le trait en trop.'
    elif kinds:heading='Corriger les points marqués ⛔ avant l’export.'
    elif any(f['kind']=='bases' for f in found):heading='À vérifier avant l’export (les pièces des Bases seront exportées).'
    else:heading='Ces éléments ne seront pas exportés.'
    app.label(win,heading).pack(anchor='w',padx=14,pady=(12,4))
    area=tk.Frame(win,bg=panel);area.pack(fill='both',expand=True,padx=14,pady=4)
    box=tk.Listbox(area,height=min(12,max(3,len(found))),width=64,bg=app.field_background(),fg=app.p['ui_ink'],selectbackground=app.p['accent'],exportselection=False,relief='solid',bd=1,font=('Segoe UI',10))
    scroll=ttk.Scrollbar(area,orient='vertical',command=box.yview);scroll.pack(side='right',fill='y');box.configure(yscrollcommand=scroll.set);box.pack(side='left',fill='both',expand=True)
    for f in found:box.insert('end',('⛔ ' if f['blocking'] else '• ')+f['text'])
    def pick(e=None):
        if box.curselection():zoom_on(app,found[box.curselection()[0]])
    box.bind('<<ListboxSelect>>',pick)
    row=tk.Frame(win,bg=panel);row.pack(fill='x',padx=14,pady=(6,12))
    def close(go=False):
        answer[0]=go;__import__('contours_ui').clear(app);win.destroy()
    app.button(row,'Fermer',close).pack(side='right')
    if any(f['kind']=='open' for f in found):
        # 0.19.13: the open ends in red rings at once; the cut lines open by less than 0,1 mm closed in one click
        import contours_ui
        contours_ui.draw(app)
        def close_gaps():
            n=contours_ui.close_small(app)
            if not n:app.status.set('Aucun écart de moins de 0,1 mm.');return
            again=[f for f in problems(app.items,None,machine=kind!='pdf',workspace=getattr(app,'workspace',None))] if kind!='pdf' else doubles(app.items)
            found[:]=again;box.delete(0,'end')
            for f in found:box.insert('end',('⛔ ' if f['blocking'] else '• ')+f['text'])
            contours_ui.draw(app);app.status.set(f'{n} contour{"s" if n!=1 else ""} fermé{"s" if n!=1 else ""} (écart de moins de 0,1 mm).')
        if contours_ui.closable(app.items):app.button(row,'Fermer les écarts < 0,1 mm',close_gaps).pack(side='left')
        win._close_gaps=close_gaps
    if not blocking:app.button(row,'Exporter quand même',lambda:close(True)).pack(side='right',padx=6)
    win.protocol('WM_DELETE_WINDOW',close);win.bind('<Escape>',lambda e:close())
    win._check_found=found
    if blocking:box.selection_set(0);pick()   # one pair at a time: the closest one is shown at once
    app.wait_window(win)
    if answer[0]:clear_marks(app)
    return answer[0]
