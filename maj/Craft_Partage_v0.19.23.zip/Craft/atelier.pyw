"""Compatibility entry point; the application class lives in atelier_core."""
from atelier_core import App

if __name__ == '__main__':
    from bootstrap import main
    raise SystemExit(main())
