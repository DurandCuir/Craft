"""CAD window/crossing selection, in model units."""
from geometry import path,bounds
from cad import segment_intersection

def in_box(p,r):return r[0]<=p[0]<=r[2] and r[1]<=p[1]<=r[3]

def hits(s,r,crossing=False):
    x,y,X,Y=bounds([s])
    if not crossing:return x>=r[0] and y>=r[1] and X<=r[2] and Y<=r[3]
    if X<r[0] or x>r[2] or Y<r[1] or y>r[3]:return False
    if s.get('annotation'):return True
    if s.get('components'):
        from curves import parts
        return any(hits(part,r,True) for part in parts(s))
    pts,closed=path(s)
    if any(in_box(p,r) for p in pts):return True
    corners=[(r[0],r[1]),(r[2],r[1]),(r[2],r[3]),(r[0],r[3])]
    edges=list(zip(corners,corners[1:]+corners[:1]))
    return any(segment_intersection(a,b,c,d) for a,b in zip(pts,pts[1:]+pts[:1] if closed else pts[1:]) for c,d in edges)

# 0.19.21: what Réseau and Joindre ask for when nothing is selected (the words he agreed to, 09/11/2026).
PICK_PROMPT='Sélectionner les objets, puis Entrée'


def shift_held(e):
    """0.18.0, like AutoCAD: Maj (Shift) + clic or rectangle removes from the selection."""
    return bool(getattr(e,'state',0)&1)


def combined(current,picked,remove=False):
    """0.18.0: a click or a rectangle ADDS to the selection (no Ctrl needed); with Maj it removes."""
    current=set(current);picked=set(picked)
    return current-picked if remove else current|picked


def select(items,a,b):
    r=(min(a[0],b[0]),min(a[1],b[1]),max(a[0],b[0]),max(a[1],b[1]))
    return {i for i,s in enumerate(items) if hits(s,r,b[0]<a[0])}


def overlay_pixel(color,alpha=45):
    import struct,zlib
    rgb=bytes(int(color[i:i+2],16) for i in (1,3,5))+bytes([alpha])
    def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',1,1,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b'\0'+rgb))+chunk(b'IEND',b'')
