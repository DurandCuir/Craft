"""Craft leather-hide emblem and Windows identity. No optional runtime dependencies."""
from brand_assets import PNG_IMAGES, ICO_IMAGE
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading

from craft_version import APP_ID
ICON_NAME = 'Craft-logo3-green.ico'

def set_process_identity():
    if os.name == 'nt':
        import ctypes
        fn=ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID
        fn.argtypes=[ctypes.c_wchar_p];fn.restype=ctypes.c_int32
        fn(APP_ID)


def ensure_icon(directory=None):
    from app_paths import icon_directory
    target = Path(directory) if directory is not None else icon_directory()
    target.mkdir(parents=True, exist_ok=True)
    path = target / ICON_NAME
    content = base64.b64decode(ICO_IMAGE)
    if not path.exists() or path.read_bytes() != content:
        path.write_bytes(content)
    # A new filename prevents Windows from reusing the cached previous icon.
    versioned=target / ('Craft-logo3-green-'+hashlib.sha256(content).hexdigest()[:12]+'.ico')
    if not versioned.exists() or versioned.read_bytes()!=content:versioned.write_bytes(content)
    return versioned


def shortcut_matches(target, arguments, directory):
    """Match this installation, never a generic Python shortcut or another Craft."""
    import ntpath,shlex
    norm=lambda p:ntpath.normcase(ntpath.normpath(str(p)))
    directory=norm(directory);target=norm(target)
    if target==ntpath.join(directory,'craft.exe'):return True
    if ntpath.basename(target) not in ('pythonw.exe','python.exe'):return False
    try:args=shlex.split(arguments,posix=False)
    except ValueError:return False
    while args and args[0] in ('-E','-s','-S','-I','-B','-u'):args.pop(0)
    if not args:return False
    launcher=norm(args[0].strip('"'))
    return launcher in {ntpath.join(directory,name) for name in ('lancer.pyw','atelier.pyw')}


def brand_error(message):
    """Keep a bounded local diagnostic instead of silently hiding Shell failures."""
    from app_paths import user_data_directory
    try:
        log=user_data_directory()/'Logo_Windows.log';log.parent.mkdir(parents=True,exist_ok=True)
        previous=log.read_text(encoding='utf-8')[-4000:] if log.exists() else ''
        log.write_text(previous+str(message)+'\n',encoding='utf-8')
    except OSError:pass


def _powershell(script):
    encoded=base64.b64encode(script.encode('utf-16-le')).decode('ascii')
    result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-EncodedCommand',encoded],capture_output=True,timeout=20,creationflags=0x08000000)
    if result.returncode:raise OSError('Raccourcis : '+str(result.stderr)[-1000:])
    return json.loads(result.stdout or b'[]')


def refresh_shortcuts(directory, icon):
    """Reconcile existing links on every launch, including later/renamed pins."""
    if os.name!='nt':return 0
    directory=Path(directory).resolve()
    try:
        records=_powershell("""$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$shell=New-Object -ComObject WScript.Shell
$folders=@([Environment]::GetFolderPath('Desktop'),(Join-Path ([Environment]::GetFolderPath('Programs')) 'Craft'),(Join-Path $env:APPDATA 'Microsoft\\Internet Explorer\\Quick Launch\\User Pinned\\TaskBar'))
$records=@()
foreach($folder in $folders){
 if(-not(Test-Path -LiteralPath $folder)){continue}
 foreach($file in (Get-ChildItem -LiteralPath $folder -Filter '*.lnk' -File)){
  try{$link=$shell.CreateShortcut($file.FullName);$records+=@{path=$file.FullName;target=$link.TargetPath;arguments=$link.Arguments}}catch{continue}
 }
}
ConvertTo-Json -InputObject @($records) -Compress
""")
        if not isinstance(records,list):raise ValueError('Liste de raccourcis invalide')
        paths=[v['path'] for v in records if isinstance(v,dict) and all(isinstance(v.get(k),str) for k in ('path','target','arguments')) and shortcut_matches(v['target'],v['arguments'],directory)]
        if not paths:return 0
        # Only the verified paths are written; data is never inserted as PS code.
        encoded=base64.b64encode(json.dumps(dict(paths=paths,icon=str(icon))).encode('utf-8')).decode('ascii')
        updated=_powershell("""$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$data=([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('PAYLOAD'))|ConvertFrom-Json)
$shell=New-Object -ComObject WScript.Shell
$updated=@()
foreach($path in $data.paths){
 try{$link=$shell.CreateShortcut($path);$link.IconLocation=$data.icon+',0';$link.Save();$updated+=$path}catch{continue}
}
ConvertTo-Json -InputObject @($updated) -Compress
""".replace('PAYLOAD',encoded))
        if not isinstance(updated,list):raise ValueError('Résultat de raccourcis invalide')
        from windows_identity import set_shortcut_identity
        done=0
        for path in paths:
            if path not in updated:brand_error('Raccourci non actualisé : '+path);continue
            try:set_shortcut_identity(path,APP_ID,icon);done+=1
            except OSError as exc:brand_error('Identité raccourci : '+path+' : '+str(exc))
        return done
    except (OSError,ValueError,subprocess.TimeoutExpired) as exc:
        brand_error(exc);return 0


def install_window_icon(window):
    import tkinter as tk
    # Keep PhotoImage references alive for every Tk size and child dialog.
    window._craft_icon_images = [tk.PhotoImage(master=window, data=PNG_IMAGES[s])
                                 for s in (256, 128, 64, 48, 32, 24, 16)]
    window.iconphoto(True, *window._craft_icon_images)
    if os.name == 'nt':
        try:
            icon = ensure_icon()
            window.iconbitmap(default=str(icon))
            window.after(100,lambda:set_native_window_icon(window,icon))
            window.after(600,lambda:set_native_window_icon(window,icon))
            __import__('ui_widgets').bind_own(window,'<Map>',lambda e:window.after_idle(lambda:set_native_window_icon(window,icon)) if e.widget is window else None)
            from app_paths import application_directory
            threading.Thread(target=refresh_shortcuts,args=(application_directory(),icon),daemon=True).start()
        except (OSError, tk.TclError) as exc:
            brand_error(exc)  # Embedded PNG remains usable if the Shell fails.

def set_native_window_icon(window,icon):
    """Set both icon sizes on Tk's outer HWND (the Windows taskbar window)."""
    if os.name!='nt':return
    import ctypes
    from ctypes import wintypes
    user=ctypes.windll.user32
    user.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT];user.GetAncestor.restype=wintypes.HWND
    user.LoadImageW.argtypes=[wintypes.HINSTANCE,wintypes.LPCWSTR,wintypes.UINT,ctypes.c_int,ctypes.c_int,wintypes.UINT];user.LoadImageW.restype=wintypes.HANDLE
    user.SendMessageW.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM];user.SendMessageW.restype=wintypes.LPARAM
    try:
        hwnd=user.GetAncestor(window.winfo_id(),2);handles=[]
        for kind,size in ((0,16),(1,32)):
            handle=user.LoadImageW(None,str(icon),1,size,size,0x10)
            if handle:user.SendMessageW(hwnd,0x80,kind,handle);handles.append(handle)
        from windows_identity import set_window_identity
        command=subprocess.list2cmdline([sys.executable]) if getattr(sys,'frozen',False) else subprocess.list2cmdline([sys.executable,'-E',str(Path(__file__).resolve().with_name('Lancer.pyw'))])
        try:set_window_identity(hwnd,APP_ID,command,icon)
        except OSError as exc:brand_error(exc)
        previous=getattr(window,'_native_icons',[]);window._native_icons=handles
        user.DestroyIcon.argtypes=[wintypes.HANDLE]
        for handle in previous:user.DestroyIcon(handle)
    except (OSError,ValueError) as exc:brand_error(exc)
