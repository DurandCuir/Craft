"""Compose the existing application once, with common source/frozen diagnostics."""
import os
import sys
import time
import traceback
from pathlib import Path
from app_paths import application_directory, is_frozen, running_directory, user_data_directory

# 0.19.5: when the start reached each step (time.perf_counter), for « Démarrage » in diagnostic.txt.
MARKS = {'start': time.perf_counter(), 'wall': time.time()}


def process_age():
    """Seconds since this process was created (Windows: Python's own start before Craft's first
    line), None elsewhere."""
    if os.name != 'nt':
        return None
    try:
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32')   # its own prototypes (a handle is 64 bits wide)
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        kernel.GetCurrentProcess.argtypes = []
        kernel.GetProcessTimes.restype = wintypes.BOOL
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        times = [wintypes.FILETIME() for _ in range(4)]
        if not kernel.GetProcessTimes(kernel.GetCurrentProcess(), *[ctypes.byref(t) for t in times]):
            return None
        created = ((times[0].dwHighDateTime << 32) | times[0].dwLowDateTime) / 1e7 - 11644473600
        return max(0., time.time() - created)
    except Exception:
        return None


MARKS['python'] = process_age()


def compiled_now(folder=None):
    """0.19.6: how many of Craft's modules Python compiled during this start (their __pycache__ file
    written since it began): many after an update, none otherwise."""
    began = MARKS.get('wall')
    if began is None:
        return 0
    try:
        cache = Path(folder or Path(__file__).resolve().parent) / '__pycache__'
        return sum(1 for p in cache.glob('*.pyc') if p.stat().st_mtime >= began - 1)
    except OSError:
        return 0


def startup_summary():
    """0.19.5: « Démarrage : 1,4 s (Python 0,2 s · modules 0,3 s · fenêtre 0,6 s · plan 0,3 s) »: until
    the plan is first drawn smooth; None when Craft was not started by main(). 0.19.6: the upkeep done once
    after an update (« entretien ») and the modules compiled at this start, when there are some."""
    if not all(k in MARKS for k in ('modules', 'window', 'ready')):
        return None
    def s(v):
        return f'{v:.1f}'.replace('.', ',') + ' s'
    python = MARKS.get('python')
    upkeep = MARKS.get('maintenance')
    upkeep = upkeep if upkeep and upkeep - MARKS['start'] >= .05 else None   # shown when it counts (after an update)
    parts = ([f'Python {s(python)}'] if python is not None else []) + ([f'entretien {s(upkeep - MARKS["start"])}'] if upkeep else []) + [
        f'modules {s(MARKS["modules"] - (upkeep or MARKS["start"]))}', f'fenêtre {s(MARKS["window"] - MARKS["modules"])}',
        f'plan {s(MARKS["ready"] - MARKS["window"])}']
    n = compiled_now()
    if n:
        parts.append(f'{n} module{"s" * (n > 1)} compilé{"s" * (n > 1)}')
    return f'Démarrage : {s((python or 0) + MARKS["ready"] - MARKS["start"])} (' + ' · '.join(parts) + ')'


def application_class():
    # Preserve this order: layers override each other's event handlers.
    from atelier_core import App
    from workspace_ui import create_app
    from craft_studio import extend
    from craft_refined import refine
    from craft_workbench import enhance
    return enhance(refine(extend(create_app(App))))


def reopen_path(arguments):
    if '--reopen' in arguments:
        index = arguments.index('--reopen') + 1
        return arguments[index] if index < len(arguments) else None
    # 0.18.0: a double-click on a .crft (or an old .patron, a DXF, a DWG) starts Craft with it.
    from doc_files import OPENABLE
    return arguments[0] if arguments and arguments[0].lower().endswith(OPENABLE) else None


def main(arguments=None):
    arguments = list(sys.argv[1:] if arguments is None else arguments)
    for key in ('TCL_LIBRARY', 'TK_LIBRARY'):
        if not is_frozen():  # PyInstaller's Tk hook sets these for its bundled runtime.
            os.environ.pop(key, None)
    lock = running_directory() / (str(os.getpid()) + '.json')
    reopen = reopen_path(arguments)
    if reopen and '--reopen' not in arguments and Path(reopen).is_file():
        # 0.18.0: Craft is already open: the file opens there, in a new tab.
        try:
            from doc_files import hand_over
            if hand_over(running_directory(), reopen):
                return 0
        except OSError:
            pass
    try:
        lock.parent.mkdir(parents=True, exist_ok=True)
        lock.write_text(str(os.getpid()), encoding='ascii')
        if not is_frozen():
            if os.name == 'nt':
                # 0.18.0: libredwg-0.dll copied in two parts is put back together first.
                try:
                    from exchange import assemble_library
                    assemble_library(application_directory())
                except Exception:
                    pass
            from updater import maintain_installation
            maintain_installation(application_directory())
        MARKS['maintenance'] = time.perf_counter()   # 0.19.6
        cls = application_class()
        MARKS['modules'] = time.perf_counter()
        app = cls()
        MARKS['window'] = time.perf_counter()
        if '--smoke-test' in arguments:
            app.withdraw()
            app.update_idletasks()
            app.destroy()
            return 0
        if reopen and Path(reopen).is_file():
            # 0.18.0: the same path as « Ouvrir… » (.crft, .patron, DXF or DWG), base scale (0.17.0).
            app.after(150, lambda: app.open_path(reopen, remember=False if '--reopen' in arguments else True))
        app.mainloop()
        return 0
    except Exception:
        details = traceback.format_exc()
        log = user_data_directory() / 'Demarrage.log'
        try:
            log.parent.mkdir(parents=True, exist_ok=True)
            log.write_text(details, encoding='utf-8')
        except OSError:
            pass
        if os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, 'Craft ne peut pas démarrer.\n\n' + details[-1800:] + '\n\nJournal : ' + str(log), 'Craft', 16)
        else:
            sys.stderr.write(details)
        return 1
    finally:
        try:
            lock.unlink(missing_ok=True)
        except OSError:
            pass
