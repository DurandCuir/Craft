"""Windows Shell identity, using only ctypes and documented IPropertyStore APIs."""
import ctypes
import os
import uuid
from contextlib import contextmanager
from pathlib import Path


class GUID(ctypes.Structure):
    _fields_ = [('data', ctypes.c_ubyte * 16)]

    @classmethod
    def parse(cls, value):
        return cls.from_buffer_copy(uuid.UUID(value).bytes_le)


class PROPERTYKEY(ctypes.Structure):
    _fields_ = [('fmtid', GUID), ('pid', ctypes.c_uint32)]


class Blob(ctypes.Structure):
    _fields_ = [('size', ctypes.c_uint32), ('data', ctypes.c_void_p)]


class VariantValue(ctypes.Union):
    _fields_ = [('text', ctypes.c_void_p), ('blob', Blob), ('number', ctypes.c_uint64)]


class PROPVARIANT(ctypes.Structure):
    _fields_ = [('vt', ctypes.c_uint16), ('reserved', ctypes.c_uint16 * 3), ('value', VariantValue)]


IID_STORE = GUID.parse('886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99')
APP_PROPERTIES = '9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3'
HRESULT = ctypes.c_int32


def check(result):
    if result < 0:
        raise OSError(f'Windows Shell HRESULT 0x{result & 0xffffffff:08x}')


def method(address, slot, result, *arguments):
    table = ctypes.cast(address, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
    prototype = getattr(ctypes, 'WINFUNCTYPE', ctypes.CFUNCTYPE)
    return prototype(result, ctypes.c_void_p, *arguments)(table[slot])


def write_properties(store, properties):
    """Write caller-owned string buffers; SetValue copies the PROPVARIANT."""
    setter = method(store, 6, HRESULT, ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT))
    for pid, text in properties:
        buffer = ctypes.create_unicode_buffer(text)
        value = PROPVARIANT()
        value.vt = 31  # VT_LPWSTR
        value.value.text = ctypes.cast(buffer, ctypes.c_void_p)
        key = PROPERTYKEY(GUID.parse(APP_PROPERTIES), pid)
        check(setter(store, ctypes.byref(key), ctypes.byref(value)))
    check(method(store, 7, HRESULT)(store))


@contextmanager
def com_store(path=None, hwnd=None):
    if os.name != 'nt':
        raise OSError('Windows Shell is only available on Windows')
    ole = ctypes.windll.ole32
    initialized = ole.CoInitializeEx(None, 2)
    address = ctypes.c_void_p()
    try:
        shell = ctypes.windll.shell32
        if path is not None:
            fn = shell.SHGetPropertyStoreFromParsingName
            fn.argtypes = [ctypes.c_wchar_p, ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
            fn.restype = HRESULT
            check(fn(str(Path(path).resolve()), None, 2, ctypes.byref(IID_STORE), ctypes.byref(address)))
        else:
            fn = shell.SHGetPropertyStoreForWindow
            fn.argtypes = [ctypes.c_void_p, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
            fn.restype = HRESULT
            check(fn(hwnd, ctypes.byref(IID_STORE), ctypes.byref(address)))
        yield address
    finally:
        if address:
            method(address, 2, ctypes.c_uint32)(address)
        if initialized in (0, 1):
            ole.CoUninitialize()


def set_shortcut_identity(path, app_id, icon=None):
    with com_store(path=path) as store:
        # A pinned shortcut can retain its own old RelaunchIconResource.
        properties=([(3,str(icon)+',0')] if icon is not None else [])+[(5,app_id)]
        write_properties(store,properties)
    notify_path(path)


def set_window_identity(hwnd, app_id, command, icon):
    # Relaunch properties precede ID, whose change notifies the taskbar.
    with com_store(hwnd=hwnd) as store:
        write_properties(store, [(1, command), (2, 'Craft'), (3, str(icon) + ',0'), (5, app_id)])


def notify_path(path):
    if os.name == 'nt':
        fn = ctypes.windll.shell32.SHChangeNotify
        fn.argtypes = [ctypes.c_int32, ctypes.c_uint32, ctypes.c_wchar_p, ctypes.c_void_p]
        fn(0x2000, 0x1005, str(Path(path).resolve()), None)
