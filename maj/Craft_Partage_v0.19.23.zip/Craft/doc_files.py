"""0.18.0: Craft's own file type (.crft), the file windows written like other software
(« Patron Craft (*.crft) »), recent files, the last folder, the double-click on a .crft
(Windows association for this user only) and the hand-over of a file to the Craft already open.

An old .patron is read, never written: « Enregistrer » makes a .crft beside it.
0.18.1: the crans of any opened pattern are drawn like Mozart's (current_crans)."""
import copy
import json
import os
import sys
import time
import uuid
from pathlib import Path

EXT = '.crft'
OLD = '.patron'
OPENABLE = ('.crft', '.patron', '.dxf', '.dwg')
# 0.18.1: DWG and DXF are two formats, each its own line; the obsolete .patron is no longer
# offered (it still opens through « Tous les fichiers », by a double-click or a drop).
OPEN_TYPES = [('Tous les formats (*.crft, *.dwg, *.dxf)', '*.crft *.dwg *.dxf'),
              ('Patron Craft (*.crft)', '*.crft'),
              ('DWG (*.dwg)', '*.dwg'),
              ('DXF (*.dxf)', '*.dxf'),
              ('Tous les fichiers (*.*)', '*.*')]
SAVE_TYPES = [('Patron Craft (*.crft)', '*.crft')]
RECENT_MAX = 8
PROG_ID = 'Craft.Patron'


def export_types(kind):
    kind = kind.lower().lstrip('.')
    return [(kind.upper() + ' (*.' + kind + ')', '*.' + kind)]


def crft_name(file):
    """The name Craft writes: always a .crft (« dessin.patron » becomes « dessin.crft »)."""
    p = Path(file)
    if p.suffix.lower() == EXT:
        return str(p)
    return str(p.with_suffix(EXT)) if p.suffix.lower() == OLD else str(p) + EXT


# ------------------------------------------------------------------ recent files, last folder
def recent(prefs):
    return [f for f in prefs.get('recent_files', []) if isinstance(f, str)][:RECENT_MAX]


def remember(prefs, file):
    """The file goes first in « Récents » and its folder becomes the last folder used."""
    try:
        file = str(Path(file).resolve())
    except OSError:
        file = str(file)
    key = os.path.normcase(file)
    prefs['recent_files'] = [file] + [f for f in recent(prefs) if os.path.normcase(f) != key][:RECENT_MAX - 1]
    prefs['last_folder'] = str(Path(file).parent)


def forget(prefs, file):
    key = os.path.normcase(str(file))
    prefs['recent_files'] = [f for f in recent(prefs) if os.path.normcase(f) != key]


def remember_folder(prefs, file):
    if file:
        prefs['last_folder'] = str(Path(file).resolve().parent)


def initial_dir(prefs):
    folder = prefs.get('last_folder')
    return folder if isinstance(folder, str) and folder and Path(folder).is_dir() else None


def recent_labels(files):
    """Menu labels: the file name, with its folder when two files have the same name."""
    names = [Path(f).name for f in files]
    return [name + ('  (' + Path(f).parent.name + ')' if names.count(name) > 1 else '') for name, f in zip(names, files)]


def document_dirty(doc):
    """0.18.1: a document tab has unsaved changes (drawing, base, picture or Infos du modèle)."""
    return (doc.get('items') != doc.get('clean') or doc.get('workspace') != doc.get('clean_workspace')
            or doc.get('background') != doc.get('clean_background') or doc.get('infos') != doc.get('clean_infos'))


# ------------------------------------------------------------------ crans of older files
def current_crans(items):
    """0.18.1: crans drawn like Mozart's. A cross cran of an older pattern takes Mozart's shape
    (bar, cap and cut stem); at a size the Cran tool gave (12, 14,4 or 15 mm) it becomes 18 mm,
    another length is kept. The items given are not changed."""
    from craft_tools import CRAN, OLD_CRAN_DEPTHS, cran_form, cran_settings, reshaped_cran
    from curves import parts

    def length(depth):
        return CRAN['depth'] if any(abs(depth - d) < .05 for d in OLD_CRAN_DEPTHS) else depth

    out = []
    for s in items:
        if s.get('is_notch'):
            strokes = parts(s) if s.get('components') else [s]
            form = cran_form(strokes) if len(strokes) == 3 else None
            out.append(reshaped_cran(s, length(form['depth'])) if form else s)
            continue
        marks = s.get('notches')
        if marks and any(m.get('kind') == 'cross' and m.get('cap_width') and not m.get('gap') for m in marks):
            s = copy.deepcopy(s)
            for mark in s['notches']:
                if mark.get('kind') == 'cross' and mark.get('cap_width') and not mark.get('gap'):
                    mark.update(cran_settings(length(float(mark.get('depth', 3)))))
        out.append(s)
    return out


def current_zones(items):
    """0.18.1: a zone typed Parage / Surcoupe before is a Surcoupe zone (its own family now)."""
    out = []
    for s in items:
        prep = s.get('preparation')
        if prep and prep.get('kind') == 'parage' and str(prep.get('type', '')).strip().lower() == 'surcoupe':
            import preparations
            s = copy.deepcopy(s)
            s['preparation'] = dict(prep, kind='surcoupe', type='Surcoupe', thickness=None)
            s['preparation']['label'] = preparations.label('surcoupe', '', prep.get('length'))
            s['style'] = dict(s.get('style') or {}, color=preparations.BASE['surcoupe'])
        out.append(s)
    return out


# ------------------------------------------------------------------ double-click on a .crft
def open_command():
    """The command Windows runs for a double-click: this Craft with the file."""
    from app_paths import application_directory, is_frozen
    if is_frozen():
        return '"' + sys.executable + '" "%1"'
    python = Path(sys.executable)
    windowed = python.with_name('pythonw.exe')
    if windowed.is_file():
        python = windowed
    return '"' + str(python) + '" "' + str(application_directory() / 'Lancer.pyw') + '" "%1"'


def register_file_type(icon=None):
    """HKCU\\Software\\Classes only (this user, no administrator): .crft opens with this Craft and
    shows its icon. Written only when something differs; returns True when it was written."""
    if os.name != 'nt':
        return False
    import winreg
    command = open_command()
    wanted = [('.crft', None, PROG_ID), (PROG_ID, None, 'Patron Craft'),
              (PROG_ID + r'\shell\open\command', None, command)]
    if icon:
        wanted.append((PROG_ID + r'\DefaultIcon', None, '"' + str(icon) + '",0'))
    changed = False
    for sub, name, value in wanted:
        key_path = r'Software\Classes' + '\\' + sub
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path) as key:
                current = winreg.QueryValueEx(key, name or '')[0]
        except OSError:
            current = None
        if current != value:
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path) as key:
                winreg.SetValueEx(key, name or '', 0, winreg.REG_SZ, value)
            changed = True
    if changed:
        try:
            import ctypes
            ctypes.windll.shell32.SHChangeNotify(0x08000000, 0, None, None)   # SHCNE_ASSOCCHANGED
        except Exception:
            pass
    return changed


# ------------------------------------------------------------------ one Craft at a time for a file
def other_craft(directory, own=None):
    """True when another Craft of this installation is running (its lock file and process)."""
    from updater import process_alive
    own = os.getpid() if own is None else own
    try:
        locks = list(Path(directory).glob('*.json'))
    except OSError:
        return False
    for lock in locks:
        if lock.stem.isdigit() and int(lock.stem) != own and process_alive(int(lock.stem)):
            return True
    return False


def hand_over(directory, file):
    """Give ``file`` to the Craft already open (it opens it in a tab); False when none is open."""
    if not other_craft(directory):
        return False
    request = Path(directory) / ('ouvrir-' + uuid.uuid4().hex + '.req')
    temp = request.with_suffix('.tmp')
    temp.write_text(json.dumps(dict(file=str(Path(file).resolve()))), encoding='utf-8')
    os.replace(temp, request)
    if os.name == 'nt':
        try:
            import ctypes
            ctypes.windll.user32.AllowSetForegroundWindow(-1)   # the open Craft may come to the front
        except Exception:
            pass
    return True


def take_requests(directory, max_age=120):
    """Files handed over by a double-click, oldest first; each request is taken once."""
    out = []
    try:
        requests = sorted(Path(directory).glob('ouvrir-*.req'), key=lambda p: p.stat().st_mtime)
    except OSError:
        return out
    for request in requests:
        mine = request.with_suffix('.taken' + str(os.getpid()))
        try:
            os.replace(request, mine)   # another Craft may take it first
        except OSError:
            continue
        try:
            if time.time() - mine.stat().st_mtime <= max_age:
                file = json.loads(mine.read_text(encoding='utf-8')).get('file')
                if isinstance(file, str):
                    out.append(file)
        except (OSError, ValueError):
            pass
        finally:
            try:
                mine.unlink()
            except OSError:
                pass
    return out
