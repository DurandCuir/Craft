"""0.19.7 « réorganise les paramètres, genre créer une fenêtre avec tous les réglages possibles comme ça peut
être fait sur d'autres logiciels »: one « Réglages » window (menu Réglages, command « op »).

The topics on the left, their settings on the right, a search box over all of them; every change is seen at
once on the plan; Valider keeps them, Annuler puts back what this window changed, « Valeurs par défaut » the
settings of the topic shown. The settings that have a window of their own (types of lines, columns of the
base, the strap tools…) open it from here (« Régler… »)."""
import tkinter as tk
import unicodedata
from tkinter import colorchooser, ttk

PAGES = ('Affichage', 'Curseur et accroches', 'Dessin', 'Base', 'Outils', 'Impression et PDF', 'Interface')
SNAP_KEYS = ('endpoint', 'midpoint', 'quarter', 'center', 'intersection', 'quadrant', 'nearest', 'guides',
             'extension', 'perpendicular', 'tangent', 'parallel', 'centroid', 'node')   # 0.19.13: as his AutoCAD
DEFAULT_SNAPS = ('endpoint', 'midpoint', 'center', 'intersection', 'extension')   # 0.19.13: Quadrant unchecked, Extension checked


def normalize(text):
    return ''.join(c for c in unicodedata.normalize('NFKD', text.casefold()) if not unicodedata.combining(c))


class Setting:
    """One setting: its topic, label, kind ('check', 'choice', 'number', 'color', 'action'), how it is read
    and set on the app, its default (None: none) and, for a choice, its values (value, label)."""

    def __init__(self, page, label, kind, get=None, put=None, default=None, values=(), low=None, high=None, unit='', action=None, auto=False):
        self.page, self.label, self.kind, self.get, self.put, self.default = page, label, kind, get, put, default
        self.values, self.low, self.high, self.unit, self.action, self.auto = values, low, high, unit, action, auto


# --- How each setting is read and applied --------------------------------------------------------

def _pref(key, fallback):
    return lambda app: app.prefs.get(key, fallback)


def _keep(app):
    try:
        app.persist_preferences()
    except OSError:
        pass


def _put_pref(key, then=None):
    def put(app, value):
        app.prefs[key] = value
        _keep(app)
        if then:
            then(app)
    return put


def _palette(key):
    def put(app, value):
        from ui_widgets import auto_palette
        app.prefs[key] = value
        app.p = auto_palette(app.prefs)
        _keep(app)
        if app.__dict__.get('_settings_batch') is not None:
            app._settings_batch = True   # several put back by Annuler: the window is made again once, after
        else:
            app.rebuild_ui()
    return put


def _var(name, then):
    def get(app):
        return bool(getattr(app, name).get())

    def put(app, value):
        getattr(app, name).set(bool(value))
        then(app)
    return get, put


def _grid_then(app):
    app.update_toggle_labels()
    _keep(app)
    app.redraw()


def _spacing_get(app):
    try:
        return float(str(app.spacing.get()).replace(',', '.'))
    except (ValueError, tk.TclError):
        return 1.


def _spacing_put(app, value):
    app.spacing.set(f'{value:g}')
    app.redraw()


def _hints_get(app):
    return bool(app.prefs.get('cursor_hints', True))


def _hints_put(app, value):
    app.cursor_hints_var.set(bool(value))
    app.toggle_cursor_hints()


def _preparations_put(app, value):
    import preparation_ui
    if preparation_ui.visible(app) != bool(value):
        preparation_ui.toggle(app)


def _cuts_put(app, which, value):
    import preparation_ui
    if preparation_ui.cut_visible(app, which) != bool(value):
        preparation_ui.toggle_cut(app, which)


def _smooth_put(app, value):
    app.prefs['smooth_display'] = bool(value)
    _keep(app)
    app.refresh()


def _snap_kind(key):
    def get(app):
        return bool(app.snap_vars[key].get())

    def put(app, value):
        app.snap_vars[key].set(bool(value))
        app.snap_change()
    return get, put


def _units_put(app, value):
    if app.units.get() != value:
        app.units.set(value)
        app.unit_change()


def _attr(name, fallback):
    # 0.19.9: kept in the preferences too (they were on Craft only: back to their default at the next start)
    return (lambda app: float(getattr(app, name, fallback))), (lambda app, value: app.keep_tool_value(name, float(value)))


def _tool_window(name):
    def opener(app):
        if name == 'belt_holes':
            return __import__('belt_holes_ui').dialog(app)
        return getattr(__import__('strap_ui'), name)(app)
    return opener


def settings(app):
    """Every setting, by topic, in the order shown."""
    from workspace_ui import SNAP_NAMES
    out = [
        Setting('Affichage', 'Fond du dessin', 'color', _pref('canvas', '#101215'), _palette('canvas'), '#101215'),
        Setting('Affichage', 'Fond des barres d’outils', 'color', _pref('panel', '#202429'), _palette('panel'), '#202429'),
        Setting('Affichage', 'Repères de base', 'color', _pref('guides', '#e3df32'), _palette('guides'), '#e3df32'),
        Setting('Affichage', 'Sélection et aperçu', 'color', _pref('accent', '#61c9ee'), _palette('accent'), '#61c9ee'),
        Setting('Affichage', 'Taille des icônes (px)', 'choice', _pref('icon_size', 16), _palette('icon_size'), 16,
                values=[(v, str(v)) for v in (16, 20, 24, 32, 40)]),
        Setting('Affichage', 'Grille', 'check', *_var('grid', _grid_then), default=False),
        Setting('Affichage', 'Pas de la grille', 'number', _spacing_get, _spacing_put, 1., low=.01, high=1000, unit='mm'),
        Setting('Affichage', 'Préparations (parage, teinte…)', 'check', lambda app: bool(app.prefs.get('show_preparations', True)), _preparations_put, True),
        Setting('Affichage', 'Précoupes', 'check', lambda app: bool(app.prefs.get('show_precuts', True)), lambda app, v: _cuts_put(app, 'precut', v), True),
        Setting('Affichage', 'Surcoupes (pièces dans leur précoupe)', 'check', lambda app: bool(app.prefs.get('show_recuts', True)), lambda app, v: _cuts_put(app, 'recut', v), True),
        Setting('Affichage', 'Aides près du curseur', 'check', _hints_get, _hints_put, True),
        Setting('Affichage', 'Plan lissé (traits nets)', 'check', lambda app: bool(app.prefs.get('smooth_display', True)), _smooth_put, True),
        Setting('Curseur et accroches', 'Longueur des bras de la croix (0 = tout le plan)', 'number', _pref('cross_size', 90),
                _put_pref('cross_size', lambda app: app.draw_crosshair()), 90., low=0, high=3000, unit='px'),
        Setting('Curseur et accroches', 'Épaisseur de la croix', 'number', _pref('cross_width', 1),
                _put_pref('cross_width', lambda app: app.draw_crosshair()), 1., low=.5, high=5, unit='px'),
        Setting('Curseur et accroches', 'Carré central', 'number', _pref('cross_box', 6),
                _put_pref('cross_box', lambda app: app.draw_crosshair()), 6., low=0, high=40, unit='px'),
        Setting('Curseur et accroches', 'Couleur de la croix', 'color', _pref('cross_color', 'auto'),
                _put_pref('cross_color', lambda app: app.draw_crosshair()), 'auto', auto=True),
        Setting('Curseur et accroches', 'Accroches', 'check', *_var('snap', lambda app: app.snap_change()), default=True),
    ]
    for key in SNAP_KEYS:
        if key in getattr(app, 'snap_vars', {}):
            out.append(Setting('Curseur et accroches', '   ' + SNAP_NAMES.get(key, key), 'check', *_snap_kind(key), default=key in DEFAULT_SNAPS))
    out += [
        Setting('Curseur et accroches', 'Couleur des accroches', 'color', _pref('anchor_color', '#efcf4b'),
                _put_pref('anchor_color', lambda app: app.redraw()), '#efcf4b'),
        Setting('Curseur et accroches', 'ORTHO (horizontal / vertical)', 'check', *_var('ortho', lambda app: app.settings_changed()), default=False),
        Setting('Dessin', 'Unités de saisie et des cotes', 'choice', lambda app: app.units.get(), _units_put, 'mm',
                values=[('mm', 'Millimètres (mm)'), ('cm', 'Centimètres (cm)')]),
        Setting('Dessin', 'Hauteur du nom de pièce', 'number', _pref('annotation_name_size', 3), _put_pref('annotation_name_size'), 3., low=.5, high=30, unit='mm'),
        Setting('Dessin', 'Hauteur du texte Matière', 'number', _pref('annotation_material_size', 3), _put_pref('annotation_material_size'), 3., low=.5, high=30, unit='mm'),
        Setting('Dessin', 'Types de lignes et épaisseurs', 'action', action=lambda app: app.edit_line_types()),
        Setting('Base', 'Colonnes et hauteur de la base', 'action', action=lambda app: app.workspace_dialog()),
        Setting('Outils', 'Arrondi : rayon', 'number', *_attr('fillet_radius', 1.), default=1., low=.001, high=50000, unit='mm'),
        Setting('Outils', 'Chanfrein : distance', 'number', *_attr('angle_value', 3.), default=3., low=.001, high=50000, unit='mm'),
        Setting('Outils', 'Bout rond : début de l’arrondi (0 = demi-cercle)', 'number', *_attr('round_depth', 0.), default=0., low=0, high=100000, unit='mm'),
        Setting('Outils', 'Bout pointu : longueur de la pointe (0 = 45°)', 'number', *_attr('point_length', 0.), default=0., low=0, high=100000, unit='mm'),
        Setting('Outils', 'Piqûre : distance du bord', 'number', _pref('stitch_distance', 2.5), _put_pref('stitch_distance'), 2.5, low=0, high=100, unit='mm'),
        # 0.19.13: the points per cm (« on calcule tjrs au cm »), kept as the pitch in mm
        Setting('Outils', 'Piqûre : points par cm', 'number', lambda app: round(10 / app.prefs.get('stitch_pitch', 10 / 3), 2),
                lambda app, v: _put_pref('stitch_pitch')(app, 10 / v), 3., low=.5, high=20, unit='points'),
        Setting('Outils', 'Bout de ceinture', 'action', action=_tool_window('belt_dialog')),
        Setting('Outils', 'Trous de ceinture', 'action', action=_tool_window('belt_holes')),
        Setting('Outils', 'Fente d’ardillon', 'action', action=_tool_window('slot_dialog')),
        Setting('Outils', 'Sangle entière', 'action', action=_tool_window('piece_dialog')),
        Setting('Impression et PDF', 'Papier', 'choice', _pref('pdf_paper', 'A4'), _put_pref('pdf_paper'), 'A4',
                values=[(v, v) for v in ('A4', 'A3', 'A2', 'A1', 'A0')]),
        Setting('Impression et PDF', 'Marge', 'number', _pref('pdf_margin', 10.), _put_pref('pdf_margin'), 10., low=3, high=30, unit='mm'),
        Setting('Impression et PDF', 'Écart entre les pièces', 'number', _pref('pdf_gap', 5.), _put_pref('pdf_gap'), 5., low=1, high=50, unit='mm'),
        Setting('Impression et PDF', 'Pièces au plus serré', 'check', lambda app: bool(app.prefs.get('pdf_tight', False)), _put_pref('pdf_tight'), False),
        Setting('Impression et PDF', 'Impression en noir et blanc', 'check', lambda app: bool(app.prefs.get('print_mono', False)), _put_pref('print_mono'), False),
        Setting('Interface', 'Mon profil d’interface (disposition des outils)', 'action', action=lambda app: app.interface_profile_dialog()),
    ]
    return out


# --- The window ------------------------------------------------------------------------------------

def open_settings(app, page=None):
    """The Réglages window (one at a time), on ``page`` or the topic seen last."""
    st = app.__dict__.get('_settings_window')
    if st and st['win'].winfo_exists():
        if page:
            st['page'] = page
            fill(app, st)
        st['win'].lift()
        st['win'].focus_force()
        return st['win']
    items = settings(app)
    st = dict(items=items, page=page or app.__dict__.get('_settings_page') or PAGES[0], query=None, initial={}, widgets={})
    for s in items:
        if s.get:
            try:
                st['initial'][id(s)] = s.get(app)
            except (tk.TclError, AttributeError, KeyError):
                pass
    app._settings_window = st
    build(app, st)
    return st['win']


def build(app, st):
    """The window itself (made again after a change of colours, with the values set so far)."""
    old = st.get('win')
    geometry = None
    if old is not None and old.winfo_exists():
        geometry = old.winfo_geometry()
        # 0.19.9: only its place, its size following the topic shown (the whole « WxH+X+Y » kept the size of the
        # topic seen at a change of colour: Valider hidden on a longer one), unless sized by hand
        if (old.winfo_width(), old.winfo_height()) == (old.winfo_reqwidth(), old.winfo_reqheight()):
            geometry = '+' + geometry.split('+', 1)[1]
        old.destroy()
    st['widgets'] = {}   # 0.19.9: the fields of the window before are gone (fill takes only those shown)
    win = app.dialog('Réglages')
    win.resizable(True, True)
    if geometry:
        win.geometry(geometry)
    st['win'] = win
    panel = app.p['panel']
    top = tk.Frame(win, bg=panel)
    top.pack(fill='x', padx=14, pady=(12, 6))
    app.label(top, 'Rechercher').pack(side='left')
    st['query'] = query = tk.StringVar(value='')
    search = app.entry(top, query, 28)
    search.pack(side='left', padx=8)
    body = tk.Frame(win, bg=panel)
    body.pack(fill='both', expand=True, padx=14)
    st['topics'] = topics = tk.Frame(body, bg=panel)
    topics.pack(side='left', fill='y', padx=(0, 12))
    st['pane'] = tk.Frame(body, bg=panel)
    st['pane'].pack(side='left', fill='both', expand=True)
    st['message'] = tk.StringVar(value='')
    tk.Label(win, textvariable=st['message'], bg=panel, fg='#e06c6c', font=('Segoe UI', 9)).pack(anchor='w', padx=14)
    buttons = tk.Frame(win, bg=panel)
    buttons.pack(fill='x', padx=14, pady=(6, 14))
    st['defaults'] = app.button(buttons, 'Valeurs par défaut', lambda: defaults(app, st))
    st['defaults'].pack(side='left')
    app.button(buttons, 'Valider', lambda: close(app, st, True)).pack(side='right')
    app.button(buttons, 'Annuler', lambda: close(app, st, False)).pack(side='right', padx=8)
    win.protocol('WM_DELETE_WINDOW', lambda: close(app, st, True))
    win.bind('<Escape>', lambda e: (close(app, st, False), 'break')[1])
    query.trace_add('write', lambda *a: fill(app, st))
    fill(app, st)
    search.focus_set()


def topic_buttons(app, st):
    import modern_style
    t = modern_style.tokens_for(app.p)
    for w in st['topics'].winfo_children():
        w.destroy()
    for name in PAGES:
        active = name == st['page'] and not st['query'].get().strip()
        pill = modern_style.make_pill(st['topics'], text=name, fill=t['raised'] if active else None, ink=t['text'] if active else t['muted'],
                                      hover='' if active else t['hover'], padx=12, pady=3, edge=t['outline'] if active else '')
        pill.pack(fill='x', pady=2)
        pill.bind('<Button-1>', lambda e, n=name: show_page(app, st, n))


def show_page(app, st, name):
    st['page'] = name
    app._settings_page = name
    if st['query'].get():
        st['query'].set('')   # (fill comes with it)
    else:
        fill(app, st)


def fill(app, st):
    """The settings of the topic shown, or those matching the search over all topics."""
    said = take_typed(app, st)   # 0.19.9: a number typed without Entrée was lost with its field (another topic, the search)
    topic_buttons(app, st)
    pane = st['pane']
    for w in pane.winfo_children():
        w.destroy()
    st['widgets'] = {}
    st['message'].set(said)
    text = normalize(st['query'].get().strip())
    if text:
        shown = [s for s in st['items'] if text in normalize(s.label) or text in normalize(s.page)]
        st['defaults'].configure(state='disabled')
        if not shown:
            app.label(pane, 'Aucun réglage ne contient « ' + st['query'].get().strip() + ' ».').grid(row=0, column=0, sticky='w')
            return
    else:
        shown = [s for s in st['items'] if s.page == st['page']]
        st['defaults'].configure(state='normal' if any(s.default is not None for s in shown) else 'disabled')
    for row, s in enumerate(shown):
        label = (s.page + ' › ' + s.label.strip()) if text else s.label
        place(app, st, pane, row, s, label)


def place(app, st, pane, row, s, label):
    import modern_style
    panel = app.p['panel']
    if s.kind == 'check':
        var = tk.BooleanVar(value=bool(read(app, s)))
        check = modern_style.make_check(pane, text=label, variable=var, bg=panel, fg=app.p['ui_ink'], selectcolor=app.field_background(),
                                        activebackground=panel, font=('Segoe UI', 10), command=lambda: apply(app, st, s, var.get()))
        check.grid(row=row, column=0, columnspan=3, sticky='w', pady=2)
        st['widgets'][id(s)] = var
        return
    app.label(pane, label).grid(row=row, column=0, sticky='w', pady=3, padx=(0, 10))
    if s.kind == 'choice':
        current = read(app, s)
        names = [text for _, text in s.values]
        var = tk.StringVar(value=next((text for value, text in s.values if str(value) == str(current)), names[0]))
        box = ttk.Combobox(pane, textvariable=var, values=names, width=18, state='readonly')
        box.grid(row=row, column=1, sticky='w', pady=3)
        box.bind('<<ComboboxSelected>>', lambda e: apply(app, st, s, next(value for value, text in s.values if text == var.get())))
        st['widgets'][id(s)] = var
    elif s.kind == 'number':
        var = tk.StringVar(value=number_text(read(app, s)))
        cell = tk.Frame(pane, bg=panel)
        cell.grid(row=row, column=1, sticky='w', pady=3)
        field = app.entry(cell, var, 9)
        field.pack(side='left')
        app.label(cell, s.unit).pack(side='left', padx=(4, 0))
        commit = lambda e=None: typed(app, st, s, var)
        field.bind('<Return>', lambda e: (commit(), 'break')[1])
        field.bind('<FocusOut>', commit)
        st['widgets'][id(s)] = var
    elif s.kind == 'color':
        value = read(app, s)
        frame = tk.Frame(pane, bg=panel)
        frame.grid(row=row, column=1, columnspan=2, sticky='w', pady=3)
        swatch = modern_style.make_button(frame, bg=value if value != 'auto' else panel, width=6, kind='swatch',
                                          command=lambda: pick(app, st, s))
        swatch.pack(side='left')
        if s.auto:
            app.button(frame, 'Automatique', lambda: apply(app, st, s, 'auto')).pack(side='left', padx=6)
            if value == 'auto':
                app.label(frame, 'automatique').pack(side='left', padx=4)
    else:
        app.button(pane, 'Régler…', lambda: tune(app, st, s)).grid(row=row, column=1, sticky='w', pady=3)


def read(app, s):
    try:
        return s.get(app)
    except (tk.TclError, AttributeError, KeyError):
        return s.default


def number_text(value):
    try:
        return f'{float(value):g}'.replace('.', ',')
    except (TypeError, ValueError):
        return ''


def typed(app, st, s, var):
    """A number typed: applied when it is in its range; refused (the value before shown again) otherwise."""
    if not st['win'].winfo_exists():
        return
    st['message'].set('')   # (what was said about a field before goes: this one is read now)
    text = var.get().strip().replace(',', '.')
    try:
        value = float(text)
        if not (s.low is None or value >= s.low) or not (s.high is None or value <= s.high):
            raise ValueError
    except ValueError:
        low, high = number_text(s.low), number_text(s.high)
        st['message'].set(f'{s.label.strip()} : de {low} à {high} {s.unit}.'.replace('  ', ' '))
        var.set(number_text(read(app, s)))
        return
    if abs(value - float(read(app, s) or 0)) > 1e-12:
        apply(app, st, s, value)


def take_typed(app, st):
    """0.19.9: the numbers typed in the fields shown and not yet taken (no Entrée: the field still had the
    keyboard) taken now, as Entrée would, before the fields go; gives what was refused ('' if nothing)."""
    said = ''
    for s in st['items']:
        var = st['widgets'].get(id(s))
        if s.kind == 'number' and var is not None and var.get().strip() != number_text(read(app, s)):
            typed(app, st, s, var)
            said = said or st['message'].get()
    return said


def pick(app, st, s):
    current = read(app, s)
    chosen = colorchooser.askcolor(current if current != 'auto' else None, parent=st['win'], title=s.label)[1]
    if chosen:
        apply(app, st, s, chosen)


def apply(app, st, s, value):
    """A change: on the plan at once; the window made again when the colours or the units changed."""
    st['message'].set('')
    try:
        s.put(app, value)
    except (ValueError, tk.TclError) as exc:
        st['message'].set(str(exc))
        return
    if s.kind == 'color' or s.put.__name__ == '_units_put' or s.label.startswith('Taille des icônes'):
        build(app, st)


def tune(app, st, s):
    """A setting with its own window: opened over this one, this one back after (the window opened is found
    when the action does not give it back)."""
    win = st['win']
    win.grab_release()
    before = set(app.winfo_children())
    sub = s.action(app)
    if not (isinstance(sub, tk.Toplevel) and sub.winfo_exists()):
        made = [w for w in app.winfo_children() if w not in before and isinstance(w, tk.Toplevel) and w is not win and w.winfo_exists()]
        sub = made[-1] if made else None
    if sub is not None:
        win.wait_window(sub)
    if win.winfo_exists():
        win.grab_set()
        win.focus_force()


def defaults(app, st):
    """The settings of the topic shown back to their values when Craft is new."""
    app._settings_batch = False   # 0.19.9: the colours and the icon size put back together: Craft's window made again once
    try:
        for s in st['items']:
            if s.page == st['page'] and s.default is not None and s.put is not None and read(app, s) != s.default:
                s.put(app, s.default)
    finally:
        again = app.__dict__.pop('_settings_batch', None)
    if again:
        app.rebuild_ui()
    build(app, st)


def close(app, st, keep):
    """Valider (keep; the window's X too) or Annuler: the settings this window changed put back as they were."""
    if keep and st['win'].winfo_exists():
        # a number typed but not yet taken (no Entrée, the field still focused): taken now; refused: the
        # window stays open with its message
        st['message'].set('')
        said = take_typed(app, st)   # 0.19.9: (shared with a change of topic)
        if said:
            st['message'].set(said)
            return
    if not keep:
        app._settings_batch = False
        try:
            for s in reversed(st['items']):
                before = st['initial'].get(id(s))
                if s.put is not None and id(s) in st['initial'] and read(app, s) != before:
                    try:
                        s.put(app, before)
                    except (ValueError, tk.TclError):
                        pass
        finally:
            again = app.__dict__.pop('_settings_batch', None)
        if again:
            app.rebuild_ui()   # the colours put back: the window made again once
    _keep(app)
    app._settings_window = None
    if st['win'].winfo_exists():
        st['win'].destroy()
    try:
        app.canvas.focus_set()
    except (AttributeError, tk.TclError):
        pass
