"""Craft curve tools, contextual options and predictable hover/toolbar feedback."""
import copy,math,re,uuid,tkinter as tk
from tkinter import simpledialog,colorchooser
from types import SimpleNamespace
from geometry import path,bounds,distance,validate
from cad import shape,polygon,object_anchors,intersections,circle_data
from curves import spline,arc,arc_three,arc_radius,bulge_arc,pointer_side,cubics,bezier,parts,parts_view,from_cubics
from precision_geometry import contour_length,contour_location,contour_slice,shifted,inside,primitives,at_primitive
from craft_tools import dimensions,aligned_annotation,style,cote_label,COTE_TEXT,COTE_ARROW,COTE_GAP
from editing import inherit,offset_vertex
from refined_icons import draw
from ui_widgets import zoom_tag,dash_px
# 0.16.29: « départ, fin et bombé » first (the default arc); the mouse sets the bulge.
CURVE_TOOLS={'arc_radius':'Arc (départ, fin, bombé)','arc_3p':'Arc (3 points)','arc_center':'Arc (centre)','spline_fit':'Spline (points)'}
ARC_STEPS={'arc_radius':('Choisir départ','Choisir fin','Bomber à la souris · rayon au clavier'),'arc_3p':('Choisir départ','Choisir point de passage','Choisir fin'),'arc_center':('Choisir centre','Choisir départ','Choisir fin')}
COTE_TOOLS={'dimension_aligned':'Cote','diameter':'Cote (diamètre)','arc_length':'Cote (longueur d’arc)','angle_dimension':'Cote (angle)'}
# 0.16.12: the grey guide beside the cursor is reserved for tools whose steps are
# not obvious. Simple drawing tools (ligne, rectangle, cercle…) show nothing there.
GUIDED_TOOLS=frozenset({'arc_3p','arc_center','arc_radius','spline_fit','ellipse_center','ellipse_box','ellipse_axis',
    'rect_rot','para','circle_3p','dimension','dimension_aligned','diameter','arc_length','angle_dimension','radius',
    'notch','copy_notch','move_anchor','copy','mirror','trim','extend','fillet','chamfer','corner','strap_round','strap_point','strap_belt','strap_piece','toron','passant','assembly','array_centre','stretch','break_point','belt_holes','buckle_slot','join',
    'offset_all','offset_part','offset_vertex','offset_edge','part_name','material','rect_path','rotate','scale','stitch','stitch_part','array'})
OVAL_STEPS={'ellipse_center':('Choisir centre','Choisir premier demi-axe','Choisir second demi-axe'),
    'ellipse_box':('Choisir premier coin','Choisir coin opposé'),
    'ellipse_axis':('Choisir début du grand axe','Choisir fin du grand axe','Choisir largeur')}
_COUNTER=re.compile(r'\d+\s+\S+\(s\)\s+sélectionné')
_READOUT=re.compile(r'\d\s*(mm|cm|°)(?!\w)')

def whole_arc_range(s,p):
    """0.16.26: an arc is stored as quarter-turn pieces; the arc-length dimension measures
    the whole arc (consecutive pieces on the same circle), not the piece under the pointer."""
    from precision_geometry import primitives,at_primitive
    qs=primitives(s);closed=path(s)[1];spans=[];travel=0.
    def same(u,q):
        tol=1e-6+1e-4*max(u['r'],q['r'])
        return math.dist(u['c'],q['c'])<=tol and abs(u['r']-q['r'])<=tol and (u['sweep']>0)==(q['sweep']>0)
    for q in qs:
        if q['sweep']:
            last=spans[-1] if spans else None
            if last and abs(last['end']-travel)<1e-7 and same(last,q):last['end']=travel+q['length'];last['prims'].append(q)
            else:spans.append(dict(c=q['c'],r=q['r'],sweep=q['sweep'],start=travel,end=travel+q['length'],prims=[q]))
        travel+=q['length']
    if closed and len(spans)>1 and spans[0]['start']<1e-7 and abs(spans[-1]['end']-travel)<1e-7 and same(spans[0],spans[-1]):
        first=spans.pop(0);spans[-1]['end']=travel+first['end'];spans[-1]['prims']+=first['prims']
    if not spans:return None,None
    near=lambda span:min(math.dist(p,at_primitive(q,t)) for q in span['prims'] for t in (0,.25,.5,.75,1))
    best=min(spans,key=near);return best['start'],best['end']

def finish_ui(Base):
 class Finished(Base):
    def __init__(self):
        self.curve_points=[];self.curve_radius=10.;self.arc_reverse=False;self.spline_closed=False;self.spline_edit=None;self.new_cote=[];self.cote_host=None;self.cote_origin=None;self._suspend_pointer=False;self._hover=None;self._dock_hint=None
        super().__init__()
    def before_build(self):
        super().before_build()
        # 0.19.5: set before the first build (they came after it, and the window was built a second time).
        from tkinter import font
        for name in ('TkDefaultFont','TkTextFont','TkMenuFont','TkHeadingFont','TkCaptionFont','TkSmallCaptionFont','TkIconFont','TkTooltipFont'):
            try:font.nametofont(name).configure(family='Segoe UI',size=10,weight='normal',slant='roman',underline=False,overstrike=False)
            except tk.TclError:pass
        self.option_add('*Font',__import__('modern_style').font(10))   # 0.19.0: Segoe UI Variable under Windows 11
    def configure_toolgroups(self):
        super().configure_toolgroups()
        self.toolgroups['Traits'].sort(key=lambda pair: {'external':0,'internal':1,'white':2}.get(pair[0],3))
        self.toolgroups['Géométrie'] += [('arc_radius',[(k,v,None) for k,v in CURVE_TOOLS.items() if k.startswith('arc')]),('spline_fit',[('spline_fit','Spline (points)',None)])]
        for key,variants in self.toolgroups['Mesures']:
            if key=='dimension':
                # 0.18.5: one « Cote » (the real distance between the 2 points; horizontal / vertical with ORTHO):
                # the aligned cote did the same and is gone; names « Cote (rayon) »… like the other variants.
                variants[:]=[('dimension','Cote',None),('radius','Cote (rayon)',None),('diameter','Cote (diamètre)',None),('arc_length','Cote (longueur d’arc)',None),('angle_dimension','Cote (angle)',None)]
    def small_icon(self,parent,icon,fn,tip):
        c=super().small_icon(parent,icon,fn,tip);c.craft_icon=icon;return c
    def build(self):
        super().build()
        from ui_widgets import keep_fonts_alive
        self._font_keep=keep_fonts_alive(self.canvas)
        self.object_tabs.pack_forget()
        for frame in self.root_frame.winfo_children():
            for tab in frame.winfo_children():
                for label in tab.winfo_children():
                    if isinstance(label,tk.Label) and label.cget('text')=='Objet':label.configure(text='Plan')
        # Pack rightmost first, then retain the existing order of the other controls.
        right=[w for w in self.footer.pack_slaves() if w.pack_info().get('side')=='right'];info=next((w for w in right if getattr(w,'craft_icon',None)=='info'),None)
        if info:
            ordered=[info]+[w for w in right if w is not info]
            options={w:w.pack_info() for w in ordered}
            for w in ordered:w.pack_forget()
            for w in ordered:
                opts=options[w];opts.pop('in',None);w.pack(**opts)
        menu=self.nametowidget(self.cget('menu'));export=self.menu(menu)
        for label,fn in [('PDF à taille réelle…',self.pdf),('DXF…',self.dxf),('SVG…',self.svg),('DWG…',self.dwg)]:export.add_command(label=label,command=fn)
        # Export remains discoverable in Fichier too, for older workflows.
        menu.insert_cascade(1,label='Exporter',menu=export)
        for i in range(menu.index('end')+1):
            if menu.type(i)=='cascade' and menu.entrycget(i,'label')=='Réglages':
                # 0.19.7 « réorganise les paramètres »: every setting in ONE window (settings_ui); here only it and ORTHO
                params=self.nametowidget(menu.entrycget(i,'menu'));params.delete(0,'end')
                params.add_command(label='Tous les réglages…',command=lambda:__import__('settings_ui').open_settings(self))
                params.add_checkbutton(label='Orthogonal  F8',variable=self.ortho,command=self.settings_changed)
                if not hasattr(self,'cursor_hints_var'):self.cursor_hints_var=tk.BooleanVar(master=self)
                self.cursor_hints_var.set(bool(self.prefs.get('cursor_hints',True)))
            if menu.type(i)=='cascade' and menu.entrycget(i,'label')=='Affichage':
                view=self.nametowidget(menu.entrycget(i,'menu'))
                for k in range(view.index('end'),-1,-1):
                    if view.type(k)=='command' and view.entrycget(k,'label')=='Couleurs et taille des icônes…':view.delete(k)   # in Réglages now
    def rebuild_tabs(self):
        super().rebuild_tabs()
        if hasattr(self,'tabbar'):
            for w in self.tabbar.winfo_children():
                if isinstance(w,tk.Button) and w.cget('text')=='+':w.configure(width=1,padx=3)
    def anchor_color_dialog(self):
        self._suspend_pointer=True;self.canvas.configure(cursor='arrow')
        try:color=colorchooser.askcolor(self.prefs.get('anchor_color','#efcf4b'),title='Couleur des accroches',parent=self)[1]
        finally:self._suspend_pointer=False
        if color:self.prefs['anchor_color']=color;self.persist_preferences();self.redraw()
    def display_menu(self):
        self._popup_anchor=next((w for w in self.footer.winfo_children() if getattr(w,'craft_icon',None)=='gear'),self.footer)
        try:return super().display_menu()
        finally:self._popup_anchor=None
    def popup_above(self,m,anchor):return super().popup_above(m,getattr(self,'_popup_anchor',None) or anchor)
    def snap_menu(self):
        from workspace_ui import SNAP_NAMES
        icons={};self._snap_images=[]
        for key in self.snap_vars:
            c=tk.Canvas(self,width=20,height=20);self.snap_symbol(c,key,10,10,self.p['ui_ink'])
            # Tiny native Tk bitmap drawn as pixels avoids platform font glyph differences.
            im=tk.PhotoImage(master=self,width=18,height=18)
            for item in c.find_all():
                coords=c.coords(item);typ=c.type(item)
                if typ in ('line','polygon'):
                    vertices=list(zip(coords[::2],coords[1::2]));vertices+=vertices[:1] if typ=='polygon' else []
                    for a,b in zip(vertices,vertices[1:]):
                        steps=max(1,round(math.dist(a,b)*2))
                        for j in range(steps+1):
                            x,y=round(a[0]+(b[0]-a[0])*j/steps),round(a[1]+(b[1]-a[1])*j/steps)
                            if 0<=x<18 and 0<=y<18:im.put(self.p['ui_ink'],(x,y))
                elif typ in ('rectangle','oval'):
                    x,y,X,Y=coords
                    for j in range(64):
                        if typ=='oval':xx=(x+X)/2+(X-x)/2*math.cos(j*math.pi/32);yy=(y+Y)/2+(Y-y)/2*math.sin(j*math.pi/32)
                        else:
                            t=j/16;xx,yy=(x+(X-x)*t,y) if t<1 else (X,y+(Y-y)*(t-1)) if t<2 else (X-(X-x)*(t-2),Y) if t<3 else (x,Y-(Y-y)*(t-3))
                        xx,yy=round(xx),round(yy)
                        if 0<=xx<18 and 0<=yy<18:im.put(self.p['ui_ink'],(xx,yy))
            c.destroy();icons[key]=im;self._snap_images.append(im)
        m=self.menu();m.add_checkbutton(label='Toutes les accroches · F3',variable=self.snap,command=self.snap_change);m.add_separator()
        for key,var in self.snap_vars.items():m.add_checkbutton(label=SNAP_NAMES[key],image=icons[key],compound='left',variable=var,command=self.snap_change)
        self.popup_above(m,self.snap_drop)
    def snap_symbol(self,c,kind,x,y,color,tags=()):
        kw=dict(fill=color,width=1.4,tags=tags)
        if kind=='endpoint':c.create_rectangle(x-3,y-3,x+3,y+3,outline=color,fill=color,width=1.4,tags=tags)
        elif kind=='midpoint':c.create_polygon(x-4,y+3,x,y-4,x+4,y+3,fill=color,outline=color,tags=tags)
        elif kind=='quarter':c.create_polygon(x-3,y+2,x,y-3,x+3,y+2,fill='',outline=color,width=1.4,tags=tags);c.create_line(x-5,y+5,x+5,y+5,**kw)   # 0.18.1
        elif kind in ('center','quadrant','nearest'):
            c.create_oval(x-3,y-3,x+3,y+3,outline=color,fill=color,width=1.4,tags=tags)
            if kind=='center':c.create_line(x-5,y,x+5,y,**kw);c.create_line(x,y-5,x,y+5,**kw)
            elif kind=='quadrant':c.create_line(x,y-5,x+5,y,x,y+5,x-5,y,x,y-5,**kw)
            else:c.create_line(x-5,y+4,x+5,y+4,**kw)
        elif kind=='intersection':c.create_line(x-4,y-4,x+4,y+4,**kw);c.create_line(x-4,y+4,x+4,y-4,**kw)
        # 0.19.13: the marks of AutoCAD's accroches
        elif kind=='perpendicular':c.create_line(x-5,y+4,x+5,y+4,**kw);c.create_line(x,y+4,x,y-5,**kw)
        elif kind=='tangent':c.create_oval(x-4,y-3,x+4,y+5,outline=color,width=1.4,tags=tags);c.create_line(x-6,y-4,x+6,y-4,**kw)
        elif kind=='parallel':c.create_line(x-5,y+4,x-1,y-4,**kw);c.create_line(x+1,y+4,x+5,y-4,**kw)
        elif kind=='extension':
            for k in (-6,-2,2):c.create_line(x+k,y,x+k+2,y,**kw)
            c.create_line(x+4,y-3,x+4,y+3,**kw)
        elif kind=='centroid':c.create_oval(x-4,y-4,x+4,y+4,outline=color,width=1.4,tags=tags);c.create_line(x-2,y,x+2,y,**kw);c.create_line(x,y-2,x,y+2,**kw)
        elif kind=='node':c.create_oval(x-4,y-4,x+4,y+4,outline=color,width=1.4,tags=tags);c.create_line(x-3,y-3,x+3,y+3,**kw);c.create_line(x-3,y+3,x+3,y-3,**kw)
        else:c.create_line(x-5,y,x+5,y,**kw);c.create_line(x,y-5,x,y+5,**kw)
    def modal_active(self):
        if self._suspend_pointer:return True
        try:
            g=self.grab_current();return g is not None and g.winfo_toplevel() is not self
        except tk.TclError:return False
    def dialog(self,title):
        self.canvas.configure(cursor='arrow');w=super().dialog(title);w.configure(cursor='arrow')
        def closed(e):
            if e.widget is w:self.after_idle(self.restore_pointer)
        w.bind('<Destroy>',closed,add='+');return w
    def restore_pointer(self):
        if self.winfo_exists() and hasattr(self,'canvas'):self.draw_crosshair()
    def draw_crosshair(self):
        if self.modal_active():
            self.pointer_cursor('arrow');self.canvas.delete('crosshair');self.canvas.delete('tool_cursor');return
        super().draw_crosshair()
        color=self.prefs.get('anchor_color','#efcf4b')
        for item in self.canvas.find_withtag('anchor_hint'):
            self.canvas.itemconfigure(item,**({'outline':color,'fill':color} if self.canvas.type(item) in ('rectangle','oval') else {'fill':color}))
        if self.tool.get()=='select' and not self.grip_drag and not getattr(self,'_contour_drag',None):
            self.canvas.delete('anchor_hint');self.canvas.delete('snap')
        self.draw_hover();self.canvas.tag_raise('spline_grips')
        self.canvas.delete('step_hint')
        text=self.cursor_hint()
        if text:
            # Below the 14 px tool icon drawn at +10/+12, so the first letter stays clear.
            # 0.18.5: from the crosshair (anchored point), like the icon, not from the real mouse.
            x,y=self.crosshair_screen() if hasattr(self,'crosshair_screen') else self.cursor_screen
            self.canvas.create_text(x+16,y+30,text=text,anchor='nw',fill='#8d9298',font=('Segoe UI',-11),tags='step_hint')
        review=getattr(self,'_export_review',None)
        if review:review.highlight()
    def cursor_hint(self):
        """Grey step guide beside the cursor, or '' when none is useful.
        Only multi-step tools are guided; the command name is never written."""
        t=self.tool.get()
        if self.__dict__.get('bg_tool') and self._inside_plan and self.prefs.get('cursor_hints',True):
            return __import__('background_ui').hint(self) or ''   # 0.18.0 Image de fond: Déplacer / Caler
        if not self._inside_plan or t not in GUIDED_TOOLS or not self.prefs.get('cursor_hints',True):return ''
        text=self.staged_hint(t)
        if text is None:
            # 0.18.0: no key reminders (« Entrée », « Échap »); counters and live measures are dropped.
            segments=[s.strip() for s in self.status.get().split(' · ')]
            text=' · '.join(s for s in segments if s and not _COUNTER.search(s) and not _READOUT.search(s) and 'Échap' not in s and 'Entrée' not in s)
        if text.startswith('Commande') or len(text)>80:return ''
        return text
    def staged_hint(self,t):
        """Guides for tools whose status line does not follow each click."""
        phase=self.__dict__.get('pick_phase')
        if phase and phase['tool']==t:
            from selection import PICK_PROMPT
            return PICK_PROMPT   # 0.19.21 Réseau, Joindre
        if t in ARC_STEPS:
            steps=ARC_STEPS[t];return steps[min(len(self.curve_points),len(steps)-1)]
        if t in OVAL_STEPS:
            steps=OVAL_STEPS[t];return steps[min(len(getattr(self,'oval_points',())),len(steps)-1)]
        if t in ('rect_rot','para','circle_3p'):
            n=len(self.stage_points) if self.start is not None else 0
            if t=='circle_3p':return f'Choisir point {min(n,2)+1} sur 3'
            return ('Choisir début de la base','Choisir fin de la base','Choisir hauteur' if t=='rect_rot' else 'Choisir troisième sommet')[min(n,2)]
        if t=='offset_edge':return 'Sélectionner ligne'
        if t in ('rotate','scale'):
            st=self.__dict__.get('xform')
            if st:
                from transform_ui import STEPS
                return STEPS[st['kind']][st['phase']]
        # 0.18.0: while choosing what a command works on, the same words as the first step.
        if t=='mirror' and self.__dict__.get('mirror_phase')=='selection':return 'Sélectionner ligne'
        if t=='copy' and (self.__dict__.get('copy_state') or {}).get('phase')=='selection':return 'Sélectionner ligne'
        if t=='copy_notch' and (self.__dict__.get('copy_crans') or {}).get('phase')=='selection':return 'Sélectionner crans'
        if t=='belt_holes':return 'Choisir autre bord' if ((self.__dict__.get('belt_state') or {}).get('first')) else 'Cliquer bout de sangle'   # 0.19.5
        if t=='buckle_slot':return 'Choisir autre bord' if ((self.__dict__.get('slot_state') or {}).get('first')) else 'Cliquer bout de sangle'   # 0.19.6
        if t=='strap_piece':return 'Choisir direction' if ((self.__dict__.get('strap_state') or {}).get('start')) else 'Cliquer bout côté boucle'
        if t=='toron':return 'Choisir direction' if ((self.__dict__.get('strap_state') or {}).get('start')) else 'Cliquer un bout'
        if t=='array_centre':return 'Cliquer le centre'   # 0.19.13
        if t=='passant':return 'Cliquer où le poser'
        if t=='stretch':st=self.__dict__.get('stretch_state') or {};n=len(st.get('corners',()));return 'Premier coin' if n==0 else 'Coin opposé' if n==1 else 'Point de base' if st.get('base') is None else "Point d'arrivée"
        if t=='break_point':return 'Cliquer où couper'
        if t=='assembly':st=self.__dict__.get('assembly_state') or {};return 'Cliquer bord 1' if not st.get('a') else ('Cliquer bord cousu dessus' if not st.get('b') else 'Maj + clic : ajouter un côté')   # 0.19.13
        return None
    def toggle_cursor_hints(self):
        self.prefs['cursor_hints']=bool(self.cursor_hints_var.get());self.persist_preferences()
        if hasattr(self,'canvas'):self.draw_crosshair()
    def draw_snap_point(self,p,kind):
        x,y=self.to_screen(p);self.snap_symbol(self.canvas,kind,x,y,self.prefs.get('anchor_color','#efcf4b'),('snap',))
    def draw_hover(self):
        self._hovered=None
        if not self._inside_plan or self.modal_active() or getattr(self,'_export_review',None):self.canvas.delete('hover');self._hover_key=None;return
        if self.hover_paused():
            self.canvas.delete('hover');self._hover_key=None
            if getattr(self,'anchors_wanted',lambda:False)():
                # 0.19.9: the anchor marks of the piece under the mouse stay while Déplacer / Copier / Symétrie aim (only
                # the outline goes); those previews keep the boxes between pointer events, so the search is cheap.
                self._hovered=self.pick(self.raw(SimpleNamespace(x=self.cursor_screen[0],y=self.cursor_screen[1])))
            return
        p=self.raw(SimpleNamespace(x=self.cursor_screen[0],y=self.cursor_screen[1]));i=self.pick(p);self._hovered=i
        if self.tool.get() in ('trim','extend'):
            self.canvas.delete('hover');self._hover_key=None;self.draw_edit_preview(p);return
        self.canvas.delete('edit_preview')
        s=self.items[i] if i is not None else None
        if s is not None and s.get('preparation'):self.canvas.delete('hover');self._hover_key=None;return   # 0.17.0: a zone is not outlined over its piece
        if s is not None and not s.get('annotation') and not s.get('is_notch'):
            # 0.16.15: the outline of a large piece is redrawn only when the hovered
            # shape or the view changes, not on every pointer move.
            from geometry import geometry_key
            key=(i,geometry_key(s),bool(s.get('drill')),self.scale,self.ox,self.oy,self.p['accent'])
            if key==self.__dict__.get('_hover_key') and self.canvas.find_withtag('hover'):return
            self.canvas.delete('hover');self._hover_key=key
        else:self.canvas.delete('hover');self._hover_key=None
        if s is not None and s.get('dimension_group'):
            # 0.16.30: the whole cote lights up (lines, arrows, value): it is one object.
            self.draw_cote_hover(s['dimension_group']);return
        if i is not None and self.items[i].get('annotation'):
            self.draw_shape(self.items[i],self.p['accent'],1,('hover',));self.canvas.tag_raise('hover');return
        if i is not None and not self.items[i].get('annotation'):
            # 0.16.28: the hovered line keeps its own colour (red cut, etc.) and just gets thicker.
            width=self.line_px()+1.6 if hasattr(self,'line_px') else 3.2
            s=self.items[i]
            for q in (parts_view(s) if s.get('is_notch') or s.get('components') else [s]):
                pts,closed=path(q);pts=pts+pts[:1] if closed else pts
                if len(pts)<2:continue
                dash=style(q)['dash'];extra=dict(dash=dash_px(dash,self.scale)) if dash else dict(capstyle='round')   # dashed lines stay dashed
                self.canvas.create_line(*[v for pt in pts for v in self.to_screen(pt)],fill=self.hover_colour(q if not s.get('is_notch') else s),width=width,joinstyle='round',tags=zoom_tag('hover','d',dash) if dash else 'hover',**extra)
    # 0.19.22 (proposed 11/11, « Propositions sont bien », GO 13/11/2026; like AutoCAD): while a selection rectangle
    # follows the mouse, what it will take is lit as under the mouse (thicker, in its own colour): blue (from left to
    # right) what is wholly inside, green (from right to left) what it touches. Only what changes is drawn again.
    def box_accepts(self,tag,s):
        """What the rectangle ``tag`` may take (Copier crans: crans; Réseau, Joindre: what they work on)."""
        return True
    LIT_EVERY=.04   # s: what the rectangle takes is worked out again at most 25 times a second (the box itself, at each move)
    def box_hits(self,tag,x,y,ex,ey,fresh=False):
        import time
        c=self.canvas;st=self.__dict__.get('_box_lit')
        key=(tag,getattr(self,'_redraws',0),self.scale,self.ox,self.oy)
        if fresh or st is None or st['key']!=key:
            if st is not None:
                c.delete(st['key'][0]+':lit')
                if st.get('job'):self.after_cancel(st['job'])
            st=self._box_lit=dict(key=key,drawn={},at=0.,job=None)
        st['due']=(tag,x,y,ex,ey);now=time.monotonic()
        if now-st['at']<self.LIT_EVERY:   # a moment later, with the box as it is then
            if not st['job']:st['job']=self.after(max(1,round((self.LIT_EVERY-(now-st['at']))*1000)),lambda:self.box_hits_due(st))
            return
        st['at']=now;self.light_box_hits(st,tag,x,y,ex,ey)
    def box_hits_due(self,st):
        st['job']=None
        if self.__dict__.get('_box_lit') is not st or not self.canvas.find_withtag(st['due'][0]+':edge'):return   # closed meanwhile
        import time
        st['at']=time.monotonic();self.light_box_hits(st,*st['due'])
    def light_box_hits(self,st,tag,x,y,ex,ey):
        from selection import select
        from geometry import pointer_frame
        c=self.canvas
        if math.hypot(ex-x,ey-y)<4:ids=set()
        else:
            a=self.raw(SimpleNamespace(x=x,y=y));b=self.raw(SimpleNamespace(x=ex,y=ey))
            try:
                with pointer_frame(self.items):ids={i for i in select(self.items,a,b) if self.box_accepts(tag,self.items[i])}   # the boxes kept
            except (ValueError,KeyError,TypeError,IndexError):ids=set()
        drawn=st['drawn']
        for i in [i for i in drawn if i not in ids]:
            for item in drawn.pop(i):c.delete(item)
        new=[i for i in sorted(ids) if i not in drawn]
        if not new:return
        import deep_zoom
        width=self.line_px()+1.6 if hasattr(self,'line_px') else 3.2;W,H=c.winfo_width(),c.winfo_height()
        X0,Y0=self.raw(SimpleNamespace(x=0,y=0));X1,Y1=self.raw(SimpleNamespace(x=W,y=H))
        with deep_zoom.drawing(self,fine=False):
            for i in new:
                s=self.items[i];made=[]
                try:
                    bx,by,BX,BY=bounds([s])
                    if BX<min(X0,X1) or bx>max(X0,X1) or BY<min(Y0,Y1) or by>max(Y0,Y1):drawn[i]=made;continue   # out of sight
                    for q in (parts_view(s) if s.get('is_notch') or s.get('components') else [s]):
                        pts,closed=path(q);pts=pts+pts[:1] if closed else pts
                        if len(pts)<2:continue
                        made.append(c.create_line(*[v for pt in pts for v in self.to_screen(pt)],fill=self.p['accent'] if s.get('annotation') else self.hover_colour(q if not s.get('is_notch') else s),
                                                  width=width,joinstyle='round',capstyle='round',tags=(tag,tag+':lit')))
                except (ValueError,KeyError,TypeError,IndexError,tk.TclError):pass
                drawn[i]=[m for m in made if m]
        try:c.tag_raise(tag+':edge')
        except tk.TclError:pass
    def hover_paused(self):
        """0.19.9: no hover outline (nor its search through every object at each move) while it means nothing: a grip
        dragged, the selection dragged, the preview of Déplacer / Copier / Rotation / Échelle / Symétrie (once the
        selection is done and the base point given; while choosing, it shows what a click takes). It also outlined
        the moved piece where it was."""
        d=self.__dict__;t=self.tool.get()
        if d.get('grip_drag') or (d.get('move_state') or {}).get('anchor') is not None:return True
        if t=='copy' and (d.get('copy_state') or {}).get('phase')=='place':return True
        if t in ('rotate','scale') and (d.get('xform') or {}).get('phase')=='value':return True
        if t=='mirror' and d.get('mirror_axis'):return True
        if d.get('_box_pending'):return True   # 0.19.21: a rectangle follows the mouse
        box=d.get('box_start');drag=d.get('_contour_drag')
        if t=='select' and box is not None:return bool(drag and drag.get('changed')) or box[3] is None and math.hypot(self.cursor_screen[0]-box[0],self.cursor_screen[1]-box[1])>=4
        return False
    def draw_cote_hover(self,group):
        width=self.line_px()+1.6;accent=self.p['accent']
        for q in self.items:
            if q.get('dimension_group')!=group:continue
            if q.get('annotation'):self.draw_shape(q,accent,1,('hover',));continue
            pts,closed=path(q)
            if len(pts)<2:continue
            if closed and not q.get('filled'):pts=pts+pts[:1]
            screen=[v for pt in pts for v in self.to_screen(pt)]
            if q.get('filled'):self.canvas.create_polygon(*screen,fill=accent,outline=accent,tags='hover')
            else:self.canvas.create_line(*screen,fill=accent,width=width,capstyle='round',joinstyle='round',tags='hover')
        self.canvas.tag_raise('hover')
    def hover_colour(self,s):
        if s.get('drill'):return '#cf5be5'
        colour=style(s)['color']
        return self.p['ink'] if colour=='auto' else colour
    def draw_edit_preview(self,p):
        from curves import removed_portions
        from editing import extend_line
        self.canvas.delete('edit_preview');t=self.tool.get();self._extend_gain=None
        if t not in ('trim','extend'):return
        i=self.pick(p)
        plans=[]
        try:
            if t=='trim':
                points=self.trim_stroke['points'] if self.trim_stroke else [p,p]
                for index,fragments in self.trim_replacements(points).items():
                    original=self.items[index];st=style(original);ink=self.p['ink'] if st['color']=='auto' else st['color']
                    ink=blend_color(ink,self.p['canvas'],.72)
                    plans.extend((q,ink,st) for q in removed_portions(original,fragments))
            elif i is not None:
                original=self.items[i];q=extend_line(original,[s for j,s in enumerate(self.items) if j!=i],p,15/self.scale)
                if q:
                    plans.extend((v,blend_color(self.p['ink'],self.p['canvas'],.48),style(original)) for v in removed_portions(q,[original]))
                    from craft_tools import perimeter
                    self._extend_gain=perimeter(q)-perimeter(original)   # 0.18.5: the length added, beside the cross
        except (ValueError,IndexError):return
        for q,color,st in plans:
            pts,closed=path(q);pts=pts+pts[:1] if closed else pts
            if len(pts)>1:
                # 0.18.5: the same width on the screen at every zoom, like the hover (it grew with the zoom).
                options=dict(fill=color,width=(self.line_px()+1.6) if hasattr(self,'line_px') else 3.2,joinstyle='round',tags='edit_preview')
                if st['dash']:options['dash']=dash_px(st['dash'],self.scale);options['tags']=zoom_tag(options['tags'],'d',st['dash'])
                else:options['capstyle']='round'
                self.canvas.create_line(*[v for pt in pts for v in self.to_screen(pt)],**options)
    def leave_plan(self,e=None):
        result=super().leave_plan(e);self.canvas.delete('hover');self.canvas.delete('object_anchors');self.canvas.delete('edit_preview');self.canvas.delete('live_value');return result
    def set_tool(self,t):
        if t=='dimension_aligned':t='dimension'   # 0.18.5: one Cote (an old choice or a repeated command lands there)
        if t in CURVE_TOOLS or t in COTE_TOOLS:
            if self._action:self.finish_action()
            self.cancel();self.tool.set(t);self.mode_label.set(CURVE_TOOLS.get(t) or COTE_TOOLS[t]);self.last_command=('tool',t);self.line_type='Plein';self.canvas.focus_set();self.status.set((CURVE_TOOLS.get(t) or COTE_TOOLS[t])+' : choisir le premier point ou tracé.');self.highlight_tools();return
        if t in ('offset_all','offset_part'):
            self._suspend_pointer=True;self.canvas.configure(cursor='arrow')
            try:return super().set_tool(t)
            finally:self._suspend_pointer=False;self.draw_crosshair()
        result=super().set_tool(t)
        if t in ('fillet','chamfer','corner','strap_round','strap_point','strap_belt'):self.status.set(self.corner_prompt(t))
        return result
    def corner_prompt(self,t):
        """What Arrondi, Chanfrein, Angle droit, Bout rond / pointu ask for (at their start and, 0.19.5, again
        after each raccord: they stay for the next one)."""
        if t=='fillet':return f'Rayon {self.fillet_radius:g} mm · clic droit pour régler · choisir deux lignes près du coin.'
        if t=='chamfer':return f'Chanfrein {self.angle_value:g} mm · clic droit pour régler · choisir deux lignes près du coin.'
        if t=='corner':return 'Choisir deux lignes près du coin.'
        if t=='strap_point':
            L=self.__dict__.get('point_length',0.)
            return (f'Pointe {L:g} mm' if L>0 else 'Pointe à 45°')+' · clic droit pour régler · cliquer le petit côté d’une pièce, ou ses deux bords près du bout.'   # 0.19.5
        if t=='strap_round':   # 0.19.6: the round starts this far from the end (0: a half round)
            d=self.__dict__.get('round_depth',0.)
            return (f'Arrondi à {d:g} mm du bout' if d>0 else 'Demi-cercle')+' · clic droit pour régler · cliquer le petit côté d’une pièce, ou ses deux bords près du bout.'
        if t=='strap_belt':return __import__('strap_ui').belt_prompt(self)   # 0.19.6
        return 'Cliquer le petit côté d’une pièce, ou ses deux bords près du bout.'   # 0.19.3
    def cancel(self):
        self.curve_points=[];self.spline_edit=None;self.new_cote=[];self.cote_host=None;self.cote_origin=None;self._arc_track=None
        return super().cancel()
    def complete_command(self,name,action=False):
        self.curve_points=[];self.spline_edit=None;self.new_cote=[];self.cote_host=None;self.cote_origin=None;self._arc_track=None
        return super().complete_command(name,action or name in ('spline_edit','spline_tangent','convert_spline'))
    def curve_shape(self,p,complete=False):
        t=self.tool.get();pts=list(self.curve_points)
        if not complete:pts.append(p)
        if t=='spline_fit':return spline(pts,self.spline_closed)
        if t=='arc_3p':return arc_three(*pts[:3]) if len(pts)>=3 else None
        if t=='arc_radius':
            if len(pts)<3:return None
            a,b,p=pts[:3];radius=self.typed_arc_radius()
            return arc_radius(a,b,radius,pointer_side(a,b,p)) if radius else bulge_arc(a,b,p)
        if t=='arc_center' and len(pts)>=3:
            c,a,b=pts[:3];r=math.dist(c,a);start=math.atan2(a[1]-c[1],a[0]-c[0]);sweep=self.follow_arc(c,start,b)
            if self.arc_reverse and sweep:sweep-=math.copysign(2*math.pi,sweep)
            if abs(sweep)<1e-9:return None
            return arc(c,r,start,sweep)
        return None
    def follow_arc(self,c,start,p):
        """0.16.29, arc by centre: the arc follows the way the mouse turns around the centre
        (before: always anticlockwise, so it sometimes went round the wrong side)."""
        track=self.__dict__.get('_arc_track')
        if not track or track[0]!=(c,start):track=((c,start),start,0.)
        key,last,sweep=track;angle=math.atan2(p[1]-c[1],p[0]-c[0])
        sweep=max(-2*math.pi+1e-6,min(2*math.pi-1e-6,sweep+(angle-last+math.pi)%(2*math.pi)-math.pi))
        self._arc_track=(key,angle,sweep);return sweep
    def typed_arc_radius(self):
        text=self.command_value.get().strip() if self.tool.get()=='arc_radius' and len(self.curve_points)==2 else ''
        if not text:return None
        try:value=self.parse_length(text)
        except ValueError:return None
        return value if value>0 else None
    def down(self,e):
        self._owned_press=False;t=self.tool.get()
        try:
            if t in CURVE_TOOLS:
                self._owned_press=True
                if len(self.curve_points)>=1000:raise ValueError('Limite de 1 000 points atteinte ; validez cette courbe.')
                p=self.point(e);self.curve_points.append(p)
                if t=='spline_fit':
                    if len(self.curve_points)>1 and math.dist(self.curve_points[-2],p)<1e-8:self.curve_points.pop();return
                    if len(self.curve_points)>=4 and math.dist(self.curve_points[0],p)<1e-8:
                        self.add_items([spline(self.curve_points[:-1],True)],t);return
                if t!='spline_fit' and len(self.curve_points)==2 and math.dist(*self.curve_points)<=1e-7:
                    self.curve_points.pop();raise ValueError('Le nouveau point se confond avec le précédent.')   # 0.19.9: refused, not kept (Arc (centre): a start on the centre left it stuck)
                if t!='spline_fit' and len(self.curve_points)>=3:
                    try:q=self.curve_shape(p,True)
                    except ValueError:self.curve_points.pop();raise
                    if q is None:self.curve_points.pop();raise ValueError('Tourner autour du centre pour tracer l’arc.')
                    self.add_items([q],t)
                elif t=='arc_radius':self.status.set('Choisir la fin de l’arc.' if len(self.curve_points)==1 else 'Bomber l’arc avec la souris, puis cliquer · ou taper le rayon.')
                else:self.status.set('Cliquer pour ajouter un point · clic droit : réglages.' if t=='spline_fit' else 'Choisir le point suivant · clic droit : réglages.')
                return
            if self.spline_edit:
                self._owned_press=True
                q=self.spline_tangent_shape(self.point(e));i=self.spline_edit['index'];self.replace_items([i],[q],'spline_tangent');return
            if t in COTE_TOOLS:self._owned_press=True;return self.cote_click(e)
            return super().down(e)
        except (ValueError,IndexError) as exc:self.invalid_at(e,str(exc))
    def up(self,e):
        if getattr(self,'_owned_press',False):self._owned_press=False;return
        if self.tool.get() in CURVE_TOOLS or self.tool.get() in COTE_TOOLS or self.spline_edit:return
        return super().up(e)
    def enter_dimension(self,e=None):
        t=self.tool.get();text=self.command_value.get().strip()
        if t=='spline_fit':
            try:self.add_items([spline(self.curve_points,self.spline_closed)],t)
            except ValueError as exc:self.status.set(str(exc))
            return 'break'
        if t=='arc_radius' and len(self.curve_points)==2:
            # Entrée: the arc with the typed radius (on the mouse side), or as bulged by the mouse.
            try:
                a,b=self.curve_points;p=self.pointer_world
                if text:
                    value=self.parse_length(text)
                    if value<=0:raise ValueError('Le rayon doit être positif.')
                    q=arc_radius(a,b,value,pointer_side(a,b,p))
                else:q=bulge_arc(a,b,p)
                self.command_value.set('');self.command_entry.place_forget();self.canvas.focus_set();self.add_items([q],t)
            except ValueError as exc:self.status.set(str(exc))
            return 'break'
        if t=='arc_radius' and text:
            self.status.set('Choisir le départ et la fin, puis taper le rayon.');return 'break'
        if t=='arc_center' and text:
            try:
                value=self.parse_length(text)
                if value<=0:raise ValueError('Le rayon doit être positif.')
                self.curve_radius=value
                if t=='arc_center':
                    if len(self.curve_points)!=1:raise ValueError('Choisir le centre avant de saisir le rayon.')
                    c=self.curve_points[0];p=self.pointer_world;angle=math.atan2(p[1]-c[1],p[0]-c[0]);self.curve_points.append((c[0]+value*math.cos(angle),c[1]+value*math.sin(angle)))
                self.command_value.set('');self.command_entry.place_forget();self.canvas.focus_set();self.motion(SimpleNamespace(x=self.cursor_screen[0],y=self.cursor_screen[1]))
            except ValueError as exc:self.status.set(str(exc))
            return 'break'
        return super().enter_dimension(e)
    def command_preview(self):
        super().command_preview()
        # A radius typed for « départ, fin et bombé » shows its arc at once.
        if self.tool.get()=='arc_radius' and len(self.curve_points)==2 and 'canvas' in self.__dict__:
            x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))
    def key_input(self,e):
        if (self.tool.get()=='arc_center' or self.tool.get()=='arc_radius' and len(self.curve_points)==2) and not e.state&4 and self.focus_get() is self.canvas and e.char and e.char in '0123456789.,(':
            self.command_entry.insert('end',e.char);self.command_entry.place(x=self.cursor_screen[0]+16,y=self.cursor_screen[1]+16,width=80,height=22);self.command_entry.focus_set();return 'break'
        return super().key_input(e)
    def motion(self,e):
        self.cursor_screen=(e.x,e.y);self._inside_plan=True;t=self.tool.get()
        if self.modal_active():self.pointer_cursor('arrow');return
        if t in CURVE_TOOLS or t in COTE_TOOLS or self.spline_edit:
            p=self.point(e);self.pointer_world=p;self.canvas.delete('preview')
            try:
                if t=='arc_radius' and len(self.curve_points)==1:
                    # Start chosen: the chord follows the mouse until the end is clicked.
                    self.canvas.create_line(*self.to_screen(self.curve_points[0]),*self.to_screen(p),fill=self.p['ink'],tags='preview',**self.guide_style())
                elif t in CURVE_TOOLS and self.curve_points:
                    try:q=self.curve_shape(p)
                    except ValueError:
                        if t!='arc_radius':raise
                        q=None;self.canvas.create_line(*self.to_screen(self.curve_points[0]),*self.to_screen(self.curve_points[1]),fill=self.p['ink'],tags='preview',**self.guide_style())
                    if q:self.draw_shape(q,self.p['ink'],1,('preview',))
                elif self.spline_edit:self.draw_shape(self.spline_tangent_shape(p),self.p['accent'],1,('preview',))
                elif t in COTE_TOOLS and (self.new_cote or self.cote_host):
                    for q in self.cote_preview(p):self.draw_shape(q,self.p['ink'],1,('preview',))
            except ValueError:pass
            if t=='spline_fit':
                for anchor in self.curve_points:
                    x,y=self.to_screen(anchor);self.canvas.create_rectangle(x-3,y-3,x+3,y+3,outline=self.prefs.get('anchor_color','#efcf4b'),fill=self.prefs.get('anchor_color','#efcf4b'),tags=('preview','curve_anchor'))
            self.draw_crosshair();return
        return super().motion(e)
    def zoom(self,e,f=None):
        # Redraw the active preview within the zoom event, before another mouse move.
        result=super().zoom(e,f)
        if self._inside_plan:self.motion(SimpleNamespace(x=e.x,y=e.y))
        return result
    def redraw(self):
        super().redraw()
        # Preserve a ruler whose start was selected while zooming/panning or resizing.
        if self.tool.get()=='measure' and self.extra_points:
            self.canvas.delete('preview');self.draw_ruler(self.extra_points[0],self.pointer_world)
        if self.tool.get() in CURVE_TOOLS and self.curve_points:
            self.canvas.delete('preview')
            try:
                q=self.curve_shape(self.pointer_world)
                if q:self.draw_shape(q,self.p['ink'],1,('preview',))
            except ValueError:pass
            if self.tool.get()=='spline_fit':
                for anchor in self.curve_points:
                    x,y=self.to_screen(anchor);self.canvas.create_rectangle(x-3,y-3,x+3,y+3,outline=self.prefs.get('anchor_color','#efcf4b'),fill=self.prefs.get('anchor_color','#efcf4b'),tags=('preview','curve_anchor'))
        self.canvas.tag_raise('spline_grips')
        review=getattr(self,'_export_review',None)
        if review:review.highlight()
    def draw_shape(self,s,color,width,tags=()):
        if s.get('is_notch') and s.get('components'):
            # 0.16.30: no grip on a cran (it slides along its piece when dragged); selected, it
            # is drawn in the selection colour.
            for mark in parts_view(s):self.draw_shape(mark,color,width,tags or ('notch_geometry',))
            return
        if s.get('spline') or s.get('components'):
            pts,closed=path(s);pts=pts+pts[:1] if closed else pts;st=style(s);selected=not tags and any(i<len(self.items) and self.items[i] is s for i in self.selected_ids());ink=color if tags else self.p['ink'] if st['color']=='auto' else st['color']
            if s.get('components') and selected:
                for child in parts_view(s):self.draw_shape(child,color,width,('component_geometry',))
                for pt,kind in object_anchors(s) if self.grips_shown() else ():   # 0.19.0: none beyond GRIP_LIMIT objects selected
                    if kind=='endpoint':
                        x,y=self.to_screen(pt);self.canvas.create_rectangle(x-2,y-2,x+2,y+2,outline=self.prefs.get('anchor_color','#efcf4b'),fill=self.prefs.get('anchor_color','#efcf4b'),tags='grips')
                return
            if s.get('components') and not selected:
                for child in parts_view(s):self.draw_shape(child,color,width,tags or ('component_geometry',))
                return
            opts=dict(fill=ink,width=self.line_px(),tags=tags)
            if st['dash']:opts['dash']=dash_px(st['dash'],self.scale);opts['tags']=zoom_tag(tags,'d',st['dash'])
            self.canvas.create_line(*[v for p in pts for v in self.to_screen(p)],**opts)
            from craft_tools import notch_shapes
            for mark in notch_shapes(s):self.draw_shape(mark,color,1.8,tags or ('marks',))
            if selected and s.get('spline') and self.grips_shown():
                ink=self.prefs.get('anchor_color','#efcf4b')
                for mode,pt,base in self.spline_grips(s):
                    x,y=self.to_screen(pt);tag='spline_tangent_grip' if mode[0]=='spline_tangent' else 'spline_point_grip'
                    tags_grip=('grips','spline_grips',tag)
                    if base is not None:
                        self.canvas.create_line(*self.to_screen(base),x,y,fill='#719eab',tags=('grips','spline_grips'),**self.guide_style())
                        self.canvas.create_oval(x-3,y-3,x+3,y+3,outline='#719eab',fill=self.p['canvas'],tags=tags_grip)
                    else:self.canvas.create_rectangle(x-3,y-3,x+3,y+3,outline=ink,fill=ink,tags=tags_grip)
            elif selected and self.grips_shown():
                for pt,kind in object_anchors(s):
                    if kind=='endpoint':
                        x,y=self.to_screen(pt);self.canvas.create_rectangle(x-2,y-2,x+2,y+2,outline=self.prefs.get('anchor_color','#efcf4b'),fill=self.prefs.get('anchor_color','#efcf4b'),tags='grips')
            return
        return super().draw_shape(s,color,width,tags)
    def spline_grips(self,s):
        cs=cubics(s);fit=s['spline'].get('fit');result=[]
        if fit:
            result=[(('spline_fit',i),(s['x']+x,s['y']+y),None) for i,(x,y) in enumerate(fit)]
            if not s.get('closed'):
                result.extend([(('spline_tangent','start'),cs[0][1],cs[0][0]),(('spline_tangent','end'),cs[-1][2],cs[-1][3])])
        else:
            for j,c in enumerate(cs):
                result.extend((('spline_control',j,k),p,c[0] if k==1 else c[3] if k==2 else None) for k,p in enumerate(c))
        return result
    def hit_grip(self,p):
        for i in self.selected_ids():
            s=self.items[i]
            if s.get('spline'):
                # Fit points take precedence if a tangent handle overlaps one.
                for mode,pt,base in self.spline_grips(s):
                    if math.dist(p,pt)<=7/self.scale:return i,mode,pt,base or pt
        # A composite moves as one object, without fake vertices from its display tessellation.
        ids=self.selected_set;old=self.selected;special={i for i in self.selected_ids() if self.items[i].get('components') or self.items[i].get('spline')}
        try:
            self.selected_set=set(self.selected_ids())-special
            if self.selected in special:self.selected=None
            result=super().hit_grip(p)
        finally:self.selected_set=ids;self.selected=old
        if result:return result
        for i in special:
            x,y,X,Y=bounds([self.items[i]]);mid=((x+X)/2,(y+Y)/2)
            if math.dist(mid,p)<=7/self.scale:return i,'move',mid,mid
    def move_grip(self,e):
        g=self.grip_drag
        if isinstance(g['mode'],tuple) and g['mode'][0]=='spline_tangent':
            p=self.point(e);s=g['original'];end=g['mode'][1];fit=[(s['x']+x,s['y']+y) for x,y in s['spline']['fit']];origin=fit[0] if end=='start' else fit[-1]
            vector=(p[0]-origin[0],p[1]-origin[1]) if end=='start' else (origin[0]-p[0],origin[1]-p[1])
            if math.hypot(*vector)<1e-6:return
            tans=copy.deepcopy(s['spline'].get('tangents',{}));tans[end]=vector
            try:q=retain_marks(inherit(spline(fit,False,s['name'],tans),s),s)
            except ValueError as exc:self.invalid_at(e,str(exc));return
            if not g['changed']:self.snapshot();g['changed']=True
            self.items[g['index']]=q;self.refresh();return
        if isinstance(g['mode'],tuple) and g['mode'][0]=='spline_control':
            p=self.point(e);q=copy.deepcopy(g['original']);_,j,k=g['mode'];controls=q['spline']['segments'];controls[j][k]=[p[0]-q['x'],p[1]-q['y']]
            if k==0 and j>0:controls[j-1][3]=list(controls[j][k])
            if k==3 and j<len(controls)-1:controls[j+1][0]=list(controls[j][k])
            # 0.19.9: a closed spline's first and last points are one point: they move together (no gap)
            if q.get('closed') and k==0 and j==0:controls[-1][3]=list(controls[j][k])
            if q.get('closed') and k==3 and j==len(controls)-1:controls[0][0]=list(controls[j][k])
            try:q=retain_marks(inherit(from_cubics(cubics(q),q.get('closed',False),q['name']),g['original']),g['original'])
            except ValueError as exc:self.invalid_at(e,str(exc));return
            if not g['changed']:self.snapshot();g['changed']=True
            self.items[g['index']]=q;self.refresh();return
        if isinstance(g['mode'],tuple) and g['mode'][0]=='spline_fit':
            p=self.point(e);original=g['original'];pts=[(original['x']+x,original['y']+y) for x,y in original['spline']['fit']];pts[g['mode'][1]]=p
            try:q=retain_marks(inherit(spline(pts,original.get('closed',False),original['name'],original['spline'].get('tangents')),original),original)
            except ValueError:return
            if not g['changed']:self.snapshot();g['changed']=True
            self.items[g['index']]=q;self.refresh();return
        return super().move_grip(e)
    def point_length_dialog(self,t='strap_point'):
        """0.19.5: Bout pointu: the length of the point (0: at 45°); 0.19.6: Bout rond: how far from the end
        its round starts (0: a half round); both inside the strap."""
        attr,title,question,zero=(('round_depth','Bout rond','Début de l’arrondi, depuis le bout (mm ; 0 : demi-cercle)','0 : demi-cercle') if t=='strap_round'
                                  else ('point_length','Bout pointu','Longueur de la pointe (mm ; 0 : à 45°)','0 : pointe à 45°'))
        self._suspend_pointer=True;self.canvas.configure(cursor='arrow')
        try:answer=simpledialog.askstring(title,question,initialvalue=f'{self.__dict__.get(attr,0.):g}',parent=self)
        finally:self._suspend_pointer=False
        if answer is not None:
            try:
                value=self.parse_length(answer if re_has_unit(answer) else answer+' mm')
                if not 0<=value<=50000:raise ValueError(f'Longueur positive requise ({zero}).')
                self.keep_tool_value(attr,value);self.status.set(self.corner_prompt(t))   # 0.19.9: kept for the next start
            except ValueError as exc:self.status.set(str(exc))
        self.canvas.focus_set();self.motion(SimpleNamespace(x=self.cursor_screen[0],y=self.cursor_screen[1]))
    def canvas_context(self,e):
        self.close_palette();t=self.tool.get()
        if t=='select':
            i=self.pick(self.raw(e))
            if i is not None and self.items[i].get('spline'):
                m=self.menu();self.spline_context(m,i,self.raw(e));m.add_separator();m.add_command(label='Menu de sélection…',command=lambda:super(Finished,self).canvas_context(e));return self.show_context(m,e)
            import background_ui
            if i is None and not self.selected_ids() and background_ui.under(self,e.x,e.y):
                # 0.19.7: a right click on the background picture: what can be done with it
                m=self.menu();background_ui.context_entries(self,m);return self.show_context(m,e)
            return super().canvas_context(e)
        m=self.menu()
        if t in ('fillet','chamfer'):m.add_command(label='Rayon…' if t=='fillet' else 'Distance…',command=lambda:self.tool_value_dialog(t))
        if t=='strap_point':m.add_command(label='Longueur de la pointe…',command=lambda:self.tool_value_dialog(t))   # 0.19.5
        if t=='strap_round':m.add_command(label='Début de l’arrondi…',command=lambda:self.tool_value_dialog(t))   # 0.19.6
        if t=='strap_belt':m.add_command(label='Affinement, largeur du bout, arrondis…',command=lambda:__import__('strap_ui').belt_dialog(self))
        if t=='belt_holes':m.add_command(label='Nombre, écart, distance, mèche…',command=lambda:__import__('belt_holes_ui').dialog(self))
        if t=='buckle_slot':m.add_command(label='Longueur, largeur, distance, tracé…',command=lambda:__import__('strap_ui').slot_dialog(self))
        if t=='strap_piece':m.add_command(label='Longueur, largeur, bouts, trous, fente…',command=lambda:__import__('strap_ui').piece_dialog(self))
        if t=='passant':m.add_command(label='Sangle, épaisseurs, largeur, aisance, recouvrement…',command=lambda:__import__('strap_ui').passant_dialog(self))   # 0.19.13
        if t=='toron':m.add_command(label='Profil, toron, longueurs, précoupe, attaches, perfos, enchapes…',command=lambda:__import__('strap_ui').toron_dialog(self))
        if t in ('rect','rect_center','rect_round','rect_rot'):m.add_command(label='Mesurer sur polyligne',command=self.start_reference_measure)
        if t=='arc_center':m.add_checkbutton(label='Inverser le sens',command=self.reverse_arc)
        if t=='spline_fit':
            m.add_command(label='Retirer le dernier point',command=self.remove_curve_point)
            m.add_command(label='Fermer et valider la spline',command=self.close_spline)
            m.add_command(label='Valider la spline ouverte',command=self.enter_dimension)
        if m.index('end') is not None:m.add_separator()
        m.add_command(label='Terminer l’outil',command=self.escape)
        return self.show_context(m,e)
    def show_context(self,m,e):
        try:m.tk_popup(e.x_root,e.y_root)
        finally:m.grab_release()
        return 'break'
    def tool_value_dialog(self,t):
        if t in ('strap_point','strap_round'):return self.point_length_dialog(t)
        attr='fillet_radius' if t=='fillet' else 'angle_value' if t=='chamfer' else 'curve_radius';initial=getattr(self,attr)
        self._suspend_pointer=True;self.canvas.configure(cursor='arrow')
        try:answer=simpledialog.askstring('Rayon' if t!='chamfer' else 'Chanfrein','Rayon (mm)' if t!='chamfer' else 'Distance (mm)',initialvalue=f'{initial:g}',parent=self)
        finally:self._suspend_pointer=False
        if answer is not None:
            try:
                value=self.parse_length(answer if re_has_unit(answer) else answer+' mm')
                if not .001<=value<=50000:raise ValueError('Valeur positive requise.')
                self.keep_tool_value(attr,value);self.status.set(f'{"Rayon" if t!="chamfer" else "Distance"} {value:g} mm · choisir les lignes / points.')   # 0.19.9: kept for the next start
            except ValueError as exc:self.status.set(str(exc))
        self.canvas.focus_set();self.motion(SimpleNamespace(x=self.cursor_screen[0],y=self.cursor_screen[1]))
    def remove_curve_point(self):
        if self.curve_points:self.curve_points.pop()
        self.motion(SimpleNamespace(x=self.cursor_screen[0],y=self.cursor_screen[1]))
    def reverse_arc(self):self.arc_reverse=not self.arc_reverse;self.motion(SimpleNamespace(x=self.cursor_screen[0],y=self.cursor_screen[1]))
    def close_spline(self):
        try:self.add_items([spline(self.curve_points,True)],'spline_fit')
        except ValueError as exc:self.status.set(str(exc))
    def spline_context(self,m,i,p):
        s=self.items[i]
        if s['spline'].get('fit'):
            m.add_command(label='Ajouter un point ici',command=lambda:self.change_spline_point(i,p,False))
            m.add_command(label='Supprimer le point le plus proche',command=lambda:self.change_spline_point(i,p,True))
            if not s.get('closed'):
                m.add_command(label='Tangente au départ',command=lambda:self.start_spline_tangent(i,'start'))
                m.add_command(label='Tangente à la fin',command=lambda:self.start_spline_tangent(i,'end'))
        m.add_command(label='Convertir en polyligne…',command=lambda:self.convert_spline(i))
    def change_spline_point(self,i,p,remove):
        s=self.items[i];pts=[(s['x']+x,s['y']+y) for x,y in s['spline']['fit']]
        if remove:pts.pop(min(range(len(pts)),key=lambda j:math.dist(pts[j],p)))
        else:
            from curves import cubic_location
            cs=cubics(s);j=min(range(len(cs)),key=lambda j:math.dist(p,cubic_location(cs[j],p)[1]));pts.insert(j+1,contour_location(s,p)[1])
        try:self.replace_items([i],[retain_marks(inherit(spline(pts,s.get('closed',False),s['name'],s['spline'].get('tangents')),s),s)],'spline_edit')
        except ValueError as exc:self.status.set(str(exc))
    def start_spline_tangent(self,i,end):
        s=copy.deepcopy(self.items[i]);self.cancel();self.tool.set('spline_tangent');self.spline_edit=dict(index=i,end=end,original=s);self.status.set('Diriger la tangente avec la souris, puis cliquer.');self.canvas.focus_set()
    def spline_tangent_shape(self,p):
        st=self.spline_edit;s=st['original'];pts=[(s['x']+x,s['y']+y) for x,y in s['spline']['fit']];end=pts[0] if st['end']=='start' else pts[-1];tans=copy.deepcopy(s['spline'].get('tangents',{}));v=(p[0]-end[0],p[1]-end[1]);tans[st['end']]=v if st['end']=='start' else (-v[0],-v[1]);return retain_marks(inherit(spline(pts,False,s['name'],tans),s),s)
    def convert_spline(self,i):
        self._suspend_pointer=True;self.canvas.configure(cursor='arrow')
        try:answer=simpledialog.askstring('Convertir en polyligne','Écart maximal (mm)',initialvalue='0.01',parent=self)
        finally:self._suspend_pointer=False
        if answer is None:return
        try:
            tol=self.parse_length(answer+' mm' if not re_has_unit(answer) else answer)
            if not .001<=tol<=1:raise ValueError('Choisissez une précision de 0,001 à 1 mm.')
            from curves import spline_path
            s=self.items[i];pts,closed=spline_path(s,tol);self.replace_items([i],[retain_marks(inherit(polygon(pts,s['name'],closed),s),s)],'convert_spline')
        except ValueError as exc:self.status.set(str(exc))
    def radius_entities(self,p):
        out=super().radius_entities(p)
        for q in out:
            if q.get('annotation'):q['text_angle']=(q.get('text_angle',0)+90)%180-90   # 0.19.9: along its leader, never upside down (it was turned across it)
        return out
    def cote_click(self,e):
        t=self.tool.get();p=self.point(e)
        if t=='dimension_aligned':
            self.new_cote.append(p)
            if len(self.new_cote)==3:self.add_items(self.cote_preview(p),'dimension_aligned')
            else:self.status.set('Choisir la deuxième extrémité.' if len(self.new_cote)==1 else 'Placer la ligne de cote, puis cliquer.')
            return
        if t=='angle_dimension':
            if len(self.new_cote)<2:
                side=self.straight_side(self.raw(e))
                if side is None:raise ValueError('Choisissez deux côtés droits.')
                if self.new_cote:
                    # 0.19.9: the same or a parallel side is refused here and not kept (each placing click was refused: stuck).
                    from editing import line_intersection
                    try:line_intersection(*path(self.new_cote[0])[0],*path(side)[0])
                    except ValueError:raise ValueError('Choisissez un deuxième côté non parallèle au premier.') from None
                side['click']=self.raw(e);self.new_cote.append(side);self.status.set('Choisir le deuxième côté.' if len(self.new_cote)==1 else 'Placer la cote d’angle.');return
            self.add_items(self.cote_preview(p),t);return
        if self.cote_host is None:
            i=self.pick(self.raw(e))
            if i is None:raise ValueError('Choisissez un cercle ou une courbe.')
            s=self.items[i]
            if t=='diameter':
                if s['kind']=='circle':c,r=circle_data(s)
                else:
                    qs=[q for q in primitives(s) if q['sweep']]
                    if not qs:raise ValueError('Choisissez un cercle ou un arc circulaire.')
                    q=min(qs,key=lambda q:math.dist(p,at_primitive(q,.5)));c,r=q['c'],q['r']
                self.cote_host=dict(center=c,radius=r)
            else:
                if s['kind']=='line' or s.get('annotation') or s.get('drill'):raise ValueError('Choisissez une courbe ou un arc.')
                if s.get('ellipse') or s.get('spline') or s['kind']=='circle':host=s
                else:
                    a,b=whole_arc_range(s,p)
                    if a is None:raise ValueError('Choisissez un arc.')
                    host=contour_slice(s,a,b)
                self.cote_host=copy.deepcopy(host);self.cote_origin=contour_location(host,p)[1]
            self.status.set('Placer la cote avec la souris, puis cliquer.');return
        self.add_items(self.cote_preview(p),t)
    def straight_side(self,p):
        """0.16.27: a straight side under the pointer, from a line or from any shape
        (rectangle, polyline…), as a line for the angle dimension."""
        i=self.pick(p)
        if i is None:return None
        s=self.items[i]
        if s.get('annotation') or s.get('drill') or s.get('dimension_group') or s.get('spline') or s.get('ellipse'):return None
        if s['kind']=='line':return copy.deepcopy(s)
        shapes=parts(s) if s.get('components') else [s]
        sides=[(distance(p,q['a'],q['b']),q['a'],q['b']) for part in shapes for q in primitives(part) if not q['sweep']]
        if not sides:return None
        d,a,b=min(sides,key=lambda v:v[0])
        if d>10/self.scale:return None
        return shape('line','Côté',*a,b[0]-a[0],b[1]-a[1])
    def cote_preview(self,p):
        t=self.tool.get()
        if t=='dimension_aligned':
            if len(self.new_cote)<2:return []
            a,b=self.new_cote[:2];return dimensions(a,b,p,self.cote_value(math.dist(a,b)))  # 0.16.27: text along the dimension line
        if t=='diameter':
            c,r=self.cote_host['center'],self.cote_host['radius'];angle=math.atan2(p[1]-c[1],p[0]-c[0]);u=(math.cos(angle),math.sin(angle));a=(c[0]-r*u[0],c[1]-r*u[1]);b=(c[0]+r*u[0],c[1]+r*u[1]);out=[shape('line','Diamètre',*a,b[0]-a[0],b[1]-a[1]),self.arrow(a,b,COTE_ARROW),self.arrow(b,a,COTE_ARROW),cote_label('Ø'+self.cote_value(2*r),p,math.degrees(angle))]
        elif t=='angle_dimension':
            if len(self.new_cote)<2:return []
            from editing import line_intersection
            s,t2=self.new_cote[:2];a,b=path(s)[0];c,d=path(t2)[0];center=line_intersection(a,b,c,d);r=math.dist(center,p)
            if r<.001:raise ValueError('Éloignez le curseur du sommet.')
            # 0.17.0: each ray goes from the vertex toward the point where that side was clicked, so
            # the dimension always stays inside the angle formed by the two sides (the pointer only
            # sets the radius).
            def ray(a,b,side):
                u=(b[0]-a[0],b[1]-a[1]);click=side.get('click') or p
                along=(click[0]-center[0])*u[0]+(click[1]-center[1])*u[1]
                if abs(along)<1e-6*math.hypot(*u):along=max(((q[0]-center[0])*u[0]+(q[1]-center[1])*u[1] for q in (a,b)),key=abs)
                sign=1 if along>=0 else -1;return math.atan2(sign*u[1],sign*u[0])
            start,end=ray(a,b,s),ray(c,d,t2);sweep=(end-start)%(2*math.pi)
            if sweep>math.pi:start,end=end,start;sweep=2*math.pi-sweep
            q=arc(center,r,start,sweep,'Cote d’angle');pts,_=path(q);mid=start+sweep/2;label_at=(center[0]+(r+COTE_GAP)*math.cos(mid),center[1]+(r+COTE_GAP)*math.sin(mid))
            out=[q,self.arrow(pts[0],pts[1],COTE_ARROW),self.arrow(pts[-1],pts[-2],COTE_ARROW),aligned_annotation(f'{math.degrees(sweep):.1f}°',label_at,math.degrees(mid)+90,COTE_TEXT)]
        elif t=='arc_length':
            host=self.cote_host;d,near=contour_location(host,p);offset=math.dist(near,p)
            if inside(host,p):offset=-offset
            if not path(host)[1]:
                pts,_=path(host);best=min(zip(pts,pts[1:]),key=lambda ab:distance(near,*ab));u=(best[1][0]-best[0][0],best[1][1]-best[0][1]);offset=math.copysign(offset,u[0]*(p[1]-near[1])-u[1]*(p[0]-near[0]))
            try:q=shifted(host,offset)
            except ValueError:q=copy.deepcopy(host)
            q['name']='Longueur d’arc';pts,closed=path(q);base,_=path(host);out=[q]
            if len(pts)>2:
                if closed:
                    pts=pts+pts[:1];out += [self.arrow(pts[0],pts[1],COTE_ARROW),self.arrow(pts[-1],pts[-2],COTE_ARROW)]
                else:
                    out += [self.arrow(pts[0],pts[1],COTE_ARROW),self.arrow(pts[-1],pts[-2],COTE_ARROW)]
                    for a,b in ((base[0],pts[0]),(base[-1],pts[-1])):out.append(shape('line','Rappel de cote',*a,b[0]-a[0],b[1]-a[1]))
                # 0.16.27: the value is written along the arc (tangent), centred, beside the dimension arc.
                k=len(pts)//2;mid=pts[k];before,after=pts[max(0,k-1)],pts[min(len(pts)-1,k+1)];angle=math.degrees(math.atan2(after[1]-before[1],after[0]-before[0]))
                _,foot=contour_location(host,mid);away=(mid[0]-foot[0],mid[1]-foot[1]);n=math.hypot(*away)
                if n>1e-9:
                    side=(away[0]/n,away[1]/n);out.append(aligned_annotation(self.cote_value(contour_length(host)),(mid[0]+side[0]*COTE_GAP,mid[1]+side[1]*COTE_GAP),angle,COTE_TEXT))
                else:out.append(cote_label(self.cote_value(contour_length(host)),mid,angle))
        else:return []
        group=uuid.uuid4().hex
        for q in out:
            q['dimension_group']=group;q['style']=dict(color='auto',width=.12,dash=[],role='dimension')
            if q.get('annotation'):q['text_angle']=(q.get('text_angle',0)+90)%180-90
        return out
    def dock_target(self,e):
        x,y=self.leftdock.winfo_rootx(),self.leftdock.winfo_rooty();W,H=self.leftdock.winfo_width(),self.leftdock.winfo_height();tx,ty=self.topdock.winfo_rootx(),self.topdock.winfo_rooty();TW,TH=self.topdock.winfo_width(),self.topdock.winfo_height()
        left=x-8<=e.x_root<=x+max(28,W)+80 and y-8<=e.y_root<=y+H+8
        top=tx-8<=e.x_root<=tx+TW+8 and ty-10<=e.y_root<=ty+max(28,TH)+60
        if left and (not top or max(0,e.x_root-x-W)<=max(0,e.y_root-ty-TH)+10):where='left'
        elif top:where='top'
        else:self.hide_dock_hint();return 'float',0
        lanes=self._dock_lanes[where];coord=e.x_root if where=='left' else e.y_root;index=len(lanes)
        for i,f in lanes.items():
            end=f.winfo_rootx()+f.winfo_width() if where=='left' else f.winfo_rooty()+f.winfo_height()
            if coord<=end+2:index=i;break
        self.show_dock_hint(where,index);return where,index
    def show_dock_hint(self,where,index):
        if self._dock_hint is None or not self._dock_hint.winfo_exists():self._dock_hint=tk.Frame(self.root_frame,bg=self.p['accent'])
        lanes=self._dock_lanes[where];parent=self.leftdock if where=='left' else self.topdock;f=lanes.get(index)
        x=(f.winfo_rootx() if f else parent.winfo_rootx()+parent.winfo_width()) if where=='left' else parent.winfo_rootx()
        y=parent.winfo_rooty() if where=='left' else (f.winfo_rooty() if f else parent.winfo_rooty()+parent.winfo_height())
        self._dock_hint.place(x=x-self.root_frame.winfo_rootx(),y=y-self.root_frame.winfo_rooty(),width=3 if where=='left' else parent.winfo_width(),height=parent.winfo_height() if where=='left' else 3);self._dock_hint.lift()
    def hide_dock_hint(self):
        if self._dock_hint is not None and self._dock_hint.winfo_exists():self._dock_hint.place_forget()
    def drop_category(self,e,name):
        try:return super().drop_category(e,name)
        finally:self.hide_dock_hint()
 from advanced_ui import enhance
 return enhance(Finished)

def re_has_unit(text):return 'mm' in text.lower() or 'cm' in text.lower()

def retain_marks(new,old):
    if old.get('notches'):
        if max(m['distance'] for m in old['notches'])>contour_length(new):raise ValueError('La courbe devient trop courte pour ses crans.')
        new['notches']=copy.deepcopy(old['notches'])
    return new


def blend_color(foreground,background,fraction):
    return '#' + ''.join(f'{round(int(foreground[i:i+2],16)*(1-fraction)+int(background[i:i+2],16)*fraction):02x}' for i in (1,3,5))
