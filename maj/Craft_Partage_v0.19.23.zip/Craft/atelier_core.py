"""Craft 0.1.1 — local desktop pattern editor, Python standard library."""
import tkinter as tk
from tkinter import messagebox
import copy
import math
from geometry import number, path, bounds, distance

BG = '#f7f4ed'
INK = '#283b36'
ACCENT = '#9b6b36'


class App(tk.Tk):

    def snapshot(self):
        self.undo_stack.append(copy.deepcopy(self.items));self.undo_stack=self.undo_stack[-100:];self.redo_stack=[]

    def to_screen(self,p):return p[0]*self.scale+self.ox,p[1]*self.scale+self.oy
    def raw(self,e):return (e.x-self.ox)/self.scale,(e.y-self.oy)/self.scale

    def pick(self,p):
        best=None;dist=9/self.scale
        for i,s in enumerate(self.items):
            if s.get('preparation'):continue   # 0.17.0: a zone is picked by a click inside it, never by its outline
            x,y,X,Y=bounds([s])
            if not x-dist<=p[0]<=X+dist or not y-dist<=p[1]<=Y+dist:continue
            pts,closed=path(s)
            for a,b in zip(pts,pts[1:]+pts[:1] if closed else pts[1:]):
                d=distance(p,a,b)
                if d<=dist:best=i;dist=d
        return best

    def list_pick(self,e):
        rows=self.list.curselection()
        if rows:self.choose(rows[0])

    def make_shape(self,kind,a,b):
        x,y=a;w,h=b[0]-x,b[1]-y
        if kind in ('rect','circle'):
            x,y=min(a[0],b[0]),min(a[1],b[1]);w,h=abs(w),abs(h)
        if kind=='circle':h=w
        r=0
        if kind=='rect':
            try:r=max(0,min(number(self.fields['r'].get()),w/2,h/2))
            except ValueError:r=0
        return dict(kind=kind,name=self.fields['name'].get().strip() or 'Pièce',x=x,y=y,w=w,h=h,r=r)

    def commit_shape(self,p):
        s=self.make_shape(self.tool.get(),self.start,p)
        if (s['kind']=='line' and math.hypot(s['w'],s['h'])<.001) or (s['kind']!='line' and min(s['w'],s['h'])<.001):return
        self.snapshot();self.items.append(s);self.start=None;self.choose(len(self.items)-1)

    def finish_poly(self,closed):
        if len(self.pending)<(3 if closed else 2):return
        x,y=self.pending[0];xs=[p[0] for p in self.pending];ys=[p[1] for p in self.pending]
        s=dict(kind='poly',name=self.fields['name'].get() or 'Contour',x=x,y=y,w=max(xs)-min(xs),h=max(ys)-min(ys),r=0,
               points=[[a-x,b-y] for a,b in self.pending],closed=closed)
        self.snapshot();self.items.append(s);self.pending=[];self.start=None;self.choose(len(self.items)-1)

    def cancel(self):
        self.start=None;self.pending=[];self.drag=None;self.redraw()

    def values(self,kind):
        s={k:(v.get().strip() or 'Pièce') if k=='name' else number(v.get()) for k,v in self.fields.items()}
        s['kind']=kind
        if kind in ('rect','circle') and (s['w']<=0 or s['h']<=0):raise ValueError('Largeur et hauteur doivent être positives.')
        if kind=='circle':s['h']=s['w'];s['r']=0
        if kind=='line':s['r']=0
        if kind=='rect' and not 0<=s['r']<=min(s['w'],s['h'])/2:raise ValueError('Rayon trop grand ou négatif.')
        return s

    def create_exact(self):
        kind=self.tool.get()
        if kind=='select':kind='rect'
        if kind=='poly':messagebox.showinfo('Contour','Tracez les points du contour sur le plan.');return
        s=self.values(kind);self.snapshot();self.items.append(s);self.choose(len(self.items)-1)

    def apply(self):
        if self.selected is None:return
        old=self.items[self.selected];s=self.values(old['kind'])
        if old['kind']=='poly':
            if (not old['w'] and s['w']!=0) or (not old['h'] and s['h']!=0):
                raise ValueError('Ce contour a une dimension nulle ; modifiez ses points en le retraçant.')
            sx=s['w']/old['w'] if old['w'] else 1;sy=s['h']/old['h'] if old['h'] else 1
            s['points']=[[x*sx,y*sy] for x,y in old['points']];s['closed']=old['closed'];s['r']=0
        self.snapshot();self.items[self.selected]=s;self.refresh()

    def delete(self):
        if self.selected is None:return
        self.snapshot();del self.items[self.selected];self.selected=None;self.refresh()
    def duplicate(self):
        if self.selected is None:return
        self.snapshot();s=copy.deepcopy(self.items[self.selected]);s['x']+=10;s['y']+=10;s['name']+=' copie'
        self.items.append(s);self.choose(len(self.items)-1)
    def undo(self):
        if not self.undo_stack:return
        self.redo_stack.append(copy.deepcopy(self.items));self.items=self.undo_stack.pop();self.selected=None;self.cancel();self.refresh()
    def redo(self):
        if not self.redo_stack:return
        self.undo_stack.append(copy.deepcopy(self.items));self.items=self.redo_stack.pop();self.selected=None;self.cancel();self.refresh()
    def pan_start(self,e):self.pan=(e.x,e.y,self.ox,self.oy)
    def pan_move(self,e):
        if self.pan:self.ox=self.pan[2]+e.x-self.pan[0];self.oy=self.pan[3]+e.y-self.pan[1];self.redraw()
    def zoom(self,e,f=None):
        p=self.raw(e);new=max(.002,min(2000,self.scale*(f if f else (1.15 if e.delta>0 else 1/1.15))))
        self.scale=new;self.ox=e.x-p[0]*new;self.oy=e.y-p[1]*new;self.redraw()
    def fit(self):
        x,y,X,Y=bounds(self.items);W=self.canvas.winfo_width();H=self.canvas.winfo_height()
        self.scale=max(.002,min(20,(W-100)/max(1,X-x),(H-100)/max(1,Y-y)))   # 0.18.5: always everything (±100 m)
        self.ox=(W-(X-x)*self.scale)/2-x*self.scale;self.oy=(H-(Y-y)*self.scale)/2-y*self.scale;self.redraw()

