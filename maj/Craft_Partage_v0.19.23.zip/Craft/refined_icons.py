"""Craft's tool icons, drawn in code: no font glyph, no picture but the logo (« info »).

One outline style for the whole set. An icon is drawn in the colour of its family
(craft_refined.icon_color: cotes blue, crans and mèches purple, piqûre green…; drawing and editing
tools in the ink colour), with one stroke, on a 24-unit grid (the drawing inside 2..22) at the size
asked (16, 20, 24, 32, 40 px; 14 px for the tool shown beside the crosshair). Points fall on the
pixel grid (``S``) with a whole-pixel stroke (``W``: 1 px up to 24 px, 2 px above): straight strokes
stay sharp, slants and curves are smoothed by display_render. A surface that helps reading (a piece,
a band, a badge) takes a soft tint of the colour on the canvas colour (``tint``), never a fixed pastel.

0.19.2: an icon may carry a second colour, for the part the tool changes, where it helps to read it:
removed red (Couper), added green (Rallonger, the new corner of Angle droit, Chanfrein and Arrondi,
the joints of Joindre), the copy or the result blue (Copier, Symétrie, Décaler); the four sides of
Décomposer each their own. These colours (``accent``) are fixed tones, deeper on a light ground and
lighter on a dark one; the rest of the icon stays in the family colour.

Only what the smoothing reads is used: lines (a dash is a short line) and polygons. Curves are
polylines and circles polygons, so that GDI+ and Pillow draw the same outline (Pillow draws a
rectangle, an oval or an arc inside its box, GDI+ on it). The smoothing ignores Tk's line caps: a
free line end is lengthened here by half the stroke, so that a stroke ends on a pixel edge.
"""
import math
import tkinter as tk
from ui_widgets import draw_icon as legacy,contrast_color

TINT=.28   # share of the icon colour in a tint, the rest being the canvas colour
# 0.19.2: the colours of the part a tool changes: (on a light ground, on a dark ground).
ACCENTS={'red':('#c62828','#e5534b'),'green':('#2a8a45','#4fbf6a'),'blue':('#2f62c4','#6aa9ff'),'orange':('#b26a00','#e3a33b')}


def ground_of(c):
    """0.19.0: the colour under the icon: its rounded tile (hover, tool in use, switch on) when it
    has one, else the canvas colour."""
    return c.__dict__.get('_modern_ground') or str(c.cget('bg'))


_RGB={}


def rgb16(c,color):
    """0.19.2: ``c.winfo_rgb(color)``, kept for a '#…' colour, which never changes (a colour name may
    follow the system): Tk was asked three or four times per icon drawn (about a tenth of an icon's
    drawing time, measured under Linux)."""
    color=str(color);found=_RGB.get(color)
    if found is None:
        found=c.winfo_rgb(color)
        if color.startswith('#'):
            if len(_RGB)>255:_RGB.clear()
            _RGB[color]=found
    return found


def tint(c,color,share=TINT):
    """``color`` mixed with the canvas colour: a soft fill that follows the family colour and the panel."""
    try:
        a,b=rgb16(c,color),rgb16(c,ground_of(c))
        return '#'+''.join(f'{round((x*share+y*(1-share))/257):02x}' for x,y in zip(a,b))
    except (tk.TclError,TypeError,ValueError):return ''


def accent(c,key):
    """0.19.2: the colour ``key`` of ACCENTS that reads on the ground under the icon: its deeper tone
    on a light ground, its lighter one on a dark ground."""
    try:dark=contrast_color('#'+''.join(f'{round(v/257):02x}' for v in rgb16(c,ground_of(c))))=='#ffffff'
    except (tk.TclError,TypeError,ValueError):dark=True
    return ACCENTS[key][dark]


def logo_size(n):
    """0.19.19: the logo's drawing for icons of ``n`` px: the largest of 16, 24 and 32 that is not larger."""
    return max([s for s in (16,24,32) if s<=n] or [16])


def draw(c,name,n,color):
    if name=='info':
        # 0.19.19: the logo no larger than the other icons (« logo », 09/11/2026: at 20 px its 24 px drawing touched
        # the edge of its button): its largest drawing that fits the icon size (16 → 16, 20 → 16, 24 → 24, 32 and 40 → 32).
        from brand_assets import PNG_IMAGES
        image=tk.PhotoImage(master=c,data=PNG_IMAGES[logo_size(n)]);c._craft_logo_image=image
        c.create_image(4+n/2,4+n/2,image=image);return
    u=n/24;W=max(1,round(1.25*u));half=.5 if W%2 else 0;soft=tint(c,color);ground=ground_of(c);made=[]
    # A grid value on the pixel grid, rounded half up (Python's round, half to even, gave two grid
    # units the same pixel at 24 px).
    def S(v):return math.floor(v*u+4-half+.5)+half
    def L(v):return max(1,round(v*u))                         # a grid length in whole pixels
    def P(v):return math.floor(v-half+.5)+half                # a pixel value on the pixel grid
    def flat(points):return [v for p in points for v in p]
    def grid(p):return [(S(p[i]),S(p[i+1])) for i in range(0,len(p),2)]
    def stroke(points,caps=(True,True),fill=None):
        """A line through pixel points, its free ends lengthened by half the stroke."""
        points=list(points)
        for end,near,cap in ((0,1,caps[0]),(-1,-2,caps[1])):
            (x,y),(a,b)=points[end],points[near];d=math.hypot(x-a,y-b)
            if cap and d>1e-9:points[end]=(x+(x-a)/d*W/2,y+(y-b)/d*W/2)
        made.append(c.create_line(*flat(points),fill=fill or color,width=W));return made[-1]
    def polygon(points,fill='',outline=None):
        """A closed outline, started halfway along its first side (Pillow leaves its start unjoined)."""
        a,b=points[0],points[1]
        made.append(c.create_polygon(*flat([((a[0]+b[0])/2,(a[1]+b[1])/2),*points[1:],a]),fill=fill,outline=outline or color,width=W));return made[-1]
    def rounded(points,r,closed=False):
        """Pixel points with their corners rounded: radius ``r`` grid units (or one per point, 0: a
        sharp corner), in whole pixels."""
        radii=list(r) if isinstance(r,(list,tuple)) else [r]*len(points);out=[];m=len(points)
        for i,B in enumerate(points):
            R=round(radii[i]*u)
            if R<1 or (not closed and i in (0,m-1)):out.append(B);continue
            A=points[i-1];C=points[(i+1)%m]
            ax,ay,cx,cy=A[0]-B[0],A[1]-B[1],C[0]-B[0],C[1]-B[1];la,lc=math.hypot(ax,ay),math.hypot(cx,cy)
            if la<1e-9 or lc<1e-9:out.append(B);continue
            ax,ay,cx,cy=ax/la,ay/la,cx/lc,cy/lc;angle=math.acos(max(-1,min(1,ax*cx+ay*cy)))
            if angle<1e-3 or math.pi-angle<1e-3:out.append(B);continue
            t=min(R/math.tan(angle/2),la/2,lc/2);rr=t*math.tan(angle/2)
            bx,by=ax+cx,ay+cy;bl=math.hypot(bx,by);d=rr/math.sin(angle/2);ox,oy=B[0]+bx/bl*d,B[1]+by/bl*d
            a1=math.atan2(B[1]+ay*t-oy,B[0]+ax*t-ox);a2=math.atan2(B[1]+cy*t-oy,B[0]+cx*t-ox)
            sweep=(a2-a1+math.pi)%(2*math.pi)-math.pi;k=max(2,math.ceil(abs(sweep)*rr/1.2))
            out+=[(ox+rr*math.cos(a1+sweep*j/k),oy+rr*math.sin(a1+sweep*j/k)) for j in range(k+1)]
        return out
    def line(*p,caps=(True,True),r=0,fill=None):
        points=grid(p);return stroke(rounded(points,r) if r else points,caps,fill)
    def shape(*p,fill='',r=0,outline=None):
        points=grid(p);return polygon(rounded(points,r,True) if r else points,fill,outline)
    def oval(x,y,rx,ry=None,fill='',nodes=()):
        """An ellipse round a grid point, its radii in half pixels: its four ends on pixel centres.
        ``nodes``: angles (degrees) of nodes on it."""
        A=max(1,round(2*rx*u)/2);B=max(1,round(2*(ry or rx)*u)/2)
        X=P(S(x)-A)+A;Y=P(S(y)-B)+B;k=max(24,math.ceil(2*math.pi*max(A,B)/1.2));turn=math.radians(nodes[0]) if nodes else 0
        points=[(X+A*math.cos(turn+2*math.pi*j/k),Y+B*math.sin(turn+2*math.pi*j/k)) for j in range(k+1)]
        if nodes:parted(points,[(X+A*math.cos(math.radians(a)),Y+B*math.sin(math.radians(a))) for a in nodes])
        else:made.append(c.create_polygon(*flat(points[:-1]),fill=fill,outline=color,width=W))
        return X,Y,A,B
    def arc(X,Y,R,a0,a1,caps=(True,True),Ry=None):
        """An arc round the pixel point (X, Y), from a0 to a1 degrees (clockwise on screen from 3 o'clock)."""
        Ry=Ry or R;k=max(3,math.ceil(abs(math.radians(a1-a0))*max(R,Ry)/1.2))
        points=[(X+R*math.cos(math.radians(a0+(a1-a0)*j/k)),Y+Ry*math.sin(math.radians(a0+(a1-a0)*j/k))) for j in range(k+1)]
        stroke(points,caps);return points
    def head(tip,dx,dy,arm=3.5,spread=45,fill=None):
        """An open arrow head at the pixel point ``tip``, pointing along (dx, dy); along an axis or a
        diagonal its arms are whole pixels (sharp 45° or straight arms)."""
        d=math.hypot(dx,dy);dx,dy=dx/d,dy/d;ends=[]
        for s in (1,-1):
            a=math.radians(180+s*spread);ex,ey=dx*math.cos(a)-dy*math.sin(a),dx*math.sin(a)+dy*math.cos(a)
            if spread==45 and (abs(dx)<1e-9 or abs(dy)<1e-9 or abs(abs(dx)-abs(dy))<1e-9):
                ends.append((tip[0]+round(ex*arm*u),tip[1]+round(ey*arm*u)))
            else:ends.append((tip[0]+ex*arm*u,tip[1]+ey*arm*u))
        return stroke([ends[0],tip,ends[1]],fill=fill)
    def node(X,Y,fill=None):
        """A small filled square on a pixel point (a point to click)."""
        X,Y=P(X),P(Y);k=max(1,round(u))
        return polygon([(X-k,Y-k),(X+k,Y-k),(X+k,Y+k),(X-k,Y+k)],fill or color,fill)
    def parted(points,nodes):
        """A curve through pixel points with a node on it at each of ``nodes``: the curve stops one
        pixel short of each node (no fill of the canvas colour, which a chosen tool's darker
        background would show)."""
        nodes=[(P(x),P(y)) for x,y in nodes];g=max(1,round(u))+W/2+1;dense=[points[0]];runs=[[]]
        for (ax,ay),(bx,by) in zip(points,points[1:]):
            m=max(1,math.ceil(math.hypot(bx-ax,by-ay)/.25));dense+=[(ax+(bx-ax)*j/m,ay+(by-ay)*j/m) for j in range(1,m+1)]
        for q in dense:
            if all(math.dist(q,o)>g for o in nodes):runs[-1].append(q)
            elif runs[-1]:runs.append([])
        for run in runs:
            if len(run)>1:stroke(run,caps=(False,False))
        for o in nodes:node(*o)
    def dashes(x0,y0,x1,y1,on=3,off=2,between=False,fill=None):
        """A dashed straight stroke between two grid points, in whole pixels: a dash at each end, or
        (``between``: the ends of two strokes) a gap at each end."""
        A,B=(S(x0),S(y0)),(S(x1),S(y1));length=math.dist(A,B)
        if length<1e-9:return
        dx,dy=(B[0]-A[0])/length,(B[1]-A[1])/length;a=max(W,round(on*u));g=max(1,round(off*u))
        T=length-W if between else length+W;start=W/2 if between else -W/2
        m=int((T-g)//(a+g)) if between else max(1,int((T+g)//(a+g)));gaps=m+1 if between else m-1
        if m<1:return
        spare=T-m*a-gaps*g;pos=start
        extra=[math.floor(spare*(j+1)/gaps)-math.floor(spare*j/gaps) for j in range(gaps)] if gaps else []
        if between:pos+=g+extra.pop(0)
        for j in range(m):
            dash=a if gaps else T
            stroke([(A[0]+dx*pos,A[1]+dy*pos),(A[0]+dx*(pos+dash),A[1]+dy*(pos+dash))],caps=(False,False),fill=fill)
            if extra:pos+=dash+g+extra.pop(0)
    def dashed_box(x0,y0,x1,y1,on=3,off=2):
        for p in ((x0,y0,x1,y0),(x1,y0,x1,y1),(x1,y1,x0,y1),(x0,y1,x0,y0)):dashes(*p,on=on,off=off)
    def plus(x,y,arm,fill=None):
        X,Y=S(x),S(y);a=L(arm);stroke([(X-a,Y),(X+a,Y)],fill=fill);stroke([(X,Y-a),(X,Y+a)],fill=fill)
    def sheet(x0,y0,x1,y1,fold=5,fill=''):
        shape(x0,y0,x1-fold,y0,x1,y0+fold,x1,y1,x0,y1,fill=fill,r=(1.5,0,0,1.5,1.5));line(x1-fold,y0,x1-fold,y0+fold,x1,y0+fold)
    def scissors():
        # Upright scissors: two rings, two blades crossing at the pivot.
        for (x,y),(tx,ty) in (((14,18.5),(20.5,2.5)),((19.5,18.5),(13,2.5))):
            X,Y,A,B=oval(x,y,2.25,fill=soft)
            tip=(S(tx),S(ty));d=math.dist(tip,(X,Y));stroke([tip,(X+(tip[0]-X)/d*A,Y+(tip[1]-Y)/d*A)],caps=(True,False))
    if name=='new':
        sheet(5,2,20,22);plus(12.5,14,3)
    elif name=='open':
        line(19,10,19,7.5,11,7.5,9,5,3,5,3,20,r=1)
        shape(3,20,6.5,10.5,22,10.5,18.5,20,fill=soft)
    elif name=='save':
        shape(3,3,17,3,21,7,21,21,3,21,r=(1.5,0,0,1.5,1.5));line(7,3,7,8.5,16,8.5,16,3)
        shape(6,21,6,13.5,18,13.5,18,21,fill=soft)
    elif name=='model_info':
        # Infos du modèle: a framed sheet with its bands (like Mozart's frame).
        shape(4,2,20,2,20,22,4,22,r=1.5)
        for y0,y1,share in ((5,8.5,.45),(11,13.5,.3),(16.5,19,.18)):shape(7,y0,17,y0,17,y1,7,y1,fill=tint(c,color,share))
    elif name in ('fiches','pdf'):
        # Générer fiches: a sheet with a folded corner and its lines.
        sheet(5,2,20,22);line(8.5,9,16.5,9);line(8.5,13.5,16.5,13.5);line(8.5,18,13,18)
    elif name in ('undo','redo'):
        start=len(made)
        line(2.5,7.5,18,7.5,18,21,9,21,caps=(False,True),r=6.75);head((S(2.5),S(7.5)),-1,0,arm=5)
        if name=='redo':
            for item in made[start:]:c.scale(item,(n+8)/2,0,-1,1)
    elif name=='select':
        shape(6,3,6,19.5,10,15.5,13,21.5,15.5,20.5,12.5,14.5,18,14.5,fill=soft)
    elif name=='delete':
        line(4,6,20,6);line(9,6,9,3,15,3,15,6);line(6,6,7,21,17,21,18,6);line(10,10,10,17);line(14,10,14,17)
    elif name=='line':
        line(4,20,20,4);node(S(4),S(20));node(S(20),S(4))
    elif name=='poly':
        line(3,19,8,6,15,17,21,5);node(S(3),S(19));node(S(21),S(5))
    elif name in ('rect','rect_center','rect_round','rect_rot','para'):
        if name=='para':shape(3,18,8,6,21,6,16,18)
        elif name=='rect_rot':shape(3,11,15,3,21,12,9,20)
        elif name=='rect_round':shape(3,5,21,5,21,19,3,19,r=4.5)
        else:shape(3,5,21,5,21,19,3,19)
        if name=='rect_center':plus(12,12,3)
    elif name in ('circle','circle_radius','circle_diameter','circle_2p','circle_3p','radius','diameter'):
        X,Y,R,_=oval(12,12,9,nodes={'circle_2p':(0,180),'circle_3p':(90,210,330)}.get(name,()))
        if name in ('circle','circle_radius'):
            a=math.radians(-35);stroke([(X,Y),(X+R*math.cos(a),Y+R*math.sin(a))],caps=(False,False));node(X,Y)
        elif name=='circle_diameter':stroke([(X-R,Y),(X+R,Y)],caps=(False,False))
        elif name=='radius':
            a=math.radians(-45);tip=(X+R*math.cos(a),Y+R*math.sin(a));stroke([(X,Y),tip],caps=(False,False));head(tip,1,-1,arm=4);node(X,Y)
        elif name=='diameter':
            a=math.radians(-45);p=(X+R*math.cos(a),Y+R*math.sin(a));q=(2*X-p[0],2*Y-p[1])
            stroke([p,q],caps=(False,False));head(p,1,-1,arm=4);head(q,-1,1,arm=4)
    elif name in ('ellipse','ellipse_center','ellipse_box','ellipse_axis'):
        X,Y,A,B=oval(12,12,10,6,nodes=(0,180) if name=='ellipse_axis' else ())
        if name=='ellipse_box':polygon([(X-A,Y-B),(X+A,Y-B),(X+A,Y+B),(X-A,Y+B)])
        elif name=='ellipse_axis':stroke([(X-A,Y),(X+A,Y)],caps=(False,False))
        else:plus(12,12,3)
    elif name in ('arc_radius','arc_3p','arc_center'):
        X,Y,R=S(12),S(13.5),L(8.5)
        if name=='arc_3p':
            points=[(X+R*math.cos(math.radians(150+240*j/48)),Y+R*math.sin(math.radians(150+240*j/48))) for j in range(49)]
            parted(points,[(X,Y-R)])
        else:points=arc(X,Y,R,150,390)
        if name=='arc_center':node(X,Y)
        else:node(*points[0]);node(*points[-1])
    elif name in ('spline_fit','spline_tangent'):
        p0,p1,p2,p3=grid((3,20,6,4,18,20,21,4));points=[]
        for j in range(41):
            t=j/40;v=1-t;points.append(tuple(v**3*a+3*v*v*t*b+3*v*t*t*cc+t**3*d for a,b,cc,d in zip(p0,p1,p2,p3)))
        parted(points,[points[20]]);node(*p0);node(*p3)
    elif name=='measure':
        # Règle: a ruler across the icon, its graduations.
        A,B,C,D=grid((2,16,16,2,22,8,8,22));polygon([A,B,C,D],soft)
        for j,k in ((.2,2.5),(.4,4),(.6,2.5),(.8,4)):
            q=(P(A[0]+(B[0]-A[0])*j),P(A[1]+(B[1]-A[1])*j));m=round(k*u*.7071)
            stroke([q,(q[0]+m,q[1]+m)],caps=(False,True))
    elif name=='dimension':
        line(3,5,3,19);line(21,5,21,19);a,b=(S(3),S(12)),(S(21),S(12))
        stroke([a,b],caps=(False,False));head(a,-1,0,arm=4);head(b,1,0,arm=4)
    elif name=='dimension_aligned':
        line(2.5,16.5,7.5,21.5);line(16.5,2.5,21.5,7.5);a,b=(S(5),S(19)),(S(19),S(5))
        stroke([a,b],caps=(False,False));head(a,-1,1,arm=4);head(b,1,-1,arm=4)
    elif name=='arc_length':
        # Cote (longueur d'arc): the « Cote » with its dimension line bent into an arc.
        line(3,11,3,20);line(21,11,21,20);a,b=(S(3),S(15)),(S(21),S(15));w=(b[0]-a[0])/2;h=L(5)
        R=(w*w+h*h)/(2*h);X,Y=(a[0]+b[0])/2,a[1]-h+R;t=math.degrees(math.atan2(a[1]-Y,a[0]-X))
        points=arc(X,Y,R,t,-180-t,caps=(False,False))
        for (px,py),(qx,qy) in ((points[0],points[1]),(points[-1],points[-2])):head((px,py),px-qx,py-qy,arm=3.5)
    elif name=='angle_dimension':
        V=(S(4),S(20));line(4,20,21,20);t=math.radians(-55);E=(V[0]+L(17)*math.cos(t),V[1]+L(17)*math.sin(t))
        stroke([V,E],caps=(False,True));arc(V[0],V[1],L(11),-55,0)
    elif name in ('notch','copy_notch'):
        # Cran: the piece's edge, the cran's stem and its bar.
        X=S(12);line(3,4,21,4);stroke([(X,S(4)),(X,S(20))],caps=(False,name=='notch'))
        a=L(4);Y=S(12.5);stroke([(X-a,Y),(X+a,Y)])
        if name=='copy_notch':line(3,20,21,20)
    elif name=='drill':
        X,Y,R,_=oval(12,12,5.5);k=L(8.5)
        stroke([(X-k,Y-k),(X+k,Y+k)]);stroke([(X-k,Y+k),(X+k,Y-k)])
    elif name=='stitch':
        # Piqûre: a piece with its stitch line (dashes) a little inside the edge.
        shape(2,3,22,3,22,21,2,21,r=2);dashed_box(6,7,18,17)
    elif name=='stitch_part':
        # Piqûre sur une partie: stitches along one side, between two points.
        shape(2,3,22,3,22,21,2,21,r=2);dashes(8.5,7.5,15.5,7.5);node(S(5.5),S(7.5));node(S(18.5),S(7.5))
    elif name=='part_name':
        shape(4,4,20,4,20,22,4,22,r=1.5);shape(8,2,16,2,16,6,8,6,fill=soft);line(7.5,12,16.5,12);line(7.5,16.5,13.5,16.5)
    elif name=='material':
        # The standard stylised hide: neck notch, four leg tips and a narrow waist.
        shape(9,2,10,5,14,5,15,2,21,5,19,8,17,11,18,15,22,19,18,22,15,19,12,22,9,19,6,22,2,19,6,15,7,11,5,8,3,5,fill=soft)
    elif name=='piece_id':
        # ID unique: a badge in the family colour with a white 1.
        X,Y,R,_=oval(12,12,9.5,fill=color);ink=max(W,round(2*u));h=.5 if ink%2 else 0
        def Q(v):return math.floor(v-h+.5)+h                  # on the pixel grid of the 1's stroke
        x,top,bottom=Q(X+.5*u),Q(Y-L(5)),Q(Y+L(5))
        made.append(c.create_line(x-L(2.5),top+L(2),x,top,x,bottom,fill='#ffffff',width=ink))
        made.append(c.create_line(x-L(3)-ink/2,bottom,x+L(3)+ink/2,bottom,fill='#ffffff',width=ink))
    elif name in ('external','internal'):
        # Coupe externe / interne: the piece (with its hole for the inner cut) and upright scissors.
        shape(2,4,10.5,4,10.5,20,2,20,fill=soft,r=(1.5,1.5,4,4))
        if name=='internal':shape(4.5,8,8,8,8,16,4.5,16,fill=ground)
        scissors()
    elif name in ('surcoupe','surcoupe_simple'):
        # Précoupe / surcoupe: the piece cut first, its band, the pieces to recut inside (dashed); 0.19.11 simple: one.
        shape(2,3,22,3,22,21,2,21,fill=soft,r=1.5)
        for x0,x1 in (((8,16),) if name=='surcoupe_simple' else ((4.5,10.5),(13.5,19.5))):
            made.append(c.create_polygon(*flat(grid((x0,6,x1,6,x1,18,x0,18))),fill=ground,outline=''));dashed_box(x0,6,x1,18,on=3,off=1.5)
    elif name=='white':
        # Dessin blanc: a fountain-pen nib.
        tip=(S(3),S(21));d=(.7071,-.7071);m=(.7071,.7071)
        def at(t,s):return (tip[0]+(d[0]*t+m[0]*s)*u,tip[1]+(d[1]*t+m[1]*s)*u)
        polygon([at(0,0),at(5,-3.2),at(11,-4.5),at(11,4.5),at(5,3.2)],soft)
        polygon([at(11,-4.5),at(19,-4.5),at(19,4.5),at(11,4.5)])
        stroke([at(1.5,0),at(7,0)])
    elif name in ('move','move_anchor'):
        # Déplacer: an orthogonal cross with small, well separated arrow heads.
        line(3,12,21,12,caps=(False,False));line(12,3,12,21,caps=(False,False))
        head((S(3),S(12)),-1,0);head((S(21),S(12)),1,0);head((S(12),S(3)),0,-1);head((S(12),S(21)),0,1)
    elif name=='copy':
        # Copier: the original behind, the copy in front with its + (0.19.2: in blue).
        blue=accent(c,'blue');line(10,14,3,14,3,3,14,3,14,10,r=1.5)
        shape(10,10,21,10,21,21,10,21,fill=tint(c,blue),r=1.5,outline=blue);plus(15.5,15.5,2.5,fill=blue)
    elif name=='rotate':
        # Rotation: a turning arrow (clockwise) around its pivot.
        X,Y,R=S(12),S(12),L(8.5);points=arc(X,Y,R,10,280,caps=(True,False))
        head(points[-1],points[-1][0]-points[-2][0],points[-1][1]-points[-2][1],arm=4.5);node(X,Y)
    elif name=='scale':
        # Échelle: a small square growing into a larger one along its diagonal.
        shape(3,3,21,3,21,21,3,21);shape(3,13,11,13,11,21,3,21,fill=soft)
        a,b=(S(11),S(13)),(S(18),S(6));stroke([a,b],caps=(False,False));head(b,1,-1,arm=5)
    elif name in ('offset','offset_all'):
        # Décaler: the contour and its offset all round (0.19.2: the offset in blue).
        shape(3,3,21,3,21,21,3,21,r=4.5,outline=accent(c,'blue'));shape(7.5,7.5,16.5,7.5,16.5,16.5,7.5,16.5,fill=soft)
    elif name=='offset_vertex':
        # Décaler sommet, partie de polyligne, un côté: the line moved by the tool (0.19.2: in blue).
        line(4,10,4,21,20,21,20,10);dashes(4,10,20,10);line(4,4,20,4,fill=accent(c,'blue'))
    elif name=='offset_part':
        line(3,3,20,3,20,21,fill=accent(c,'blue'));line(3,8.5,15,8.5,15,21);node(S(3),S(8.5));node(S(15),S(21))
    elif name=='offset_edge':
        line(3,17,21,17);line(12,7,12,17);line(3,7,21,7,fill=accent(c,'blue'))
    elif name=='join':
        # Joindre: one polyline, its joints (0.19.2: in green).
        green=accent(c,'green');line(2,19,9,19,9,5,22,5)
        for y in (19,5):shape(7,y-2,11,y-2,11,y+2,7,y+2,fill=green,outline=green)
    elif name=='explode':
        # Décomposer (0.19.2): a rectangle whose four sides come apart (open corners, pushed
        # outward), each side its own colour.
        for p,key in (((6.5,3,17.5,3),'blue'),((22,7.5,22,16.5),'green'),((17.5,21,6.5,21),'orange'),((2,16.5,2,7.5),'red')):
            line(*p,fill=accent(c,key))
    elif name=='trim':
        # Couper (0.19.2: the drawing of 0.18.7 again, no longer like the Cote): the two cutting
        # edges, the line kept along each, the part removed between them in red.
        red=accent(c,'red');line(3,3,3,21);line(21,3,21,21);line(3,12,7,12);line(17,12,21,12);shape(10,10,14,10,14,14,10,14,fill=red,outline=red)
    elif name=='extend':
        # Rallonger: the line and the part added up to the boundary (0.19.2: in green).
        green=accent(c,'green');line(21,4,21,20);line(2,12,10,12)   # the green starts where the line's end stops
        a=(S(20),S(12));stroke([(S(10)+W/2,S(12)),a],caps=(False,False),fill=green);head(a,1,0,arm=4,fill=green)
    elif name=='corner':
        # Angle droit: the two sides and the corner they now make, with its square (0.19.2: in green).
        line(3,21,3,10);line(9,4,21,4);shape(3,4,9,4,9,10,3,10,outline=accent(c,'green'))
    elif name=='chamfer':
        # Chanfrein: the two sides and the chamfer joining them (0.19.2: in green).
        line(3,21,3,11);line(10,4,21,4);line(3,11,10,4,caps=(False,False),fill=accent(c,'green'))
    elif name=='fillet':
        # Arrondi: the two sides and the arc joining them (0.19.2: in green).
        points=rounded(grid((3,21,3,4,21,4)),8);stroke(points[:2]);stroke(points[-2:])
        stroke(points[1:-1],caps=(False,False),fill=accent(c,'green'))
    elif name=='belt_holes':
        # 0.19.5: Trous de ceinture: a strap with its round end and a row of holes along its middle.
        line(2,7,15,7);line(2,17,15,17)
        X,Y,R=S(15),S(12),L(5);k=max(3,math.ceil(math.pi*R/1.2))
        stroke([(X+R*math.cos(math.radians(-90+180*j/k)),Y+R*math.sin(math.radians(-90+180*j/k))) for j in range(k+1)],caps=(False,False))
        for x in (5.5,10.5,15.5):oval(x,12,1.5)
    elif name=='buckle_slot':
        # 0.19.6: Fente d'ardillon: the square end of a strap and the oblong slot along its middle.
        line(2,6,21,6,21,18,2,18,caps=(True,True));shape(7,10,16,10,16,14,7,14,r=2)
    elif name=='strap_belt':
        # 0.19.6: Bout de ceinture: the edges come in straight to a narrower straight tip (in green).
        green=accent(c,'green');line(2,7,10,7);line(2,17,10,17);line(10,7,20,9.5,20,14.5,10,17,caps=(False,False),r=1,fill=green)
    elif name=='toron':
        # 0.19.11: Poignée toron: the band bowed, its two attaches with their rounded tips.
        polygon(rounded(grid((2,13,6,13,8,10,16,10,18,13,22,13,22,16,18,16,16,15,8,15,6,16,2,16)),[1.5,0,0,0,0,1.5,1.5,0,0,0,0,1.5],closed=True))
    elif name=='passant':
        # 0.19.13: Passant: a band round a strap (the strap through it).
        line(2,10,22,10);line(2,14,22,14);shape(8,6,16,6,16,18,8,18,r=2)
    elif name=='array':
        # 0.19.13: Réseau: the same square in columns and rows. 0.19.19: its four corners (two only made a slash: « ? »,
        # 09/11/2026), the first square empty, its copies filled.
        for i in range(2):
            for j in range(2):
                x0,y0=3+i*11,3+j*11;shape(x0,y0,x0+7,y0,x0+7,y0+7,x0,y0+7,fill=soft if (i or j) else '')
    elif name=='stretch':
        # 0.19.13: Étirer: a shape whose right side is pulled (dashed window), an arrow.
        line(3,7,12,7,12,17,3,17,3,7,caps=(False,False));dashes(10,4,21,4,on=2,off=2);dashes(21,4,21,20,on=2,off=2);dashes(10,20,21,20,on=2,off=2);line(14,12,20,12,caps=(False,True))
    elif name=='break_point':
        # 0.19.13: Couper au point: a line cut in two at a point.
        line(2,15,10,9);line(14,7,22,3);oval(12,8,1.6)
    elif name=='assembly':
        # 0.19.13: Contrôle d'assemblage: two edges sewn together (orange, teal), their lengths compared.
        line(3,6,21,6,fill=accent(c,'orange'));line(3,18,21,18,fill=accent(c,'blue'));line(12,8.5,12,15.5,caps=(True,True))
    elif name=='strap_piece':
        # 0.19.6: Sangle entière: a whole strap, its round end, its pointed end and its holes.
        polygon(rounded(grid((2,8,17,8,22,12,17,16,2,16)),[4,0,0,0,4],closed=True));oval(10,12,1.2);oval(14,12,1.2)
    elif name in ('strap_round','strap_point'):
        # 0.19.3: Bout rond / Bout pointu: the two edges of a strap and its end (in green), a half round
        # or a point.
        green=accent(c,'green');line(2,7,14,7);line(2,17,14,17)
        if name=='strap_point':line(14,7,19,12,14,17,caps=(False,False),fill=green)
        else:
            X,Y,R=S(14),S(12),L(5);k=max(3,math.ceil(math.pi*R/1.2))
            stroke([(X+R*math.cos(math.radians(-90+180*j/k)),Y+R*math.sin(math.radians(-90+180*j/k))) for j in range(k+1)],caps=(False,False),fill=green)
    elif name=='mirror':
        # Symétrie: the axis, the shape and its mirror image (0.19.2: in blue).
        blue=accent(c,'blue');dashes(12,2,12,22,on=2.5,off=2);shape(2,6,9,9,9,19,2,19,fill=soft)
        shape(22,6,15,9,15,19,22,19,fill=tint(c,blue),outline=blue)
    elif name=='preparation':
        # Préparation: a piece with a band along one side.
        shape(3,3,21,3,21,21,3,21);shape(3,3,9,3,9,21,3,21,fill=soft)
    elif name in ('precut_layer','recut_layer'):
        # 0.19.14 Afficher / masquer les précoupes (the outer contour, the piece inside dashed) or the surcoupes (the
        # piece inside, the précoupe dashed); greyed and crossed out by advanced_ui.show_layer_button when hidden.
        if name=='precut_layer':
            shape(2,4,22,4,22,20,2,20,fill=soft,r=1.5)
            made.append(c.create_polygon(*flat(grid((7,8,17,8,17,16,7,16))),fill=ground,outline=''));dashed_box(7,8,17,16,on=3,off=1.5)
        else:
            dashed_box(2,4,22,20,on=3,off=1.5);shape(7,8,17,8,17,16,7,16,fill=soft,r=1)
    elif name=='prep_layer':
        # Afficher / masquer les préparations: two stacked layers (the lower one a line: when the
        # layer is hidden, advanced_ui.show_layer_button greys the icon and empties its polygons).
        line(2,15.5,12,20.5,22,15.5);shape(12,3.5,22,8.5,12,13.5,2,8.5,fill=soft)
    elif name=='grid':
        shape(3,3,21,3,21,21,3,21)
        for v in (9,15):line(v,3,v,21,caps=(False,False));line(3,v,21,v,caps=(False,False))
    elif name=='snap':
        line(8,12,8,20,21,20);shape(4,4,12,4,12,12,4,12,fill=soft)
    elif name=='ortho':
        line(4,3,4,20,21,20);line(4,15,9,15,9,20)
    elif name in ('recenter','fit'):
        for p in ((3,8,3,3,8,3),(16,3,21,3,21,8),(3,16,3,21,8,21),(16,21,21,21,21,16)):line(*p)
        if name=='recenter':plus(12,12,3.5)
    elif name=='gear':
        X,Y=S(12),S(12);outer,inner=L(10),L(7.5);points=[]
        for i in range(8):
            base=i*45
            for r,a in ((inner,base-22.5),(inner,base-12),(outer,base-8),(outer,base+8),(inner,base+12)):
                points.append((X+r*math.cos(math.radians(a)),Y+r*math.sin(math.radians(a))))
        made.append(c.create_polygon(*flat(points),fill='',outline=color,width=W));oval(12,12,3)
    else:
        before=set(c.find_all());legacy(c,name,n,color)
        for i in set(c.find_all())-before:
            c.move(i,4,4)
            try:c.itemconfigure(i,width=W)
            except Exception:pass
