"""0.16.28 « Imprimer » (Windows): the pages of the PDF written by Craft are drawn with GDI at
real size (1 mm on the plan = 1 mm on paper), without any PDF reader. Craft runs this file in
its own process: a printer driver problem never closes Craft.
0.16.29: printing straight to the printer chosen in Craft (no Windows window), A4 portrait,
100 %, copies, colour or black & white; list of printers; driver preferences on request.
0.18.1: the paper of the PDF (A4, A3, A2, A1 or A0, read from its pages) when the printer has it.
0.18.5: the clip of a page is rounded outwards to whole dots: a line is never cut at the frame.
0.19.14: the pictures of a page (the Image du modèle of the fiches) are printed too (StretchDIBits); one that cannot
be read or drawn is left out, the page is printed all the same.

  print_direct.py PDF NAME [--printer P] [--copies N] [--mono] [--devmode FILE]
  print_direct.py --printers OUT.json
  print_direct.py --prefs PRINTER DEVMODE_FILE

Exit codes: 0 done, 1 cancelled, 3 refused with a message already shown, 2 other error
(Craft then opens the PDF instead)."""
import math,re,struct,sys

A4=(210.0,297.0)
PT=25.4/72
# Paper sizes (portrait, mm) and their Windows codes (DMPAPER_A4 9, A3 8, A2 66; A1 and A0
# have none: asked as a user size in tenths of mm).
PAPERS={'A4':(210.,297.,9),'A3':(297.,420.,8),'A2':(420.,594.,66),'A1':(594.,841.,0),'A0':(841.,1189.,0)}
DMPAPER_USER=256


DM_ORIENTATION,DM_PAPERSIZE,DM_PAPERLENGTH,DM_PAPERWIDTH,DM_SCALE,DM_COPIES,DM_COLOR=0x1,0x2,0x4,0x8,0x10,0x100,0x800


def tune_devmode(buf,mono,paper='A4',keep_paper=False):
    """Printer settings of the job (DEVMODEW): A4 (or ``paper``) portrait, 100 %, one copy (Craft
    repeats the pages itself), colour or black & white. ``keep_paper``: the paper chosen in the
    printer's preferences stays (a driver that names A1 / A0 its own way)."""
    width,height,code=PAPERS.get(paper,PAPERS['A4'])
    fields=struct.unpack_from('<I',buf,72)[0]|DM_ORIENTATION|DM_SCALE|DM_COPIES|DM_COLOR
    values=[(76,1),(84,100),(86,1),(92,1 if mono else 2)]
    if not keep_paper:
        if code:fields=(fields|DM_PAPERSIZE)&~(DM_PAPERLENGTH|DM_PAPERWIDTH);values.append((78,code))
        else:fields|=DM_PAPERSIZE|DM_PAPERLENGTH|DM_PAPERWIDTH;values+=[(78,DMPAPER_USER),(80,round(height*10)),(82,round(width*10))]
    struct.pack_into('<I',buf,72,fields)
    for offset,value in sorted(values):struct.pack_into('<h',buf,offset,value)
    return buf


def pdf_size(data):
    """Width and height (mm) of the pages of a PDF written by Craft; A4 when not found."""
    m=re.search(rb'/MediaBox \[0 0 ([0-9.]+) ([0-9.]+)\]',data)
    return (float(m.group(1))*PT,float(m.group(2))*PT) if m else A4


def paper_of(size):
    """The name of a paper size (A4…A0, portrait), None for another size."""
    for name,(w,h,_) in PAPERS.items():
        if abs(size[0]-w)<=2 and abs(size[1]-h)<=2:return name
    return None


def pdf_pages(data):
    """Content streams of a PDF written by Craft (not compressed, one per page, in order)."""
    return [data[m.end():m.end()+int(m.group(1))] for m in re.finditer(rb'<< /Length (\d+) >>\nstream\n',data)]


def tokens(data):
    i=0;n=len(data)
    while i<n:
        c=data[i:i+1]
        if c.isspace():i+=1;continue
        if c==b'(':
            j=i+1;buf=bytearray();depth=1
            while j<n:
                ch=data[j:j+1]
                if ch==b'\\':buf+=data[j+1:j+2];j+=2;continue
                if ch==b'(':depth+=1
                elif ch==b')':
                    depth-=1
                    if not depth:break
                buf+=ch;j+=1
            yield 'str',bytes(buf).decode('cp1252','replace');i=j+1;continue
        if c in (b'[',b']'):yield c.decode(),None;i+=1;continue
        j=i
        while j<n and not data[j:j+1].isspace() and data[j:j+1] not in (b'(',b'[',b']'):j+=1
        word=data[i:j].decode('latin-1');i=j
        try:yield 'num',float(word)
        except ValueError:yield ('name' if word.startswith('/') else 'op'),word


def paper(x,y,height=A4[1]):
    """PDF points (origin bottom left) -> millimetres on the sheet (origin top left)."""
    return x*PT,height-y*PT


def run(data,out,height=A4[1],images=None):
    """Draw one page on `out` (stroke, fill, clip, restore, text), in millimetres; 0.19.14: the pictures of ``images``
    (name → dict(width, height, rgb)) where the page places them."""
    stack=[];array=None;subpaths=[];saved=[]
    mm=lambda x,y:paper(x,y,height)
    st=dict(stroke=(0,0,0),fill=(0,0,0),width=1.0*PT,dash=[],font=('/F1',9.0),ctm=(1.,0.,0.,1.,0.,0.))
    for kind,value in tokens(data):
        if kind=='[':array=[];continue
        if kind==']':stack.append(array or []);array=None;continue
        if array is not None:array.append(value);continue
        if kind!='op':stack.append(value);continue
        op=value
        if op=='m':subpaths.append([[mm(*stack[-2:])],False])
        elif op=='l' and subpaths:subpaths[-1][0].append(mm(*stack[-2:]))
        elif op=='h' and subpaths:subpaths[-1][1]=True
        elif op=='re':
            x,y,w,h=stack[-4:];subpaths.append([[mm(x,y),mm(x+w,y),mm(x+w,y+h),mm(x,y+h)],True])
        elif op=='S':out.stroke(subpaths,st['stroke'],st['width'],st['dash']);subpaths=[]
        elif op=='f':out.fill(subpaths,st['fill']);subpaths=[]
        elif op=='W':
            pts=[p for sub,_ in subpaths for p in sub]
            if pts:out.clip((min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts)))
        elif op=='n':subpaths=[]
        elif op=='q':saved.append(dict(st,dash=list(st['dash'])));out.save()
        elif op=='Q':
            if saved:st=saved.pop()
            out.restore()
        elif op=='w':st['width']=stack[-1]*PT
        elif op=='d':st['dash']=[v*PT for v in stack[-2]] if len(stack)>=2 and isinstance(stack[-2],list) else []
        elif op=='RG':st['stroke']=tuple(stack[-3:])
        elif op=='rg':st['fill']=tuple(stack[-3:])
        elif op=='G':st['stroke']=(stack[-1],)*3
        elif op=='g':st['fill']=(stack[-1],)*3
        elif op=='Tf':st['font']=(stack[-2],stack[-1])
        elif op=='Tm':st['matrix']=tuple(stack[-6:])
        elif op=='Tj':
            a,b,c,d,e,f=st.get('matrix',(1,0,0,1,0,0));x,y=mm(e,f)
            out.text(x,y,math.degrees(math.atan2(b,a)),st['font'][1]*math.hypot(a,b)*PT,st['font'][0]=='/F2',stack[-1],st['fill'])
        elif op=='cm' and len(stack)>=6 and all(isinstance(v,float) for v in stack[-6:]):
            a,b,c,d,e,f=stack[-6:];A,B,C,D,E,F=st['ctm']
            st['ctm']=(a*A+b*C,a*B+b*D,c*A+d*C,c*B+d*D,e*A+f*C+E,e*B+f*D+F)
        elif op=='Do' and stack and images and isinstance(stack[-1],str) and images.get(stack[-1]):
            a,b,c,d,e,f=st['ctm'];corners=[mm(a*u+c*v+e,b*u+d*v+f) for u,v in ((0,0),(1,0),(0,1),(1,1))]
            box=(min(p[0] for p in corners),min(p[1] for p in corners),max(p[0] for p in corners),max(p[1] for p in corners))
            try:out.image(images[stack[-1]],box)
            except Exception:pass   # a picture the printer refuses: the page without it
        stack=[]


def page_images(raw,count):
    """0.19.14: the pictures of each of the ``count`` pages of a PDF written by Craft: [{'/Im1': dict(width, height,
    rgb)}…] (rows from the top); a picture that cannot be read is left out, all of them when the PDF is not read."""
    out=[{} for _ in range(count)]
    if b'/Subtype /Image' not in raw:return out
    try:
        import pdf_reader
        doc=pdf_reader.Document(raw);pages=doc.pages()
    except Exception:return out
    if len(pages)!=count:return out
    found={}
    for k,page in enumerate(pages):
        try:
            resources=doc.resolve(page.get('Resources'));xobjects=doc.resolve(resources.get('XObject')) if isinstance(resources,dict) else None
            for name,ref in (xobjects.items() if isinstance(xobjects,dict) else ()):
                key=ref.num if isinstance(ref,pdf_reader.Ref) else name
                if key not in found:found[key]=picture_of(doc,doc.resolve(ref))
                if found[key]:out[k]['/'+name]=found[key]
        except Exception:continue
    return out


def picture_of(doc,stream):
    """The pixels of an image of the PDF (a JPEG decoded by backdrop: GDI+ under Windows): dict(width, height, rgb),
    None when it cannot be read."""
    try:
        import pdf_reader
        if not isinstance(stream,pdf_reader.Stream) or stream.dict.get('Subtype')!='Image':return None
        image=pdf_reader.image_data(doc,stream);w,h=image['width'],image['height']
        if image['kind']=='jpeg':
            import backdrop
            w,h,rgb=backdrop.decoded_rgb(image['data'])
        elif image['kind']=='rgb' and w>0 and h>0 and len(image['data'])>=w*h*3:rgb=bytes(image['data'][:w*h*3])
        elif image['kind']=='gray' and w>0 and h>0 and len(image['data'])>=w*h:
            grey=bytes(image['data'][:w*h]);rgb=bytearray(w*h*3);rgb[0::3]=grey;rgb[1::3]=grey;rgb[2::3]=grey;rgb=bytes(rgb)
        else:return None
        return dict(width=w,height=h,rgb=rgb) if w>0 and h>0 else None
    except Exception:return None


def dib_rows(width,height,rgb):
    """0.19.14: RGB pixels (rows from the top) as the bits of a 24-bit Windows DIB: rows from the bottom, BGR, each
    a multiple of 4 bytes."""
    row=width*3;stride=(row+3)&~3;out=bytearray(stride*height)
    for k in range(height):
        line=bytearray(rgb[k*row:(k+1)*row]).ljust(row,b'\xff');line[0::3],line[2::3]=line[2::3],line[0::3]
        start=(height-1-k)*stride;out[start:start+row]=line
    return bytes(out)


class Sheet:
    """GDI drawing on a printer device context; millimetres -> printer dots, real size."""
    def __init__(self,gdi,hdc):
        self.gdi=gdi;self.hdc=hdc
        self.dx=gdi.GetDeviceCaps(hdc,88);self.dy=gdi.GetDeviceCaps(hdc,90)          # LOGPIXELSX/Y
        self.ox=gdi.GetDeviceCaps(hdc,112);self.oy=gdi.GetDeviceCaps(hdc,113)        # PHYSICALOFFSETX/Y
        self.size=(gdi.GetDeviceCaps(hdc,110)/self.dx*25.4,gdi.GetDeviceCaps(hdc,111)/self.dy*25.4)   # PHYSICALWIDTH/HEIGHT
    def dot(self,p):return (round(p[0]/25.4*self.dx-self.ox),round(p[1]/25.4*self.dy-self.oy))
    def length(self,mm):return max(1,round(mm/25.4*self.dx))
    @staticmethod
    def colour(rgb):
        r,g,b=(max(0,min(255,round(v*255))) for v in rgb);return r|g<<8|b<<16
    def stroke(self,subpaths,rgb,width,dash):
        g=self.gdi;pen=g.pen(self.length(width),self.colour(rgb),[self.length(v) for v in dash])
        old=g.SelectObject(self.hdc,pen)
        try:
            for pts,closed in subpaths:
                dots=[self.dot(p) for p in pts+(pts[:1] if closed else [])]
                if len(dots)>1:g.polyline(self.hdc,dots)
        finally:g.SelectObject(self.hdc,old);g.DeleteObject(pen)
    def fill(self,subpaths,rgb):
        g=self.gdi;brush=g.CreateSolidBrush(self.colour(rgb));old_brush=g.SelectObject(self.hdc,brush);old_pen=g.SelectObject(self.hdc,g.GetStockObject(8))   # NULL_PEN
        try:
            for pts,closed in subpaths:
                if len(pts)>2:g.polygon(self.hdc,[self.dot(p) for p in pts])
        finally:g.SelectObject(self.hdc,old_pen);g.SelectObject(self.hdc,old_brush);g.DeleteObject(brush)
    def clip(self,box):
        # 0.18.5: the PDF's clip (already larger than the area by half the widest line) rounded
        # outwards to whole dots, its right and bottom edges included: the rounding never shaves a
        # line drawn against the frame.
        x=math.floor(box[0]/25.4*self.dx-self.ox);y=math.floor(box[1]/25.4*self.dy-self.oy)
        X=math.ceil(box[2]/25.4*self.dx-self.ox)+1;Y=math.ceil(box[3]/25.4*self.dy-self.oy)+1
        self.gdi.IntersectClipRect(self.hdc,x,y,X,Y)
    def save(self):self.gdi.SaveDC(self.hdc)
    def restore(self):self.gdi.RestoreDC(self.hdc,-1)
    def text(self,x,y,angle,size,bold,text,rgb):
        g=self.gdi;tenths=round(angle*10)
        font=g.font(-max(1,round(size/25.4*self.dy)),tenths,700 if bold else 400)
        old=g.SelectObject(self.hdc,font)
        try:
            g.SetBkMode(self.hdc,1);g.SetTextAlign(self.hdc,24);g.SetTextColor(self.hdc,self.colour(rgb))   # TRANSPARENT, TA_BASELINE|TA_LEFT
            X,Y=self.dot((x,y));g.TextOutW(self.hdc,X,Y,text,len(text))
        finally:g.SelectObject(self.hdc,old);g.DeleteObject(font)
    def image(self,picture,box):
        """0.19.14: a picture (dict(width, height, rgb)) stretched into ``box`` (mm: left, top, right, bottom)."""
        x0,y0=self.dot(box[:2]);x1,y1=self.dot(box[2:])
        if x1>x0 and y1>y0:self.gdi.picture(self.hdc,x0,y0,x1-x0,y1-y0,picture['width'],picture['height'],picture['rgb'])


def windows_gdi():
    """ctypes access to GDI, the print dialog and message boxes (Windows only)."""
    import ctypes
    from ctypes import wintypes as w
    gdi=ctypes.WinDLL('gdi32');comdlg=ctypes.WinDLL('comdlg32');user=ctypes.WinDLL('user32');kernel=ctypes.WinDLL('kernel32');spool=ctypes.WinDLL('winspool.drv')
    class PRINTER_INFO_4W(ctypes.Structure):_fields_=[('pPrinterName',w.LPWSTR),('pServerName',w.LPWSTR),('Attributes',w.DWORD)]
    class POINT(ctypes.Structure):_fields_=[('x',ctypes.c_long),('y',ctypes.c_long)]
    class LOGBRUSH(ctypes.Structure):_fields_=[('lbStyle',w.UINT),('lbColor',w.DWORD),('lbHatch',ctypes.c_size_t)]
    class DOCINFOW(ctypes.Structure):_fields_=[('cbSize',ctypes.c_int),('lpszDocName',w.LPCWSTR),('lpszOutput',w.LPCWSTR),('lpszDatatype',w.LPCWSTR),('fwType',w.DWORD)]
    class BITMAPINFOHEADER(ctypes.Structure):_fields_=[('biSize',w.DWORD),('biWidth',ctypes.c_long),('biHeight',ctypes.c_long),('biPlanes',w.WORD),('biBitCount',w.WORD),
                                                         ('biCompression',w.DWORD),('biSizeImage',w.DWORD),('biXPelsPerMeter',ctypes.c_long),('biYPelsPerMeter',ctypes.c_long),('biClrUsed',w.DWORD),('biClrImportant',w.DWORD)]
    fields=[('lStructSize',w.DWORD),('hwndOwner',w.HANDLE),('hDevMode',w.HANDLE),('hDevNames',w.HANDLE),('hDC',w.HANDLE),('Flags',w.DWORD),
            ('nFromPage',w.WORD),('nToPage',w.WORD),('nMinPage',w.WORD),('nMaxPage',w.WORD),('nCopies',w.WORD),('hInstance',w.HANDLE),('lCustData',w.LPARAM),
            ('lpfnPrintHook',ctypes.c_void_p),('lpfnSetupHook',ctypes.c_void_p),('lpPrintTemplateName',w.LPCWSTR),('lpSetupTemplateName',w.LPCWSTR),('hPrintTemplate',w.HANDLE),('hSetupTemplate',w.HANDLE)]
    if ctypes.sizeof(ctypes.c_void_p)==4:
        class PRINTDLGW(ctypes.Structure):_pack_=1;_fields_=fields     # 32-bit commdlg.h is packed
    else:
        class PRINTDLGW(ctypes.Structure):_fields_=fields
    H=w.HANDLE;I=ctypes.c_int
    for name,res,args in [('GetDeviceCaps',I,[H,I]),('SelectObject',H,[H,H]),('DeleteObject',w.BOOL,[H]),('GetStockObject',H,[I]),
                          ('CreateSolidBrush',H,[w.DWORD]),('ExtCreatePen',H,[w.DWORD,w.DWORD,ctypes.POINTER(LOGBRUSH),w.DWORD,ctypes.POINTER(w.DWORD)]),
                          ('Polyline',w.BOOL,[H,ctypes.POINTER(POINT),I]),('Polygon',w.BOOL,[H,ctypes.POINTER(POINT),I]),('IntersectClipRect',I,[H,I,I,I,I]),
                          ('SaveDC',I,[H]),('RestoreDC',w.BOOL,[H,I]),('SetBkMode',I,[H,I]),('SetTextAlign',w.UINT,[H,w.UINT]),('SetTextColor',w.DWORD,[H,w.DWORD]),
                          ('TextOutW',w.BOOL,[H,I,I,w.LPCWSTR,I]),('CreateFontW',H,[I,I,I,I,I]+[w.DWORD]*8+[w.LPCWSTR]),
                          ('StartDocW',I,[H,ctypes.POINTER(DOCINFOW)]),('StartPage',I,[H]),('EndPage',I,[H]),('EndDoc',I,[H]),('AbortDoc',I,[H]),('DeleteDC',w.BOOL,[H]),
                          ('StretchDIBits',I,[H,I,I,I,I,I,I,I,I,ctypes.c_void_p,ctypes.c_void_p,w.UINT,w.DWORD]),('SetStretchBltMode',I,[H,I]),('SetBrushOrgEx',w.BOOL,[H,I,I,ctypes.c_void_p])]:
        f=getattr(gdi,name);f.restype=res;f.argtypes=args
    comdlg.PrintDlgW.restype=w.BOOL;comdlg.PrintDlgW.argtypes=[ctypes.POINTER(PRINTDLGW)];comdlg.CommDlgExtendedError.restype=w.DWORD
    gdi.CreateDCW.restype=H;gdi.CreateDCW.argtypes=[w.LPCWSTR,w.LPCWSTR,w.LPCWSTR,ctypes.c_void_p]
    spool.EnumPrintersW.restype=w.BOOL;spool.EnumPrintersW.argtypes=[w.DWORD,w.LPCWSTR,w.DWORD,ctypes.c_void_p,w.DWORD,ctypes.POINTER(w.DWORD),ctypes.POINTER(w.DWORD)]
    spool.GetDefaultPrinterW.restype=w.BOOL;spool.GetDefaultPrinterW.argtypes=[ctypes.c_void_p,ctypes.POINTER(w.DWORD)]
    spool.OpenPrinterW.restype=w.BOOL;spool.OpenPrinterW.argtypes=[w.LPCWSTR,ctypes.POINTER(H),ctypes.c_void_p]
    spool.ClosePrinter.restype=w.BOOL;spool.ClosePrinter.argtypes=[H]
    spool.DocumentPropertiesW.restype=ctypes.c_long;spool.DocumentPropertiesW.argtypes=[H,H,w.LPCWSTR,ctypes.c_void_p,ctypes.c_void_p,w.DWORD]
    kernel.GlobalFree.restype=H;kernel.GlobalFree.argtypes=[H]
    user.MessageBoxW.restype=I;user.MessageBoxW.argtypes=[H,w.LPCWSTR,w.LPCWSTR,w.UINT]

    class Api:
        def __getattr__(self,name):return getattr(gdi,name)
        def pen(self,width,colour,dash):
            brush=LOGBRUSH(0,colour,0)          # BS_SOLID
            style=0x10000|0x200|0x0             # PS_GEOMETRIC|PS_ENDCAP_FLAT|PS_JOIN_ROUND
            if dash:
                array=(w.DWORD*len(dash))(*dash);return gdi.ExtCreatePen(style|7,width,ctypes.byref(brush),len(dash),array)   # PS_USERSTYLE
            return gdi.ExtCreatePen(style,width,ctypes.byref(brush),0,None)
        def polyline(self,hdc,dots):gdi.Polyline(hdc,(POINT*len(dots))(*[POINT(*d) for d in dots]),len(dots))
        def polygon(self,hdc,dots):gdi.Polygon(hdc,(POINT*len(dots))(*[POINT(*d) for d in dots]),len(dots))
        def picture(self,hdc,x,y,width,height,w_px,h_px,rgb):
            """0.19.14: RGB pixels stretched into a rectangle of printer dots (a 24-bit DIB from the bottom, halftoned)."""
            bits=dib_rows(w_px,h_px,rgb);info=BITMAPINFOHEADER(ctypes.sizeof(BITMAPINFOHEADER),w_px,h_px,1,24,0,len(bits),0,0,0,0)
            gdi.SetStretchBltMode(hdc,4);gdi.SetBrushOrgEx(hdc,0,0,None)   # HALFTONE, its brush origin set after it
            gdi.StretchDIBits(hdc,x,y,width,height,0,0,w_px,h_px,bits,ctypes.byref(info),0,0xCC0020)   # DIB_RGB_COLORS, SRCCOPY
        def font(self,height,tenths,weight):
            return gdi.CreateFontW(height,0,tenths,tenths,weight,0,0,0,1,0,0,0,0x22,'Arial')   # DEFAULT_CHARSET, VARIABLE_PITCH|FF_SWISS
        def dialog(self):
            """Windows print dialog; the chosen printer's device context, or None if cancelled."""
            pd=PRINTDLGW();pd.lStructSize=ctypes.sizeof(PRINTDLGW);pd.nCopies=1
            pd.Flags=0x100|0x4|0x8|0x40000|0x100000   # RETURNDC, NOSELECTION, NOPAGENUMS, USEDEVMODECOPIESANDCOLLATE, HIDEPRINTTOFILE
            ok=comdlg.PrintDlgW(ctypes.byref(pd))
            for handle in (pd.hDevMode,pd.hDevNames):
                if handle:kernel.GlobalFree(handle)
            if not ok:
                if comdlg.CommDlgExtendedError():raise OSError('Boîte d’impression indisponible.')
                return None
            return pd.hDC
        def message(self,text):user.MessageBoxW(None,text,'Craft · Imprimer',0x30|0x10000)   # MB_ICONWARNING|MB_SETFOREGROUND
        def printers(self):
            """Installed printers and the default one."""
            needed=w.DWORD(0);count=w.DWORD(0);flags=2|4      # PRINTER_ENUM_LOCAL|PRINTER_ENUM_CONNECTIONS
            spool.EnumPrintersW(flags,None,4,None,0,ctypes.byref(needed),ctypes.byref(count));names=[]
            if needed.value:
                buf=ctypes.create_string_buffer(needed.value)
                if spool.EnumPrintersW(flags,None,4,ctypes.addressof(buf),needed.value,ctypes.byref(needed),ctypes.byref(count)):
                    info=ctypes.cast(buf,ctypes.POINTER(PRINTER_INFO_4W));names=[info[i].pPrinterName for i in range(count.value) if info[i].pPrinterName]
            size=w.DWORD(0);spool.GetDefaultPrinterW(None,ctypes.byref(size));default=''
            if size.value:
                text=ctypes.create_unicode_buffer(size.value)
                if spool.GetDefaultPrinterW(ctypes.addressof(text),ctypes.byref(size)):default=text.value
            return dict(printers=names,default=default)
        def devmode(self,name,saved=None,prompt=False):
            """The printer's settings (DEVMODE bytes): the driver's own, or saved ones merged by the
            driver; prompt opens the driver's preferences window (None when cancelled)."""
            h=H()
            if not spool.OpenPrinterW(name,ctypes.byref(h),None):raise OSError('Imprimante introuvable : '+name)
            try:
                size=spool.DocumentPropertiesW(None,h,name,None,None,0)
                if size<=0:raise OSError('Réglages de l’imprimante illisibles.')
                if saved is not None and len(saved)!=size:saved=None        # another driver version
                out=ctypes.create_string_buffer(size);source=ctypes.create_string_buffer(bytes(saved),size) if saved else None
                result=spool.DocumentPropertiesW(None,h,name,ctypes.addressof(out),ctypes.addressof(source) if source else None,2|(8 if source else 0)|(4 if prompt else 0))
                if result<0:raise OSError('Réglages de l’imprimante refusés.')
                if prompt and result!=1:return None
                return out.raw
            finally:spool.ClosePrinter(h)
        def printer_dc(self,name,mono,saved=None,paper='A4',keep_paper=False):
            data=tune_devmode(bytearray(self.devmode(name,saved)),mono,paper,keep_paper)
            data=bytearray(self.devmode(name,bytes(data)))          # the driver checks the paper / 100 % / colour
            buf=ctypes.create_string_buffer(bytes(data),len(data))
            dc=gdi.CreateDCW('WINSPOOL',name,None,ctypes.addressof(buf))
            if not dc:raise OSError('Imprimante indisponible : '+name)
            return dc
        def preferences(self,name,file):
            from pathlib import Path
            path=Path(file);saved=path.read_bytes() if path.is_file() else None
            data=self.devmode(name,saved,prompt=True)
            if data is None:return 1
            path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);return 0
        def document(self,hdc,name):
            info=DOCINFOW(ctypes.sizeof(DOCINFOW),name,None,None,0)
            if gdi.StartDocW(hdc,ctypes.byref(info))<=0:raise OSError('Impression refusée par l’imprimante.')
    return Api()


def print_file(file,name='Craft',api=None,printer=None,copies=1,mono=False,devmode=None):
    from pathlib import Path
    raw=Path(file).read_bytes();pages=pdf_pages(raw)
    if not pages:return 2
    size=pdf_size(raw);wanted=paper_of(size) or 'A4'
    api=api or windows_gdi();saved=None
    fits=lambda sheet:abs(sheet.size[0]-size[0])<=3 and abs(sheet.size[1]-size[1])<=3
    if printer:
        if devmode:
            try:saved=Path(devmode).read_bytes()
            except OSError:saved=None
        hdc=api.printer_dc(printer,mono,saved,paper=wanted)
    else:hdc=api.dialog()
    if not hdc:return 1
    try:
        sheet=Sheet(api,hdc)
        if not fits(sheet) and printer and saved:
            # The paper chosen with « Propriétés… » (a driver naming A1 / A0 its own way).
            api.DeleteDC(hdc);hdc=api.printer_dc(printer,mono,saved,paper=wanted,keep_paper=True);sheet=Sheet(api,hdc)
        if not fits(sheet):
            api.message(f'Choisir le papier {wanted} (portrait) dans les préférences de l’imprimante.');return 3
        images=page_images(raw,len(pages))   # 0.19.14: the Image du modèle of the fiches
        api.document(hdc,name)
        try:
            for _ in range(max(1,copies)):           # copies kept together (1, 2, 3… then again)
                for data,pictures in zip(pages,images):
                    api.StartPage(hdc);run(data,sheet,size[1],pictures);api.EndPage(hdc)
        except Exception:
            api.AbortDoc(hdc);raise
        api.EndDoc(hdc);return 0
    finally:api.DeleteDC(hdc)


def main(argv):
    try:
        from pathlib import Path
        if argv and argv[0]=='--printers':
            import json;Path(argv[1]).write_text(json.dumps(windows_gdi().printers()),encoding='utf-8');return 0
        if argv and argv[0]=='--prefs':return windows_gdi().preferences(argv[1],argv[2])
        args=list(argv);file=args.pop(0);name=args.pop(0) if args and not args[0].startswith('--') else 'Craft';options={}
        while args:
            key=args.pop(0)
            if key=='--mono':options['mono']=True
            elif key in ('--printer','--copies','--devmode') and args:options[key[2:]]=args.pop(0)
        return print_file(file,name,printer=options.get('printer'),copies=max(1,min(99,int(options.get('copies',1)))),mono=options.get('mono',False),devmode=options.get('devmode'))
    except Exception:return 2


if __name__=='__main__':sys.exit(main(sys.argv[1:]))
