"""Center the document caption in the existing Windows title bar.

An owned, click-through Win32 surface draws only text over the native caption.
The native frame, menu, resize/snap and system buttons are retained. No extra
client row and no second taskbar entry. Non-Windows/failure uses a native title.
"""
import ctypes,os,time,tkinter as tk


def caption_geometry(window,bar,text_width,text_height):
    left,top,right,bottom=window;L,T,R,B=bar
    reserve=max(180,6*(B-T))
    available=right-left-2*reserve
    if available<100 or B<=T:return None
    width=min(max(100,int(text_width)+16),available)
    height=min(max(12,int(text_height)+2),B-T)
    return (round((left+right-width)/2),round((T+B-height)/2),width,height)


def premultiply_caption(pixels,color,ink_on_white=False):
    """Convert grayscale glyph coverage to premultiplied BGRA.

    GDI's alpha byte is undefined. Coverage comes from RGB, never a color key;
    this keeps antialiased edges transparent instead of leaving dark fringes.
    0.17.0: dark text is rendered dark on white (``ink_on_white``), as Windows draws
    it on a light bar; white-on-black coverage made dark letters look bold.
    """
    red,green,blue=(int(color[i:i+2],16) for i in (1,3,5))
    for i in range(0,len(pixels),4):
        alpha=255-min(pixels[i],pixels[i+1],pixels[i+2]) if ink_on_white else max(pixels[i],pixels[i+1],pixels[i+2])
        pixels[i:i+4]=bytes(((blue*alpha+127)//255,(green*alpha+127)//255,(red*alpha+127)//255,alpha))
    return pixels


def dark(color):
    return sum(int(color[i:i+2],16)*k for i,k in ((1,299),(3,587),(5,114)))<128000


class LOGFONTW(ctypes.Structure):
    """Win32 LOGFONTW (ctypes.wintypes does not define it): LONG fields are 32-bit."""
    _fields_=[('lfHeight',ctypes.c_int32),('lfWidth',ctypes.c_int32),('lfEscapement',ctypes.c_int32),('lfOrientation',ctypes.c_int32),('lfWeight',ctypes.c_int32),
              ('lfItalic',ctypes.c_ubyte),('lfUnderline',ctypes.c_ubyte),('lfStrikeOut',ctypes.c_ubyte),('lfCharSet',ctypes.c_ubyte),('lfOutPrecision',ctypes.c_ubyte),
              ('lfClipPrecision',ctypes.c_ubyte),('lfQuality',ctypes.c_ubyte),('lfPitchAndFamily',ctypes.c_ubyte),('lfFaceName',ctypes.c_wchar*32)]


def colorref(color):
    """'#rrggbb' to a Win32 COLORREF (0x00bbggrr)."""
    return int(color[1:3],16)|int(color[3:5],16)<<8|int(color[5:7],16)<<16


def caption_text_colors(background,active):
    """Text colour for the title on a sampled bar colour: black or white by
    contrast, dimmed toward the bar when the window is inactive, as Windows does."""
    r,g,b=(int(background[i:i+2],16) for i in (1,3,5))
    ink=(0,0,0) if (0.299*r+0.587*g+0.114*b)>=140 else (255,255,255)
    if not active:ink=tuple(round(i+(c-i)*.55) for i,c in zip(ink,(r,g,b)))
    return '#'+''.join(f'{v:02x}' for v in ink)


def opaque_caption(pixels):
    """GDI clears the alpha byte where it draws: the whole surface is opaque."""
    pixels[3::4]=b'\xff'*(len(pixels)//4)
    return pixels


class WindowsCaptionAPI:
    def __init__(self):
        from ctypes import wintypes as w
        self.w=w;self.u=ctypes.WinDLL('user32',use_last_error=True)
        self.result=ctypes.c_ssize_t;self.P=ctypes.c_void_p
        self.proc_type=ctypes.WINFUNCTYPE(self.result,w.HWND,w.UINT,w.WPARAM,w.LPARAM)
        class TitleInfo(ctypes.Structure):_fields_=[('size',w.DWORD),('rect',w.RECT),('states',w.DWORD*6)]
        self.TitleInfo=TitleInfo
        signatures={'GetAncestor':([w.HWND,w.UINT],w.HWND),'GetWindowRect':([w.HWND,ctypes.POINTER(w.RECT)],w.BOOL),
          'GetTitleBarInfo':([w.HWND,ctypes.POINTER(TitleInfo)],w.BOOL),'IsIconic':([w.HWND],w.BOOL),'IsWindowVisible':([w.HWND],w.BOOL),'IsWindow':([w.HWND],w.BOOL),
          'GetSysColor':([ctypes.c_int],w.DWORD),'CallWindowProcW':([self.P,w.HWND,w.UINT,w.WPARAM,w.LPARAM],self.result),
          'SetWindowPos':([w.HWND,w.HWND,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,w.UINT],w.BOOL)}
        for name,(args,result) in signatures.items():fn=getattr(self.u,name);fn.argtypes=args;fn.restype=result
        self.get=getattr(self.u,'GetWindowLongPtrW' if ctypes.sizeof(self.P)==8 else 'GetWindowLongW');self.get.argtypes=[w.HWND,ctypes.c_int];self.get.restype=self.result
        self.put=getattr(self.u,'SetWindowLongPtrW' if ctypes.sizeof(self.P)==8 else 'SetWindowLongW');self.put.argtypes=[w.HWND,ctypes.c_int,self.result];self.put.restype=self.result
        self.hooks=[]
        self._init_text_renderer()
    def _init_text_renderer(self):
        w=self.w;P=self.P
        self.g=ctypes.WinDLL('gdi32',use_last_error=True)
        class Header(ctypes.Structure):
            _fields_=[('size',w.DWORD),('width',w.LONG),('height',w.LONG),('planes',w.WORD),('bits',w.WORD),('compression',w.DWORD),('image_size',w.DWORD),('xppm',w.LONG),('yppm',w.LONG),('used',w.DWORD),('important',w.DWORD)]
        class BitmapInfo(ctypes.Structure):_fields_=[('header',Header),('colors',w.DWORD*1)]
        class Blend(ctypes.Structure):_fields_=[('operation',w.BYTE),('flags',w.BYTE),('constant',w.BYTE),('format',w.BYTE)]
        self.BitmapInfo=BitmapInfo;self.Blend=Blend
        signatures={
          'CreateCompatibleDC':([P],P),'DeleteDC':([P],w.BOOL),
          'CreateDIBSection':([P,ctypes.POINTER(BitmapInfo),w.UINT,ctypes.POINTER(P),P,w.DWORD],P),
          'SelectObject':([P,P],P),'DeleteObject':([P],w.BOOL),
          'CreateFontW':([ctypes.c_int]*5+[w.DWORD]*8+[w.LPCWSTR],P),
          'SetBkMode':([P,ctypes.c_int],ctypes.c_int),'SetTextColor':([P,w.DWORD],w.DWORD),'GdiFlush':([],w.BOOL)}
        for name,(args,result) in signatures.items():
            fn=getattr(self.g,name);fn.argtypes=args;fn.restype=result
        self.u.DrawTextW.argtypes=[P,w.LPCWSTR,ctypes.c_int,ctypes.POINTER(w.RECT),w.UINT];self.u.DrawTextW.restype=ctypes.c_int
        self.u.UpdateLayeredWindow.argtypes=[w.HWND,P,ctypes.POINTER(w.POINT),ctypes.POINTER(w.SIZE),P,ctypes.POINTER(w.POINT),w.DWORD,ctypes.POINTER(Blend),w.DWORD];self.u.UpdateLayeredWindow.restype=w.BOOL
        w=self.w
        class NonClientMetrics(ctypes.Structure):
            _fields_=[('size',w.UINT),('border',ctypes.c_int),('scroll_width',ctypes.c_int),('scroll_height',ctypes.c_int),('caption_width',ctypes.c_int),('caption_height',ctypes.c_int),
                      ('caption_font',LOGFONTW),('small_caption_width',ctypes.c_int),('small_caption_height',ctypes.c_int),('small_caption_font',LOGFONTW),
                      ('menu_width',ctypes.c_int),('menu_height',ctypes.c_int),('menu_font',LOGFONTW),('status_font',LOGFONTW),('message_font',LOGFONTW),('padded_border',ctypes.c_int)]
        self.NonClientMetrics=NonClientMetrics
        self.g.CreateFontIndirectW.argtypes=[ctypes.POINTER(LOGFONTW)];self.g.CreateFontIndirectW.restype=P
        self.g.GetPixel.argtypes=[P,ctypes.c_int,ctypes.c_int];self.g.GetPixel.restype=w.DWORD
        self.u.GetDC.argtypes=[w.HWND];self.u.GetDC.restype=P
        self.u.ReleaseDC.argtypes=[w.HWND,P];self.u.ReleaseDC.restype=ctypes.c_int
        self.u.GetForegroundWindow.argtypes=[];self.u.GetForegroundWindow.restype=w.HWND
        self.metrics_function=getattr(self.u,'SystemParametersInfoForDpi',None)
        if self.metrics_function:self.metrics_function.argtypes=[w.UINT,w.UINT,ctypes.POINTER(NonClientMetrics),w.UINT,w.UINT];self.metrics_function.restype=w.BOOL
        self.dpi_function=getattr(self.u,'GetDpiForWindow',None)
        if self.dpi_function:self.dpi_function.argtypes=[w.HWND];self.dpi_function.restype=w.UINT
        self.rendered=None
    def caption_font(self,dpi,clear_type=True):
        """Windows' own caption font for this DPI (Segoe UI 9 by default).
        DEFAULT_QUALITY keeps the user's ClearType setting, like the menus."""
        font=None;metrics_type=getattr(self,'NonClientMetrics',None);fn=getattr(self,'metrics_function',None)
        if metrics_type is not None and fn is not None:
            metrics=metrics_type();metrics.size=ctypes.sizeof(metrics)
            try:
                if fn(0x29,ctypes.sizeof(metrics),ctypes.byref(metrics),0,dpi) and metrics.caption_font.lfFaceName and metrics.caption_font.lfHeight:font=metrics.caption_font
            except (OSError,TypeError,ctypes.ArgumentError):font=None
        if font is None:
            font=LOGFONTW();font.lfHeight=-round(9*dpi/72);font.lfWeight=400;font.lfCharSet=1;font.lfFaceName='Segoe UI'
        font.lfQuality=0 if clear_type else 4
        return font
    def create_font(self,dpi,clear_type=True):
        face=self.g.CreateFontIndirectW(ctypes.byref(self.caption_font(dpi,clear_type)))
        if not face:raise ctypes.WinError(ctypes.get_last_error())
        return face
    def is_active(self,root):
        return self.u.GetForegroundWindow()==self.handle(root)
    def sample_background(self,geometry):
        """Colour of the native bar on both sides of the title; None if they
        disagree (another window over the bar) or the screen cannot be read."""
        x,y,width,height=geometry;row=y+height//2
        dc=self.u.GetDC(None)
        if not dc:return None
        try:samples=(self.g.GetPixel(dc,x-4,row),self.g.GetPixel(dc,x+width+3,row))
        finally:self.u.ReleaseDC(None,dc)
        if 0xffffffff in samples:return None
        channels=[[(v>>k)&255 for v in samples] for k in (0,8,16)]
        # 0.17.0: Windows 11 bars differ by a shade from side to side (a sample at 240 and one at
        # 241 is the same bar); refusing them left the title in the bold fallback after a save.
        if any(abs(a-b)>8 for a,b in channels):return None
        return '#%02x%02x%02x'%tuple((a+b+1)//2 for a,b in channels)
    def dpi(self,root):
        return (self.dpi_function(self.handle(root)) if self.dpi_function else 96) or 96
    def measure_text(self,root,text):
        dpi=self.dpi(root);key=(text,dpi)
        if getattr(self,'measured',None) and self.measured[0]==key:return self.measured[1]
        dc=self.g.CreateCompatibleDC(None)
        if not dc:raise ctypes.WinError(ctypes.get_last_error())
        face=old=None
        try:
            face=self.create_font(dpi)
            old=self.g.SelectObject(dc,face);rect=self.w.RECT()
            if not self.u.DrawTextW(dc,text or ' ', -1,ctypes.byref(rect),0x400|0x20|0x800):raise ctypes.WinError(ctypes.get_last_error())
            result=(rect.right-rect.left,rect.bottom-rect.top)
            self.measured=(key,result);return result
        finally:
            if old:self.g.SelectObject(dc,old)
            if face:self.g.DeleteObject(face)
            self.g.DeleteDC(dc)
    def draw_text(self,popup,geometry,text,color,dpi,background=None):
        """A fresh surface per changed caption. With the bar colour known
        (0.16.15) the text is drawn opaque, like the native title and menus, with
        the system ClearType setting; otherwise grayscale coverage alpha."""
        x,y,width,height=geometry;key=(width,height,text,color,dpi,background)
        if self.rendered==key:return
        g=self.g;w=self.w;dc=g.CreateCompatibleDC(None)
        if not dc:raise ctypes.WinError(ctypes.get_last_error())
        bitmap=face=old_bitmap=old_face=None
        try:
            info=self.BitmapInfo();info.header.size=ctypes.sizeof(info.header)
            info.header.width=width;info.header.height=-height;info.header.planes=1;info.header.bits=32
            bits=self.P();bitmap=g.CreateDIBSection(dc,ctypes.byref(info),0,ctypes.byref(bits),None,0)
            if not bitmap or not bits.value:raise ctypes.WinError(ctypes.get_last_error())
            old_bitmap=g.SelectObject(dc,bitmap)
            ink=not background and dark(color)
            if background:ctypes.memmove(bits,bytes((int(background[5:7],16),int(background[3:5],16),int(background[1:3],16),255))*(width*height),width*height*4)
            else:ctypes.memset(bits,255 if ink else 0,width*height*4)
            # ClearType RGB fringes are only correct on an opaque known background;
            # without it, grayscale antialiasing on a transparent surface.
            face=self.create_font(dpi,clear_type=bool(background))
            old_face=g.SelectObject(dc,face);g.SetBkMode(dc,1);g.SetTextColor(dc,colorref(color) if background else 0 if ink else 0xffffff)
            rect=w.RECT(0,0,width,height)
            if text and not self.u.DrawTextW(dc,text,-1,ctypes.byref(rect),0x1|0x4|0x20|0x8000|0x800):raise ctypes.WinError(ctypes.get_last_error())
            g.GdiFlush()
            raw=bytearray(ctypes.string_at(bits,width*height*4))
            data=opaque_caption(raw) if background else premultiply_caption(raw,color,ink)
            ctypes.memmove(bits,bytes(data),len(data))
            dest=w.POINT(x,y);size=w.SIZE(width,height);source=w.POINT(0,0);blend=self.Blend(0,0,255,1)
            if not self.u.UpdateLayeredWindow(self.handle(popup),None,ctypes.byref(dest),ctypes.byref(size),dc,ctypes.byref(source),0,ctypes.byref(blend),2):raise ctypes.WinError(ctypes.get_last_error())
            self.rendered=key
        finally:
            if old_face:g.SelectObject(dc,old_face)
            if old_bitmap:g.SelectObject(dc,old_bitmap)
            if face:g.DeleteObject(face)
            if bitmap:g.DeleteObject(bitmap)
            g.DeleteDC(dc)
    def create_popup(self,root):
        w=self.w;u=self.u
        u.CreateWindowExW.argtypes=[w.DWORD,w.LPCWSTR,w.LPCWSTR,w.DWORD,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,w.HWND,self.P,self.P,self.P]
        u.CreateWindowExW.restype=w.HWND
        u.ShowWindow.argtypes=[w.HWND,ctypes.c_int];u.ShowWindow.restype=w.BOOL
        u.DestroyWindow.argtypes=[w.HWND];u.DestroyWindow.restype=w.BOOL
        hwnd=u.CreateWindowExW(0x08000000|0x80000|0x80|0x20,'STATIC','',0x80000000,0,0,1,1,self.handle(root),None,None,None)
        if not hwnd:raise ctypes.WinError(ctypes.get_last_error())
        class Surface:
            def winfo_id(self):return hwnd
            def winfo_ismapped(self):return bool(u.IsWindowVisible(hwnd))
            def withdraw(self):u.ShowWindow(hwnd,0)
            def deiconify(self):u.ShowWindow(hwnd,4)
            def destroy(self):u.DestroyWindow(hwnd)
        return Surface()
    def handle(self,widget):return self.u.GetAncestor(widget.winfo_id(),2) or widget.winfo_id()
    def text_color(self):
        color=self.u.GetSysColor(9)
        return '#'+''.join(f'{(color>>shift)&255:02x}' for shift in (0,8,16))
    def make_passive(self,popup):
        hwnd=self.handle(popup);style=self.get(hwnd,-20)
        ctypes.set_last_error(0);self.put(hwnd,-20,(style|0x08000000|0x80000|0x80|0x20)&~0x40000)
        if ctypes.get_last_error():raise ctypes.WinError(ctypes.get_last_error())
        for handle in set((hwnd,popup.winfo_id())):
            previous=self.get(handle,-4)
            def dispatch(window,message,wp,lp,old=previous):
                if message==0x84:return -1 # HTTRANSPARENT: forward to same-thread native titlebar.
                if message==0x21:return 3  # MA_NOACTIVATE.
                return self.u.CallWindowProcW(self.P(old),window,message,wp,lp)
            callback=self.proc_type(dispatch);ctypes.set_last_error(0)
            self.put(handle,-4,ctypes.cast(callback,self.P).value)
            if ctypes.get_last_error():raise ctypes.WinError(ctypes.get_last_error())
            self.hooks.append((handle,previous,callback))
    def rectangles(self,root):
        hwnd=self.handle(root)
        if self.u.IsIconic(hwnd) or not self.u.IsWindowVisible(hwnd):return None
        window=self.w.RECT();title=self.TitleInfo();title.size=ctypes.sizeof(title)
        if not self.u.GetWindowRect(hwnd,ctypes.byref(window)) or not self.u.GetTitleBarInfo(hwnd,ctypes.byref(title)):return None
        def values(r):return (r.left,r.top,r.right,r.bottom)
        return values(window),values(title.rect)
    def place(self,popup,geometry):
        x,y,width,height=geometry
        if not self.u.SetWindowPos(self.handle(popup),None,x,y,width,height,0x4|0x10|0x40):raise ctypes.WinError(ctypes.get_last_error())
    def restore(self):
        for handle,old,callback in reversed(self.hooks):
            if self.u.IsWindow(handle):self.put(handle,-4,old)
        self.hooks.clear()


class Caption:
    def __init__(self,root,api):
        self.root=root;self.api=api;self.text='';self.closed=False;self.timer=None;self.pending=None;self.placed=None
        self.palette={};self.active=None;self.active_since=0.0;self.native=False;self.started=time.monotonic()
        self.alpha_renderer=callable(getattr(api,'draw_text',None))
        native=callable(getattr(api,'create_popup',None))
        if native:self.popup=api.create_popup(root)
        else:
            self.popup=tk.Toplevel(root,takefocus=False);self.popup.withdraw();self.popup.overrideredirect(True);self.popup.transient(root)
            self.popup.configure(bg='#f0f0f0')
        key='#f0f0f0'
        self.label=tk.Label(root if native else self.popup,bg=key,fg=api.text_color(),font=('Segoe UI',9),anchor='center',bd=0,padx=0,pady=0,takefocus=False)
        if not self.alpha_renderer:self.label.pack(fill='both',expand=True)
        from tkinter import font
        self.font=font.Font(self.label,font=self.label.cget('font'))
        if not native:self.popup.update_idletasks()
        api.make_passive(self.popup)
        # 0.19.3: the window's own events only (a binding on the window ran for each widget inside it).
        from ui_widgets import bind_own
        bind_own(root,'<Configure>',self.schedule);bind_own(root,'<Map>',self.schedule);bind_own(root,'<Unmap>',self.hide);bind_own(root,'<Destroy>',self.destroyed)
        self.poll()
    def set(self,text):
        self.text=text;self.label.configure(text=text)
        if self.native:self.root.title(text);return
        self.schedule()
    def schedule(self,event=None):
        if self.closed or (event is not None and event.widget is not self.root) or self.pending:return
        self.pending=self.root.after_idle(self.sync)
    def hide(self,event=None):
        if not self.closed and (event is None or event.widget is self.root):
            self.popup.withdraw();self.placed=None
            if self.alpha_renderer:self.api.rendered=None
    def sync(self):
        self.pending=None
        if self.closed or self.native:return
        try:
            rects=self.api.rectangles(self.root)
            if not rects:self.hide();return
            metrics=self.api.measure_text(self.root,self.text) if self.alpha_renderer else (self.font.measure(self.text),self.font.metrics('linespace'))
            geometry=caption_geometry(*rects,*metrics)
            if not geometry:self.hide();return
            color=self.api.text_color()
            background=self.bar_colour(geometry) if self.alpha_renderer else None
            if self.alpha_renderer and not background and callable(getattr(self.api,'sample_background',None)) and time.monotonic()-self.started<1.5:
                # 0.16.24: at opening, wait for the bar colour (sampled after Windows' fade) instead of
                # showing a grey, blurry first title; the title appears once, crisp.
                if self.popup.winfo_ismapped():self.hide()
                if self.root.title():self.root.title('')
                return
            if self.placed!=geometry or not self.popup.winfo_ismapped():
                x,y,width,height=geometry
                if not self.alpha_renderer:self.popup.geometry(f'{width}x{height}{x:+d}{y:+d}')
                self.popup.deiconify();self.api.place(self.popup,geometry);self.placed=geometry
            if self.alpha_renderer:
                if background:self.api.draw_text(self.popup,geometry,self.text,caption_text_colors(background,self.active),self.api.dpi(self.root),background)
                else:self.api.draw_text(self.popup,geometry,self.text,color,self.api.dpi(self.root))
            else:self.label.configure(fg=color)
            # Keep the icon, with only one centered layer of caption text.
            if self.root.title():self.root.title('')
        except Exception:
            # Any native failure: keep the complete native title from now on.
            self.native=True;self.hide();self.root.title(self.text)
    def bar_colour(self,geometry):
        """Sampled once per window state, after Windows' activation fade."""
        if not callable(getattr(self.api,'sample_background',None)):return None
        active=bool(self.api.is_active(self.root));now=time.monotonic()
        if active!=self.active:
            # 0.17.0: the colour known for this state stays in use until a new sample succeeds
            # (a save dialog used to drop it and leave the title bold).
            self.active=active;self.active_since=now;self.resample=True
        if (active not in self.palette or self.__dict__.get('resample')) and now-self.active_since>=.3:
            sampled=self.api.sample_background(geometry)
            if sampled:self.palette[active]=sampled;self.resample=False
            elif active in self.palette:self.resample=False
        return self.palette.get(active)
    def poll(self):
        if self.closed:return
        self.sync();self.timer=self.root.after(200,self.poll)
    def destroyed(self,event):
        if event.widget is self.root:self.close()
    def close(self):
        if self.closed:return
        self.closed=True
        for token in (self.pending,self.timer):
            if token:
                try:self.root.after_cancel(token)
                except tk.TclError:pass
        self.api.restore()
        popup=self.__dict__.get('popup')
        if popup:
            try:popup.destroy()
            except tk.TclError:pass


def install(root):
    if os.name!='nt':return None
    api=None;controller=None
    try:
        api=WindowsCaptionAPI();controller=Caption.__new__(Caption);controller.__init__(root,api)
        root._caption_controller=controller;root.update_window_title();return controller
    except (OSError,AttributeError,tk.TclError):
        if controller:controller.close()
        elif api:api.restore()
        # A failed enhancement must keep the complete native title available.
        root.title(root.window_caption.cget('text'));return None
