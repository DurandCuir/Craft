"""0.18.0 Image de fond: pictures read, resampled and written without any installed package.

Windows: GDI+ (JPEG, PNG, BMP, GIF, TIFF; the orientation of a phone photo is applied) and, for
the formats GDI+ does not read (WEBP, HEIC…), the Windows Imaging Component when Windows has the
codec. Elsewhere (development): Pillow. A PDF page is drawn here from what ``pdf_reader`` finds on
it (lines, curves, pictures), at its real size.

A ``Picture`` is held by one backend; ``view()`` gives the part of it seen on the plan, at the
screen's size, faded toward the plan colour (``opacity``: 1 = the picture as it is)."""
import base64
import ctypes
import io
import math
import os
import sys
import tempfile
from functools import lru_cache

MAX_SIDE=2400          # pixels of the light copy kept in the document
PDF_RESOLUTION=8.      # pixels per millimetre when a PDF page is drawn
PDF_MAX_SIDE=4000
RASTER_EXTENSIONS=('.jpg','.jpeg','.jpe','.jfif','.png','.bmp','.dib','.gif','.tif','.tiff','.webp','.heic','.heif','.avif','.ico')


class PictureError(ValueError):
    pass


def ppm(width,height,rgb):return b'P6 %d %d 255\n'%(width,height)+bytes(rgb)


def blend_matrix(opacity,background):
    """GDI+ colour matrix (row vectors) fading toward ``background`` (r,g,b 0-255)."""
    a=max(0.,min(1.,float(opacity)));r,g,b=[(1-a)*v/255 for v in background]
    return [a,0,0,0,0, 0,a,0,0,0, 0,0,a,0,0, 0,0,0,1,0, r,g,b,0,1]


# --- Pillow (development, or a Windows with Pillow) -------------------------------------------

class PillowBackend:
    name='Pillow'

    def __init__(self):
        from PIL import Image
        self.Image=Image

    def open(self,path):
        from PIL import ImageOps
        try:
            im=self.Image.open(path)
            dpi=im.info.get('dpi',(0,0))[0] if isinstance(im.info.get('dpi'),tuple) else 0
            im=ImageOps.exif_transpose(im);im.load()
        except (OSError,ValueError,SyntaxError) as exc:raise PictureError('Image illisible : '+str(exc)) from None
        return self._rgb(im),float(dpi or 0)

    def _rgb(self,im):
        if im.mode in ('RGBA','LA','P'):
            im=im.convert('RGBA');back=self.Image.new('RGB',im.size,(255,255,255));back.paste(im,mask=im.split()[-1]);return back
        return im.convert('RGB')

    def from_pixels(self,width,height,data,mode='rgb'):
        return self.Image.frombytes('L' if mode=='gray' else 'RGB',(width,height),bytes(data)).convert('RGB')

    def from_encoded(self,data):
        try:
            im=self.Image.open(io.BytesIO(data));im.load();return self._rgb(im)
        except (OSError,ValueError,SyntaxError) as exc:raise PictureError('Image illisible : '+str(exc)) from None

    def size(self,h):return h.size

    def scaled(self,h,max_side):
        w,hh=h.size;f=min(1.,max_side/max(w,hh))
        return h if f>=1 else h.resize((max(1,round(w*f)),max(1,round(hh*f))),self.Image.Resampling.LANCZOS)

    def encode(self,h,fmt):
        buf=io.BytesIO()
        if fmt=='jpeg':h.save(buf,'JPEG',quality=85,optimize=True)
        else:h.save(buf,'PNG',optimize=True)
        return buf.getvalue()

    def page(self,width,height):
        return self.Image.new('RGB',(width,height),(255,255,255))

    def draw_lines(self,h,lines,width):
        from PIL import ImageDraw
        d=ImageDraw.Draw(h)
        for pts in lines:
            if len(pts)>1:d.line([tuple(p) for p in pts],fill=(0,0,0),width=max(1,round(width)))

    def draw_picture(self,h,picture,corners):
        """``corners``: where the picture's top-left, top-right and bottom-left pixels go."""
        (x0,y0),(x1,y1),(x2,y2)=corners;w,hh=picture.size
        # Inverse affine map: page pixel → picture pixel.
        ax,ay=(x1-x0)/w,(y1-y0)/w;bx,by=(x2-x0)/hh,(y2-y0)/hh;det=ax*by-ay*bx
        if abs(det)<1e-12:return
        ia,ib,ic,idd=by/det,-bx/det,-ay/det,ax/det
        coeffs=(ia,ib,-(ia*x0+ib*y0),ic,idd,-(ic*x0+idd*y0))
        layer=picture.transform(h.size,self.Image.Transform.AFFINE,coeffs,resample=self.Image.Resampling.BILINEAR,fillcolor=None)
        mask=self.Image.new('L',picture.size,255).transform(h.size,self.Image.Transform.AFFINE,coeffs,resample=self.Image.Resampling.BILINEAR,fillcolor=0)
        h.paste(layer,(0,0),mask)

    def view(self,h,src,dst,opacity,background):
        sx,sy,sw,sh=src;dw,dh=dst
        part=h.resize((dw,dh),self.Image.Resampling.BILINEAR,box=(sx,sy,sx+sw,sy+sh))
        if opacity<1:part=self.Image.blend(self.Image.new('RGB',(dw,dh),tuple(background)),part,max(0.,opacity))
        return ppm(dw,dh,part.tobytes())

    def faded(self,h,opacity,background):
        return self.Image.blend(self.Image.new('RGB',h.size,tuple(background)),h,max(0.,min(1.,opacity)))

    def dispose(self,h):pass


# --- Windows: GDI+ and WIC ----------------------------------------------------------------------

class GUID(ctypes.Structure):
    _fields_=[('Data1',ctypes.c_uint32),('Data2',ctypes.c_uint16),('Data3',ctypes.c_uint16),('Data4',ctypes.c_ubyte*8)]

    @classmethod
    def parse(cls,text):
        import uuid
        u=uuid.UUID(text);b=u.bytes_le;g=cls()
        ctypes.memmove(ctypes.byref(g),b,16);return g


JPEG_ENCODER='557CF401-1A04-11D3-9A73-0000F81EF32E'
PNG_ENCODER='557CF406-1A04-11D3-9A73-0000F81EF32E'
JPEG_QUALITY='1d5be4b5-fa4a-452d-9cdd-5db35105e7eb'   # EncoderQuality
FORMAT_24RGB=0x21808     # PixelFormat24bppRGB (bytes B, G, R)
FORMAT_32ARGB=0x26200A   # PixelFormat32bppARGB (bytes B, G, R, A)
# EXIF orientation (1 to 8) → GDI+ RotateFlipType that puts the picture upright.
TURNS={2:4,3:2,4:6,5:5,6:1,7:7,8:3}


class EncoderParameter(ctypes.Structure):
    _fields_=[('Guid',GUID),('NumberOfValues',ctypes.c_uint32),('Type',ctypes.c_uint32),('Value',ctypes.c_void_p)]


class EncoderParameters(ctypes.Structure):
    _fields_=[('Count',ctypes.c_uint32),('Parameter',EncoderParameter*1)]


class GdiPicture:
    __slots__=('image','width','height')
    gdi=None   # gdiplus (set by GdiBackend): a picture dropped without dispose() is freed all the same

    def __init__(self,image,width,height):self.image=image;self.width=width;self.height=height

    def __del__(self):
        image=getattr(self,'image',None);self.image=None
        if image and GdiPicture.gdi is not None:
            try:GdiPicture.gdi.GdipDisposeImage(image)
            except Exception:pass


class GdiBackend:
    name='GDI+'

    def __init__(self):
        from ctypes import wintypes as w
        self.g=ctypes.WinDLL('gdiplus');P=ctypes.c_void_p;F=ctypes.c_float;I=ctypes.c_int;U=ctypes.c_uint32
        class Startup(ctypes.Structure):_fields_=[('version',w.UINT),('callback',P),('suppress_thread',w.BOOL),('suppress_codecs',w.BOOL)]
        class Rect(ctypes.Structure):_fields_=[('X',I),('Y',I),('Width',I),('Height',I)]
        class PointF(ctypes.Structure):_fields_=[('X',F),('Y',F)]
        class BitmapData(ctypes.Structure):_fields_=[('Width',w.UINT),('Height',w.UINT),('Stride',I),('PixelFormat',I),('Scan0',P),('Reserved',ctypes.c_size_t)]
        class PropertyItem(ctypes.Structure):_fields_=[('id',ctypes.c_uint32),('length',ctypes.c_uint32),('type',ctypes.c_uint16),('value',P)]
        self.Rect=Rect;self.PointF=PointF;self.BitmapData=BitmapData;self.PropertyItem=PropertyItem;self.P=P
        specs={'GdiplusStartup':[ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(Startup),P],
               'GdipCreateBitmapFromFile':[w.LPCWSTR,ctypes.POINTER(P)],'GdipCreateBitmapFromScan0':[I,I,I,I,P,ctypes.POINTER(P)],
               'GdipGetImageWidth':[P,ctypes.POINTER(w.UINT)],'GdipGetImageHeight':[P,ctypes.POINTER(w.UINT)],
               'GdipGetImageHorizontalResolution':[P,ctypes.POINTER(F)],'GdipGetImageGraphicsContext':[P,ctypes.POINTER(P)],
               'GdipSetInterpolationMode':[P,I],'GdipSetPixelOffsetMode':[P,I],'GdipSetSmoothingMode':[P,I],'GdipGraphicsClear':[P,U],
               'GdipDrawImageRectRect':[P,P,F,F,F,F,F,F,F,F,I,P,P,P],'GdipDrawImagePointsRect':[P,P,ctypes.POINTER(PointF),I,F,F,F,F,I,P,P,P],
               'GdipCreateImageAttributes':[ctypes.POINTER(P)],'GdipDisposeImageAttributes':[P],
               'GdipSetImageAttributesColorMatrix':[P,I,w.BOOL,ctypes.POINTER(F),P,I],'GdipSetImageAttributesWrapMode':[P,I,U,w.BOOL],
               'GdipBitmapLockBits':[P,ctypes.POINTER(Rect),U,I,ctypes.POINTER(BitmapData)],'GdipBitmapUnlockBits':[P,ctypes.POINTER(BitmapData)],
               'GdipDeleteGraphics':[P],'GdipDisposeImage':[P],'GdipSaveImageToFile':[P,w.LPCWSTR,ctypes.POINTER(GUID),P],
               'GdipGetPropertyItemSize':[P,ctypes.c_uint32,ctypes.POINTER(w.UINT)],'GdipGetPropertyItem':[P,ctypes.c_uint32,w.UINT,P],
               'GdipImageRotateFlip':[P,I],'GdipCreatePen1':[U,F,I,ctypes.POINTER(P)],'GdipDeletePen':[P],
               'GdipDrawLines':[P,P,ctypes.POINTER(PointF),I],'GdipSetPenLineJoin':[P,I]}
        for name,args in specs.items():
            fn=getattr(self.g,name);fn.argtypes=args;fn.restype=I
        self.token=ctypes.c_size_t()
        self.call('GdiplusStartup',ctypes.byref(self.token),ctypes.byref(Startup(1,None,False,False)),None)
        GdiPicture.gdi=self.g

    def call(self,name,*args):
        status=getattr(self.g,name)(*args)
        if status:raise PictureError(f'GDI+ {name} : {status}')

    def _new(self,width,height):
        image=self.P();self.call('GdipCreateBitmapFromScan0',int(width),int(height),0,FORMAT_24RGB,None,ctypes.byref(image));return image

    def _graphics(self,image,mode=7):
        """``mode``: 7 HighQualityBicubic, 6 HighQualityBilinear (smooth when shrinking), 3 Bilinear."""
        g=self.P();self.call('GdipGetImageGraphicsContext',image,ctypes.byref(g))
        try:
            self.call('GdipSetInterpolationMode',g,mode)
            self.call('GdipSetPixelOffsetMode',g,4);self.call('GdipSetSmoothingMode',g,4)
        except Exception:
            self.g.GdipDeleteGraphics(g);raise
        return g

    def _wrap(self):
        """Attributes that repeat the edge pixels (TileFlipXY): without them GDI+ fades the edge
        of a drawn picture into transparent black, a faint grey border."""
        a=self.P();self.call('GdipCreateImageAttributes',ctypes.byref(a))
        try:self.call('GdipSetImageAttributesWrapMode',a,3,0,False)
        except Exception:
            self.g.GdipDisposeImageAttributes(a);raise
        return a

    def _size(self,image):
        from ctypes import wintypes as w
        a,b=w.UINT(),w.UINT();self.call('GdipGetImageWidth',image,ctypes.byref(a));self.call('GdipGetImageHeight',image,ctypes.byref(b))
        return int(a.value),int(b.value)

    def _copy(self,source,width,height,target=None,mode=7,attributes=None,src=None):
        """``source`` drawn on white into a new 24-bit bitmap of width × height (it never refers
        to a file; transparent parts become white)."""
        target=target or (width,height);own=None
        if attributes is None:attributes=own=self._wrap()
        try:
            image=self._new(*target)
            try:
                g=self._graphics(image,mode)
                try:
                    self.call('GdipGraphicsClear',g,0xFFFFFFFF)
                    sx,sy,sw,sh=src or (0,0,width,height)
                    self.call('GdipDrawImageRectRect',g,source,0.,0.,float(target[0]),float(target[1]),float(sx),float(sy),float(sw),float(sh),2,attributes,None,None)
                finally:self.g.GdipDeleteGraphics(g)
            except Exception:
                self.g.GdipDisposeImage(image);raise
            return image
        finally:
            if own:self.g.GdipDisposeImageAttributes(own)

    def _upright(self,image,orientation):
        """A bitmap of our own turned upright (EXIF orientation), as a picture."""
        try:
            turn=TURNS.get(orientation)
            if turn:self.call('GdipImageRotateFlip',image,turn)
            width,height=self._size(image)
        except Exception:
            self.g.GdipDisposeImage(image);raise
        return GdiPicture(image,width,height)

    def _orientation(self,image):
        """EXIF orientation of a photo (1 when unknown)."""
        from ctypes import wintypes as w
        size=w.UINT()
        if self.g.GdipGetPropertyItemSize(image,0x0112,ctypes.byref(size)) or size.value<ctypes.sizeof(self.PropertyItem):return 1
        buf=ctypes.create_string_buffer(size.value)
        if self.g.GdipGetPropertyItem(image,0x0112,size.value,buf):return 1
        item=self.PropertyItem.from_buffer(buf)
        return ctypes.c_uint16.from_address(item.value).value if item.value and item.length>=2 else 1

    def open(self,path):
        image=self.P();status=self.g.GdipCreateBitmapFromFile(str(path),ctypes.byref(image))
        if status:
            # WEBP, HEIC… when Windows has their codec: 32-bit pixels, drawn on white like the others.
            width,height,pixels,dpi,orientation=wic_decode(path)
            source=self.P()
            self.call('GdipCreateBitmapFromScan0',width,height,width*4,FORMAT_32ARGB,pixels,ctypes.byref(source))
            try:copy=self._copy(source,width,height)
            finally:self.g.GdipDisposeImage(source)   # before ``pixels`` goes: the bitmap reads them
            return self._upright(copy,orientation),dpi
        try:
            dpi=ctypes.c_float();self.g.GdipGetImageHorizontalResolution(image,ctypes.byref(dpi))
            orientation=self._orientation(image)
            width,height=self._size(image)
            copy=self._copy(image,width,height)
        finally:self.g.GdipDisposeImage(image)
        return self._upright(copy,orientation),float(dpi.value or 0)

    def from_pixels(self,width,height,data,mode='rgb'):
        """Grey, RGB or BGR bytes (rows without padding) into a bitmap."""
        image=self._new(width,height);bd=self.BitmapData();rect=self.Rect(0,0,width,height)
        try:
            self.call('GdipBitmapLockBits',image,ctypes.byref(rect),2,FORMAT_24RGB,ctypes.byref(bd))   # write
            try:
                stride=bd.Stride;row=width*3
                if mode=='gray':
                    for y in range(height):
                        line=bytes(data[y*width:(y+1)*width]).ljust(width,b'\xff');triple=bytearray(row)
                        triple[0::3]=line;triple[1::3]=line;triple[2::3]=line
                        ctypes.memmove(bd.Scan0+y*stride,bytes(triple),row)
                else:
                    for y in range(height):
                        line=bytearray(bytes(data[y*row:(y+1)*row]).ljust(row,b'\xff'))
                        if mode=='rgb':line[0::3],line[2::3]=line[2::3],line[0::3]
                        ctypes.memmove(bd.Scan0+y*stride,bytes(line),row)
            finally:self.g.GdipBitmapUnlockBits(image,ctypes.byref(bd))
        except Exception:
            self.g.GdipDisposeImage(image);raise
        return GdiPicture(image,width,height)

    def from_encoded(self,data):
        handle,name=tempfile.mkstemp(prefix='craft-image-')
        try:
            with os.fdopen(handle,'wb') as f:f.write(data)
            return self.open(name)[0]
        finally:
            try:os.unlink(name)
            except OSError:pass

    def size(self,h):return h.width,h.height

    def scaled(self,h,max_side):
        f=min(1.,max_side/max(h.width,h.height))
        if f>=1:return h
        w,hh=max(1,round(h.width*f)),max(1,round(h.height*f))
        return GdiPicture(self._copy(h.image,h.width,h.height,target=(w,hh)),w,hh)

    def encode(self,h,fmt):
        handle,name=tempfile.mkstemp(prefix='craft-image-',suffix='.jpg' if fmt=='jpeg' else '.png');os.close(handle)
        try:
            encoder=GUID.parse(JPEG_ENCODER if fmt=='jpeg' else PNG_ENCODER);done=False
            if fmt=='jpeg':
                # Quality 85, as with Pillow (GDI+ alone writes 75); its default if this is refused.
                quality=ctypes.c_uint32(85)
                params=EncoderParameters(1,(EncoderParameter*1)(EncoderParameter(GUID.parse(JPEG_QUALITY),1,4,ctypes.addressof(quality))))
                done=not self.g.GdipSaveImageToFile(h.image,name,ctypes.byref(encoder),ctypes.byref(params))
            if not done:self.call('GdipSaveImageToFile',h.image,name,ctypes.byref(encoder),None)
            with open(name,'rb') as f:return f.read()
        finally:
            try:os.unlink(name)
            except OSError:pass

    def page(self,width,height):
        image=self._new(width,height);g=self._graphics(image)
        try:self.call('GdipGraphicsClear',g,0xFFFFFFFF)
        finally:self.g.GdipDeleteGraphics(g)
        return GdiPicture(image,width,height)

    def draw_lines(self,h,lines,width):
        g=self._graphics(h.image);pen=self.P()
        try:
            self.call('GdipCreatePen1',0xFF000000,float(max(1.,width)),2,ctypes.byref(pen));self.call('GdipSetPenLineJoin',pen,2)
            for pts in lines:
                if len(pts)<2:continue
                array=(self.PointF*len(pts))(*[self.PointF(float(x),float(y)) for x,y in pts])
                self.call('GdipDrawLines',g,pen,array,len(pts))
        finally:
            if pen:self.g.GdipDeletePen(pen)
            self.g.GdipDeleteGraphics(g)

    def draw_picture(self,h,picture,corners):
        g=self._graphics(h.image);wrap=None
        try:
            wrap=self._wrap()
            points=(self.PointF*3)(*[self.PointF(float(x),float(y)) for x,y in corners])
            self.call('GdipDrawImagePointsRect',g,picture.image,points,3,0.,0.,float(picture.width),float(picture.height),2,wrap,None,None)
        finally:
            if wrap:self.g.GdipDisposeImageAttributes(wrap)
            self.g.GdipDeleteGraphics(g)

    def faded(self,h,opacity,background):
        """0.19.7: the whole picture faded once (its colour matrix), for the views made after."""
        attributes=self.P();self.call('GdipCreateImageAttributes',ctypes.byref(attributes))
        try:
            matrix=(ctypes.c_float*25)(*blend_matrix(opacity,background))
            self.call('GdipSetImageAttributesColorMatrix',attributes,0,True,matrix,None,0)
            self.call('GdipSetImageAttributesWrapMode',attributes,3,0,False)
            return GdiPicture(self._copy(h.image,h.width,h.height,mode=5,attributes=attributes),h.width,h.height)
        finally:self.g.GdipDisposeImageAttributes(attributes)

    def view(self,h,src,dst,opacity,background):
        attributes=self.P();self.call('GdipCreateImageAttributes',ctypes.byref(attributes))
        try:
            if opacity<1:   # 0.19.7: a picture faded beforehand (faded) needs no colour work here
                matrix=(ctypes.c_float*25)(*blend_matrix(opacity,background))
                self.call('GdipSetImageAttributesColorMatrix',attributes,0,True,matrix,None,0)
            self.call('GdipSetImageAttributesWrapMode',attributes,3,0,False)   # TileFlipXY: no grey border
            # Smooth when the plan is zoomed out (the picture shrunk to less than 2/3), quick otherwise.
            mode=6 if src[2]>1.5*dst[0] or src[3]>1.5*dst[1] else 3
            image=self._copy(h.image,h.width,h.height,target=dst,mode=mode,attributes=attributes,src=src)
        finally:self.g.GdipDisposeImageAttributes(attributes)
        try:
            return ppm(dst[0],dst[1],self._rgb(image,*dst))
        finally:self.g.GdipDisposeImage(image)

    def _rgb(self,image,width,height):
        bd=self.BitmapData();rect=self.Rect(0,0,width,height)
        self.call('GdipBitmapLockBits',image,ctypes.byref(rect),1,FORMAT_24RGB,ctypes.byref(bd))
        try:
            out=bytearray(width*height*3);row=width*3
            for y in range(height):out[y*row:(y+1)*row]=ctypes.string_at(bd.Scan0+y*bd.Stride,row)
            out[0::3],out[2::3]=out[2::3],out[0::3]   # BGR → RGB
            return bytes(out)
        finally:self.g.GdipBitmapUnlockBits(image,ctypes.byref(bd))

    def dispose(self,h):
        if isinstance(h,GdiPicture) and h.image:self.g.GdipDisposeImage(h.image);h.image=None


def wic_decode(path):
    """Windows Imaging Component: (width, height, BGRA pixels, dpi, EXIF orientation) of a picture
    whose codec Windows has (WEBP, HEIC…); the decoder does not turn a phone photo upright.
    COM through its function tables, with ctypes."""
    ole=ctypes.WinDLL('ole32');HRESULT=ctypes.c_long;P=ctypes.c_void_p
    ole.CoInitializeEx.argtypes=[P,ctypes.c_uint32];ole.CoInitializeEx.restype=HRESULT
    ole.CoCreateInstance.argtypes=[ctypes.POINTER(GUID),P,ctypes.c_uint32,ctypes.POINTER(GUID),ctypes.POINTER(P)];ole.CoCreateInstance.restype=HRESULT
    ole.PropVariantClear.argtypes=[P];ole.PropVariantClear.restype=HRESULT
    ole.CoInitializeEx(None,2)   # apartment threaded; « already initialised » is fine
    def method(obj,index,*types):
        table=ctypes.cast(ctypes.cast(obj,ctypes.POINTER(P))[0],ctypes.POINTER(P))
        return ctypes.WINFUNCTYPE(HRESULT,P,*types)(table[index])
    def check(hr,what):
        if hr<0:raise PictureError(f'Format non lu par Windows ({what} : {hr & 0xFFFFFFFF:#x}). Enregistrez l’image en JPG ou PNG.')
    def release(obj):
        if obj:method(obj,2)(obj)
    factory=P();decoder=P();frame=P();converter=P()
    try:
        check(ole.CoCreateInstance(ctypes.byref(GUID.parse('cacaf262-9370-4615-a13b-9f5539da4c0a')),None,1,ctypes.byref(GUID.parse('ec5ec8a9-c395-4314-9c77-54d7a935ff70')),ctypes.byref(factory)),'WIC')
        # IWICImagingFactory::CreateDecoderFromFilename(name, vendor, GENERIC_READ, WICDecodeMetadataCacheOnDemand, &decoder)
        check(method(factory,3,ctypes.c_wchar_p,P,ctypes.c_uint32,ctypes.c_int,ctypes.POINTER(P))(factory,str(path),None,0x80000000,0,ctypes.byref(decoder)),'décodeur')
        check(method(decoder,13,ctypes.c_uint32,ctypes.POINTER(P))(decoder,0,ctypes.byref(frame)),'image')   # GetFrame(0)
        orientation=1;reader=P()
        try:
            # IWICBitmapFrameDecode::GetMetadataQueryReader, IWICMetadataQueryReader::GetMetadataByName
            if method(frame,8,ctypes.POINTER(P))(frame,ctypes.byref(reader))>=0 and reader:
                value=(ctypes.c_uint64*3)()   # PROPVARIANT: its type at 0, a VT_UI2 (18) at 8
                if method(reader,5,ctypes.c_wchar_p,P)(reader,'System.Photo.Orientation',value)>=0:
                    raw=bytes(value)
                    if int.from_bytes(raw[:2],'little')==18:orientation=int.from_bytes(raw[8:10],'little')
                    ole.PropVariantClear(value)
        except OSError:orientation=1
        finally:release(reader)
        check(method(factory,10,ctypes.POINTER(P))(factory,ctypes.byref(converter)),'conversion')           # CreateFormatConverter
        # IWICFormatConverter::Initialize(source, GUID_WICPixelFormat32bppBGRA, dither none, palette none, 0, custom)
        check(method(converter,8,P,ctypes.POINTER(GUID),ctypes.c_int,P,ctypes.c_double,ctypes.c_int)(converter,frame,ctypes.byref(GUID.parse('6fddc324-4e03-4bfe-b185-3d77768dc90f')),0,None,0.,0),'conversion')
        w,h=ctypes.c_uint32(),ctypes.c_uint32()
        check(method(converter,3,ctypes.POINTER(ctypes.c_uint32),ctypes.POINTER(ctypes.c_uint32))(converter,ctypes.byref(w),ctypes.byref(h)),'taille')
        dx,dy=ctypes.c_double(),ctypes.c_double()
        if method(converter,5,ctypes.POINTER(ctypes.c_double),ctypes.POINTER(ctypes.c_double))(converter,ctypes.byref(dx),ctypes.byref(dy))<0:dx.value=0.
        width,height=int(w.value),int(h.value)
        if not 0<width*height<=120_000_000:raise PictureError('Image trop grande.')
        stride=width*4
        try:buf=ctypes.create_string_buffer(stride*height)
        except MemoryError:raise PictureError('Image trop grande.') from None
        check(method(converter,7,P,ctypes.c_uint32,ctypes.c_uint32,P)(converter,None,stride,stride*height,buf),'pixels')   # CopyPixels
        return width,height,buf,float(dx.value or 0),orientation
    finally:
        for obj in (converter,frame,decoder,factory):release(obj)


@lru_cache(maxsize=1)
def backend():
    """GDI+ on Windows, else Pillow; None when neither is there."""
    if sys.platform=='win32':
        try:return GdiBackend()
        except (OSError,AttributeError,PictureError):pass
    try:return PillowBackend()
    except ImportError:return None


def require():
    b=backend()
    if b is None:raise PictureError('Lecture des images impossible sur cet ordinateur.')
    return b


# --- What Craft keeps --------------------------------------------------------------------------

def read_picture(path,page=0):
    """(picture, width_mm or None, format) of a picture file or a PDF page: the real size when the
    file gives it (resolution of a scan, size of a PDF page), else None."""
    b=require();suffix=os.path.splitext(str(path))[1].lower()
    if suffix=='.pdf':
        with open(path,'rb') as f:data=f.read()
        return pdf_picture(data,page)
    picture,dpi=b.open(path)
    w,_=b.size(picture)
    # A resolution of 72 or 96 is the default of cameras and screens, not a measurement.
    width_mm=w/dpi*25.4 if dpi and dpi>=100 else None
    return picture,width_mm,'jpeg' if suffix not in ('.png','.gif','.bmp','.dib','.tif','.tiff') else 'png'


def pdf_picture(data,page=0):
    """A PDF page drawn as a picture: its lines and its pictures, at its real size."""
    import pdf_reader
    b=require();content=pdf_reader.read_page(data,page)
    W,H=content['width'],content['height']
    if W<=0 or H<=0:raise PictureError('Page PDF vide.')
    r=min(PDF_RESOLUTION,PDF_MAX_SIDE/max(W,H));pw,ph=max(1,round(W*r)),max(1,round(H*r))
    sheet=b.page(pw,ph);drawn=0;skipped=[]
    for item in content['images']:
        m=item['matrix']
        if abs(m[0]*m[3]-m[1]*m[2])*r*r<1e-6:continue   # drawn flat: nothing to see
        try:
            if item['kind']=='jpeg':pic=b.from_encoded(item['data'])
            elif item['kind'] in ('rgb','gray') and item['width']>0 and item['height']>0:pic=b.from_pixels(item['width'],item['height'],item['data'],mode=item['kind'])
            else:skipped.append(item.get('filter','?'));continue
        except PictureError:skipped.append('?');continue
        corner=lambda u,v:((m[0]*u+m[2]*v+m[4])*r,(m[1]*u+m[3]*v+m[5])*r)
        # The picture's first row is at the top of its unit square (v = 1).
        try:b.draw_picture(sheet,pic,[corner(0,1),corner(1,1),corner(0,0)]);drawn+=1
        except PictureError:skipped.append('?')
        finally:b.dispose(pic)
    if content['paths']:
        b.draw_lines(sheet,[[(x*r,y*r) for x,y in p] for p in content['paths']],max(1.,.25*r));drawn+=1
    if not drawn:
        b.dispose(sheet)
        raise PictureError('Rien à afficher sur cette page'+(' (images en '+', '.join(sorted(set(skipped)))+' : exportez la page en JPG).' if skipped else ' (texte seul).'))
    return sheet,W,'jpeg' if content['images'] and not content['paths'] else 'png'


def light_copy(picture,fmt,max_side=MAX_SIDE):
    """The copy kept in the document: at most MAX_SIDE pixels (0.19.14: or ``max_side``), JPEG (photo) or PNG (drawing)."""
    b=require();small=b.scaled(picture,max_side)
    data=b.encode(small,fmt);width,height=b.size(small)
    if small is not picture:b.dispose(small)
    return dict(format=fmt,data=base64.b64encode(data).decode('ascii'),pixels=[width,height])


def rgb_of(picture):
    """0.19.14: (width, height, RGB bytes from the top row) of a picture, read through ``view`` like the plan's
    picture (Pillow, or GDI+ under Windows)."""
    b=require();w,h=b.size(picture)
    data=b.view(picture,(0,0,w,h),(w,h),1.,(255,255,255));head=b'P6 %d %d 255\n'%(w,h)
    if not data.startswith(head) or len(data)!=len(head)+w*h*3:raise PictureError('Image illisible.')
    return w,h,data[len(head):]


def decoded_rgb(data):
    """0.19.14: (width, height, RGB bytes) of an encoded picture (JPEG, PNG…)."""
    b=require();picture=b.from_encoded(data)
    try:return rgb_of(picture)
    finally:b.dispose(picture)


_cache={}


def picture_key(background):return (len(background['data']),background['data'][:64],background['data'][-64:])


def held(background):
    """The decoded light copy of a background (kept while it is the same picture)."""
    key=picture_key(background)
    found=_cache.get('picture')
    if found and found[0]==key:return found[1]
    b=require();picture=b.from_encoded(base64.b64decode(background['data']))
    if found:
        try:b.dispose(found[1])
        except Exception:pass
    _cache['picture']=(key,picture);return picture


def faded(background,colour):
    """0.19.7 (« impression que image fait laguer »): the light copy faded toward the plan colour ONCE for
    its « Transparence »: each view (zoom, move, size) is then only a part of it resampled; the colour
    work was done again for every view, at the screen's size."""
    picture=held(background);opacity=round(max(.05,min(1.,float(background.get('opacity',1)))),3)
    if opacity>=1:return picture
    key=(picture_key(background),opacity,tuple(colour));found=_cache.get('faded')
    if found and found[0]==key:return found[1]
    b=require();out=b.faded(picture,opacity,colour)
    if found:
        try:b.dispose(found[1])
        except Exception:pass
    _cache['faded']=(key,out);return out


def self_test():
    """Lines for diagnostic.txt: what this computer can do with pictures."""
    out=[]
    try:
        b=require();out.append('Images : '+b.name)
        sample=b.from_pixels(4,2,bytes([255,0,0,0,255,0,0,0,255,255,255,255]*2),mode='rgb')
        view=b.view(sample,(0,0,4,2),(8,4),.5,(0,0,0));out.append('Affichage : '+('OK' if view.startswith(b'P6 8 4 255\n') and len(view)==len(b'P6 8 4 255\n')+96 else 'taille '+str(len(view))))
        for fmt in ('jpeg','png'):
            data=b.encode(sample,fmt);back=b.from_encoded(data);out.append(f'{fmt.upper()} : OK ({len(data)} octets, {b.size(back)})');b.dispose(back)
        sheet=b.page(40,30);b.draw_lines(sheet,[[(2,2),(38,28)]],2);b.draw_picture(sheet,sample,[(5,5),(25,5),(5,15)]);out.append('Page PDF : OK');b.dispose(sheet);b.dispose(sample)
    except Exception as exc:out.append('Erreur : '+type(exc).__name__+' : '+str(exc))
    if sys.platform=='win32':
        try:
            handle,name=tempfile.mkstemp(suffix='.png');os.close(handle)
            with open(name,'wb') as f:f.write(base64.b64decode(TINY_PNG))
            w,h,data,dpi,orientation=wic_decode(name);out.append(f'WIC : OK ({w}×{h})')
        except Exception as exc:out.append('WIC : '+type(exc).__name__+' : '+str(exc))
        finally:
            try:os.unlink(name)
            except Exception:pass
    return out


# A 2 × 2 PNG (red, green / blue, white) for the self-test.
TINY_PNG='iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFklEQVR4nGP4z8DA8J+BkYHh////DAAe9gT9Ce00PgAAAABJRU5ErkJggg=='
