"""0.18.7: a drawing of the plan keeps what did not change (a click, Supprimer, Annuler, a change of
one object…).

Every object of the plan is drawn as one group of canvas items, tagged « _obj » and « _obj:<n> »,
starting with a hidden anchor (its place in the stacking order). The next drawing keeps the groups
whose object and selection are the same (the key) and draws only the others; each new group is put
just under the anchor of the group that follows it, so the stacking order is that of a full drawing
(the list of objects). Anything else the drawing of an object depends on (the view, the size of the
plan, the colours, the preferences, the line profiles…) is the drawing's context, given by the
application (``draw_context``): another context, or no context (a sheet shown instead of the plan),
draws everything again, as does a canvas emptied or moved by someone else (the number of kept items
and a hidden sentinel are checked) or a change of most of what was drawn.

Dashes (dash_lines) share a budget per drawing, spent in the order of the objects: a kept group
counts what it spent, a new one draws with the count a full drawing would have reached, and a kept
group whose dashes would come out otherwise (the budget reached before it, or not any more) is drawn
again."""
import marshal

TAG = '_obj'
UNDER = '_obj_under'
ANCHOR = '_obj_anchor'
SENTINEL = '_obj_sentinel'
# Items of a group that the drawing then moves to the bottom or the top of the canvas
# (preparation_ui.lower_fills, finish_ui: spline grips): among them, the order of the objects too.
DISPLACED = ('prep_fill', 'spline_grips')
REUSE_AT_LEAST = .5   # fewer of the objects drawn last time kept than this: everything is drawn again (quicker)

def fast_create(canvas):
    """0.19.21 (optimisation): the plan's items created with their options handed to Tcl as they are (numbers,
    texts, lists of tags or dashes): tkinter's own way spelled each option out as text first (_options,
    _stringify), a third of a full drawing of DIFORME. A callback or the old dict form: tkinter's way."""
    from tkinter import _flatten
    try:
        slow = canvas._create
        call, getint, name = canvas.tk.call, canvas.tk.getint, canvas._w
    except AttributeError:
        return   # not a Tk canvas (a stand-in): tkinter's way

    def create(kind, args, kw):
        args = _flatten(args)
        if not kw or args and isinstance(args[-1], (dict, tuple)):
            return slow(kind, args, kw)
        options = []
        for key, value in kw.items():
            if value is None:
                continue
            if callable(value):
                return slow(kind, args, kw)
            options.append('-' + (key[:-1] if key[-1] == '_' else key))
            options.append(value)
        return getint(call(name, 'create', kind, *args, *options))
    canvas._create = create


_PROCS = r'''proc craft_raise_groups {c tags} {foreach t $tags {$c raise $t}}
proc craft_lower_groups {c pairs} {foreach {t a} $pairs {$c lower $t $a}}
proc craft_delete_groups {c tags} {foreach t $tags {$c delete $t}}
proc craft_count {c tag} {llength [$c find withtag $tag]}'''


def content(s):
    """The object as bytes (equal bytes: the same object); None: drawn again at every drawing."""
    try:
        return marshal.dumps(s, 2)
    except ValueError:
        return None


class Drawing:
    """The groups made by one drawing of the plan, kept on the canvas for the next one."""

    def __init__(self, app, context, contents, previous=None):
        self.app = app
        self.canvas = app.canvas
        self.context = context
        self.contents = contents
        self.previous = previous
        self.groups = {}        # key -> [tag, ...] in stacking order
        self.position = {}      # tag -> position in this drawing
        self.anchors = {}       # tag -> id of its anchor item
        self.dashes = {}        # tag -> (dashes counted before it, dashes it made, a dash left to Tk)
        self.displaced = {}     # tag -> the DISPLACED tags among its items
        self.boxes = {}         # content -> bounds (plan mm)
        self.sequence = []
        self.fresh = set()
        self.serial = previous.serial if previous else 0
        self.waiting = {k: list(v) for k, v in previous.groups.items()} if previous else {}
        self.ordering = None    # how the stacking order was made again (for the tests)
        self.used = None
        self.current = None
        self.kept = self.drawn = 0
        items = app.items
        n = len(items)
        selected = app.selected
        ids = app.selected_ids() if hasattr(app, 'selected_ids') else ([selected] if selected is not None else [])
        # How each layer knows that an object is selected (by identity, as they do).
        self.first = id(items[selected]) if isinstance(selected, int) and 0 <= selected < n else None
        self.picked = {id(items[i]) for i in (app.__dict__.get('selected_set') or ()) if isinstance(i, int) and 0 <= i < n}
        self.chosen = {id(items[i]) for i in ids if isinstance(i, int) and 0 <= i < n}
        # The objects being translated are drawn for their quick moves (tag « moving », moved where
        # they are): drawn at every drawing, never kept.
        self.moving = app.__dict__.get('_capture_ids') or ()

    def key(self, i, s, data):
        if data is None or id(s) in self.moving:
            return None
        sid = id(s)
        return (data, i == self.app.selected, sid == self.first, sid in self.picked, sid in self.chosen)

    def bounds(self, i, s, measure):
        data = self.contents[i]
        if data is None:
            return measure(s)
        box = self.previous.boxes.get(data) if self.previous else None
        if box is None:
            box = measure(s)
        self.boxes[data] = box
        return box

    # Every item drawn for an object gets the tags of its group (also the pieces of a dashed line
    # or of a clipped curve: the tags go down with the creation).
    def install(self):
        c = self.canvas
        self.restore = c.__dict__.get('_create')
        original = c._create

        def create(kind, args, kw, original=original):
            tags = self.current
            if tags is not None:
                kw = dict(kw or {})
                existing = kw.get('tags', ())
                existing = (existing,) if isinstance(existing, str) else tuple(existing or ())
                kw['tags'] = existing + tags
                moved = [t for t in DISPLACED if t in existing]
                if moved and len(tags) == 2:
                    self.displaced.setdefault(tags[1], set()).update(moved)
            return original(kind, args, kw)
        c._create = create

    def uninstall(self):
        c = self.canvas
        if self.restore is None:
            c.__dict__.pop('_create', None)
        else:
            c._create = self.restore

    def under(self, start):
        """What is drawn before the objects (grid, guides) goes under the kept groups."""
        if self.previous is None:
            return
        if start:
            self.current = (UNDER,)
        else:
            self.current = None
            c = self.canvas
            c.tag_lower(UNDER)
            c.dtag(UNDER, UNDER)
            c.tag_lower('_smooth_display')   # the picture kept until the smoothing stays under all

    def reusable(self, tag):
        """A kept group comes out as a new drawing would draw it (its dashes, against the budget)."""
        start, spent, left = self.previous.dashes.get(tag, (0, 0, False))
        if not spent and not left:
            return True
        from dash_lines import BUDGET
        return self.used == start or (not left and self.used + spent <= BUDGET)

    def draw(self, i, s, color, width):
        c = self.canvas
        if self.used is None:
            self.used = c.__dict__.get('_dash_used', 0)
        data = self.contents[i]
        key = self.key(i, s, data)
        waiting = self.waiting.get(key) if key is not None else None
        tag = None
        if waiting:
            candidate = waiting[0]
            if self.reusable(candidate):
                tag = waiting.pop(0)
                _, spent, left = self.previous.dashes.get(tag, (0, 0, False))
                self.dashes[tag] = (self.used, spent, left)
                self.used += spent
                self.anchors[tag] = self.previous.anchors[tag]
                if tag in self.previous.displaced:
                    self.displaced[tag] = self.previous.displaced[tag]
                self.kept += 1
        if tag is None:
            self.serial += 1
            tag = f'{TAG}:{self.serial}'
            c._dash_used = self.used   # the dashes a full drawing would have made before this object
            left = c.__dict__.get('_dash_left', 0)
            self.current = (TAG, tag)
            try:
                self.anchors[tag] = c.create_image(0, 0, state='hidden', tags=ANCHOR)   # its place in the stacking order
                self.app.draw_shape(s, color, width)
            finally:
                self.current = None
            spent = c.__dict__.get('_dash_used', 0) - self.used
            self.dashes[tag] = (self.used, spent, c.__dict__.get('_dash_left', 0) > left)
            self.used += spent
            self.fresh.add(tag)
            self.drawn += 1
        if key is not None:
            self.groups.setdefault(key, []).append(tag)
        self.position[tag] = len(self.sequence)
        self.sequence.append(tag)

    def order(self):
        """The new groups (drawn on top) go just under the anchor of the group after them, from the
        last one back; the kept ones are still in the order of the previous drawing. Kept groups in
        another order (the list of objects reordered), or more new groups than groups after the first
        new one: every group from there on is raised in order, as a full drawing stacks them."""
        c = self.canvas
        previous = self.previous.position
        highest, broken, last_kept = -1, None, -1
        for k, tag in enumerate(self.sequence):
            if tag in self.fresh:
                continue
            last_kept = k
            if broken is None:
                if previous[tag] < highest:
                    broken = k
                highest = max(highest, previous[tag])
        first = next((k for k, tag in enumerate(self.sequence) if tag in self.fresh), None)
        if broken is not None:
            start = broken if first is None else min(broken, first)
            c.tk.call('craft_raise_groups', c._w, self.sequence[start:])
            self.ordering = 'raise'
            return
        if first is None or first > last_kept:
            return   # nothing new, or only after every kept group: on top already, in order
        moves = []
        for k in range(last_kept - 1, first - 1, -1):
            tag = self.sequence[k]
            if tag in self.fresh:
                moves += [tag, self.anchors[self.sequence[k + 1]]]
        if len(moves) // 2 <= len(self.sequence) - first:
            c.tk.call('craft_lower_groups', c._w, moves)
            self.ordering = 'lower'
        else:
            c.tk.call('craft_raise_groups', c._w, self.sequence[first:])
            self.ordering = 'raise'

    def restack(self):
        """The items of new groups that the drawing moves to the bottom or the top (DISPLACED) are put
        among those of the other groups in the order of the objects (just under those of the next
        group, or above those of the one before)."""
        c = self.canvas
        for moved in DISPLACED:
            having = [tag for tag in self.sequence if moved in self.displaced.get(tag, ())]
            if len(having) < 2 or not any(tag in self.fresh for tag in having):
                continue
            for k in range(len(having) - 1, -1, -1):
                tag = having[k]
                if tag not in self.fresh:
                    continue
                if k + 1 < len(having):
                    c.tk.call(c._w, 'lower', f'{tag}&&{moved}', f'{having[k + 1]}&&{moved}')
                else:
                    c.tk.call(c._w, 'raise', f'{tag}&&{moved}', f'{having[k - 1]}&&{moved}')

    def finish(self):
        """The groups no longer drawn go; the others take the stacking order of the objects."""
        c = self.canvas
        if self.used is not None:
            c._dash_used = self.used   # what is drawn after the objects counts as in a full drawing
        if self.previous is not None:
            gone = [tag for tag in self.previous.sequence if tag not in self.position]
            if gone:
                c.tk.call('craft_delete_groups', c._w, gone)
            self.order()
            self.restack()
        self.count = int(c.tk.call('craft_count', c._w, TAG))
        self.sentinel = c.create_text(0, 0, text='', state='hidden', tags=SENTINEL)
        self.previous = None   # no chain of drawings in memory

    def intact(self):
        """The canvas holds the groups as this drawing left them (not emptied, moved nor zoomed)."""
        c = self.canvas
        try:
            return tuple(c.coords(self.sentinel)) == (0.0, 0.0) and int(c.tk.call('craft_count', c._w, TAG)) == self.count
        except Exception:
            return False


def forget(canvas):
    canvas.__dict__.pop('_draw_cache', None)


def begin(app):
    """Start a drawing of the plan: the canvas emptied, or emptied of all but the groups that may be
    kept. Returns the Drawing (None: nothing is kept, now nor for the next drawing)."""
    c = app.canvas
    last = c.__dict__.pop('_draw_cache', None)
    try:
        context = app.draw_context() if hasattr(app, 'draw_context') else None
    except Exception:
        context = None
    drawing = None
    if context is not None:
        if not c.tk.call('info', 'procs', 'craft_count'):
            c.tk.eval(_PROCS)
        contents = [content(s) for s in app.items]
        if last is not None and last.context == context and last.intact():
            drawing = Drawing(app, context, contents, last)
            # Kept only if most of what was drawn stays (the rest may be off the screen): a window
            # selection of the whole plan, a document changed… are quicker drawn whole.
            left = {k: len(v) for k, v in last.groups.items()}
            same = 0
            for i, (s, data) in enumerate(zip(app.items, contents)):
                key = drawing.key(i, s, data)
                if key is not None and left.get(key, 0) > 0:
                    left[key] -= 1
                    same += 1
            if not same or same < REUSE_AT_LEAST * len(last.sequence):
                drawing = None
        if drawing is None:
            drawing = Drawing(app, context, contents)
    if drawing is not None and drawing.previous is not None:
        c.addtag_all('_stale')
        c.dtag(TAG, '_stale')
        smoothing = bool(app.__dict__.get('_smooth_idle')) and bool(c.find_withtag('_smooth_display'))
        if smoothing:
            # The smoothing comes before Tk shows anything: it makes the picture again (only its
            # changed part) and hides the new lines; until then the old picture and the hidden kept
            # lines stay, the picture marked as stale (a move of the view coming first does not
            # carry it: keep_picture; a zoom shows the lines: show_raw).
            c.dtag('_smooth_display', '_stale')
            c._smooth_stale = True
        c.delete('_stale')
        if not smoothing:
            hidden = c.__dict__.pop('_smooth_hidden', None)
            if hidden:
                c.tk.call('craft_show', c._w, hidden)
    else:
        c.delete('all')
        c.__dict__.pop('_smooth_hidden', None)
        c.__dict__.pop('_smooth_stale', None)
        __import__('display_render').forget_rows(c)
    if drawing is not None:
        drawing.install()
    return drawing


def abandon(app, drawing):
    """The drawing stopped on an error: nothing is kept (the next one empties the canvas)."""
    if drawing is not None:
        drawing.current = None
        drawing.uninstall()
    app.canvas.__dict__.pop('_draw_cache', None)


def end(app, drawing):
    """The drawing of the objects is over (the rest of the plan's drawing comes after)."""
    if drawing is None:
        return
    drawing.uninstall()
    drawing.finish()
    app.canvas._draw_cache = drawing
