"""Licences Craft : clés signées Ed25519, vérifiées hors ligne, sans dépendance.

Édition personnelle : sans le module licence_cle, Craft reste « Version
personnelle », sans aucune restriction ni fichier de licence.
Édition commerciale : licence_cle (produit par l'Espace vendeur) apporte la clé
publique du vendeur ; Craft fonctionne alors en essai, sous licence perpétuelle
ou datée (« abonnement » : une licence d'un an). La clé privée n'existe que chez
le vendeur. Sans licence valable (essai fini, licence annulée, licence datée finie
depuis GRACE_JOURS), Craft est en lecture seule (0.19.16). La date du début de
l'essai est gardée à trois endroits du poste (0.19.17) : en effacer un ne relance pas
l'essai.
"""
import base64
import datetime
import hashlib
import json
import os
import re
from pathlib import Path

PREFIXE = 'CRAFT1'
DOMAINE = b'craft-licence-v1\x00'
TYPES = ('perpetuelle', 'abonnement')
ESSAI_JOURS = 7   # 0.19.17 (« diminue à 7 j l'essai gratuit », 08/11/2026 ; 15 jours en 0.19.16)
GRACE_JOURS = 15
RAPPEL_JOURS = 30
CHAMPS = frozenset({'v', 'kid', 'id', 'produit', 'client', 'email', 'type', 'emise', 'fin', 'postes'})

try:  # Présent seulement dans l'édition commerciale.
    from licence_cle import CLES_PUBLIQUES, REVOQUEES
except ImportError:
    CLES_PUBLIQUES, REVOQUEES = {}, frozenset()
try:  # 0.19.18 : l'adresse où demander une clé (« Demander une clé »), écrite par l'Espace vendeur.
    from licence_cle import CONTACT
except ImportError:
    CONTACT = ''


class LicenceInvalide(ValueError):
    pass


def commerciale():
    return bool(CLES_PUBLIQUES)


# --- Ed25519 (RFC 8032, implémentation de référence en Python pur) ---------
_P = 2 ** 255 - 19
_Q = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_RACINE_M1 = pow(2, (_P - 1) // 4, _P)


def _sha512_modq(data):
    return int.from_bytes(hashlib.sha512(data).digest(), 'little') % _Q


def _ajouter(a, b):
    x1, y1, z1, t1 = a
    x2, y2, z2, t2 = b
    va = (y1 - x1) * (y2 - x2) % _P
    vb = (y1 + x1) * (y2 + x2) % _P
    vc = 2 * t1 * t2 * _D % _P
    vd = 2 * z1 * z2 % _P
    e, f, g, h = vb - va, vd - vc, vd + vc, vb + va
    return (e * f % _P, g * h % _P, f * g % _P, e * h % _P)


def _multiplier(s, point):
    resultat = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            resultat = _ajouter(resultat, point)
        point = _ajouter(point, point)
        s >>= 1
    return resultat


def _egal(a, b):
    return (a[0] * b[2] - b[0] * a[2]) % _P == 0 and (a[1] * b[2] - b[1] * a[2]) % _P == 0


def _retrouver_x(y, signe):
    if y >= _P:
        return None
    x2 = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P) % _P
    if x2 == 0:
        return None if signe else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P:
        x = x * _RACINE_M1 % _P
    if (x * x - x2) % _P:
        return None
    if (x & 1) != signe:
        x = _P - x
    return x


_GY = 4 * pow(5, _P - 2, _P) % _P
_GX = _retrouver_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)


def _compresser(point):
    zinv = pow(point[2], _P - 2, _P)
    x, y = point[0] * zinv % _P, point[1] * zinv % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, 'little')


def _decompresser(octets):
    if len(octets) != 32:
        return None
    y = int.from_bytes(octets, 'little')
    signe = y >> 255
    y &= (1 << 255) - 1
    x = _retrouver_x(y, signe)
    return None if x is None else (x, y, 1, x * y % _P)


def _developper(graine):
    if len(graine) != 32:
        raise ValueError('Graine Ed25519 : 32 octets')
    h = hashlib.sha512(graine).digest()
    a = int.from_bytes(h[:32], 'little')
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def cle_publique(graine):
    """Clé publique (32 octets) d'une graine privée de 32 octets."""
    a, _ = _developper(graine)
    return _compresser(_multiplier(a, _G))


def signer(graine, message):
    """Signature Ed25519 (64 octets). Côté vendeur uniquement."""
    a, prefixe = _developper(graine)
    publique = _compresser(_multiplier(a, _G))
    r = _sha512_modq(prefixe + message)
    rs = _compresser(_multiplier(r, _G))
    h = _sha512_modq(rs + publique + message)
    return rs + int.to_bytes((r + h * a) % _Q, 32, 'little')


def verifier(publique, message, signature):
    """Vrai si la signature Ed25519 est valable pour ce message et cette clé."""
    if len(publique) != 32 or len(signature) != 64:
        return False
    point_a = _decompresser(publique)
    point_r = _decompresser(signature[:32])
    if point_a is None or point_r is None:
        return False
    s = int.from_bytes(signature[32:], 'little')
    if s >= _Q:
        return False
    h = _sha512_modq(signature[:32] + publique + message)
    return _egal(_multiplier(s, _G), _ajouter(point_r, _multiplier(h, point_a)))


# --- Format de la clé de licence -------------------------------------------
def b64(data):
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')


def unb64(texte):
    if not isinstance(texte, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,4000}', texte):
        raise LicenceInvalide('Clé de licence illisible.')
    try:
        return base64.urlsafe_b64decode(texte + '=' * (-len(texte) % 4))
    except ValueError as exc:
        raise LicenceInvalide('Clé de licence illisible.') from exc


def canonique(valeur):
    return json.dumps(valeur, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def date_iso(valeur):
    if isinstance(valeur, datetime.datetime):
        valeur = valeur.date()
    if isinstance(valeur, datetime.date):
        return valeur.isoformat()
    return datetime.date.fromisoformat(str(valeur)).isoformat()


def _date(texte):
    try:
        return datetime.date.fromisoformat(texte)
    except (TypeError, ValueError) as exc:
        raise LicenceInvalide('Date de licence invalide.') from exc


def controler(contenu):
    """Vérifie la forme du contenu d'une licence (pas la signature)."""
    if not isinstance(contenu, dict) or set(contenu) != CHAMPS:
        raise LicenceInvalide('Clé de licence illisible.')
    if contenu['v'] != 1 or contenu['produit'] != 'craft' or contenu['type'] not in TYPES:
        raise LicenceInvalide('Licence d’un autre produit ou d’un format inconnu.')
    for champ, limite in (('client', 100), ('email', 254), ('kid', 32)):
        valeur = contenu[champ]
        if not isinstance(valeur, str) or not valeur.strip() or len(valeur) > limite:
            raise LicenceInvalide('Licence incomplète.')
    if '@' not in contenu['email'] or not isinstance(contenu['id'], str) or not re.fullmatch(r'[0-9a-f]{8,32}', contenu['id']):
        raise LicenceInvalide('Licence incomplète.')
    if type(contenu['postes']) is not int or not 1 <= contenu['postes'] <= 1000:
        raise LicenceInvalide('Nombre de postes invalide.')
    emise = _date(contenu['emise'])
    if contenu['type'] == 'abonnement':
        if contenu['fin'] is None or _date(contenu['fin']) < emise:
            raise LicenceInvalide('Abonnement sans date de fin valable.')
    elif contenu['fin'] is not None:
        raise LicenceInvalide('Une licence perpétuelle n’a pas de date de fin.')
    return contenu


def creer(graine, kid, client, email, type_licence, emise, fin=None, postes=1, ident=None):
    """Côté vendeur : texte de la clé à envoyer au client."""
    contenu = dict(v=1, kid=kid, id=ident or os.urandom(8).hex(), produit='craft', client=str(client).strip(),
                   email=str(email).strip(), type=type_licence, emise=date_iso(emise),
                   fin=date_iso(fin) if fin else None, postes=int(postes))
    controler(contenu)
    brut = canonique(contenu)
    return '%s.%s.%s' % (PREFIXE, b64(brut), b64(signer(graine, DOMAINE + brut)))


def lire(texte, cles=None, revoquees=None):
    """Contenu d'une clé de licence dont la signature est valable ; sinon LicenceInvalide."""
    cles = CLES_PUBLIQUES if cles is None else cles
    revoquees = REVOQUEES if revoquees is None else revoquees
    texte = re.sub(r'\s+', '', texte or '')
    if not texte.startswith(PREFIXE + '.') or len(texte) > 6000:
        raise LicenceInvalide('Ce texte n’est pas une clé de licence Craft.')
    morceaux = texte.split('.')
    if len(morceaux) != 3:
        raise LicenceInvalide('Clé de licence incomplète : copiez-la en entier.')
    brut, signature = unb64(morceaux[1]), unb64(morceaux[2])
    try:
        contenu = json.loads(brut.decode('utf-8'))
    except (UnicodeError, ValueError) as exc:
        raise LicenceInvalide('Clé de licence illisible.') from exc
    if not isinstance(contenu, dict) or set(contenu) != CHAMPS:
        raise LicenceInvalide('Clé de licence illisible.')
    publique = cles.get(contenu.get('kid')) if isinstance(contenu.get('kid'), str) else None
    if not publique or not verifier(unb64(publique), DOMAINE + brut, signature):
        raise LicenceInvalide('Cette clé n’est pas valable pour cette édition de Craft.')
    controler(contenu)
    if contenu['id'] in revoquees:
        raise LicenceInvalide('Cette licence a été annulée par le vendeur.')
    return contenu


# --- État local et règles d'utilisation -----------------------------------
def demande_de_cle(nom, adresse=None):
    """0.19.18 « Demander une clé » : le lien mailto vers le vendeur, l'objet et le message (le nom de l'utilisateur
    de Windows déjà écrit) ; '' sans adresse."""
    from urllib.parse import quote
    adresse = (CONTACT if adresse is None else adresse).strip()
    if '@' not in adresse or any(c in adresse for c in ' ?&#<>"\'\n\r'):
        return ''
    corps = 'Bonjour,\n\nJe voudrais une clé de licence Craft.\nNom : %s\n\nMerci !' % (nom or '').strip()
    return 'mailto:%s?subject=%s&body=%s' % (quote(adresse, safe='@'), quote('Clé Craft'), quote(corps))


def chemin_etat():
    from app_paths import user_data_directory
    return user_data_directory() / 'licence.json'


def charger(chemin):
    try:
        donnees = json.loads(Path(chemin).read_text(encoding='utf-8'))
        return donnees if isinstance(donnees, dict) else {}
    except (OSError, ValueError):
        return {}


def enregistrer(chemin, donnees):
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    temporaire = chemin.with_name(chemin.name + '.tmp')
    temporaire.write_text(json.dumps(donnees, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(temporaire, chemin)


def _francais(jour):
    return jour.strftime('%d/%m/%Y')


LECTURE_SEULE = ('Craft est en lecture seule : vos patrons s’ouvrent toujours ; pour dessiner, collez une clé de licence '
                 '(Aide › Activer une licence…).')


def evaluer(donnees, aujourd_hui, cles=None, revoquees=None):
    """Règles : licence valable, licence datée (+GRACE_JOURS de grâce), sinon essai de ESSAI_JOURS.
    Sans licence ni essai (``export`` faux) : lecture seule (0.19.16) ; ouvrir, regarder et enregistrer restent
    possibles, ni dessin, ni modification, ni export."""
    essai = _date(donnees.get('essai_debut', aujourd_hui.isoformat()))
    contenu, probleme = None, ''
    if donnees.get('cle'):
        try:
            contenu = lire(donnees['cle'], cles, revoquees)
        except LicenceInvalide as exc:
            probleme = str(exc) + ' '
    if contenu:
        client = contenu['client']
        if contenu['fin'] is None:
            return dict(mode='licence', client=client, type='perpetuelle', fin=None, jours=None, export=True,
                        titre='Licence ' + client, message='Licence à vie de ' + client + '.')
        fin = _date(contenu['fin'])
        jours = (fin - aujourd_hui).days
        if jours >= 0:
            message = 'Licence de %s jusqu’au %s.' % (client, _francais(fin))
            if jours <= RAPPEL_JOURS:
                message += ' Pensez à demander une nouvelle clé (%d jour%s).' % (jours, 's' if jours > 1 else '')
            return dict(mode='licence', client=client, type='abonnement', fin=fin, jours=jours, export=True,
                        titre='Licence ' + client, message=message)
        if -jours <= GRACE_JOURS:
            reste = GRACE_JOURS + jours
            return dict(mode='grace', client=client, type='abonnement', fin=fin, jours=jours, export=True,
                        titre='Licence %s — à renouveler' % client,
                        message='Licence terminée le %s. Craft reste complet encore %d jour%s : collez la nouvelle clé '
                                '(Aide › Activer une licence…).' % (_francais(fin), reste, 's' if reste > 1 else ''))
        return dict(mode='expiree', client=client, type='abonnement', fin=fin, jours=jours, export=False,
                    titre='Licence %s terminée — lecture seule' % client,
                    message='Licence terminée le %s. %s' % (_francais(fin), LECTURE_SEULE))
    restants = ESSAI_JOURS - (aujourd_hui - essai).days
    if restants > 0:
        return dict(mode='essai', client=None, type=None, fin=essai + datetime.timedelta(days=ESSAI_JOURS), jours=restants,
                    export=True, titre='Essai — %d jour%s' % (restants, 's' if restants > 1 else ''),
                    message=probleme + 'Essai complet : %d jour%s restant%s.' % (restants, 's' if restants > 1 else '', 's' if restants > 1 else ''))
    return dict(mode='essai_fini', client=None, type=None, fin=essai + datetime.timedelta(days=ESSAI_JOURS), jours=restants,
                export=False, titre='Essai terminé — lecture seule', message=probleme + 'Essai terminé. ' + LECTURE_SEULE)


# --- 0.19.17 : la date du début de l'essai gardée à trois endroits -----------
# « si quelqu'un réinstalle juste tous les 7 jours ? » : licence.json (AppData\Local\Craft), le registre de Windows
# (HKCU\Software\Craft) et ProgramData\Craft ; la date la plus ancienne compte, et le jour le plus récent déjà vu
# (l'horloge reculée ne prolonge rien) ; une marque retouchée est ignorée puis réécrite. La désinstallation et
# l'installateur n'y touchent pas. Les trois effacés à la main : un nouvel essai (le serveur, plus tard, l'empêchera).
_SEL = b'craft-essai-v1\x00'


def marque(debut, vu):
    brut = canonique(dict(e=debut.isoformat(), v=vu.isoformat()))
    return 'E1.%s.%s' % (b64(brut), hashlib.sha256(_SEL + brut).hexdigest()[:16])


def lire_marque(texte):
    """(début, jour vu) d'une marque intacte ; None si elle manque, est abîmée ou retouchée."""
    try:
        prefixe, corps, somme = str(texte).strip().split('.')
        brut = unb64(corps)
        if prefixe != 'E1' or hashlib.sha256(_SEL + brut).hexdigest()[:16] != somme:
            return None
        donnees = json.loads(brut.decode('utf-8'))
        return datetime.date.fromisoformat(donnees['e']), datetime.date.fromisoformat(donnees['v'])
    except (ValueError, TypeError, KeyError, AttributeError, UnicodeError):
        return None


class CopieFichier:
    """La marque dans un fichier (ProgramData\\Craft\\essai.dat)."""

    def __init__(self, chemin):
        self.chemin = Path(chemin)

    def lire(self):
        try:
            return lire_marque(self.chemin.read_text(encoding='ascii'))
        except (OSError, ValueError):
            return None

    def ecrire(self, debut, vu):
        self.chemin.parent.mkdir(parents=True, exist_ok=True)
        temporaire = self.chemin.with_name(self.chemin.name + '.tmp')
        temporaire.write_text(marque(debut, vu), encoding='ascii')
        os.replace(temporaire, self.chemin)


class CopieRegistre:
    """La marque dans le registre de Windows (HKCU\\Software\\Craft, valeur Etat)."""
    CLE, VALEUR = r'Software\Craft', 'Etat'

    def __init__(self, winreg):
        self.winreg = winreg

    def lire(self):
        try:
            with self.winreg.OpenKey(self.winreg.HKEY_CURRENT_USER, self.CLE) as cle:
                return lire_marque(self.winreg.QueryValueEx(cle, self.VALEUR)[0])
        except (OSError, ValueError, TypeError):
            return None

    def ecrire(self, debut, vu):
        with self.winreg.CreateKey(self.winreg.HKEY_CURRENT_USER, self.CLE) as cle:
            self.winreg.SetValueEx(cle, self.VALEUR, 0, self.winreg.REG_SZ, marque(debut, vu))


def copies_essai():
    """Les deux autres endroits du poste : le registre (Windows) et ProgramData."""
    copies = []
    try:
        import winreg
        copies.append(CopieRegistre(winreg))
    except ImportError:
        pass
    if os.environ.get('PROGRAMDATA'):
        copies.append(CopieFichier(Path(os.environ['PROGRAMDATA']) / 'Craft' / 'essai.dat'))
    return copies


def _jour(texte):
    try:
        return datetime.date.fromisoformat(texte)
    except (TypeError, ValueError):
        return None


def etat_actuel(aujourd_hui=None, chemin=None, cles=None, revoquees=None, copies=None):
    """État de la licence de ce poste. L'édition personnelle n'écrit aucun fichier. ``copies`` : les autres endroits
    de la date de l'essai (par défaut ceux du poste, sauf pour un ``chemin`` donné)."""
    cles = CLES_PUBLIQUES if cles is None else cles
    if not cles:
        return dict(mode='personnelle', client=None, type=None, fin=None, jours=None, export=True,
                    titre='Version personnelle', message='Version personnelle.')
    if copies is None:
        copies = copies_essai() if chemin is None else ()
    chemin = chemin or chemin_etat()
    aujourd_hui = aujourd_hui or datetime.date.today()
    donnees = charger(chemin)
    lues = [(copie, copie.lire()) for copie in copies]
    traces = [trace for _, trace in lues if trace]
    debuts = [d for d in [_jour(donnees.get('essai_debut'))] + [t[0] for t in traces] if d]
    vus = [v for v in [_jour(donnees.get('vu'))] + [t[1] for t in traces] if v]
    jour = max([aujourd_hui] + vus)  # Reculer l'horloge ne prolonge ni l'essai ni l'abonnement.
    debut = min(min(debuts) if debuts else aujourd_hui, jour)
    if (donnees.get('essai_debut'), donnees.get('vu')) != (debut.isoformat(), jour.isoformat()):
        donnees['essai_debut'], donnees['vu'] = debut.isoformat(), jour.isoformat()
        try:
            enregistrer(chemin, donnees)
        except OSError:
            pass
    for copie, trace in lues:
        if trace != (debut, jour):
            try:
                copie.ecrire(debut, jour)
            except (OSError, ValueError, TypeError):
                pass
    return evaluer(donnees, jour, cles, revoquees)


def activer(texte, aujourd_hui=None, chemin=None, cles=None, revoquees=None):
    """Enregistre la clé si elle est valable et utilisable aujourd'hui ; renvoie le nouvel état."""
    cles = CLES_PUBLIQUES if cles is None else cles
    if not cles:
        raise LicenceInvalide('Cette édition de Craft n’utilise pas de licence.')
    contenu = lire(texte, cles, revoquees)
    chemin = chemin or chemin_etat()
    aujourd_hui = aujourd_hui or datetime.date.today()
    donnees = charger(chemin)
    essai = dict(donnees, cle=re.sub(r'\s+', '', texte))
    essai.setdefault('essai_debut', aujourd_hui.isoformat())
    resultat = evaluer(essai, max(aujourd_hui, _date(essai.get('vu', aujourd_hui.isoformat()))), cles, revoquees)
    if resultat['mode'] == 'expiree':
        raise LicenceInvalide('Cette licence s’est terminée le %s : demandez une nouvelle clé.' % _francais(_date(contenu['fin'])))
    enregistrer(chemin, essai)
    return resultat
