"""Édition partagée de Craft : où chercher ses mises à jour, et la clé publique qui les signe.
Produit par tools/build_share.py. Ne contient aucun secret."""
MANIFESTE = 'https://raw.githubusercontent.com/DurandCuir/Craft/main/craft-maj.json'
CLE = 'Cv3YRq_ep-ZDoHH2UDRBJsGmUGMiBXzO8dvUjVviYr4'
