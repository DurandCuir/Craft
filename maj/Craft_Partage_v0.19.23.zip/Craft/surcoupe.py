"""0.18.1 Précoupe / surcoupe (Mozart: P_07 SURCOUPE, « Objet de surcoupe » lines).

1st step, précoupe: a piece larger than the final ones (a rectangle, or their contours moved out
by the écart) is cut, then the layers are glued. 2nd step, surcoupe: the final pieces are recut
inside it (emporte-pièce or cutting machine), then filetées.

« Précoupe en série »: the piece chosen, ``columns`` × ``rows`` copies ``gap`` mm apart, the same
gap all round; a rectangle, or the contours moved out by the gap and joined (« suit la forme »).
The piece becomes the précoupe: its contour is drawn in « objet de surcoupe » (dash-dot, role
'surcoupe', never cut at the 1st step), the précoupe (Coupe externe) takes its name, material
and number, everything that belonged to the piece goes to the précoupe (moved, copied with it),
and the band between them is a Surcoupe zone (« SURCOUPE 5 »)."""
import copy
import math
import uuid

ROLE = 'surcoupe'
# « Objet de surcoupe ____ . ____ . ____ » (Mozart's MOZ_RIFILO linetype).
STYLE = dict(color='auto', width=.2, dash=[6., 1.5, .5, 1.5], role=ROLE)


def is_precut(s):
    return bool(s.get('surcoupe')) and not s.get('annotation')


def inner_contours(items, i):
    """Indices of the pieces to recut (contours in « objet de surcoupe ») of précoupe ``i``."""
    from craft_tools import style
    owner = items[i].get('piece_id')
    if not owner:
        return []
    return [k for k, s in enumerate(items) if s.get('owner_id') == owner and style(s)['role'] == ROLE and not s.get('annotation')]


def per_precut(items, i):
    """How many final pieces one précoupe gives (1 when it is not a précoupe)."""
    return max(1, len(inner_contours(items, i)))


def precuts_needed(quantity, per):
    """0.18.1 n°17: précoupes to cut for ``quantity`` final pieces, ``per`` in each."""
    return max(1, math.ceil(max(1, int(quantity)) / max(1, int(per))))


def members(items, i):
    """What goes with piece ``i``: what it owns, and the lines, crans and pointés inside it."""
    from entity_rules import geometry_entity, closed_piece
    from craft_tools import style
    from geometry import path, bounds
    from precision_geometry import inside, contour_location
    piece = items[i]
    owner = piece.get('piece_id')
    x, y, X, Y = bounds([piece])
    out = []
    for k, s in enumerate(items):
        if k == i:
            continue
        if owner and s.get('owner_id') == owner:
            out.append(k)
            continue
        if s.get('owner_id') or s.get('dimension_group'):
            continue
        if s.get('annotation') and not s.get('identification'):
            continue
        if closed_piece(s) and style(s)['role'] == 'external':
            continue
        if s.get('is_notch'):
            # A cran goes with the piece its foot is on (it may point outwards).
            if _on_or_in(piece, s):
                out.append(k)
            continue
        try:
            pts = path(s)[0]
        except (ValueError, KeyError, TypeError):
            continue
        if not pts or not all(x - .05 <= p[0] <= X + .05 and y - .05 <= p[1] <= Y + .05 for p in pts):
            continue
        if all(inside(piece, p) or math.dist(contour_location(piece, p)[1], p) < .05 for p in pts):
            if geometry_entity(s) or s.get('is_notch') or s.get('drill') or s.get('identification') or s.get('preparation'):
                out.append(k)
    return out


def moved(s, dx, dy):
    q = copy.deepcopy(s)
    q['x'] += dx
    q['y'] += dy
    return q


def outline(piece, columns, rows, gap, follow=False):
    """The précoupe's contour: around ``columns`` × ``rows`` copies ``gap`` mm apart and from the
    edge; ``follow``: the contour of the piece moved out by ``gap`` (in series, these contours
    joined into one)."""
    from geometry import bounds
    from cad import polygon
    x, y, X, Y = bounds([piece])
    w, h = X - x, Y - y
    if follow:
        from precision_geometry import shifted
        try:
            q = shifted(piece, gap)
        except ValueError:
            # 0.19.14: a hollow narrower than the écart (the arrondi of a Poignée toron with a thin toron, a step): the
            # outer edge of the contour moved out, its inner loops left out
            q = envelope(piece, gap)
            if q is None:
                raise ValueError('« Suit la forme » impossible avec cet écart (le contour décalé se croise) : réduire l’écart ou choisir Rectangle.') from None
        for key in ('notches', 'piece_id', 'owner_id', 'piece_info', 'stitch', 'surcoupe'):
            q.pop(key, None)
        if columns == 1 and rows == 1:
            return q
        joined = union([moved(q, c * (w + gap), r * (h + gap)) for r in range(rows) for c in range(columns)])
        if joined is None:
            raise ValueError('Avec cet écart, les contours décalés ne se rejoignent pas : choisir Rectangle.')
        return joined
    right = x + columns * w + (columns - 1) * gap + gap
    bottom = y + rows * h + (rows - 1) * gap + gap
    return polygon([(x - gap, y - gap), (right, y - gap), (right, bottom), (x - gap, bottom)], 'Précoupe', True)


class SegmentGrid:
    """0.19.14: the segments of closed rings in a grid of square cells, to find quickly those near a point or crossing
    a segment (the précoupe's checks)."""

    def __init__(self, rings, cell):
        self.cell = max(cell, 1e-3)
        self.cells = {}
        self.segments = []
        c = self.cell
        cell_of = lambda p: (math.floor(p[0] / c), math.floor(p[1] / c))
        for ring in rings:
            for a, b in zip(ring, ring[1:] + ring[:1]):
                k = len(self.segments)
                self.segments.append((a, b))
                # the cells along the segment only (a long diagonal side filled its whole box: 800 000 cells): points
                # half a cell apart, and the corners of each step's box
                n = max(1, math.ceil(math.dist(a, b) / (c / 2)))
                pts = [(a[0] + (b[0] - a[0]) * j / n, a[1] + (b[1] - a[1]) * j / n) for j in range(n + 1)]
                keys = {cell_of(p) for p in pts}
                for p, q in zip(pts, pts[1:]):
                    keys.add(cell_of((p[0], q[1])))
                    keys.add(cell_of((q[0], p[1])))
                for key in keys:
                    self.cells.setdefault(key, []).append(k)

    def _keys(self, x0, y0, x1, y1):
        c = self.cell
        for i in range(math.floor(x0 / c), math.floor(x1 / c) + 1):
            for j in range(math.floor(y0 / c), math.floor(y1 / c) + 1):
                yield (i, j)

    def near(self, x0, y0, x1, y1):
        seen = set()
        for key in self._keys(x0, y0, x1, y1):
            for k in self.cells.get(key, ()):
                if k not in seen:
                    seen.add(k)
                    yield self.segments[k]

    def distance(self, p, reach):
        """The distance from ``p`` to the nearest segment, at most ``reach`` (``reach`` when none is nearer)."""
        best = reach
        for a, b in self.near(p[0] - reach, p[1] - reach, p[0] + reach, p[1] + reach):
            best = min(best, _segment_gap(p, a, b))
        return best

    def crosses(self, a, b):
        from cad import segment_intersection
        for c, d in self.near(min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1])):
            if segment_intersection(a, b, c, d):
                return True
        return False


def _segment_gap(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = dx * dx + dy * dy
    t = 0. if L == 0 else max(0., min(1., ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L))
    return math.dist(p, (a[0] + t * dx, a[1] + t * dy))


def _ring(s):
    from geometry import path
    pts, closed = path(s)
    pts = [tuple(p) for p in pts]
    if len(pts) > 2 and math.dist(pts[0], pts[-1]) < 1e-9:
        pts = pts[:-1]
    return [p for k, p in enumerate(pts) if math.dist(p, pts[k - 1]) > 1e-9], closed


def holds(outer, piece, gap, tolerance=.05):
    """0.19.14: True when the précoupe ``outer`` holds ``piece``: never crossing it, every point of each ``gap`` from
    the other (``tolerance`` less), the piece inside."""
    from precision_geometry import inside
    q, _ = _ring(outer)
    pts, _ = _ring(piece)
    if len(q) < 3 or len(pts) < 3 or not inside(outer, pts[0]):
        return False
    cell = max(gap, 1.)
    grid_piece, grid_outer = SegmentGrid([pts], cell), SegmentGrid([q], cell)
    if any(grid_piece.crosses(a, b) for a, b in zip(q, q[1:] + q[:1])):
        return False
    want = gap - tolerance
    if any(grid_piece.distance(p, gap) < want for p in q):
        return False
    return not any(grid_outer.distance(p, gap) < want for p in pts)


def envelope(piece, gap):
    """0.19.14: the contour of a closed piece moved out by ``gap`` when the plain offset crosses itself (a hollow
    narrower than the écart, a step): each side moved out; at a corner that opens, the two sides joined at their
    meeting point (rounded round the corner when that point is further than twice the écart); at a hollow corner,
    through the corner itself; then only the outer edge kept (the island seen from outside, as ``union``), and kept
    only when it holds the piece (``holds``). None when it cannot be made."""
    try:
        pts, closed = _ring(piece)
    except (ValueError, KeyError, TypeError):
        return None
    if not closed or len(pts) < 3 or gap <= 0:
        return None
    # a hollow of about the radius of the écart folds its moved sides onto one spot, where the island search loses
    # its way: a little further then (the précoupe is never nearer than the écart)
    for more in (0., .02, .05, .2, .5):
        q = _moved_out(pts, gap + more)
        if q is not None and holds(q, piece, gap):
            return q
    return None


def _moved_out(pts, gap):
    from geometry import bounds
    from cad import polygon
    from regions import region_at
    area = sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(pts, pts[1:] + pts[:1]))
    out_sign = -1 if area > 0 else 1      # the normal (-dy, dx) points outwards for a clockwise ring (y down)
    sides = []
    for a, b in zip(pts, pts[1:] + pts[:1]):
        n = math.dist(a, b)
        ux, uy = -(b[1] - a[1]) / n * out_sign * gap, (b[0] - a[0]) / n * out_sign * gap
        sides.append(((a[0] + ux, a[1] + uy), (b[0] + ux, b[1] + uy)))
    ring = []
    for k in range(len(sides)):
        (a, b), (c, e) = sides[k - 1], sides[k]
        v = pts[k]
        u, w = (b[0] - a[0], b[1] - a[1]), (e[0] - c[0], e[1] - c[1])
        cross = u[0] * w[1] - u[1] * w[0]
        if abs(cross) <= 1e-12 * math.hypot(*u) * math.hypot(*w) and u[0] * w[0] + u[1] * w[1] > 0:
            ring.append(b)   # straight on
        elif cross * area > 0:   # a corner that opens outwards: their meeting point, or round
            s = ((c[0] - a[0]) * w[1] - (c[1] - a[1]) * w[0]) / cross
            p = (a[0] + u[0] * s, a[1] + u[1] * s)
            if math.dist(p, v) <= 2 * gap:
                ring.append(p)
            else:
                a0 = math.atan2(b[1] - v[1], b[0] - v[0])
                a1 = math.atan2(c[1] - v[1], c[0] - v[0])
                sweep = (a1 - a0) % (2 * math.pi)
                if sweep > math.pi:
                    sweep -= 2 * math.pi
                steps = max(2, int(abs(sweep) / math.radians(10)) + 1)
                ring += [(v[0] + gap * math.cos(a0 + sweep * j / steps), v[1] + gap * math.sin(a0 + sweep * j / steps)) for j in range(steps + 1)]
        elif math.dist(b, c) <= 1e-6:   # a hollow corner whose moved sides meet
            ring.append(b)
        else:   # a hollow corner: through the corner itself (the loops it makes stay inside)
            ring += [b, v, c]
    ring = [p for j, p in enumerate(ring) if math.dist(p, ring[j - 1]) > 1e-6]
    raw = polygon(ring, 'Précoupe', True)
    x, y, X, Y = bounds([raw])
    frame = polygon([(x - 20, y - 20), (X + 20, y - 20), (X + 20, Y + 20), (x - 20, Y + 20)], '', True)
    try:
        found = region_at([frame, raw], (x - 10, y - 10))
    except (ValueError, ZeroDivisionError, IndexError, RecursionError):
        return None
    if not found or not found.get('holes'):
        return None
    # the outer edge: the largest one seen from outside (tiny pockets where moved sides overlap left out, ``holds``
    # checks the result)
    edge = max(([tuple(p) for p in hole] for hole in found['holes']),
               key=lambda h: abs(sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(h, h[1:] + h[:1]))))
    if len(edge) < 3:
        return None
    return polygon(edge, 'Précoupe', True)


def union(contours):
    """The outline of closed contours that overlap (one piece), None when they do not all meet:
    the island found by « point intérieur » between them and a frame around them."""
    from regions import region_at
    from geometry import bounds
    from cad import polygon
    x, y, X, Y = bounds(contours)
    frame = polygon([(x - 20, y - 20), (X + 20, y - 20), (X + 20, Y + 20), (x - 20, Y + 20)], '', True)
    found = region_at([frame] + contours, (x - 10, y - 10))
    if not found or len(found.get('holes') or []) != 1:
        return None
    ring = found['holes'][0]
    a, b, A, B = (min(p[0] for p in ring), min(p[1] for p in ring), max(p[0] for p in ring), max(p[1] for p in ring))
    if abs(a - x) > .05 or abs(b - y) > .05 or abs(A - X) > .05 or abs(B - Y) > .05:
        return None
    return polygon([tuple(p) for p in ring], 'Précoupe', True)


def thinned(pts, tol=.05):
    """A closed ring with fewer points (Douglas-Peucker within ``tol`` mm): the Surcoupe zone is
    only shown, its arcs need no 0,005 mm precision."""
    pts = [tuple(q) for q in pts]
    if len(pts) < 8:
        return pts
    line = pts + [pts[0]]
    keep = [False] * len(line)
    far = max(range(len(line)), key=lambda k: math.dist(line[0], line[k]))
    keep[0] = keep[-1] = keep[far] = True
    stack = [(0, far), (far, len(line) - 1)]
    while stack:
        a, b = stack.pop()
        if b - a < 2:
            continue
        (ax, ay), (bx, by) = line[a], line[b]
        dx, dy = bx - ax, by - ay
        size = math.hypot(dx, dy)
        best, at = -1., None
        for k in range(a + 1, b):
            px, py = line[k]
            d = abs(dx * (py - ay) - dy * (px - ax)) / size if size > 1e-12 else math.hypot(px - ax, py - ay)
            if d > best:
                best, at = d, k
        if best > tol:
            keep[at] = True
            stack += [(a, at), (at, b)]
    return [q for q, k in zip(line[:-1], keep[:-1]) if k]


def band_zone(outer, inners, gap, owner):
    """The Surcoupe zone: the précoupe minus the pieces to recut."""
    from geometry import path
    import preparations as prep
    region = dict(points=thinned(path(outer)[0]), holes=[thinned(path(s)[0]) for s in inners], width=gap)
    data = dict(kind='surcoupe', type='Surcoupe', length=round(gap, 2), width=gap)
    return prep.zone(region, data, owner)


def make_precut(items, i, columns=1, rows=1, gap=5., follow=False):
    """The document with piece ``i`` made into a précoupe of ``columns`` × ``rows`` pieces;
    returns (items, index of the précoupe). The items given are not changed."""
    from craft_tools import PROFILES, style
    from geometry import bounds
    from entity_rules import closed_piece
    columns, rows, gap = int(columns), int(rows), float(gap)
    if not 1 <= columns <= 50 or not 1 <= rows <= 50 or columns * rows > 400:
        raise ValueError('Colonnes et rangées : 1 à 50 (400 pièces au plus).')
    if not .5 <= gap <= 200:
        raise ValueError('Écart : 0,5 à 200 mm.')
    piece = items[i]
    if not closed_piece(piece) or style(piece)['role'] != 'external':
        raise ValueError('Choisir une pièce fermée en Coupe externe.')
    if is_precut(piece):
        raise ValueError('Cette pièce est déjà une précoupe.')
    owner = uuid.uuid4().hex
    group = members(items, i)
    x, y, X, Y = bounds([piece])
    w, h = X - x, Y - y
    outer = outline(piece, columns, rows, gap, follow)
    outer['name'] = piece.get('name') or 'Précoupe'
    outer['profile'] = 'Coupe extérieure'
    outer['style'] = dict(PROFILES['Coupe extérieure'])
    outer['piece_id'] = owner
    outer['surcoupe'] = dict(columns=columns, rows=rows, gap=gap, follow=bool(follow))
    if piece.get('piece_info'):
        outer['piece_info'] = copy.deepcopy(piece['piece_info'])
    base = copy.deepcopy(piece)
    for key in ('piece_id', 'piece_info', 'notches', 'surcoupe'):
        base.pop(key, None)
    base['style'] = dict(STYLE)
    base['owner_id'] = owner
    keep_once = lambda s: s.get('identification') or s.get('piece_badge')
    out = [copy.deepcopy(s) for s in items]
    out[i] = outer
    inners = []
    extra = []
    for r in range(rows):
        for c in range(columns):
            dx, dy = c * (w + gap), r * (h + gap)
            inner = moved(base, dx, dy)
            inners.append(inner)
            extra.append(inner)
            for k in group:
                s = items[k]
                if keep_once(s):
                    continue
                q = moved(s, dx, dy) if (dx or dy) else None
                if q is not None:
                    q['owner_id'] = owner
                    extra.append(q)
    for k in group:
        if out[k].get('owner_id') == piece.get('piece_id') or not out[k].get('owner_id'):
            out[k]['owner_id'] = owner
    if piece.get('notches'):
        for inner in inners:
            inner['notches'] = copy.deepcopy(piece['notches'])
    extra.append(band_zone(outer, inners, gap, owner))
    try:
        from geometry import validate
        validate(copy.deepcopy([outer, extra[-1]]))
    except ValueError:
        raise ValueError('Précoupe trop détaillée pour être enregistrée : moins de pièces, ou Rectangle.') from None
    return out + extra, i


def final_size(items, i):
    """Width and height of the pieces to recut in précoupe ``i`` (None when it has none)."""
    from geometry import bounds
    ks = inner_contours(items, i)
    if not ks:
        return None
    x, y, X, Y = bounds([items[ks[0]]])
    return X - x, Y - y


def band_width(items, i):
    """The écart of précoupe ``i``: as made, else the Surcoupe zone's length."""
    s = items[i]
    if s.get('surcoupe', {}).get('gap'):
        return float(s['surcoupe']['gap'])
    owner = s.get('piece_id')
    for z in items:
        p = z.get('preparation')
        if p and p.get('kind') == 'surcoupe' and z.get('owner_id') == owner and p.get('length'):
            return float(p['length'])
    return None


def _on_or_in(contour, s):
    """True when ``s`` (a cran by its foot, else all its points) lies on or inside ``contour``."""
    from geometry import path
    from curves import parts
    from precision_geometry import inside, contour_location
    near = lambda p: inside(contour, p) or math.dist(contour_location(contour, p)[1], p) < .05
    try:
        if s.get('is_notch'):
            strokes = parts(s) if s.get('components') else [s]
            return near(path(strokes[0])[0][0])
        pts = path(s)[0]
    except (ValueError, KeyError, TypeError, IndexError):
        return False
    return bool(pts) and all(near(q) for q in pts)


def second_step(items):
    """0.18.1 « Surcoupe (2e étape) »: the pieces to recut as pieces in Coupe externe, each with
    the name and material of its précoupe, its crans and its inner lines, where they are on the
    plan. Only what the cutting machine needs: ready for export_dxf / export_dwg."""
    from craft_tools import PROFILES, style
    from entity_rules import fabrication_ids, closed_piece, piece_labels
    out = []
    precuts = [i for i, s in enumerate(items) if is_precut(s) and closed_piece(s) and style(s)['role'] == 'external']
    for i in precuts:
        owner = items[i].get('piece_id')
        labels = piece_labels(items, i)
        inners = inner_contours(items, i)
        owned = [j for j, s in enumerate(items) if j != i and j not in inners and s.get('owner_id') == owner
                 and not (s.get('identification') or s.get('preparation') or s.get('piece_badge'))]
        names = [j for kind in ('part_name', 'material') for j in labels.get(kind, [])[:1]]
        # The name and material sit in one of the pieces: each recut piece gets them at the same
        # place in itself.
        from geometry import bounds
        from precision_geometry import inside
        def holds(k):
            return any(inside(items[k], (items[j]['x'], items[j]['y'])) for j in names)
        holder = next((k for k in inners if holds(k)), inners[0] if inners else None)
        for k in inners:
            new = uuid.uuid4().hex
            piece = copy.deepcopy(items[k])
            piece.pop('owner_id', None)
            piece['profile'] = 'Coupe extérieure'
            piece['style'] = dict(PROFILES['Coupe extérieure'])
            piece['piece_id'] = new
            group = [piece]
            a, b = bounds([items[holder]])[:2]
            x, y = bounds([items[k]])[:2]
            for j in names:
                q = moved(items[j], x - a, y - b)
                q['owner_id'] = new
                group.append(q)
            for j in owned:
                if _on_or_in(items[k], items[j]):
                    q = copy.deepcopy(items[j])
                    q['owner_id'] = new
                    group.append(q)
            out += group
    if not out:
        return []
    return [out[k] for k in fabrication_ids(out)]
