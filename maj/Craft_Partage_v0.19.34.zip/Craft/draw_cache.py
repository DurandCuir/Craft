"""0.18.7: a drawing of the plan keeps what did not change (a click, Supprimer, Annuler, a change of
one object…).

Every object of the plan is drawn as one group of canvas items, tagged « _obj » and « _obj:<n> »,
starting with a hidden anchor (its place in the stacking order). The next drawing keeps the groups
whose object and selection are the same (the key) and draws only the others; each new group is put
just under the anchor of the group that follows it, so the stacking order is that of a full drawing
(the list of objects). Anything else the drawing of an object depends on (the view, the size of the
plan, the colours, the preferences, the line profiles…) is the drawing's context, given by the
application (``draw_context``): another context, or no context (a sheet shown instead of the plan),
draws everything again, as does a canvas emptied or moved by someone else (the number of kept items
and a hidden sentinel are checked) or a change of most of what was drawn.

Dashes (dash_lines) share a budget per drawing, spent in the order of the objects: a kept group
counts what it spent, a new one draws with the count a full drawing would have reached, and a kept
group whose dashes would come out otherwise (the budget reached before it, or not any more) is drawn
again.

0.19.33 (« c'est le but d'avoir un logiciel fluide »): a group whose object only changed its selection is not drawn
again when this drawing's context already drew the object in its new state: the items of the group are recorded as
they are made (kind, coordinates, options, tags), each state of an object kept as a pattern (``library``), and the
group's items take the options of the pattern in place (``craft_restyle``: one call of Tk), when the pattern has the
same items, coordinates and tags (and neither has dashes). A selection on DIFORME: 100 ms drawn again, 5 ms in
place."""
import marshal

TAG = '_obj'
UNDER = '_obj_under'
ANCHOR = '_obj_anchor'
SENTINEL = '_obj_sentinel'
# Items of a group that the drawing then moves to the bottom or the top of the canvas
# (preparation_ui.lower_fills, finish_ui: spline grips): among them, the order of the objects too.
DISPLACED = ('prep_fill', 'spline_grips')
REUSE_AT_LEAST = .5   # fewer of the objects drawn last time kept than this: everything is drawn again (quicker)
HOOKED = ('itemconfigure', 'itemconfig', 'dtag', 'addtag_withtag', 'delete', 'coords', 'move', 'scale',
          'tag_raise', 'lift', 'tkraise', 'tag_lower', 'lower')   # 0.19.33 (review: a group's items restacked: no pattern)

def fast_create(canvas):
    """0.19.21 (optimisation): the plan's items created with their options handed to Tcl as they are (numbers,
    texts, lists of tags or dashes): tkinter's own way spelled each option out as text first (_options,
    _stringify), a third of a full drawing of DIFORME. A callback or the old dict form: tkinter's way."""
    from tkinter import _flatten
    try:
        slow = canvas._create
        call, getint, name = canvas.tk.call, canvas.tk.getint, canvas._w
    except AttributeError:
        return   # not a Tk canvas (a stand-in): tkinter's way

    def create(kind, args, kw):
        args = _flatten(args)
        if not kw or args and isinstance(args[-1], (dict, tuple)):
            return slow(kind, args, kw)
        options = []
        for key, value in kw.items():
            if value is None:
                continue
            if callable(value):
                return slow(kind, args, kw)
            options.append('-' + (key[:-1] if key[-1] == '_' else key))
            options.append(value)
        return getint(call(name, 'create', kind, *args, *options))
    canvas._create = create


_PROCS = r'''proc craft_raise_groups {c tags} {foreach t $tags {$c raise $t}}
proc craft_restyle {c changes} {foreach {i o} $changes {$c itemconfigure $i {*}$o}}
proc craft_lower_groups {c pairs} {foreach {t a} $pairs {$c lower $t $a}}
proc craft_delete_groups {c tags} {foreach t $tags {$c delete $t}}
proc craft_count {c tag} {llength [$c find withtag $tag]}'''


def smoothed(kind, options, tags):
    """(review) An item that the smoothing draws (display_render.craft_canvas_meta): a line or a polygon, every tag of it
    among those it smooths (a grip: no)."""
    if kind not in ('line', 'polygon') or options.get('stipple') or options.get('arrow', 'none') != 'none':
        return False
    if options.get('smooth') not in (None, 0, False, '0', 'false', ''):
        return False
    if not _SMOOTH_TAGS:
        _SMOOTH_TAGS.append(__import__('display_render')._ALLOWED)
    allowed = _SMOOTH_TAGS[0]
    return all(t in allowed or t.startswith(('zoom:', '_obj')) or t == 'current' for t in tags)


_SMOOTH_TAGS = []


def content(s):
    """The object as bytes (equal bytes: the same object); None: drawn again at every drawing."""
    try:
        return marshal.dumps(s, 2)
    except ValueError:
        return None


class Drawing:
    """The groups made by one drawing of the plan, kept on the canvas for the next one."""

    def __init__(self, app, context, contents, previous=None):
        self.app = app
        self.canvas = app.canvas
        self.context = context
        self.contents = contents
        self.previous = previous
        self.groups = {}        # key -> [tag, ...] in stacking order
        self.position = {}      # tag -> position in this drawing
        self.anchors = {}       # tag -> id of its anchor item
        self.dashes = {}        # tag -> (dashes counted before it, dashes it made, a dash left to Tk)
        self.displaced = {}     # tag -> the DISPLACED tags among its items
        self.boxes = {}         # content -> bounds (plan mm)
        self.sequence = []
        self.fresh = set()
        self.serial = previous.serial if previous else 0
        self.waiting = {k: list(v) for k, v in previous.groups.items()} if previous else {}
        self.ordering = None    # how the stacking order was made again (for the tests)
        self.used = None
        self.current = None
        self.kept = self.drawn = 0
        # 0.19.33: the items of each group as made (tag -> [(id, kind, coordinates, options, tags)]), the patterns of the
        # objects' states drawn in this context (key -> (items without ids, dashes made, a dash left, displaced tags)),
        # the changes of options of the groups switched in place, and the content of each group
        self.scripts = {}
        self.library = previous.library if previous else {}
        self.restyle = []
        self.switched = 0
        self.reshaped = 0   # (review) items the smoothing draws changed, made or deleted in switched groups
        self.version = app.__dict__.get('_doc_version')   # (review) the refresh it was drawn for (craft_workbench.paint_color_picker)
        self.recording = None
        self.data_of = {}
        self.same_geometry = False
        self.picture_current = False   # (review) the smoothed picture shown was made from the previous drawing (none older)
        self.failed = False
        self.by_data = {}
        for key in self.waiting:
            self.by_data.setdefault(key[0], []).append(key)
        items = app.items
        n = len(items)
        selected = app.selected
        ids = app.selected_ids() if hasattr(app, 'selected_ids') else ([selected] if selected is not None else [])
        # How each layer knows that an object is selected (by identity, as they do).
        self.first = id(items[selected]) if isinstance(selected, int) and 0 <= selected < n else None
        self.picked = {id(items[i]) for i in (app.__dict__.get('selected_set') or ()) if isinstance(i, int) and 0 <= i < n}
        self.chosen = {id(items[i]) for i in ids if isinstance(i, int) and 0 <= i < n}
        # The objects being translated are drawn for their quick moves (tag « moving », moved where
        # they are): drawn at every drawing, never kept.
        self.moving = app.__dict__.get('_capture_ids') or ()
        # 0.19.33: grips shown or not (GRIP_LIMIT) changes the drawing of the selected objects only: in their key (it was
        # in the drawing's context: a selection past 100 objects drew the whole plan again, and so did Échap after it)
        try:
            self.grips = bool(app.grips_shown()) if hasattr(app, 'grips_shown') else None
        except Exception:
            self.grips = None

    def key(self, i, s, data):
        if data is None or id(s) in self.moving:
            return None
        sid = id(s)
        flags = (i == self.app.selected, sid == self.first, sid in self.picked, sid in self.chosen)
        return (data,) + flags + ((self.grips if any(flags) else None),)

    def bounds(self, i, s, measure):
        data = self.contents[i]
        if data is None:
            return measure(s)
        box = self.previous.boxes.get(data) if self.previous else None
        if box is None:
            box = measure(s)
        self.boxes[data] = box
        return box

    # Every item drawn for an object gets the tags of its group (also the pieces of a dashed line
    # or of a clipped curve: the tags go down with the creation).
    def install(self):
        c = self.canvas
        self.restore = c.__dict__.get('_create')
        original = c._create
        self.original_create = original

        def create(kind, args, kw, original=original):
            tags = self.current
            if tags is not None:
                given = kw or {}
                kw = dict(given)
                existing = kw.get('tags', ())
                existing = (existing,) if isinstance(existing, str) else tuple(existing or ())
                kw['tags'] = existing + tags
                moved = [t for t in DISPLACED if t in existing]
                if moved and len(tags) == 2:
                    self.displaced.setdefault(tags[1], set()).update(moved)
                item = original(kind, args, kw)
                record = self.recording
                if record is not None and record is not False:
                    if any(isinstance(a, dict) for a in args) or not isinstance(item, int):
                        self.recording = False   # options given another way: no pattern for this group
                    else:
                        record.append([item, kind, args, {k: v for k, v in given.items() if k != 'tags' and v is not None}, existing])   # (review: None given to Tk: no option, as tkinter)
                return item
            return original(kind, args, kw)
        c._create = create
        # 0.19.33: what the drawing of a group changes in its items once made (advanced_ui.light_selected: the selection's
        # colour, the « lit » tag taken off) goes into its record; anything else done to them: no pattern for the group
        self.hooked = {name: c.__dict__.get(name) for name in HOOKED}

        def targets(record, which):
            if isinstance(which, int) or (isinstance(which, str) and which.isdigit()):
                n = int(which)
                found = [r for r in record if r[0] == n]
                return found if found else None
            return [r for r in record if which in r[4]]

        def changing(name, real):
            def hook(*a, **k):
                record = self.recording
                if record:
                    try:
                        if not self.noted(record, name, a, k, targets):
                            self.recording = False
                    except Exception:
                        self.recording = False
                return real(*a, **k)
            return hook
        for name in HOOKED:
            setattr(c, name, changing(name, getattr(c, name)))

    def noted(self, record, name, a, k, targets):
        """A change of the items of the group being drawn, written into its record; False: not one it can follow."""
        if name in ('itemconfigure', 'itemconfig'):
            which = a[0] if a else k.get('tagOrId')
            cnf = a[1] if len(a) > 1 else None
            if cnf is not None and not isinstance(cnf, dict):
                return False
            options = dict(cnf or {}, **{n: v for n, v in k.items() if n != 'tagOrId'})
            if not options:
                return True   # a reading
            found = targets(record, which)
            if found is None:
                return True   # not an item of this group
            for r in found:
                for n, v in options.items():
                    if v is None:
                        continue   # (review) tkinter gives Tk nothing for it
                    if n == 'tags':
                        r[4] = (v,) if isinstance(v, str) else tuple(v or ())
                    else:
                        r[3][n] = v
            return True
        if name == 'dtag':
            which = a[0] if a else None
            gone = a[1] if len(a) > 1 else which
            found = targets(record, which)
            for r in found or ():
                r[4] = tuple(t for t in r[4] if t != gone)
            return True
        if name == 'addtag_withtag':
            new, which = a[0], a[1]
            for r in targets(record, which) or ():
                if new not in r[4]:
                    r[4] = r[4] + (new,)
            return True
        if name == 'delete':
            for which in a:
                found = targets(record, which)
                if found:
                    for r in found:
                        record.remove(r)
            return True
        if name == 'coords':
            if len(a) <= 1:
                return True   # a reading
            return not targets(record, a[0])
        # move, scale, tag_raise / lower… of an item of the group: not followed
        found = targets(record, a[0]) if a else None
        return not found

    def uninstall(self):
        c = self.canvas
        if self.restore is None:
            c.__dict__.pop('_create', None)
        else:
            c._create = self.restore
        for name, before in getattr(self, 'hooked', {}).items():
            if before is None:
                c.__dict__.pop(name, None)
            else:
                setattr(c, name, before)
        self.hooked = {}

    def under(self, start):
        """What is drawn before the objects (grid, guides) goes under the kept groups."""
        if self.previous is None:
            return
        if start:
            self.current = (UNDER,)
        else:
            self.current = None
            c = self.canvas
            c.tag_lower(UNDER)
            c.dtag(UNDER, UNDER)
            c.tag_lower('_smooth_display')   # the picture kept until the smoothing stays under all

    def reusable(self, tag):
        """A kept group comes out as a new drawing would draw it (its dashes, against the budget)."""
        start, spent, left = self.previous.dashes.get(tag, (0, 0, False))
        if not spent and not left:
            return True
        from dash_lines import BUDGET
        return self.used == start or (not left and self.used + spent <= BUDGET)

    def draw(self, i, s, color, width):
        c = self.canvas
        if self.used is None:
            self.used = c.__dict__.get('_dash_used', 0)
        data = self.contents[i]
        key = self.key(i, s, data)
        waiting = self.waiting.get(key) if key is not None else None
        tag = None
        if waiting:
            candidate = waiting[0]
            if self.reusable(candidate):
                tag = waiting.pop(0)
                _, spent, left = self.previous.dashes.get(tag, (0, 0, False))
                self.dashes[tag] = (self.used, spent, left)
                self.used += spent
                self.anchors[tag] = self.previous.anchors[tag]
                if tag in self.previous.displaced:
                    self.displaced[tag] = self.previous.displaced[tag]
                self.kept += 1
                script = self.previous.scripts.get(tag)
                if script is not None:
                    self.scripts[tag] = script
        if tag is None and key is not None:
            tag = self.switch(key, data)
        if tag is None:
            self.serial += 1
            tag = f'{TAG}:{self.serial}'
            c._dash_used = self.used   # the dashes a full drawing would have made before this object
            left = c.__dict__.get('_dash_left', 0)
            self.current = (TAG, tag)
            # (review) past 80 px/mm deep_zoom makes several items of one line (its runs in the clip box) or other kinds (a
            # circle as lines): the record would hold its first item only, a switch restyled only that one
            self.recording = False if c.__dict__.get('_deep_zoom') else []
            try:
                self.anchors[tag] = c.create_image(0, 0, state='hidden', tags=ANCHOR)   # its place in the stacking order
                self.app.draw_shape(s, color, width)
            finally:
                self.current = None
                record, self.recording = self.recording, None
            spent = c.__dict__.get('_dash_used', 0) - self.used
            made_left = c.__dict__.get('_dash_left', 0) > left
            self.dashes[tag] = (self.used, spent, made_left)
            self.used += spent
            self.fresh.add(tag)
            self.drawn += 1
            if record:
                record = [tuple(r) for r in record]
                self.scripts[tag] = record
                if key is not None:
                    self.library[key] = (tuple(r[1:] for r in record), spent, made_left, frozenset(self.displaced.get(tag, ())))
        self.data_of[tag] = data
        if key is not None:
            self.groups.setdefault(key, []).append(tag)
        self.position[tag] = len(self.sequence)
        self.sequence.append(tag)

    def switch(self, key, data):
        """0.19.33: the group of this object in another selection state, its items given the options of the pattern of
        ``key`` in place (no drawing); None when there is no such group or pattern, or they do not match."""
        pattern = self.library.get(key)
        if pattern is None or self.previous is None:
            return None
        items, spent, left, displaced = pattern
        if spent or left:
            return None
        for other in self.by_data.get(data, ()):
            if other == key:
                continue
            waiting = self.waiting.get(other)
            if not waiting:
                continue
            tag = waiting[0]
            script = self.previous.scripts.get(tag)
            before = self.previous.dashes.get(tag, (0, 0, False))
            if script is None or not script or not items or before[1] or before[2]:
                continue
            if frozenset(self.previous.displaced.get(tag, ())) != displaced:
                continue
            common = min(len(script), len(items))
            changes = []
            for (item, kind, args, options, tags), (kind2, args2, options2, tags2) in zip(script[:common], items[:common]):
                if kind != kind2 or tags != tags2 or args != args2 or options.keys() != options2.keys():
                    break
                diff = []
                for name, value in options2.items():
                    if options[name] != value:
                        diff += ['-' + (name[:-1] if name[-1] == '_' else name), value]
                if diff:
                    changes.append((item, diff, smoothed(kind, options2, tags)))
            else:
                # the same items but at the end: those of the new state made (a text's dashed frame, just above the
                # group's last item, as a drawing makes it), those of the old one deleted
                kept_ids = [r[0] for r in script[:common]]
                made = []
                try:
                    last = kept_ids[-1]
                    for kind2, args2, options2, tags2 in items[common:]:
                        item = self.original_create(kind2, args2, dict(options2, tags=tuple(tags2) + (TAG, tag)))
                        self.canvas.tk.call(self.canvas._w, 'raise', item, last)
                        made.append(item)
                        last = item
                except Exception:
                    for item in made:
                        self.canvas.delete(item)
                    continue
                gone = [r[0] for r in script[common:]]
                if gone:
                    self.canvas.delete(*gone)
                self.reshaped += sum(smoothed(*new[:1], *new[2:]) for new in items[common:])
                self.reshaped += sum(smoothed(r[1], r[3], r[4]) for r in script[common:])
                self.reshaped += sum(smooth for _, _, smooth in changes)
                waiting.pop(0)
                self.anchors[tag] = self.previous.anchors[tag]
                if tag in self.previous.displaced:
                    self.displaced[tag] = self.previous.displaced[tag]
                self.dashes[tag] = (self.used, 0, False)
                self.scripts[tag] = [(i,) + new for i, new in zip(kept_ids + made, items)]
                for item, diff, _ in changes:
                    self.restyle += [item, diff]
                self.switched += 1
                return tag
        return None

    def order(self):
        """The new groups (drawn on top) go just under the anchor of the group after them, from the
        last one back; the kept ones are still in the order of the previous drawing. Kept groups in
        another order (the list of objects reordered), or more new groups than groups after the first
        new one: every group from there on is raised in order, as a full drawing stacks them."""
        c = self.canvas
        previous = self.previous.position
        highest, broken, last_kept = -1, None, -1
        for k, tag in enumerate(self.sequence):
            if tag in self.fresh:
                continue
            last_kept = k
            if broken is None:
                if previous[tag] < highest:
                    broken = k
                highest = max(highest, previous[tag])
        first = next((k for k, tag in enumerate(self.sequence) if tag in self.fresh), None)
        if broken is not None:
            start = broken if first is None else min(broken, first)
            c.tk.call('craft_raise_groups', c._w, self.sequence[start:])
            self.ordering = 'raise'
            return
        if first is None or first > last_kept:
            return   # nothing new, or only after every kept group: on top already, in order
        moves = []
        for k in range(last_kept - 1, first - 1, -1):
            tag = self.sequence[k]
            if tag in self.fresh:
                moves += [tag, self.anchors[self.sequence[k + 1]]]
        if len(moves) // 2 <= len(self.sequence) - first:
            c.tk.call('craft_lower_groups', c._w, moves)
            self.ordering = 'lower'
        else:
            c.tk.call('craft_raise_groups', c._w, self.sequence[first:])
            self.ordering = 'raise'

    def restack(self):
        """The items of new groups that the drawing moves to the bottom or the top (DISPLACED) are put
        among those of the other groups in the order of the objects (just under those of the next
        group, or above those of the one before)."""
        c = self.canvas
        for moved in DISPLACED:
            having = [tag for tag in self.sequence if moved in self.displaced.get(tag, ())]
            if len(having) < 2 or not any(tag in self.fresh for tag in having):
                continue
            for k in range(len(having) - 1, -1, -1):
                tag = having[k]
                if tag not in self.fresh:
                    continue
                if k + 1 < len(having):
                    c.tk.call(c._w, 'lower', f'{tag}&&{moved}', f'{having[k + 1]}&&{moved}')
                else:
                    c.tk.call(c._w, 'raise', f'{tag}&&{moved}', f'{having[k - 1]}&&{moved}')

    def finish(self):
        """The groups no longer drawn go; the others take the stacking order of the objects."""
        c = self.canvas
        if self.used is not None:
            c._dash_used = self.used   # what is drawn after the objects counts as in a full drawing
        if self.restyle:
            try:
                c.tk.call('craft_restyle', c._w, self.restyle)
            except Exception:   # (review) an option of a pattern Tk refused: the plan drawn again in full (end)
                self.failed = True
            __import__('display_render').forget_items(c, self.restyle[::2])   # their rows read again by the smoothing
        if self.previous is not None:
            gone = [tag for tag in self.previous.sequence if tag not in self.position]
            if gone:
                c.tk.call('craft_delete_groups', c._w, gone)
            self.order()
            self.restack()
            # the same objects as the last drawing (a selection changed): their smoothing may come in the background
            mine = [self.data_of.get(t) for t in self.sequence]
            theirs = [self.previous.data_of.get(t) for t in self.previous.sequence]
            self.same_geometry = None not in mine and None not in theirs and sorted(mine) == sorted(theirs)
        if self.library:
            alive = set(self.contents)
            self.library = {k: v for k, v in self.library.items() if k[0] in alive}
        self.count = int(c.tk.call('craft_count', c._w, TAG))
        self.sentinel = c.create_text(0, 0, text='', state='hidden', tags=SENTINEL)
        self.previous = None   # no chain of drawings in memory

    def changed_items(self):
        """(review) How many items the smoothing draws this drawing changed in the kept groups (options, made, deleted) and
        how many groups it drew: a selection shown by grips alone changes none of them (nothing to make again)."""
        return self.reshaped + self.drawn

    def intact(self):
        """The canvas holds the groups as this drawing left them (not emptied, moved nor zoomed)."""
        c = self.canvas
        try:
            return tuple(c.coords(self.sentinel)) == (0.0, 0.0) and int(c.tk.call('craft_count', c._w, TAG)) == self.count
        except Exception:
            return False


def forget(canvas):
    canvas.__dict__.pop('_draw_cache', None)


def begin(app):
    """Start a drawing of the plan: the canvas emptied, or emptied of all but the groups that may be
    kept. Returns the Drawing (None: nothing is kept, now nor for the next drawing)."""
    c = app.canvas
    last = c.__dict__.pop('_draw_cache', None)
    try:
        context = app.draw_context() if hasattr(app, 'draw_context') else None
    except Exception:
        context = None
    drawing = None
    if context is not None:
        if not c.tk.call('info', 'procs', 'craft_count'):
            c.tk.eval(_PROCS)
        contents = [content(s) for s in app.items]
        if last is not None and last.context == context and last.intact():
            drawing = Drawing(app, context, contents, last)
            # Kept only if most of what was drawn stays (the rest may be off the screen): a window
            # selection of the whole plan, a document changed… are quicker drawn whole.
            left = {k: len(v) for k, v in last.groups.items()}
            same = 0
            other = []
            for i, (s, data) in enumerate(zip(app.items, contents)):
                key = drawing.key(i, s, data)
                if key is not None and left.get(key, 0) > 0:
                    left[key] -= 1
                    same += 1
                elif key is not None and key in last.library:
                    other.append((key, data))
            if other:   # 0.19.33: groups of another selection state whose pattern is known: switched in place, kept
                spare = {}
                for k, n in left.items():
                    if n > 0:
                        spare[k[0]] = spare.get(k[0], 0) + n
                for key, data in other:
                    if spare.get(data, 0) > 0:
                        spare[data] -= 1
                        same += 1
            if not same or same < REUSE_AT_LEAST * len(last.sequence):
                drawing = None
        if drawing is None:
            drawing = Drawing(app, context, contents)
            if last is not None and last.context == context:
                drawing.library = last.library   # 0.19.33: the patterns of the objects' states stay right in the same context
    if drawing is not None and drawing.previous is not None:
        c.addtag_all('_stale')
        c.dtag(TAG, '_stale')
        smoothing = bool(app.__dict__.get('_smooth_idle') or app.__dict__.get('_keep_picture')) and bool(c.find_withtag('_smooth_display'))   # (0.19.30: full_settle)
        if smoothing:
            # The smoothing comes before Tk shows anything: it makes the picture again (only its
            # changed part) and hides the new lines; until then the old picture and the hidden kept
            # lines stay, the picture marked as stale (a move of the view coming first does not
            # carry it: keep_picture; a zoom shows the lines: show_raw).
            c.dtag('_smooth_display', '_stale')
            drawing.picture_current = not c.__dict__.get('_smooth_stale')   # (review: advanced_ui.selection_soon)
            c._smooth_stale = True
        c.delete('_stale')
        if not smoothing:
            hidden = c.__dict__.pop('_smooth_hidden', None)
            if hidden:
                c.tk.call('craft_show', c._w, hidden)
    elif app.__dict__.get('_keep_picture') and c.find_withtag('_smooth_display'):
        # 0.19.30 (full_settle): all goes but the smoothed picture, shown until its new one is made in the background
        c.addtag_all('_stale')
        c.dtag('_smooth_display', '_stale')
        c.delete('_stale')
        c.__dict__.pop('_smooth_hidden', None)
        c._smooth_stale = True
        __import__('display_render').forget_rows(c)
    else:
        c.delete('all')
        c.__dict__.pop('_smooth_hidden', None)
        c.__dict__.pop('_smooth_stale', None)
        __import__('display_render').forget_rows(c)
    if drawing is not None:
        drawing.install()
    return drawing


def abandon(app, drawing):
    """The drawing stopped on an error: nothing is kept (the next one empties the canvas)."""
    if drawing is not None:
        drawing.current = None
        drawing.uninstall()
    app.canvas.__dict__.pop('_draw_cache', None)


def end(app, drawing):
    """The drawing of the objects is over (the rest of the plan's drawing comes after)."""
    if drawing is None:
        return
    drawing.uninstall()
    drawing.finish()
    if drawing.failed:   # (review) nothing kept: drawn again in full as soon as Tk is idle
        app.canvas.__dict__.pop('_draw_cache', None)
        try:
            app.after_idle(app.redraw)
        except Exception:
            pass
        return
    app.canvas._draw_cache = drawing
