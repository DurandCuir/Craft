"""0.19.39 « Teinte des bords » (« bien ajoute », 17/11/2026: the teinte in one click, proposed with 0.19.36).

A click on a side of a piece (Coupe externe, or a piece inside its précoupe) dyes it: a line of the « Préparation » type
``distance`` mm outside the side (3 mm: his RIDER, « lignes décalées de 3 mm à l'extérieur du bord teint ») and the zone
Teinte between the side and that line (« pas la pièce entière »), both attached to the piece (they move, turn, are copied
and are hidden with it). Each click adds a side: sides that follow one another make one band (its line mitred round their
corners as Décaler makes it, its ends square to the side); a click on a side already dyed takes it off; a double-click
dyes the whole piece round (one closed line). Another distance typed + Entrée (2 for Mozart's), right click: distance and
couches. The zone keeps the sides it dyes (``sides``, ``count``: how many sides the piece had then) and its line the same
``band`` as the zone: only those bands are joined, taken off and follow the piece reshaped (refit); a side under a zone
made otherwise (by hand, from Mozart) is said, never dyed twice."""
import math
import uuid
import copy
import tkinter as tk
from tkinter import messagebox

import preparations as prep

DEFAULTS = dict(distance=3., couches=1)
TAG = 'teinte_preview'
GEOMETRY = ('kind', 'x', 'y', 'w', 'h', 'r', 'points', 'closed', 'bulges', 'components', 'spline', 'ellipse', 'reversed')
PROBE = .05   # mm: a point just off a side, to know its outside


def settings(app):
    saved = (getattr(app, 'prefs', None) or {}).get('teinte_bords')
    out = dict(DEFAULTS)
    if isinstance(saved, dict):
        try:
            d = float(saved.get('distance', out['distance']))
            if math.isfinite(d) and .1 <= d <= 50:
                out['distance'] = d
        except (TypeError, ValueError):
            pass
        c = saved.get('couches')
        if isinstance(c, int) and not isinstance(c, bool) and 1 <= c <= 20:
            out['couches'] = c
    return out


def keep(app, **changes):
    st = settings(app)
    st.update(changes)
    app.prefs['teinte_bords'] = st
    try:
        app.persist_preferences()
    except OSError:
        pass


def fmt(v):
    return f'{v:.2f}'.rstrip('0').rstrip('.').replace('.', ',')


# ---------------------------------------------------------------- the geometry

def sides(piece):
    from assembly_ui import sides as cut
    return cut(piece)


def owner(app, k, make=False):
    """The piece id the bands of contour ``k`` are attached to: its own; a piece inside its précoupe (no id of its own):
    the précoupe's, which carries its data (assembly_ui.host), as the Préparation tool attaches its zones."""
    s = app.items[k]
    if s.get('piece_id') or not s.get('owner_id'):
        if make:
            from entity_rules import ensure_piece_id
            return ensure_piece_id(s)
        return s.get('piece_id')
    return s['owner_id']


def _halfway(pts):
    """The point half way along a run of points and the direction of the run there."""
    half = sum(math.dist(a, b) for a, b in zip(pts, pts[1:])) / 2
    for a, b in zip(pts, pts[1:]):
        L = math.dist(a, b)
        if L >= half and L > 1e-12:
            t = half / L
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t), ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
        half -= L
    a, b = pts[-2], pts[-1]
    L = math.dist(a, b) or 1.
    return b, ((b[0] - a[0]) / L, (b[1] - a[1]) / L)


def outward(piece, run):
    """(the middle of a side, the unit normal pointing out of the piece there)."""
    from precision_geometry import inside
    m, (ux, uy) = _halfway(run)
    n = (-uy, ux)
    if inside(piece, (m[0] + n[0] * PROBE, m[1] + n[1] * PROBE)):
        n = (uy, -ux)
    return m, n


def groups(ids, n):
    """The sides ``ids`` cut into runs that follow one another (round the closing corner too)."""
    ids = sorted({i for i in ids if 0 <= i < n})
    if len(ids) == n:
        return [list(range(n))] if n else []
    out = []
    for i in ids:
        if out and i == out[-1][-1] + 1:
            out[-1].append(i)
        else:
            out.append([i])
    if len(out) > 1 and out[0][0] == 0 and out[-1][-1] == n - 1:
        out[0] = out.pop() + out[0]
    return out


def bare(q, name):
    """A new line from what an offset gave: only its geometry (never the piece's id, its piqûre, its names…)."""
    from geometry import path
    from cad import polygon
    if q.get('components') or q.get('spline'):
        pts, closed = path(q)
        return polygon(pts, name, closed)
    out = {k: copy.deepcopy(q[k]) for k in GEOMETRY if k in q}
    out['name'] = name
    return out


def _clear(piece, line):
    """No part of the line inside the piece (a band that would cut it: a slot narrower than the teinte, an end going
    back over the piece)."""
    from geometry import path
    pts, closed = path(line)
    tests = list(pts) + [((a[0] + b[0]) / 2, (a[1] + b[1]) / 2) for a, b in zip(pts, pts[1:] + (pts[:1] if closed else []))]
    for q in tests:
        if _in(piece, q):
            raise ValueError('La teinte couperait la pièce ici : réduire la distance.')


def _in(piece, q):
    """``q`` inside the piece, not on its contour."""
    from precision_geometry import inside, contour_location
    return inside(piece, q) and math.dist(contour_location(piece, q)[1], q) > 1e-3


def _crossings(piece, pts):
    """The points where the run of points ``pts`` crosses the piece's contour, in their order along it."""
    from geometry import path
    ring = list(path(piece)[0])
    edges = list(zip(ring, ring[1:] + ring[:1]))
    out = []
    travel = 0.
    for p, q in zip(pts, pts[1:]):
        L = math.dist(p, q)
        if L < 1e-12:
            continue
        x0, x1, y0, y1 = min(p[0], q[0]) - 1e-9, max(p[0], q[0]) + 1e-9, min(p[1], q[1]) - 1e-9, max(p[1], q[1]) + 1e-9
        rx, ry = q[0] - p[0], q[1] - p[1]
        for e, f in edges:
            if max(e[0], f[0]) < x0 or min(e[0], f[0]) > x1 or max(e[1], f[1]) < y0 or min(e[1], f[1]) > y1:
                continue
            sx, sy = f[0] - e[0], f[1] - e[1]
            den = rx * sy - ry * sx
            if abs(den) < 1e-15:
                continue
            t = ((e[0] - p[0]) * sy - (e[1] - p[1]) * sx) / den
            u = ((e[0] - p[0]) * ry - (e[1] - p[1]) * rx) / den
            if -1e-12 <= t <= 1 + 1e-12 and -1e-12 <= u <= 1 + 1e-12:
                out.append((travel + t * L, (p[0] + t * rx, p[1] + t * ry)))
        travel += L
    return [q for _, q in sorted(out)]


def _stopped(piece, line, part, a, b):
    """0.19.40 (an acute inside corner, a V notch: the end of the band square to its side went into the piece at any
    distance, neither side could be dyed alone and « réduire la distance » never helped): an end of the line inside the
    piece stops where the line meets the piece (the next side); the band goes along that side back to the corner.
    (line, the region's ring) or ValueError."""
    from geometry import path
    from precision_geometry import contour_location, contour_length, contour_slice
    pts = list(path(line)[0])
    if len(pts) < 2 or not (_in(piece, pts[0]) or _in(piece, pts[-1])):
        raise ValueError('La teinte couperait la pièce ici : réduire la distance.')
    total = contour_length(piece)
    L = contour_length(line)
    t0, t1, before, after = 0., L, [], []
    crossings = _crossings(piece, pts)   # (an end inside: the line meets the contour between it and the rest)
    if not crossings:
        raise ValueError('Ce côté ne peut pas être teinté.')
    if _in(piece, pts[0]):
        x = crossings[0]
        t0 = contour_location(line, x)[0]
        at = contour_location(piece, x)[0]
        back = (a - at) % total   # along the contour from where the line stops to the corner
        if back > total / 2 or back < 1e-6:
            raise ValueError('La teinte couperait la pièce ici : réduire la distance.')
        after = list(reversed(path(contour_slice(piece, at, at + back))[0]))   # the corner → the line
    if _in(piece, pts[-1]):
        y = crossings[-1]
        t1 = contour_location(line, y)[0]
        at = contour_location(piece, y)[0]
        ahead = (at - b) % total
        if ahead > total / 2 or ahead < 1e-6:
            raise ValueError('La teinte couperait la pièce ici : réduire la distance.')
        before = list(reversed(path(contour_slice(piece, b, b + ahead))[0]))   # the line → the corner
    if t1 - t0 < 1e-6:
        raise ValueError('Ce côté ne peut pas être teinté.')
    cut = contour_slice(line, t0, t1)
    out = {k: copy.deepcopy(cut[k]) for k in GEOMETRY if k in cut}
    out['name'] = line.get('name', 'Teinte')
    _clear(piece, out)
    ring = list(path(out)[0]) + before + list(reversed(path(part)[0])) + after
    return out, ring


def _line_out(piece, base, d, closed):
    """The offset of ``base`` (a part of the piece's contour, or the whole of it) ``d`` mm out of the piece."""
    from precision_geometry import shifted, inside, contour_length
    from geometry import path
    if closed:
        q = shifted(base, d)   # (a closed contour: positive is outside)
        return bare(q, 'Teinte')
    m0, out = outward(piece, list(path(base)[0]))   # (review: toward the side's own outside; « its middle not inside » took
    last = None                                     # the offset inward when the piece is thinner than d there: TILTED's 2 mm sides)
    for sign in (1, -1):
        try:
            q = shifted(base, sign * d)
        except ValueError as exc:
            last = exc
            continue
        pts = path(q)[0]
        if len(pts) < 2:
            continue
        m, _ = _halfway(pts)
        if (m[0] - m0[0]) * out[0] + (m[1] - m0[1]) * out[1] > 0 and not inside(piece, m):
            return bare(q, 'Teinte')
    raise last or ValueError('Ce côté ne peut pas être teinté.')


def band(piece, run_ids, runs, d):
    """(line, region) of a band dyeing the sides ``run_ids`` (following one another) of ``piece``: the line ``d`` mm out
    of them, the region between them and it (regions.region_at's form: points, holes). ValueError: why not."""
    from geometry import path
    from precision_geometry import contour_location, contour_length, contour_slice
    n = len(runs)
    if len(run_ids) == n:
        line = _line_out(piece, piece, d, True)
        _clear(piece, line)
        return line, dict(points=list(path(line)[0]), holes=[list(path(piece)[0])])
    pts = []
    for j in run_ids:
        run = runs[j][0]
        pts += run if not pts else run[1:]
    total = contour_length(piece)
    a = contour_location(piece, pts[0])[0]
    b = contour_location(piece, pts[-1])[0]
    m = contour_location(piece, _halfway(pts)[0])[0]
    span = (b - a) % total
    if (m - a) % total > span + 1e-7:   # the contour drawn the other way round from its sides
        a, b = b, a
        span = (b - a) % total
    if span < 1e-6:
        raise ValueError('Côté trop court.')
    part = contour_slice(piece, a, a + span)
    line = _line_out(piece, part, d, False)
    try:
        _clear(piece, line)
    except ValueError as exc:
        try:
            line, ring = _stopped(piece, line, part, a, a + span)
        except ValueError:
            raise exc from None   # (a slot narrower than the teinte: « réduire la distance » helps there)
        return line, dict(points=ring, holes=[])
    ring = list(path(line)[0]) + list(reversed(path(part)[0]))
    return line, dict(points=ring, holes=[])


def build(piece, ids, d, couches, uid=None):
    """[(line, zone)] for the sides ``ids`` of ``piece`` at ``d`` mm (no piece attached yet)."""
    from craft_tools import PROFILES
    runs, total = sides(piece)
    n = len(runs)
    out = []
    for run_ids in groups(ids, n):
        line, region = band(piece, run_ids, runs, d)
        key = uid if uid and len(out) == 0 else uuid.uuid4().hex
        zone = prep.zone(region, dict(kind='teinte', type='', thickness=None, width=d, couches=couches,
                                      sides=list(run_ids), count=n, band=key))
        line['profile'] = 'Préparation'
        line['style'] = {k: copy.deepcopy(v) for k, v in PROFILES['Préparation'].items()}
        line['teinte_band'] = key
        out.append((line, zone))
    return out


def _zones(app, pid):
    """The tool's zones Teinte attached to ``pid`` (any piece's state): [(index, zone)]."""
    return [(j, s) for j, s in enumerate(app.items)
            if s.get('owner_id') == pid and isinstance(s.get('preparation'), dict)
            and s['preparation'].get('kind') == 'teinte' and s['preparation'].get('band')]


def _line_of(app, pid, key, zone=None):
    """(review: a piece dyed, then made a précoupe in series: each piece to recut has a copy of the band, the same id on the
    same précoupe; the second one's click took the first one's line) the line on ``zone``'s outline when several are."""
    found = [j for j, s in enumerate(app.items) if s.get('teinte_band') == key and s.get('owner_id') == pid]
    if len(found) > 1 and zone is not None:
        from geometry import path
        try:
            ring = prep.ring_points(zone)
            return min(found, key=lambda j: min(math.dist(path(app.items[j])[0][0], v) for v in ring))
        except (ValueError, KeyError, TypeError, IndexError):
            pass
    return found[0] if found else None


def bands(app, k):
    """The bands the tool made on contour ``k``, still with its sides (as many as when they were made, and round it: a
    précoupe holds several pieces): [dict(zone, line, sides, width, couches)]."""
    piece = app.items[k]
    pid = owner(app, k)
    if not pid:
        return []
    runs, total = sides(piece)
    n = len(runs)
    out = []
    for j, z in _zones(app, pid):
        p = z['preparation']
        if p.get('count') != n:
            continue
        ids = {v for v in p.get('sides') or () if isinstance(v, int) and not isinstance(v, bool) and 0 <= v < n}
        if not ids:
            continue
        try:
            width = float(p.get('width') or 0) or settings(app)['distance']
            m, nrm = outward(piece, runs[min(ids)][0])
            ring = prep.ring_points(z)
            # (0.19.40: a band stopped on the next side of an acute corner can be thinner than half its width there)
            if not any(prep.inside(ring, (m[0] + nrm[0] * t, m[1] + nrm[1] * t)) for t in (width / 2, 2 * PROBE)):
                continue
        except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
            continue
        couches = p.get('couches')
        couches = couches if isinstance(couches, int) and not isinstance(couches, bool) and couches >= 1 else 1
        out.append(dict(zone=j, line=_line_of(app, pid, p['band'], z), sides=ids, width=width, couches=couches))
    return out


def foreign(app, k, i, mine):
    """A zone Teinte on side ``i`` the tool did not make (by hand, from Mozart, a piece reshaped since): its index, or
    None. Looked for just out of the side and just in (Mozart dyes inside the piece)."""
    piece = app.items[k]
    runs, total = sides(piece)
    m, n = outward(piece, runs[i][0])
    probes = [(m[0] + n[0] * s, m[1] + n[1] * s) for s in (.5, -.5)]
    own = {b['zone'] for b in mine}
    for j, z in enumerate(app.items):
        p = z.get('preparation')
        if j in own or not isinstance(p, dict) or p.get('kind') != 'teinte':
            continue
        try:
            ring = prep.ring_points(z)
            if any(prep.inside(ring, q) for q in probes):
                return j
        except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
            continue
    return None


FOREIGN = 'Ce côté a déjà une teinte (faite autrement) : outil Préparation, clic dans la zone, Supprimer.'


def change(app, k, i=None, whole=False):
    """What a click on side ``i`` of contour ``k`` does (``whole``: a double-click, the whole piece round), nothing done:
    dict(k, remove=[indices], add=[(line, zone)], dyed=sides dyed after, bands). ValueError: said where one clicked."""
    piece = app.items[k]
    runs, total = sides(piece)
    n = len(runs)
    if not n:
        raise ValueError('Contour trop court.')
    st = settings(app)
    d = st['distance']
    mine = bands(app, k)
    holding = []
    if whole:
        affected = mine
        ids = set(range(n))
        width = d
        for j in range(n):
            if foreign(app, k, j, mine) is not None:
                raise ValueError(FOREIGN.replace('Ce côté a', 'Une partie du tour a'))
    else:
        holding = [b for b in mine if i in b['sides']]
        if holding:
            b = holding[0]
            affected = [b]
            ids = b['sides'] - {i}
            width = b['width']
        else:
            if foreign(app, k, i, mine) is not None:
                raise ValueError(FOREIGN)
            # (0.19.40: a band joined only at the distance and the couches set: with 2 couches set, a side next to a band
            # of 1 couche was added to it at 1 couche)
            near = [b for b in mine if abs(b['width'] - d) < 1e-6 and b['couches'] == st['couches']
                    and b['sides'] & {(i - 1) % n, (i + 1) % n}]
            affected = near
            ids = set().union(*[b['sides'] for b in near]) | {i}
            width = d
    # (0.19.40) a side taken off: its band keeps its couches; a side added or the whole round (at the distance set): the
    # couches set
    couches = holding[0]['couches'] if holding else st['couches']
    add = build(piece, ids, width, couches) if ids else []
    remove = sorted({b['zone'] for b in affected} | {b['line'] for b in affected if b['line'] is not None})
    kept = set().union(*[b['sides'] for b in mine if b not in affected]) if len(mine) > len(affected) else set()
    return dict(k=k, piece=piece, remove=remove, add=add, dyed=len(kept | ids), width=width)


def apply(app, plan):
    """The change made (one Annuler)."""
    app.snapshot()
    piece = plan['piece']
    k = next((j for j, s in enumerate(app.items) if s is piece), None)
    if k is None:
        return
    pid = owner(app, k, make=True)
    for j in sorted(plan['remove'], reverse=True):
        del app.items[j]
    for line, zone in plan['add']:
        line['owner_id'] = zone['owner_id'] = pid
        app.items.append(zone)
        app.items.append(line)
    app.selected = None
    app.selected_set = set()


def refit(app, pieces):
    """``pieces``: piece id → (the piece as it was, as it is now) (advanced_ui.refit_stitches: a grip, a raccord, Échelle):
    the tool's bands on them made again on the piece as it is, at their width, with their couches and ids: the same sides
    when the piece has as many, else the sides nearest those dyed. (In the Annuler step of the change.) How many."""
    import surcoupe
    from entity_rules import closed_piece
    done = 0
    for pid, (old, new) in pieces.items():
        if not pid or surcoupe.is_precut(old) or not closed_piece(new):
            # (review: a précoupe's id holds the bands of the pieces inside it, never bands of its own sides; as the Piqûres
            # (refit_stitches): Décomposer leaves lines with the piece's id, never a band on one)
            continue
        zones = _zones(app, pid)
        if not zones:
            continue
        try:
            before, _ = sides(old)
            after, _ = sides(new)
        except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
            continue
        n0, n1 = len(before), len(after)
        for j, z in zones:
            p = z['preparation']
            ids = [v for v in p.get('sides') or () if isinstance(v, int) and not isinstance(v, bool) and 0 <= v < n0]
            if p.get('count') != n0 or not ids or not n1:
                continue
            if n1 != n0:
                from assembly_ui import _gap
                mapped = []
                for v in ids:
                    m, _ = _halfway(before[v][0])
                    mapped.append(min(range(n1), key=lambda w: _gap(m, after[w][0])))
                # (review) the whole round stays whole, and a band keeps the sides a raccord puts between its own (a corner
                # chamfered: the band round it was left where it was, the whole round lost the new side)
                run = [(mapped[0] + t) % n1 for t in range((mapped[-1] - mapped[0]) % n1 + 1)]
                if len(ids) == n0:
                    ids = list(range(n1))
                elif set(mapped) <= set(run) and len(run) <= len(ids) + max(0, n1 - n0):
                    ids = run
                else:
                    ids = sorted(set(mapped))
            try:
                width = float(p.get('width') or 0)
                made = build(new, ids, width, p.get('couches') or 1, uid=p['band']) if width > 0 else []
            except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
                continue
            if len(made) != 1:
                continue   # (the sides no longer follow one another: left as it was)
            line, zone = made[0]
            line['owner_id'] = zone['owner_id'] = pid
            zone['preparation'] = dict(p, **{key: zone['preparation'][key] for key in ('sides', 'count', 'width')})
            zone['preparation']['band'] = p['band']
            line['teinte_band'] = p['band']
            at = _line_of(app, pid, p['band'], z)
            app.items[j] = zone
            if at is not None:
                kept = {key: copy.deepcopy(v) for key, v in app.items[at].items() if key not in GEOMETRY}
                kept.update({key: line[key] for key in GEOMETRY if key in line})
                for key in GEOMETRY:
                    if key not in line:
                        kept.pop(key, None)
                app.items[at] = kept
            else:
                app.items.append(line)
            done += 1
    return done


def drop_line(app, j):
    """0.19.39: a zone of the tool deleted (Préparation › Supprimer): its line with it. The index of the line, or None."""
    z = app.items[j]
    key = (z.get('preparation') or {}).get('band')
    return _line_of(app, z.get('owner_id'), key, z) if key and z.get('owner_id') else None


# ---------------------------------------------------------------- the tool

def reach(app):
    return 8 / max(app.scale, 1e-9)


def prompt(app, more=''):
    d = settings(app)['distance']
    app.status.set(f'Teinte des bords à {fmt(d)} mm : cliquer un côté (les côtés qui se suivent font une bande) · un côté teint : '
                   f'enlevé · double-clic : tout le tour · autre distance : la taper + Entrée.{more}')


def resume(app, more=''):
    app.tool.set('teinte_bord')
    app.last_command = ('tool', 'teinte_bord')
    app.teinte_state = dict(last=None)
    try:
        app.canvas.delete(TAG)
    except (AttributeError, tk.TclError):
        pass
    app.highlight_tools()
    prompt(app, more)


def start(app):
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    if not app.prefs.get('show_preparations', True):
        app.prefs['show_preparations'] = True   # one sees the bands one makes (they hide with the Préparations)
        try:
            app.persist_preferences()
        except OSError:
            pass
    resume(app)
    app.refresh()


def cancel(app):
    app.teinte_state = None
    try:
        app.canvas.delete(TAG)
    except (AttributeError, tk.TclError):
        pass


def _hit(app, e):
    from assembly_ui import side_at
    try:
        return side_at(app, app.raw(e), reach(app))
    except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
        return None


def words(plan):
    w = fmt(plan['width'])
    # 0.19.40 (« si les textes sont tous homogènes »): « … Échap pour finir. » as every tool in series (the status line
    # writes « · Échap pour finir »: a « · » before it was written twice)
    if not plan['dyed']:
        return 'Teinte enlevée de ce côté. Échap pour finir.'
    n = plan['dyed']
    return f'Teinte à {w} mm : {n} côté{"s" if n > 1 else ""} teint{"s" if n > 1 else ""} sur cette pièce. Échap pour finir.'


def act(app, e, whole=False):
    st = app.__dict__.get('teinte_state')
    if st is None:
        return 'break'
    hit = _hit(app, e)
    if hit is None:
        app.invalid_at(e, 'Cliquer le bord d’une pièce (Coupe externe).')
        return 'break'
    try:
        plan = change(app, hit[0], hit[1], whole)
    except ValueError as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    apply(app, plan)
    app.canvas.delete(TAG)
    st['last'] = (id(plan['piece']), hit[1])
    st['key'] = None
    app.refresh()
    app.status.set(('Tout le tour teint à ' + fmt(plan['width']) + ' mm. Échap pour finir.') if whole else words(plan))
    return 'break'


def click(app, e):
    return act(app, e)


def double(app, e):
    """A double-click on the side just clicked: the whole piece round (its first click did that side already)."""
    st = app.__dict__.get('teinte_state') or {}
    hit = _hit(app, e)
    if hit is not None and st.get('last') == (id(app.items[hit[0]]), hit[1]):
        return act(app, e, whole=True)
    return act(app, e)


def enter(app):
    """Entrée: a distance typed is kept for the next sides; else the tool is over."""
    text = app.command_value.get().strip()
    if text:
        try:
            # (0.19.40) read as every length typed (parse_length: the unit, cm, « 1+1 »: they fell to « Cliquez d'abord le
            # point de départ sur le dessin. »)
            v = app.parse_length(text)
        except ValueError:
            return None   # (a command's name: as before)
        if not (math.isfinite(v) and .1 <= v <= 50):
            app.status.set('Distance de la teinte : de 0,1 à 50 mm.')
            return 'break'
        keep(app, distance=round(v, 3))
        app.command_value.set('')
        try:
            app.command_entry.place_forget()
        except (AttributeError, tk.TclError):
            pass
        if app.__dict__.get('teinte_state') is not None:
            app.teinte_state['key'] = None
        prompt(app)
        return 'break'
    app.escape()
    app.status.set('Teinte des bords terminée.')
    return 'break'


def preview(app, e):
    """Under the mouse, before the click: the band it makes (dashed), or the one it takes off (red)."""
    c = app.canvas
    c.delete(TAG)
    st = app.__dict__.get('teinte_state')
    if st is None:
        return
    hit = _hit(app, e)
    if hit is None:
        return
    key = (app.__dict__.get('_doc_version'), id(app.items), len(app.items), hit, settings(app)['distance'])
    if st.get('key') != key:
        try:
            st['plan'] = change(app, *hit)
        except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
            st['plan'] = None
        st['key'] = key
    plan = st.get('plan')
    try:
        if plan is None:
            from assembly_ui import sides as cut
            run = cut(app.items[hit[0]])[0][hit[1]][0]
            c.create_line(*[v for q in run for v in app.to_screen(q)], fill='#e05050', width=3, tags=TAG)
            return
        for j in plan['remove']:
            if j < len(app.items) and app.items[j].get('preparation'):
                pts = prep.ring_points(app.items[j])
                c.create_polygon(*[v for q in pts for v in app.to_screen(q)], fill='', outline='#e05050', width=2, dash=(4, 3), tags=TAG)
        from geometry import path
        for line, zone in plan['add']:
            pts = prep.ring_points(zone)
            c.create_polygon(*[v for q in pts for v in app.to_screen(q)], fill='', outline=app.p['accent'], width=2, dash=(4, 3), tags=TAG)
            pts, closed = path(line)
            flat = [v for q in pts + (pts[:1] if closed else []) for v in app.to_screen(q)]
            if len(flat) >= 4:
                c.create_line(*flat, fill='#f4a6ca', width=2, tags=TAG)
    except (tk.TclError, ValueError, IndexError, TypeError):
        c.delete(TAG)


def dialog(app):
    """Right click: the distance and the couches of the next bands."""
    st = settings(app)
    win = app.dialog('Teinte des bords')
    panel = app.p['panel']
    form = tk.Frame(win, bg=panel)
    form.pack(fill='x', padx=16, pady=(14, 4))
    distance = tk.StringVar(value=fmt(st['distance']))
    coats = tk.StringVar(value=str(st['couches']))
    app.label(form, 'Distance du bord (mm)').grid(row=0, column=0, sticky='w', pady=3)
    first = app.entry(form, distance, 8)
    first.grid(row=0, column=1, sticky='w', padx=8, pady=3)
    app.label(form, 'Couche(s)').grid(row=1, column=0, sticky='w', pady=3)
    app.entry(form, coats, 4).grid(row=1, column=1, sticky='w', padx=8, pady=3)

    def valid(e=None):
        try:
            d = float(distance.get().strip().replace(',', '.'))
            n = int(coats.get().strip())
            if not (math.isfinite(d) and .1 <= d <= 50):
                raise ValueError('Distance : de 0,1 à 50 mm.')
            if not 1 <= n <= 20:
                raise ValueError('Couche(s) : de 1 à 20.')
        except ValueError as exc:
            text = str(exc)
            messagebox.showerror('Teinte des bords', text if ' : ' in text else 'Distance en mm, couches : un nombre entier.', parent=win)
            return 'break'
        win.destroy()
        keep(app, distance=round(d, 3), couches=n)
        if app.__dict__.get('teinte_state') is not None:
            app.teinte_state['key'] = None
            prompt(app)
        app.canvas.focus_set()
        return 'break'
    win.bind('<Return>', valid)
    win.bind('<KP_Enter>', valid)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(8, 14))
    app.button(foot, 'Valider', valid).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', lambda: (win.destroy(), app.canvas.focus_set()))
    first.focus_set()
    first.select_range(0, 'end')
    return win
