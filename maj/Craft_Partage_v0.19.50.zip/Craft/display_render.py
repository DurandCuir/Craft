"""Display-only antialiasing. Windows GDI+ needs no installed Python package.

Native canvas entities remain the source for tags and editing. Unsupported
backends/options keep their native drawing. CAD geometry and exports never pass
through this module. Pillow is a portable development/optional fallback.
"""
import base64,ctypes,io,math,struct,sys,time,zlib
from functools import lru_cache


def png_rgba(width,height,raw):
    def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    rows=b''.join(b'\0'+raw[y*width*4:(y+1)*width*4] for y in range(height))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(rows,3))+chunk(b'IEND',b'')


def rgba(color):
    if not color:return (0,0,0,0)
    value=color.lstrip('#')
    if len(value)==3:value=''.join(v*2 for v in value)
    return (*[int(value[i:i+2],16) for i in (0,2,4)],255)


def segments(points,dash):
    """Continuous dash phase across a polyline, in screen pixels."""
    pairs=list(zip(points,points[1:]))
    if not dash:return pairs
    pattern=list(dash)*(2 if len(dash)%2 else 1);phase=0;remaining=pattern[0];out=[]
    for a,b in pairs:
        length=math.dist(a,b)
        if length<1e-10:continue
        pos=0
        while pos<length-1e-10:
            step=min(remaining,length-pos)
            if phase%2==0:out.append((tuple(a[k]+(b[k]-a[k])*pos/length for k in (0,1)),tuple(a[k]+(b[k]-a[k])*(pos+step)/length for k in (0,1))))
            pos+=step;remaining-=step
            if remaining<1e-9:phase=(phase+1)%len(pattern);remaining=pattern[phase]
    return out


def ppm(width,height,rgb):
    return b'P6 %d %d 255\n'%(width,height)+bytes(rgb)


def png_rgb(width,height,rgb):
    def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    rows=b''.join(b'\0'+rgb[y*width*3:(y+1)*width*3] for y in range(height))
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(rows,1))+chunk(b'IEND',b'')


def unpadded(buffer,width,height,stride):
    """0.19.24: the rows of a picture of 3 bytes a pixel, each ``stride`` bytes long in ``buffer`` (GDI+ pads them to 4
    bytes), one after the other without their padding."""
    row=width*3
    if stride==row:return buffer if len(buffer)==row*height else bytes(buffer[:row*height])
    view=memoryview(buffer);return b''.join(view[k*stride:k*stride+row] for k in range(height))


class Stopped(Exception):
    """0.19.30: a smoothing in the background dropped while it is made (paint_soon)."""


def supersampling(width,height):
    """Pillow draws at 2 or 3 times the size, then reduces (antialiasing)."""
    return 3 if width*height<300000 else 2


class PillowBackend:
    name='Pillow'
    @staticmethod
    def _drawn(width,height,ops,ground,stop=None):
        """The lines drawn at 2 or 3 times the size, and that factor. ``ground``: the RGBA of the picture's ground; 0.19.25:
        an opaque one (R, G, B): an RGB picture (the same pixels; Pillow reduces an RGBA picture through a premultiplied
        copy of the whole of it, made again for each part). 0.19.30 ``stop``: asked every 32 lines, true: Stopped."""
        from PIL import Image,ImageDraw
        factor=supersampling(width,height);im=Image.new('RGB' if len(ground)==3 else 'RGBA',(width*factor,height*factor),ground);d=ImageDraw.Draw(im)
        colour=(lambda c:rgba(c)[:3]) if len(ground)==3 else rgba
        def coords(values):return [v*factor for v in values]
        for n,(kind,xy,fill,outline,weight,dash,start,extent) in enumerate(ops):
            if stop is not None and not n&31 and stop():raise Stopped
            w=max(1,round(weight*factor));points=list(zip(xy[::2],xy[1::2]))
            if kind=='line':
                if dash:
                    for a,b in segments(points,dash):d.line(coords((*a,*b)),fill=colour(fill),width=w)
                else:d.line([tuple(coords(p)) for p in points],fill=colour(fill),width=w,joint='curve')
            elif kind=='polygon':
                if fill:d.polygon([tuple(coords(p)) for p in points],fill=colour(fill))
                if outline:d.line([tuple(coords(p)) for p in points+points[:1]],fill=colour(outline),width=w,joint='curve')
            elif kind=='rectangle':d.rectangle(coords(xy),fill=colour(fill) if fill else None,outline=colour(outline) if outline else None,width=w)
            elif kind=='oval':d.ellipse(coords(xy),fill=colour(fill) if fill else None,outline=colour(outline) if outline else None,width=w)
            elif kind=='arc':d.arc(coords(xy),-start-extent,-start,fill=colour(outline),width=w)
        return im,factor
    def render_parts(self,width,height,ops,background,boxes,stop=None):
        """0.19.25: the parts ``boxes`` (x0, y0, x1, y1) of the opaque picture of the whole screen, each a PPM: the lines
        drawn once on the whole (the same cuts at its edges) and each part reduced from it (``resize(box=…)``: the same
        weights: the pixels of the whole). 0.19.30 ``stop``: see _drawn."""
        from PIL import Image
        im,factor=self._drawn(width,height,ops,rgba(background)[:3],stop);out=[]
        for x0,y0,x1,y1 in boxes:
            if stop is not None and stop():raise Stopped
            part=im.resize((x1-x0,y1-y0),Image.Resampling.LANCZOS,box=(x0*factor,y0*factor,x1*factor,y1*factor))
            out.append(ppm(x1-x0,y1-y0,part.tobytes()))
        return out
    def render(self,width,height,ops,background=None,box=None,base=None):
        """PNG with transparency, or (0.17.0) an opaque PPM on ``background``: Tk shows an opaque
        image at once, while a transparent one with many antialiased lines took over a second.
        0.19.7: ``base`` (x, y, w, h, RGB bytes): the background picture under the lines (« trait pas
        beau »: the lines over a picture were not smoothed).
        0.18.7: ``box`` (x0, y0, x1, y1): only that part of the picture, the same pixels as the whole:
        drawn on the whole (Pillow cuts a line at the picture's edge: a smaller picture would draw it
        a little differently) and reduced from the whole (``resize(box=…)``: the same weights; a
        reduction of a cut-out piece differs by a few levels)."""
        from PIL import Image
        im,factor=self._drawn(width,height,ops,rgba(background)[:3] if background and not base else (0,0,0,0))
        if box:
            x0,y0,x1,y1=box;width,height=x1-x0,y1-y0
            im=im.resize((width,height),Image.Resampling.LANCZOS,box=(x0*factor,y0*factor,x1*factor,y1*factor))
        else:im=im.resize((width,height),Image.Resampling.LANCZOS)
        if base:
            x0,y0=box[:2] if box else (0,0);out=Image.new('RGB',im.size,rgba(background)[:3] if background else (255,255,255))
            bx,by,bw,bh,rgb=base;out.paste(Image.frombytes('RGB',(bw,bh),bytes(rgb)),(bx-x0,by-y0));out.paste(im,(0,0),im)
            return ppm(out.size[0],out.size[1],out.tobytes())
        if background:return ppm(width,height,im.convert('RGB').tobytes())
        buf=io.BytesIO();im.save(buf,format='PNG',compress_level=2);return buf.getvalue()


class GdiBackend:
    name='GDI+'
    fast=True   # 0.19.24: an opaque picture drawn in GDI+'s own format and read as RGB at once (else as before)
    def __init__(self):
        from ctypes import wintypes as w
        self.g=ctypes.WinDLL('gdiplus');self.P=ctypes.c_void_p;self.F=ctypes.c_float
        class Startup(ctypes.Structure):_fields_=[('version',w.UINT),('callback',self.P),('suppress_thread',w.BOOL),('suppress_codecs',w.BOOL)]
        class Point(ctypes.Structure):_fields_=[('X',ctypes.c_float),('Y',ctypes.c_float)]
        class Rect(ctypes.Structure):_fields_=[('X',ctypes.c_int),('Y',ctypes.c_int),('Width',ctypes.c_int),('Height',ctypes.c_int)]
        class BitmapData(ctypes.Structure):_fields_=[('Width',w.UINT),('Height',w.UINT),('Stride',ctypes.c_int),('PixelFormat',ctypes.c_int),('Scan0',ctypes.c_void_p),('Reserved',ctypes.c_size_t)]
        self.Point=Point;self.Rect=Rect;self.BitmapData=BitmapData
        P=self.P;F=self.F;I=ctypes.c_int;U=ctypes.c_uint32
        specs={'GdiplusStartup':[ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(Startup),P], 'GdiplusShutdown':[ctypes.c_size_t],
          'GdipCreateBitmapFromScan0':[I,I,I,I,P,ctypes.POINTER(P)],'GdipGetImageGraphicsContext':[P,ctypes.POINTER(P)],
          'GdipSetSmoothingMode':[P,I],'GdipSetPixelOffsetMode':[P,I],'GdipGraphicsClear':[P,U],
          'GdipCreatePen1':[U,F,I,ctypes.POINTER(P)],'GdipDeletePen':[P], 'GdipSetPenLineJoin':[P,I],
          'GdipDrawLines':[P,P,ctypes.POINTER(Point),I], 'GdipDrawPolygon':[P,P,ctypes.POINTER(Point),I],
          'GdipCreateSolidFill':[U,ctypes.POINTER(P)],'GdipDeleteBrush':[P], 'GdipFillPolygon':[P,P,ctypes.POINTER(Point),I,I],
          'GdipDrawEllipse':[P,P,F,F,F,F],'GdipFillEllipse':[P,P,F,F,F,F],'GdipDrawRectangle':[P,P,F,F,F,F],'GdipFillRectangle':[P,P,F,F,F,F],
          'GdipDrawArc':[P,P,F,F,F,F,F,F], 'GdipBitmapLockBits':[P,ctypes.POINTER(Rect),U,I,ctypes.POINTER(BitmapData)],
          'GdipBitmapUnlockBits':[P,ctypes.POINTER(BitmapData)],'GdipDeleteGraphics':[P],'GdipDisposeImage':[P],
          'GdipDrawImageRectI':[P,P,I,I,I,I],'GdipSetInterpolationMode':[P,I]}
        for name,args in specs.items():fn=getattr(self.g,name);fn.argtypes=args;fn.restype=I
        self.token=ctypes.c_size_t();self.call('GdiplusStartup',ctypes.byref(self.token),ctypes.byref(Startup(1,None,False,False)),None)
        import atexit
        atexit.register(self.g.GdiplusShutdown,self.token)
    def call(self,name,*args):
        result=getattr(self.g,name)(*args)
        if result:raise OSError('GDI+ '+name+': '+str(result))
    def argb(self,color):
        r,g,b,a=rgba(color);return (a<<24)|(r<<16)|(g<<8)|b
    def bgra(self,color):
        """0.19.24: the colour with red and blue swapped: drawn so, GDI+'s bytes (B, G, R) are the picture's R, G, B."""
        r,g,b,a=rgba(color);return (a<<24)|(b<<16)|(g<<8)|r
    def draw_base(self,graphics,base,swapped=False):
        """0.19.7: the background picture (RGB rows) drawn as it is at (x, y): a 24-bit bitmap over our
        own bytes (B, G, R, rows padded to 4 bytes), pixel for pixel. 0.19.24 ``swapped``: the colours of the picture
        being made are swapped (bgra): its own bytes go as they are."""
        x,y,w,h,rgb=base;row=(w*3+3)//4*4;data=bytearray(row*h);line=bytearray(rgb)
        if not swapped:line[0::3],line[2::3]=line[2::3],line[0::3]
        if row==w*3:data[:]=line
        else:
            for k in range(h):data[k*row:k*row+w*3]=line[k*w*3:(k+1)*w*3]
        buffer=(ctypes.c_char*len(data)).from_buffer(data);bitmap=self.P()
        self.call('GdipCreateBitmapFromScan0',w,h,row,0x21808,buffer,ctypes.byref(bitmap))
        try:
            self.call('GdipSetInterpolationMode',graphics,5);self.call('GdipSetPixelOffsetMode',graphics,4)
            self.call('GdipDrawImageRectI',graphics,bitmap,x,y,w,h)
        finally:self.g.GdipDisposeImage(bitmap)
    def points(self,xy):
        """0.18.7: the coordinates as GDI+ points in one go (float32 pairs: the layout of an array
        of Point), instead of one Python object per point (25 times quicker)."""
        import array
        return (self.Point*(len(xy)//2)).from_buffer(array.array('f',xy[:len(xy)//2*2]))
    def render(self,width,height,ops,background=None,box=None,base=None):
        """0.18.7: ``box`` (x0, y0, x1, y1): only that part, drawn on the whole picture (the same
        positions and cuts at the edge as the whole), only its pixels read. 0.19.7: ``base`` (x, y, w, h,
        RGB bytes): the background picture drawn first, the lines smoothed over it. 0.19.24: an opaque picture is
        drawn in GDI+'s premultiplied format (its quickest), its colours swapped so that its pixels read in 24 bits are
        already the R, G, B rows of the PPM (no byte shuffled by Python); a refusal of GDI+: as before, for good."""
        if background and self.fast:
            try:return self._render(width,height,ops,background,box,base,True)
            except (OSError,ValueError,ctypes.ArgumentError):type(self).fast=False
        return self._render(width,height,ops,background,box,base,False)
    def render_parts(self,width,height,ops,background,boxes,stop=None):
        """0.19.25: the parts ``boxes`` (x0, y0, x1, y1) of the opaque picture of the whole screen, each a PPM: the lines
        drawn once on the whole picture, only the pixels of each part read (the same pixels as the whole). 0.19.30
        ``stop``: asked every 32 lines, true: Stopped."""
        if self.fast:
            try:return self._render(width,height,ops,background,None,None,True,boxes,stop)
            except (OSError,ValueError,ctypes.ArgumentError):type(self).fast=False
        return self._render(width,height,ops,background,None,None,False,boxes,stop)
    def _render(self,width,height,ops,background,box,base,quick,boxes=None,stop=None):
        P=self.P;image=P();graphics=P();fmt=0xE200B if quick else 0x26200A;pens={};colour=self.bgra if quick else self.argb
        self.call('GdipCreateBitmapFromScan0',width,height,0,fmt,None,ctypes.byref(image))
        try:
            self.call('GdipGetImageGraphicsContext',image,ctypes.byref(graphics))
            self.call('GdipSetSmoothingMode',graphics,4);self.call('GdipSetPixelOffsetMode',graphics,4);self.call('GdipGraphicsClear',graphics,colour(background) if background else 0)
            if base:self.draw_base(graphics,base,quick)
            for n,(kind,xy,fill,outline,weight,dash,start,extent) in enumerate(ops):
                if stop is not None and not n&31 and stop():raise Stopped
                array=self.points(xy);count=len(array);pen=P();brush=P()
                ink=fill if kind=='line' else outline
                try:
                    if ink:
                        # 0.17.0: one pen per colour and width for the whole picture.
                        known=pens.get((ink,weight))
                        if known is None:
                            self.call('GdipCreatePen1',colour(ink),weight,2,ctypes.byref(pen));self.call('GdipSetPenLineJoin',pen,2);pens[(ink,weight)]=pen
                        else:pen=known
                    if fill and kind!='line':self.call('GdipCreateSolidFill',colour(fill),ctypes.byref(brush))
                    if kind=='line':
                        if dash:
                            for a,b in segments(list(zip(xy[::2],xy[1::2])),dash):self.call('GdipDrawLines',graphics,pen,(self.Point*2)(self.Point(*a),self.Point(*b)),2)
                        else:self.call('GdipDrawLines',graphics,pen,array,count)
                    elif kind=='polygon':
                        if brush:self.call('GdipFillPolygon',graphics,brush,array,count,0)
                        if pen:self.call('GdipDrawPolygon',graphics,pen,array,count)
                    else:
                        x,y,X,Y=xy;frame=(x,y,max(0,X-x),max(0,Y-y))
                        if kind=='arc':self.call('GdipDrawArc',graphics,pen,*frame,-start,-extent)
                        else:
                            suffix='Ellipse' if kind=='oval' else 'Rectangle'
                            if brush:self.call('GdipFill'+suffix,graphics,brush,*frame)
                            if pen:self.call('GdipDraw'+suffix,graphics,pen,*frame)
                finally:
                    if brush:self.g.GdipDeleteBrush(brush)
            def read(left,top,right,bottom):
                w,h=right-left,bottom-top
                data=self.BitmapData();rect=self.Rect(left,top,w,h)
                if quick:   # read as 24-bit rows: R, G, B (the colours were swapped)
                    self.call('GdipBitmapLockBits',image,ctypes.byref(rect),1,0x21808,ctypes.byref(data))
                    try:
                        if data.Stride<w*3:raise OSError('GDI+ GdipBitmapLockBits: '+str(data.Stride))   # rows upside down: as before
                        return ppm(w,h,unpadded(ctypes.string_at(data.Scan0,data.Stride*h),w,h,data.Stride))
                    finally:self.g.GdipBitmapUnlockBits(image,ctypes.byref(data))
                self.call('GdipBitmapLockBits',image,ctypes.byref(rect),1,fmt,ctypes.byref(data))
                try:
                    if data.Stride==w*4:raw=bytearray(ctypes.string_at(data.Scan0,w*h*4))   # 0.18.7: in one go
                    else:
                        raw=bytearray(w*h*4)
                        for row in range(h):raw[row*w*4:(row+1)*w*4]=ctypes.string_at(data.Scan0+row*data.Stride,w*4)
                    if background:
                        rgb=bytearray(w*h*3);rgb[0::3]=raw[2::4];rgb[1::3]=raw[1::4];rgb[2::3]=raw[0::4]
                        return ppm(w,h,rgb)
                    raw[0::4],raw[2::4]=raw[2::4],raw[0::4]
                    return png_rgba(w,h,raw)
                finally:self.g.GdipBitmapUnlockBits(image,ctypes.byref(data))
            if boxes is not None:return [read(*b) for b in boxes]   # 0.19.25: the parts of the sparse picture
            return read(*(box if box else (0,0,width,height)))
        finally:
            for pen in pens.values():self.g.GdipDeletePen(pen)
            if graphics:self.g.GdipDeleteGraphics(graphics)
            self.g.GdipDisposeImage(image)


@lru_cache(maxsize=1)
def backend():
    if sys.platform=='win32':
        try:return GdiBackend()
        except (OSError,AttributeError):pass
    try:
        import PIL.Image
        return PillowBackend()
    except ImportError:return None


_OPS_PROC=r"""proc craft_canvas_row {c i kinds} {
    set t [$c type $i]
    if {[lsearch -exact $kinds $t] < 0} {return ""}
    if {[$c itemcget $i -stipple] ne ""} {return ""}
    if {$t eq "line"} {
        if {[$c itemcget $i -arrow] ne "none"} {return ""}
        set sm [$c itemcget $i -smooth]
        if {$sm ne "0" && $sm ne "false" && $sm ne ""} {return ""}
    }
    if {$t eq "arc" && [$c itemcget $i -style] ne "arc"} {return ""}
    set fill {};set outline {};set dash {};set start 0;set extent 0
    if {$t ne "arc"} {set fill [$c itemcget $i -fill]}
    if {$t ne "line"} {set outline [$c itemcget $i -outline]}
    if {$t eq "line"} {set dash [$c itemcget $i -dash]}
    if {$t eq "arc"} {set start [$c itemcget $i -start];set extent [$c itemcget $i -extent]}
    set tags [lsearch -all -inline -not -regexp [$c gettags $i] {^(zoom:|_obj|current$)}]
    return "$i\x1f[join [list $t [join $tags \x1d] [$c coords $i] $fill $outline [$c itemcget $i -width] $dash $start $extent] \x1f]"
}
proc craft_canvas_ops {c icons} {
    global craft_rows
    if {$icons} {set kinds {line polygon rectangle oval arc}} else {set kinds {line polygon}}
    set slot "$c $icons"
    if {!$icons && [info exists craft_rows($slot)]} {set known $craft_rows($slot)} else {set known {}}
    set fresh {}
    set out {}
    foreach i [$c find all] {
        if {[dict exists $known $i]} {set row [dict get $known $i]} else {set row [craft_canvas_row $c $i $kinds]}
        dict set fresh $i $row
        if {$row ne ""} {lappend out $row}
    }
    if {!$icons} {set craft_rows($slot) $fresh}
    return [join $out \x1e]
}
proc craft_forget_rows {c} {
    global craft_rows craft_brows craft_bstale craft_bkept
    foreach slot [array names craft_rows "$c *"] {unset craft_rows($slot)}
    catch {unset craft_brows($c)}
    catch {unset craft_bstale($c)}
    catch {unset craft_bkept($c)}
}
proc craft_forget_items {c ids} {
    global craft_rows craft_brows craft_bkept
    if {[info exists craft_brows($c)]} {
        set d $craft_brows($c)
        foreach i $ids {dict unset d $i}
        set craft_brows($c) $d
    }
    catch {unset craft_bkept($c)}
    foreach slot [array names craft_rows "$c *"] {
        set d $craft_rows($slot)
        foreach i $ids {dict unset d $i}
        set craft_rows($slot) $d
    }
}
proc craft_canvas_meta {c i} {
    set t [$c type $i]
    if {$t ne "line" && $t ne "polygon"} {return ""}
    if {[$c itemcget $i -stipple] ne ""} {return ""}
    if {$t eq "line"} {
        if {[$c itemcget $i -arrow] ne "none"} {return ""}
        set sm [$c itemcget $i -smooth]
        if {$sm ne "0" && $sm ne "false" && $sm ne ""} {return ""}
    }
    set tags [lsearch -all -inline -not -regexp [$c gettags $i] {^(zoom:|_obj|current$)}]
    if {![craft_allowed $tags]} {return ""}
    set outline {};set dash {}
    if {$t eq "line"} {set dash [$c itemcget $i -dash]} else {set outline [$c itemcget $i -outline]}
    return [list $t [join $tags \x1d] [$c itemcget $i -fill] $outline [$c itemcget $i -width] $dash 0 0]
}
proc craft_allowed {tags} {
    global craft_allowed_tags
    foreach g $tags {if {![info exists craft_allowed_tags($g)]} {return 0}}
    return 1
}
proc craft_canvas_kept {c all} {
    # 0.19.42: nothing changed since the last reading (the same items in the same order, no row forgotten, nothing moved):
    # that reading as it was (the smoothing reads the plan again to check its picture). "" otherwise: read as before.
    global craft_bkept
    if {![info exists craft_bkept($c)]} {return ""}
    lassign $craft_bkept($c) order out bin
    if {$order ne $all} {return ""}
    return [list $out $bin]
}
proc craft_canvas_bin {c} {
    global craft_brows craft_bstale craft_bkept
    set all [$c find all]
    if {![info exists craft_bstale($c)]} {
        set quick [craft_canvas_kept $c $all]
        if {$quick ne ""} {return $quick}
    }
    if {[info exists craft_brows($c)]} {set known $craft_brows($c)} else {set known {}}
    set stale [info exists craft_bstale($c)]
    if {$stale} {unset craft_bstale($c)}
    set fresh {}
    set meta {}
    set bin [binary format a0 {}]
    foreach i $all {
        if {[dict exists $known $i]} {
            set e [dict get $known $i]
            if {$stale && $e ne ""} {
                set xy [$c coords $i]
                set m [lindex $e 0]
                if {[lindex $m 5] ne ""} {lset m 5 [$c itemcget $i -dash]}
                set e [list $m [llength $xy] [binary format d* $xy]]
            }
        } else {
            set m [craft_canvas_meta $c $i]
            if {$m eq ""} {set e ""} else {
                set xy [$c coords $i]
                set e [list $m [llength $xy] [binary format d* $xy]]
            }
        }
        dict set fresh $i $e
        if {$e ne ""} {
            lassign $e m n b
            lappend meta "$i\x1f[join $m \x1f]\x1f$n"
            append bin $b
        }
    }
    set craft_brows($c) $fresh
    set out [join $meta \x1e]
    set craft_bkept($c) [list $all $out $bin]
    return [list $out $bin]
}
proc craft_stale_rows {c} {
    global craft_bstale
    set craft_bstale($c) 1
}
proc craft_hide {c ids} {foreach i $ids {$c itemconfigure $i -state hidden}}
proc craft_show {c ids} {foreach i $ids {catch {$c itemconfigure $i -state normal}}}
proc craft_over {c ids} {
    set top {}
    foreach i $ids {if {[llength [$c find withtag $i]]} {set top $i;if {[$c itemcget $i -state] eq "hidden"} {$c itemconfigure $i -state normal}}}
    if {$top ne {} && [llength [$c find withtag _smooth_display]]} {$c raise _smooth_display $top}
}
proc craft_unhide {c ids} {foreach i $ids {if {[llength [$c find withtag $i]] && [$c itemcget $i -state] eq "hidden"} {$c itemconfigure $i -state normal}}}
# 0.19.43: the stacking paint and preparation_ui.lower_fills make, already there (a restack of the smoothed picture makes Tk
# show all of it again): the same order as their restack would leave, nothing else looked at
proc craft_picture_ok {c item under bg} {
    # paint: the picture to the bottom, (``bg``) the background pictures under it, then over the last zone of ``under``
    set top {}
    foreach i $under {if {[llength [$c find withtag $i]]} {set top $i}}
    set bgs {}
    if {$bg} {set bgs [$c find withtag background_image]}
    if {[llength $bgs] && [lrange [$c find all] 0 [expr {[llength $bgs]-1}]] ne $bgs} {return 0}
    set below [$c find below $item]
    if {$top ne {}} {return [expr {$below eq $top}]}
    if {[llength $bgs]} {return [expr {$below eq [lindex $bgs end]}]}
    return [expr {$below eq {}}]
}
proc craft_fills_ok {c} {
    # lower_fills: the zones under all (in their order), the picture just over them
    set want [$c find withtag prep_fill]
    lappend want {*}[$c find withtag _smooth_display]
    return [expr {[lrange [$c find all] 0 [expr {[llength $want]-1}]] eq $want}]
}"""
_ALLOWED={'component_geometry','notch_geometry','marks','label','guides','prep_fill','grid'}   # 0.18.2: the grid is tagged


def _procs(canvas):
    tk=canvas.tk
    if not tk.call('info','procs','craft_over'):
        tk.eval(_OPS_PROC)
        for tag in sorted(_ALLOWED):tk.call('set','craft_allowed_tags('+tag+')',1)   # 0.19.30: what craft_canvas_bin reads
    return tk


def plain(value):
    """0.18.1: Tk 8.6.15 (Windows) hands some values back as _tkinter.Tcl_Obj (a colour or a
    width keeping a Tk internal type): unhashable and not a number for Python, the smoothing
    stopped on « unhashable type ». Their text is what counts; an empty Tcl list arrives as ()."""
    if isinstance(value,str):return value
    if isinstance(value,tuple):return ' '.join(plain(v) for v in value)
    return str(value)


_UNREAD=object()


def forget_rows(canvas):
    """The items are gone (a drawing emptied the canvas): read again."""
    try:_procs(canvas).call('craft_forget_rows',canvas._w)
    except Exception:pass


def forget_items(canvas,ids):
    """0.19.33: these items changed their options in place (draw_cache: a selection switched): their rows read again."""
    try:_procs(canvas).call('craft_forget_items',canvas._w,list(ids))
    except Exception:pass


def stale_rows(canvas):
    """0.19.30: the items were moved or scaled where they are (the wheel, a move of the view): the next reading takes only
    their coordinates again (and a dash: zoom_marks), not the ten other values of each."""
    try:_procs(canvas).call('craft_stale_rows',canvas._w)
    except Exception:pass


def rows_of(meta,blob,known,colour):
    """0.19.30: the operations of the plan's smoothed items as canvas_rows gives them, from craft_canvas_bin: ``meta`` a row
    an item (its id, kind, tags, colours, width, dash, its count of coordinates), ``blob`` all their coordinates (doubles
    packed: Tk's text of 40 000 numbers and Python's reading of it cost 15 ms on DIFORME; 3 ms now). ``known``: key →
    operation of the last reading; ``colour``: a colour as the smoothing writes it. The key of an item: (its row but for its
    id and count, the bytes of its coordinates). (operations, ids, keys, key → operation)."""
    import array
    numbers=array.array('d');numbers.frombytes(blob)
    seen={};operations=[];identifiers=[];keys=[];at=0
    for row in meta.split('\x1e') if meta else ():
        item,rest=row.split('\x1f',1);head,n=rest.rsplit('\x1f',1);n=int(n)
        key=(head,blob[8*at:8*(at+n)]);op=known.get(key,_UNREAD)
        if op is _UNREAD:
            kind,tags,fill,outline,width,dash,start,extent=head.split('\x1f')
            op=(kind,tuple(numbers[at:at+n]),colour(fill),colour(outline),float(width),tuple(map(float,dash.split())) if kind=='line' else (),float(start),float(extent))
        at+=n;seen[key]=op
        operations.append(op);identifiers.append(int(item));keys.append(key)
    return tuple(operations),identifiers,tuple(keys),seen


def read_plan(canvas):
    """0.19.30: the plan's smoothed items in one call of Tk: (rows, packed coordinates); see rows_of."""
    tk=_procs(canvas)
    if not canvas.__dict__.get('_rows_destroy_bound'):
        # 0.19.9: the rows kept for this canvas go with it (each rebuild_ui left those of the plan before: +0.34 MB on DIFORME)
        tk.call('bind',canvas._w,'<Destroy>','+catch [list craft_forget_rows %W]');canvas._rows_destroy_bound=True
    meta,blob=tk.call('craft_canvas_bin',canvas._w)
    if isinstance(blob,str):blob=blob.encode('latin-1')   # (a Tk keeping it as text: one character a byte)
    elif not isinstance(blob,bytes):blob=bytes(blob) if isinstance(blob,(bytearray,memoryview)) else plain(blob).encode('latin-1')
    return plain(meta),blob


def canvas_rows(canvas,icons=False):
    """0.18.7: the smoothed items in stacking order, as (operations, item ids, keys). One Tcl call
    returning ONE string (split by Python: the list of lists cost ~25 ms for 900 lines). An item
    already read keeps its row (Tcl, by item: the items kept by draw_cache are not read again; the
    wheel zoom and the move of the view, which change items where they are, call stale_rows); a row
    already converted keeps its operation (Python, by key: kind, tags, coordinates, colours, width).
    A size kept for the zoom (« zoom: », 0.18.3), the groups of draw_cache (« _obj ») and Tk's
    « current » are not part of the key. 0.19.30: the plan's coordinates packed (read_plan, rows_of)."""
    tk=_procs(canvas);colours=canvas.__dict__.setdefault('_rgb_names',{});known=canvas.__dict__.get('_ops_known') or {}
    seen={};operations=[];identifiers=[];keys=[]
    def colour(value):
        if not value:return ''
        if value not in colours:colours[value]='#'+''.join(f'{round(v/257):02x}' for v in canvas.winfo_rgb(value))
        return colours[value]
    if not icons:   # 0.19.30: the plan, its coordinates packed
        meta,blob=read_plan(canvas)
        operations,identifiers,keys,seen=rows_of(meta,blob,known,colour)
        canvas._ops_known=seen
        return operations,identifiers,keys
    text=plain(tk.call('craft_canvas_ops',canvas._w,1 if icons else 0))
    for row in text.split('\x1e') if text else ():
        item,key=row.split('\x1f',1);op=known.get(key,_UNREAD)
        if op is _UNREAD:
            kind,tags,coords,fill,outline,width,dash,start,extent=key.split('\x1f')
            if tags and not icons and not set(tags.split('\x1d'))<=_ALLOWED:op=None
            else:op=(kind,tuple(map(float,coords.split())),colour(fill),colour(outline),float(width),tuple(map(float,dash.split())) if kind=='line' else (),float(start),float(extent))
        seen[key]=op
        if op is None:continue
        operations.append(op);identifiers.append(int(item));keys.append(key)
    canvas._ops_known=seen
    return tuple(operations),identifiers,tuple(keys)


def canvas_operations(canvas,icons=False):
    """0.17.0: read in ONE Tcl call (it took ~80 ms of Python→Tk calls for 4000 lines)."""
    ops,ids,_=canvas_rows(canvas,icons)
    return ops,ids


@lru_cache(maxsize=192)
def icon_image(width,height,ops,background):return backend().render(width,height,ops,background)


def photo_image(canvas,data):
    """An opaque PPM goes straight to Tk; a Tk refusing binary PPM gets the same picture as PNG."""
    import tkinter as tk
    if data[:2]==b'P6':
        try:return tk.PhotoImage(master=canvas,data=data,format='PPM')
        except tk.TclError:
            head,rgb=data.split(b'\n',1);_,w,h,_=head.split();data=png_rgb(int(w),int(h),rgb)
    return tk.PhotoImage(master=canvas,data=base64.b64encode(data))


# 0.18.0: what the last smoothing did, for diagnostic.txt ('plan', 'icons').
STATUS={}


# 0.18.7: only the changed part of the smoothed picture is made again (a click, Supprimer, Annuler,
# a change of one piece): the lines that came or went give a rectangle; the lines over it and a
# margin (Pillow's reduction reaches 3 pixels) are drawn on the whole picture's frame, and only that
# rectangle, read or reduced from it, is copied into the picture. Beyond 60 % of the screen, or when
# unchanged lines changed their order, all is made again.
_MARGIN=4


def _extent(op):
    xy=op[1]
    if len(xy)<2:return None
    xs=xy[0::2];ys=xy[1::2];m=op[4]/2+3
    return (min(xs)-m,min(ys)-m,max(xs)+m,max(ys)+m)


def _left(keys,without):
    left=dict(without);out=[]
    for key in keys:
        if left.get(key,0)>0:left[key]-=1;continue
        out.append(key)
    return out


def _twins(gone,came,old_ops,new_ops):
    """0.19.41: the rows come whose line went with its coordinates less than a millionth of a pixel away (the same line drawn
    again after the wheel or a move of the view scaled or moved it where it was: only its last bits differ): taken out of
    ``gone`` and ``came`` (Counters), {new key: old key}. The picture keeps them as it drew them."""
    if not gone or not came:return {}
    # (review) the rows gone found by their head, their count of coordinates and their first point to a hundredth of a pixel
    # (a twin is in the same cell or a next one): after a change of the whole view (Cadrer, a click while the picture of a
    # gesture is made in the background) every row goes and comes with a few heads only: each compared with all the others,
    # 0.35 to 0.7 s on DIFORME
    cells={}
    for key in gone:
        if not isinstance(key,tuple):continue
        b=old_ops[key][1]
        if len(b)>=2:cells.setdefault((key[0],len(key[1]),round(b[0]*100),round(b[1]*100)),[]).append(key)
    twins={}
    for key in list(came):
        if not isinstance(key,tuple):continue
        a=new_ops[key][1]
        if len(a)<2:continue
        head,size,cx,cy=key[0],len(key[1]),round(a[0]*100),round(a[1]*100)
        for cell in ((cx,cy),(cx-1,cy),(cx+1,cy),(cx,cy-1),(cx,cy+1),(cx-1,cy-1),(cx+1,cy-1),(cx-1,cy+1),(cx+1,cy+1)):
            for other in cells.get((head,size)+cell,()):
                if gone[other]<=0 or came[key]<=0:continue
                b=old_ops[other][1]
                if all(abs(x-y)<=1e-6+1e-11*abs(x) for x,y in zip(a,b)):
                    n=min(gone[other],came[key]);gone[other]-=n;came[key]-=n;twins[key]=other
                    if not gone[other]:del gone[other]
            if came[key]<=0:
                del came[key];break
    return twins


def changed_part(old_keys,new_keys,old_ops,new_ops,width,height):
    """The rectangle (x0, y0, x1, y1) of the picture that changes from ``old_keys`` to ``new_keys``
    (``old_ops`` / ``new_ops``: key → operation); () when no pixel changes; None when the whole
    picture is to be made again."""
    from collections import Counter
    count=Counter(old_keys);count.subtract(new_keys);gone=+count;came=-count
    twins=_twins(gone,came,old_ops,new_ops)
    if twins:new_keys=[twins.get(key,key) for key in new_keys]
    if not gone and not came:return None if tuple(old_keys)!=tuple(new_keys) else ()
    if _left(old_keys,gone)!=_left(new_keys,came):return None   # the same lines, not in the same order
    boxes=[_extent(old_ops[key]) for key in gone]+[_extent(new_ops[key]) for key in came]
    # (0.19.41) lines wholly off the picture change none of its pixels (those left out after a move of the view, on both sides
    # of the screen, made a band as wide as the screen made again)
    boxes=[b for b in boxes if b and b[2]>0 and b[0]<width and b[3]>0 and b[1]<height]
    if not boxes:return ()
    x0=max(0,math.floor(min(b[0] for b in boxes)));y0=max(0,math.floor(min(b[1] for b in boxes)))
    x1=min(width,math.ceil(max(b[2] for b in boxes)));y1=min(height,math.ceil(max(b[3] for b in boxes)))
    if x1<=x0 or y1<=y0:return ()
    if (x1-x0)*(y1-y0)>.6*width*height:return None
    return (x0,y0,x1,y1)


def _patched(canvas,renderer,old,signature,ops,base=None):
    """The last smoothed picture with its changed part made again, or None. 0.19.25: the picture is the canvas's sheet
    (the whole screen, sparse or not): the part is put into it as it comes (PPM), no picture made for it."""
    photo=canvas.__dict__.get('_smooth_photo');before=canvas.__dict__.get('_smooth_ops')
    if photo is None or before is None or old is None or old[:3]!=signature[:3] or old[4:]!=signature[4:]:return None
    width,height,background,keys=signature[:4];now=dict(zip(keys,ops))
    part=changed_part(old[3],keys,before,now,width,height)
    if part is None:return None
    if part:
        x0,y0,x1,y1=part
        X0,Y0,X1,Y1=max(0,x0-_MARGIN),max(0,y0-_MARGIN),min(width,x1+_MARGIN),min(height,y1+_MARGIN)
        extents=canvas.__dict__.get('_op_extents') or {};kept={};inside=[]
        for key,op in zip(keys,ops):
            e=extents[key] if key in extents else _extent(op);kept[key]=e
            if e and e[2]>=X0 and e[0]<=X1 and e[3]>=Y0 and e[1]<=Y1:inside.append(op)
        canvas._op_extents=kept
        _put(photo,renderer.render(width,height,tuple(inside),background,box=(x0,y0,x1,y1),base=base),x0,y0)
        canvas._smooth_patched=part   # for the tests: what was made again
    else:canvas._smooth_patched=()
    return photo


# 0.19.25: the smoothed picture is a sheet as large as the screen, kept with the canvas (made once, emptied for each new
# picture: Tk then makes nothing for its empty parts), and only the parts of the screen where the smoothed lines differ
# from the bare canvas are put into it: tiles along the lines (a piece filling the screen: its sides, not its inside), a
# strip along each long straight side across or down (the base's lines), the edges of the zones (their inside, the same
# colour, is shown by the zone itself, just under the picture). The rest of the sheet stays empty: the canvas shows
# through. Parts over most of the screen (or very many): the whole screen at once, as before.
TILE=32        # the tiles of the sparse picture (pixels)
INK=4          # beyond half a line's width: antialiasing and Pillow's reduction reach this far (pixels)
STRIP=3*TILE   # a side straight across or down at least this long: a strip of its own
DENSE=.85      # parts covering more of the screen than this: the whole screen
MAX_PARTS=200
MERGE=2048     # pixels more to show rather than one part more
SPARSE=True    # (False: always the whole screen, as before; for the tests of what was made again)
GUIDES={'guides'}
UNDER={'prep_fill'}   # filled shapes shown as they are under the picture (preparation_ui.lower_fills keeps them under all)


def _tags(key):
    tags=(key[0] if isinstance(key,tuple) else key).split('\x1f',2)[1]
    return frozenset(tags.split('\x1d')) if tags else frozenset()


def ink_parts(ops,width,height,inside=None):
    """0.19.25: the rectangles (x0, y0, x1, y1) of the screen where the smoothed ``ops`` differ from the bare canvas (a
    line, INK pixels around it beyond half its width; a filled shape, unless ``inside`` (one flag an operation) says its
    inside is shown as it is: its edges only): tiles of TILE pixels, in runs along each row of tiles and in blocks of the
    same runs one under the other; a long side straight across or down: a strip of its own. [] : nothing to show."""
    T=TILE;half=T/2;cols=-(-width//T);rows=-(-height//T)
    if cols<=0 or rows<=0:return []
    grid=bytearray(cols*rows);ones=b'\x01'*cols;strips=[]
    def mark(x0,y0,x1,y1):
        a=int(x0//T);b=int(x1//T);c=int(y0//T);d=int(y1//T)
        if a<0:a=0
        if b>=cols:b=cols-1
        if c<0:c=0
        if d>=rows:d=rows-1
        if a>b or c>d:return
        n=b-a+1
        for k in range(c*cols+a,d*cols+a+1,cols):grid[k:k+n]=ones[:n]
    def segment(ax,ay,bx,by,r,strip):
        dx=abs(bx-ax);dy=abs(by-ay)
        if dx<=half and dy<=half:mark(min(ax,bx)-r,min(ay,by)-r,max(ax,bx)+r,max(ay,by)+r);return
        if strip and (dx<.5 or dy<.5) and max(dx,dy)>=STRIP:   # straight across or down: a strip
            x0=max(0,math.floor(min(ax,bx)-r));y0=max(0,math.floor(min(ay,by)-r))
            x1=min(width,math.ceil(max(ax,bx)+r));y1=min(height,math.ceil(max(ay,by)+r))
            if x1>x0 and y1>y0:strips.append((x0,y0,x1,y1))
            return
        k=math.ceil(max(dx,dy)/half);px,py=ax,ay
        for j in range(1,k+1):
            qx=ax+(bx-ax)*j/k;qy=ay+(by-ay)*j/k
            mark(min(px,qx)-r,min(py,qy)-r,max(px,qx)+r,max(py,qy)+r);px,py=qx,qy
    for index,op in enumerate(ops):
        kind,xy,fill=op[0],op[1],op[2]
        if len(xy)<2:continue
        r=op[4]/2+INK;xs=xy[0::2];ys=xy[1::2]
        x0=min(xs);x1=max(xs);y0=min(ys);y1=max(ys)
        if x1+r<0 or y1+r<0 or x0-r>width or y0-r>height:continue   # out of sight
        closed=kind=='polygon' and len(xs)>2
        # its inside: the rows of tiles crossing it at their middle, and its sides in tiles, never strips (review of
        # 0.19.25: the inside between a strip and the middle of its row of tiles was in no part)
        filled=closed and bool(fill) and (inside is None or inside[index])
        if filled:
            ring=list(zip(xs,ys));ring.append(ring[0])
            for ty in range(max(0,int(y0//T)),min(rows-1,int(y1//T))+1):
                yc=(ty+.5)*T;cut=sorted(ax+(yc-ay)*(bx-ax)/(by-ay) for (ax,ay),(bx,by) in zip(ring,ring[1:]) if (ay<=yc)!=(by<=yc))
                for k in range(0,len(cut)-1,2):mark(cut[k],yc,cut[k+1],yc)
        if x1-x0<=half and y1-y0<=half:mark(x0-r,y0-r,x1+r,y1+r);continue   # small: its box
        if closed:xs=xs+xs[:1];ys=ys+ys[:1]
        n=len(xs)
        for s in range(0,n-1,8):   # 8 sides at a time: their box when within half a tile, else side by side
            e=min(n,s+9);gx=xs[s:e];gy=ys[s:e];gx0=min(gx);gx1=max(gx);gy0=min(gy);gy1=max(gy)
            if gx1-gx0<=half and gy1-gy0<=half:mark(gx0-r,gy0-r,gx1+r,gy1+r);continue
            for k in range(s,e-1):segment(xs[k],ys[k],xs[k+1],ys[k+1],r,not filled)
    # runs of tiles along each row (two tiles or less apart: one run), each run added to the block over it when that
    # costs MERGE pixels or less (fewer parts: each costs Tk a call)
    out=[];blocks=[];spare=MERGE/(T*T)
    for ty in range(rows):
        row=grid[ty*cols:(ty+1)*cols];runs=[];tx=row.find(1)
        while tx>=0:
            end=row.find(0,tx)
            if end<0:end=cols
            if runs and tx-runs[-1][1]<=2:runs[-1]=(runs[-1][0],end)
            else:runs.append((tx,end))
            tx=row.find(1,end)
        now=[]
        for a,b in runs:
            best=None
            for k,(x0,x1,t0) in enumerate(blocks):
                if x1<a or x0>b:continue
                u0=min(x0,a);u1=max(x1,b);extra=(u1-u0-(x1-x0))*(ty-t0)+(u1-u0-(b-a))
                if extra<=spare and (best is None or extra<best[0]):best=(extra,k,u0,u1)
            if best:_,k,u0,u1=best;t0=blocks.pop(k)[2];now.append((u0,u1,t0))
            else:now.append((a,b,ty))
        for x0,x1,t0 in blocks:out.append((x0*T,t0*T,min(width,x1*T),min(height,ty*T)))
        blocks=now
    for x0,x1,t0 in blocks:out.append((x0*T,t0*T,min(width,x1*T),min(height,rows*T)))
    return out+strips


_INK=[None]


def _ink(ops,keys,zone,width,height):
    """0.19.42 (fluidité): ink_parts of a picture, kept for the same lines (where they are, their kind, width, fill: a
    selection changes only their colours, the parts are the same; 35 ms on DIFORME at each selection of all, Échap after it).
    One kept, for the main thread and the worker (a dict read or set at once)."""
    geo=(width,height,tuple(k[1] if isinstance(k,tuple) else k for k in keys),tuple((op[0],op[4],bool(op[2])) for op in ops),tuple(zone))
    hit=_INK[0]
    if hit is not None and hit[0]==geo:return list(hit[1])
    parts=ink_parts(ops,width,height,[not z for z in zone])
    _INK[0]=(geo,tuple(parts))
    return parts


def _sheet(canvas,width,height):
    """0.19.25: the canvas's sheet for its smoothed picture, as large as the screen, emptied (Tk keeps nothing for its
    empty parts); a new one when the screen's size changed."""
    import tkinter as tk
    photo=canvas.__dict__.get('_smooth_photo')
    if photo is not None and canvas.__dict__.get('_smooth_sheet')==(width,height):
        try:canvas.tk.call(photo.name,'blank');return photo
        except tk.TclError:pass
    photo=tk.PhotoImage(master=canvas,width=width,height=height);canvas._smooth_photo=photo;canvas._smooth_sheet=(width,height)
    return photo


def fills_in_place(canvas):
    """0.19.43: the zones already under all, in their order, the smoothed picture just over them: preparation_ui.lower_fills
    has nothing to restack (a restack of the picture makes Tk show all of it again)."""
    import tkinter as tk
    try:return bool(int(_procs(canvas).call('craft_fills_ok',canvas._w)))
    except (tk.TclError,ValueError):return False


def _kept_item(canvas,photo):
    """0.19.43: the smoothed picture's item already on the canvas, showing ``photo`` where paint puts it (0, 0, shown), or
    None (a new one is made)."""
    import tkinter as tk
    found=canvas.find_withtag('_smooth_display')
    if len(found)!=1:return None
    item=found[0]
    try:
        if plain(canvas.itemcget(item,'image'))!=str(photo) or plain(canvas.itemcget(item,'anchor'))!='nw':return None
        if canvas.itemcget(item,'state')=='hidden' or [float(v) for v in canvas.coords(item)]!=[0.,0.]:return None
    except (tk.TclError,ValueError):return None
    return item


_PPM_PUT=[True]


def _put(photo,data,x,y):
    """0.19.25: a part of the picture (PPM, or PNG) put into the sheet at (x, y); a Tk refusing binary PPM gets it as PNG."""
    import tkinter as tk
    if data[:2]==b'P6':
        if _PPM_PUT[0]:
            try:photo.tk.call(photo.name,'put',data,'-format','ppm','-to',x,y);return
            except tk.TclError:_PPM_PUT[0]=False
        head,rgb=data.split(b'\n',1);_,w,h,_=head.split();data=png_rgb(int(w),int(h),rgb)
    photo.tk.call(photo.name,'put',base64.b64encode(data),'-format','png','-to',x,y)


def _timed(label,since):
    """0.19.24: the time of a step of the smoothing, for lenteurs.txt (slow_log: its parts of the moment)."""
    now=time.perf_counter()
    try:
        import slow_log
        slow_log.add(label,now-since)
    except Exception:pass
    return now


def paint(canvas,icons=False):
    import tkinter as tk
    if not icons:cancel_soon(canvas)   # 0.19.30: smoothed now: one under way in the background is dropped
    renderer=backend();which='icons' if icons else 'plan'
    if renderer is None:STATUS[which]='aucun moteur (ni GDI+ ni Pillow)';return False
    try:
        width=int(float(plain(canvas.cget('width')))) if icons else canvas.winfo_width()
        height=int(float(plain(canvas.cget('height')))) if icons else canvas.winfo_height()
        if width<2 or height<2 or width*height>16000000:
            if not icons:drop_picture(canvas)
            return False
        start=time.perf_counter()
        ops,ids,keys=canvas_rows(canvas,icons);tags=()
        if not icons:
            tags=tuple(map(_tags,keys))
            if ops and all(t and t<=GUIDES for t in tags):ops=()   # 0.19.24: only the base's lines: drawn as they are
            start=_timed('lissage : lecture',start)
        if not ops:
            if not icons:drop_picture(canvas)   # 0.18.7: a picture kept by draw_cache for this pass goes
            return False
        # 0.17.0: an OPAQUE picture on the canvas colour, at the very bottom: Tk displays it at
        # once (a transparent one with thousands of antialiased lines froze Craft over a second).
        background='#'+''.join(f'{round(v/257):02x}' for v in canvas.winfo_rgb(plain(canvas.cget('background'))))
        if icons:
            signature=(width,height,background,keys);old=canvas.__dict__.get('_smooth_signature')
            if old==signature:photo=canvas._smooth_photo
            else:photo=photo_image(canvas,icon_image(width,height,ops,background));canvas._smooth_signature=signature;canvas._smooth_ops=None
            canvas.delete('_smooth_display')
            canvas.tag_lower(canvas.create_image(0,0,image=photo,anchor='nw',tags='_smooth_display'));canvas._smooth_photo=photo
            canvas.tk.call('craft_hide',canvas._w,ids);canvas._smooth_hidden=ids
            canvas.__dict__.pop('_smooth_stale',None)
            canvas._smooth_backend=renderer.name;STATUS[which]='OK ('+renderer.name+')';return True
        base=None
        if canvas.find_withtag('background_image') and canvas.itemcget('background_image','state')!='hidden':
            # 0.19.7: a background picture shown: it goes under the smoothed lines (the picture of it made last,
            # at its place on the screen); none ready (a lighter one during a gesture): the lines stay as they are.
            base=canvas.__dict__.get('_smooth_base')
            if not base or base[0]!=canvas.__dict__.get('_background_key'):drop_picture(canvas);return False
        # 0.19.25: the zones shown as they are under the picture (its empty parts show their inside); over a background
        # picture: all in the picture, as before
        zone=[False]*len(ops) if base else [op[0]=='polygon' and bool(op[2]) and bool(t) and t<=UNDER for op,t in zip(ops,tags)]
        under=[i for i,z in zip(ids,zone) if z]
        signature=(width,height,background,keys,base[0] if base else None,None);old=canvas.__dict__.get('_smooth_signature')
        made=None
        if old==signature and canvas.__dict__.get('_smooth_photo') is not None:photo=canvas._smooth_photo
        elif _patched(canvas,renderer,old,signature,ops,base[1:] if base else None) is not None:
            photo=canvas._smooth_photo;start=_timed('lissage : rendu (une partie)',start)
        else:
            canvas._smooth_patched=None
            if base:parts=[(0,0,width,height)];datas=[renderer.render(width,height,ops,background,base=base[1:])]
            else:
                parts=_ink(ops,keys,zone,width,height) if SPARSE else [(0,0,width,height)]
                if not parts:drop_picture(canvas);return False   # (nothing in sight)
                if len(parts)>MAX_PARTS or sum((x1-x0)*(y1-y0) for x0,y0,x1,y1 in parts)>DENSE*width*height:parts=[(0,0,width,height)]
                datas=renderer.render_parts(width,height,ops,background,parts)
            start=_timed('lissage : rendu',start)
            photo=_sheet(canvas,width,height);made=(parts,datas)
            canvas._smooth_parts=parts;canvas._smooth_renders=canvas.__dict__.get('_smooth_renders',0)+1   # (for the tests)
        canvas._smooth_signature=signature;canvas._smooth_ops=dict(zip(keys,ops))
        # 0.19.43 (fluidity): the picture's item kept while it shows this sheet: Tk then shows again only the parts put into it
        # and what else changed (a click on a piece: around it; before, the whole plan each time, 64 to 105 ms on his PC),
        # restacked only when it is not where it goes (craft_picture_ok)
        item=_kept_item(canvas,photo);fresh=item is None
        if fresh:
            canvas.delete('_smooth_display')
            item=canvas.create_image(0,0,image=photo,anchor='nw',tags='_smooth_display')
        if made:   # put once its item is there: Tk makes each part only
            for (x0,y0,x1,y1),data in zip(*made):_put(photo,data,x0,y0)
        if under:canvas.tk.call('craft_unhide',canvas._w,under)
        if fresh or not int(canvas.tk.call('craft_picture_ok',canvas._w,item,under,1 if base else 0)):
            canvas.tag_lower(item)
            if base:canvas.tag_lower('background_image')   # under it (seen again where the picture of the lines slides away)
            if under:canvas.tk.call('craft_over',canvas._w,under)   # the picture just over the zones: their inside shows through its empty parts
        if under:shown=set(under);ids=[i for i in ids if i not in shown]
        canvas._smooth_under=under
        canvas.tk.call('craft_hide',canvas._w,ids);canvas._smooth_hidden=ids   # shown again by show_raw
        canvas.__dict__.pop('_smooth_stale',None)
        if made:
            parts=made[0];area=sum((x1-x0)*(y1-y0) for x0,y0,x1,y1 in parts)
            _timed('lissage : image %d partie%s (%d %%)'%(len(parts),'s' if len(parts)>1 else '',round(100*area/(width*height))),start)
        canvas._smooth_backend=renderer.name;STATUS[which]='OK ('+renderer.name+')';return True
    except (OSError,ValueError,tk.TclError,OverflowError,TypeError,AttributeError,KeyError) as exc:
        STATUS[which]=f'erreur {type(exc).__name__} : {exc}'
        # Keep native geometry visible if a platform backend cannot render it.
        canvas.delete('_smooth_display');canvas.__dict__.pop('_smooth_signature',None);canvas.__dict__.pop('_smooth_hidden',None);canvas.__dict__.pop('_smooth_stale',None);canvas.__dict__.pop('_smooth_under',None)
        for identifier in locals().get('ids',[]):canvas.itemconfigure(identifier,state='normal')
        return False


def drop_picture(canvas):
    """0.18.7: no smoothed picture this time (nothing to smooth): the picture kept until this pass
    (draw_cache) goes and the lines it hid are shown."""
    cancel_soon(canvas)
    canvas.__dict__.pop('_smooth_stale',None);canvas.__dict__.pop('_smooth_under',None)
    if not canvas.find_withtag('_smooth_display'):return
    canvas.delete('_smooth_display');ids=canvas.__dict__.pop('_smooth_hidden',None)
    if ids:_procs(canvas).call('craft_show',canvas._w,ids)


def show_raw(canvas):
    """0.18.2: a move or a zoom starts: the smoothed picture (as large as the screen only) is
    removed and the lines it hid are shown again, in one Tcl call; a pending pass is dropped."""
    cancel_paint(canvas);stale_rows(canvas)   # 0.18.7: the items are going to move (0.19.30: only their coordinates read again)
    canvas.__dict__.pop('_smooth_stale',None);canvas.__dict__.pop('_smooth_under',None)
    if not canvas.find_withtag('_smooth_display'):return False
    canvas.delete('_smooth_display');ids=canvas.__dict__.pop('_smooth_hidden',None)
    if ids:_procs(canvas).call('craft_show',canvas._w,ids)
    return True


def cancel_paint(canvas):
    """Drop a pending smoothing pass (a drag or move is in progress); 0.19.30: one in the background too."""
    cancel_soon(canvas)
    token=canvas.__dict__.get('_smooth_job')
    if token:
        try:canvas.after_cancel(token)
        except Exception:pass
    canvas._smooth_job=None


def queue_paint(canvas,delay=65):
    """Keep pointer motion native/immediate; finish with AA after a short idle (``delay`` ms; a
    timer, not an idle callback: a click or a key coming meanwhile is handled first)."""
    if not canvas.__dict__.get('_smooth_destroy_bound'):
        def cancel(event):
            token=canvas.__dict__.get('_smooth_job')
            if token:
                try:canvas.after_cancel(token)
                except Exception:pass
            canvas._smooth_job=None
        canvas.bind('<Destroy>',cancel,add='+');canvas._smooth_destroy_bound=True
    old=canvas.__dict__.get('_smooth_job')
    if old:
        try:canvas.after_cancel(old)
        except Exception:pass
    def finish():
        canvas._smooth_job=None
        if canvas.winfo_exists():paint(canvas)
    canvas._smooth_job=canvas.after(delay,finish)



# 0.19.30 (« on doit faire mieux, mozart n'a pas de lag »; his lenteurs.txt: 100 to 160 ms each time the wheel stops on TILTED
# or DIFORME, 90 to 140 ms when the view is let go): the smoothing of a view that moved is made in the background. Tk reads
# the lines (one call, read_plan); a worker thread makes the picture (rows_of, ink_parts, the renderer: no call to Tk); Tk
# then puts it into the spare sheet, hidden, in slices of SLICE s (the mouse and the wheel handled between two), and shows
# it with the lines it covers hidden once all of it is in, if the lines are still the same (read again: else made again).
# A notch, a move of the view, a drawing smoothed at once, a picture dropped: the work goes (cancel_soon; the worker stops
# within 32 lines). Meanwhile Tk shows the lines, as during the gesture (or the picture kept: ``hide``).
import threading
SLICE=.004      # s of Tk's time for each slice of the picture put into its sheet
POLL=3          # ms between two looks at the worker
BAND=96*1024    # pixels: a larger part of the picture is put in bands (a slice each at most)
AGAIN=3         # times the work is made again when the lines changed while it was made (then: at once, paint)
SWITCH=.0005    # s: Python's switch between threads while the worker works (5 ms otherwise: Tk would wait for it)
_HEX=__import__('re').compile(r'#[0-9a-fA-F]{6}')
_QUEUE=[]
_IDLE=threading.Event();_IDLE.set()   # (review) the worker not in the middle of a picture
_CLOSING=[False]
_SWITCHING=[0,None,threading.Lock()]   # (0.19.49) works asking for the short switch, the interval before the first one


class fast_switch:
    """(0.19.49) Python's switch between threads at SWITCH while a worker works (this picture, a DWG Mozart written by
    advanced_ui.wait_for_work): Tk's thread waits 0,5 ms at most for each of its calls, never 5 ms (a window created at
    the start of the save waited 170 ms). Counted: the interval of before given back when the last one ends (two works
    at once never leave it short, nor long while one goes on)."""
    def __enter__(self):
        with _SWITCHING[2]:
            if not _SWITCHING[0]:_SWITCHING[1]=sys.getswitchinterval();sys.setswitchinterval(SWITCH)
            _SWITCHING[0]+=1
        return self
    def __exit__(self,*exc):
        with _SWITCHING[2]:
            _SWITCHING[0]-=1
            if not _SWITCHING[0]:sys.setswitchinterval(_SWITCHING[1])
        return False


class _Work:
    """What the worker thread sees of a smoothing in the background (review: never a Tk object: the last reference to one,
    dropped in that thread, deleted it from there: a crash, but for bootstrap.tk_main_thread)."""
    __slots__=('cancelled','event','out','error','times')
    def __init__(self):
        self.cancelled=False;self.event=threading.Event();self.out=None;self.error=None;self.times={}


class _Soon:
    """A smoothing in the background, as Tk's side keeps it (its canvas, its sheet, its item, its slices)."""
    __slots__=('canvas','work','token','photo','item','k','spare','read','again','hide','drawn')
    def __init__(self,canvas):
        self.canvas=canvas;self.work=_Work();self.token=None
        self.photo=None;self.item=None;self.k=0;self.spare=None;self.read=None;self.again=0;self.hide=False;self.drawn=None
    @property
    def cancelled(self):return self.work.cancelled
    @cancelled.setter
    def cancelled(self,value):self.work.cancelled=value
    @property
    def event(self):return self.work.event
    @property
    def out(self):return self.work.out
    @property
    def error(self):return self.work.error
    @property
    def times(self):return self.work.times


def _wanted(canvas):
    """(review) the app still wants a smoothed plan (advanced_ui.smoothing_wanted: « Plan lissé » on, the plan shown)."""
    w=canvas.__dict__.get('_soon_wanted')
    try:return w is None or bool(w())
    except Exception:return False


def _size(canvas):
    try:return (canvas.winfo_width(),canvas.winfo_height())
    except Exception:return None


def busy(canvas):
    """0.19.30: a smoothing under way in the background."""
    return canvas.__dict__.get('_soon') is not None


def cancel_soon(canvas):
    """0.19.30: a smoothing in the background dropped (its worker stops; its slices never come)."""
    job=canvas.__dict__.pop('_soon',None)
    if job is None:return
    job.cancelled=True
    if job.token:
        try:canvas.after_cancel(job.token)
        except Exception:pass
        job.token=None
    if job.item:
        try:canvas.delete(job.item)
        except Exception:pass
        job.item=None


def _worker(queue):
    while True:
        work,args=queue.get()   # (a _Work: nothing of Tk)
        if work.cancelled or _CLOSING[0]:work.event.set();work=args=None;continue
        _IDLE.clear()
        try:
            with fast_switch():_work(work,*args)
        finally:_IDLE.set()
        work=args=None   # (nothing of the last job kept while the next one is awaited)


def _closing():
    """(review) Craft closing: the picture under way dropped, and awaited (at most 2 s): GDI+ is shut down after it
    (atexit, the last registered first), never in the middle of one of its calls."""
    _CLOSING[0]=True
    _IDLE.wait(2.)


def _submit(job,args):
    if not _QUEUE:
        import queue
        q=queue.SimpleQueue();_QUEUE.append(q)
        __import__('atexit').register(_closing)   # (after GDI+'s own: called before it)
        threading.Thread(target=_worker,args=(q,),daemon=True,name='craft-lissage').start()
    _QUEUE[0].put((job,args))


def _banded(parts,width):
    """A part larger than BAND pixels in bands across it (each put in one slice)."""
    out=[]
    for x0,y0,x1,y1 in parts:
        w=x1-x0;h=y1-y0
        if w*h<=BAND or h<2:out.append((x0,y0,x1,y1));continue
        step=max(1,BAND//max(1,w))
        for y in range(y0,y1,step):out.append((x0,y,x1,min(y1,y+step)))
    return out


def _work(job,renderer,read,known,colours,width,height,background):
    """In the worker thread: the picture of ``read`` as paint makes it (no call to Tk; a colour not met yet: 'colours');
    ``job``: the _Work of the smoothing."""
    try:
        start=time.perf_counter();unknown=set()
        def colour(value):
            if not value:return ''
            v=colours.get(value)
            if v is None:
                if _HEX.fullmatch(value):v=value.lower()
                else:unknown.add(value);v='#000000'
            return v
        ops,ids,keys,seen=rows_of(read[0],read[1],known,colour)
        if unknown:job.out=('colours',unknown);return
        tags=tuple(map(_tags,keys))
        if ops and all(t and t<=GUIDES for t in tags):ops=()   # (only the base's lines: drawn as they are)
        if not ops:job.out=('none',seen);return
        zone=[op[0]=='polygon' and bool(op[2]) and bool(t) and t<=UNDER for op,t in zip(ops,tags)]
        parts=_ink(ops,keys,zone,width,height) if SPARSE else [(0,0,width,height)]
        if not parts:job.out=('none',seen);return
        if len(parts)>MAX_PARTS or sum((x1-x0)*(y1-y0) for x0,y0,x1,y1 in parts)>DENSE*width*height:parts=[(0,0,width,height)]
        area=sum((x1-x0)*(y1-y0) for x0,y0,x1,y1 in parts);shown=_banded(parts,width)
        if job.cancelled:return
        made=time.perf_counter();job.times['parties']=made-start
        datas=renderer.render_parts(width,height,ops,background,shown,lambda:job.cancelled or _CLOSING[0])
        job.times['rendu']=time.perf_counter()-made
        job.out=('picture',ops,ids,keys,seen,zone,parts,shown,datas,area)
    except Stopped:pass
    except Exception as exc:job.error=exc
    finally:job.event.set()


def paint_soon(canvas,hide=False,again=0):
    """0.19.30: the plan's smoothing in the background (see above); True when under way (or done: paint, when it cannot be:
    no engine, a background picture under the lines, a size out of range). ``hide``: the lines just drawn hidden at once,
    the picture shown kept until the new one comes (full_settle: no flash of raw lines)."""
    import tkinter as tk
    cancel_soon(canvas)
    renderer=backend()
    try:
        if renderer is None or canvas.find_withtag('background_image') and canvas.itemcget('background_image','state')!='hidden':
            return paint(canvas)
        width=canvas.winfo_width();height=canvas.winfo_height()
        if width<2 or height<2 or width*height>16000000:return paint(canvas)
        hide=hide and bool(canvas.find_withtag('_smooth_display'))
        if not canvas.__dict__.get('_soon_destroy_bound'):   # (review: a window built again: its work dropped with its canvas)
            canvas.bind('<Destroy>',lambda e,c=canvas:cancel_soon(c) if str(e.widget)==c._w else None,add='+');canvas._soon_destroy_bound=True
        job=_Soon(canvas);job.again=again;job.hide=hide;canvas._soon=job
        start=time.perf_counter()
        read=read_plan(canvas);job.read=read
        background='#'+''.join(f'{round(v/257):02x}' for v in canvas.winfo_rgb(plain(canvas.cget('background'))))
        if hide:   # the lines just drawn under the picture kept (zones stay: they show under it), as the new one leaves them
            ids=[];under=[]
            for row in read[0].split('\x1e') if read[0] else ():
                item,kind,tags,fill=row.split('\x1f',4)[:4]
                (under if kind=='polygon' and fill and tags and set(tags.split('\x1d'))<=UNDER else ids).append(int(item))
            tk_=_procs(canvas)
            if under:tk_.call('craft_over',canvas._w,under)
            tk_.call('craft_hide',canvas._w,ids);canvas._smooth_hidden=ids;canvas._smooth_under=under
        job.spare=(width,height,background)
        _submit(job.work,(renderer,read,canvas.__dict__.get('_ops_known') or {},dict(canvas.__dict__.setdefault('_rgb_names',{})),width,height,background))
        _timed('lissage en fond : lecture',start)
        job.token=canvas.after(POLL,_poll,job)
        return True
    except (OSError,ValueError,tk.TclError,TypeError,AttributeError) as exc:
        canvas.__dict__.pop('_soon',None);STATUS['plan']=f'erreur {type(exc).__name__} : {exc}'
        return paint(canvas)


def _poll(job):
    """The worker done: its picture put into the spare sheet (in slices), if Tk still shows the same lines."""
    import tkinter as tk
    canvas=job.canvas;job.token=None
    if job.cancelled or canvas.__dict__.get('_soon') is not job:return
    if not job.event.is_set():
        try:job.token=canvas.after(POLL,_poll,job)
        except tk.TclError:canvas.__dict__.pop('_soon',None)
        return
    try:
        if not _wanted(canvas):   # (review: « Plan lissé » turned off, a fiche shown meanwhile)
            canvas.__dict__.pop('_soon',None)
            if job.hide:drop_picture(canvas)
            return
        if job.error is not None:raise job.error
        if job.out is None:raise ValueError('lissage arrêté')
        kind=job.out[0]
        if kind=='colours':   # a colour not met yet: Tk names it, then the work again
            names=canvas.__dict__.setdefault('_rgb_names',{})
            for value in job.out[1]:names[value]='#'+''.join(f'{round(v/257):02x}' for v in canvas.winfo_rgb(value))
            canvas._soon=None;paint_soon(canvas,job.hide,job.again);return
        if kind=='none':
            canvas._soon=None;canvas._ops_known=job.out[1];drop_picture(canvas);return
        start=time.perf_counter()
        if read_plan(canvas)!=job.read or _size(canvas)!=job.spare[:2]:   # (the lines changed meanwhile (review: or the size): the work again, a few times, then at once)
            canvas._soon=None
            if job.again<AGAIN:paint_soon(canvas,False,job.again+1)
            else:paint(canvas)
            return
        width,height,background=job.spare
        photo=canvas.__dict__.get('_spare_sheet')
        if photo is None or canvas.__dict__.get('_spare_size')!=(width,height) or photo is canvas.__dict__.get('_smooth_photo'):
            photo=tk.PhotoImage(master=canvas,width=width,height=height)
        else:canvas.tk.call(photo.name,'blank')
        job.photo=photo;job.item=canvas.create_image(0,0,image=photo,anchor='nw',tags='_smooth_next',state='hidden')
        job.k=0;job.drawn=canvas.__dict__.get('_drawn_count')   # (review: a drawing of the plan while it is put in: dropped)
        _timed('lissage en fond : vérification',start)
        job.token=canvas.after(1,_slice,job)
    except (OSError,ValueError,tk.TclError,OverflowError,TypeError,AttributeError,KeyError,IndexError,RuntimeError,MemoryError) as exc:
        canvas.__dict__.pop('_soon',None);STATUS['plan']=f'erreur {type(exc).__name__} : {exc}'
        paint(canvas)


def _slice(job):
    """A slice of the picture put into its sheet; the last one shows it (the lines it covers hidden)."""
    import tkinter as tk
    canvas=job.canvas;job.token=None
    if job.cancelled or canvas.__dict__.get('_soon') is not job:return
    try:
        _,ops,ids,keys,seen,zone,parts,shown,datas,area=job.out
        start=time.perf_counter();end=start+SLICE
        while job.k<len(shown):
            x0,y0,x1,y1=shown[job.k];_put(job.photo,datas[job.k],x0,y0);job.k+=1
            if time.perf_counter()>end:break
        if job.k<len(shown):
            _timed('lissage en fond : image',start)
            job.token=canvas.after(1,_slice,job);return
        width,height,background=job.spare
        if not _wanted(canvas) or _size(canvas)!=(width,height) or canvas.__dict__.get('_drawn_count')!=job.drawn:
            # (review) « Plan lissé » off or a fiche shown, the window resized, the plan drawn again (its own smoothing
            # comes with it): never shown
            canvas.delete(job.item);job.item=None;canvas.__dict__.pop('_soon',None)
            if not _wanted(canvas):
                if job.hide:drop_picture(canvas)
            elif _size(canvas)!=(width,height) and canvas.__dict__.get('_drawn_count')==job.drawn:
                if job.again<AGAIN:paint_soon(canvas,job.hide,job.again+1)
                else:paint(canvas)
            return
        old=canvas.__dict__.get('_smooth_photo');old_size=canvas.__dict__.get('_smooth_sheet')
        canvas.delete('_smooth_display')
        item=job.item;job.item=None
        canvas.dtag(item,'_smooth_next');canvas.addtag_withtag('_smooth_display',item)
        canvas.itemconfigure(item,state='normal');canvas.tag_lower(item)
        under=[i for i,z in zip(ids,zone) if z]
        if under:   # (the picture just over the zones: their inside shows through its empty parts)
            canvas.tk.call('craft_over',canvas._w,under);inside=set(under);hide=[i for i in ids if i not in inside]
        else:hide=list(ids)
        canvas.tk.call('craft_hide',canvas._w,hide)
        canvas._smooth_under=under;canvas._smooth_hidden=hide
        canvas._smooth_photo=job.photo;canvas._smooth_sheet=(width,height)
        if old is not None and old is not job.photo and old_size==(width,height):
            canvas._spare_sheet=old;canvas._spare_size=(width,height)   # (the next one is made in it: two sheets in all)
        canvas._smooth_signature=(width,height,background,keys,None,None);canvas._smooth_ops=dict(zip(keys,ops));canvas._ops_known=seen
        canvas.__dict__.pop('_smooth_stale',None);canvas._smooth_patched=None
        canvas._smooth_parts=parts;canvas._smooth_renders=canvas.__dict__.get('_smooth_renders',0)+1;canvas._smooth_soon=canvas.__dict__.get('_smooth_soon',0)+1
        canvas._soon=None
        renderer=backend();canvas._smooth_backend=renderer.name;STATUS['plan']='OK ('+renderer.name+', en fond)'
        _timed('lissage en fond : image %d partie%s (%d %%), rendu %d ms'%(len(parts),'s' if len(parts)>1 else '',round(100*area/(width*height)),round(1000*job.times.get('rendu',0))),start)
    except (OSError,ValueError,tk.TclError,OverflowError,TypeError,AttributeError,KeyError,IndexError,MemoryError) as exc:
        canvas.__dict__.pop('_soon',None);STATUS['plan']=f'erreur {type(exc).__name__} : {exc}'
        try:canvas.delete('_smooth_next')
        except tk.TclError:pass
        paint(canvas)


def finish_soon(canvas,timeout=10.):
    """0.19.30: a smoothing in the background done now (the tests); False when none was under way."""
    done=False
    for _ in range(AGAIN+3):
        job=canvas.__dict__.get('_soon')
        if job is None:break
        done=True
        job.event.wait(timeout)
        if job.token:
            try:canvas.after_cancel(job.token)
            except Exception:pass
            job.token=None
        if job.photo is None:_poll(job)
        while canvas.__dict__.get('_soon') is job and job.photo is not None:
            if job.token:
                try:canvas.after_cancel(job.token)
                except Exception:pass
                job.token=None
            _slice(job)
    return done
