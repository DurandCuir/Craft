"""Craft 0.3 desktop workspace and keyboard-first construction."""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser
import copy
import json
import math
from pathlib import Path
from geometry import number, path, bounds, export_svg, clone
from cad import default_workspace, validate_workspace, guide_segments, snap_point, object_anchors, directed, construct, polygon, write_document, LABELS, SNAPS
from ui_widgets import IconButton, auto_palette, contrast_color, forget_zoom_marks, show_error
import modern_style
from exchange import export_dwg
import threading
import queue

from craft_version import VERSION
from app_preferences import DEFAULTS, read_preferences as load_preferences
from app_paths import settings_path
TOOLS={
 'select':'Sélection', 'delete':'Supprimer · cliquez un tracé', 'line':'Ligne', 'poly':'Contour point par point',
 'rect':'Rectangle (2 coins)', 'rect_center':'Rectangle (centré)',
 'rect_round':'Rectangle (arrondi)', 'rect_rot':'Rectangle (orienté)',
 'para':'Parallélogramme',
 'circle_radius':'Cercle (rayon)', 'circle_diameter':'Cercle (diamètre)',
 'circle_2p':'Cercle (2 points)','circle_3p':'Cercle (3 points)'}
SNAP_NAMES=dict(endpoint='Extrémités',midpoint='Milieux',quarter='Quarts',center='Centres',intersection='Intersections',
                quadrant='Quadrants',nearest='Point le plus proche',guides='Repères de base',
                extension='Extension',perpendicular='Perpendiculaire',tangent='Tangente',parallel='Parallèle',centroid='Centre géométrique',node='Nœud')   # 0.19.13
THREE=('rect_rot','para','circle_3p')
GRIP_LIMIT=100   # 0.19.0, like AutoCAD's GRIPOBJLIMIT: more objects selected than this, no grips (grips_shown)


def read_preferences():
    # Keep the public hook for integrations and tests; validation has one owner.
    return load_preferences(settings_path())


def create_app(Base):
    class Studio(Base):
        def __init__(self):
            from craft_brand import set_process_identity, install_window_icon
            set_process_identity()
            tk.Tk.__init__(self)
            install_window_icon(self)
            self.title(f'Craft {VERSION}');self.geometry('1440x900');self.minsize(1000,680)
            self.prefs=auto_palette(read_preferences());self.p=self.prefs
            modern_style.apply(self,self.p)   # 0.19.0: colours, font, rounded widgets, message windows, title bar
            self.configure(bg=self.p['panel'])
            self.items=[];self.selected=None;self.filename=None;self.clean=[]
            self.workspace=default_workspace('maro');self.clean_workspace=copy.deepcopy(self.workspace)
            self.undo_stack=[];self.redo_stack=[]
            self.scale=.3;self.ox=30;self.oy=30
            self.start=None;self.pending=[];self.stage_points=[];self.numeric_width=None
            self.drag=None;self.pan=None;self.press_start=None;self.mouse_started=False
            self.pointer_world=(100,100);self.last_direction=(1,0);self.snap_marker=None
            self.cursor_screen=(100,100);self.last_command=None;self.export_busy=False
            self.tool=tk.StringVar(value='select');self.grid=tk.BooleanVar(value=self.p['grid'])
            self.snap=tk.BooleanVar(value=True);self.ortho=tk.BooleanVar(value=self.p['ortho'])
            self.spacing=tk.StringVar(value='1');self.status=tk.StringVar(value='Prêt · dessin en millimètres')
            self.hint=tk.StringVar(value='Choisir un outil à gauche · F8 orthogonal · F3 ancrages')
            self.command_value=tk.StringVar(value='');self.mode_label=tk.StringVar(value=TOOLS['select'])
            self.snap_vars={k:tk.BooleanVar(value=k in self.p['snaps']) for k in SNAPS}
            self.fields={k:tk.StringVar(value=v) for k,v in dict(name='Pièce',x='0',y='0',w='100',h='60',r='5').items()}
            self.length_var=tk.StringVar(value='100');self.angle_var=tk.StringVar(value='0')
            self.quickbar_open=False;self.units=tk.StringVar(value=self.prefs['units']);self.last_unit=self.units.get();
            if self.units.get()=='cm':
                self.length_var.set('10')
                for key,var in self.fields.items():
                    if key!='name':var.set(f'{number(var.get())/10:g}')
            self.panel_open=False;self.position_open=False;self.rebuilding=False;self.name_list_indices=[]
            self.before_build();self.build()
            # 0.19.9: with Caps Lock on too (Tk then gives the capital letter: Ctrl+S did nothing); Windows gives the small
            # letter for Caps Lock + Maj, hence <Control-Shift-s> for « Enregistrer sous ».
            for key in ('<Control-s>','<Control-S>'):self.bind(key,lambda e:self.save_doc())
            for key in ('<Control-Shift-S>','<Control-Shift-s>'):self.bind(key,lambda e:self.save_as())
            for key in ('<Control-o>','<Control-O>'):self.bind(key,lambda e:self.open_doc())
            for key in ('<Control-n>','<Control-N>'):self.bind(key,lambda e:self.new_doc())
            for key in ('<Control-p>','<Control-P>'):self.bind(key,lambda e:(self.pdf(),'break')[1])   # 0.18.0: print
            for key in ('<Control-z>','<Control-Z>'):self.bind(key,lambda e:self.undo())
            for key in ('<Control-y>','<Control-Y>'):self.bind(key,lambda e:self.redo())
            # (Maj held gives the same letters: Ctrl+Maj+Z, Y, N, O stay without effect, as before, Verr. Maj or not)
            for key in ('<Control-Shift-Z>','<Control-Shift-Y>','<Control-Shift-N>','<Control-Shift-O>'):
                self.bind(key,lambda e:'break');self.bind(key.replace(key[-2],key[-2].lower()),lambda e:'break')
            self.bind('<F8>',self.toggle_ortho);self.bind('<F3>',self.toggle_snap)
            self.bind('<F7>',self.toggle_grid);self.bind('<F4>',lambda e:self.toggle_panel())
            self.bind('<Escape>',lambda e:self.escape())
            self.bind('<KeyPress>',self.key_input)
            self.bind('<space>',self.space_command)
            self.bind('<Return>',self.root_enter)
            self.command_value.trace_add('write',lambda *a:self.command_preview())
            self.protocol('WM_DELETE_WINDOW',self.close);self.report_callback_exception=self.error
            self.after(120,lambda:(self.fit_workspace(),self.canvas.focus_set()))

        def button(self,parent,text,fn,**kwargs):
            # 0.19.0: rounded and flat; the main action of a window (Valider, Appliquer, Imprimer…) in the accent colour.
            kwargs.setdefault('cursor','arrow')
            return modern_style.make_button(parent,text=text,command=fn,font=modern_style.font(10),**kwargs)

        def label(self,parent,text=None,**kw):
            options=dict(text=text,bg=self.p['panel'],fg=modern_style.tokens_for(self.p)['text'],font=modern_style.font(10))
            options.update(kw)
            return tk.Label(parent,**options)

        def field_background(self):return modern_style.tokens_for(self.p)['field']   # 0.19.0: the modern field colours
        def field_border(self):return modern_style.tokens_for(self.p)['field_border']
        def entry(self,parent,var,width=None):
            options=modern_style.field(modern_style.tokens_for(self.p));options.pop('disabledbackground',None)
            return tk.Entry(parent,textvariable=var,width=width,**options)

        def menu(self,parent=None):
            return tk.Menu(parent or self,tearoff=False,**modern_style.menu_options(modern_style.tokens_for(self.p)))

        def cget(self,key):
            # 0.19.0: the menu bar is drawn by Craft (modern_style.MenuStrip); its tk.Menu is still found here.
            if key=='menu' and self.__dict__.get('_menu_model') is not None:return str(self._menu_model)
            return super().cget(key)
        __getitem__=cget

        def icon(self,parent,name,fn,tip,dropdown=False,side='left'):
            b=IconButton(parent,name,fn,tip,self.p,self.p['icon_size'],dropdown,self.status)
            b.pack(side=side,padx=2,pady=2);return b

        def before_build(self):
            """0.19.5: what the layers set before the window is built (fonts, the user's toolbar layout…):
            the window is built once (it was built twice at each start)."""
        def build(self):
            p=self.p;self.configure(bg=p['panel'])
            # Native menu bar keeps conventional shortcuts discoverable.
            menubar=self.menu()
            file=self.menu(menubar)
            # 0.18.0: one « Nouveau » with its three starts, « Récents », « Imprimer… Ctrl+P ».
            new=self.menu(file);self.new_menu=new
            self.rebuild_new_menu()   # 0.19.13: the base profiles too
            file.add_cascade(label='Nouveau',menu=new)
            file.add_command(label='Ouvrir…  Ctrl+O',command=self.open_doc)
            self.recent_menu=self.menu(file);file.add_cascade(label='Récents',menu=self.recent_menu)
            file.add_command(label='Enregistrer  Ctrl+S',command=self.save_doc)
            file.add_command(label='Enregistrer sous…',command=self.save_as)
            exports=self.menu(file)
            for label,fn in [('PDF à taille réelle…',self.pdf),('SVG…',self.svg),('DXF…',self.dxf),('DWG…',self.dwg)]:
                exports.add_command(label=label,command=fn)
            file.add_cascade(label='Exporter',menu=exports)
            file.add_command(label='Imprimer…  Ctrl+P',command=self.pdf)
            file.add_command(label='Quitter',command=self.close)
            menubar.add_cascade(label='Fichier',menu=file)
            if hasattr(self,'rebuild_recent_menu'):self.rebuild_recent_menu()
            edit=self.menu(menubar)
            for title,fn in [('Annuler  Ctrl+Z',self.undo),('Rétablir  Ctrl+Y',self.redo),
                             ('Dupliquer la sélection',self.duplicate),('Supprimer la sélection',self.delete),
                             ('Terminer le contour ouvert',lambda:self.finish_poly(False)),('Fermer le contour',lambda:self.finish_poly(True))]:
                edit.add_command(label=title,command=fn)
            menubar.add_cascade(label='Édition',menu=edit)
            view=self.menu(menubar)
            view.add_command(label='Couleurs et taille des icônes…',command=self.preferences_dialog)
            view.add_command(label='Pièces et dimensions  F4',command=self.toggle_panel)
            view.add_checkbutton(label='Grille  F7',variable=self.grid,command=self.view_change)
            view.add_command(label='Afficher / masquer les repères jaunes',command=self.toggle_guides)
            framing=self.menu(view)
            framing.add_command(label='Cadrer les tracés',command=self.fit)
            framing.add_command(label='Cadrer la base',command=self.fit_workspace)
            view.add_cascade(label='Cadrage',menu=framing)
            bars=self.menu(view)
            bars.add_command(label='Afficher / masquer les raccourcis de fichiers',command=self.toggle_quickbar)
            view.add_cascade(label='Barres d’outils',menu=bars)
            menubar.add_cascade(label='Affichage',menu=view)
            params=self.menu(menubar)
            params.add_command(label='Colonnes et hauteur de la base…',command=self.workspace_dialog)
            # 0.16.26: base lines have the drawing-line thickness; no separate setting.
            unitsmenu=self.menu(params)
            for unit,label in [('mm','Millimètres (mm)'),('cm','Centimètres (cm)')]:
                unitsmenu.add_radiobutton(label=label,variable=self.units,value=unit,command=self.unit_change)
            params.add_cascade(label='Unités de saisie et dimensions',menu=unitsmenu)
            params.add_command(label='Types de lignes…',command=lambda:self.edit_line_types())
            params.add_command(label='Curseur…',command=lambda:self.crosshair_dialog())
            params.add_command(label='Mon profil d’interface…',command=lambda:self.interface_profile_dialog())
            params.add_command(label='Pas de la grille…',command=self.grid_dialog)
            params.add_checkbutton(label='Orthogonal  F8',variable=self.ortho,command=self.settings_changed)
            menubar.add_cascade(label='Réglages',menu=params)
            helpmenu=self.menu(menubar)
            helpmenu.add_command(label='Mode d’emploi',command=self.help)
            helpmenu.add_command(label='Mettre à jour Craft depuis un ZIP…',command=self.update_from_zip)
            helpmenu.add_separator();helpmenu.add_command(label='Version '+VERSION,state='disabled')
            menubar.add_cascade(label='Aide',menu=helpmenu);self._menu_model=menubar
            self.root_frame=tk.Frame(self,bg=p['panel']);self.root_frame.pack(fill='both',expand=True)
            # 0.19.0: the menu bar drawn in the panel colour (the Windows one stayed white over a dark Craft).
            self.menu_strip=modern_style.make_strip(self.root_frame,menubar);self.menu_strip.pack(fill='x')
            # One compact contextual row; drawing tools only live on the left rail.
            header=tk.Frame(self.root_frame,bg=p['panel']);self.header=header;header.pack(fill='x',padx=9,pady=2)
            # Application name is already in the window title.
            self.unit_label=self.label(header,text=self.units.get());self.unit_label.pack(side='right',padx=8)
            self.quickbar=tk.Frame(self.root_frame,bg=p['panel'])
            for name,fn,tip in [('open',self.open_doc,'Ouvrir · Ctrl+O'),('save',self.save_doc,'Enregistrer · Ctrl+S'),
                                ('pdf',self.pdf,'PDF à taille réelle'),('undo',self.undo,'Annuler'),('redo',self.redo,'Rétablir')]:
                self.icon(self.quickbar,name,fn,tip)
            if self.quickbar_open:self.quickbar.pack(fill='x',padx=8,pady=1)
            body=tk.Frame(self.root_frame,bg=p['panel']);self.body=body;body.pack(fill='both',expand=True)
            rail=tk.Frame(body,bg=p['panel']);self.rail=rail;rail.pack(side='left',fill='y',padx=(5,4))
            self.icon(rail,'select',lambda:self.set_tool('select'),'Sélection · clic sur le bord',side='top')
            self.icon(rail,'line',lambda:self.group_menu('lines'),'Lignes et contours ▾',True,side='top')
            self.icon(rail,'rect',lambda:self.group_menu('rectangles'),'Rectangles et parallélogrammes ▾',True,side='top')
            self.icon(rail,'circle',lambda:self.group_menu('circles'),'Cercles · choix de construction ▾',True,side='top')
            self.side=tk.Frame(body,bg=p['panel'],width=265)
            self.make_side_panel()
            if self.panel_open:self.side.pack(side='right',fill='y',padx=10)
            self.side.pack_propagate(False)
            self.canvas=tk.Canvas(body,bg=p['canvas'],highlightthickness=0,cursor='arrow' if self.tool.get()=='select' else 'crosshair')
            self.canvas.pack(side='left',fill='both',expand=True)
            cmd=tk.Frame(self.root_frame,bg=p['panel']);self.command_frame=cmd;cmd.pack(fill='x',padx=12,pady=(7,5))
            self.label(cmd,'Dimension ('+self.units.get()+')',fg=p['accent']).pack(side='left',padx=(0,8))
            self.command_entry=self.entry(cmd,self.command_value,width=22);self.command_entry.pack(side='left',ipady=5)
            self.command_entry.bind('<Return>',self.enter_dimension)
            foot=tk.Frame(self.root_frame,bg=p['panel']);self.footer=foot;foot.pack(fill='x',padx=12,pady=(0,7))
            self.ortho_button=self.button(foot,'',self.toggle_ortho);self.ortho_button.pack(side='right',padx=4)
            self.snap_button=self.button(foot,'',self.toggle_snap);self.snap_button.pack(side='right',padx=4)
            self.button(foot,'Ancrages ▾',self.snap_menu).pack(side='right',padx=4)
            self.icon(foot,'gear',self.display_menu,'Affichage de la base ▾',side='right')
            self.bind_canvas();self.update_toggle_labels()

        def make_side_panel(self):
            s=self.side
            self.label(s,'PIÈCES & DIMENSIONS · '+self.units.get(),font=modern_style.font(9,'bold'),fg=modern_style.tokens_for(self.p)['muted']).pack(anchor='w',pady=10)
            self.list=tk.Listbox(s,height=7,exportselection=False,**modern_style.listing(modern_style.tokens_for(self.p)))
            self.list.pack(fill='x');self.list.bind('<<ListboxSelect>>',self.list_pick)
            self.label(s,'Nom').pack(anchor='w',pady=(12,2));self.entry(s,self.fields['name']).pack(fill='x',ipady=4)
            self.line_frame=tk.Frame(s,bg=self.p['panel'])
            for label,var in [('Longueur ('+self.units.get()+')',self.length_var),('Angle (°)',self.angle_var)]:
                self.label(self.line_frame,label).pack(anchor='w',pady=(8,2));self.entry(self.line_frame,var).pack(fill='x',ipady=4)
            self.dim_frame=tk.Frame(s,bg=self.p['panel']);self.dim_frame.pack(fill='x')
            for key,title in [('w','Largeur X / diamètre ('+self.units.get()+')'),('h','Longueur Y ('+self.units.get()+')'),('r','Rayon des coins ('+self.units.get()+')')]:
                self.label(self.dim_frame,title).pack(anchor='w',pady=(8,2));self.entry(self.dim_frame,self.fields[key]).pack(fill='x',ipady=4)
            self.button(s,'Appliquer à la sélection',self.apply).pack(fill='x',pady=10)
            self.button(s,'Position avancée ▾',self.toggle_positions).pack(fill='x')
            self.position_frame=tk.Frame(s,bg=self.p['panel'])
            for key in ('x','y'):
                self.label(self.position_frame,f'Position {key.upper()} ({self.units.get()})').pack(anchor='w');self.entry(self.position_frame,self.fields[key]).pack(fill='x',ipady=4,pady=2)
            if self.position_open:self.position_frame.pack(fill='x')
            self.side_close=tk.Canvas(self.body,width=20,height=22,bg=self.p['panel'],highlightthickness=0,cursor='arrow')
            self.side_close.create_line(6,7,14,15,fill=self.p['ui_ink'],width=1.4);self.side_close.create_line(14,7,6,15,fill=self.p['ui_ink'],width=1.4)
            self.side_close.bind('<Button-1>',lambda e:self.toggle_panel())
            if self.panel_open:self.after_idle(self.show_side_close)

        def bind_canvas(self):
            c=self.canvas;c.bind('<Configure>',lambda e:self.redraw())
            c.bind('<Button-1>',self.down);c.bind('<B1-Motion>',self.motion);c.bind('<ButtonRelease-1>',self.up)
            c.bind('<Motion>',self.motion);c.bind('<Double-Button-1>',self.double)
            c.bind('<MouseWheel>',self.zoom);c.bind('<Button-4>',lambda e:self.zoom(e,1.15));c.bind('<Button-5>',lambda e:self.zoom(e,1/1.15))
            for b in (2,):
                c.bind(f'<Button-{b}>',self.pan_start);c.bind(f'<B{b}-Motion>',self.pan_move)
            c.bind('<Delete>',lambda e:self.delete());c.bind('<Return>',self.enter_dimension)

        def update_from_zip(self,file=None):
            # 0.19.15: ``file``, an update already downloaded and checked (online_update, « Redémarrer »): no
            # window to choose it and no question (the notice asked).
            from app_paths import is_frozen
            if is_frozen():
                messagebox.showinfo('Mise à jour Craft', 'Cette édition se met à jour avec le nouvel installateur Craft. Fermez Craft puis lancez le nouvel installateur. Les ZIP de sources concernent uniquement l’édition Python.');return
            if getattr(self,'export_busy',False):
                messagebox.showinfo('Mise à jour','Attendez la fin de la conversion DWG.');return
            if not self.guard():return
            asked=file is None
            if asked:file=filedialog.askopenfilename(title='Choisir le nouveau ZIP Craft',filetypes=[('Mise à jour Craft (*.zip)','*.zip')])
            if not file:return
            from updater import read_bundle,start_update,check_edition
            try:
                manifest,_=read_bundle(file)
                check_edition(Path(__file__).resolve().parent,manifest['files'])   # 0.19.15: never the other edition
                answer=not asked or messagebox.askokcancel('Mise à jour Craft',
                    'Version actuelle : '+VERSION+'\nNouvelle version : '+manifest['version']+
                    '\n\nCraft va fermer, se mettre à jour puis rouvrir.\nVos préférences et patrons seront conservés.')
                if not answer:return
                import sys
                start_update(file,Path(__file__).resolve().parent,sys.executable,self.filename)
                self.destroy()
            except Exception as exc:messagebox.showerror('Mise à jour Craft',str(exc))

        def complete_command(self,name,action=False):
            self.last_command=('action' if action else 'tool',name)
            self.start=None;self.pending=[];self.stage_points=[];self.numeric_width=None
            self.mouse_started=False;self.snap_marker=None;self.command_value.set('')
            self.tool.set('select');self.mode_label.set(TOOLS['select'])
            self.canvas.configure(cursor='arrow');self.canvas.focus_set();self.set_hint()

        def repeat_last(self,e=None):
            command=getattr(self,'last_command',None)
            if not command:self.status.set('Choisissez d’abord une commande.');return 'break'
            category,name=command
            if category=='tool':self.set_tool(name)
            elif name in ('delete','duplicate','apply','undo','redo'):
                getattr(self,name)()
            return 'break'

        def root_enter(self,e=None):
            if self.focus_get() in (self.canvas,self.command_entry):return self.enter_dimension(e)

        def space_command(self,e=None):
            # 0.16.31: Espace = Entrée on the plan and the command line (validate a value or a
            # selection, finish a polyline or a series tool, repeat the last command).
            if self.focus_get() not in (self.canvas,self.command_entry):return None
            return self.enter_dimension(e)

        def delete(self):
            self.last_command=('action','delete')
            if self.selected is None:
                self.cancel();self.tool.set('delete');self.mode_label.set(TOOLS['delete']);self.set_hint();self.canvas.focus_set()
                return
            Base.delete(self);self.complete_command('delete',True);self.refresh()

        def duplicate(self):
            if self.selected is None:self.status.set('Sélectionnez un tracé à dupliquer.');return
            Base.duplicate(self);self.complete_command('duplicate',True);self.refresh()

        def draw_input_bubble(self):
            if not hasattr(self,'canvas'):return
            c=self.canvas;c.delete('input_bubble')
            t=self.tool.get()
            if self.start is None or t in ('select','delete'):return
            typed=self.command_value.get()[:50];unit=self.units.get();a=self.start;p=self.pointer_world
            if t in ('rect','rect_center','rect_round'):
                factor=2 if t=='rect_center' else 1
                if self.numeric_width is None:
                    label='Largeur X';value=typed or self.format_length(abs(p[0]-a[0])*factor)
                    lines=[f'{label} : {value}'+(' |' if typed else '')+' '+unit]
                else:
                    value=typed or self.format_length(abs(p[1]-a[1])*factor)
                    lines=[f'Largeur X : {self.format_length(self.numeric_width)} {unit}',
                           f'Longueur Y : {value}'+(' |' if typed else '')+' '+unit]
            else:
                label='Rayon' if t=='circle_radius' else 'Diamètre' if t in ('circle_diameter','circle_2p') else 'Longueur'
                value=typed or self.format_length(math.dist(a,p));lines=[f'{label} : {value}'+(' |' if typed else '')+' '+unit]
            x,y=getattr(self,'cursor_screen',self.to_screen(p));x+=18;y+=20
            text=c.create_text(x+8,y+6,text='\n'.join(lines),anchor='nw',fill=contrast_color(self.p['panel']),
                               font=('Segoe UI',10),tags='input_bubble')
            box=c.bbox(text)
            if not box:return
            left,top,right,bottom=box;W=c.winfo_width();H=c.winfo_height()
            dx=min(0,W-right-16);dy=min(0,H-bottom-12)
            if dx or dy:c.move(text,dx,dy);left+=dx;right+=dx;top+=dy;bottom+=dy
            rect=c.create_rectangle(left-8,top-6,right+8,bottom+6,fill=self.p['panel'],outline=contrast_color(self.p['panel']),tags='input_bubble')
            c.tag_lower(rect,text)

        def display_menu(self):
            m=self.menu();kind=self.workspace['kind'] if self.workspace else None
            for key,label in [('maro','Base maro'),('petite','Base petite maroquinerie')]:
                m.add_command(label=('✓  ' if key==kind else '    ')+label,command=lambda k=key:self.change_workspace(k))
            m.add_separator();m.add_command(label='Afficher / masquer les colonnes',command=self.toggle_guides)
            m.add_command(label='Régler les colonnes…',command=self.workspace_dialog)
            m.add_command(label='Cadrer la base',command=self.fit_workspace)
            try:m.tk_popup(self.winfo_pointerx(),self.winfo_pointery())
            finally:m.grab_release()

        def rebuild_new_menu(self):
            """Nouveau ▸ Vide, the lycée's two bases, then one's own base profiles; Ctrl+N with the profile of Nouveau."""
            import base_profiles as bp
            new=self.__dict__.get('new_menu')
            if new is None:return
            new.delete(0,'end');default=bp.default_name(self.prefs)
            new.add_command(label='Vide',command=lambda:self.new_base(None))
            for name,label in ((bp.LYCEE[0],'Base maro'),(bp.LYCEE[1],'Base petite maroquinerie')):
                new.add_command(label=label+('  Ctrl+N' if name==default else ''),command=lambda n=name:self.new_profile(n))
            own=[n for n in bp.names(self.prefs) if n not in bp.LYCEE]
            if own:new.add_separator()
            for name in own:new.add_command(label=name+('  Ctrl+N' if name==default else ''),command=lambda n=name:self.new_profile(n))
        def new_profile(self,name):
            import base_profiles as bp
            self.add_doc([],bp.workspace_for(self.prefs,name))
        def change_workspace(self,kind):
            # View/layout changes must never create a new document or drop drawings.
            # 0.19.14: the base already there changes nothing (re-clicking « Base maro » on a Mozart pattern put it back
            # at its default place under the pieces); another one keeps the place of the one it replaces.
            w=self.workspace
            if w and w.get('kind')==kind and 'labels' not in w and not w.get('profile'):self.status.set('Base déjà choisie.');return
            new=default_workspace(kind)
            if w:new['origin_x']=w.get('origin_x',0.)   # (shown: one sees the base one chooses)
            self.snapshot();self.workspace=new;self.cancel();self.refresh();self.fit_workspace()

        def dxf(self):
            from export_preview import open_review
            return open_review(self,'dxf')

        def dwg(self):
            # 0.18.0: written by the converter shipped with Craft (LibreDWG, DWG 2000), nothing to install.
            if getattr(self,'export_busy',False):self.status.set('Une conversion DWG est déjà en cours.');return
            items=self.export_items()
            if not items:return
            import doc_files
            options=dict(defaultextension='.dwg',filetypes=doc_files.export_types('dwg'));folder=doc_files.initial_dir(self.prefs)
            if folder:options['initialdir']=folder
            file=filedialog.asksaveasfilename(**options)
            if not file:return
            doc_files.remember_folder(self.prefs,file);self.persist_preferences()
            items=clone(items);result=queue.Queue();self.export_busy=True;self.status.set('Conversion DWG en cours…')
            def work():
                try:export_dwg(file,items);result.put((True,file))
                except Exception as exc:result.put((False,str(exc)))
            threading.Thread(target=work,daemon=True).start()
            def poll():
                try:ok,detail=result.get_nowait()
                except queue.Empty:self.after(150,poll);return
                self.export_busy=False
                if ok:self.status.set('DWG exporté : '+Path(detail).name)
                else:self.status.set('Échec de l’export DWG.');show_error('Export DWG',detail,self)   # 0.19.19: converter blocked: what to do
            self.after(150,poll)

        def to_mm(self,value):return number(number(value)*(10 if self.units.get()=='cm' else 1))
        def format_length(self,value):return f'{value/(10 if self.units.get()=="cm" else 1):.6g}'
        def unit_change(self):
            factor=(10 if self.last_unit=='cm' else 1)/(10 if self.units.get()=='cm' else 1)
            if self.selected is None:
                for key,var in self.fields.items():
                    if key!='name':
                        try:var.set(f'{number(var.get())*factor:g}')
                        except ValueError:pass
            self.last_unit=self.units.get()
            self.cancel();self.persist_preferences();self.rebuild_ui()
            self.status.set('Unité : '+self.units.get()+' · les dimensions du dessin sont conservées.')
        def settings_changed(self):self.update_toggle_labels();self.persist_preferences();self.preview()
        def toggle_quickbar(self):
            self.quickbar_open=not self.quickbar_open;self.rebuild_ui()
        def grid_dialog(self):
            win=self.dialog('Pas de la grille')
            self.label(win,'Pas en '+self.units.get()).pack(padx=20,pady=12)
            val=tk.StringVar(value=self.format_length(number(self.spacing.get())))
            self.entry(win,val,12).pack(padx=20,pady=5)
            def apply():
                try:
                    g=self.to_mm(val.get())
                    if not .01<=g<=1000:raise ValueError('Pas autorisé : 0,01 à 1 000 mm.')
                    self.spacing.set(f'{g:g}');win.destroy();self.redraw()
                except ValueError as exc:messagebox.showerror('Pas de grille',str(exc),parent=win)
            self.button(win,'Appliquer',apply).pack(padx=20,pady=12)
        def values(self,kind):
            s={k:(v.get().strip() or 'Pièce') if k=='name' else self.to_mm(v.get()) for k,v in self.fields.items()}
            s['kind']=kind
            if kind in ('rect','circle') and (s['w']<=0 or s['h']<=0):raise ValueError('Dimensions positives nécessaires.')
            if kind=='circle':s['h']=s['w'];s['r']=0
            if kind=='line':s['r']=0
            if kind=='rect' and not 0<=s['r']<=min(s['w'],s['h'])/2:raise ValueError('Rayon trop grand ou négatif.')
            return s

        def group_menu(self,group):
            m=self.menu()
            ids={'lines':['line','poly'],'rectangles':['rect','rect_center','rect_round','rect_rot','para'],
                 'circles':['circle_radius','circle_diameter','circle_2p','circle_3p']}[group]
            symbols={'lines':'╱','rectangles':'▱','circles':'○'}
            for tool in ids:m.add_command(label=f'{symbols[group]}   {TOOLS[tool]}',command=lambda t=tool:self.set_tool(t))
            try:m.tk_popup(self.winfo_pointerx(),self.winfo_pointery())
            finally:m.grab_release()

        def set_tool(self,tool):
            self.cancel();self.tool.set(tool);self.mode_label.set(TOOLS[tool]);
            if tool!='select':self.last_command=('tool',tool)
            self.canvas.configure(cursor='arrow' if tool in ('select','delete') else 'crosshair')
            if tool=='rect_round' and self.read_radius()==0:self.fields['r'].set(self.format_length(5))
            self.set_hint();self.canvas.focus_set()

        def set_hint(self):
            t=self.tool.get()
            if t=='select':txt='Sélectionner un bord'
            elif t=='delete':txt='Cliquez le tracé à supprimer'
            elif self.start is None and not self.stage_points:txt='Cliquez le premier point'+(' / centre' if t.startswith('circle_') and t not in ('circle_2p','circle_3p') else '')
            elif t in ('line','poly'):txt='Donnez une direction, tapez la longueur'
            elif t in ('rect','rect_center','rect_round'):
                txt='Longueur Y : tapez la valeur' if self.numeric_width is not None else 'Largeur X, ensuite longueur Y'
            elif t in ('circle_radius','circle_diameter','circle_2p'):txt='Tapez le '+('rayon' if t=='circle_radius' else 'diamètre')
            elif t=='circle_3p':txt=f'Cliquez le point {len(self.stage_points)+1} sur 3'
            else:txt='Cliquez le troisième point ou tapez la hauteur / longueur du côté' if len(self.stage_points)==2 else 'Cliquez le deuxième point ou tapez la longueur de base'
            self.hint.set(txt)
            self.draw_input_bubble()

        def update_toggle_labels(self):
            self.ortho_button.configure(text='ORTHO F8 · '+('ON' if self.ortho.get() else 'OFF'),fg=self.p['accent'] if self.ortho.get() else self.p['ui_ink'])
            self.snap_button.configure(text='ANCRAGES F3 · '+('ON' if self.snap.get() else 'OFF'),fg=self.p['accent'] if self.snap.get() else self.p['ui_ink'])

        def persist_preferences(self):
            self.prefs.update(units=self.units.get(),grid=self.grid.get(),ortho=self.ortho.get(),snaps=[k for k,v in self.snap_vars.items() if v.get()])
            try:
                from app_preferences import write_atomic   # 0.19.9: written whole or not at all
                write_atomic(settings_path(),json.dumps(self.prefs,indent=2))
            except OSError:self.status.set('Préférences appliquées ; enregistrement impossible sur ce PC.')

        def toggle_ortho(self,e=None):
            self.ortho.set(not self.ortho.get());self.update_toggle_labels();self.persist_preferences();self.preview();return 'break'
        def toggle_grid(self,e=None):
            self.grid.set(not self.grid.get());self.view_change();return 'break'
        def view_change(self):self.persist_preferences();self.redraw()

        def toggle_panel(self):
            self.panel_open=not self.panel_open
            if self.panel_open:
                self.side.pack(side='right',fill='y',before=self.canvas,padx=10);self.show_side_close()
            else:self.side.pack_forget();self.side_close.place_forget()
        def show_side_close(self):
            if not self.panel_open:return
            self.side_close.place(in_=self.side,x=-20,y=4,width=20,height=22)
            if hasattr(self.side_close.tk,'call'):self.side_close.tk.call('raise',self.side_close._w)
        def toggle_positions(self):
            self.position_open=not self.position_open
            if self.position_open:self.position_frame.pack(fill='x')
            else:self.position_frame.pack_forget()

        def point(self,e):
            p=self.raw(e);kind=None
            if self.snap.get():
                modes={k for k,v in self.snap_vars.items() if v.get()}
                p,kind=snap_point(p,self.items,modes,10/self.scale,self.workspace,
                                  self.selected if self.tool.get()=='select' else None)
            if not kind and self.grid.get():
                try:g=number(self.spacing.get());assert g>0
                except (ValueError,AssertionError):g=1
                p=tuple(round(v/g)*g for v in p)
            if self.start and self.ortho.get() and self.tool.get() in ('line','poly','rect_rot','para') and len(self.stage_points)<2:
                a=self.start
                constrained=(p[0],a[1]) if abs(p[0]-a[0])>=abs(p[1]-a[1]) else (a[0],p[1])
                if math.dist(constrained,p)>1e-7:kind=None
                p=constrained
            self.snap_marker=(p,kind) if kind else None
            return p

        def base_width_dialog(self):
            from tkinter import simpledialog
            value=simpledialog.askfloat('Lignes de base','Épaisseur (mm)',initialvalue=self.prefs.get('base_line_width',4.5),minvalue=.1,maxvalue=5,parent=self)
            if value is not None:self.prefs['base_line_width']=value;self.persist_preferences();self.redraw()

        def draw_guides(self):
            w=self.workspace
            if not w or not w.get('visible',True):return
            for a,b in guide_segments(w):self.canvas.create_line(*self.to_screen(a),*self.to_screen(b),fill=self.p['guides'],width=max(.5,self.prefs.get('base_line_width',4.5)*self.scale),tags='guides')
            x=w.get('origin_x',0);labels=__import__('cad').column_labels(w);suffix=__import__('cad').title_suffix(w)
            for i,width in enumerate(w['widths']):
                label=labels[i]+(' '+suffix if i==1 and suffix else '')
                sx,sy=self.to_screen((x+width*.05,w['header']*.6))
                self.canvas.create_text(sx,sy,text=label,anchor='w',fill=self.p['guides'],font=('Segoe UI',-max(1,round(w['header']*.20*self.scale)),'bold'),tags='guides')
                x+=width

        def redraw(self):
            if not hasattr(self,'canvas') or not self.canvas.winfo_exists():return
            c=self.canvas;W=c.winfo_width();H=c.winfo_height()
            import draw_cache
            kept=draw_cache.begin(self)   # 0.18.7: the canvas emptied, or emptied of all but the unchanged objects
            forget_zoom_marks(c)   # 0.18.3: what the wheel zoom resizes is looked for again
            # 0.18.2: what is drawn, in plan mm (``_drawn_box``): the screen (quick after each change;
            # the pieces left out kept in ``_culled`` for extend_drawing when the view moves or zooms
            # out), or one screen beyond each side (``_wide_draw``).
            wide=bool(self.__dict__.get('_wide_draw'));mw,mh=(W,H) if wide else (20,20);culled=[]
            self._drawn_box=((-mw-self.ox)/self.scale,(-mh-self.oy)/self.scale,(W+mw-self.ox)/self.scale,(H+mh-self.oy)/self.scale);self._drawn_wide=wide
            try:
                if kept:kept.under(True)
                if self.grid.get():self.draw_grid(mw,mh)
                self.draw_guides()
                if kept:kept.under(False)
                measure=lambda s:bounds([s])
                for i,s in enumerate(self.items):
                    x,y,X,Y=kept.bounds(i,s,measure) if kept else bounds([s]);a,b=self.to_screen((x,y));A,B=self.to_screen((X,Y))
                    if max(a,A)<-mw or min(a,A)>W+mw or max(b,B)<-mh or min(b,B)>H+mh:culled.append((i,s,(x,y,X,Y)));continue   # 0.18.4: with its box
                    color,width=(self.p['accent'],2) if i==self.selected else (self.p['ink'],1.2)
                    if kept:kept.draw(i,s,color,width)
                    else:self.draw_shape(s,color,width)
            except BaseException:
                draw_cache.abandon(self,kept);raise
            draw_cache.end(self,kept)
            self._culled=culled
            if self.pending:
                pts=[v for p in self.pending for v in self.to_screen(p)]
                if len(pts)>=4:c.create_line(*pts,fill=self.p['accent'],width=1.5)
            self.preview()
            self.draw_scale_bar()

        def draw_grid(self,mw=20,mh=20):
            """The grid over the screen and ``mw`` / ``mh`` pixels around it, under everything."""
            c=self.canvas;c.delete('grid');W=c.winfo_width();H=c.winfo_height()
            try:g=number(self.spacing.get());assert g>0
            except (ValueError,AssertionError):g=1
            while g*self.scale<20:g*=5
            for x in range(math.floor((-mw-self.ox)/self.scale/g),math.ceil((W+mw-self.ox)/self.scale/g)+1):
                sx=x*g*self.scale+self.ox;c.create_line(sx,-mh,sx,H+mh,fill='#30343a',tags='grid')
            for y in range(math.floor((-mh-self.oy)/self.scale/g),math.ceil((H+mh-self.oy)/self.scale/g)+1):
                sy=y*g*self.scale+self.oy;c.create_line(-mw,sy,W+mw,sy,fill='#30343a',tags='grid')
            c.tag_lower('grid')

        def draw_scale_bar(self):
            c=self.canvas;c.delete('scale_bar');H=c.winfo_height()
            length=10
            while length*self.scale<50:length*=2
            while length*self.scale>140:length/=2
            if not .05<=self.scale<=80:
                # 0.18.5: deep zoom (to 2 000 px/mm) or far out (to 0,002): a round length (1, 2, 5 × 10ⁿ).
                k=10**math.floor(math.log10(50/self.scale))
                length=next(v*k for v in (1,2,5,10,20) if v*k*self.scale>=50)
            # Tagged (0.16.26): the scale bar stays a native item above the smoothed drawing,
            # otherwise its own background box hid the smoothed bar once a shape existed.
            label=self.format_length(length)+' '+self.units.get();right=max(20+length*self.scale,20+len(label)*7)+8  # box only as wide as the bar (0.16.27)
            c.create_rectangle(10,H-42,right,H-5,fill=self.p['canvas'],outline='',tags='scale_bar')
            c.create_line(20,H-15,20+length*self.scale,H-15,fill=self.p['ink'],width=2,tags='scale_bar')
            c.create_text(20,H-31,text=label,anchor='w',fill=self.p['ink'],font=('Segoe UI',10),tags='scale_bar')

        def grips_shown(self):
            """0.19.0, like AutoCAD (GRIPOBJLIMIT): the grips of the selection are drawn, shown under the pointer
            and taken only while at most GRIP_LIMIT objects are selected (selected_ids(): the selected set, else
            one object at most). Beyond, none: a window over a whole pattern was slowed down by drawing them;
            the selection is still moved, copied, turned, deleted… whole."""
            st=self.__dict__.get('_drawing_selection')   # 0.19.9: once per drawing of the plan (selection_index)
            if st and st.get('items') is self.items and st['selected_set'] is self.__dict__.get('selected_set'):return st['grips']
            ids=self.__dict__.get('selected_set')
            if not ids or len(ids)<=GRIP_LIMIT:return True
            # A cote (its lines, arrows and value) is one object for the user, as in AutoCAD.
            groups=set();count=0
            for i in ids:
                group=self.items[i].get('dimension_group') if 0<=i<len(self.items) else None
                if group is None:count+=1
                elif group not in groups:groups.add(group);count+=1
                if count>GRIP_LIMIT:return False
            return True
        # 0.19.9: while the plan's objects are drawn, the selection is looked up once ({id(object): index} and
        # grips_shown()) instead of being gone through for each object drawn: with 900 objects all selected, a
        # drawing took 4 times as long as with none selected.
        def selection_drawing(self):
            """``with`` it, the objects drawn use selection_index."""
            app=self
            class Scope:
                def __enter__(self):
                    self.outer='_drawing_selection' in app.__dict__
                    if not self.outer:app._drawing_selection={}
                def __exit__(self,*exc):
                    if not self.outer:app.__dict__.pop('_drawing_selection',None)
            return Scope()
        def selection_index(self):
            """{id(object): index} of the selected objects (the selected set, else ``selected``) during a drawing
            (selection_drawing), made again when the list of objects changes; None outside a drawing."""
            st=self.__dict__.get('_drawing_selection')
            if st is None:return None
            if st.get('items') is not self.items or st.get('count')!=len(self.items):
                items=self.items;n=len(items);chosen=self.__dict__.get('selected_set');index={}
                st.clear();grips=self.grips_shown()
                for i in ([self.selected] if self.selected is not None else [])+list(chosen or ()):   # the selected set last: it wins
                    if isinstance(i,int) and 0<=i<n:index[id(items[i])]=i
                st.update(items=items,count=n,selected_set=chosen,index=index,grips=grips)
            return st['index']
        def draw_shape(self,s,color,width,tags=()):
            pts,closed=path(s)
            if closed:pts=pts+pts[:1]
            xy=[v for p in pts for v in self.to_screen(p)]
            if len(xy)>=4:self.canvas.create_line(*xy,fill=color,width=width,tags=tags)
            if tags:return
            if self.selected is not None and self.items[self.selected] is s and self.grips_shown():
                # 0.19.8 « 4 points sur mon arc »: a shape with arcs shows only the grips it can be taken by (start, middle,
                # end and centre of each arc, vertices between straight sides: advanced_ui.deformation_grips); its
                # quadrants, the ends of the quarter turns an arc is stored in… stay accroches.
                arcs=any(s.get('bulges') or ())
                for p,kind in () if arcs else object_anchors(s):
                    if kind=='quarter':continue   # 0.18.1: an accroche only, not a grip
                    a,b=self.to_screen(p);self.canvas.create_rectangle(a-2.5,b-2.5,a+2.5,b+2.5,fill=self.prefs.get('anchor_color','#efcf4b'),outline=self.prefs.get('anchor_color','#efcf4b'),tags='grips')
                x,y,X,Y=bounds([s]);a,b=self.to_screen((x,y))

        def read_radius(self):
            try:return max(0,self.to_mm(self.fields['r'].get()))
            except ValueError:return 5

        def preview(self):
            if not hasattr(self,'canvas'):return
            c=self.canvas;c.delete('preview');c.delete('snap')
            t=self.tool.get();p=self.pointer_world
            if self.start is not None:
                try:
                    data=self.preview_shape(p)
                    if data:self.draw_shape(data,self.p['accent'],1,('preview',))
                except (ValueError,ZeroDivisionError):pass
            self.draw_input_bubble()
            if self.snap_marker:
                p,kind=self.snap_marker;a,b=self.to_screen(p);r=5
                if kind=='center':c.create_oval(a-r,b-r,a+r,b+r,outline=self.p['accent'],width=1.5,tags='snap')
                elif kind=='midpoint':c.create_polygon(a,b-r,a+r,b+r,a-r,b+r,fill='',outline=self.p['accent'],width=1.5,tags='snap')
                else:c.create_rectangle(a-r,b-r,a+r,b+r,outline=self.p['accent'],width=1.5,tags='snap')
                c.create_text(a+9,b-12,text=SNAP_NAMES[kind],fill=self.p['accent'],anchor='w',font=('Segoe UI',8),tags='snap')

        def preview_shape(self,p):
            t=self.tool.get();a=self.start
            if t=='poly':return construct('line',[a,p])
            if t in THREE:
                if len(self.stage_points)<2:return construct('line',[a,p])
                return construct(t,self.stage_points+[p],radius=self.read_radius())
            if t in ('rect','rect_center','rect_round') and self.numeric_width is not None:
                factor=.5 if t=='rect_center' else 1
                p=(a[0]+self.numeric_width*factor*(-1 if p[0]<a[0] else 1),p[1])
            return construct(t,[a,p],radius=self.read_radius()) if t not in ('select','delete') else None

        def down(self,e):
            self.canvas.focus_set();self.press_start=(e.x,e.y);self.cursor_screen=(e.x,e.y);self.mouse_started=False
            t=self.tool.get()
            if t=='delete':
                self.selected=self.pick(self.raw(e))
                if self.selected is not None:self.delete()
                return
            if t=='select':
                self.choose(self.pick(self.raw(e)))
                if self.selected is not None:
                    self.drag=(self.raw(e),copy.deepcopy(self.items[self.selected]));self.snapshot()
                return
            p=self.point(e);self.pointer_world=p
            if t=='poly':
                if len(self.pending)>=3 and math.dist(p,self.pending[0])*self.scale<10:self.finish_poly(True);return
                if not self.pending or math.dist(p,self.pending[-1])>1e-7:self.pending.append(p)
                self.start=p;self.set_hint();self.redraw();return
            if self.start is None:
                self.start=p;self.stage_points=[p] if t in THREE else [];self.mouse_started=True
            elif t in THREE:
                if len(self.stage_points)<2:
                    if math.dist(p,self.stage_points[0])>1e-7:self.stage_points.append(p)
                else:self.commit_current(p)
            else:
                with self.held_redraw():self.commit_current(p);self.set_hint();self.redraw()
                return
            self.set_hint();self.redraw()

        def up(self,e):
            if self.drag:
                if self.items[self.selected]==self.drag[1] and self.undo_stack:self.undo_stack.pop()
                self.drag=None;self.refresh();return
            if self.mouse_started and self.start and self.tool.get() not in THREE+('poly','select') and self.press_start:
                if math.dist((e.x,e.y),self.press_start)>5:self.commit_current(self.point(e))
            self.mouse_started=False

        def motion(self,e):
            self.cursor_screen=(e.x,e.y)
            p=self.point(e);self.pointer_world=p
            if self.drag and self.selected is not None:
                a,original=self.drag;dx,dy=p[0]-a[0],p[1]-a[1]
                self.items[self.selected]['x']=original['x']+dx;self.items[self.selected]['y']=original['y']+dy
                self.fields['x'].set(self.format_length(self.items[self.selected]["x"]));self.fields['y'].set(self.format_length(self.items[self.selected]["y"]))
                self.redraw();return
            if self.start:
                length=math.dist(self.start,p)
                # 0.19.9: the live distance is marked (_live_status): the history leaves it out in every unit (only
                # « mm » was recognised: in cm each move was written there)
                self._live_status=f'{TOOLS[self.tool.get()]} · {self.format_length(length)} {self.units.get()}'+(f' · {SNAP_NAMES[self.snap_marker[1]]}' if self.snap_marker else '')
                self.status.set(self._live_status)
            self.preview()

        def valid_shape(self,s):
            if s['kind']=='line' and math.hypot(s['w'],s['h'])<1e-6:return False
            if s['kind'] in ('circle','rect') and min(s['w'],s['h'])<1e-6:return False
            if s['kind']=='poly':
                pts,_=path(s);area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1]))
                if abs(area)<1e-7:return False
            return True

        def commit_current(self,p):
            t=self.tool.get()
            if t in ('rect','rect_center','rect_round') and self.numeric_width is not None:
                a=self.start;factor=.5 if t=='rect_center' else 1
                p=(a[0]+self.numeric_width*factor*(-1 if p[0]<a[0] else 1),p[1])
            pts=(self.stage_points+[p]) if t in THREE else [self.start,p]
            s=construct(t,pts,self.fields['name'].get() or 'Pièce',self.read_radius())
            if not self.valid_shape(s):raise ValueError('La forme est trop petite ou ses points sont alignés.')
            self.snapshot();self.items.append(s);self.selected=len(self.items)-1
            if t=='line':self.last_direction=(p[0]-self.start[0],p[1]-self.start[1])
            self.numeric_width=None;self.stage_points=[];self.command_value.set('')
            self.start=None
            self.sync_fields();self.complete_command(t);self.refresh()

        def cancel(self):
            self.start=None;self.pending=[];self.stage_points=[];self.numeric_width=None;self.drag=None
            self.command_value.set('');self.snap_marker=None;self.mouse_started=False
            self.tool.set('select');self.mode_label.set(TOOLS['select'])
            if hasattr(self,'canvas'):self.canvas.configure(cursor='arrow');self.canvas.focus_set();self.redraw()
            self.set_hint();return 'break'

        def double(self,e):
            if self.tool.get()=='poly':self.finish_poly(False)
            elif self.tool.get()=='select' and self.selected is not None:
                if not self.panel_open:self.toggle_panel()

        def finish_poly(self,closed):
            if len(self.pending)<(3 if closed else 2):return
            s=polygon(self.pending,self.fields['name'].get() or 'Contour',closed)
            self.snapshot();self.items.append(s);self.selected=len(self.items)-1
            self.pending=[];self.start=None;self.command_value.set('');self.sync_fields();self.complete_command('poly');self.refresh()

        def key_input(self,e):
            if e.state & 4:return None
            focus=self.focus_get()
            if focus is self.canvas and e.char and e.char in '0123456789.,;-+xX*':
                if self.tool.get()=='select':return None
                self.command_entry.focus_set();self.command_entry.insert('end',e.char);return 'break'

        def command_preview(self):
            if hasattr(self,'canvas'):self.draw_input_bubble()

        def enter_dimension(self,e=None):
            text=self.command_value.get().strip();t=self.tool.get()
            if not text:
                if t=='poly' and self.pending:self.finish_poly(False)
                elif self.start is None:self.repeat_last()
                return 'break'
            if t in ('line','poly'):
                from command_catalog import coordinate
                try:q=coordinate(text,self.start,self.units.get())
                except ValueError as exc:self.status.set(str(exc));return 'break'
                if q is not None:
                    if self.start is not None and math.dist(self.start,q)<1e-8:self.status.set('Le nouveau point se confond avec le précédent.');return 'break'
                    if self.start is None:
                        self.start=q
                        if t=='poly':self.pending=[q]
                        self.pointer_world=q;self.command_value.set('');self.set_hint();self.redraw()
                    elif t=='poly':
                        if not self.pending:self.pending=[self.start]
                        self.pending.append(q);self.start=q;self.pointer_world=q;self.command_value.set('');self.redraw();self.set_hint()
                    else:self.pointer_world=q;self.commit_current(q)
                    return 'break'
            if self.start is None:
                self.status.set('Cliquez d’abord le point de départ sur le dessin.');return 'break'
            try:
                from command_catalog import length_expression,dimension_chunks
                chunks=dimension_chunks(text,t in ('rect','rect_center','rect_round','rect_rot','para'))
                values=[length_expression(v.strip(),self.units.get()) for v in chunks]
                if any(v<=0 for v in values):raise ValueError('Les dimensions doivent être positives.')
                a=self.start;p=self.pointer_world
                if t in ('line','poly') and math.dist(a,p)<1e-8:
                    dx,dy=getattr(self,'last_direction',(1,0));p=(a[0]+dx,a[1]+dy)
                if t in ('line','poly','circle_radius','circle_diameter','circle_2p'):
                    if len(values)!=1:raise ValueError('Entrez une seule longueur dans l’unité choisie.')
                    q=directed(a,p,values[0],self.ortho.get() and t in ('line','poly'))
                    if t=='poly':
                        if not self.pending:self.pending=[a]
                        self.pending.append(q);self.start=q;self.command_value.set('');self.redraw();self.set_hint()
                    else:self.commit_current(q)
                    self.pointer_world=q
                elif t in ('rect','rect_center','rect_round'):
                    if len(values)==1 and self.numeric_width is None:
                        self.numeric_width=values[0];self.command_value.set('');self.set_hint();return 'break'
                    if len(values)==2:w,h=values
                    elif len(values)==1 and self.numeric_width is not None:w,h=self.numeric_width,values[0]
                    else:raise ValueError('Entrez largeur X;longueur Y, par exemple 100;70.')
                    factor=.5 if t=='rect_center' else 1
                    q=(a[0]+w*factor*(-1 if p[0]<a[0] else 1),a[1]+h*factor*(-1 if p[1]<a[1] else 1))
                    self.commit_current(q)
                elif t in ('rect_rot','para'):
                    if len(values)!=1:raise ValueError('Entrez une longueur à la fois.')
                    if len(self.stage_points)<2:
                        q=directed(a,p,values[0],self.ortho.get());self.stage_points=[a,q];self.command_value.set('');self.set_hint();self.redraw()
                    else:
                        b=self.stage_points[1]
                        if t=='para':q=directed(b,p,values[0],False)
                        else:
                            dx,dy=b[0]-a[0],b[1]-a[1];n=math.hypot(dx,dy);ux,uy=-dy/n,dx/n
                            sign=-1 if (p[0]-b[0])*ux+(p[1]-b[1])*uy<0 else 1
                            q=(b[0]+ux*values[0]*sign,b[1]+uy*values[0]*sign)
                        self.commit_current(q)
                else:raise ValueError('Pour ce cercle, cliquez trois points du contour.')
                self.canvas.focus_set()
            except (ValueError,ZeroDivisionError) as exc:self.status.set(str(exc))
            return 'break'

        def sync_fields(self):
            if self.selected is None:return
            s=self.items[self.selected]
            for key,var in self.fields.items():var.set(s[key] if key=='name' else self.format_length(s[key]))
            if s['kind']=='line':
                self.length_var.set(self.format_length(math.hypot(s["w"],s["h"])))
                self.angle_var.set(f'{math.degrees(math.atan2(-s["h"],s["w"])):g}')
                self.dim_frame.pack_forget();self.line_frame.pack(fill='x',after=self.list)
            else:self.line_frame.pack_forget();self.dim_frame.pack(fill='x',after=self.list)

        def choose(self,i):self.selected=i;self.sync_fields();self.refresh()
        def refresh(self):
            # 0.18.5: the list keeps its scrolling (it was emptied and filled again at every click).
            from ui_widgets import refill_list
            refill_list(self.list,[f'{i+1:02d}  {s["name"]}' for i,s in enumerate(self.items)],self.selected if self.selected is not None and self.selected<len(self.items) else None)
            # 0.17.0: with the centred Windows caption, the native title stays empty (it used to
            # flash « Craft 0.16.x - fichier » beside the icon at every action).
            if not self.__dict__.get('_caption_controller'):self.title(f'Craft {VERSION} · {Path(self.filename).name if self.filename else "Sans titre"}'+(' *' if self.dirty() else ''))
            self.redraw()

        def apply(self):
            if self.selected is None:return
            s=self.items[self.selected]
            if s['kind']=='line':
                length=self.to_mm(self.length_var.get());angle=math.radians(number(self.angle_var.get()))
                if length<=0:raise ValueError('Longueur positive nécessaire.')
                new=copy.deepcopy(s);new.update(w=length*math.cos(angle),h=-length*math.sin(angle),
                     name=self.fields['name'].get() or 'Ligne',x=self.to_mm(self.fields['x'].get()),y=self.to_mm(self.fields['y'].get()))
                self.snapshot();self.items[self.selected]=new;self.sync_fields();self.refresh()
            else:Base.apply(self);self.sync_fields()
            self.last_command=('action','apply')

        def state(self):
            # 0.18.0: the background picture too (a plain copy: its data is never copied).
            # 0.18.1: the Infos du modèle too.
            back=self.__dict__.get('background');infos=self.__dict__.get('infos')
            return dict(items=clone(self.items),workspace=clone(self.workspace),background=dict(back) if back else None,infos=copy.deepcopy(infos) if infos else None)
        def snapshot(self):self.undo_stack.append(self.state());self.undo_stack=self.undo_stack[-100:];self.redo_stack=[]
        def held_redraw(self):
            """0.17.0: the redraws asked inside the block become ONE redraw at its end (with 80
            pieces each full redraw costs ~0.1 s; Annuler, Échap or a click used to do 2 to 6)."""
            app=self
            class Hold:
                def __enter__(self):app._hold_redraw=app.__dict__.get('_hold_redraw',0)+1
                def __exit__(self,*exc):
                    app._hold_redraw-=1
                    if not app._hold_redraw and app.__dict__.pop('_redraw_wanted',False):app.redraw()
            return Hold()
        def restore(self,s):
            with self.held_redraw():
                self.items=s['items'];self.workspace=s['workspace'];back=s.get('background');self.background=dict(back) if back else None
                infos=s.get('infos');self.infos=copy.deepcopy(infos) if infos else None
                self.selected=None;self.cancel();self.refresh()
        def undo(self):
            if self.undo_stack:
                self.redo_stack.append(self.state());self.restore(self.undo_stack.pop());self.last_command=('action','undo')
        def redo(self):
            if self.redo_stack:
                self.undo_stack.append(self.state());self.restore(self.redo_stack.pop());self.last_command=('action','redo')
        def dirty(self):return self.items!=self.clean or self.workspace!=self.clean_workspace or self.__dict__.get('background')!=self.__dict__.get('clean_background') or self.__dict__.get('infos')!=self.__dict__.get('clean_infos')
        def document_name(self):
            """The name on the document's tab: its file, else the name it was opened with, else « Nouveau »."""
            return Path(self.filename).stem if self.filename else self.__dict__.get('display_name') or 'Nouveau'
        def guard(self):
            if not self.dirty():return True
            # 0.18.3: the tab's name, to know which drawing when several are open
            answer=messagebox.askyesnocancel('Enregistrer',f'Enregistrer les modifications de {self.document_name()} avant de continuer ?')
            return self.save_doc() if answer else answer is False
        def new_base_dialog(self):
            win=self.dialog('Nouveau dessin')
            self.label(win,'Choisissez votre espace de travail').pack(padx=20,pady=15)
            for text,kind in [('Base maro','maro'),('Base petite maroquinerie','petite'),('Dessin libre, sans repères',None)]:
                self.button(win,text,lambda k=kind:(win.destroy(),self.new_base(k))).pack(fill='x',padx=20,pady=5)
        def save_doc(self):
            # 0.18.0: Craft writes .crft only; a document opened from an old .patron (or a Mozart
            # file) is saved through « Enregistrer sous », the original file is never written.
            if not self.filename or Path(self.filename).suffix.lower()!='.crft':return self.save_as()
            return self.write_doc(self.filename)
        def save_as(self):
            import doc_files
            name=self.__dict__.get('display_name') or (Path(self.filename).stem if self.filename else None)
            if not self.filename:
                # 0.18.5: a document never saved proposes its model's name (Infos du modèle, else the model
                # written on the pieces), still editable in the window; the pieces' labels are never changed.
                try:model=__import__('model_info').model_name(self)
                except Exception:model=''
                model=__import__('re').sub(r'[\\/:*?"<>|]+','-',model or '').strip(' .')
                if model and model.lower() not in ('modèle','modele','nouveau modèle','nouveau'):name=model
            options=dict(defaultextension='.crft',filetypes=doc_files.SAVE_TYPES)
            folder=str(Path(self.filename).parent) if self.filename else doc_files.initial_dir(self.prefs)
            if folder:options['initialdir']=folder
            if name:options['initialfile']=name+'.crft'
            file=filedialog.asksaveasfilename(**options)
            if not file:return False
            return self.write_doc(doc_files.crft_name(file))
        def write_doc(self,file):
            import doc_files
            back=self.__dict__.get('background')
            # 0.18.1: the dates of the Infos du modèle (still editable): created at the first
            # save, modified when the drawing changed.
            import model_info
            infos=model_info.dated(self.__dict__.get('infos'),file,self.items!=self.clean or self.workspace!=self.clean_workspace or back!=self.__dict__.get('clean_background') or not self.filename)
            write_document(file,self.items,self.workspace,back,infos);self.infos=infos   # the dates change only once the file is written
            # 0.19.17: fast copies (clone), as Annuler does
            self.filename=file;self.clean=clone(self.items);self.clean_workspace=clone(self.workspace);self.clean_background=dict(back) if back else None
            self.clean_infos=clone(self.infos)
            doc_files.remember(self.prefs,file);self.persist_preferences()
            if hasattr(self,'rebuild_recent_menu'):self.rebuild_recent_menu()
            self.refresh();return True
        def toggle_guides(self):
            if not self.workspace:return
            self.snapshot();self.workspace['visible']=not self.workspace.get('visible',True);self.refresh()
        def fit_workspace(self):
            if not self.workspace:
                self.fit();return
            W=max(100,self.canvas.winfo_width());H=max(100,self.canvas.winfo_height());w=self.workspace
            width=sum(w['widths']);height=w['header']+w['height']
            self.scale=max(.02,min(20,(W-60)/width,(H-60)/height));self.ox=(W-width*self.scale)/2-w.get('origin_x',0)*self.scale;self.oy=25;self.redraw()
        def pdf(self):
            from export_preview import open_review
            return open_review(self,'pdf')

        def svg(self):
            items=self.export_items()
            if not items:return
            import doc_files
            options=dict(defaultextension='.svg',filetypes=doc_files.export_types('svg'));folder=doc_files.initial_dir(self.prefs)
            if folder:options['initialdir']=folder
            file=filedialog.asksaveasfilename(**options)
            if file:export_svg(file,items);doc_files.remember_folder(self.prefs,file);self.persist_preferences()

        def dialog(self,title):
            w=tk.Toplevel(self);w.title(title);w.configure(bg=self.p['panel']);w.transient(self);w.grab_set();w.resizable(False,False)
            w.geometry(f'+{self.winfo_rootx()+160}+{self.winfo_rooty()+110}')
            return w

        def workspace_dialog(self):
            # 0.19.13: bases libres (columns and rows, by profile)
            return __import__('base_profiles').dialog(self)
        def old_workspace_dialog(self):
            if not self.workspace:self.status.set('Choisissez une base avec la roue crantée.');return
            win=self.dialog('Organisation des colonnes')
            self.label(win,'Dimensions en '+self.units.get()+' · une seule ligne sous les titres').pack(padx=20,pady=15)
            fields={};grid=tk.Frame(win,bg=self.p['panel']);grid.pack(padx=20,pady=5,fill='x')
            entries=[(LABELS[j],f'col{j}',v) for j,v in enumerate(self.workspace['widths'])]
            entries += [('Hauteur de dessin visible','height',self.workspace['height']),('Hauteur des titres','header',self.workspace['header'])]
            for i,(label,key,value) in enumerate(entries):
                self.label(grid,label).grid(row=i,column=0,sticky='w',padx=(0,15),pady=4)
                fields[key]=tk.StringVar(value=self.format_length(value));self.entry(grid,fields[key],12).grid(row=i,column=1,sticky='ew',pady=4)
            def apply():
                try:
                    data=copy.deepcopy(self.workspace);data['widths']=[self.to_mm(fields[f'col{j}'].get()) for j in range(6)]
                    data['height']=self.to_mm(fields['height'].get());data['header']=self.to_mm(fields['header'].get())
                    data=validate_workspace(data);self.snapshot();self.workspace=data;win.destroy();self.refresh();self.fit_workspace()
                except ValueError as exc:messagebox.showerror('Réglage invalide',str(exc),parent=win)
            self.button(win,'Appliquer',apply).pack(fill='x',padx=20,pady=15)

        def preferences_dialog(self):
            win=self.dialog('Personnaliser l’interface');draft=copy.deepcopy(self.prefs);chips={}
            self.label(win,'Icônes et textes contrastés automatiquement · taille réglable').pack(padx=20,pady=15)
            form=tk.Frame(win,bg=self.p['panel']);form.pack(padx=20,fill='x')
            for row,(key,title) in enumerate([('canvas','Fond du dessin'),('panel','Fond des barres d’outils'),('guides','Repères de base'),('accent','Sélection et aperçu')]):
                self.label(form,title).grid(row=row,column=0,sticky='w',padx=(0,20),pady=6)
                def choose(k=key):
                    result=colorchooser.askcolor(draft[k],parent=win,title='Choisir une couleur')[1]
                    if result:draft[k]=result;chips[k].configure(bg=result)
                chips[key]=modern_style.make_button(form,bg=draft[key],width=8,command=choose,kind='swatch');chips[key].grid(row=row,column=1)
            size=tk.StringVar(value=str(draft['icon_size']))
            self.label(form,'Taille des icônes (px)').grid(row=5,column=0,sticky='w',pady=12)
            ttk.Combobox(form,textvariable=size,values=(16,20,24,32,40),width=7,state='readonly').grid(row=5,column=1)
            def apply():
                draft['icon_size']=int(size.get());self.prefs.update(draft);self.p=auto_palette(self.prefs)
                self.persist_preferences();win.destroy();self.rebuild_ui()
            self.button(win,'Appliquer',apply).pack(fill='x',padx=20,pady=15)

        def rebuild_ui(self):
            modern_style.apply(self,self.p)   # 0.19.0: new colours for the widgets, ttk, menus and the title bar
            self.root_frame.destroy();self.build();self.sync_fields();self.refresh();self.canvas.focus_set()

    return Studio
