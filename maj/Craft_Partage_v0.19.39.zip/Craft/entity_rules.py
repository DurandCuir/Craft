"""Entity roles and explicit piece/identification ownership. Standard library only."""
import math,uuid,threading,contextlib
from geometry import path,bounds

def geometry_entity(s):
    # 0.17.0: a preparation zone is not geometry either: never cut, offset or used as a contour.
    return not(s.get('is_notch') or s.get('annotation') or s.get('drill') or s.get('dimension_group') or s.get('filled') or s.get('preparation'))

def closed_piece(s):
    # 0.16.20: rectangles, circles and ovals are closed pieces too, not only closed polylines.
    # 0.18.0: a closed stitch (Piqûre) is a line of its piece, never a piece.
    if not geometry_entity(s) or s.get('kind')=='line' or s.get('stitch'):return False
    # 0.19.36 (review): nor a line of the « Préparation » type (craft_tools.prep_line): a label inside a piece it surrounds
    # stays the piece's, it is never named as a piece
    st=s.get('style')
    if (st.get('role')=='prep_line' if isinstance(st,dict) and 'role' in st else s.get('profile')=='Préparation'):return False
    if s.get('kind')=='poly':return bool(s.get('closed'))
    try:return bool(path(s)[1])
    except (ValueError,KeyError,TypeError):return False

def ensure_piece_id(s):
    if not s.get('piece_id'):s['piece_id']=uuid.uuid4().hex
    return s['piece_id']

def text_inside(piece,label):
    from precision_geometry import inside,contour_location
    from cad import intersections,project
    pts,_=path(label)
    if not pts:return False
    contained=lambda p:inside(piece,p) or math.dist(contour_location(piece,p)[1],p)<.01
    if not all(contained(p) for p in pts):return False
    # Split every label edge at boundary crossings, including narrow concavities.
    hits=intersections(label,piece)
    for a,b in zip(pts,pts[1:]+pts[:1]):
        length=math.dist(a,b)
        if length<1e-8:continue
        cuts=[0.,1.]
        for p in hits:
            if math.dist(project(p,a,b),p)<.01:cuts.append(max(0,min(1,((p[0]-a[0])*(b[0]-a[0])+(p[1]-a[1])*(b[1]-a[1]))/length**2)))
        cuts=sorted(set(cuts))
        for lo,hi in zip(cuts,cuts[1:]):
            t=(lo+hi)/2
            if not contained((a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1]))):return False
    return True

def identification_kind(s):
    data=s.get('identification') or {}
    # 0.19.28 (second review): a label written wrong (identification not a dict, values not a list) is none
    if not s.get('annotation') or not isinstance(data,dict) or not isinstance(data.get('values',[]),(list,tuple)):return None
    if not any(str(v).strip() for v in data.get('values',[])):return None
    return data.get('kind') if data.get('kind') in ('part_name','material') else None

class Reading:
    """0.19.28: ``items`` read once for a whole fiche (``reading``): the labels and the pieces an
    unattached one is inside, each piece's labels, the crans and the lines that may go with a
    piece, what each piece id owns. A fiche of DIFORME: its 33 pieces each looked for their labels
    three times among the 345 items, and for their crans and inner lines once for each picture.
    The same results as reading ``items`` again each time (tests/test_v1928.py)."""
    def __init__(self,items):
        self.items=items;self.size=len(items);self._kinds=None
        self._closed=None;self.holders={};self.labels={};self.fabrication={};self.sorted={}
        self.with_piece={};self.origins={};self.points={};self._roots=None;self._owned=None;self._numbers=None
    @property
    def kinds(self):
        """[(index, kind)] of the labels (read when a piece first asks, as before)"""
        if self._kinds is None:self._kinds=[(i,k) for i,s in enumerate(self.items) for k in (identification_kind(s),) if k]
        return self._kinds
    def closed(self):
        if self._closed is None:self._closed=[j for j,s in enumerate(self.items) if closed_piece(s)]
        return self._closed
    def holder(self,i):
        """The closed pieces the unattached label ``i`` is inside."""
        if i not in self.holders:self.holders[i]=[j for j in self.closed() if text_inside(self.items[j],self.items[i])]
        return self.holders[i]
    def roots(self):
        from craft_tools import style
        if self._roots is None:self._roots=[i for i,s in enumerate(self.items) if closed_piece(s) and style(s)['role']=='external']
        return self._roots
    def owned(self,owner):
        """The indices of what ``owner`` (a piece id) owns, in the drawing's order."""
        if self._owned is None:
            self._owned={}
            for k,s in enumerate(self.items):
                if s.get('owner_id'):self._owned.setdefault(s['owner_id'],[]).append(k)
        return self._owned.get(owner,[]) if owner else []

_now=threading.local()

def current(items):
    """The Reading of ``items`` when one is open in this thread for this very list, unchanged in
    length (never across a change of the drawing), else None."""
    r=getattr(_now,'reading',None)
    return r if r is not None and r.items is items and r.size==len(items) else None

@contextlib.contextmanager
def reading(items):
    """0.19.28: inside, piece_labels, fabrication_ids and what asks ``current`` read ``items``
    once. Nothing may change the drawing inside (a fiche, a list of pieces: only read)."""
    r=current(items)
    if r is not None:
        yield r;return
    old=getattr(_now,'reading',None);_now.reading=Reading(items)
    try:yield _now.reading
    finally:_now.reading=old

def piece_labels(items,index):
    r=current(items)
    if r is not None:
        if index not in r.labels:r.labels[index]=_piece_labels(items,index,r)
        return {k:list(v) for k,v in r.labels[index].items()}
    return _piece_labels(items,index)

def _piece_labels(items,index,r=None):
    piece=items[index];owner=piece.get('piece_id');found={}
    for i,kind in (r.kinds if r is not None else ((i,identification_kind(s)) for i,s in enumerate(items))):
        if not kind:continue
        label=items[i]
        if label.get('owner_id'):
            # 0.16.28: an attached label belongs to its piece even if it goes a little outside.
            if not owner or label['owner_id']!=owner:continue
        elif r is not None:
            # 0.19.28: the pieces it is inside found once, only when it is inside this one (as before: review, a
            # degenerate shape elsewhere is never measured for a label outside every piece).
            if not text_inside(piece,label) or r.holder(i)!=[index]:continue
        else:
            if not text_inside(piece,label):continue
            # Existing documents have no links. Accept only unambiguous containment.
            possible=[j for j,s in enumerate(items) if closed_piece(s) and text_inside(s,label)]
            if possible!=[index]:continue
        found.setdefault(kind,[]).append(i)
    return found

def piece_count(items):
    """0.18.1: finished pieces among the items of an export (closed, Coupe externe): the export
    windows count pieces, not objects (the items already carry a name and a material)."""
    from craft_tools import style
    return sum(1 for s in items if closed_piece(s) and style(s)['role']=='external')

def fabrication_ids(items,selected=None,points=False):
    """Valid pieces with what goes with them; ``points``: pointés too (PDF, 0.17.0)."""
    r=current(items)
    if r is None:return _fabrication_ids(items,selected,points)
    chosen=None if selected is None else set(selected)
    key=(None if chosen is None else tuple(sorted(chosen)),bool(points))   # 0.19.28: once a fiche
    if key not in r.fabrication:r.fabrication[key]=tuple(_fabrication_ids(items,chosen,points,r))
    return list(r.fabrication[key])

def _fabrication_ids(items,selected=None,points=False,r=None):
    from craft_tools import style
    roots=[];labels={}
    for i in (r.roots() if r is not None else range(len(items))):
        s=items[i]
        if r is None and (not closed_piece(s) or style(s)['role']!='external'):continue
        if selected is not None and i not in selected:continue
        owned=piece_labels(items,i)
        if not all(owned.get(k) for k in ('part_name','material')):continue
        roots.append(i);labels[i]=owned
    keep=set(roots)
    # 0.17.0: crans and inner cuts sorted once (80 pieces: 3 s → a few tenths), a cran is only
    # read for its own piece, and the piece's box is checked before measuring.
    def sort(points):
        crans=[];inner=[]
        for i,s in enumerate(items):
            if s.get('dimension_group') or s.get('annotation'):continue
            if s.get('is_notch'):crans.append(i)
            elif style(s)['role']=='internal' or s.get('drill') and (points or not s.get('drill_point')) or s.get('stitch'):inner.append(i)   # 0.18.0: stitches too
        return crans,inner
    if r is None:
        crans,inner=sort(points);origins={};seen={}
        for j in roots:
            keep.update(i for indices in labels[j].values() for i in indices)
            keep.update(_with_piece(items,j,crans,inner,origins,seen))
        return sorted(keep)
    # 0.19.28: what goes with each piece found once; the pointés (the PDF's pictures) apart, only
    # when asked (each line is kept or not for itself: the same as with them in one list).
    if not r.sorted:
        crans,inner=sort(False);more=set(sort(True)[1])-set(inner)
        r.sorted.update(crans=crans,inner=inner,pointed=[i for i in range(len(items)) if i in more])
    for j in roots:
        keep.update(i for indices in labels[j].values() for i in indices)
        for part,(crans,inner) in (('base',(r.sorted['crans'],r.sorted['inner'])),)+((('pointed',([],r.sorted['pointed'])),) if points else ()):
            if (j,part) not in r.with_piece:r.with_piece[j,part]=_with_piece(items,j,crans,inner,r.origins,r.points)
            keep.update(r.with_piece[j,part])
    return sorted(keep)

def _with_piece(items,j,crans,inner,origins,points):
    """The crans and inner lines of piece ``j`` among ``crans`` and ``inner`` (``origins`` and
    ``points``: their places, kept from one piece to the next)."""
    from precision_geometry import inside,contour_location
    from curves import parts_view
    keep=set()
    piece=items[j];owner=piece.get('piece_id');x,y,X,Y=bounds([piece])
    for i in crans:
        s=items[i]
        if s.get('owner_id') and s['owner_id']!=owner:continue
        if i not in origins:origins[i]=path(parts_view(s)[0])[0][0] if s.get('components') else path(s)[0][0]
        origin=origins[i]
        if not(x-.03<=origin[0]<=X+.03 and y-.03<=origin[1]<=Y+.03):continue
        if math.dist(contour_location(piece,origin)[1],origin)<.03:keep.add(i)
    # 0.18.1: a précoupe is cut on its contour only; what is inside goes with the pieces
    # recut at the 2nd step (surcoupe.second_step).
    if piece.get('surcoupe'):return keep
    for i in inner:
        if owner and items[i].get('stitch') and items[i].get('owner_id')==owner:keep.add(i);continue
        if i not in points:points[i]=path(items[i])[0]
        pts=points[i]
        if not pts or not all(x-.01<=p[0]<=X+.01 and y-.01<=p[1]<=Y+.01 for p in pts):continue
        if all(inside(piece,p) or math.dist(contour_location(piece,p)[1],p)<.01 for p in pts):keep.add(i)
    return keep

def linked_selection(items,ids):
    ids={i for i in ids if 0<=i<len(items)};owners={items[i].get('piece_id') for i in ids if closed_piece(items[i])};owners.discard(None)
    # 0.16.26: a dimension (cote) is one object: its lines, arrows and text go together.
    groups={items[i].get('dimension_group') for i in ids};groups.discard(None)
    return sorted(ids|{i for i,s in enumerate(items) if s.get('owner_id') in owners or (groups and s.get('dimension_group') in groups)}|loose_members(items,ids))

def loose_members(items,ids):
    """0.19.39: what the exports take with a piece (_with_piece) though nothing ties it to it (no owner_id): the pointés
    and mèches (« Pointés et mèches », « Trous de ceinture », a Mozart import never attach them), its inner cuts (a
    Mozart import, the Fente d'ardillon, a line made Coupe intérieure) and Piqûres inside it, the crans on its contour:
    they go with the pieces ``ids`` (Coupe externe) as their owned ones (moved, turned, copied, deleted with it); an
    inside one with the smallest piece around it only."""
    from craft_tools import style
    from precision_geometry import inside,contour_location
    from curves import parts_view
    chosen=[i for i in ids if closed_piece(items[i]) and style(items[i])['role']=='external']
    if not chosen:return set()
    loose=[k for k,s in enumerate(items) if k not in ids and not s.get('owner_id') and not s.get('annotation') and not s.get('dimension_group')
           and (s.get('drill') or s.get('is_notch') or s.get('stitch') or (geometry_entity(s) and style(s)['role']=='internal'))]
    if not loose:return set()
    boxes={}
    def box(i):
        if i not in boxes:
            try:boxes[i]=bounds([items[i]])
            except (ValueError,KeyError,TypeError,IndexError):boxes[i]=None
        return boxes[i]
    area=lambda i:(box(i)[2]-box(i)[0])*(box(i)[3]-box(i)[1])
    others=None;out=set()
    for k in loose:
        s=items[k];on=bool(s.get('is_notch'))
        try:
            if s.get('drill'):pts=[(s['x']+s['w']/2,s['y']+s['h']/2)]
            elif on:pts=[path(parts_view(s)[0])[0][0] if s.get('components') else path(s)[0][0]]   # its foot
            else:pts=path(s)[0];pts=pts[::max(1,len(pts)//40)]+pts[-1:]
        except (ValueError,KeyError,TypeError,IndexError):continue
        if not pts:continue
        def holds(i):
            b=box(i)
            if b is None or not all(b[0]-.05<=p[0]<=b[2]+.05 and b[1]-.05<=p[1]<=b[3]+.05 for p in pts):return False
            try:
                if on:return math.dist(contour_location(items[i],pts[0])[1],pts[0])<.03   # as _with_piece
                return all(inside(items[i],p) or math.dist(contour_location(items[i],p)[1],p)<.01 for p in pts)
            except (ValueError,KeyError,TypeError,IndexError,ZeroDivisionError):return False
        mine=[i for i in chosen if holds(i)]
        if not mine:continue
        if not on:
            if others is None:others=sorted((area(i),box(i),i) for i,q in enumerate(items) if i not in ids and closed_piece(q) and style(q)['role']=='external' and box(i) is not None)
            best=min(area(i) for i in mine);x0=min(p[0] for p in pts);y0=min(p[1] for p in pts);x1=max(p[0] for p in pts);y1=max(p[1] for p in pts)
            smaller=False   # a smaller piece around it: its own
            for a,b,i in others:
                if a>=best:break
                if b[0]-.05<=x0 and x1<=b[2]+.05 and b[1]-.05<=y0 and y1<=b[3]+.05 and holds(i):smaller=True;break
            if smaller:continue
        out.add(k)
    return out

def dimension_members(items,ids):
    """Selected ids completed with every part of the selected dimensions."""
    ids={i for i in ids if 0<=i<len(items)};groups={items[i].get('dimension_group') for i in ids};groups.discard(None)
    if not groups:return ids
    return ids|{i for i,s in enumerate(items) if s.get('dimension_group') in groups}

def fresh_copy_ids(items):
    """A copied piece owns its copied labels, never the original piece's labels."""
    mapping={s['piece_id']:uuid.uuid4().hex for s in items if s.get('piece_id')}
    for s in items:
        if s.get('piece_id') in mapping:s['piece_id']=mapping[s['piece_id']]
        if s.get('owner_id') in mapping:s['owner_id']=mapping[s['owner_id']]
    return items

def tool_accepts(tool,s):
    if tool in ('move_anchor','mirror','copy','select','delete','rotate','scale','array'):return True   # 0.19.13 Réseau: what is selected
    if tool=='copy_notch':return bool(s.get('is_notch'))
    if tool=='notch':return geometry_entity(s)
    if tool in ('part_name','material','surcoupe','surcoupe_simple'):return closed_piece(s)   # 0.18.1: the piece chosen before « Précoupe »
    if tool.startswith('paint_'):return geometry_entity(s)
    if tool in ('join','explode','trim','extend','fillet','chamfer','corner','strap_round','strap_point','strap_belt','offset_all','offset_part','offset_vertex'):return geometry_entity(s)
    return False


def update_style(s,**changes):
    """Apply a line style through nested geometry without changing crans."""
    if s.get('is_notch'):return
    from craft_tools import style
    s['style']=dict(style(s),**changes)
    for child in s.get('components',[]):update_style(child,**changes)
