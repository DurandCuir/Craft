"""0.19.13 Contrôle d'assemblage (« assemblages en 2D », 07/11: « tu calcules par rapport à l'épaisseur qu'aura sur
les assemblages la personne, mais ça il faudrait savoir quelle pièce va où et sur quoi »).

A click on the edge of a piece takes its side (between two corners, as the stitches cut a line: a smooth round
piece is one side); Maj + click adds the next side. A click on another piece takes the edge sewn on it (Maj + click:
its next side too). The window says both lengths and their difference, the crans in front of each other (the edges
taken in the direction that puts the most crans in front), the thickness at the seam (the refentes of both pieces,
1 mm when a piece has none; it can be typed), the points of the seam (points per cm of the Piqûre) and the thread
of a lock stitch: at each point, the length of the point and the thickness, for each of the two threads, without
margin. « Écrire sur le plan » leaves it written by the first edge; Entrée starts a new check; Échap ends.

0.19.14: the bag is sewn with the pieces surcoupées, not their précoupe (« ça va être avec les surcoupes que le sac sera
assemblé »): a click on a précoupe takes the side of its piece inside. The thickness at the seam follows the parage
of the edge: biseau, the middle of the bevel (« ça tombe au milieu du biseau »: between the edge and the leather);
rembord, the flap pared and folded on the leather itself (his way: leather + pared), or pared over twice its width
(2 × pared, to tick); another parage, its thickness; the renforts and doublures of the piece (by their names: RENFORT
FACE, DBL FACE…) are offered to tick.

0.19.24 (proposed on 13/11, « Fais les pistes aussi »: « le Contrôle d'assemblage de tout le sac d'un coup »): each check
done is kept with the model (its two edges: the pieces and their sides; Infos du modèle « assemblages », the .crft keeps
them, Annuler does not take them away); « Contrôle d'assemblage du sac… » (Exporter, « Tout le sac… » in the check's
window, typed « assemblage du sac ») checks them all again at once: lengths, écart, crans in front of each other, in a
list and on the plan (green: good; red: an écart over 0,5 mm; orange: crans not all in front; grey: a piece gone or its
sides changed, to check again). A double click opens the check of that pair; « Retirer de la liste ».

0.19.25 (« Go tes propositions et améliore toujours »): « Paires probables… » proposes the edges of two pieces of about
the same length with their crans in front of each other, to tick (proposals); the fiche « Assemblages » (fiches.py)
prints the pairs kept with their numbers, points and thread.

0.19.26 (« Go propositions c bien »): the edges measured at their seam (« En règle générale on pique toujours à 2,5mm.
Pour un Jonc comme sur difforme c’est 5mm »): 2,5 mm from the edge, a jonc's 5 mm kept with its pair
(Seam: the edge moved in, its round corners shorter); « Crans en face » adds on edge 2 the crans missing in front of
edge 1's; the bag's list is the order of montage (Monter / Descendre, numbered on the plan and on the fiche « Montage »),
with the steps between the seams (« il y a les étapes inter à prendre en compte »: typed, or proposed from the pieces:
parage, renfort, surcoupe, rembordé, teinture, jonc)."""
import bisect
import math
import tkinter as tk

COLORS = ('#ff9f1c', '#2ec4b6')
TOLERANCE = 1.   # mm: a cran in front of another one


def _pieces(app, every=False):
    """The edges that are sewn: the pieces (Coupe extérieure) but not the précoupes, and the pieces inside them.
    0.19.24 ``every``: also those of a layer hidden (the pairs kept)."""
    from entity_rules import closed_piece
    from craft_tools import style
    import surcoupe
    out = []
    hidden = __import__('preparation_ui').hidden_ids(app) if hasattr(app, 'prefs') and not every else set()   # 0.19.14: layers hidden
    for k, s in enumerate(app.items):
        if not closed_piece(s) or s.get('annotation') or k in hidden:
            continue
        role = style(s)['role']
        if role == 'external' and not surcoupe.is_precut(s) or role == surcoupe.ROLE and s.get('owner_id'):
            out.append(k)
    return out


def _precuts(app):
    import surcoupe
    hidden = __import__('preparation_ui').hidden_ids(app)   # 0.19.14: a hidden précoupe is not clicked
    return [k for k, s in enumerate(app.items) if surcoupe.is_precut(s) and k not in hidden]


def host(app, k):
    """The piece that carries the data of ``k`` (its précoupe for a piece inside one)."""
    s = app.items[k]
    if s.get('piece_id') or not s.get('owner_id'):
        return s
    return next((q for q in app.items if q.get('piece_id') == s['owner_id']), s)


_CACHE = {}


def sides(piece):
    """[(points, start distance along the contour, length)] between the corners, and the contour's length (kept for
    the same piece: the mouse moves over them)."""
    hit = _CACHE.get(id(piece))
    if hit is not None and hit[0] is piece:
        return hit[1]
    import stitching
    from geometry import path
    from craft_tools import locate
    pts, closed = path(piece)
    out = []
    for run in stitching._runs(pts, closed):
        length = sum(math.dist(a, b) for a, b in zip(run, run[1:]))
        if length > 1e-6:
            out.append((run, locate(piece, run[0])[0], length))
    value = (out, sum(r[2] for r in out))
    if len(_CACHE) > 500:
        _CACHE.clear()
    _CACHE[id(piece)] = (piece, value)
    return value


def _gap(p, run):
    best = 1e18
    for a, b in zip(run, run[1:]):
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = dx * dx + dy * dy
        t = 0 if L == 0 else max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L))
        best = min(best, math.dist(p, (a[0] + t * dx, a[1] + t * dy)))
    return best


def side_at(app, p, reach):
    """(piece index, side index) of the side nearest ``p`` within ``reach`` mm, or None. 0.19.14: on a précoupe, the
    nearest side of the piece inside it."""
    from geometry import bounds
    best = None
    for k in _pieces(app):
        s = app.items[k]
        x, y, X, Y = bounds([s])
        if not (x - reach <= p[0] <= X + reach and y - reach <= p[1] <= Y + reach):
            continue
        for i, (run, start, length) in enumerate(sides(s)[0]):
            d = _gap(p, run)
            if d <= reach and (best is None or d < best[0]):
                best = (d, k, i)
    if best:
        return best[1:]
    import surcoupe
    shown = set(_pieces(app))
    for k in _precuts(app):
        s = app.items[k]
        x, y, X, Y = bounds([s])
        if not (x - reach <= p[0] <= X + reach and y - reach <= p[1] <= Y + reach):
            continue
        if min(_gap(p, run) for run, _, _ in sides(s)[0]) > reach:
            continue
        for j in surcoupe.inner_contours(app.items, k):
            if j not in shown:
                continue
            for i, (run, start, length) in enumerate(sides(app.items[j])[0]):
                d = _gap(p, run)
                if best is None or d < best[0]:
                    best = (d, j, i)
    return best[1:] if best else None


def portion(app, chosen):
    """(points, start, length, total) of the sides ``chosen`` = (piece, [side indices]) taken in the contour's order."""
    k, ids = chosen
    runs, total = sides(app.items[k])
    ids = sorted(ids)
    # contiguous through the end of the contour (the last side then the first ones)
    n = len(runs)
    if len(ids) > 1 and ids[0] == 0 and ids[-1] == n - 1:
        cut = next(i for i in range(1, len(ids)) if ids[i] != ids[i - 1] + 1) if any(ids[i] != ids[i - 1] + 1 for i in range(1, len(ids))) else len(ids)
        ids = ids[cut:] + ids[:cut]
    pts, length = [], 0.
    for i in ids:
        pts += runs[i][0] if not pts else runs[i][0][1:]
        length += runs[i][2]
    return pts, runs[ids[0]][1], length, total


def in_one_run(app, k, ids):
    """0.19.22: the sides ``ids`` of piece ``k`` follow one another (one edge, round the closing corner too)."""
    n = len(sides(app.items[k])[0])
    taken = set(ids)
    return len(taken) == n or sum((j + 1) % n not in taken for j in taken) == 1


def adjacent(app, chosen, i):
    k, ids = chosen
    n = len(sides(app.items[k])[0])
    return any((i - j) % n in (1, n - 1) for j in ids)


_MARKS = {}
_MISSING = object()


def _cran_distance(cran, piece, piece_key):
    """Where the cran sits along the contour of ``piece`` (craft_tools.cran_mark), None when it is not on it; kept by
    their geometry (0.19.26: the bag's list read each piece's crans again for each of its edges, each time)."""
    from craft_tools import cran_mark
    from geometry import geometry_key
    key = (geometry_key(cran), piece_key)
    hit = _MARKS.get(key, _MISSING)
    if hit is _MISSING:
        mark = cran_mark(cran, piece)
        hit = None if mark is None else mark['distance']
        if len(_MARKS) > 20000:
            _MARKS.clear()
        _MARKS[key] = hit
    return hit


def crans(app, k, start, length, total):
    """The crans of piece ``k`` on the portion: their distances from its start (0.19.14: a piece inside a précoupe, the
    crans of its précoupe on its contour)."""
    from geometry import geometry_key
    from entity_rules import current
    piece = app.items[k]
    owner = piece.get('piece_id') or piece.get('owner_id')
    out = []
    piece_key = None
    read = current(app.items)   # 0.19.28: inside a fiche, what each piece owns read once
    for s in ([app.items[j] for j in read.owned(owner)] if read is not None else app.items):
        if s.get('is_notch') and s.get('owner_id') and s.get('owner_id') == owner:
            if piece_key is None:
                piece_key = geometry_key(piece)
            at = _cran_distance(s, piece, piece_key)
            if at is not None:
                d = (at - start) % total if total else 0.
                if d <= length + .05:
                    out.append(min(d, length))
    return sorted(out)


def facing_counts(a, la, b, lb, embu=0.):
    """(crans of a in front of b's, the same with b the other way round); 0.19.36: ``embu`` (mm) eased into the shorter
    edge between its crans: a cran of the longer one up to that much further along"""
    lo, hi = -TOLERANCE, TOLERANCE
    if embu > 0:
        lo, hi = (-TOLERANCE, embu + TOLERANCE) if la >= lb else (-embu - TOLERANCE, TOLERANCE)

    def count(bs):
        left, n = list(bs), 0
        for x in a:
            hit = next((y for y in left if lo <= x - y <= hi), None)
            if hit is not None:
                left.remove(hit)
                n += 1
        return n
    return count(b), count([lb - y for y in b])


def facing(a, la, b, lb, embu=0.):
    """(crans in front of each other, b reversed or not): the direction that puts the most of them in front (0.19.36:
    with an ``embu``, facing_counts)."""
    same, back = facing_counts(a, la, b, lb, embu)
    return (back, True) if back > same else (same, False)


# --- 0.19.26 the seam (« En règle générale on pique toujours à 2,5mm. Pour un Jonc comme sur difforme c’est 5mm ») ------

JONC = 5.   # mm from the edges: a seam with a jonc
SEAM = 2.5   # mm: « En règle générale on pique toujours à 2,5mm »


TISSU = 5.   # mm: 0.19.28 « 5mm de marge en général pour tissu minimum » (14/11/2026)
RETOURNE = 5.   # mm: 0.19.29 « ça peut être monté en piqûre extérieure donc on pique à 2,5 ou piqué retourné donc 5 mm du bord »
POINTS = 3.   # points per cm of a seam: 0.19.29 « 3 pts par cm je t'ai dit » (never the Piqûre tool's last pitch)
PIQURES = (('exterieure', 'Piqûre extérieure (2,5 mm)'), ('retourne', 'Piqué retourné (5 mm)'))


def montage(app):
    """0.19.29: what the model says of its montage (the Infos du modèle « montage »): dict(piqure 'exterieure' /
    'retourne', type: the bag's montage chosen or recognised), {} when nothing is said."""
    data = (app.__dict__.get('infos') or {}).get('montage')
    return dict(data) if isinstance(data, dict) else {}


def piqure(app):
    """0.19.29: 'retourne' (piqué retourné: seams at 5 mm) or 'exterieure' (piqûre extérieure: 2,5 mm, the default)"""
    return 'retourne' if montage(app).get('piqure') == 'retourne' else 'exterieure'


piqure_of = piqure


def default_seam(app):
    """The distance of a seam from the edges: 2,5 mm (review: never the last distance typed in the Piqûre tool, which
    keeps it, 0 too: every pair kept followed it); 0.19.29: 5 mm for a model « piqué retourné »."""
    return RETOURNE if piqure(app) == 'retourne' else SEAM


def points_of(value):
    """0.19.29: a pair's points per cm: its own (typed in the check) or 3 (POINTS)."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return POINTS
    return v if math.isfinite(v) and .5 <= v <= 20 else POINTS


FABRIC_WORDS = ('TOILE', 'TISSU', 'POLYEST', 'COTON', 'NYLON', 'VISCOS', 'MICROFIBR', 'FEUTR', 'POLYAMID', 'TEXTIL', 'JERSEY',
                'TAFFETAS', 'SERGE', 'SERGÉ', 'ACETATE', 'ACÉTATE')   # (the start of a word of the material's name)
FABRIC_NAMES = ('LIN', 'SATIN')   # (a whole word: « veau satiné » is a leather)


def fabric(app, k):
    """0.19.28: piece ``k`` is in fabric: its material is a Tissu in the archives (Matière), or, the archives not knowing
    it, its name says a fabric (« TOILE POLYESTER »: DIFORME's linings; never a lining by its Mozart « F- » alone: a lining
    may be in leather)."""
    import re
    data = (host(app, k).get('piece_info') or {}).get('material') or {}
    name = str((data.get('values') or [''])[0] or '').strip()
    archives = app.__dict__.get('archives') or {}
    if name and (archives.get('material_info') or {}).get(name):
        import materials
        return materials.info(archives, name)['type'] == 'Tissu'
    words = re.findall(r'[^\W\d_]+', (name + ' ' + str((data.get('mozart') or {}).get('MATERIALE') or '')).upper())
    return any(w.startswith(FABRIC_WORDS) or w in FABRIC_NAMES for w in words)


def both_fabric(app, ks):
    """0.19.29: the two pieces ``ks`` of a pair are in fabric"""
    try:
        return bool(ks) and len(ks) == 2 and None not in ks and all(fabric(app, k) for k in ks)
    except (IndexError, KeyError, TypeError, ValueError, AttributeError):
        return False


def plain_seam(app, ks=None):
    """The seam of a pair without one of its own and without a jonc: 5 mm between two pieces in fabric (TISSU), else
    2,5 mm (0.19.29: 5 mm for a model « piqué retourné »)."""
    return TISSU if both_fabric(app, ks) else default_seam(app)


def usual_seam(app, ks=None, sides=None):
    """0.19.28: the seam of a pair without one of its own (plain_seam); 0.19.36 (« sac à jonc : les coutures avec le jonc
    passent d'office à 5 mm »): 5 mm with a jonc (with_jonc: ``sides``, the sides of each of its pieces ``ks``)."""
    return JONC if with_jonc(app, ks, sides) else plain_seam(app, ks)


def seam_of(app, value, ks=None, sides=None):
    """A pair's seam: its own (a jonc: 5 mm) or the usual one (2,5 mm; 0.19.28: 5 mm in fabric, ``ks`` its pieces; 0.19.36:
    5 mm with a jonc, ``sides`` their sides)."""
    if value is None:
        return usual_seam(app, ks, sides)
    try:
        d = float(value)
    except (TypeError, ValueError):
        return usual_seam(app, ks, sides)
    return min(30., max(0., d)) if math.isfinite(d) else usual_seam(app, ks, sides)


_JONC_SIDES = {}


def jonc_sides(app):
    """0.19.36: {piece index: its sides sewn to a jonc (a passepoil): a pair kept with it}, kept for the same plan and
    the same pairs."""
    raw = (app.__dict__.get('infos') or {}).get('assemblages')
    key = (id(app), id(app.items), len(app.items), app.__dict__.get('_doc_version'), repr(raw))
    found = _JONC_SIDES.get('key') == key and _JONC_SIDES.get('value')
    if found is not False and found is not None:
        return found
    out = {}
    try:
        pairs = kept_pairs(app)
        pieces = _pieces(app, every=True) if pairs else []
        for pair in pairs:
            ends = [(piece_index(app, pair[x]['piece'], pieces), e_sides(pair[x])) for x in ('a', 'b')]
            if any(k is None or len(sides(app.items[k])[0]) != pair[x]['count'] for (k, _), x in zip(ends, 'ab')):
                continue   # (review: a pair to check again: its old side numbers are other sides now)
            for i, (k, s) in enumerate(ends):
                if piping(app, ends[1 - i][0]) and not piping(app, k):
                    out.setdefault(k, set()).update(s)
    except (KeyError, TypeError, ValueError, IndexError, AttributeError):
        out = {}
    _JONC_SIDES.update(key=key, value=out)
    return out


def with_jonc(app, ks, sides=None):
    """0.19.36: a seam with a jonc: one of its pieces ``ks`` is the jonc (a passepoil), or ``sides`` of one of them (the
    sides of each piece) are sewn to a jonc too (a kept pair: the jonc goes in this seam: DIFORME's FACE / CAVOUR)."""
    try:
        if not ks or None in ks:
            return False
        if any(piping(app, k) for k in ks):
            return True
        if not sides:
            return False
        sewn = jonc_sides(app)
        return any(k in sewn and sewn[k] & set(s or ()) for k, s in zip(ks, sides))
    except (KeyError, TypeError, ValueError, IndexError, AttributeError):
        return False


def seam_kind(value, d, woven=None, retourne=False):
    """0.19.28: what the seam ``d`` is (``value``: the pair's own, None): 'jonc', 'tissu' (5 mm, two pieces in fabric), None
    (0.19.29 ``woven``: the two pieces are in fabric, when known: a model « piqué retourné » sews leather at 5 mm too;
    ``retourne``: the pair's own 5 mm is a piqué retourné (a fond rapporté in a bag sewn outside), never a jonc)."""
    if value is not None:
        if retourne:
            return 'retourné'
        return 'jonc' if abs(d - JONC) < 1e-9 else None
    if woven is not None:
        return 'tissu' if woven else None
    return 'tissu' if abs(d - TISSU) < 1e-9 and abs(TISSU - SEAM) > 1e-9 else None


def seam_info(app, value, ks=None, retourne=False, sides=None):
    """0.19.29: (the seam of a pair: its distance from the edges, what it is: 'jonc', 'tissu', 'retourné' or None);
    0.19.36: 'jonc' too for a seam with a jonc without a seam of its own (``sides``: with_jonc)"""
    d = seam_of(app, value, ks, sides)
    if value is None and with_jonc(app, ks, sides):
        return d, 'jonc'
    return d, seam_kind(value, d, both_fabric(app, ks), retourne)


EMBU_MOST = 50.   # mm: the embu a seam may keep (0.19.36)


def embu_of(pair):
    """0.19.36 (« l'embu par couture » for the RIDER's « effet bombé »: 4 mm in each corner of the face): the écart a seam is
    meant to have (mm, eased into its shorter edge between its crans), 0 when none"""
    try:
        v = float(pair.get('embu') or 0.)
    except (TypeError, ValueError, AttributeError):
        return 0.
    return min(EMBU_MOST, v) if math.isfinite(v) and v > 0 else 0.


def embu_words(v):
    return f'embu {_mm(v)} mm' if v > 0 else ''


def _st_sides(st):
    """0.19.36: the sides of each edge of a check (st['a'], st['b']: (piece, sides))"""
    try:
        return (list(st['a'][1]), list(st['b'][1]))
    except (KeyError, TypeError, IndexError):
        return None


def is_jonc(pair):
    """0.19.29: the pair (or the check) is sewn with a jonc: its own 5 mm, not a piqué retourné's"""
    try:
        d = float(pair.get('seam'))
    except (TypeError, ValueError):
        return False
    return not pair.get('retourne') and abs(d - JONC) < 1e-9


BAND_MOST = 30.   # 0.19.29: a rembord zone wider than this is not a band along one edge


def rembord_width(app, k, pts, double=False):
    """0.19.29 (« si rembordé alors il y aura un rajout pour le rembord sinon c'est bord franc »; « oui sauf si la personne
    choisit de parer la zone entière et donc si rembord de 7 mm elle pare 14 »): the width folded under along the edge
    ``pts`` of piece ``k``: its parage « rembord » zone's width (half of it when pared on twice its width, ``double``),
    0 for a bord franc."""
    zone = parage(app, k, pts, True)
    if zone is None or 'REMBORD' not in str(zone[0].get('type') or '').upper():
        return 0.
    try:
        w = float(__import__('preparation_ui').zone_width(zone[1]))
    except (TypeError, ValueError, ZeroDivisionError):
        return 0.
    if not math.isfinite(w) or w <= 0 or w > BAND_MOST:
        return 0.   # a zone over the whole piece (DIFORME's FACE, « REMBORD 7 »): it does not say which edge is folded
    return w / 2 if double else w


def reaches(app, seam, ks, edges, double=False):
    """0.19.29: where each edge of a pair is measured, mm inside its piece: two pieces in fabric at the cut (« la mesure
    sur polyligne fait la même longueur » : the fabric eases into the rounds), a rembordé edge from its fold (its rembord's
    width + the seam), else at the seam. ``edges``: [(k, its points at the cut)]."""
    if both_fabric(app, ks):
        return [0. for _ in edges]
    return [seam + rembord_width(app, k, pts, double) for k, pts in edges]


# 0.19.35 (« comprendre que si c'est un parage rembord, une fois rembordé le côté fera la même longueur que le cavour. Il
# faudrait donc qu'assemblage comprenne que ça doit s'arrêter à l'intersection si la préparation parage est faite », 16/11
# 23 h 49): the seam of an edge that runs into a parage « rembord » band of its piece stops where it meets the band's fold
# (the rest is folded under): measured, its crans counted and placed, drawn so, in the check, the bag, the proposals.
FOLD_STEP = .25   # mm between the points of a seam looked at for a fold (the crossing then halved 12 times)
PROBE = .05   # (review) mm inside the cut where an edge measured at the cut is looked at for a fold


def _bands(app, k):
    """0.19.35: (the parage « rembord » bands of piece ``k``: [(its ring, its width)], unknown: a rembord zone of the piece is
    not a band along an edge: pared over the whole piece (DIFORME_DA's FACE, « Rembord 7 »), which edge is folded is not
    said). Its zones, and a zone without its piece lying on it (most of its points inside)."""
    from geometry import bounds, geometry_key, path
    zone_width = __import__('preparation_ui').zone_width
    piece = app.items[k]
    owners = {piece.get('piece_id'), piece.get('owner_id'), host(app, k).get('piece_id')} - {None}
    bands, unknown, contour, ids, box, boxes = [], False, None, None, None, None
    for s in app.items:
        data = s.get('preparation')
        if not isinstance(data, dict) or data.get('kind') != 'parage' or 'REMBORD' not in str(data.get('type') or '').upper():
            continue
        try:
            ring = [(float(p[0]), float(p[1])) for p in path(s)[0]]
            if contour is None:
                contour = [(float(p[0]), float(p[1])) for p in path(piece)[0]]
                box = bounds([piece])
        except (TypeError, ValueError, ZeroDivisionError, KeyError, IndexError):
            if s.get('owner_id') in owners:
                unknown = True
            continue
        if s.get('owner_id') not in owners:
            if ids is None:
                ids = {q.get('piece_id') for q in app.items if q.get('piece_id')}
            # (a zone left without its piece, DIFORME_DA's DOS: the piece it lies on; never another piece's)
            if s.get('owner_id') in ids or len(ring) < 3:
                continue
            xs, ys = [p[0] for p in ring], [p[1] for p in ring]
            zbox = (min(xs), min(ys), max(xs), max(ys))
            # (review) a zone far from the piece: never on it (measured against its contour only when the boxes meet; DIFORME_DA:
            # checks 3 → 18 ms); a point on the contour is on the piece (inside() said yes or no by the side: a band along the
            # bottom or the right side was never counted)
            if zbox[2] < box[0] or zbox[0] > box[2] or zbox[3] < box[1] or zbox[1] > box[3] or 2 * _near_count(
                    ring, contour, .05, key=geometry_key(piece)) < len(ring):
                # (review) a rembord over a whole piece left on no piece (DIFORME_DA's DOS: its zone beside it): which piece it
                # folds is not said, every pair measured as before (else the cavour folded alone: 14 mm off the DOS)
                if boxes is None:
                    from entity_rules import closed_piece
                    boxes = [bounds([q]) for q in app.items if q.get('piece_id') and closed_piece(q)]
                try:
                    whole = not 0 < float(zone_width(s)) <= BAND_MOST
                except (TypeError, ValueError, ZeroDivisionError, KeyError, IndexError):
                    whole = True
                if whole and not any(zbox[2] >= b[0] and zbox[0] <= b[2] and zbox[3] >= b[1] and zbox[1] <= b[3] for b in boxes):
                    unknown = True
                continue
        try:
            w = float(zone_width(s))
        except (TypeError, ValueError, ZeroDivisionError, KeyError, IndexError):
            unknown = True
            continue
        if not math.isfinite(w) or w <= 0 or w > BAND_MOST or len(ring) < 3:
            unknown = True
            continue
        bands.append((ring, w))
    return bands, unknown


def _folded(bands, p, others=None):
    """0.19.35: the point ``p`` is folded under by one of ``bands``: inside it (pared on twice its fold, ``others``: the
    piece's other sides, within half its width of them)"""
    from preparations import inside
    for ring, w in bands:
        if inside(ring, p) and (others is None or min(_gap(p, run) for run in others) < w / 2):
            return True
    return False


def _walk(pts):
    """0.19.35: (the length of the line ``pts``, the point y mm along it)"""
    starts, total = [0.], 0.
    for a, b in zip(pts, pts[1:]):
        total += math.dist(a, b)
        starts.append(total)

    def at(y):
        k = min(max(0, bisect.bisect_right(starts, y) - 1), len(pts) - 2)
        if k < 0:
            return pts[0]
        a, b = pts[k], pts[k + 1]
        span = starts[k + 1] - starts[k]
        f = 0. if span < 1e-12 else min(1., max(0., (y - starts[k]) / span))
        return (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)
    return total, at


def folds(app, chosen, d, double=False, bands=None):
    """0.19.35: (mm, mm) the seam of the edge ``chosen`` (``d`` mm inside its piece; 0: the cut) loses at its start and at its
    end in a parage « rembord » band of its piece (``bands``, else read): folded under, up to the band's fold (its width;
    half of it from the piece's other sides when pared on twice its width, ``double``). Never for the whole contour (no
    end), nor along a band (its seam in it further than a crossing goes: the band of the edge itself)."""
    k, ids = chosen
    if bands is None:
        bands = _bands(app, k)[0]
    if not bands:
        return (0., 0.)
    try:
        from craft_tools import interior_side
        from geometry import path
        from preparations import inside
        runs = sides(app.items[k])[0]
        if len(set(ids)) >= len(runs):
            return (0., 0.)
        others = [list(run[0]) for i, run in enumerate(runs) if i not in set(ids)] if double else None
        pts = portion(app, chosen)[0]
        # (review) at the cut (fabric, a seam typed 0) its points lie on the band's own sides (inside() says yes or no by the
        # side: one end folded, not the other): looked at a hair inside
        line = seam_line(pts, max(d, PROBE), interior_side(app.items[k]))
        total, at = line.length, (lambda y: line.point(y)[0])
        contour = [(float(p[0]), float(p[1])) for p in path(app.items[k])[0]]
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        return (0., 0.)
    if not total > 0:
        return (0., 0.)
    most = min(total / 2, 2 * max(w for _, w in bands) + d + 2)

    def trim(where):
        y = .05
        while y < most and not inside(contour, where(y)):   # (review: by an acute corner, a face wider at its top, the
            y += FOLD_STEP                                  # seam starts square to the edge, outside the piece)
        if y >= most or not _folded(bands, where(y), others):
            return 0.
        start = y
        while y < most and _folded(bands, where(y), others):
            y += FOLD_STEP
        if y >= most:
            return 0.   # (along a band, never across it)
        if others is not None:   # (review: pared on twice its width, the rembordé edge's own seam runs in its zone, near
            z = y                # the sides at its ends: never cut there)
            while z < most and _folded(bands, where(z)):
                z += FOLD_STEP
            if z >= most:
                return 0.
        lo, hi = max(start, y - FOLD_STEP), y
        for _ in range(12):
            mid = (lo + hi) / 2
            if _folded(bands, where(mid), others):
                lo = mid
            else:
                hi = mid
        return hi
    try:
        return (trim(at), trim(lambda y: at(total - y)))
    except (ValueError, TypeError, IndexError, ZeroDivisionError):
        return (0., 0.)


edge_folds = folds   # (proposals: « folds » is its own table there)


PIPING_WORDS = ('JONC', 'PASSEPOIL')   # (as montage_auto.JONC_WORDS)


def piping(app, k):
    """0.19.35 (review: his DIFORME_DA_crans, CAVOUR / JONC 569,66 = 569,66 lost): a jonc (passepoil) is sewn in the seam to
    its ends and folded with the rembord of the pieces it goes between: its pairs measured to the end, as before."""
    try:
        return any(w in _name(host(app, k)) for w in PIPING_WORDS)
    except (ValueError, KeyError, TypeError, IndexError, AttributeError):
        return False


def pair_folds(app, edges, reach, double=False):
    """0.19.35: [(mm, mm)] what each edge of a pair (``edges``: [(k, ids)], each measured at its ``reach``) loses to the folds of
    its rembords; none at all when a piece of the pair has a rembord zone that is not a band (which edge it folds is not
    said: the pair measured as before, never one edge shortened alone), or is a jonc (piping)."""
    if any(piping(app, k) for k, _ in edges):
        return [(0., 0.) for _ in edges]
    known = [_bands(app, k) for k, _ in edges]
    if any(unknown for _, unknown in known):
        return [(0., 0.) for _ in edges]
    return [folds(app, e, r, double, bands) for e, r, (bands, _) in zip(edges, reach, known)]


def _cut_line(points, a, b):
    """0.19.35: the part of the line ``points`` from ``a`` mm to ``b`` mm along it"""
    total, at = _walk(points)
    out, travel = [at(a)], 0.
    for p, q in zip(points, points[1:]):
        travel += math.dist(p, q)
        if a < travel < b:
            out.append(q)
    return out + [at(b)]


def with_folds(shut, folded):
    """0.19.35: what each edge's seam loses at its ends: the closing of a tube (closings) or a rembord's fold, the most"""
    return tuple((max(s[0], f[0]), max(s[1], f[1])) for s, f in zip(shut, folded))


def seam_text(d, kind=None):
    return _mm(d, 1) + (f' {kind}' if kind else '')


def seam_words(d, kind=None):
    return f'à {_mm(d, 1)} mm du bord' + (f', {kind}' if kind else '')


class Seam:
    """0.19.26: an edge (its points in the contour's order) at its seam, ``d`` mm inside its piece (``inside``: 1 when the
    inside is on the left of the points): each straight part moved in, the moved parts meeting at their corners (a round
    corner of radius R: d × its angle shorter; a part that vanishes, as a round corner smaller than d, goes and its
    neighbours meet), the ends square to the edge. ``length``; ``at(x)``: where the point ``x`` mm along the edge (a
    cran) falls on the seam, in mm from its start; ``point(y)`` the point ``y`` mm along the seam, ``back(y)`` the
    point of the edge in front of it."""

    MITER = 4.   # a corner turning away from the inside: the seam meets at most this many times d from it, else cut square

    def __init__(self, pts, d, inside, _open=False):
        self.ring = None
        if not _open and len(pts) > 3 and math.dist(pts[0], pts[-1]) < 1e-6:   # the whole contour: its closing corner too
            lengths = [math.dist(a, b) for a, b in zip(pts, pts[1:])]
            total = sum(lengths)
            if total > 1e-9:   # (a seam round it: started in the middle of its longest part, where it has no corner)
                i = max(range(len(lengths)), key=lengths.__getitem__)
                a, b = pts[i], pts[i + 1]
                mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
                rot = Seam([mid] + list(pts[i + 1:]) + list(pts[1:i + 1]) + [mid], d, inside, True)
                s_mid = sum(lengths[:i]) + lengths[i] / 2
                self.ring = (rot, s_mid, total, rot.at((total - s_mid) % total))
                self.points, self.length, self.cut, self.samples, self.corners = rot.points, rot.length, total, rot.samples, {}
                return
        segs, travel = [], 0.
        for a, b in zip(pts, pts[1:]):
            L = math.dist(a, b)
            if L < 1e-9:
                continue
            u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
            n = (-u[1] * inside * d, u[0] * inside * d)
            segs.append(((a[0] + n[0], a[1] + n[1]), u, n, travel, L, a))
            travel += L
        self.segs, self.cut, self.travels, self.samples, self.corners = segs, travel, [q[3] for q in segs], None, {}
        if not segs:
            self.points, self.starts, self.order, self.length = list(pts[:1]) or [(0., 0.)], [0.], [], 0.
            return
        if not self._parts(d, inside):   # (an edge too tangled for its parts' meeting points: a spike, a slit)
            self._sampled(d, inside)

    def _parts(self, d, inside):
        """The seam from the moved parts and their meeting points; False when a meeting point is not one of the seam (a
        part met far from where it is: a spike's two sides nearly in line)."""
        segs = self.segs
        near = 1e-6 * max(1., d)

        def along(i, m):   # where m falls along part i, from the start of its moved line
            q, u = segs[i][:2]
            return (m[0] - q[0]) * u[0] + (m[1] - q[1]) * u[1]
        kept = [[0, segs[0][0], None]]   # [part, where its seam starts, 'chord' round a slit's end / 'inside' corner]
        for j in range(1, len(segs)):
            q, v, _, _, Lj, aj = segs[j]
            i = kept[-1][0]
            u = segs[i][1]
            cross = u[0] * v[1] - u[1] * v[0]
            if j == i + 1 and cross * inside < 0:   # a corner turning away from the inside: both parts go on to meet
                b = segs[i]
                m = self._meet(i, j) if abs(cross) > 1e-9 else None
                if m is not None and along(i, m) >= b[4] - near and along(j, m) <= near and math.dist(m, aj) <= self.MITER * d:
                    kept.append([j, m, 'inside'])
                else:   # (a slit: the seam cut square round its end)
                    kept += [[j, (b[5][0] + b[1][0] * b[4] + b[2][0], b[5][1] + b[1][1] * b[4] + b[2][1]), 'chord'], [j, q, None]]
                continue
            gone = False   # parts kept before j vanished
            while True:
                i, s, _ = kept[-1]
                m = self._meet(i, j)
                if along(i, m) <= along(i, s) + 1e-9:
                    if len(kept) > 1:
                        kept.pop()   # this part vanishes between its neighbours
                        if len(kept) > 1 and kept[-1][0] == i and kept[-1][2] == 'chord':
                            kept.pop()   # (second review: with the chord round the slit before it)
                        gone = True
                        continue
                    t = along(j, s)   # (the first part vanishes: the seam starts on part j, in front of its start)
                    if not -near <= t <= Lj + near:
                        return False
                    kept[0], m = [j, (q[0] + v[0] * t, q[1] + v[1] * t), None], None
                elif along(j, m) >= Lj - 1e-9:
                    m = None   # part j vanishes behind part i
                break
            if m is None:
                continue
            if (gone or j != i + 1) and not (-near <= along(j, m) and along(i, m) <= segs[i][4] + near):
                return False   # met beyond the parts themselves
            kept.append([j, m, None])
        last = segs[-1]
        end = (last[5][0] + last[1][0] * last[4] + last[2][0], last[5][1] + last[1][1] * last[4] + last[2][1])
        i, s, _ = kept[-1]
        if i != len(segs) - 1:   # the last part vanished: the seam ends on the last one kept, in front of the edge's end
            t = along(i, end)
            if not along(i, s) - near <= t <= segs[i][4] + near:
                return False
            q, u = segs[i][:2]
            end = (q[0] + u[0] * t, q[1] + u[1] * t)
        self.order = [i for i, _, _ in kept]
        self.points = [s for _, s, _ in kept] + [end]
        self.starts = [0.]
        for a, b in zip(self.points, self.points[1:]):
            self.starts.append(self.starts[-1] + math.dist(a, b))
        self.length = self.starts[-1]
        # (second review) a cran on an inside corner: where the two seams meet there
        self.corners = {j: self.starts[k] for k, (j, _, kind) in enumerate(kept) if kind == 'inside'}
        return self._clear(d, {k for k, e in enumerate(kept) if e[2] == 'chord'})

    def _grid(self, d, cell):
        """The edge's parts by the squares of ``cell`` mm they come within d of (along each part: second review, a long
        slanting part filled its whole box, a second for a 1,2 m strap at 0,5 mm)."""
        grid, floor = {}, math.floor
        for k, (_, u, _, _, L, a) in enumerate(self.segs):
            if L <= 2 * cell:   # (a short part: its box)
                b = (a[0] + u[0] * L, a[1] + u[1] * L)
                boxes = [(min(a[0], b[0]) - d, min(a[1], b[1]) - d, max(a[0], b[0]) + d, max(a[1], b[1]) + d)]
            else:   # (a long one: the boxes round its points every cell, each d + cell / 2 wide)
                r = d + cell / 2
                boxes = [(a[0] + u[0] * t - r, a[1] + u[1] * t - r, a[0] + u[0] * t + r, a[1] + u[1] * t + r)
                         for t in (min(n * cell, L) for n in range(int(L // cell) + 2))]
            for x0, y0, x1, y1 in boxes:
                for gx in range(floor(x0 / cell), floor(x1 / cell) + 1):
                    for gy in range(floor(y0 / cell), floor(y1 / cell) + 1):
                        cell_parts = grid.setdefault((gx, gy), [])
                        if not cell_parts or cell_parts[-1] != k:
                            cell_parts.append(k)
        return grid

    def _clear(self, d, chords):
        """Every point of the seam (each meeting point, and every 2 d along a long part) d at least from every part of the
        edge, else False (the edge tangled: a spike narrower than the seam); ``chords``: parts cut square round a slit
        (nearer: as they should be)."""
        cell, limit = max(2. * d, 1.), (d - 1e-6 * max(1., d)) ** 2
        grid = self._grid(d, cell)
        parts = [(q[5][0], q[5][1], q[1][0], q[1][1], q[4]) for q in self.segs]
        floor = math.floor

        def far(x, y, own):
            for o in grid.get((floor(x / cell), floor(y / cell)), ()):
                if o != own:
                    ax, ay, ux, uy, L = parts[o]
                    t = (x - ax) * ux + (y - ay) * uy
                    t = 0. if t < 0. else L if t > L else t
                    dx, dy = x - ax - ux * t, y - ay - uy * t
                    if dx * dx + dy * dy < limit:
                        return False
            return True
        pts, order, step = self.points, self.order, 2. * d
        for k, (p0, p1) in enumerate(zip(pts, pts[1:])):
            if k in chords:
                continue
            own = order[k]
            if not far(p0[0], p0[1], own):
                return False
            count = int(math.dist(p0, p1) // step)
            for t in range(1, count + 1):
                f = t / (count + 1)
                if not far(p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f, own):
                    return False
        return len(pts) < 2 or len(pts) - 2 in chords or far(pts[-1][0], pts[-1][1], order[-1])

    def _distance(self, p, k):
        """From p to the edge's part k."""
        a, u, L = self.segs[k][5], self.segs[k][1], self.segs[k][4]
        t = min(max((p[0] - a[0]) * u[0] + (p[1] - a[1]) * u[1], 0.), L)
        return math.hypot(p[0] - a[0] - u[0] * t, p[1] - a[1] - u[1] * t)

    STEP = .25   # mm between the points of an edge moved in (the fallback)

    def _sampled(self, d, inside):
        """(fallback) points of the edge every STEP mm moved in by d, those nearer than d to the edge dropped (a corner cut
        by its neighbours), the seam through the others; each kept with the point of the edge it comes from."""
        segs, near, cell = self.segs, 1e-5 * max(1., d), max(2. * d, 1.)
        grid = self._grid(d, cell)

        def trim(u, v):   # how much a corner toward the inside cuts each of its parts at the seam (else 0)
            cross, dot = u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1]
            return d * math.tan(min(abs(math.atan2(cross, dot)), math.radians(170)) / 2) if cross * inside > 0 else 0.
        xs, ys, points, cuts, y, last = [], [], [], [], 0., None
        for k, (_, u, n, travel, L, a) in enumerate(segs):
            count = max(1, math.ceil(L / self.STEP))
            spots = {L * t / count for t in range(count + (k == len(segs) - 1))}
            t0 = trim(segs[k - 1][1], u) if k else 0.   # (second review: where the part's seam begins and ends, so that a
            t1 = L - trim(u, segs[k + 1][1]) if k + 1 < len(segs) else L   # round a little wider than the seam keeps it)
            spots |= {t for t in (t0, t1) if 0. <= t <= L and t0 <= t1 and (t < L or k == len(segs) - 1)}
            for tt in sorted(spots):
                c = (a[0] + u[0] * tt, a[1] + u[1] * tt)
                p = (c[0] + n[0], c[1] + n[1])
                if all(self._distance(p, o) >= d - near for o in grid.get((math.floor(p[0] / cell), math.floor(p[1] / cell)), ()) if o != k):
                    if last is not None:
                        y += math.dist(last, p)
                    last = p
                    points.append(p)
                    cuts.append(c)
                    ys.append(y)
                xs.append(travel + tt)
                if len(ys) < len(xs):   # (dropped: at the place of the last point kept)
                    ys.append(y)
        if not points:
            points, cuts, ys = [segs[0][0]], [segs[0][5]], [0.] * len(xs)
        self.samples, self.corners = (xs, ys, cuts), {}
        self.order, self.points = [], points
        self.starts = [0.]
        for a, b in zip(points, points[1:]):
            self.starts.append(self.starts[-1] + math.dist(a, b))
        self.length = self.starts[-1]

    def _meet(self, i, j):
        (p, u), (q, v) = self.segs[i][:2], self.segs[j][:2]
        den = u[0] * v[1] - u[1] * v[0]
        if abs(den) < 1e-9:   # in line (or a half turn): the next part's start
            return q
        t = ((q[0] - p[0]) * v[1] - (q[1] - p[1]) * v[0]) / den
        return (p[0] + u[0] * t, p[1] + u[1] * t)

    def at(self, x):
        if self.ring:
            rot, s_mid, total, y0 = self.ring
            return (rot.at((x - s_mid) % total) - y0) % self.length if self.length else 0.
        if self.samples:
            xs, ys, _ = self.samples
            i = bisect.bisect_right(xs, x) - 1
            if i < 0:
                return ys[0]
            if i >= len(xs) - 1:
                return ys[-1]
            f = (x - xs[i]) / (xs[i + 1] - xs[i]) if xs[i + 1] > xs[i] else 0.
            return ys[i] + (ys[i + 1] - ys[i]) * f
        if not self.order:
            return x
        j = max(0, bisect.bisect_right(self.travels, x) - 1)
        if self.corners:
            c = bisect.bisect_left(self.travels, x - 1e-6)
            if c < len(self.travels) and abs(self.travels[c] - x) <= 1e-6 and c in self.corners:
                return self.corners[c]   # (on an inside corner: where its two seams meet)
        k = bisect.bisect_right(self.order, j) - 1
        if k < 0:
            return 0.   # (on a part that vanished before the seam's start)
        if self.order[k] != j:
            return self.starts[k + 1]   # a part that vanished: at the corner where it went
        q0, u, n, travel, L, a = self.segs[j]
        t = min(max(x - travel, 0.), L)
        moved = (a[0] + u[0] * t + n[0], a[1] + u[1] * t + n[1])
        p0, p1 = self.points[k], self.points[k + 1]
        w = (p1[0] - p0[0], p1[1] - p0[1])
        ww = w[0] * w[0] + w[1] * w[1]
        f = 0. if ww < 1e-18 else min(1., max(0., ((moved[0] - p0[0]) * w[0] + (moved[1] - p0[1]) * w[1]) / ww))
        return self.starts[k] + f * math.sqrt(ww)

    def point(self, y):
        if self.ring:
            return self.ring[0].point((y + self.ring[3]) % self.length if self.length else 0.)
        k = min(max(0, bisect.bisect_right(self.starts, y) - 1), len(self.points) - 2)
        if k < 0:
            return self.points[0], 0
        p0, p1 = self.points[k], self.points[k + 1]
        span = self.starts[k + 1] - self.starts[k]
        f = 0. if span < 1e-12 else min(1., max(0., (y - self.starts[k]) / span))
        return (p0[0] + (p1[0] - p0[0]) * f, p0[1] + (p1[1] - p0[1]) * f), k

    def back(self, y):
        """The point of the edge in front of the point ``y`` mm along the seam (moved back out)."""
        if self.ring:
            return self.ring[0].back((y + self.ring[3]) % self.length if self.length else 0.)
        if self.samples:
            cuts = self.samples[2]
            p, k = self.point(y)
            if k + 1 >= len(cuts):
                return cuts[-1]
            span = self.starts[k + 1] - self.starts[k]
            f = 0. if span < 1e-12 else min(1., max(0., (y - self.starts[k]) / span))
            return (cuts[k][0] + (cuts[k + 1][0] - cuts[k][0]) * f, cuts[k][1] + (cuts[k + 1][1] - cuts[k][1]) * f)
        if not self.order:
            return None
        p, k = self.point(y)
        n = self.segs[self.order[k]][2]
        return (p[0] - n[0], p[1] - n[1])


_SEAMS = {}


def seam_line(pts, d, inside):
    """Seam(pts, d, inside), kept for the same points (the bag's list and the proposals ask again for the same edges)."""
    key = (tuple((float(x), float(y)) for x, y in pts), float(d), inside)
    line = _SEAMS.get(key)
    if line is None:
        if len(_SEAMS) > 500:   # (each holds its edge: a few kB)
            _SEAMS.clear()
        line = _SEAMS[key] = Seam(pts, d, inside)
    return line


def measured(app, chosen, d, shut=(0., 0.)):
    """0.19.26: the edge ``chosen`` (piece, sides) at its seam, ``d`` mm inside the piece: (its points (at the cut), its
    start along the contour, its length at the seam, the contour's length, its crans at the seam (mm from its start)).
    0.19.29 ``shut``: (mm, mm) its seam loses at its start and at its end (closings: a partie haute closed into a tube)."""
    from craft_tools import interior_side
    pts, start, length, total = portion(app, chosen)
    cut = crans(app, chosen[0], start, length, total)
    if d > 0:
        try:
            line = seam_line(pts, d, interior_side(app.items[chosen[0]]))
            length, cut = line.length, [line.at(x) for x in cut]
        except ValueError:
            pass
    if shut[0] or shut[1]:
        length = max(length - shut[0] - shut[1], 0.)
        cut = [min(max(x - shut[0], 0.), length) for x in cut]
    return pts, start, length, total, cut


_LOCAL = __import__('threading').local()
MEMO_MOST = 2000   # measures kept for one drawing (pairs, checks, hints)


def _memo(app):
    """0.19.36 (« c'est le but d'avoir un logiciel fluide »; lenteurs.txt of 17/11: « souris (motion) 73 ms » in the Contrôle
    d'assemblage): the measures of this drawing (pairs at their seam: reach, folds, lengths, crans), kept until it changes
    (an object replaced, one more or less, a refresh, the pairs kept, the archives): each move of the mouse with a check
    shown measured both edges again with their folds, and the hint every piece of edge 2. None without a refresh to tell
    (a stand-in of the application: every call measures)."""
    version = app.__dict__.get('_doc_version')
    if version is None:
        return None
    import marshal
    items = app.items
    infos = app.__dict__.get('infos') or {}
    try:
        pairs = marshal.dumps(infos.get(KEY), 2)
    except ValueError:
        pairs = repr(infos.get(KEY))
    key = (id(app), id(items), len(items), version, tuple(map(id, items)), pairs, repr(infos.get('montage')),
           id(app.__dict__.get('archives')))
    hit = getattr(_LOCAL, 'memo', None)
    if hit is not None and hit[0] == key:
        if len(hit[1]) > MEMO_MOST:   # (review: hovering every side for many first edges kept about 10 MB)
            hit[1].clear()
        return hit[1]
    values = {}
    _LOCAL.memo = (key, values)
    return values


def pair_measure(app, a, b, seam, double=False):
    """0.19.36: (reach, shut, folded, measured edge a, measured edge b) of the edges ``a`` and ``b`` ((piece, sides)) sewn
    at ``seam`` mm, as result() measures them (each where it is sewn, up to its folds and closings); kept for the same
    drawing (_memo): the results are shared, never changed by their callers."""
    memo = _memo(app)
    key = ('pair', a[0], tuple(a[1]), b[0], tuple(b[1]), float(seam), bool(double))
    if memo is not None and key in memo:
        return memo[key]
    ks = (a[0], b[0])
    reach = reaches(app, seam, ks, [(a[0], portion(app, a)[0]), (b[0], portion(app, b)[0])], double)
    shut = (closings(app, *a), closings(app, *b))
    folded = pair_folds(app, [a, b], reach, double)
    shut = with_folds(shut, folded)
    out = (tuple(reach), shut, tuple(folded), measured(app, a, reach[0], shut[0]), measured(app, b, reach[1], shut[1]))
    if memo is not None:
        memo[key] = out
    return out


def closings(app, k, ids, rows=None):
    """0.19.29 (fond rapporté: « partie haute en une seule pièce principalement », its two ends sewn together; bande
    allemande type seau): (mm, mm) the seam of the edge ``ids`` of piece ``k`` loses at its start and at its end when the
    two sides just beside it are sewn together in a pair of the bag (``rows``, else the bag's): the seam of the fond
    runs from one of their seams to the other (each at its distance from those ends)."""
    try:
        n = len(sides(app.items[k])[0])
        order = sorted(set(ids))
        if len(order) >= n - 1:
            return (0., 0.)
        if len(order) > 1 and order[0] == 0 and order[-1] == n - 1:   # (round the closing corner)
            cut = next(i for i in range(1, len(order)) if order[i] != order[i - 1] + 1)
            order = order[cut:] + order[:cut]
        before, after = (order[0] - 1) % n, (order[-1] + 1) % n
        if before == after:
            return (0., 0.)
        key = piece_key(app, k) if app.items[k].get('piece_id') or app.items[k].get('owner_id') else None
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError, StopIteration):
        return (0., 0.)
    if key is None:
        return (0., 0.)
    for pair in (kept_pairs(app) if rows is None else [r for r in rows if 'a' in r]):
        a, b = pair['a'], pair['b']
        if a['piece'] == b['piece'] == key and a.get('count', n) == n and {before, after} <= set(a['sides']) | set(b['sides']) and (
                before in a['sides'] and after in b['sides'] or after in a['sides'] and before in b['sides']):
            d = seam_of(app, pair.get('seam'), (k, k))
            return (d, d)
    return (0., 0.)


def thickness(app, k):
    """The refente of piece ``k`` in mm (« refente 10/10 » = 1 mm), None when it has none."""
    info = (host(app, k).get('piece_info') or {}).get('material') or {}
    try:
        v = float(str(info.get('refente', '')).replace(',', '.'))
    except ValueError:
        return None
    return v / 10 if v > 0 else None


def _along(pts, step=2.):
    """Points every ``step`` mm along a line."""
    out = []
    for a, b in zip(pts, pts[1:]):
        n = max(1, int(math.dist(a, b) / step))
        out += [(a[0] + (b[0] - a[0]) * j / n, a[1] + (b[1] - a[1]) * j / n) for j in range(n)]
    return out + pts[-1:]


def parage(app, k, pts, zone=False):
    """The parage zone along most of the edge ``pts`` of piece ``k`` (its préparation data; 0.19.29 ``zone``: (data, the
    zone)), or None."""
    from geometry import geometry_key, path
    owners = {app.items[k].get('piece_id'), app.items[k].get('owner_id'), host(app, k).get('piece_id')} - {None}
    samples = _along(pts)
    best = None
    for s in app.items:
        data = s.get('preparation')
        if not data or data.get('kind') != 'parage' or s.get('owner_id') not in owners:
            continue
        try:
            ring = path(s)[0]
        except (ValueError, KeyError, TypeError):
            continue
        near = _near_count(samples, ring, key=geometry_key(s))
        if near >= len(samples) / 2 and (best is None or near > best[0]):
            best = (near, data, s)
    if best is None:
        return None
    return (best[1], best[2]) if zone else best[1]


_RINGS = {}


def _near_count(samples, ring, reach=.3, cell=2., key=None):
    """0.19.27: how many of ``samples`` lie inside ``ring`` or nearer than ``reach`` to it, counted as before
    (preparations.inside, then _gap) but each point measured only against the sides of the ring near it: a grid of
    squares of ``cell`` mm along each side, and for inside the sides across its band of ``cell`` mm, kept by ``key`` (the
    zone's geometry) (the fiche Montage measured each edge's points every 2 mm against every side of every parage: 70 %
    of its time)."""
    if len(ring) < 2:
        from preparations import inside
        return sum(1 for q in samples if inside(ring, q) or _gap(q, ring + ring[:1]) < reach)
    floor = math.floor
    kept = _RINGS.get((key, reach, cell)) if key is not None else None
    if kept is None:
        kept = _ring_grid(ring, reach, cell)
        if key is not None:
            if len(_RINGS) > 500:
                _RINGS.clear()
            _RINGS[(key, reach, cell)] = kept
    run, (x0, y0, x1, y1), grid, bands, cell = kept
    n = 0
    for q in samples:
        x, y = q
        if not (x0 <= x <= x1 and y0 <= y <= y1):   # (outside its box: neither inside nor near)
            continue
        hit = False
        for k in bands.get(floor(y / cell), ()):   # (preparations.inside: the sides across y, the same sum)
            a, b = run[k], run[k + 1]
            if (a[1] > y) != (b[1] > y) and x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]:
                hit = not hit
        if hit:
            n += 1
            continue
        for k in grid.get((floor(x / cell), floor(y / cell)), ()):
            a, b = run[k], run[k + 1]
            dx, dy = b[0] - a[0], b[1] - a[1]
            L = dx * dx + dy * dy
            t = 0 if L == 0 else max(0, min(1, ((q[0] - a[0]) * dx + (q[1] - a[1]) * dy) / L))
            if math.dist(q, (a[0] + t * dx, a[1] + t * dy)) < reach:   # (as _gap measures it)
                n += 1
                break
    return n


def _ring_grid(ring, reach, cell):
    """(the ring closed, its box widened by ``reach``, its sides by the squares of ``cell`` mm they come within reach of,
    by the bands of ``cell`` mm across their height, the size of the squares). Each box a hair wider than ``reach``
    (review: a point just outside a side's box by rounding was near it for _gap): it only picks the sides to measure. A
    huge ring: larger squares (review: a ring a kilometre long filled the memory)."""
    floor = math.floor
    run = ring + ring[:1]
    xs, ys = [p[0] for p in ring], [p[1] for p in ring]
    reach += 1e-13 * (1. + max(max(map(abs, xs)), max(map(abs, ys))))   # (a few hundred times the rounding)
    cell = max(cell, sum(math.dist(a, b) for a, b in zip(run, run[1:])) / 20000.)
    grid, bands = {}, {}
    for k, (a, b) in enumerate(zip(run, run[1:])):
        for band in range(floor(min(a[1], b[1]) / cell), floor(max(a[1], b[1]) / cell) + 1):
            bands.setdefault(band, []).append(k)
        L = math.dist(a, b)
        if L <= 2 * cell:   # (a short side: its box)
            boxes = [(min(a[0], b[0]) - reach, min(a[1], b[1]) - reach, max(a[0], b[0]) + reach, max(a[1], b[1]) + reach)]
        else:   # (a long one: boxes round its points every cell, reach + cell / 2 wide: a slanting side never fills its box)
            r, ux, uy = reach + cell / 2, (b[0] - a[0]) / L, (b[1] - a[1]) / L
            boxes = [(a[0] + ux * t - r, a[1] + uy * t - r, a[0] + ux * t + r, a[1] + uy * t + r)
                     for t in (min(n * cell, L) for n in range(int(L // cell) + 2))]
        for bx0, by0, bx1, by1 in boxes:
            for gx in range(floor(bx0 / cell), floor(bx1 / cell) + 1):
                for gy in range(floor(by0 / cell), floor(by1 / cell) + 1):
                    found = grid.setdefault((gx, gy), [])
                    if not found or found[-1] != k:
                        found.append(k)
    return run, (min(xs) - reach, min(ys) - reach, max(xs) + reach, max(ys) + reach), grid, bands, cell


def edge_thickness(app, k, pts, double=False):
    """(thickness at the seam in mm, what it is made of, the refente known, a rembord found) of the edge ``pts``."""
    leather = thickness(app, k)
    e = leather if leather is not None else 1.
    data = parage(app, k, pts)
    if not data:
        return e, f'cuir {_mm(e, 2)}', leather is not None, False
    kind = str(data.get('type') or '').upper()
    try:
        t = float(data.get('thickness')) / 10
    except (TypeError, ValueError):
        t = None
    if not t or t <= 0:
        return e, f'cuir {_mm(e, 2)} (parage {kind.lower() or "sans épaisseur"} : épaisseur non donnée)', leather is not None, 'REMBORD' in kind
    if 'BISEAU' in kind:
        return (e + t) / 2, f'parage biseau à {_mm(t, 2)} : milieu du biseau {_mm((e + t) / 2, 2)}', leather is not None, False
    if 'REMBORD' in kind:
        if double:
            return 2 * t, f'rembord paré à {_mm(t, 2)}, plié : 2 × {_mm(t, 2)}', leather is not None, True
        return e + t, f'rembord paré à {_mm(t, 2)}, plié sur le cuir : {_mm(e, 2)} + {_mm(t, 2)}', leather is not None, True
    return t, f'parage {kind.lower()} à {_mm(t, 2)}', leather is not None, False


def _name(s):
    info = (s.get('piece_info') or {}).get('part_name') or {}
    values = info.get('values') or []
    return ' '.join(str(v) for v in values if v).strip().upper() or str(s.get('name') or '').strip().upper()


LAYER_WORDS = ('RENFORT', 'RFT', 'DOUBLURE', 'DBL', 'NON TISSE', 'NON TISSÉ')


def piece_names(app, every=False):
    """0.19.27: [(index, name)] of the pieces (_pieces), read once for all the pieces whose layers are looked for."""
    return [(j, _name(host(app, j))) for j in _pieces(app, every)]


def layers(app, k, every=False, names=None):
    """The renforts and doublures of piece ``k`` found by their names (« RENFORT FACE », « DBL FACE » for FACE):
    [(index, name, thickness in mm or None)]. 0.19.25 ``every``: also among the pieces of a layer hidden (the
    proposals look at every piece). 0.19.27 ``names``: piece_names(app, every), when several pieces are looked at (the
    names were read again for each piece: Paires probables, Étape…)."""
    import re
    name = _name(host(app, k))
    if not name:
        return []
    word = re.compile(r'(^|\W)' + re.escape(name) + r'(\W|$)')
    out = []
    for j, other in (piece_names(app, every) if names is None else names):
        if j == k or other == name or not any(w in other for w in LAYER_WORDS) or not word.search(other):
            continue
        if any(other == o for _, o, _ in out):
            continue
        out.append((j, other, thickness(app, j)))
    return out


def thread(length, points, thick):
    """(points, thread in mm) of a lock stitch ``length`` mm long: each of the two threads lies along each point
    (10 / points per cm) and crosses the thickness once at each point."""
    n = max(1, round(length * points / 10))
    step = 10 / points
    return n, n * 2 * (step + thick)


def _drop_stale(app):
    """0.19.24 (review): the edges taken whose piece changed meanwhile (its sides fewer, the drawing changed under the
    tool: an IndexError at each move of the mouse) are let go: the check starts again."""
    st = app.__dict__.get('assembly_state')
    if not st:
        return False
    for key in ('a', 'b'):
        chosen = st.get(key)
        if not chosen:
            continue
        k, ids = chosen
        try:
            ok = bool(ids) and k < len(app.items) and max(ids) < len(sides(app.items[k])[0])
        except (IndexError, KeyError, TypeError, ValueError, ZeroDivisionError):
            ok = False
        if not ok:
            st.update(a=None, b=None, kept=None, added=False, more=[])
            return True
    if st.get('more'):   # 0.19.36: edge 2's next pieces whose piece changed: let go
        kept = []
        for k, ids in st['more']:
            try:
                if ids and k < len(app.items) and max(ids) < len(sides(app.items[k])[0]):
                    kept.append((k, ids))
            except (IndexError, KeyError, TypeError, ValueError, ZeroDivisionError):
                pass
        if len(kept) != len(st['more']):
            st['more'] = kept
            return True
    return False


def redrawn(app):
    """0.19.30: the check's edges drawn again after a drawing of the plan (a resize of the window, a settle of the view:
    they went with it until the mouse moved over the plan); an edge whose piece changed is never let go here (Annuler
    finds it again: resume)."""
    st = app.__dict__.get('assembly_state')
    if not st or not (st.get('a') or st.get('b')):
        return False
    for key in ('a', 'b'):
        chosen = st.get(key)
        if not chosen:
            continue
        try:
            k, ids = chosen
            if not ids or k >= len(app.items) or max(ids) >= len(sides(app.items[k])[0]):
                return False
        except (IndexError, KeyError, TypeError, ValueError, ZeroDivisionError):
            return False
    draw(app)
    return True


def result(app):
    """The numbers of the check (None while the second edge is not chosen); 0.19.36: kept for the same check and drawing
    (the prompt and the window asked for them at each click, the hint at each move of the mouse): a copy."""
    _drop_stale(app)
    st = app.__dict__.get('assembly_state') or {}
    if not st.get('a') or not st.get('b'):
        return None
    memo = _memo(app)
    try:
        key = ('result', (st['a'][0], tuple(st['a'][1])), (st['b'][0], tuple(st['b'][1])),
               tuple((k, tuple(ids)) for k, ids in st.get('more') or ()), st.get('seam'), bool(st.get('retourne')),
               bool(st.get('double')), st.get('thickness'), st.get('points'), tuple(sorted(st.get('layers') or ())), embu_of(st))
        hash(key)
    except TypeError:
        key = memo = None
    if memo is not None and key in memo:
        return dict(memo[key])
    r = _chain_result(app, st) if st.get('more') else _result(app, st)
    if memo is not None:
        memo[key] = r
    return dict(r)


def _result(app, st):
    ks = (st['a'][0], st['b'][0])
    seam, kind = seam_info(app, st.get('seam'), ks, st.get('retourne'), _st_sides(st))   # 0.19.26: measured at the seam (0.19.28: tissu 5 mm)
    double = bool(st.get('double'))
    # 0.19.29: each edge where it is measured; a tube's bottom from one end's seam to the other; 0.19.35: up to a rembord's
    # fold; 0.19.36: kept for the same drawing (pair_measure)
    reach, shut, folded, (pa, sa, la, ta, ca), (pb, sb, lb, tb, cb) = pair_measure(app, st['a'], st['b'], seam, double)
    embu = embu_of(st)
    front, reversed_ = facing(ca, la, cb, lb, embu)
    ta_, da, ka, ra = edge_thickness(app, st['a'][0], pa, double)
    tb_, db, kb, rb = edge_thickness(app, st['b'][0], pb, double)
    names = piece_names(app)   # 0.19.27: read once for both edges
    first = layers(app, st['a'][0], names=names)
    found = first + [x for x in layers(app, st['b'][0], names=names) if x[0] not in {y[0] for y in first}]
    ticked = [x for x in found if x[0] in (st.get('layers') or set())]
    extra = sum(x[2] if x[2] is not None else 1. for x in ticked)
    thick = st.get('thickness') if st.get('thickness') is not None else ta_ + tb_ + extra
    points = points_of(st.get('points'))   # 0.19.29: 3 per cm, or typed (never the Piqûre's pitch)
    n, fil = thread(max(la, lb), points, thick)
    return dict(la=la, lb=lb, diff=la - lb, ca=len(ca), cb=len(cb), front=front, reversed=reversed_, thickness=thick,
                known=(ka, kb), points=points, n=n, thread=fil, a=pa, b=pb, made=(da, db), rembord=ra or rb, layers=found,
                seam=seam, crans_a=ca, crans_b=cb, seam_kind=kind, reach=reach, shut=shut, folds=folded, embu=embu)


# --- 0.19.36 « montage fond mexicain » (« la face et le dos ont 3 pièces qui viennent se coudre sur le bas (1 petite patte
# des soufflets, le fond et la patte de l'autre soufflet) »; « pq avoir des crans ? la distance fait que c parfait »): edge 2
# made of several pieces one after the other (Ctrl + clic: the next piece), their lengths added, the junctions by distance

def _chain_cached(app, st):
    """chain_numbers of the check ``st`` (edge 2 on several pieces), kept for the same edges and drawing (_memo: review, the
    kept pairs and the model's piqûre too); None when it fails"""
    memo = _memo(app)
    key = ('chain', st.get('a') and (st['a'][0], tuple(st['a'][1])), tuple((k, tuple(ids)) for k, ids in parts_of(st)),
           st.get('seam'), bool(st.get('double')), bool(st.get('retourne')))
    if memo is not None and key in memo:
        return memo[key]
    try:
        value = chain_numbers(app, st['a'], parts_of(st), st.get('seam'), st.get('retourne'), bool(st.get('double')))
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        value = None
    if memo is not None:
        memo[key] = value
    return value


def parts_of(st):
    """the pieces of edge 2 of a check, one after the other: [(k, ids)…] (st['b'], then st['more'])"""
    return ([st['b']] if st.get('b') else []) + [tuple(p) for p in st.get('more') or ()]


def chain_numbers(app, a, parts, value=None, retourne=False, double=False):
    """edge 1 ``a`` (k, ids) sewn to edge 2 made of ``parts`` [(k, ids)…] one after the other, each measured where it is
    sewn to edge 1 (as a pair of two: reaches, closings, folds): dict(la, lb, ca, cb (edge 2's crans along it as one),
    pa, pbs (each part's points), lbs (each part's length), junctions (mm along edge 2), seam, kind, reach, shut)"""
    k0 = parts[0][0]
    seam, kind = seam_info(app, value, (a[0], k0), retourne, (list(a[1]), list(parts[0][1])))
    la = lb = None
    cb, pbs, lbs, junctions, reach_b, shut_b = [], [], [], [], [], []
    for n, part in enumerate(parts):
        reach, shut, _, mine, (pb, _, length, _, crans_) = pair_measure(app, a, part, seam, double)   # (kept: the hint adds a piece)
        if la is None:
            pa, _, la, _, ca = mine
            reach_a, shut_a = reach[0], shut[0]
            lb = 0.
        cb += [lb + x for x in crans_]
        pbs.append(pb)
        lbs.append(length)
        reach_b.append(reach[1])
        shut_b.append(shut[1])
        lb += length
        if n < len(parts) - 1:
            junctions.append(lb)
    return dict(la=la, lb=lb, ca=ca, cb=cb, pa=pa, pbs=pbs, lbs=lbs, junctions=junctions, seam=seam, kind=kind,
                reach=(reach_a, reach_b[0]), shut=(shut_a, shut_b[0]), reaches=reach_b, shuts=shut_b)


def junction_words(r):
    """the junctions of edge 2's pieces, in words ('' for one piece)"""
    j = r.get('junctions') or ()
    if not j:
        return ''
    return 'jonctions à ' + ', '.join(_mm(x) for x in j) + ' mm du début du bord 1'


def within(r):
    """0.19.36: the écart of a check is the one it is meant to have (its embu, 0) to 0,5 mm"""
    return abs(abs(r['diff']) - r.get('embu', 0.)) <= .5


def _chain_result(app, st):
    """result for edge 2 on several pieces (fond mexicain): the same numbers, edge 2's pieces added one after the other"""
    double = bool(st.get('double'))
    parts = parts_of(st)
    c = chain_numbers(app, st['a'], parts, st.get('seam'), st.get('retourne'), double)
    la, lb, ca, cb = c['la'], c['lb'], c['ca'], c['cb']
    embu = embu_of(st)
    front, reversed_ = facing(ca, la, cb, lb, embu)
    ta_, da, ka, ra = edge_thickness(app, st['a'][0], c['pa'], double)
    tb_, db, kb, rb = edge_thickness(app, parts[0][0], c['pbs'][0], double)
    names = piece_names(app)
    first = layers(app, st['a'][0], names=names)
    found = first + [x for x in layers(app, parts[0][0], names=names) if x[0] not in {y[0] for y in first}]
    ticked = [x for x in found if x[0] in (st.get('layers') or set())]
    extra = sum(x[2] if x[2] is not None else 1. for x in ticked)
    thick = st.get('thickness') if st.get('thickness') is not None else ta_ + tb_ + extra
    points = points_of(st.get('points'))
    n, fil = thread(max(la, lb), points, thick)
    pb = [q for part in c['pbs'] for q in part]
    return dict(la=la, lb=lb, diff=la - lb, ca=len(ca), cb=len(cb), front=front, reversed=reversed_, thickness=thick,
                known=(ka, kb), points=points, n=n, thread=fil, a=c['pa'], b=pb, made=(da, db), rembord=ra or rb, layers=found,
                seam=c['seam'], crans_a=ca, crans_b=cb, seam_kind=c['kind'], reach=c['reach'], shut=c['shut'],
                folds=((0., 0.), (0., 0.)), embu=embu, junctions=c['junctions'], parts=c['pbs'], lbs=c['lbs'])


def folded_words(lost):
    """0.19.36 (« plié 7 mm au bout » said in the check): what an edge loses to the folds of its rembords, in words; ''"""
    a, b = (round(v, 1) for v in lost)
    if a < .05 and b < .05:
        return ''
    if abs(a - b) < .05:
        return f'plié {_mm(a)} mm aux deux bouts'
    if a < .05 or b < .05:
        return f'plié {_mm(max(a, b))} mm au bout'
    return f'plié {_mm(a)} mm au début, {_mm(b)} mm à la fin'


def _mm(v, digits=1):
    return f'{round(v, digits):g}'.replace('.', ',')


def summary(r):
    embu = embu_words(r.get('embu', 0.))
    return (f'{_mm(r["la"])} / {_mm(r["lb"])} mm {seam_words(r["seam"], r.get("seam_kind"))} (écart {_mm(abs(r["diff"]))}'
            f'{", " + embu if embu else ""}) · crans {r["front"]} en face '
            f'sur {r["ca"]} / {r["cb"]} · {r["n"]} points · fil ≈ {_mm(r["thread"] / 10, 0)} cm')


# --- the tool -----------------------------------------------------------------------------------------------------

def start(app):
    if hasattr(app, 'plan_active') and not app.plan_active() and hasattr(app, 'select_section'):
        app.select_section('plan')   # 0.19.25 (review): the check is made on the plan, never over a fiche shown
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    app.tool.set('assembly')
    app.last_command = ('tool', 'assembly')
    app.assembly_state = dict(a=None, b=None, thickness=None, points=None, kept=None, added=False)
    app.highlight_tools()
    prompt(app)
    app.refresh()


def resume(app):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return start(app)
    app.tool.set('assembly')   # 0.19.22: (Annuler / Rétablir left the Sélection under this prompt)
    app.last_command = ('tool', 'assembly')
    app.highlight_tools()
    st.pop('placed', None)
    found = _found_again(app, st)   # 0.19.26: the same edges, found by their pieces (« Crans en face » then Annuler)
    if not found:
        st.update(a=None, b=None, kept=None, added=False)
    prompt(app)
    draw(app)
    if found:
        window(app)   # (second review: Annuler closed it; refilled when it is still there)


def _frozen(chosen):
    return (chosen[0], tuple(chosen[1]))


def _hold(app, st, a, b, more=None):
    """0.19.26: the two edges of the check as they are kept (their pieces' keys), with the places they were taken at
    (0.19.36: edge 2's next pieces too)."""
    st['edges'] = dict(at=(_frozen(st['a']), _frozen(st['b'])), a=dict(a), b=dict(b), more=[dict(x) for x in more or ()])


def _found_again(app, st):
    """0.19.26: after Annuler / Rétablir, the check's two edges found again by their pieces' keys, their sides the same
    in number (else the check starts again, as before)."""
    edges = st.get('edges') or {}
    if not st.get('a') or not st.get('b') or edges.get('at') != (_frozen(st['a']), _frozen(st['b'])):
        return False
    pieces = _pieces(app, every=True)
    found = [piece_index(app, edges[x]['piece'], pieces) for x in ('a', 'b')]
    try:
        if None in found or any(len(sides(app.items[k])[0]) != edges[x]['count'] or max(edges[x]['sides']) >= edges[x]['count']
                                for k, x in zip(found, 'ab')):
            return False
    except (IndexError, KeyError, TypeError, ValueError, ZeroDivisionError):
        return False
    st.update(a=(found[0], e_sides(edges['a'])), b=(found[1], e_sides(edges['b'])))
    more = []
    for x in edges.get('more') or ():   # 0.19.36: edge 2's next pieces, each found again (else let go)
        k = piece_index(app, x['piece'], pieces)
        try:
            if k is not None and len(sides(app.items[k])[0]) == x['count'] and max(x['sides']) < x['count']:
                more.append((k, e_sides(x)))
        except (IndexError, KeyError, TypeError, ValueError, ZeroDivisionError):
            pass
    st['more'] = more
    edges['at'] = (_frozen(st['a']), _frozen(st['b']))
    return True


def prompt(app):
    st = app.assembly_state
    _drop_stale(app)
    if not st.get('a'):
        app.status.set('Contrôle d’assemblage : cliquer le bord de la 1re pièce (Maj + clic : ajouter le côté suivant).')
    elif not st.get('b'):
        app.status.set('Cliquer le bord cousu dessus, sur l’autre pièce (Maj + clic : ajouter un côté ; Entrée : même pièce).')
    else:
        r = result(app)
        app.status.set('Assemblage : ' + summary(r) + (f' · {junction_words(r)}' if r.get('junctions') else '')
                       + ' · Ctrl + clic : pièce suivante du bord 2 · Entrée : nouveau contrôle.')


def _reach(app):
    return 8 / max(app.scale, 1e-9)


def hover(app, e):
    under = side_at(app, app.raw(e), _reach(app))
    draw(app, under)
    hint(app, e, under)


# --- 0.19.36 « LE AJOUTER UN COTE... peut être mieux diriger savoir si c bon ou pas »: what a click (Maj + clic) on the side
# under the mouse would give, beside the mouse: the edge's length, and with two edges their écart (green: good) --------

GOOD, WRONG = '#4fbf6a', '#ef6a5e'


def _lengths(app, st):
    """(la, lb, the check's numbers as result measures them) for edges ``st`` (a, b: piece, sides; seam, double…): lb None
    without edge 2 (la then at the cut)"""
    if not st.get('b'):
        return portion(app, st['a'])[2], None, None
    if st.get('more'):   # edge 2 on several pieces
        c = chain_numbers(app, st['a'], parts_of(st), st.get('seam'), st.get('retourne'), bool(st.get('double')))
        return c['la'], c['lb'], dict(diff=c['la'] - c['lb'], embu=embu_of(st))
    ks = (st['a'][0], st['b'][0])
    seam, kind = seam_info(app, st.get('seam'), ks, st.get('retourne'), _st_sides(st))
    _, _, _, ma, mb = pair_measure(app, st['a'], st['b'], seam, bool(st.get('double')))
    la, lb = ma[2], mb[2]
    return la, lb, dict(diff=la - lb, embu=embu_of(st))


def _as_kept(app, st):
    """0.19.40 (review): the check ``st`` (its two edges) as the click makes it (remember): its first two edges those of a
    fond mexicain kept, that chain; its edges a pair kept, that pair's seam, points, rembord, piqué retourné and embu
    (before, the words beside the mouse said « écart 8 ✗ » on RIDER's FACE / CAVOUR, kept with an embu of 8 mm, the
    click « bon »). Nothing is given an id (peek_edge)."""
    if not st.get('a') or not st.get('b'):
        return st
    try:
        pair = dict(a=peek_edge(app, st['a']), b=peek_edge(app, st['b']))
        pairs = entries(app)
        out = st
        if st.get('more'):
            pair['more'] = [peek_edge(app, part) for part in st['more']]
        else:
            chained = _chain_of(app, pairs, pair)
            if chained and chained[1] != st.get('kept'):
                out = dict(st, more=chained[0])
                pair['more'] = [peek_edge(app, part) for part in chained[0]]
        new = _ident(pair)
        if new != st.get('kept'):
            for p in pairs:
                if 'a' in p and _ident(p) == new:
                    return dict(out, seam=p.get('seam'), points=p.get('points'), double=bool(p.get('double')),
                                retourne=bool(p.get('retourne')), embu=embu_of(p))
        return out
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        return st


def again(app, st, k):
    """0.19.39: piece ``k`` (edge 2's first piece) cut more times than it is in edge 2 already, after another piece (a
    soufflet cut twice: its second copy, after the fond)"""
    return bool(st.get('more')) and quantity(app, k) > sum(1 for kk, _ in [st['b']] + [tuple(p) for p in st['more']] if kk == k)


def chain_part(app, st, k, i):
    """0.19.40 (review): the next piece of edge 2 (``st['more'][n]``) a Maj + clic on side ``i`` of piece ``k`` is for: n,
    or None (none of them). A soufflet cut twice is twice in edge 2 (its first piece, then after the fond): the copy whose
    edge holds the side, else the one it follows (the first copy first; before, always the second)."""
    parts = [(n, tuple(p)) for n, p in enumerate(st.get('more') or ()) if p[0] == k]
    if not parts:
        return None
    first = [(None, tuple(st['b']))] if st.get('b') and st['b'][0] == k else []
    for n, part in first + parts:
        if i in part[1]:
            return n
    for n, part in first + parts:
        if adjacent(app, part, i):
            return n
    return parts[-1][0]


def would(app, under):
    """(what a click on side ``under`` does, the check it would give: st) or None: 'add' / 'remove' a side of an edge
    (Maj + clic), 'second' (edge 2), 'first' (a new edge 1)"""
    st = app.__dict__.get('assembly_state') or {}
    if under is None:
        return None
    k, i = under
    at = chain_part(app, st, k, i)
    for n, (kk, ids) in enumerate(st.get('more') or ()):   # 0.19.36: a next piece of edge 2: its sides (Maj + clic)
        if n == at:
            parts = [tuple(p) for p in st['more']]
            if i in ids:
                rest = [j for j in ids if j != i]
                if rest and in_one_run(app, kk, rest):
                    parts[n] = (kk, rest)
                    return 'remove', dict(st, more=parts), 'b'
                return 'chain_out', dict(st, more=[p for p in parts if p[0] != k]), 'b'
            if adjacent(app, (kk, ids), i):
                parts[n] = (kk, list(ids) + [i])
                return 'add', dict(st, more=parts), 'b'
            return 'chain_out', dict(st, more=[p for p in parts if p[0] != k]), 'b'
    if st.get('a') and not st.get('b') and st.get('switched') and k == st['a'][0]:
        return 'second', dict(st, b=(k, [i])), 'b'   # (review: after Entrée, a click on the same piece takes edge 2, as click())
    edges = [key for key in ('b', 'a') if st.get(key) and st[key][0] == k]
    for key in edges:
        k0, ids = st[key]
        if i in ids:
            rest = [j for j in ids if j != i]
            if rest and in_one_run(app, k0, rest):
                return 'remove', dict(st, **{key: (k0, rest)}), key
        elif adjacent(app, st[key], i) and not any(st.get(o) and st[o][0] == k and i in st[o][1] for o in ('a', 'b') if o != key):
            return 'add', dict(st, **{key: (k0, list(ids) + [i])}), key   # (review: never a side of the other edge)
    if st.get('a') and not st.get('b') and k != st['a'][0]:
        return 'second', dict(st, b=(k, [i])), 'b'
    if st.get('a') and st.get('b') and k != st['a'][0] and (k != st['b'][0] or again(app, st, k)):   # 0.19.36: Ctrl + clic, the
        return 'chain', dict(st, more=[tuple(p) for p in st.get('more') or ()] + [(k, [i])]), 'b'       # next piece of edge 2
    return 'first', dict(a=(k, [i]), b=None), 'a'


def hint_text(app, under):
    """(the words beside the mouse for side ``under``, their colour) or None; kept for the same side, edges and drawing
    (_memo: review, the kept pairs and the model's piqûre too)"""
    st = app.__dict__.get('assembly_state') or {}
    memo = _memo(app)
    key = ('hint', under, st.get('a') and (st['a'][0], tuple(st['a'][1])), st.get('b') and (st['b'][0], tuple(st['b'][1])),
           st.get('seam'), tuple((kk, tuple(ids)) for kk, ids in st.get('more') or ()), bool(st.get('double')), embu_of(st),
           bool(st.get('retourne')), bool(st.get('switched')), st.get('kept'))
    if memo is not None and key in memo:
        return memo[key]
    out = None
    try:
        what = would(app, under)
        if what is not None:
            how, st2, edge = what
            st2 = _as_kept(app, st2)   # 0.19.40: what the click gives (a pair kept: its embu…)
            name = 'bord 1' if edge == 'a' else 'bord 2'
            la, lb, r = _lengths(app, st2)
            if lb is None:
                verb = {'add': 'Maj + clic : ajouter', 'remove': 'Maj + clic : retirer'}.get(how, 'Clic')   # (0.19.40: « Clic → », as below)
                out = (f'{verb} → {name} {_mm(la)} mm (à la coupe)', None)
            else:
                verb = {'add': 'Maj + clic : ajouter ce côté', 'remove': 'Maj + clic : retirer ce côté',
                        'chain': 'Ctrl + clic : pièce suivante du bord 2', 'chain_out': 'Ctrl + clic : retirer cette pièce'}.get(how, 'Clic')
                good = within(r)
                embu = f', {embu_words(r["embu"])}' if r['embu'] else ''
                out = (f'{verb} → {_mm(la)} / {_mm(lb)} mm, écart {_mm(abs(r["diff"]))}{embu} ' + ('✓' if good else '✗'),
                       GOOD if good else WRONG)
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError, AttributeError):
        out = None
    if memo is not None:
        memo[key] = out
    return out


def hint(app, e, under):
    """the words of hint_text beside the mouse (in the check's preview: gone with it)"""
    c = app.canvas
    c.delete('assembly_hint')
    found = hint_text(app, under) if under is not None else None
    if not found:
        return
    text, colour = found
    x, y = e.x + 16, e.y + 16
    item = c.create_text(x, y, text=text, anchor='nw', fill=colour or app.p.get('ink', '#f1f3f5'), font=('Segoe UI', 9, 'bold'),
                         tags=('assembly_preview', 'assembly_hint'))
    box = c.bbox(item)
    if box:   # (by the right or the bottom of the plan: on the other side of the mouse, never cut)
        dx = -(box[2] - box[0]) - 32 if box[2] > c.winfo_width() - 6 else 0
        dy = -(box[3] - box[1]) - 32 if box[3] > c.winfo_height() - 6 else 0
        if dx or dy:
            c.move(item, dx, dy)
            box = c.bbox(item)
    if box:
        back = c.create_rectangle(box[0] - 5, box[1] - 3, box[2] + 5, box[3] + 3, fill=app.p.get('panel', '#202429'),
                                  outline=colour or app.p.get('accent', '#61c9ee'), tags=('assembly_preview', 'assembly_hint'))
        c.tag_lower(back, item)


def drawn_edges(app, st):
    """{'a' / 'b': (the edge's points at the cut, its seam where it is measured: [] when none)} for the check ``st``: each
    edge where it is measured (0.19.29), its seam up to a rembord's fold or a tube's closing seam (0.19.35); 0.19.36: kept
    for the same drawing (each move of the mouse drew them again from the start)."""
    both = st.get('a') and st.get('b')
    memo = _memo(app)
    key = ('drawn', st.get('a') and (st['a'][0], tuple(st['a'][1])), st.get('b') and (st['b'][0], tuple(st['b'][1])),
           st.get('seam'), bool(st.get('double')), bool(st.get('retourne')))
    if memo is not None and key in memo:
        return memo[key]
    seam = seam_of(app, st.get('seam'), (st['a'][0], st['b'][0]) if both else None, _st_sides(st) if both else None)
    cut = {x: portion(app, st[x])[0] for x in ('a', 'b') if st.get(x)}
    reach, shut = {}, {}
    if both:
        try:
            r, s, _, _, _ = pair_measure(app, st['a'], st['b'], seam, bool(st.get('double')))
            reach, shut = dict(zip('ab', r)), dict(zip('ab', s))
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            reach, shut = {}, {}
    out = {}
    for x, pts in cut.items():
        line = ()
        if reach.get(x, 0) > 0:
            from craft_tools import interior_side
            try:
                seam_at = seam_line(pts, reach[x], interior_side(app.items[st[x][0]]))
                line = seam_at.points
                lost = shut.get(x) or (0., 0.)
                if (lost[0] or lost[1]) and len(line) > 1:
                    line = _cut_line(line, lost[0], max(lost[0], seam_at.length - lost[1]))
            except ValueError:
                line = ()
        out[x] = (pts, list(line))
    if memo is not None:
        memo[key] = out
    return out


def draw(app, under=None):
    c = app.canvas
    c.delete('assembly_preview')
    if hasattr(app, 'plan_active') and not app.plan_active():
        return   # (review) a fiche shown: nothing over it
    _drop_stale(app)
    st = app.__dict__.get('assembly_state') or {}
    both = st.get('a') and st.get('b')
    for key, color in zip(('a', 'b'), COLORS):
        if st.get(key):
            pts, line = drawn_edges(app, st)[key]
            c.create_line(*[v for p in pts for v in app.to_screen(p)], fill=color, width=5, capstyle='round', tags=('assembly_preview',))
            if len(line) > 1:   # 0.19.26: the seam where it is measured, dashed
                c.create_line(*[v for p in line for v in app.to_screen(p)], fill=color, width=1.5, dash=(5, 3), tags=('assembly_preview',))
    if both and st.get('more'):   # 0.19.36: edge 2's next pieces, in its colour; the junctions marked on edge 1
        for k, ids in st['more']:
            try:
                pts = portion(app, (k, ids))[0]
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                continue
            c.create_line(*[v for p in pts for v in app.to_screen(p)], fill=COLORS[1], width=5, capstyle='round', tags=('assembly_preview',))
        r = _chain_cached(app, st)
        if r is not None:
            try:
                line = r['pa']
                total, at = _walk(line)
                same, back = facing_counts(r['ca'], r['la'], r['cb'], r['lb'], embu_of(st))   # (review: the way its crans say)
                for x in ([r['la'] - x for x in r['junctions']] if back > same else r['junctions']):
                    q = at(min(max(x, 0.), total))
                    q2 = at(min(max(x + .5, 0.), total))
                    dx, dy = q2[0] - q[0], q2[1] - q[1]
                    L = math.hypot(dx, dy) or 1.
                    sx, sy = app.to_screen(q)
                    nx, ny = -dy / L * 9, dx / L * 9
                    c.create_line(sx - nx, sy - ny, sx + nx, sy + ny, fill=COLORS[1], width=3, tags=('assembly_preview',))
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                pass
    growing = 'b' if st.get('b') else 'a' if st.get('a') else None
    if growing:   # 0.19.36: the sides Maj + clic can add to the edge being chosen, dotted in its colour
        k0, ids = st[growing]
        try:
            runs = sides(app.items[k0])[0]
            for j, (run, _, _) in enumerate(runs):
                if j not in ids and adjacent(app, st[growing], j):
                    c.create_line(*[v for p in run for v in app.to_screen(p)], fill=COLORS[growing == 'b'], width=2, dash=(2, 4),
                                  tags=('assembly_preview', 'assembly_next'))
        except (IndexError, KeyError, TypeError, ValueError):
            pass
    if under is not None:
        run = sides(app.items[under[0]])[0][under[1]][0]
        c.create_line(*[v for p in run for v in app.to_screen(p)], fill=app.p.get('accent', '#61c9ee'), width=3, dash=(6, 4), tags=('assembly_preview',))


def click(app, e):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return None
    _drop_stale(app)
    found = side_at(app, app.raw(e), _reach(app))
    note = None
    if found is None and drawn_here(app, app.raw(e), _reach(app)):
        found = _made_here(app, e)   # 0.19.29: the piece drawn inside a précoupe as Mozart draws it (a .crft made before)
        if found == 'break':
            return 'break'
        found, note = found
    if found is None:
        app.invalid_at(e, 'Cliquer le bord d’une pièce (Coupe externe).')
        return 'break'
    k, i = found
    shift = bool(getattr(e, 'state', 0) & 1)
    ctrl = bool(getattr(e, 'state', 0) & 4)
    if st.get('a') and st.get('b') and k != st['a'][0] and (ctrl or shift and chain_part(app, st, k, i) is not None):
        # 0.19.36 (fond mexicain): Ctrl + clic, edge 2 goes on onto this piece (again: it leaves edge 2); Maj + clic on one of
        # those pieces: its sides, as on edge 2's first one (0.19.40: a soufflet cut twice, the copy the hint names)
        parts = [tuple(p) for p in st.get('more') or ()]
        at = next((n for n, (kk, _) in enumerate(parts) if kk == k), None) if ctrl else chain_part(app, st, k, i)
        if ctrl:
            if at is not None:
                del parts[at]
            elif k != st['b'][0] or again(app, st, k):   # 0.19.39: a soufflet cut twice: its second copy
                parts.append((k, [i]))
        else:
            kk, ids = parts[at]
            ids = list(ids)
            if i in ids:
                if len(ids) > 1 and in_one_run(app, kk, [j for j in ids if j != i]):
                    ids.remove(i)
            elif adjacent(app, (kk, ids), i):
                ids.append(i)
            parts[at] = (kk, ids)
        st['more'] = parts
        st.pop('placed', None)
        remember(app)
        prompt(app)
        draw(app)
        window(app)
        return 'break'

    def grow(key):
        """Maj + click on a side of the same piece: added if it follows, removed if it was taken."""
        k0, ids = st[key]
        if i in ids:
            if len(ids) > 1 and in_one_run(app, k0, [j for j in ids if j != i]):   # 0.19.22: an end of the edge only (a
                ids.remove(i)                                                     # side in its middle split it in two)
        elif adjacent(app, st[key], i):
            ids.append(i)
    if not st.get('a'):
        st.update(a=(k, [i]), thickness=None, seam=None, **FRESH)   # 0.19.14: a thickness typed is for its own check (0.19.26: a jonc too)
    elif not st.get('b'):
        if k == st['a'][0] and not st.get('switched'):
            if shift:
                grow('a')
            else:
                st.update(a=(k, [i]), thickness=None, seam=None, **FRESH)
        else:
            st.update(b=(k, [i]), thickness=None, more=[])
    elif shift and k in (st['b'][0], st['a'][0]):
        # (review) the edge the hint beside the mouse names (would): edge 2 first, else edge 1, both on one piece too
        what = would(app, (k, i))
        grow(what[2] if what and what[0] in ('add', 'remove') else 'b' if k == st['b'][0] else 'a')
    else:   # a new check from this edge
        st.update(a=(k, [i]), b=None, switched=False, thickness=None, kept=None, added=False, seam=None, **FRESH)
    st.pop('placed', None)   # (second review: « Crans en face » again turns them only right after)
    if st.get('b'):
        remember(app)   # 0.19.24: kept with the model (Contrôle d'assemblage du sac); (review) first: its jonc shown
    prompt(app)
    if note:
        app.status.set(note + ' ' + app.status.get())
    draw(app)
    if st.get('b'):
        window(app)
    return 'break'


FRESH = dict(points=None, double=False, retourne=False, embu=0., more=())   # 0.19.29 (review): a new check keeps none of the last one's


_DRAWN = {}


def drawn_here(app, p, reach):
    """0.19.29: a piece drawn as Mozart draws it inside its précoupe (a closed line « dessin », surcoupe.drawn_precuts)
    has a side within ``reach`` of ``p`` (review: looked for once for the same drawing, not at each click)"""
    import surcoupe
    key = (id(app.items), len(app.items), tuple(map(id, app.items)))
    found = _DRAWN.get(id(app))
    if found is None or found[0] != key:
        try:
            found = (key, surcoupe.drawn_precuts(app.items))
        except (ValueError, KeyError, TypeError, IndexError):
            found = (key, [])
        _DRAWN.clear()
        _DRAWN[id(app)] = found
    found = found[1]
    for h, k, d in found:
        try:
            if min(_gap(p, run) for run, _, _ in sides(app.items[k])[0]) <= reach:
                return True
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            continue
    return False


def _made_here(app, e):
    """0.19.29 (« je t'ai déjà dit que s'il y a précoupe ça devrait marcher »): the précoupes drawn as Mozart's made
    Craft's own (as when a Mozart pattern is opened: the line inside, the piece), one Annuler; then the side clicked."""
    import surcoupe
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 'break'
    if not (getattr(app, 'prefs', None) or {}).get('show_recuts', True):   # (review: made, the piece would be hidden: never silently)
        app.invalid_at(e, 'Pièce tracée dans sa précoupe : afficher les surcoupes (Préparations › Surcoupes) pour la cliquer.')
        return 'break'
    try:
        app.snapshot()
    except Exception as exc:   # (read-only: licence_ui.LectureSeule)
        app.status.set(str(exc))
        return 'break'
    made = surcoupe.made_precuts(app.items)
    if hasattr(app, 'refresh'):
        app.refresh()
    return side_at(app, app.raw(e), _reach(app)), (
        f'{made} précoupe{"s" if made > 1 else ""} reconnue{"s" if made > 1 else ""} : la ligne tracée dedans est la pièce '
        '(comme à l’ouverture d’un patron Mozart ; Annuler : comme avant).')


def enter(app):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return 'break'
    if st.get('a') and not st.get('b'):
        st['switched'] = True   # the second edge on the same piece
        app.status.set("Cliquer le bord cousu dessus (sur la même pièce ou une autre).")
        return 'break'
    st.update(a=None, b=None, switched=False, thickness=None, kept=None, added=False, seam=None, **FRESH)
    st.pop('placed', None)
    prompt(app)
    draw(app)
    return 'break'


def write(app):
    """The check written on the plan, by the middle of the first edge."""
    from craft_tools import annotation
    r = result(app)
    if r is None:
        return None
    pts = r['a']
    half, travel, at = sum(math.dist(a, b) for a, b in zip(pts, pts[1:])) / 2, 0., pts[0]
    for a, b in zip(pts, pts[1:]):
        seg = math.dist(a, b)
        if travel + seg >= half:
            t = (half - travel) / seg if seg else 0
            at = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            break
        travel += seg
    text = annotation('Assemblage : ' + summary(r), (at[0] + 2, at[1] + 2), 2.5)
    text['assembly'] = dict(la=round(r['la'], 2), lb=round(r['lb'], 2), front=r['front'], points=r['points'], thickness=r['thickness'],
                            seam=r['seam'])
    app.snapshot()
    app.items.append(text)
    app.refresh()
    draw(app)
    return text


def _model_cran(app, chosen):
    """The settings of a cran already on the edge (piece, sides) to shape the new ones like it: its mark and whether it
    points inside; None without one."""
    from craft_tools import cran_mark, interior_side
    k, ids = chosen
    piece = app.items[k]
    owner = piece.get('piece_id') or piece.get('owner_id')
    pts, start, length, total = portion(app, chosen)
    for s in app.items:
        if s.get('is_notch') and owner and s.get('owner_id') == owner:
            mark = cran_mark(s, piece)
            if mark is not None and ((mark['distance'] - start) % total if total else 0.) <= length + .05:
                try:
                    return mark, mark.get('side', 1) == interior_side(piece)
                except ValueError:
                    return mark, True
    return None


def crans_in_front(app):
    """0.19.26 « Crans en face » (« Craft pose sur le 2e bord les crans qui manquent, en face de ceux du 1er »): on edge 2,
    a cran in front of each cran of edge 1 that has none there: at the same distance along the seam from the end facing
    edge 1's start (as the check counts them in front: review), shaped as a cran already on edge 2 (else on edge 1), on a
    corner along its bisector (as the Cran tool); one Annuler. Edge 2 without a cran: the way two pieces drawn the same
    way round are sewn (their edges run opposite), and « Crans en face » again right after puts them the other way. The
    number added."""
    st = app.__dict__.get('assembly_state') or {}
    r = result(app)
    if r is None:
        return 0
    if st.get('more'):   # 0.19.36 (« pq avoir des crans ? la distance fait que c parfait »)
        app.status.set('Bord 2 sur plusieurs pièces : les jonctions se placent par la distance (pas de crans à poser).')
        return 0
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    edges = (_frozen(st['a']), _frozen(st['b']))
    placed = st.get('placed')
    again = bool(placed) and placed['edges'] == edges and len(app.items) == placed['count'] and all(
        app.items[len(app.items) - len(placed['ids']) + n] is c for n, c in enumerate(placed['ids']))
    removed = []
    if again:   # « Crans en face » again right after: the crans it put, the other way (the same Annuler)
        removed = app.items[len(app.items) - len(placed['ids']):]
        del app.items[len(app.items) - len(placed['ids']):]
        r = result(app)
    else:
        bagged = (app.__dict__.get('_bag_placed') or {}).get(edges)
        if bagged and all(any(c is s for s in app.items) for c in bagged['ids']):
            # 0.19.27 (second review): the crans the whole bag put the way pieces are sewn (edge 2 had none): the other way
            try:
                app.snapshot()
            except Exception as exc:   # (read-only: licence_ui.LectureSeule)
                app.status.set(str(exc))
                return 0
            app._bag_placed.pop(edges, None)
            removed = list(bagged['ids'])
            app.items[:] = [s for s in app.items if not any(s is c for c in removed)]
            r = result(app)
            placed, again = dict(back=bagged['back']), True
    st.pop('placed', None)
    n = 0
    try:
        n = _in_front(app, st, r, edges, placed['back'] if again else None)
    finally:
        if removed and not n:   # (none put the other way: as they were)
            app.items.extend(removed)
            app.refresh()
    return n


def _new_crans(app, st, r, was=None):
    """The crans to put on edge 2 of the check ``st`` (a, b: piece, sides) in front of edge 1's, ``r`` its numbers
    (crans_a, crans_b, la, lb, b: edge 2's points, seam): (crans, the way they go, edge 2 had none or a tie (the way
    guessed), why none when none, how many of edge 2's are just beside where one goes: MISPLACED, to move, none put
    there). ``was``: the way crans just put went (now the other way)."""
    from craft_tools import interior_side, locate, new_cran, standalone_notch
    from entity_rules import ensure_piece_id
    ca, cb, la, lb = r['crans_a'], r['crans_b'], r['la'], r['lb']
    if not ca:
        return [], False, False, 'Aucun cran sur le bord 1 : rien à mettre en face.', 0
    piece = app.items[st['b'][0]]
    try:
        inside = interior_side(piece)
        guess = interior_side(app.items[st['a'][0]]) == inside   # (edge 2 without a cran: sewn, they run opposite)
    except ValueError:
        return [], False, False, 'Bord 2 : contour sans intérieur, crans impossibles.', 0
    embu = r.get('embu') or 0.   # 0.19.36: eased between the crans: those of edge 2 within it are in front already
    same, other = facing_counts(ca, la, cb, lb, embu)
    guessed = was is None and same == other
    back = (not was) if was is not None else other > same if other != same else guess   # (second review: a tie: as sewn)
    pts = r['b']
    ring = len(pts) > 3 and math.dist(pts[0], pts[-1]) < 1e-6   # (edge 2 all round: 0 and its length the same place)

    def apart(y, z):
        gap = abs(y - z)
        return min(gap, lb - gap) if ring else gap
    wanted, near = [], 0
    free = list(cb)   # (review: the crans of edge 2 not in front of one of edge 1's yet)
    ease = None
    if embu > 0:
        lo, hi = (-TOLERANCE, embu + TOLERANCE) if la >= lb else (-embu - TOLERANCE, TOLERANCE)
        mine = [(lb - z if back else z, z) for z in cb]
        ease = easing(app, st, r, back)   # 0.19.39: the embu taken up in the round corners, the straight parts in front
    else:   # (review) one in front of one first, as facing_counts counts them: a cran of edge 2 in front of one of edge 1's
        for x in ca:   # is never « near » another one of them (a double cran: its second one put, never « à déplacer »)
            y = min(max(lb - x if back else x, 0.), lb)
            y = 0. if ring and y >= lb - 1e-9 else y
            hit = next((z for z in free if apart(y, z) <= TOLERANCE), None)
            if hit is not None:
                free.remove(hit)
    for x in ca:
        if embu > 0:
            hit = next((n for n, (m, z) in enumerate(mine) if z in free and lo <= x - m <= hi), None)
            if hit is not None:   # (review: one in front of one, as facing_counts counts them; never « near » another)
                free.remove(mine[hit][1])
                continue
            x = ease(x) if ease is not None else x * lb / la if la > 1e-9 else x   # (else the embu spread along the edge)
        y = min(max(lb - x if back else x, 0.), lb)   # (along edge 2 itself)
        if ring and y >= lb - 1e-9:
            y = 0.
        if not any(apart(y, z) <= TOLERANCE for z in cb + wanted):
            if any(apart(y, z) < MISPLACED for z in free):   # 0.19.27 (second review): one of edge 2's just beside: to move,
                near += 1                                  # never a second one beside it
                continue
            wanted.append(y)
    if not wanted:
        return [], back, guessed, (f'{near} cran{"s" if near > 1 else ""} du bord 2 presque en face (à moins de {_mm(MISPLACED)} mm) : '
                                   f'à déplacer ; aucun ajouté.' if near else 'Les crans du bord 2 sont déjà en face de ceux du bord 1.'), near
    d = (r.get('reach') or (r['seam'], r['seam']))[1]   # 0.19.29: edge 2 where it is measured (its fold, the cut for fabric)
    line = seam_line(pts, d, inside) if d > 0 else None
    lost = (r.get('shut') or ((0., 0.), (0., 0.)))[1][0]   # 0.19.29: its seam starting at a tube's end seam
    model = _model_cran(app, st['b']) or _model_cran(app, st['a'])
    mark, pointing_in = model if model else (None, True)
    side = inside if pointing_in else -inside
    owner = piece.get('piece_id') or piece.get('owner_id') or ensure_piece_id(piece)
    made, taken = [], []
    for y in wanted:
        y += lost
        if line is not None:
            spot = line.back(y)
        else:
            spot, travel = pts[-1], 0.
            for a, b in zip(pts, pts[1:]):
                L = math.dist(a, b)
                if travel + L >= y and L > 0:
                    t = (y - travel) / L
                    spot = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
                    break
                travel += L
        if spot is None:
            continue
        distance = locate(piece, spot)[0]
        if any(abs(distance - other) < TOLERANCE / 2 for other in taken):
            continue   # (second review: several wanted by an inside corner: one cran there, never a stack)
        taken.append(distance)
        settings = new_cran(distance, side)
        for key in ('depth', 'kind', 'width', 'cap_width', 'gap'):
            if mark and key in mark:
                settings[key] = mark[key]
        bisector = app.corner_bisector(piece, distance, side) if hasattr(app, 'corner_bisector') else None
        if bisector:
            settings['direction'] = bisector   # (on a corner: along its bisector, as the Cran tool)
        cran = standalone_notch(piece, settings)
        cran['owner_id'] = owner
        made.append(cran)
    return made, back, guessed, None if made else 'Aucun cran posé sur le bord 2.', near


CURVED = 1 / 2000.   # 1/mm: 0.19.39 a part of a seam turning more than this (a radius under 2 m) is a curve
BEND = 30.   # degrees: a sharper turn is a corner, not a curve (stitching.CORNER)


def curves(pts, d, inside, shut=(0., 0.)):
    """0.19.39: the curved parts of an edge (its points ``pts``) at its seam, ``d`` mm inside (0: the cut), [(from, to)]
    in mm along the seam as its crans are counted (``shut``: what its seam loses at its start and its end), merged. A part
    turning gently all along (a round corner, a curve) counts; a straight part between two round corners (tangent to
    them) and a sharp corner never do."""
    offset, ring = 0., False
    line = None
    if d > 0:
        try:
            line = seam_line(pts, d, inside)
        except (ValueError, ZeroDivisionError, IndexError):
            line = None
    if line is None:
        P = [tuple(q) for q in pts]
        S = [0.]
        for a, b in zip(P, P[1:]):
            S.append(S[-1] + math.dist(a, b))
        L = S[-1]
        ring = len(P) > 3 and math.dist(P[0], P[-1]) < 1e-6
    elif line.ring:
        rot = line.ring[0]
        P, S, L, offset, ring = list(rot.points), list(rot.starts), line.length, line.ring[3], True
    else:
        P, S, L = list(line.points), list(line.starts), line.length
    n = len(P)
    if n < 3 or L <= 1e-9:
        return []

    def turn(a, b, c):
        u, v = (b[0] - a[0], b[1] - a[1]), (c[0] - b[0], c[1] - b[1])
        if math.hypot(*u) < 1e-12 or math.hypot(*v) < 1e-12:
            return 0.
        angle = abs(math.atan2(u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1]))
        return angle if math.degrees(angle) < BEND else 0.
    bends = [0.] * n
    for k in range(1, n - 1):
        bends[k] = turn(P[k - 1], P[k], P[k + 1])
    if ring and n > 3:   # (round the closing point too: P[0] and P[-1] the same point)
        bends[0] = bends[-1] = turn(P[-2], P[0], P[1])
    found = []
    for k in range(n - 1):
        span = S[k + 1] - S[k]
        if span > 1e-9 and (bends[k] + bends[k + 1]) / 2 / span > CURVED:
            if found and abs(found[-1][1] - S[k]) < 1e-9:
                found[-1][1] = S[k + 1]
            else:
                found.append([S[k], S[k + 1]])
    out = []
    usable = max(L - shut[0] - shut[1], 0.)
    for a, b in found:
        pieces = [(a - offset, b - offset)]
        if ring:
            a, b = (a - offset) % L, (b - offset) % L
            pieces = [(a, b)] if a <= b else [(a, L), (0., b)]
        for a, b in pieces:
            a, b = max(a - shut[0], 0.), min(b - shut[0], usable)
            if b - a > 1e-9:
                out.append((a, b))
    return sorted(out)


def _covered(parts, x):
    return sum(max(0., min(b, x) - a) for a, b in parts if a < x)


def easing(app, st, r, back):
    """0.19.39 « Crans en face » with an embu (« répartit l'embu dans les coins arrondis (effet bombé), crans des côtés
    droits pile en face »): a function giving, for a cran ``x`` mm along edge 1, where it falls along edge 2 (from the end
    facing edge 1's start): the straight parts sewn one in front of the other, the difference of the lengths taken up in
    the curves of the edge that has the most of them; None when neither edge has curves that can take it (the embu then
    spread along the whole edge, as before)."""
    from craft_tools import interior_side
    la, lb = r['la'], r['lb']
    D = la - lb
    reach = r.get('reach') or (r['seam'], r['seam'])
    shut = r.get('shut') or ((0., 0.), (0., 0.))
    try:
        ca = curves(r['a'], reach[0], interior_side(app.items[st['a'][0]]), shut[0])
        cb = curves(r['b'], reach[1], interior_side(app.items[st['b'][0]]), shut[1])
    except (ValueError, KeyError, IndexError, TypeError):
        return None
    if back:
        cb = sorted((lb - b, lb - a) for a, b in cb)
    A, B = sum(b - a for a, b in ca), sum(b - a for a, b in cb)
    for curved, total in sorted(((ca, A), (cb, B)), key=lambda c: -c[1]):
        if total <= 1e-6:
            continue
        if curved is ca and D < total * .95:   # edge 1's curves: f(x) = x − D × (its curve before x) / A
            return lambda x, ca=ca, A=A: min(max(x - D * _covered(ca, x) / A, 0.), lb)
        if curved is cb and -D < total * .95:   # edge 2's: g(y) = y + D × (its curve before y) / B, f its inverse
            def inverse(x, cb=cb, B=B):
                lo, hi = 0., lb
                for _ in range(60):
                    mid = (lo + hi) / 2
                    if mid + D * _covered(cb, mid) / B < x:
                        lo = mid
                    else:
                        hi = mid
                return (lo + hi) / 2
            return inverse
    return None


def _in_front(app, st, r, edges, was):
    """crans_in_front once the check is known: ``was`` the way the crans just put went (put now the other way), None."""
    again = was is not None
    made, back, tie, why, near = _new_crans(app, st, r, was)
    cb, ca = r['crans_b'], r['crans_a']
    if why:
        app.status.set(why)
        return 0
    if not again:
        try:
            app.snapshot()
        except Exception as exc:   # (read-only: licence_ui.LectureSeule)
            app.status.set(str(exc))
            return 0
    app.items.extend(made)
    turned = tie and any(abs(x - y) > TOLERANCE for x, y in zip(sorted(ca), sorted(r['lb'] - x for x in ca)))
    if not cb or again or turned:   # (0.19.27, second review: a tie with crans on edge 2, the two ways not the same places)
        st['placed'] = dict(edges=edges, count=len(app.items), ids=list(made), back=back)
    app.refresh()
    draw(app)
    win = app.__dict__.get('_assembly_window')
    if win is not None and win.winfo_exists():
        win._refill()
    prompt(app)
    n = len(made)
    after = result(app)
    short = len(ca) - (after['front'] if after else len(ca)) - near   # (second review: by an inside corner, a cran falls at the
    app.status.set(f'{n} cran{"s" if n > 1 else ""} ajouté{"s" if n > 1 else ""} sur le bord 2, en face de ceux du bord 1'   # corner)
                   + (f' ({short} pas tout à fait en face)' if short > 0 else '')
                   + (f' ; {near} du bord 2 presque en face (à moins de {_mm(MISPLACED)} mm) : à déplacer' if near else '')
                   + (' ; « Crans en face » encore : l’autre sens' if st.get('placed') else '') + ' (Annuler : les retire).')
    return n


MISPLACED = 3.   # mm: a cran of edge 2 this near where one should be (not within TOLERANCE): one to move, not one to add
SAME_LENGTH = .005   # mm: 0.19.29 « Ajuster »: edge 2 as long as edge 1 to this


def _segment_of(q, run):
    """0.19.29: the longest straight segment of the polyline ``q`` (its index) lying on the side ``run`` (its points), None"""
    V = [(q['x'] + x, q['y'] + y) for x, y in q['points']]
    n = len(V)
    B = (list(q.get('bulges') or []) + [0] * n)[:n]
    best = None
    for k in range(n if q.get('closed') else n - 1):
        a, b = V[k], V[(k + 1) % n]
        if B[k] or math.dist(a, b) < 1e-6 or _gap(a, run) > 1e-6 or _gap(b, run) > 1e-6:
            continue
        if best is None or math.dist(a, b) > best[0]:
            best = (math.dist(a, b), k)
    return best[1] if best else None


def adjust(app):
    """0.19.29 « Ajuster » (« raccourcir ou allonger le bord 2 de son écart en un clic »): edge 2 of the check made as long
    as edge 1 at the seam: the side just after it, else just before it, moved across itself as by its « milieu » grip
    (its neighbours keep their lines, its rounds their radius, its crans follow) until the two lengths are the same
    (SAME_LENGTH); one Annuler. Never a side of edge 1, never across the contour (« Le contour se croise. »). The mm
    edge 2 changed by, None."""
    st = app.__dict__.get('assembly_state') or {}
    r = result(app)
    if r is None:
        return None
    if st.get('more'):   # 0.19.36: edge 2 on several pieces: which one to change is not said
        app.status.set('Ajuster : bord 2 sur plusieurs pièces : à corriger à la main (la pièce à changer n’est pas dite).')
        return None
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return None
    delta = r['la'] - r['lb'] + _goal(r)   # 0.19.36: up to its embu
    if abs(delta) <= SAME_LENGTH:
        app.status.set('Ajuster : les deux bords ont déjà la même longueur.' if not r.get('embu') else
                       f'Ajuster : l’écart est déjà celui de l’embu ({_mm(r["embu"])} mm).')
        return None
    kb = st['b'][0]
    found, why = _adjusting(app, st, r)
    if found is None:
        app.status.set(why)
        return None
    try:
        app.snapshot()
    except Exception as exc:   # (read-only: licence_ui.LectureSeule)
        app.status.set(str(exc))
        return None
    zone = _adjusted(app, kb, found)
    if hasattr(app, 'refresh'):
        app.refresh()
    remember(app)
    draw(app)
    win = app.__dict__.get('_assembly_window')
    if win is not None and win.winfo_exists():
        win._refill()
    prompt(app)
    c, k, d = found[:3]
    follows = ', sa précoupe aussi' if len(found) > 4 and found[4] is not None else ''   # 0.19.31
    if zone is False:
        follows += ' (sa zone de surcoupe n’a pas pu être refaite : à refaire)'
    app.status.set(f'Bord 2 {"allongé" if delta > 0 else "raccourci"} de {_mm(abs(delta), 2)} mm : {_name(host(app, kb)) or "pièce"}, '
                   f'côté {c + 1} déplacé de {_mm(abs(d), 2)} mm{follows} (Annuler : comme avant).')
    return delta


def _goal(r):
    """0.19.36: what edge 2 less edge 1 is meant to be: its embu, the longer edge staying the longer; 0 without"""
    embu = r.get('embu') or 0.
    if embu <= 0:
        return 0.
    return -embu if r['la'] >= r['lb'] else embu


def _adjusting(app, st, r, avoid=()):
    """0.19.29 (0.19.30: out of adjust, for the bag too): edge 2 of ``st`` (its numbers ``r``: la, lb, reach, shut) made as
    long as edge 1 by moving the side just after it, else just before it: (c, k, d, (difference, piece, moved, arcs)) the
    side, its segment, how far, the new piece; or (None, why). ``avoid``: sides of the piece never moved, nor whose other
    neighbour (the side beyond: its length changes too) is one of them (0.19.30: the other seams of the bag)."""
    from advanced_edit import side_moved
    from geometry import validate
    goal = _goal(r)   # 0.19.36: edge 2 as much shorter (longer) as its embu
    delta = r['la'] - r['lb'] + goal
    kb, ids = st['b']
    piece = app.items[kb]
    inside_precut = _inside_precut(piece)   # 0.19.31: its précoupe follows (_precut_follows)
    q0 = app.as_polyline(piece) if hasattr(app, 'as_polyline') else (piece if piece.get('kind') == 'poly' else None)
    if q0 is None:
        return None, 'Ajuster : seulement une pièce en polyligne (Joindre ou Décomposer d’abord).'
    runs = sides(piece)[0]
    n = len(runs)
    order = sorted(set(ids))
    if len(order) > 1 and order[0] == 0 and order[-1] == n - 1 and len(order) < n:   # (round the closing corner)
        cut = next(i for i in range(1, len(order)) if order[i] != order[i - 1] + 1)
        order = order[cut:] + order[:cut]
    if len(order) >= n:
        return None, 'Ajuster : le bord 2 fait tout le tour de la pièce, rien à déplacer.'
    edge1 = set(st['a'][1]) if st['a'][0] == kb else set()
    avoid = set(avoid)
    reach, shut = r['reach'][1], r['shut'][1]

    def length(q):
        """edge 2 less edge 1 (review: edge 1 on the same piece may change too)"""
        app.items[kb] = q
        try:
            if len(sides(q)[0]) != n:
                return None
            la = measured(app, st['a'], r['reach'][0], r['shut'][0])[2] if edge1 else r['la']
            return measured(app, (kb, ids), reach, shut)[2] - la - goal
        finally:
            app.items[kb] = piece
    found = None
    why = 'Ajuster : aucun côté droit à déplacer au bout du bord 2.'
    for c, beyond, end in (((order[-1] + 1) % n, (order[-1] + 2) % n, order[-1]), ((order[0] - 1) % n, (order[0] - 2) % n, order[0])):
        if c in order or c in edge1:
            continue
        if end in avoid:   # (review: the side of edge 2 that gets longer is sewn in another seam too)
            why = 'Ajuster : le bout du bord 2 est aussi cousu dans une autre couture du sac : à corriger à la main.'
            continue
        if c in avoid or beyond in avoid and beyond not in order:
            why = 'Ajuster : le côté au bout du bord 2 touche une autre couture du sac : à corriger à la main.'
            continue
        if _side_zones(app, kb, runs[c][0])[1]:   # (review, 0.19.35: its rembord goes on along other sides: it cannot follow)
            why = 'Ajuster : le côté au bout du bord 2 est rembordé avec d’autres côtés : à corriger à la main.'
            continue
        k = _segment_of(q0, runs[c][0])
        if k is None:
            continue
        tried = {}

        def f(d):
            if d not in tried:
                try:
                    arcs = []
                    q, moved = side_moved(q0, k, d, arcs)
                    validate([q])
                    got = length(q)
                    tried[d] = None if got is None else (got, q, moved, arcs)
                except ValueError as exc:
                    tried[d] = None
                    f.why = str(exc)
            return tried[d]
        f.why = None
        d0, f0 = 0., r['lb'] - r['la'] - goal
        d1 = f1 = None
        # (a step each way: which way, how much the edge changes for it; 0.19.40 review: half the écart under 0,4 mm too: a
        # step of 0,2 mm overshot an écart under 0,1 mm both ways, « aucun côté droit à déplacer » was said)
        h = max(SAME_LENGTH, min(abs(delta) / 2, 5.))
        for guess in (h, -h):
            got = f(guess)
            if got is not None and abs(got[0]) < abs(f0) and (d1 is None or abs(got[0]) < abs(f1)):
                d1, f1 = guess, got[0]
        if d1 is None:
            why = (f'Ajuster : {f.why}' if f.why else 'Ajuster : déplacer le côté au bout du bord 2 change autant le bord 1 (même pièce) : '
                   'à corriger à la main.' if edge1 and any(v is not None for v in tried.values()) else why)
            continue
        for _ in range(12):
            if abs(f1) <= SAME_LENGTH or abs(f1 - f0) < 1e-12:
                break
            d2 = d1 - f1 * (d1 - d0) / (f1 - f0)
            got = f(d2)
            if got is None:
                break
            d0, f0, d1, f1 = d1, f1, d2, got[0]
        if abs(f1) <= max(SAME_LENGTH, .01):
            found = (c, k, d1, tried[d1])
            if inside_precut:
                try:
                    found += (_precut_follows(app, kb, found),)
                except ValueError as exc:
                    why, found = f'Ajuster : {exc}', None
                    continue
            break
    return (found, None) if found is not None else (None, why)


def _inside_precut(s):
    """0.19.30 (review): a piece surcoupée (the line inside its précoupe, with no id of its own: « dans: »): never adjusted
    (its précoupe would keep its size, its crans (its précoupe's) and its Piqûre would stay where they are)."""
    import surcoupe
    from craft_tools import style
    try:
        return not s.get('piece_id') and bool(s.get('owner_id')) and style(s)['role'] == surcoupe.ROLE
    except (KeyError, TypeError, AttributeError):
        return False


def _rank(r):
    """0.19.30 (review): how far a pair checked is from right, to tell whether an adjustment made it worse."""
    return ({'ok': 0, 'crans': 1, 'bad': 2}.get(r['state'], 3), round(abs(r['la'] - r['lb']), 2) if r['state'] == 'bad' else 0.,
            -r.get('front', 0))


def _adjusted(app, kb, found):
    """The piece ``kb`` as _adjusting made it (in the Annuler step taken before): its crans and Piqûres follow it. 0.19.31:
    a piece in a précoupe: the crans and the Piqûre are its précoupe's (owner_id), the précoupe follows (_precut_follows),
    with its Surcoupe zone."""
    c, k, d, (_, q, moved, arcs) = found[:4]
    follow = found[4] if len(found) > 4 else None
    piece = app.items[kb]
    q0 = app.as_polyline(piece) if hasattr(app, 'as_polyline') else piece
    _zones_follow(app, kb, sides(piece)[0][c][0], q0, k, d)   # (review, 0.19.35) before the piece changes (its zones read on it)
    app.items[kb] = q
    original = piece if piece.get('piece_id') or not piece.get('owner_id') else dict(piece, piece_id=piece['owner_id'])
    g = dict(original=original, index=kb, mode=('side', k), polyline=q0)
    if hasattr(app, 'reattach_crans'):
        app.reattach_crans(g, q, moved, arcs)
    if hasattr(app, 'grip_done'):
        app.grip_done(g)   # (the Piqûres made round it follow it)
    if follow is not None:
        hp, outer, j, moved2, arcs2 = follow
        old = app.items[hp]
        app.items[hp] = outer
        g2 = dict(original=old, index=hp, mode=('side', j), polyline=old)
        if hasattr(app, 'reattach_crans'):
            app.reattach_crans(g2, outer, moved2, arcs2)
        if hasattr(app, 'grip_done'):
            app.grip_done(g2)
    if piece.get('owner_id') and not piece.get('piece_id'):
        return _band_again(app, piece['owner_id'], q)
    return True


def _side_zones(app, kb, run):
    """(review, 0.19.35) the parage « rembord » zones of piece ``kb`` along its side ``run`` (most of it in or by the zone, as
    parage() finds them; its zones or a zone without its piece lying on it, as _bands counts them): ([zone index], wrapped:
    one of them goes on along other sides: it cannot follow). A zone that is not a band (over the whole piece, its width
    unknown) is neither: its pairs are measured as before (_bands: unknown)."""
    from geometry import geometry_key, path
    zone_width = __import__('preparation_ui').zone_width
    piece = app.items[kb]
    owners = {piece.get('piece_id'), piece.get('owner_id'), host(app, kb).get('piece_id')} - {None}
    ids = {q.get('piece_id') for q in app.items if q.get('piece_id')}
    samples = _along(run)
    contour, out, wrapped = None, [], False
    for z, s in enumerate(app.items):
        data = s.get('preparation')
        if not isinstance(data, dict) or data.get('kind') != 'parage' or 'REMBORD' not in str(data.get('type') or '').upper():
            continue
        try:
            ring = [(float(p[0]), float(p[1])) for p in path(s)[0]]
            if s.get('owner_id') not in owners:
                if s.get('owner_id') in ids or len(ring) < 3:
                    continue
                if contour is None:
                    contour = [(float(p[0]), float(p[1])) for p in path(piece)[0]]
                if 2 * _near_count(ring, contour, .05, key=geometry_key(piece)) < len(ring):
                    continue
            if _near_count(samples, ring, key=geometry_key(s)) < len(samples) / 2:
                continue
            w = float(zone_width(s))
        except (TypeError, ValueError, ZeroDivisionError, KeyError, IndexError):
            continue   # (no band: its pairs measured as before, _bands: unknown)
        if not (math.isfinite(w) and 0 < w <= BAND_MOST):
            continue   # (over the whole piece: its pairs measured as before; it stays, as in 0.19.34)
        if any(_gap(p, run) > w + .5 for p in ring):
            wrapped = True
            continue
        out.append(z)
    return out, wrapped


def _zones_follow(app, kb, run, q0, k, d):
    """(review, 0.19.35) the rembord bands along the side ``run`` of piece ``kb`` (_side_zones) moved with it (segment ``k`` of
    the polyline ``q0`` moved ``d`` mm across itself, as side_moved moves it): new objects (adjust_bag puts the list back as
    it was when an adjustment is undone). Else « Ajuster » measured edge 2 folded at that end, but the zone stayed: the end
    no longer folded, the écart came back (a cavour lengthened by 10 mm: 7 mm too long)."""
    V = [(q0['x'] + x, q0['y'] + y) for x, y in q0['points']]
    a, b = V[k], V[(k + 1) % len(V)]
    L = math.dist(a, b)
    if L < 1e-9:
        return
    dx, dy = -(b[1] - a[1]) / L * d, (b[0] - a[0]) / L * d
    for z in _side_zones(app, kb, run)[0]:
        s = app.items[z]
        app.items[z] = dict(s, x=s['x'] + dx, y=s['y'] + dy)


def _precut_follows(app, kb, found):
    """0.19.31 (« Ajuster » une pièce dans une précoupe : sa précoupe, ses crans et sa piqûre suivent): the précoupe of the
    piece ``kb`` (surcoupée) as it follows the side ``found`` moves: its side facing that one, parallel at its écart
    (surcoupe.band_width), moved as far: (its index, the précoupe moved, its segment, (old, new) of its points moved, its
    arcs changed); None when no side faces it and the précoupe still holds the piece at its écart (nothing to move).
    ValueError: a précoupe in series (several pieces), none found, a précoupe that would no longer hold the piece."""
    import surcoupe
    from advanced_edit import side_moved
    from geometry import validate
    from precision_geometry import inside
    piece = app.items[kb]
    owner = piece.get('owner_id')
    hp = next((i for i, s in enumerate(app.items) if s.get('piece_id') == owner and surcoupe.is_precut(s)), None)
    if hp is None:
        raise ValueError('la précoupe du bord 2 est introuvable : à corriger à la main.')
    if surcoupe.inner_contours(app.items, hp) != [kb]:
        raise ValueError('le bord 2 est sur une pièce d’une précoupe en série : à corriger à la main.')
    gap = surcoupe.band_width(app.items, hp)
    if not gap:   # (review: said as it is, not « ne suit pas ce côté »)
        raise ValueError('l’écart de la précoupe du bord 2 est inconnu : à corriger à la main.')
    c, k, d, (_, q, _, _) = found[:4]
    q0 = _polyline(app, piece)
    V = [(q0['x'] + x, q0['y'] + y) for x, y in q0['points']]
    a, b = V[k], V[(k + 1) % len(V)]
    L = math.dist(a, b)
    u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
    n = (-u[1], u[0])   # (side_moved moves the side by d along it)
    middle = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
    out = -1. if inside(piece, (middle[0] + .01 * n[0], middle[1] + .01 * n[1])) else 1.   # (the side's outside, along n)
    outer = app.items[hp]
    o0 = _polyline(app, outer)
    best = None
    if o0 is not None and gap:
        P = [(o0['x'] + x, o0['y'] + y) for x, y in o0['points']]
        B = (list(o0.get('bulges') or []) + [0] * len(P))[:len(P)]
        for j in range(len(P) if o0.get('closed') else len(P) - 1):
            a2, b2 = P[j], P[(j + 1) % len(P)]
            L2 = math.dist(a2, b2)
            if B[j] or L2 < 1e-6:
                continue
            u2 = ((b2[0] - a2[0]) / L2, (b2[1] - a2[1]) / L2)
            if abs(u[0] * u2[1] - u[1] * u2[0]) > 2e-3:
                continue   # (not parallel)
            away = ((a2[0] - a[0]) * n[0] + (a2[1] - a[1]) * n[1]) * out
            if abs(away - gap) > max(.05, 2e-3 * gap):
                continue   # (not at the écart, outside)
            t1 = (a2[0] - a[0]) * u[0] + (a2[1] - a[1]) * u[1]
            t2 = (b2[0] - a[0]) * u[0] + (b2[1] - a[1]) * u[1]
            overlap = min(L, max(t1, t2)) - max(0., min(t1, t2))
            if overlap > 1e-6 and (best is None or overlap > best[0]):
                best = (overlap, j, u2)
    if best is None:
        if gap and surcoupe.holds(outer, q, gap):
            return None   # (the précoupe holds it still: a Rectangle around it, a side moved in)
        raise ValueError('la précoupe du bord 2 ne suit pas ce côté : à corriger à la main.')
    _, j, u2 = best
    n2 = (-u2[1], u2[0])
    d2 = d * (n[0] * n2[0] + n[1] * n2[1])
    arcs2 = []
    o1, moved2 = side_moved(o0, j, d2, arcs2)
    validate([o1])
    if not surcoupe.holds(o1, q, gap):
        raise ValueError('la précoupe ne garderait pas son écart : à corriger à la main.')
    return hp, o1, j, moved2, arcs2


def _polyline(app, s):
    """the shape as one polyline (advanced_ui.as_polyline; a polyline as it is without the app's), None"""
    if hasattr(app, 'as_polyline'):
        return app.as_polyline(s)
    return s if s.get('kind') == 'poly' and not s.get('notches') else None


def _band_again(app, owner, inner):
    """0.19.31: the Surcoupe zone of the précoupe ``owner`` (its band: the précoupe less its piece) made again; False when
    it could not be (review: said, never silently the old one)."""
    import surcoupe
    hp = next((i for i, s in enumerate(app.items) if s.get('piece_id') == owner and surcoupe.is_precut(s)), None)
    if hp is None:
        return True
    for z, s in enumerate(app.items):
        prep = s.get('preparation')
        if prep and prep.get('kind') == 'surcoupe' and s.get('owner_id') == owner:
            try:
                new = surcoupe.band_zone(app.items[hp], [inner], float(prep.get('width') or surcoupe.band_width(app.items, hp)), owner)
            except (ValueError, KeyError, TypeError, ZeroDivisionError):
                return False
            from stitching import GEOMETRY
            app.items[z] = dict({k: v for k, v in s.items() if k not in GEOMETRY}, **{k: new[k] for k in GEOMETRY if k in new})
    return True


def adjust_bag(app):
    """0.19.30 « Ajuster » for the whole bag (« Ajuster tout le sac en un clic »): each pair kept whose edges differ at the
    seam by more than ECART (red in the list) gets edge 2 made as long as edge 1 as « Ajuster » makes it for one (the side
    at its end moved), never a side of another seam of the bag nor one beside it (review: nor the end of edge 2 when another
    seam sews it too), never a piece inside a précoupe; the pairs in the order of the list, each measured after those before
    it; an adjustment that would make another seam on the same piece worse (_rank) is undone; one snapshot, one Annuler.
    Left, and said by their numbers with the reason the single « Ajuster » gives (_reason): a pair to check again, no side
    that can be moved... The number of pairs adjusted."""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    pieces = _pieces(app, every=True)
    pairs = [(n, pair) for n, pair in enumerate(entries(app), 1) if 'etape' not in pair]
    def sewn(pair):
        """the edges of a pair as (piece, sides), but those of a piece whose sides changed since (to check again: review);
        0.19.36 (review): edge 2's next pieces too (a fond mexicain's fond and other patte)"""
        out = []
        for e in [pair['a'], pair['b']] + list(pair.get('more') or ()):
            k = piece_index(app, e['piece'], pieces)
            try:
                if k is not None and len(sides(app.items[k])[0]) == e['count']:
                    out.append((k, set(e['sides'])))
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                pass
        return out
    edges = {n: sewn(pair) for n, pair in pairs}   # (« Ajuster » never changes how many sides a piece has)
    done, left, saved = [], {}, False

    def leave(n, why):
        left.setdefault(why, []).append(n)
    for n, pair in pairs:
        r = check(app, pair, pieces)
        if r['state'] in ('gone', 'changed'):
            leave(n, 'à refaire')
            continue
        if r['state'] != 'bad':
            continue
        if pair.get('more'):   # 0.19.36: edge 2 on several pieces: which one to change is not said
            leave(n, 'bord 2 sur plusieurs pièces : à corriger à la main')
            continue
        found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
        kb = found[1]
        # (review) the sides of the piece sewn in the OTHER seams of the bag: never moved, nor one whose length changes
        others = set()
        for m, theirs in edges.items():
            if m != n:
                for k, s in theirs:
                    if k == kb:
                        others |= s
        st = dict(a=(found[0], e_sides(pair['a'])), b=(kb, e_sides(pair['b'])))
        try:
            shut = (closings(app, *st['a']), closings(app, *st['b']))
            shut = with_folds(shut, pair_folds(app, [st['a'], st['b']], r['reach'], bool(pair.get('double'))))   # 0.19.35
            got, why = _adjusting(app, st, dict(la=r['la'], lb=r['lb'], reach=r['reach'], shut=shut, embu=r.get('embu', 0.)), others)
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            got, why = None, None
        if got is None:   # (review: the reason said, as the single « Ajuster » says it)
            leave(n, _reason(why))
            continue
        near = [(m, other) for m, other in pairs if m != n and any(k == kb for k, _ in edges[m])]
        before = {m: _rank(check(app, other, pieces)) for m, other in near}
        kept = list(app.items)   # (_adjusted puts new objects in: the list as it was is the drawing as it was)
        _adjusted(app, kb, got)
        pieces = _pieces(app, every=True)
        worse = [m for m, other in near if _rank(check(app, other, pieces)) > before[m]]
        if worse:   # (review: never another seam of the bag made worse; the reason said)
            app.items[:] = kept
            pieces = _pieces(app, every=True)
            leave(n, f'l’ajuster changerait la couture {_numbers(worse)} : à corriger à la main')
            continue
        if not saved:   # (the Annuler step taken with the drawing as it was, once an adjustment is kept: never an empty one)
            made = list(app.items)
            app.items[:] = kept
            try:
                app.snapshot()
            except Exception as exc:   # (read-only: licence_ui.LectureSeule)
                pieces = _pieces(app, every=True)
                app.status.set(str(exc))
                return 0
            app.items[:] = made
            saved = True
        done.append(n)
    still = [n for n, pair in pairs if n in done and check(app, pair, pieces)['state'] == 'bad']
    said = ''
    if left:
        said = (' Laissée' if sum(len(v) for v in left.values()) == 1 else ' Laissées') + ' : ' + ' ; '.join(
            f'{_numbers(ns)} ({why})' for why, ns in left.items()) + '.'
    if still:
        said += f' {_numbers(still)} : encore un écart, à refaire.'
    if not done:
        app.status.set(('Aucune couture ajustée.' if left else 'Aucune couture du sac n’a d’écart de plus de 0,5 mm.') + said)
        return 0
    app.refresh()
    for name in ('_bag_window', '_assembly_window'):
        win = app.__dict__.get(name)
        if win is not None and win.winfo_exists():
            if name == '_assembly_window' and (app.__dict__.get('assembly_state') or {}).get('b'):
                draw(app)
            win._refill()
    one = len(done) == 1
    app.status.set(f'{len(done)} couture{"" if one else "s"} ajustée{"" if one else "s"} ({_numbers(done)} : le 2e bord à la longueur du 1er ; '
                   f'Annuler : comme avant).' + said)
    return len(done)


LEFT_ADJUST = 'aucun côté à déplacer au bout du 2e bord : à corriger à la main'   # (a pair left for a reason not said)


def _reason(why):
    """0.19.30 (review): a pair the bag's « Ajuster » leaves, said with the reason the single « Ajuster » gives: « Ajuster : le
    bord 2 fait tout le tour de la pièce, rien à déplacer. » → « le bord 2 fait tout le tour de la pièce, rien à déplacer »."""
    if not why:
        return LEFT_ADJUST
    text = why.split(' : ', 1)[1] if why.startswith('Ajuster : ') else why
    text = text.strip().rstrip('.')
    if len(text) > 1 and text[0].isupper() and text[1].islower():
        text = text[0].lower() + text[1:]
    return text or LEFT_ADJUST


def _numbers(ns):
    """« n° 2 », « n° 2 et 5 », « n° 2, 3 et 5 »"""
    ns = [str(n) for n in ns]
    return 'n° ' + (ns[0] if len(ns) == 1 else ', '.join(ns[:-1]) + ' et ' + ns[-1])


LEFT = (('écart', 'écart de plus de 0,5 mm : à régler d’abord'),
        ('presque', 'un cran du 2e bord presque en face : à déplacer'),
        ('autant', 'autant de crans sur le 2e bord, pas tous en face : à déplacer'),
        ('sens', 'sens à choisir : « Crans en face » de la couture'),
        ('à refaire', 'à refaire'))


def crans_in_front_bag(app):
    """0.19.27 « Crans en face » for the whole bag (« pour tout le sac d'un seul clic »): each pair kept whose edges are
    the same length at the seam (ECART) gets on edge 2 the crans missing in front of edge 1's, as « Crans en face » puts
    them for one (each pair counting the crans put for the ones before it); one snapshot, one Annuler. Left alone, and
    said with their numbers and what to do (reviews: DIFORME's linings, 7,86 mm apart, got 7 crans more each): a pair to
    check again, an écart, a cran of edge 2 near where one goes (MISPLACED: to move, not one more beside it), edge 2 with
    as many crans as edge 1, a tie with crans on edge 2 when the two ways differ (which way: « Crans en face » of the
    pair). Edge 2 without a cran: the way pieces are sewn, said when the two ways differ; « Crans en face » of that pair
    then puts them the other way (_bag_placed). The number put."""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    pieces = _pieces(app, every=True)
    put, sewn, saved, marked = 0, [], False, False
    guessed, left, bagged = [], {}, {}
    for n, pair in enumerate(entries(app), 1):
        if 'etape' in pair or pair.get('more'):   # (0.19.36: edge 2 on several pieces: junctions by distance, no crans)
            continue
        found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
        if None in found or any(len(sides(app.items[k])[0]) != e['count'] or max(e['sides']) >= e['count']
                                for k, e in zip(found, (pair['a'], pair['b']))):
            left.setdefault('à refaire', []).append(n)
            continue
        st = dict(a=(found[0], e_sides(pair['a'])), b=(found[1], e_sides(pair['b'])))
        d = seam_of(app, pair.get('seam'), found, _st_sides(st))
        try:
            reach = reaches(app, d, found, [(k, portion(app, st[x])[0]) for k, x in zip(found, 'ab')], bool(pair.get('double')))
            shut = (closings(app, *st['a']), closings(app, *st['b']))   # 0.19.29: a tube's bottom
            shut = with_folds(shut, pair_folds(app, [st['a'], st['b']], reach, bool(pair.get('double'))))   # 0.19.35
            pa, _, la, _, ca = measured(app, st['a'], reach[0], shut[0])
            pb, _, lb, _, cb = measured(app, st['b'], reach[1], shut[1])
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            left.setdefault('à refaire', []).append(n)
            continue
        marked = marked or bool(ca)
        embu = embu_of(pair)   # 0.19.36
        same, other = facing_counts(ca, la, cb, lb, embu)
        if not ca or max(same, other) == len(ca):
            continue   # (nothing on edge 1, or each of its crans has one in front already)
        if abs(abs(la - lb) - embu) > ECART:
            left.setdefault('écart', []).append(n)
            continue
        # (second review) both ways the same places (a cran in the middle, at both ends…): no way to choose
        symmetric = all(abs(x - y) <= TOLERANCE for x, y in zip(sorted(ca), sorted(lb - x for x in ca)))

        def misplaced(back):
            """a cran of edge 2 near (not in front of) where one of edge 1's goes, that way round (review: never one in
            front of another one of edge 1's, as _new_crans)"""
            ys, free = [lb - x if back else x for x in ca], list(cb)
            for y in ys:
                hit = next((z for z in free if abs(y - z) <= TOLERANCE), None)
                if hit is not None:
                    free.remove(hit)
            return any(not any(abs(y - z) <= TOLERANCE for z in cb) and any(abs(y - z) < MISPLACED for z in free) for y in ys)
        tie = bool(cb) and same == other and not symmetric
        # (0.19.36 review: with an embu, the crans of edge 2 are where it eases: _new_crans says which are near, below)
        if not embu and (misplaced(other > same) or tie and misplaced(other <= same)):
            left.setdefault('presque', []).append(n)
            continue
        if tie:
            left.setdefault('sens', []).append(n)
            continue
        if len(cb) >= len(ca):
            left.setdefault('autant', []).append(n)
            continue
        made, back, _, _, near = _new_crans(app, st, dict(crans_a=ca, crans_b=cb, la=la, lb=lb, b=pb, seam=d, reach=tuple(reach), shut=shut,
                                                          embu=embu))
        if not made:
            if near:
                left.setdefault('presque', []).append(n)
            continue
        if not saved:
            try:
                app.snapshot()
            except Exception as exc:   # (read-only: licence_ui.LectureSeule)
                app.status.set(str(exc))
                return 0
            saved = True
        app.items.extend(made)
        put += len(made)
        sewn.append(n)
        if not cb and not symmetric:   # (the way pieces are sewn: to check; that pair's own « Crans en face »: the other way)
            guessed.append(n)
            bagged[(_frozen(st['a']), _frozen(st['b']))] = dict(ids=list(made), back=back)
    app._bag_placed = bagged
    said = ''
    if left:
        count = sum(len(v) for v in left.values())
        said = (' Laissée' if count == 1 else ' Laissées') + ' : ' + ' ; '.join(
            f'{_numbers(left[key])} ({text})' for key, text in LEFT if key in left) + '.'
    if not put:
        app.status.set(('Aucun cran ajouté.' if left else 'Chaque cran du 1er bord a déjà son cran en face.' if marked
                        else 'Aucun cran sur le 1er bord des coutures du sac : rien à mettre en face.') + said)
        return 0
    app.refresh()
    win = app.__dict__.get('_bag_window')
    if win is not None and win.winfo_exists():
        win._refill()
    check = app.__dict__.get('_assembly_window')   # (review: a check open shows the crans put)
    if check is not None and check.winfo_exists():
        if (app.__dict__.get('assembly_state') or {}).get('b'):
            draw(app)
        check._refill()
    one = put == 1
    app.status.set(f'{put} cran{"" if one else "s"} ajouté{"" if one else "s"} ({_numbers(sewn)} ; Annuler {"le" if one else "les"} retire).'
                   + (f' {"Couture" if len(guessed) == 1 else "Coutures"} {_numbers(guessed)} : 2e bord sans cran, crans mis dans le sens '
                      f'des pièces cousues, à vérifier sur le plan (« Crans en face » de la couture : l’autre sens).' if guessed else '')
                   + said)
    return put


def window(app):
    """The numbers of the check, kept up to date; the thickness and the points per cm can be typed."""
    from tkinter import messagebox
    old = app.__dict__.get('_assembly_window')
    if old is not None and old.winfo_exists():
        old._refill()
        return old
    win = app.dialog('Contrôle d’assemblage')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    app._assembly_window = win
    panel = app.p['panel']
    box = tk.Frame(win, bg=panel)
    box.pack(fill='x', padx=16, pady=(14, 4))
    labels = {}
    for row, (key, text) in enumerate((('a', 'Bord 1'), ('b', 'Bord 2'), ('diff', 'Écart'), ('crans', 'Crans en face'), ('n', 'Points'), ('thread', 'Fil (2 fils, sans marge)'))):
        app.label(box, text).grid(row=row, column=0, sticky='w', pady=2)
        labels[key] = tk.StringVar()
        tk.Label(box, textvariable=labels[key], bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 10, 'bold')).grid(row=row, column=1, sticky='w', padx=10)
    thick, points, seam = tk.StringVar(), tk.StringVar(), tk.StringVar()
    app.label(box, 'Épaisseur à la couture (mm)').grid(row=6, column=0, sticky='w', pady=2)
    app.entry(box, thick, 7).grid(row=6, column=1, sticky='w', padx=10)
    app.label(box, 'Points par cm').grid(row=7, column=0, sticky='w', pady=2)
    app.entry(box, points, 7).grid(row=7, column=1, sticky='w', padx=10)
    app.label(box, 'Couture (mm du bord)').grid(row=8, column=0, sticky='w', pady=2)   # 0.19.26: measured there
    seam_row = tk.Frame(box, bg=panel)
    seam_row.grid(row=8, column=1, sticky='w', padx=10)
    seam_entry = app.entry(seam_row, seam, 7)
    seam_entry.pack(side='left')
    embu = tk.StringVar()   # 0.19.36: « l'embu par couture » (the écart the seam is meant to have)
    app.label(box, 'Embu (mm)').grid(row=9, column=0, sticky='w', pady=2)
    embu_entry = app.entry(box, embu, 7)
    embu_entry.grid(row=9, column=1, sticky='w', padx=10)
    jonc = tk.BooleanVar()
    note = tk.StringVar()
    tk.Label(win, textvariable=note, bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 9), justify='left', wraplength=330).pack(fill='x', padx=16)
    extras = tk.Frame(win, bg=panel)   # 0.19.14: the rembord's way, the renforts and doublures to add
    extras.pack(fill='x', padx=16)
    ticks = {}
    double = tk.BooleanVar(value=bool(app.assembly_state.get('double')))
    check = dict(bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), selectcolor=app.field_background(), activebackground=panel, font=('Segoe UI', 9))

    def joncs():
        """0.19.26: a jonc: the seam at 5 mm (kept with the pair); unticked: 2,5 mm again; 0.19.36: a seam with a jonc by
        itself (with_jonc): unticked, the usual seam kept as its own"""
        st = app.assembly_state
        ks = (st['a'][0], st['b'][0]) if st.get('a') and st.get('b') else None
        auto = with_jonc(app, ks, _st_sides(st) if ks else None)
        st['seam'] = (None if auto else JONC) if jonc.get() else (plain_seam(app, ks) if auto else None)
        st.pop('retourne', None)   # (0.19.29: a jonc, or the usual seam: no longer a piqué retourné of its own)
        if not jonc.get() and auto and abs(st['seam'] - JONC) < 1e-9 and piqure(app) == 'retourne':
            st['retourne'] = True   # (review: unticked in a model piqué retourné: its 5 mm a piqué retourné, never a jonc again)
        st.pop('placed', None)   # (second review: then « Crans en face »: at that seam, never the other way)
        remember(app)
        refill()
        prompt(app)
        draw(app)
    __import__('modern_style').make_check(seam_row, text=f'jonc ({_mm(JONC)} mm)', variable=jonc, command=joncs, **check).pack(side='left', padx=8)

    def changed():
        st = app.assembly_state
        moved = bool(st.get('double')) != double.get()
        st['double'] = double.get()
        st['layers'] = {j for j, v in ticks.items() if v.get()}
        st['thickness'] = None   # the thickness computed again
        if moved:   # 0.19.29: the rembord's fold moves where the edge is measured: kept with the pair, drawn again
            remember(app)
            draw(app)
        refill()
        prompt(app)

    def build_extras(r):
        for w in extras.winfo_children():
            w.destroy()
        make = __import__('modern_style').make_check
        if r['rembord']:
            make(extras, text='Rembord paré sur 2 × sa largeur (sinon : rabat paré plié sur le cuir)', variable=double, command=changed, **check).pack(anchor='w')
        chosen = app.assembly_state.get('layers') or set()
        for j, name, t in r['layers']:
            v = ticks.setdefault(j, tk.BooleanVar(value=j in chosen))
            make(extras, text=f'+ {name} ({_mm(t, 2) + " mm" if t is not None else "1 mm compté"})', variable=v, command=changed, **check).pack(anchor='w')

    def refill():
        r = result(app)
        if r is None:
            for v in labels.values():
                v.set('—')
            return
        labels['a'].set(f'{_mm(r["la"])} mm')
        labels['b'].set(f'{_mm(r["lb"])} mm')
        labels['diff'].set(f'{_mm(abs(r["diff"]))} mm' + (' ✓' if within(r) else (' : bord 1 plus long' if r['diff'] > 0 else ' : bord 2 plus long'))
                           + (f' ({embu_words(r["embu"])})' if r.get('embu') else ''))   # 0.19.36: its embu
        labels['crans'].set(f'{r["front"]} (bord 1 : {r["ca"]}, bord 2 : {r["cb"]})' + (' · sens inverse' if r['reversed'] else ''))
        price, speed, hourly = sewing_prefs(app)   # 0.19.27: its thread and its time in the model's cost
        minutes = max(r['la'], r['lb']) / 10 / speed if speed else None
        labels['n'].set(f'{r["n"]} ({_mm(r["points"], 2)} par cm)'
                        + (f' · ≈ {_mm(minutes, 1)} min' if minutes is not None else '')
                        + (f' · {euros(minutes / 60 * hourly)}' if minutes is not None and hourly else ''))
        labels['thread'].set(f'≈ {_mm(r["thread"] / 10, 0)} cm' + (f' · {euros(r["thread"] / 1000 * price)}' if price else ''))
        thick.set(_mm(r['thickness'], 2))
        points.set(_mm(r['points'], 2))
        embu.set(_mm(r.get('embu', 0.), 2))
        double.set(bool(app.assembly_state.get('double')))   # (0.19.29: a pair kept reached again: its own)
        seam.set(_mm(r['seam'], 2))
        own = app.assembly_state.get('seam')   # (0.19.28: a jonc is the pair's own 5 mm, never the 5 mm of fabric)
        st = app.assembly_state
        jonc.set(is_jonc(st) or st.get('seam') is None and r.get('seam_kind') == 'jonc')   # (0.19.36: by itself too)
        missing = [n for n, known in zip(('1', '2'), r['known']) if not known]
        made = [m + (f', {w}' if w else '') for m, w in zip(r['made'], (folded_words(f) for f in r.get('folds') or ((0., 0.), (0., 0.))))]
        if r.get('lbs'):   # 0.19.36: edge 2 on several pieces
            made[1] += f' ; {len(r["lbs"])} pièces ({" + ".join(_mm(x) for x in r["lbs"])} mm), {junction_words(r)}'
        note.set(f'Bord 1 : {made[0]} · bord 2 : {made[1]}.'
                 + (' 1 mm compté pour le cuir de la pièce ' + ' et '.join(missing) + ' (pas de refente dans sa matière).' if missing else '')
                 + ('' if r['layers'] else ' Renforts et doublures : à ajouter à l’épaisseur.'))
        key = (r['rembord'], tuple(j for j, _, _ in r['layers']))
        if win.__dict__.get('_extras_key') != key:
            win._extras_key = key
            build_extras(r)

    def typed(e=None):
        st = app.assembly_state
        try:
            from command_catalog import length_field   # 0.19.42: « 5 cm » too
            t = length_field(thick.get())
            p = float(points.get().replace(',', '.'))
            d = length_field(seam.get())
            m = length_field(embu.get()) if embu.get().strip() else 0.
            if not 0 < t <= 50 or not .5 <= p <= 20 or not 0 <= d <= 30 or not 0 <= m <= EMBU_MOST:
                raise ValueError
        except ValueError:
            messagebox.showerror('Contrôle d’assemblage', 'Épaisseur : 0 à 50 mm ; points par cm : 0,5 à 20 ; couture : 0 à 30 mm du bord ; '
                                 f'embu : 0 à {_mm(EMBU_MOST)} mm.', parent=win)
            return 'break' if e is not None else False   # 0.19.22: (the button: nothing written)
        typed_points = abs(p - points_of(st.get('points'))) > 1e-9 or abs(m - embu_of(st)) > 1e-9   # (0.19.36: an embu kept too)
        st['thickness'], st['points'], st['embu'] = t, p, m
        before = st.get('seam')
        ks = (st['a'][0], st['b'][0]) if st.get('a') and st.get('b') else None
        sides = _st_sides(st) if ks else None
        if seam.get().strip() != _mm(seam_of(app, before, ks, sides), 2):   # (review: as shown, rounded: kept as it was)
            st['seam'] = None if abs(d - usual_seam(app, ks, sides)) < 1e-9 else d   # 0.19.26 (2,5 mm: nothing kept; 0.19.28: 5 in fabric)
            st.pop('retourne', None)   # (0.19.29: typed: its own seam)
        if st['seam'] != before:
            st.pop('placed', None)
            remember(app)
            draw(app)
        elif typed_points:
            remember(app)   # 0.19.29: the points per cm typed kept with the pair
        refill()
        prompt(app)
        return 'break' if e is not None else True
    for w in box.winfo_children() + [seam_entry, embu_entry]:
        if isinstance(w, tk.Entry):
            w.bind('<Return>', typed)
            w.bind('<FocusOut>', lambda e: None)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(8, 14))
    app.button(foot, 'Écrire sur le plan', lambda: typed() and write(app)).pack(side='left')
    app.button(foot, 'Crans en face', lambda: typed() and crans_in_front(app), kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.26
    app.button(foot, 'Ajuster', lambda: typed() and adjust(app), kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.29
    app.button(foot, 'Tout le sac…', lambda: bag(app), kind='secondary').pack(side='left', padx=6)   # 0.19.24
    app.button(foot, 'Fermer', win.destroy).pack(side='right')
    win._refill = refill
    win._seam, win._jonc, win._joncs, win._typed, win._embu = seam, jonc, joncs, typed, embu   # (essais)
    refill()
    return win


# --- 0.19.24 the whole bag: every check done, kept with the model, checked again at once ----------------------------------

KEY = 'assemblages'
GOOD, BAD, WARN, GREY = '#34c759', '#ff3b30', '#ff9500', '#8e8e93'
ECART = .5   # mm: over it, the pair is in red (the check's ✓ above)


def piece_key(app, k):
    """What names piece ``k`` in a pair kept: its piece_id (given if it has none); a piece surcoupée: its précoupe's."""
    s = app.items[k]
    if s.get('piece_id'):
        return s['piece_id']
    import surcoupe
    from craft_tools import style
    if s.get('owner_id') and style(s)['role'] == surcoupe.ROLE:
        return 'dans:' + s['owner_id']   # (its copies in the précoupe are the same piece)
    from entity_rules import ensure_piece_id
    before = dict(s)
    key = ensure_piece_id(s)
    # (review) the same piece in the drawings Annuler / Rétablir bring back gets the same id: a change undone that did
    # not touch it never makes its pair « introuvable »
    for state in list(app.__dict__.get('undo_stack') or ()) + list(app.__dict__.get('redo_stack') or ()):
        for q in (state.get('items') or ()) if isinstance(state, dict) else ():
            if isinstance(q, dict) and not q.get('piece_id') and q == before:
                q['piece_id'] = key
    return key


def piece_index(app, key, pieces=None):
    """The piece named ``key`` (piece_key), or None when it is gone."""
    pieces = _pieces(app, every=True) if pieces is None else pieces
    if key.startswith('ici:'):   # 0.19.29 (peek_edge)
        try:
            k = int(key[4:])
        except ValueError:
            return None
        return k if k in pieces and not app.items[k].get('piece_id') else None
    if key.startswith('dans:'):
        owner = key[5:]
        return next((k for k in pieces if not app.items[k].get('piece_id') and app.items[k].get('owner_id') == owner), None)
    return next((k for k in pieces if app.items[k].get('piece_id') == key), None)


def edge_of(app, chosen):
    k, ids = chosen
    return dict(piece=piece_key(app, k), sides=sorted(set(ids)), count=len(sides(app.items[k])[0]))


def _ident(pair):
    """The same two edges, in either order (0.19.36: edge 2's next pieces in their order after them)."""
    head = tuple(sorted((e['piece'], tuple(e['sides'])) for e in (pair['a'], pair['b'])))
    more = pair.get('more') or ()
    return head + tuple((e['piece'], tuple(e['sides'])) for e in more) if more else head


def entries(app):
    """0.19.26: the bag's list in the order of montage: the pairs kept (dict a, b; seam: a jonc's) and the steps between
    them (dict etape: its text), copies."""
    out = []
    for e in (app.__dict__.get('infos') or {}).get(KEY) or []:
        if 'etape' in e:
            out.append(dict(etape=e['etape'], **({'minutes': e['minutes']} if e.get('minutes') else {})))   # (0.19.28: its time)
        else:
            pair = dict(a=dict(e['a']), b=dict(e['b']))
            if e.get('more'):
                pair['more'] = [dict(x) for x in e['more']]   # 0.19.36: edge 2's next pieces
            if e.get('seam') is not None:
                pair['seam'] = e['seam']
            for key in ('points', 'double', 'retourne', 'embu'):   # 0.19.29: typed in the check; a fond sewn piqué retourné
                if e.get(key) is not None:
                    pair[key] = e[key]
            out.append(pair)
    return out


def kept_pairs(app):
    return [e for e in entries(app) if 'a' in e]


def _store(app, rows):
    """The bag's list (pairs and steps) in the Infos du modèle (a new dict: the « * » of the tab compares it with the one
    saved)."""
    infos = dict(app.__dict__.get('infos') or {})
    if rows:
        infos[KEY] = rows
    else:
        infos.pop(KEY, None)
    app.infos = infos or None
    for name in ('update_window_title', 'rebuild_tabs'):
        if hasattr(app, name):
            getattr(app, name)()


def remember(app):
    """The check shown kept with the model: the same edges once; while a check goes on (a side added, the second edge
    taken again), the pair it added follows it."""
    st = app.__dict__.get('assembly_state') or {}
    if not st.get('a') or not st.get('b'):
        return
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        return   # (read-only: the check is shown, nothing is kept)
    pair = dict(a=edge_of(app, st['a']), b=edge_of(app, st['b']))
    pairs = entries(app)   # (0.19.26: the steps between them stay where they are)
    if st.get('more'):
        pair['more'] = [edge_of(app, part) for part in st['more']]   # 0.19.36: edge 2's next pieces (fond mexicain)
    reached = False
    if not st.get('more'):   # 0.19.36 (review): the first two edges of a fond mexicain kept: that chain, its next pieces found
        chained = _chain_of(app, pairs, pair)   # again (never the chain this check follows, its pieces just taken out by Ctrl + clic)
        if chained and chained[1] != st.get('kept'):
            st['more'] = chained[0]
            pair['more'] = [edge_of(app, part) for part in chained[0]]
            reached = True
    _hold(app, st, pair['a'], pair['b'], pair.get('more'))
    new = _ident(pair)
    old = st.get('kept')
    idents = [_ident(p) if 'a' in p else None for p in pairs]
    if new != old and new in idents:   # (review) a check reaching a pair kept: its seam (a jonc) with it
        st['seam'] = pairs[idents.index(new)].get('seam')
        st['points'] = pairs[idents.index(new)].get('points')   # (0.19.29: its points per cm, its rembord pared twice too)
        st['double'] = bool(pairs[idents.index(new)].get('double'))
        st['retourne'] = bool(pairs[idents.index(new)].get('retourne'))
        st['embu'] = embu_of(pairs[idents.index(new)])
    if st.get('seam') is not None:
        pair['seam'] = st['seam']   # 0.19.26: a jonc's
        if st.get('retourne'):
            pair['retourne'] = True   # 0.19.29: its 5 mm is a piqué retourné (a fond rapporté)
    if st.get('points') is not None and abs(points_of(st['points']) - POINTS) > 1e-9:
        pair['points'] = points_of(st['points'])   # 0.19.29: typed in the check (3 per cm: nothing kept)
    if st.get('double'):
        pair['double'] = True   # 0.19.29: « Rembord paré sur 2 × sa largeur » (its fold measured from half the zone)
    if embu_of(st):
        pair['embu'] = embu_of(st)   # 0.19.36: the écart it is meant to have
    if old is not None and old != new and st.get('added') and old in idents:   # the pair of this check follows its edges
        at = idents.index(old)
        if new in idents:   # now the same as another one kept: that one, its sides counted again
            del pairs[at]
            idents.pop(at)
            pairs[idents.index(new)] = pair
            added = False
        else:
            pairs[at] = pair
            added = True
    elif new in idents:
        at = idents.index(new)
        if pairs[at] == pair and old == new:
            return
        pairs[at] = pair   # (review) checked again: its sides counted again (« côtés changés » goes)
        added = st.get('added') if old == new else False
    else:
        pairs.append(pair)
        added = True
    st.update(kept=new, added=added or reached)   # (0.19.36 review: a chain reached is followed, as one opened from the bag)
    _store(app, pairs)
    win = app.__dict__.get('_bag_window')
    if win is not None and win.winfo_exists():
        win._refill()


def _chain_of(app, pairs, pair):
    """0.19.36 (review: a check never reached a fond mexicain kept): (the next pieces [(k, sides)], its ident) of the chain
    kept whose edge 1 and edge 2 are ``pair``'s, in that order, each found again with as many sides as then; None"""
    same = lambda x, y: x['piece'] == y['piece'] and sorted(x['sides']) == sorted(y['sides'])
    for p in pairs:
        if 'a' not in p or not p.get('more') or not same(p['a'], pair['a']) or not same(p['b'], pair['b']):
            continue
        pieces = _pieces(app, every=True)
        out = []
        for x in p['more']:
            k = piece_index(app, x['piece'], pieces)
            try:
                if k is None or len(sides(app.items[k])[0]) != x['count'] or max(x['sides']) >= x['count']:
                    return None
            except (IndexError, KeyError, TypeError, ValueError, ZeroDivisionError):
                return None
            out.append((k, e_sides(x)))
        return out, _ident(p)
    return None


def _side_text(app, k, ids):
    name = _name(host(app, k)) or 'Pièce'
    return name + (f' · {len(ids)} côtés' if len(ids) > 1 else '')


def check(app, pair, pieces=None):
    """The pair kept checked again: dict(state 'ok' / 'bad' (écart) / 'crans' / 'gone' / 'changed', its texts, the edges'
    points)."""
    pieces = _pieces(app, every=True) if pieces is None else pieces
    if pair.get('more'):
        return _chain_check(app, pair, pieces)
    found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
    seam, kind = seam_info(app, pair.get('seam'), found, pair.get('retourne'),
                           (e_sides(pair['a']), e_sides(pair['b'])))   # (0.19.28: 5 mm between two pieces in fabric; 0.19.36: jonc)
    out = dict(a_text=pair['a']['piece'][:8], b_text=pair['b']['piece'][:8], lengths='', diff='', crans='', a=None, b=None,
               seam=seam, seam_kind=kind, points=points_of(pair.get('points')))
    for key, k, e in zip(('a_text', 'b_text'), found, (pair['a'], pair['b'])):
        if k is not None:
            out[key] = _side_text(app, k, e['sides'])
    def shown(k, e):
        """(grey on the plan) the edge as it is when its sides are still there, else the whole contour"""
        if k is None:
            return None
        try:
            if max(e['sides']) < len(sides(app.items[k])[0]):
                return portion(app, (k, e_sides(e)))[0]
            pts, closed = __import__('geometry').path(app.items[k])
            return pts + pts[:1] if closed else pts
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            return None
    if None in found:
        return dict(out, state='gone', text='— pièce introuvable', a=shown(found[0], pair['a']), b=shown(found[1], pair['b']))
    for k, e in zip(found, (pair['a'], pair['b'])):
        if len(sides(app.items[k])[0]) != e['count'] or max(e['sides']) >= e['count']:
            return dict(out, state='changed', text='— côtés changés : refaire ce contrôle', a=shown(found[0], pair['a']), b=shown(found[1], pair['b']))
    try:   # (0.19.26: at the seam; 0.19.29: each edge at its own distance: the cut for fabric, the fold of a rembord)
        chosen = [(k, e_sides(e)) for k, e in zip(found, (pair['a'], pair['b']))]
        reach = reaches(app, seam, found, [(k, portion(app, c)[0]) for k, c in zip(found, chosen)], bool(pair.get('double')))
        shut = [closings(app, k, c[1]) for k, c in zip(found, chosen)]   # 0.19.29: a tube's bottom
        shut = with_folds(shut, pair_folds(app, chosen, reach, bool(pair.get('double'))))   # 0.19.35: up to a rembord's fold
        pa, sa, la, ta, ca = measured(app, chosen[0], reach[0], shut[0])
        pb, sb, lb, tb, cb = measured(app, chosen[1], reach[1], shut[1])
        out['reach'] = tuple(reach)
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        return dict(out, state='changed', text='— côtés changés : refaire ce contrôle')
    embu = embu_of(pair)
    front, _ = facing(ca, la, cb, lb, embu)
    diff = abs(la - lb)
    out.update(a=pa, b=pb, la=la, lb=lb, lengths=f'{_mm(la)} / {_mm(lb)}', diff=_mm(diff, 2), crans=f'{front} sur {len(ca)} / {len(cb)}',
               front=front, embu=embu)
    said = f' ({embu_words(embu)})' if embu else ''   # 0.19.36: the écart it is meant to have
    if abs(diff - embu) > ECART:
        return dict(out, state='bad', text=f'✗ écart de {_mm(diff, 2)} mm{said}')
    if not front == len(ca) == len(cb):
        return dict(out, state='crans', text=f'⚠ crans : {front} en face sur {len(ca)} / {len(cb)}{said}')
    return dict(out, state='ok', text=f'✓ bon{said}')


def _chain_check(app, pair, pieces):
    """check for a pair whose edge 2 is on several pieces (0.19.36, fond mexicain): their lengths added, the junctions"""
    edges = [pair['a'], pair['b']] + list(pair['more'])
    found = [piece_index(app, e['piece'], pieces) for e in edges]
    texts = [_side_text(app, k, e['sides']) if k is not None else e['piece'][:8] for k, e in zip(found, edges)]
    seam, kind = seam_info(app, pair.get('seam'), (found[0], found[1]), pair.get('retourne'), (e_sides(pair['a']), e_sides(pair['b'])))
    out = dict(a_text=texts[0], b_text=' + '.join(texts[1:]), lengths='', diff='', crans='', a=None, b=None, seam=seam,
               seam_kind=kind, points=points_of(pair.get('points')))
    if None in found:
        return dict(out, state='gone', text='— pièce introuvable')
    for k, e in zip(found, edges):
        if len(sides(app.items[k])[0]) != e['count'] or max(e['sides']) >= e['count']:
            return dict(out, state='changed', text='— côtés changés : refaire ce contrôle')
    try:
        c = chain_numbers(app, (found[0], e_sides(pair['a'])), [(k, e_sides(e)) for k, e in zip(found[1:], edges[1:])],
                          pair.get('seam'), pair.get('retourne'), bool(pair.get('double')))
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        return dict(out, state='changed', text='— côtés changés : refaire ce contrôle')
    la, lb, ca, cb = c['la'], c['lb'], c['ca'], c['cb']
    embu = embu_of(pair)
    front, _ = facing(ca, la, cb, lb, embu)
    diff = abs(la - lb)
    out.update(a=c['pa'], b=c['pbs'][0], parts=c['pbs'], la=la, lb=lb, lengths=f'{_mm(la)} / {" + ".join(_mm(x) for x in c["lbs"])}',
               diff=_mm(diff, 2), crans=f'{front} sur {len(ca)} / {len(cb)}', front=front, embu=embu, junctions=c['junctions'],
               reach=c['reach'], lbs=c['lbs'])
    said = f' ({embu_words(embu)})' if embu else ''
    if abs(diff - embu) > ECART:
        return dict(out, state='bad', text=f'✗ écart de {_mm(diff, 2)} mm{said}')
    if not front == len(ca) == len(cb):
        return dict(out, state='crans', text=f'⚠ crans : {front} en face sur {len(ca)} / {len(cb)}{said}')
    return dict(out, state='ok', text=f'✓ bon{said}')


def cran_ticks(app, k, ids):
    """0.19.28 (« sur les dessins de la fiche Montage, les crans des deux bords »): each cran of the edge ``ids`` of piece
    ``k``, at the cut: [(its point, the unit normal into the piece)]."""
    from craft_tools import interior_side
    pts, start, length, total = portion(app, (k, ids))
    inside = interior_side(app.items[k])
    out = []
    for x in crans(app, k, start, length, total):
        travel = 0.
        for a, b in zip(pts, pts[1:]):
            L = math.dist(a, b)
            if L > 1e-9 and (travel + L >= x - 1e-9 or b is pts[-1]):
                t = min(1., max(0., (x - travel) / L))
                u = ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
                out.append(((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t), (-u[1] * inside, u[0] * inside)))
                break
            travel += L
    return out


def e_sides(edge):
    return list(edge['sides'])


def checks(app):
    pieces = _pieces(app, every=True)
    return [check(app, pair, pieces) for pair in kept_pairs(app)]


COLOUR = dict(ok=GOOD, bad=BAD, crans=WARN, gone=GREY, changed=GREY)


def _fingerprint(app):
    """What the checks depend on: the pieces of the pairs and their crans (marshal: quick), the pairs."""
    import marshal
    pairs = kept_pairs(app)
    names = {e['piece'] for p in pairs for e in [p['a'], p['b']] + list(p.get('more') or ())}   # (0.19.36 review: a chain's pieces)
    owners = {n[5:] if n.startswith('dans:') else n for n in names}
    parts = [s for s in app.items if s.get('piece_id') in owners or s.get('owner_id') in owners]
    # 0.19.35 (review): the rembord zones fold the pairs, also those without their piece (_bands)
    folds = [s for s in app.items if isinstance(s.get('preparation'), dict) and s['preparation'].get('kind') == 'parage'
             and 'REMBORD' in str(s['preparation'].get('type') or '').upper()]
    try:
        return marshal.dumps((pairs, parts, folds), 2)
    except ValueError:
        return None


def draw_bag(app):
    """The edges of the pairs kept on the plan (tag assembly_bag), in the colour of their state; the pair chosen in the
    list wider, in the check's two colours. Checked again when the pieces or their crans changed."""
    marks = app.__dict__.get('_bag_marks')
    c = app.canvas
    c.delete('assembly_bag')
    if not marks:
        return
    win = app.__dict__.get('_bag_window')
    if win is None or not win.winfo_exists():
        clear_bag(app)   # (its window gone another way)
        return
    if hasattr(app, 'plan_active') and not app.plan_active():
        return   # a fiche shown: nothing over it
    key = _fingerprint(app)
    if key is not None and key != marks.get('key'):
        return win._refill()   # the list and the plan checked again (it draws them)
    chosen = marks.get('chosen')
    for pts, pick in zip(marks.get('proposal') or (), (COLORS[0],) + (COLORS[1],) * 8):   # 0.19.25: the probable pair picked in its list
        if pts and len(pts) > 1:
            c.create_line(*[v for p in pts for v in app.to_screen(p)], fill=pick, width=6, capstyle='round', dash=(8, 4), tags=('assembly_bag',))
    for n, row in enumerate(marks['rows']):
        more = [('part', pts) for pts in (row.get('parts') or ())[1:]]   # 0.19.36: edge 2's next pieces
        for edge, pick in [('a', COLORS[0]), ('b', COLORS[1])] + [(x, COLORS[1]) for x in more]:
            pts = row.get(edge) if isinstance(edge, str) else edge[1]
            if not pts or len(pts) < 2:
                continue
            xy = [v for p in pts for v in app.to_screen(p)]
            if n == chosen:
                c.create_line(*xy, fill=pick, width=6, capstyle='round', tags=('assembly_bag',))
            c.create_line(*xy, fill=COLOUR[row['state']], width=3 if n != chosen else 2, capstyle='round', tags=('assembly_bag',))
            if row.get('n'):   # 0.19.26: its number in the order of montage, by the middle of each edge
                x, y = app.to_screen(_middle(pts))
                c.create_oval(x - 9, y - 9, x + 9, y + 9, fill=app.p.get('panel', '#2b2f33'), outline=COLOUR[row['state']], width=2, tags=('assembly_bag',))
                c.create_text(x, y, text=str(row['n']), fill=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 9, 'bold'), tags=('assembly_bag',))
    c.tag_raise('assembly_bag')


def _middle(pts):
    """The point half way along a line."""
    half = sum(math.dist(a, b) for a, b in zip(pts, pts[1:])) / 2
    for a, b in zip(pts, pts[1:]):
        L = math.dist(a, b)
        if L >= half and L > 0:
            t = half / L
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        half -= L
    return pts[-1]


def clear_bag(app):
    app.__dict__.pop('_bag_marks', None)
    try:
        app.canvas.delete('assembly_bag')
    except tk.TclError:
        pass


def open_pair(app, pair):
    """The check of a pair kept, in the tool (its window: the thickness, the points and the thread)."""
    pieces = _pieces(app, every=True)
    found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
    if None in found:
        return False
    for k, e in zip(found, (pair['a'], pair['b'])):
        if len(sides(app.items[k])[0]) != e['count'] or max(e['sides']) >= e['count']:
            return False   # (review: its sides changed: an IndexError at each move of the mouse)
    more = []
    for x in pair.get('more') or ():   # 0.19.36: edge 2's next pieces
        k = piece_index(app, x['piece'], pieces)
        if k is None or len(sides(app.items[k])[0]) != x['count'] or max(x['sides']) >= x['count']:
            return False
        more.append((k, e_sides(x)))
    start(app)
    st = app.assembly_state
    # (review) corrected here (Maj + clic), the pair follows: never a second one beside it
    st.update(a=(found[0], e_sides(pair['a'])), b=(found[1], e_sides(pair['b'])), kept=_ident(pair), added=True, seam=pair.get('seam'),
              points=pair.get('points'), double=bool(pair.get('double')), retourne=bool(pair.get('retourne')),
              embu=embu_of(pair))   # (0.19.29 review; 0.19.36: its embu)
    st['more'] = more
    _hold(app, st, pair['a'], pair['b'], pair.get('more'))
    prompt(app)
    draw(app)
    window(app)
    return True


# --- 0.19.25 the fiche « Assemblages » (fiches.py): the pairs kept with their numbers, points and thread -------------------

WORDS = dict(ok='bon', bad='écart', crans='crans', gone='à refaire', changed='à refaire')


def fiche_rows(app):
    """The fiche « Montage » (0.19.25 « Assemblages »), in the list's order of montage: the pairs kept [dict(a, b: the
    edges (ID unique, name, sides), seam, lengths (at the seam), diff, crans, state, word, thickness, n, thread (mm), la,
    lb)] and the steps between them [dict(etape: its text)]. Thickness, points and thread as the check counts them before
    anything is typed: the refentes and parages of both edges (1 mm for a leather without refente), 3 points per cm
    (0.19.29: or the pair's own, typed in the check; never the Piqûre's pitch); a pair to check again: its numbers left
    out. 0.19.27: drawing (each piece's outline and its edge), minutes (at the speed of Réglages, when given)."""
    import piece_ids
    pieces = _pieces(app, every=True)
    speed = sewing_prefs(app)[1]
    out = []
    for pair in entries(app):
        if 'etape' in pair:
            out.append(dict(etape=pair['etape'], state='etape', minutes=pair.get('minutes')))   # (0.19.28: its minutes)
            continue
        r = check(app, pair, pieces)
        found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
        more = [piece_index(app, e['piece'], pieces) for e in pair.get('more') or ()]   # 0.19.36: edge 2's next pieces
        points = points_of(pair.get('points'))
        # (0.19.40 review: its embu beside its écart, « 8,03 (embu 8) »: the fiche said « bon » under 8,03 mm, its legend « écart »
        # over 0,5 mm)
        diff = r['diff'] + (f' (embu {_mm(r["embu"])})' if r['diff'] and r.get('embu') else '')
        row = dict(a=r['a_text'], b=r['b_text'], lengths=r['lengths'], diff=diff, crans=r['crans'], state=r['state'],
                   word=WORDS[r['state']], thickness=None, n=None, thread=None, points=points, la=r.get('la'), lb=r.get('lb'),
                   seam=r['seam'], seam_kind=r.get('seam_kind'))
        for key, k in zip(('a', 'b'), found):
            number = piece_ids.number_of(app.items, k) if k is not None else None
            if number:
                row[key] = f'{number} · {row[key]}'
        if pair.get('more'):   # 0.19.36 (review): each piece of edge 2 with its own number
            named = []
            for k, e in zip([found[1]] + more, [pair['b']] + list(pair['more'])):
                text = _side_text(app, k, e['sides']) if k is not None else e['piece'][:8]
                number = piece_ids.number_of(app.items, k) if k is not None else None
                named.append(f'{number} · {text}' if number else text)
            row['b'] = ' + '.join(named)
        if None not in found and r.get('a') and r.get('b') and r['state'] in ('ok', 'bad', 'crans'):   # 0.19.27: its drawing (the pieces, the edges sewn; review: never a pair to check again, its old sides on the new contour)
            try:
                ks = found + more
                edges = [r['a']] + list(r.get('parts') or [r['b']])
                row['drawing'] = [(__import__('geometry').path(app.items[k]), list(edge), cran_ticks(app, k, e_sides(e)))   # (the piece sewn,
                                  for k, edge, e in zip(ks, edges, [pair['a'], pair['b']] + list(pair.get('more') or ()))]   # in a précoupe too; 0.19.28: its crans)
                if None in ks:
                    row.pop('drawing', None)
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                row.pop('drawing', None)
        if r['state'] in ('ok', 'bad', 'crans'):
            try:
                twice = bool(pair.get('double'))   # (0.19.29: as the check counts it)
                thick = edge_thickness(app, found[0], r['a'], twice)[0] + edge_thickness(app, found[1], r['b'], twice)[0]
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                thick = None
            if thick is not None:
                n, fil = thread(max(r['la'], r['lb']), points, thick)
                row.update(thickness=thick, n=n, thread=fil)
                if speed:   # 0.19.27: its time at the machine
                    row['minutes'] = max(r['la'], r['lb']) / 10 / speed
        out.append(row)
    return out


# --- 0.19.27 the thread and the time of the seams in the model's cost (« Le fil et le temps de piqûre de chaque couture
# dans le coût du modèle ») ------------------------------------------------------------------------------------------------

SLOWEST = .1   # cm/min: a slower speed is none (review: 1e-310 made the minutes infinite, the fiches failed)


def sewing_prefs(app):
    """(price of the thread in €/m, speed of the seam in cm/min, cost of an hour in €/h) of Réglages › Outils: 0 when
    not given (nothing counted, like a material without a price)."""
    prefs = app.__dict__.get('prefs') or {}

    def value(key, least=0.):
        v = prefs.get(key)
        return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and v > least else 0.
    return value('thread_price'), value('sewing_speed', SLOWEST), value('hourly_cost')


def sewing(app, rows=None):
    """The thread and the time of the bag's seams (fiche_rows: the pairs whose numbers are known; a pair to check again
    is not counted): dict(seams, left (pairs not counted), thread (mm), length (mm, the longer edge of each), price,
    thread_cost (€ or None), minutes (None without a speed), hourly, time_cost (€ or None)). 0.19.28: step_minutes (the
    steps' minutes typed), total (the seams' and the steps' minutes, None when neither is known); time_cost on the total."""
    price, speed, hourly = sewing_prefs(app)
    rows = fiche_rows(app) if rows is None else rows
    pairs = [r for r in rows if 'etape' not in r]
    counted = [r for r in pairs if r.get('thread') is not None]
    fil = sum(r['thread'] for r in counted)
    length = sum(max(r['la'], r['lb']) for r in counted)
    minutes = length / 10 / speed if speed and counted else None
    steps = sum(r['minutes'] for r in rows if 'etape' in r and r.get('minutes'))   # 0.19.28: the steps' minutes typed
    total = (minutes or 0.) + steps if minutes is not None or steps else None
    return dict(seams=len(counted), left=len(pairs) - len(counted), thread=fil, length=length, price=price,
                thread_cost=fil / 1000 * price if price and counted else None, minutes=minutes, speed=speed, hourly=hourly,
                step_minutes=steps, total=total, time_cost=total / 60 * hourly if total is not None and hourly else None)


def euros(v):
    return f'{v:.2f}'.replace('.', ',') + ' €'


# --- 0.19.25 the pairs proposed (« Go tes propositions »: « Craft te propose les paires d'assemblage probables (même
# longueur, crans en face), tu n'as qu'à cocher ») ------------------------------------------------------------------------

NEAR = 3.          # mm: the lengths of a probable pair at most this far apart, or SPREAD of the longer
SPREAD = .03       # (the edges are measured at the cut: round corners make them a little longer than at the seam)
SHORTEST = 10.     # mm: a shorter edge is never proposed
LONGEST_RUN = 12   # sides in a row at most in one edge
MOST = 60          # proposals shown at most


def _known_key(app, k, here=False):
    """The name of piece ``k`` in the pairs kept, when it has one (nothing given: proposing changes nothing). 0.19.29
    ``here``: else « ici:k » (a list only looked at, the Montage auto's: piece_index finds it while the drawing is the same)."""
    s = app.items[k]
    if s.get('piece_id'):
        return s['piece_id']
    import surcoupe
    from craft_tools import style
    if s.get('owner_id') and style(s)['role'] == surcoupe.ROLE:
        return 'dans:' + s['owner_id']
    return f'ici:{k}' if here else None


def peek_edge(app, chosen):
    """0.19.29 (review: opening the Montage auto gave ids to the pieces: the model « modifié », even read-only): an edge as
    edge_of says it, its piece never given an id."""
    k, ids = chosen
    return dict(piece=_known_key(app, k, True), sides=sorted(set(ids)), count=len(sides(app.items[k])[0]))


def _cran_spots(app, k, total):
    """The crans of piece ``k``: their distances along its contour, from its start."""
    from geometry import geometry_key
    piece = app.items[k]
    owner = piece.get('piece_id') or piece.get('owner_id')
    if not owner:
        return []
    out = []
    piece_key = None
    for s in app.items:
        if s.get('is_notch') and s.get('owner_id') == owner:
            if piece_key is None:
                piece_key = geometry_key(piece)
            at = _cran_distance(s, piece, piece_key)
            if at is not None:
                out.append(at % total if total else 0.)
    return sorted(out)


def _alike(a, la, b, lb):
    """The crans ``a`` (along an edge ``la`` long) in front of the crans ``b`` once ``b`` is brought to that length, either
    way (3 mm or 1 % apart at most): round corners drift crans measured at the cut."""
    tol = max(3., .01 * la)
    k = la / lb if lb else 1.

    def count(bs):
        left, n = sorted(bs), 0
        for x in a:
            hit = next((y for y in left if abs(x - y) <= tol), None)
            if hit is not None:
                left.remove(hit)
                n += 1
        return n
    return max(count([y * k for y in b]), count([(lb - y) * k for y in b]))


def _bends(pts, reach):
    """How much a line's seam can differ from it, per mm of the seam's distance (``reach`` mm at most): 2 tan(turn / 2)
    at each of its corners, the turns near enough to meet at that distance counted as one corner (review: a round
    smaller than the seam loses as a sharp corner, more than its angle), a corner counted 170° at most."""
    cap = math.radians(170)
    turns = []   # (the turn at a point inside the line, the length to the next point)
    for a, b, c in zip(pts, pts[1:], pts[2:]):
        u, v = (b[0] - a[0], b[1] - a[1]), (c[0] - b[0], c[1] - b[1])
        cross, dot = u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1]
        turns.append((abs(math.atan2(cross, dot)) if cross or dot < 0 else 0., math.dist(b, c)))
    total, corner = 0., 0.
    for k, (turn, after) in enumerate(turns):
        corner += turn
        following = turns[k + 1][0] if k + 1 < len(turns) else None
        if following is not None and after < reach * (math.tan(min(corner, cap) / 2) + math.tan(min(following, cap) / 2)):
            continue   # (the part after it vanishes at that distance: one corner with the next)
        total += 2 * math.tan(min(corner, cap) / 2)
        corner = 0.
    return total


FRONT_WORDS = ('FACE', 'DEVANT', 'AVANT')   # 0.19.29: the piece that takes a band's edge the way it is sewn (the other, turned)


def quantity(app, k):
    """0.19.29: how many times piece ``k`` is cut (its matière's number: « 2 TOILE POLYESTER »), 1 when unknown."""
    try:
        s = host(app, k)
        i = next(j for j, q in enumerate(app.items) if q is s)
        return max(1, int(__import__('fiches')._material(app.items, i)[1]))
    except (StopIteration, ValueError, KeyError, TypeError, IndexError, AttributeError):
        return 1


def _overlap(a, b):
    return bool(set(a) & set(b))


GLUED_WORDS = ('RENFORT', 'RFT', 'AIDE', 'GAB', 'GABARIT')   # 0.19.29: pieces glued or used as templates, never sewn


def sewn_piece(app, k):
    """0.19.29: piece ``k`` may be sewn in a pair: not a renfort, an aide or a gabarit (by its name, its Mozart matière
    « I- », its matière's type in the archives, or its column of the base: Renforts, Aides)."""
    import materials
    from geometry import bounds
    s = host(app, k)
    if _name(s).startswith(GLUED_WORDS):
        return False
    data = (s.get('piece_info') or {}).get('material') or {}
    if str((data.get('mozart') or {}).get('MATERIALE') or '').strip().upper().startswith('I-'):
        return False
    name = str((data.get('values') or [''])[0] or '').strip()
    archives = app.__dict__.get('archives') or {}
    if name and (archives.get('material_info') or {}).get(name) and materials.info(archives, name)['type'] in ('Renfort', 'Gabarit'):
        return False
    workspace = app.__dict__.get('workspace')
    if workspace:
        try:
            x, y, X, Y = bounds([app.items[k]])
            if materials.column_at(workspace, (x + X) / 2) in (4, 5):
                return False
        except (ValueError, KeyError, TypeError, IndexError):
            pass
    return True


NOCRAN_NEAR = 1.5     # mm: 0.19.29 two edges without crans: only their lengths tell (so this close)
NOCRAN_SPREAD = .005  # (or 0,5 % of their length)
NOCRAN_SHORTEST = 50.  # mm: a side without crans shorter than this is never proposed (the ends of a strap…)
NOCRAN_PARTNERS = 8    # (review: 80 pieces of one size, 2,6 s) sides of one length without crans: 8 partners each at most
NOTCH_TURN = 10.      # degrees: a corner cut out is square to this
END_NEAR = 1.         # mm: the two ends of a tube are this close in length
FOND_WORDS = ('FOND', 'BASE', 'CUL', 'SEMELLE')   # 0.19.29: a fond's name (a fond rapporté: the piece sewn all round)
TUBE_WORDS = ('CORPS', 'PARTIE HAUTE', 'HAUT', 'BANDE', 'TOUR', 'JUPE', 'FUT', 'FÛT')


LINING_WORDS = ('DBL', 'DOUBLURE', 'DB')   # 0.19.29: the start of a lining's name
COPY_WORDS = {'D', 'G', 'DROIT', 'DROITE', 'GAUCHE', 'DR', 'GA'}   # (the end of a name told apart from its other copy)
STAGE_WORDS = ('SURCOUPE', 'PRECOUPE', 'PRÉCOUPE')
DEFAULT_NAMES = {'', 'PIÈCE', 'PIECE', 'CONTOUR', 'POLYLIGNE', 'RECTANGLE', 'CERCLE', 'ELLIPSE', 'FORME', 'LIGNE', 'ARC'}


def lining(app, k):
    """0.19.29: piece ``k`` belongs to the lining (its name: DBL, DOUBLURE, DB; a Mozart « F- »; a fabric), sewn with the
    lining's pieces, never edge to edge with the outside's"""
    import re
    words = re.findall(r'[^\W_]+', _name(host(app, k)))
    while words and words[0] in STAGE_WORDS:
        words = words[1:]   # (« SURCOUPE DBL ENCHAPE 1 »)
    if words and words[0] in LINING_WORDS:
        return True
    data = (host(app, k).get('piece_info') or {}).get('material') or {}
    if str((data.get('mozart') or {}).get('MATERIALE') or '').strip().upper().startswith('F-'):
        return True
    try:
        return fabric(app, k)
    except (KeyError, TypeError, ValueError, AttributeError):
        return False


def base_name(app, k):
    """0.19.29: piece ``k``'s name without what tells it from its other copy (« SOUFFLET D » / « G », « ENCHAPE 1 » / « 2 »)
    nor its stage (« SURCOUPE ENCHAPE 1 »): two pieces of one base name are two copies of one piece, never sewn edge to
    edge by their lengths alone"""
    import re
    info = (host(app, k).get('piece_info') or {}).get('part_name') or {}
    named = ' '.join(str(v) for v in info.get('values') or [] if v).strip().upper()
    if not named and str(host(app, k).get('name') or '').strip().upper() in DEFAULT_NAMES:
        return ''   # (review: Craft's own « Pièce »: not a name the pieces were given)
    words = re.findall(r'[^\W_]+', named or _name(host(app, k)))
    while words and words[0] in STAGE_WORDS:
        words = words[1:]
    while len(words) > 1 and (words[-1] in COPY_WORDS or words[-1].isdigit()):
        words = words[:-1]
    return ' '.join(words)


def _straight(run, tol=.01):
    """0.19.29: the points ``run`` are on one straight line"""
    a, b = run[0], run[-1]
    L = math.dist(a, b)
    if L < 1e-9:
        return False
    ux, uy = (b[0] - a[0]) / L, (b[1] - a[1]) / L
    return all(abs((p[0] - a[0]) * uy - (p[1] - a[1]) * ux) <= tol for p in run)


def _unit(run):
    a, b = run[0], run[-1]
    L = math.dist(a, b)
    return ((b[0] - a[0]) / L, (b[1] - a[1]) / L) if L > 1e-12 else (0., 0.)


def _rembord_bands(app):
    """0.19.29: {owner id: its widest rembord} of the parage zones « rembord » that are a band along an edge (BAND_MOST)"""
    zone_width = __import__('preparation_ui').zone_width
    out = {}
    for q in app.items:
        data = q.get('preparation')
        if not isinstance(data, dict) or data.get('kind') != 'parage' or not q.get('owner_id') \
                or 'REMBORD' not in str(data.get('type') or '').upper():
            continue
        try:
            w = float(zone_width(q))
        except (TypeError, ValueError, ZeroDivisionError, KeyError, IndexError):
            continue
        if math.isfinite(w) and 0 < w <= BAND_MOST:
            out[q['owner_id']] = max(out.get(q['owner_id'], 0.), w)
    return out


def notches(app, k):
    """0.19.29 (fond mexicain: « les coins découpés cousus, même pièce »): the corners cut out of piece ``k``, each two
    straight sides of about one length meeting at a square corner turned inwards, sewn together (closed like a pince):
    [(i, j)] (j the side after i), when the piece has two of them at least of one size, small beside the piece."""
    from craft_tools import interior_side
    from geometry import bounds
    try:
        runs, total = sides(app.items[k])
        inside = interior_side(app.items[k])
        x, y, X, Y = bounds([app.items[k]])
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        return []
    n = len(runs)
    if n < 6:
        return []
    small = min(X - x, Y - y) / 2
    square = math.sin(math.radians(NOTCH_TURN))
    found = []
    for i in range(n):
        j = (i + 1) % n
        a, b = runs[i], runs[j]
        if min(a[2], b[2]) < 3 or max(a[2], b[2]) > small or abs(a[2] - b[2]) > max(.5, .02 * max(a[2], b[2])):
            continue
        if not (_straight(a[0]) and _straight(b[0])):
            continue
        u, v = _unit(a[0]), _unit(b[0])
        if abs(u[0] * v[0] + u[1] * v[1]) > square or (u[0] * v[1] - u[1] * v[0]) * inside >= 0:
            continue   # (not square, or turned towards the inside: a corner of the piece itself)
        found.append((i, j, (a[2] + b[2]) / 2))
    taken = [s for i, j, _ in found for s in (i, j)]
    found = [f for f in found if taken.count(f[0]) == 1 and taken.count(f[1]) == 1]   # (a side in two of them: neither)
    out = []
    for f in found:   # (of one size: two at least)
        alike = [g for g in found if abs(g[2] - f[2]) <= max(1., .03 * max(g[2], f[2]))]
        if len(alike) >= 2:
            out.append((f[0], f[1]))
    return out


TUBE_SIDES = 12   # 0.19.29 (review): a piece of more sides is never a partie haute closed into a tube (an 80-teeth piece: 17 s)


def _tube_lengths(app, k, ids, f, seam_fond, end):
    """(review) the bottom ``ids`` of the tube ``k`` and the whole fond ``f`` as their pair is then proposed and checked
    (_own_pairs, check): each where it is sewn (the cut for fabric, a rembordé edge from its fold), the bottom from one end
    seam to the other, or up to its rembords' folds; None"""
    a, b = (k, list(ids)), (f, list(range(len(sides(app.items[f])[0]))))
    try:
        reach = reaches(app, seam_fond, (k, f), [(k, portion(app, a)[0]), (f, portion(app, b)[0])])
        shut = with_folds(((end, end), (0., 0.)), pair_folds(app, [a, b], reach))
        return measured(app, a, reach[0], shut[0])[2], measured(app, b, reach[1], shut[1])[2]
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        return None


def tubes(app, pieces, own, seam_fond):
    """0.19.29 (fond rapporté: « partie haute en une seule pièce principalement », its two ends sewn together, « le fond
    cousu généralement en piqué retourné »; bande allemande type seau: a bande and a fond): each piece closed into a tube
    by two of its sides (straight, of one length within END_NEAR, running opposite) with a fond sewn all round its bottom:
    the run between those ends whose seam, from one end's seam to the other (each its usual seam, as closings counts it),
    is as long as the fond's whole contour at its seam ``seam_fond`` (two pieces in fabric: at the cut, as the check
    measures them; NEAR or SPREAD; a fond or a tube named so, else within NOCRAN_NEAR); never the lining with the outside:
    [dict(piece, ends=(i, j), bottom=[ids], fond, end: the ends' seam, lb: the bottom's seam, lf: the fond's)], the closest
    first, each piece and each fond once."""
    contour = {}
    for f in pieces:
        try:
            contour[f] = sides(app.items[f])[1]
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            pass
    kept = {}

    def length(k, ids, d):
        if (k, ids, d) not in kept:
            try:
                kept[k, ids, d] = measured(app, (k, list(ids)), d)[2]
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                kept[k, ids, d] = None
        return kept[k, ids, d]
    inside = {k: lining(app, k) for k in pieces}
    found = []
    for k in pieces:
        try:
            runs, total = sides(app.items[k])
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            continue
        n = len(runs)
        if not 4 <= n <= TUBE_SIDES:
            continue
        straight = [i for i in range(n) if _straight(runs[i][0])]
        tube_named = any(w in _name(host(app, k)) for w in TUBE_WORDS)
        end = usual_seam(app, (k, k))   # (its two ends sewn together: the seam closings takes)
        for x, i in enumerate(straight):
            for j in straight[x + 1:]:
                if (j - i) % n in (1, n - 1) or abs(runs[i][2] - runs[j][2]) > END_NEAR:
                    continue
                u, v = _unit(runs[i][0]), _unit(runs[j][0])
                if u[0] * v[0] + u[1] * v[1] > -.995:
                    continue
                for ids in (tuple(range(i + 1, j)), tuple((j + 1 + m) % n for m in range(n - (j - i) - 1))):
                    cut = sum(runs[m][2] for m in ids)
                    if not ids:
                        continue
                    for f in contour:
                        if f == k or f in own.get(k, ()) or k in own.get(f, ()) or inside[f] != inside[k] \
                                or abs(contour[f] - cut) > .1 * cut + 2 * math.pi * seam_fond + 2 * end + 20:
                            continue
                        d = 0. if both_fabric(app, (k, f)) else seam_fond
                        lb, lf = length(k, ids, d), length(f, tuple(range(len(sides(app.items[f])[0]))), d)
                        if lb is None or lf is None or lb - 2 * end <= 0:
                            continue
                        lb -= 2 * end
                        diff = abs(lf - lb)
                        named = tube_named or any(w in _name(host(app, f)) for w in FOND_WORDS)
                        if diff > (max(NEAR, SPREAD * max(lf, lb)) if named else max(NOCRAN_NEAR, NOCRAN_SPREAD * max(lf, lb))):
                            continue
                        exact = _tube_lengths(app, k, list(ids), f, seam_fond, end)   # (as the pair proposed is measured)
                        if exact is None:
                            continue
                        lb, lf = exact
                        diff = abs(lf - lb)
                        if lb <= 0 or diff > (max(NEAR, SPREAD * max(lf, lb)) if named else max(NOCRAN_NEAR, NOCRAN_SPREAD * max(lf, lb))):
                            continue
                        found.append((diff, k, (i, j), list(ids), f, end, lb, lf))
    found.sort(key=lambda t: t[0])
    out, used = [], set()
    for diff, k, ends, ids, f, end, lb, lf in found:
        if k in used or f in used:
            continue
        used.update((k, f))
        out.append(dict(piece=k, ends=ends, bottom=ids, fond=f, end=end, lb=lb, lf=lf))
    return out


def proposals(app, every=False):
    """0.19.25: the probable pairs of edges: two edges (a side, or several in a row, each end side with a cran) of two
    pieces of about the same length (NEAR mm or SPREAD apart at most, SHORTEST mm long at least) with about as many
    crans, most of them falling in front of each other (``_alike``); never a piece with its own renfort or doublure, nor
    an edge already in a pair kept. [dict(a=(k, ids), b=(k, ids), la, lb, ca, cb, front: in front as the check counts
    them, seam: a jonc's 5 mm when the edges go together there, else None)]: the most crans alike first, then the closest
    numbers of crans, then the closest lengths. 0.19.26: measured at the seam (2,5 mm, or a jonc's 5 mm when that puts
    more crans in front or the lengths clearly closer: DIFORME's FACE and CAVOUR). 0.19.29: two pieces in fabric at the
    cut (« la mesure sur polyligne fait la même longueur »), a rembordé edge from its fold; sides without crans too
    (« il n'y a pas forcément de crans sur les sacs basiques »), on pieces without any, their lengths within NOCRAN_NEAR
    (``nocran``: to check, after the others); the corners cut out of a fond mexicain (``kind`` 'coin': the piece with
    itself) and a partie haute closed into a tube with its fond (tubes: 'bout', 'fond'; the fond at 5 mm, piqué retourné);
    a band between two pieces (« entre face et dos il y a le cavour ») : never those two pieces together, each of its
    edges to one of them only, chosen by its crans the way the pieces are sewn (« le cavour a une bande spécifique pour
    chaque côté »; FACE the way it is sewn, DOS turned), both to a piece cut twice; each edge in one pair (a piece cut
    twice: two). ``every``: the edges kept too (the Montage auto: the whole bag)."""
    from craft_tools import interior_side
    pieces = _pieces(app, every=True)
    taken = {}   # the sides of the edges kept: sewn already (review: nor an edge sharing a side with one)
    uses, kept_edges, busy, faces = {}, set(), {}, {}   # 0.19.40: a piece cut twice: its sides free once more (its second copy)
    for pair in [] if every else kept_pairs(app):
        edges = [pair['a'], pair['b']] + list(pair.get('more') or ())   # (0.19.36: edge 2's next pieces too)
        if any(k is not None and len(sides(app.items[k])[0]) != e['count'] for k, e in ((piece_index(app, e['piece'], pieces), e) for e in edges)):
            continue   # (review: a pair to check again: its old side numbers are other sides now, proposed again)
        for e in edges:
            for i in e['sides']:
                uses[(e['piece'], i)] = uses.get((e['piece'], i), 0) + 1
        kept_edges.add(frozenset((e['piece'], tuple(sorted(e['sides']))) for e in edges))   # (never proposed again)
        k = piece_index(app, pair['a']['piece'], pieces) if pair.get('more') else None
        if k is not None:
            faces[k] = faces.get(k, 0) + 1   # (a face has one bottom: its chain kept, never another of its sides)
    for (key, i), n in uses.items():   # each side as many times as its piece is cut (a soufflet cut twice: the face's
        k = piece_index(app, key, pieces)   # chain kept, the dos's still proposed)
        if k is None or n >= quantity(app, k):
            taken.setdefault(key, set()).add(i)
        else:
            busy[(k, i)] = n
    cloth = {}   # 0.19.28: the pieces in fabric
    for k in pieces:
        try:
            cloth[k] = fabric(app, k)
        except (KeyError, TypeError, ValueError, AttributeError):
            cloth[k] = False
    bands = _rembord_bands(app)   # 0.19.29: the pieces with a rembord along an edge (the others are never folded)
    folds = {}   # (k, ids) -> the rembord folded under that edge

    def fold(k, ids):
        if (k, ids) not in folds:
            owners = {app.items[k].get('piece_id'), app.items[k].get('owner_id'), host(app, k).get('piece_id')} - {None}
            folds[k, ids] = 0.
            if owners & set(bands):
                try:
                    folds[k, ids] = rembord_width(app, k, portion(app, (k, list(ids)))[0])
                except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                    pass
        return folds[k, ids]
    widest = max(bands.values(), default=0.)
    reach = max(default_seam(app), JONC, TISSU) + widest   # (review: an edge's seam differs from it by its bends × the seam's distance at most:
    sewn = [k for k in pieces if sewn_piece(app, k)]   # 0.19.29: renforts, aides, gabarits are glued or used, never sewn
    edges = []   # (length, k, ids, crans along the edge, bends, with crans)   (a round base all round, twice two round corners)
    for k in sewn:
        try:
            runs, total = sides(app.items[k])
            n = len(runs)
            spots = _cran_spots(app, k, total) if n and total > 0 else []   # (review: a cran it cannot read, as check())
        except (ValueError, KeyError, TypeError, ZeroDivisionError, IndexError):
            continue

        def on(start, length):
            return sorted(min((d - start) % total, length) for d in spots if (d - start) % total <= length + .05)
        marked = [bool(on(start, length)) for _, start, length in runs]
        for i in range(n):   # each edge: from side i, one side or more in a row (round the closing corner too)
            if not marked[i] and (spots or runs[i][2] < NOCRAN_SHORTEST):
                continue   # 0.19.29: sides without crans on a piece without any (its crans tell its seams otherwise)
            start, length, ids, line = runs[i][1], 0., [], []
            for m in range(min(n, LONGEST_RUN) if marked[i] else 1):
                j = (i + m) % n
                length += runs[j][2]
                line += list(runs[j][0][1:] if ids else runs[j][0])
                ids.append(j)
                if m + 1 == n and i:   # (the whole contour: once)
                    continue
                if marked[i]:
                    if length < SHORTEST or not marked[j]:
                        continue
                    crans_on = on(start, length)
                else:
                    crans_on = []
                # 0.19.26: how far its seam can be from it (the whole contour: its closing corner too)
                bend = _bends(line + line[1:2] if m + 1 == n else line, reach)
                edges.append((length, k, tuple(ids), crans_on, bend, marked[i]))
    edges.sort(key=lambda e: e[0])
    names = piece_names(app, True)   # 0.19.27: read once
    own = {k: {j for j, _, _ in layers(app, k, True, names)} for k in pieces}   # a piece and its renforts / doublures (by their names)
    kind_of = {k: lining(app, k) for k in sewn}
    base = {k: base_name(app, k) for k in sewn}
    shape = {}   # 0.19.29: two pieces of one shape (FACE, DOS) are sewn to the other pieces first (soufflets, rehausses)
    for k in sewn:
        try:
            shape[k] = tuple(sorted(round(r[2]) for r in sides(app.items[k])[0]))
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            shape[k] = None
    found = {}
    most = max((e[4] for e in edges), default=0.)
    lines = {}
    partners = {}   # 0.19.29 (review): the pairs without crans of each edge so far
    places = {}     # its place in its piece (_mirrored)

    known = {}   # 0.19.35: each piece's rembord bands, and whether one of its rembord zones is not a band

    def bands_of(k):
        if k not in known:
            try:
                known[k] = ([], True) if piping(app, k) else _bands(app, k)   # (a jonc: its pairs to the end, pair_folds)
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                known[k] = ([], True)
        return known[k]

    def at_seam(k, ids, cut, d, trimmed=False):
        """(length at the seam d, crans there) of the edge, kept (0.19.29: a rembordé edge from its fold; 0.19.35 ``trimmed``:
        up to the folds of the rembords it runs into, as the check measures it)"""
        if d > 0:
            d += fold(k, ids)
        key = (k, ids, d, trimmed)
        if key not in lines:
            pts, start, length, total = portion(app, (k, list(ids)))
            try:
                line = seam_line(pts, d, interior_side(app.items[k])) if d > 0 else None
            except ValueError:
                line = None
            got = (line.length, [line.at(v) for v in cut]) if line else (length, list(cut))
            if trimmed:
                s, e = edge_folds(app, (k, list(ids)), d, False, bands_of(k)[0])
                if s or e:
                    L = max(got[0] - s - e, 0.)
                    got = (L, [min(max(v - s, 0.), L) for v in got[1]])
            lines[key] = got
        return lines[key]
    slack = 3 * widest   # 0.19.35: two edges alike once folded may differ at the cut by their folds
    for x, (la, ka, ia, ca, ua, ma) in enumerate(edges):
        for lb, kb, ib, cb, ub, mb in edges[x + 1:]:
            if lb - la > max(NEAR, SPREAD * (lb + reach * most)) + reach * (ua + most) + slack:
                break
            if lb - la > max(NEAR, SPREAD * (lb + reach * ub)) + reach * (ua + ub) + slack:
                continue
            if ma != mb or kb == ka or kb in own[ka] or ka in own[kb] or abs(len(ca) - len(cb)) > max(1, round(.15 * max(len(ca), len(cb)))):
                continue
            if not ma and (kind_of[ka] != kind_of[kb] or base[ka] and base[ka] == base[kb]
                           or partners.get((ka, ia), 0) >= NOCRAN_PARTNERS or partners.get((kb, ib), 0) >= NOCRAN_PARTNERS):
                continue   # 0.19.29: by their lengths alone, never the lining with the outside, nor two copies of one piece
            key = tuple(sorted(((ka, tuple(sorted(ia))), (kb, tuple(sorted(ib))))))
            named = [_known_key(app, k) for k in (ka, kb)]
            if named[0] is not None and named[0] == named[1]:
                continue   # (review) two copies in one précoupe: the same piece for a pair kept
            if taken.get(named[0], set()) & set(ia) or taken.get(named[1], set()) & set(ib):
                continue
            if frozenset(((named[0], tuple(sorted(ia))), (named[1], tuple(sorted(ib))))) in kept_edges:
                continue   # 0.19.40: a pair kept, its sides free once more (pieces cut twice): never the same pair again
            best = None
            woven = cloth.get(ka) and cloth.get(kb)   # 0.19.29: two pieces in fabric: at the cut
            usual = TISSU if woven else default_seam(app)
            distances = [0.] if woven else [usual] + ([JONC] if abs(JONC - usual) > 1e-9 and ma else [])
            trimmed = not (bands_of(ka)[1] or bands_of(kb)[1])   # 0.19.35: never one edge folded alone (nor a jonc's pairs)
            for d in distances:   # 0.19.26: at the seam; a jonc's only when clearly better than 2,5 mm
                sa, xa = at_seam(ka, ia, ca, d, trimmed)
                sb, xb = at_seam(kb, ib, cb, d, trimmed)
                if abs(sa - sb) > (max(NEAR, SPREAD * max(sa, sb)) if ma else max(NOCRAN_NEAR, NOCRAN_SPREAD * max(sa, sb))):
                    continue
                if ma:
                    alike = _alike(xa, sa, xb, sb)
                    if alike < max(1, (max(len(ca), len(cb)) + 1) // 2):
                        continue   # their crans do not fall in front of each other: a coincidence of lengths
                else:
                    alike = 0
                front, _ = facing(xa, sa, xb, sb)
                if best is not None and not (front > best[4] or front == best[4] and abs(best[2] - best[3]) - abs(sa - sb) > ECART):
                    continue
                best = (d, alike, sa, sb, front, xa, xb)
            if best is None:
                continue
            d, alike, sa, sb, front, xa, xb = best
            if woven:
                d = usual   # (measured at the cut, sewn at its 5 mm: « 5 tissu »)
            score = ((0, -round(alike / max(len(ca), len(cb)), 1), abs(len(ca) - len(cb)), abs(sa - sb)) if ma
                     else (2, round(abs(sa - sb), 1), int(shape.get(ka) is not None and shape.get(ka) == shape.get(kb)),
                           round(_mirrored(app, (ka, ia), (kb, ib), places), 2), -round(max(sa, sb))))   # 0.19.29: without
                     # crans after, the closest first; at one length, the sides face to face (a piece turned over onto the other)
            if not ma and key not in found:
                for e in ((ka, ia), (kb, ib)):
                    partners[e] = partners.get(e, 0) + 1
            if key not in found or score < found[key][0]:
                found[key] = (score, dict(a=(ka, list(ia)), b=(kb, list(ib)), la=sa, lb=sb, ca=len(ca), cb=len(cb), front=front,
                                          pieces=(app.items[ka], app.items[kb]), seam=None if d == usual else d, nocran=not ma,
                                          xa=xa, xb=xb))
    found = _between_bands(app, found)
    found.update(_own_pairs(app, sewn, own, taken))   # 0.19.29: the corners of a fond mexicain, a tube and its fond

    def kept_already(p):   # 0.19.40: the same edges as a pair kept (pieces cut twice: their sides free once more)
        edges = [p['a'], p['b']] + list(p.get('more') or ())
        return frozenset((_known_key(app, k), tuple(sorted(ids))) for k, ids in edges) in kept_edges
    if kept_edges:
        found = {key: v for key, v in found.items() if not kept_already(v[1])}
    out, used, cut, joined, chosen, between = [], dict(busy), {}, {}, set(), {}
    try:   # 0.19.36: a face's (a dos's) bottom on a patte, the fond and the other patte (fond mexicain), first: its sides taken
        chains = [q for q in chain_proposals(app, pieces, taken, busy, faces) if not (kept_edges and kept_already(q))]
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError, AttributeError):
        chains = []
    for q in chains:
        for k, ids in [q['a'], q['b']] + q['more']:
            for i in ids:
                used[(k, i)] = used.get((k, i), 0) + 1
    ordered = [p for _, p in sorted(found.values(), key=lambda v: v[0])]
    rank = {id(p): n for n, p in enumerate(ordered)}
    by_shape = {}
    for k, v in shape.items():
        if v is not None:
            by_shape.setdefault(v, []).append(k)
    for strict in (True, False):   # 0.19.29: by lengths alone, a piece goes once to each of two pieces of one shape first
        for p in ordered:          # (TILTED: a soufflet to the FACE on one side, to the DOS on the other)
            if id(p) in chosen:
                continue
            ka, kb = p['a'][0], p['b'][0]
            if strict and p.get('nocran') and (joined.get((ka, kb)) and any(t not in (ka, kb) for t in by_shape.get(shape.get(kb), ()))
                                               or joined.get((kb, ka)) and any(t not in (ka, kb) for t in by_shape.get(shape.get(ka), ()))):
                continue
            if any(all(set(dict((p['a'], p['b']))[k]) & set(dict((q['a'], q['b']))[k]) for k in {ka, kb})
                   for q in between.get(frozenset((ka, kb)), ())):
                continue   # the best first; one seam once (edges overlapping on both pieces)
            sides_of = [(k, i) for k, ids in (p['a'], p['b']) for i in ids]   # 0.19.29: each side in one pair (cut twice: two)
            for k, _ in sides_of:
                if k not in cut:
                    cut[k] = quantity(app, k)
            if any(used.get(s, 0) >= cut[s[0]] for s in sides_of):
                continue
            for s in sides_of:
                used[s] = used.get(s, 0) + 1
            joined[ka, kb] = joined[kb, ka] = True
            chosen.add(id(p))
            between.setdefault(frozenset((ka, kb)), []).append(p)
            out.append(p)
    out.sort(key=lambda p: rank[id(p)])
    for p in out:
        p.pop('xa', None)
        p.pop('xb', None)
    return (chains + out)[:MOST]


SOUFFLET_WORDS = ('SOUFFLET', 'GOUSSET', 'COTE', 'CÔTÉ', 'FLANC')   # 0.19.36: a piece whose short sides may be its pattes
PATTE_MOST = 60.   # mm: a patte (the short side of a soufflet sewn on with the fond) at most this long


def proposal_pieces(p):
    """0.19.36: the pieces of a proposal in the order of p['pieces']: edge 1's, edge 2's, then its next pieces' (a chain)"""
    return [p['a'][0], p['b'][0]] + [k for k, _ in p.get('more') or ()]


def moved_under(app, p):
    """(review) the drawing changed under a proposal: one of its pieces is not where it was"""
    items = app.items
    ks = proposal_pieces(p)
    return len(ks) != len(p['pieces']) or not all(k < len(items) and items[k] is s for k, s in zip(ks, p['pieces']))


def chain_proposals(app, pieces, taken=None, busy=(), faces=None):
    """0.19.36 (« montage fond mexicain : la face et le dos ont 3 pièces qui viennent se coudre sur le bas (1 petite patte
    des soufflets, le fond et la patte de l'autre soufflet) »): a side of a piece as long as a side of a fond (FOND_WORDS)
    with a short side (PATTE_MOST) of each of two other pieces as long as each other (the pattes), at the cut (NEAR or
    SPREAD): edge 2 on the patte, the fond, the other patte, one after the other (kind 'mexicain'; the junctions by
    distance, no crans), the lining's with the lining's; each side once; the pieces whose name says a soufflet first.
    0.19.39 (« fond mexicain avec un seul soufflet dessiné et coupé deux fois »): a soufflet drawn once and cut twice (its
    matière's number, quantity) gives both pattes, its two copies' (two sides of it: one copy on each side of the bag, its
    other patte toward the face), when no two soufflets do; each side as many times as its piece is cut.
    [dict(a=(k, [i]), b=(k, [i]), more=[(k, [i]), (k, [i])], la, lb, ca, cb, front, seam, kind)]"""
    import re
    taken = taken or {}
    keys = {}
    used = dict(busy) if isinstance(busy, dict) else {s: 99 for s in busy}   # 0.19.39: how many copies of each side are
    # in a chain already (0.19.40: ``busy`` {(k, i): uses in the pairs kept}, a piece cut twice used once)
    cuts = {}

    def copies(k):
        if k not in cuts:
            cuts[k] = quantity(app, k)
        return cuts[k]

    def key_of(k):
        if k not in keys:
            try:
                keys[k] = _known_key(app, k, True)
            except (ValueError, KeyError, TypeError, IndexError):
                keys[k] = None
        return keys[k]

    def free(k, i, n=1):
        return used.get((k, i), 0) + n <= copies(k) and i not in taken.get(key_of(k), ())
    sewn = [k for k in pieces if sewn_piece(app, k)]
    words = {k: re.findall(r'[^\W_]+', _name(host(app, k))) for k in sewn}
    inner = {k: lining(app, k) for k in sewn}
    lengths = {k: [run[2] for run in sides(app.items[k])[0]] for k in sewn}
    fonds = [k for k in sewn if any(w in FOND_WORDS for w in words[k])]
    bases = {}

    def twins(s1, s2):
        for s in (s1, s2):
            if s not in bases:
                bases[s] = base_name(app, s)
        both = all(any(w.startswith(SOUFFLET_WORDS) for w in words[s]) for s in (s1, s2))
        return bool(bases[s1]) and bases[s1] == bases[s2] or both

    def beside(k, s1, s2):
        """piece ``k`` has a long side as long as one of the soufflets' long ones (sewn to them up its sides)"""
        mine = [v for v in lengths[k] if v >= NOCRAN_SHORTEST]
        theirs = [v for s in (s1, s2) for v in lengths[s] if v >= NOCRAN_SHORTEST]
        return any(abs(a - b) <= NEAR for a in mine for b in theirs)

    def slim(k):
        """piece ``k`` is a band (three times longer than wide): a rehausse, a strap, never the face"""
        from geometry import bounds
        x, y, X, Y = bounds([app.items[k]])
        return max(X - x, Y - y) > 3 * max(min(X - x, Y - y), 1e-9)

    def low(k, i):
        """how low side ``i`` of piece ``k`` is on the plan (its middle: y downwards)"""
        run = sides(app.items[k])[0][i][0]
        return (run[0][1] + run[-1][1]) / 2 if run else 0.
    out, chained = [], {k for k, n in (faces or {}).items() if n >= copies(k)}   # 0.19.40: the faces of the chains kept
    for f in fonds:
        for y_i, y in sorted(enumerate(lengths[f]), key=lambda v: -v[1]):
            if y < NOCRAN_SHORTEST or not free(f, y_i):
                continue
            best = None
            for p in sewn:
                if p == f or p in chained or inner[p] != inner[f] or any(w in FOND_WORDS for w in words[p]):
                    continue
                mine = None   # this piece's side for it: the closest, two alike the lower one (its bottom)
                for e_i, e in enumerate(lengths[p]):
                    rest = e - y
                    if not free(p, e_i) or not 2. <= rest <= 2 * PATTE_MOST:
                        continue
                    tol = max(NEAR, SPREAD * e)
                    pattes = [(abs(x - rest / 2), s, x_i, x) for s in sewn if s not in (p, f) and inner[s] == inner[f]
                              for x_i, x in enumerate(lengths[s]) if x <= PATTE_MOST and free(s, x_i) and abs(x - rest / 2) <= tol]
                    pattes.sort(key=lambda v: (not any(w.startswith(SOUFFLET_WORDS) for w in words[v[1]]), v[0]))
                    for n, (_, s1, x1_i, x1) in enumerate(pattes):
                        # the two pattes: of two copies of one piece (« SOUFFLET D » / « G »), or of two soufflets by their names
                        two = next(((s2, x2_i, x2) for _, s2, x2_i, x2 in pattes[n + 1:] if s2 != s1 and abs(x1 - x2) <= 1.
                                    and abs(x1 + y + x2 - e) <= tol and twins(s1, s2)), None)
                        # 0.19.39: one soufflet cut twice (review: named as one; RIDER's PATTE ANNEAU, cut twice, and its
                        # PLAQUE DE FOND made the FACE a fond mexicain: Montage auto « mexicain », its cavour lost)
                        if two is None and copies(s1) >= 2 and any(w.startswith(SOUFFLET_WORDS) for w in words[s1]):
                            # its other patte (the other
                            alike = [(s2, x2_i, x2) for _, s2, x2_i, x2 in pattes[n:] if s2 == s1   # copy's), else the same
                                     and abs(x1 - x2) <= 1. and abs(x1 + y + x2 - e) <= tol]          # one twice
                            two = next((c for c in alike if c[1] != x1_i), None) or next(
                                (c for c in alike if c[1] == x1_i and free(s1, x1_i, 2)), None)
                        if two is None:
                            continue
                        s2, x2_i, x2 = two
                        gap = abs(x1 + y + x2 - e)
                        named = any(w.startswith(SOUFFLET_WORDS) for w in words[s1] + words[s2])
                        # (TILTED: the REHAUSSE's 260 too: a face is sewn to the soufflets by its sides too, and is no band)
                        here = ((not named, not beside(p, s1, s2), slim(p), round(gap, 1)), -low(p, e_i))
                        if mine is None or here < mine[0]:
                            mine = (here, dict(a=(p, [e_i]), b=(s1, [x1_i]), more=[(f, [y_i]), (s2, [x2_i])],
                                               la=e, lb=x1 + y + x2, ca=0, cb=0, front=0, seam=None, kind='mexicain', nocran=False,
                                               pieces=(app.items[p], app.items[s1], app.items[f], app.items[s2])))
                        break
                if mine is not None and (best is None or mine[0][0] < best[0]):
                    best = (mine[0][0], mine[1])
            if best is not None:
                q = best[1]
                for k, ids in [q['a'], q['b']] + q['more']:
                    for i in ids:
                        used[(k, i)] = used.get((k, i), 0) + 1
                chained.add(q['a'][0])   # (a face has one bottom)
                out.append(q)
    return out


def _mirrored(app, a, b, kept=None):
    """0.19.29: how far the edge ``b`` of its piece is from where the edge ``a`` of its own would come once one piece is
    turned over onto the other (left with right, top with top), 0 when just there (by the middles of the edges, in
    parts of each piece's size). ``kept``: {edge: its place} (review: once per edge)."""
    from geometry import bounds
    kept = {} if kept is None else kept
    places = []
    for k, ids in (a, b):
        key = (k, tuple(ids))
        if key not in kept:
            try:
                pts = portion(app, (k, list(ids)))[0]
                x, y, X, Y = bounds([app.items[k]])
                mx, my = sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)
                kept[key] = ((mx - (x + X) / 2) / max(X - x, 1e-9), (my - (y + Y) / 2) / max(Y - y, 1e-9))
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                kept[key] = None
        if kept[key] is None:
            return 0.
        places.append(kept[key])
    (ax, ay), (bx, by) = places
    return abs(ax + bx) + abs(ay - by)


def _own_pairs(app, sewn, own, taken):
    """0.19.29: the pairs a piece makes with itself, and a tube's fond: {key: (score, proposal)} (crans as the others)"""
    from craft_tools import interior_side
    out = {}

    def add(kind, a, b, score, d=None, shut=((0., 0.), (0., 0.)), retourne=False):
        named = [_known_key(app, k) for k in (a[0], b[0])]
        if taken.get(named[0], set()) & set(a[1]) or taken.get(named[1], set()) & set(b[1]):
            return   # (a side already in a pair kept)
        ks = (a[0], b[0])
        usual = usual_seam(app, ks)
        d = usual if d is None else d
        try:   # (each edge where it is measured: the cut for fabric, the fold of a rembord)
            reach = reaches(app, d, ks, [(a[0], portion(app, a)[0]), (b[0], portion(app, b)[0])])
            shut = with_folds(shut, pair_folds(app, [a, b], reach))   # 0.19.35: up to a rembord's fold
            ma = measured(app, a, reach[0], shut[0])
            mb = measured(app, b, reach[1], shut[1])
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            return
        front, _ = facing(ma[4], ma[2], mb[4], mb[2])
        key = tuple(sorted(((a[0], tuple(sorted(a[1]))), (b[0], tuple(sorted(b[1]))))))
        out[key] = ((1, score, 0, 0), dict(a=(a[0], list(a[1])), b=(b[0], list(b[1])), la=ma[2], lb=mb[2], ca=len(ma[4]), cb=len(mb[4]),
                                           front=front, pieces=(app.items[a[0]], app.items[b[0]]),
                                           seam=None if abs(d - usual) < 1e-9 else d, nocran=False, kind=kind,
                                           retourne=bool(retourne and abs(d - usual) > 1e-9)))
    for k in sewn:
        for i, j in notches(app, k):
            add('coin', (k, [i]), (k, [j]), 0)
    fond = RETOURNE   # « le fond cousu généralement en piqué retourné »
    for t in tubes(app, sewn, own, fond):
        k, (i, j), end = t['piece'], t['ends'], t['end']
        add('bout', (k, [i]), (k, [j]), 1)
        n = len(sides(app.items[t['fond']])[0])
        add('fond', (k, t['bottom']), (t['fond'], list(range(n))), 2, fond, ((end, end), (0., 0.)), True)
    return out


def _natural(app, p, band, other):
    """(crans in front the way piece ``other`` is sewn to the band's edge, in front the other way) of the proposal ``p``
    (pieces drawn the same way round are sewn edges running opposite)"""
    from craft_tools import interior_side
    xa, xb = (p['xa'], p['xb']) if p['a'][0] == band else (p['xb'], p['xa'])
    la, lb = (p['la'], p['lb']) if p['a'][0] == band else (p['lb'], p['la'])
    same, back = facing_counts(xa, la, xb, lb)
    try:
        opposite = interior_side(app.items[band]) == interior_side(app.items[other])
    except ValueError:
        opposite = True
    return (back, same) if opposite else (same, back)


def _between_bands(app, found):
    """0.19.29 (« entre face et dos il y a le cavour … avec jonc »; « le cavour a une bande spécifique pour chaque côté »):
    the proposals ``found`` ({key: (score, p)}) without the two pieces a band goes between (FACE / DOS, the CAVOUR's two
    edges each sewn to one of them), each edge of the band to one of them only (the way the crans fall in front as the
    pieces are sewn: FACE the way it is sewn, DOS turned; a tie: the piece named FACE, DEVANT, AVANT first), both edges to
    a piece cut twice (DB CORPS and its DOUBLURE CAVOUR)."""
    items = list(found.items())

    def edge(p, k):
        return p['a'][1] if p['a'][0] == k else p['b'][1]

    def other(p, k):
        return p['b'][0] if p['a'][0] == k else p['a'][0]
    drop = set()
    by_piece = {}
    for key, (score, p) in items:
        if p['a'][0] == p['b'][0] or p.get('nocran') or p.get('kind'):
            continue   # (0.19.29: by their crans only; edges without crans: each side in one pair, proposals)
        for k in (p['a'][0], p['b'][0]):
            by_piece.setdefault(k, []).append((key, p))
    # 1. a band between two pieces: A's edge with one of C's edges, B's with another one of C's: never A with B
    for key, (score, p) in items:
        A, B = p['a'][0], p['b'][0]
        if A == B:
            continue
        ea, eb = edge(p, A), edge(p, B)
        for C in by_piece:
            if C in (A, B):
                continue
            with_a = [edge(q, C) for _, q in by_piece[C] if other(q, C) == A and _overlap(edge(q, A), ea)]
            with_b = [edge(q, C) for _, q in by_piece[C] if other(q, C) == B and _overlap(edge(q, B), eb)]
            if any(not _overlap(c1, c2) for c1 in with_a for c2 in with_b):
                drop.add(key)
                break
    # 2. each edge of a band to one piece only (a piece cut twice: both): one edge of a piece with several edges of the
    # band, one of them kept (0.19.29: two pieces sewn along several edges of their own keep each of them)
    qty = {}

    def cut(k):
        if k not in qty:
            qty[k] = quantity(app, k)
        return qty[k]
    for C, mine in by_piece.items():
        groups = []   # [(A, [(key, q)])]: the pairs of A with C whose edges of A overlap
        for key, q in mine:
            if key in drop:
                continue
            A = other(q, C)
            g = next((g for B, g in groups if B == A and any(_overlap(edge(q, A), edge(r, A)) for _, r in g)), None)
            if g is None:
                groups.append((A, [(key, q)]))
            else:
                g.append((key, q))
        def double(g):
            return len({tuple(edge(q, C)) for _, q in g}) > 1 and not all(_overlap(edge(g[0][1], C), edge(q, C)) for _, q in g)
        decided = set()

        def nat(q, A):
            return _natural(app, q, C, A)[0]
        for n, (A, pa) in enumerate(groups):   # (0.19.29 review: the two pieces given their edges together, never the same)
            if n in decided or cut(A) >= 2 or not double(pa):
                continue   # (cut twice: one copy on each edge)
            decided.add(n)
            ours = {tuple(edge(q, C)) for _, q in pa}
            r = next((m for m, (B, g) in enumerate(groups) if m not in decided and B != A and cut(B) < 2
                      and {tuple(edge(q, C)) for _, q in g} & ours), None)   # (the other one: one edge of the band or more)
            front_a = _name(host(app, A)).startswith(FRONT_WORDS)
            best = None
            if r is not None:   # the other piece takes the other edge: the two together the way they are sewn
                B, pb = groups[r]
                front_b = _name(host(app, B)).startswith(FRONT_WORDS)
                for key, q in pa:
                    for key2, q2 in pb:
                        if _overlap(edge(q, C), edge(q2, C)):
                            continue
                        na, nb = nat(q, A), nat(q2, B)
                        rank = (na + nb, na if front_a else nb if front_b else 0, q['front'] + q2['front'],
                                -abs(q['la'] - q['lb']) - abs(q2['la'] - q2['lb']))
                        if best is None or rank > best[0]:
                            best = (rank, {key, key2})
                if best is not None:
                    decided.add(r)
                    drop.update(k for k, _ in pa + pb if k not in best[1])
                    continue
            for key, q in pa:   # alone (or no other edge left for the other one)
                rank = (nat(q, A), q['front'], -abs(q['la'] - q['lb']))
                if best is None or rank > best[0]:
                    best = (rank, {key})
            drop.update(k for k, _ in pa if k not in best[1])
    return {key: v for key, v in items if key not in drop}


def proposal_crans(p):
    """0.19.29: what the Crans column says of the proposal ``p``"""
    what = dict(coin='coin (même pièce)', bout='bouts (même pièce)', fond='fond tout autour').get(p.get('kind'))
    if p.get('nocran'):
        return 'sans crans · à vérifier'
    counted = f'{p["ca"]} / {p["cb"]} ({p["front"]} en face)' if p['ca'] or p['cb'] else 'sans crans'
    return f'{what} · {counted}' if what else counted


def add_pairs(app, chosen):
    """0.19.25: the proposals ``chosen`` kept with the model (each once); the number added."""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    pairs = entries(app)   # (0.19.26: after the steps and pairs already there)
    idents = {_ident(p) for p in pairs if 'a' in p}
    added = 0
    for p in chosen:
        if p.get('pieces') and moved_under(app, p):
            continue   # (0.19.36 review: the drawing changed under it: never a pair on other pieces, never an IndexError)
        pair = dict(a=edge_of(app, p['a']), b=edge_of(app, p['b']))
        if p.get('more'):
            pair['more'] = [edge_of(app, x) for x in p['more']]   # 0.19.36: edge 2's next pieces (fond mexicain)
        if p.get('seam') is not None:
            pair['seam'] = p['seam']   # 0.19.26: a jonc
            if p.get('retourne'):
                pair['retourne'] = True   # 0.19.29: a fond rapporté sewn piqué retourné
        if _ident(pair) not in idents:
            pairs.append(pair)
            idents.add(_ident(pair))
            added += 1
    if added:
        _store(app, pairs)
    win = app.__dict__.get('_bag_window')
    if win is not None and win.winfo_exists():
        win._refill()
    return added


def propose(app):
    """0.19.25 « Paires probables… » (Contrôle d'assemblage du sac): the probable pairs in a list to tick; a click shows
    the pair on the plan; « Ajouter les paires cochées » keeps them with the model."""
    from tkinter import ttk
    old = app.__dict__.get('_proposal_window')
    if old is not None and old.winfo_exists():
        old._refill()
        old.lift()
        return old
    win = app.dialog('Paires probables')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._proposal_window = win
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    head = tk.StringVar()
    tk.Label(win, textvariable=head, bg=panel, fg=ink, font=('Segoe UI', 10), justify='left', wraplength=620).pack(anchor='w', padx=14, pady=(12, 4))
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    columns = (('tick', '', 3), ('a', 'Bord 1', 24), ('b', 'Bord 2', 24), ('seam', 'Couture', 8), ('len', 'Longueurs (mm)', 15), ('crans', 'Crans', 15))
    table = ttk.Treeview(area, columns=[k for k, _, _ in columns], show='headings', height=10, selectmode='browse')
    for key, label, width in columns:
        table.heading(key, text=label)
        table.column(key, width=width * 7, anchor='center' if key == 'tick' else 'w', stretch=key in ('a', 'b'))
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')
    state = dict(rows=[], ticked=set())

    def text(chosen):
        k, ids = chosen
        return _side_text(app, k, ids)

    def stale():
        """(review) the drawing changed under the list: its pieces are not where they were (0.19.36 review: a chain's
        next pieces too)"""
        return any(moved_under(app, p) for p in state['rows'])

    def refill():
        state['rows'] = rows = proposals(app)
        state['ticked'] = set()
        table.delete(*table.get_children())
        for n, p in enumerate(rows):
            ks = (p['a'][0], p['b'][0])
            d, kind = seam_info(app, p.get('seam'), ks, p.get('retourne'))
            table.insert('', 'end', iid=str(n), values=('☐', text(p['a']), ' + '.join(text(x) for x in [p['b']] + list(p.get('more') or ())),
                                                        seam_text(d, kind), f'{_mm(p["la"])} / {_mm(p["lb"])}', proposal_crans(p)))
        if rows:
            unsure = sum(1 for p in rows if p.get('nocran'))
            head.set(f'{len(rows)} paire{"s" if len(rows) > 1 else ""} de bords de même longueur à la couture (à 3 mm ou 3 % près ; '
                     'deux tissus : à la coupe), aux crans en face'
                     + (f' ; {unsure} sans crans (seulement leurs longueurs, à 1,5 mm près : à vérifier)' if unsure else '')
                     + ' : cocher celles qui sont cousues ensemble, puis « Ajouter les paires cochées ». Clic : la paire sur le plan. '
                     'Couture « jonc » : les bords vont ensemble à 5 mm ; « coin » : un coin découpé du fond mexicain, fermé sur '
                     'lui-même ; « bouts », « fond » : une partie haute fermée par ses deux bouts et son fond, piqué retourné.')
        else:
            head.set('Aucune paire probable : il faut des bords de même longueur (les bords déjà dans la liste du sac '
                     'ne sont pas proposés).')
        shown(None)

    def shown(n):
        marks = app.__dict__.get('_bag_marks')
        if marks is None:
            return
        if n is None or n >= len(state['rows']):
            marks.pop('proposal', None)
        else:
            p = state['rows'][n]
            try:
                marks['proposal'] = tuple(portion(app, (e[0], list(e[1])))[0] for e in [p['a'], p['b']] + list(p.get('more') or ()))
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                marks.pop('proposal', None)
        draw_bag(app)

    def toggle(n):
        if n in state['ticked']:
            state['ticked'].discard(n)
        else:
            state['ticked'].add(n)
        table.set(str(n), 'tick', '☑' if n in state['ticked'] else '☐')

    def clicked(e):
        row = table.identify_row(e.y)
        if row and table.identify_column(e.x) == '#1':
            toggle(int(row))

    def picked(e=None):
        if stale():
            return refill()
        sel = table.selection()
        shown(int(sel[0]) if sel else None)

    def key_toggle(e=None):
        sel = table.selection()
        if sel:
            toggle(int(sel[0]))
        return 'break'

    def double(e):
        if table.identify_column(e.x) == '#1':
            return 'break'   # (review) its first click ticked it already: the double click leaves it ticked
        return key_toggle(e)
    table.bind('<Button-1>', clicked, add='+')
    table.bind('<<TreeviewSelect>>', picked)
    table.bind('<space>', key_toggle)
    table.bind('<Double-1>', double)

    def add():
        chosen = [state['rows'][n] for n in sorted(state['ticked'])]
        if not chosen:
            app.status.set('Cocher les paires cousues ensemble.')
            return
        if stale():
            refill()
            app.status.set('Le dessin a changé : la liste est refaite, cocher à nouveau.')
            return
        added = add_pairs(app, chosen)
        if added:
            app.status.set(f'{added} assemblage{"s" if added > 1 else ""} ajouté{"s" if added > 1 else ""} au contrôle du sac.')
        refill()

    def done():
        marks = app.__dict__.get('_bag_marks')
        if marks is not None:
            marks.pop('proposal', None)
            draw_bag(app)
        app.__dict__.pop('_proposal_window', None)
        win.destroy()
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Ajouter les paires cochées', add).pack(side='left')
    app.button(foot, 'Fermer', done).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win.bind('<FocusIn>', lambda e: refill() if e.widget is win and stale() else None)   # back from the plan, changed
    win._refill = refill
    win._table = table
    win._toggle = toggle
    win._add = add
    win._done = done
    win._state = state
    refill()
    return win


def montage_rows(app):
    """0.19.26: the bag's list in its order of montage: each pair checked again (check()) or a step (state 'etape', its
    text), each with its number n (1, 2, …: the same on the plan and on the fiche)."""
    pieces = _pieces(app, every=True)
    out = []
    for n, e in enumerate(entries(app), 1):
        if 'etape' in e:
            out.append(dict(state='etape', text=e['etape'], n=n, a=None, b=None, a_text=e['etape'], b_text='', lengths='', diff='', crans='',
                            minutes=e.get('minutes')))
        else:
            out.append(dict(check(app, e, pieces), n=n))
    return out


STEP_LONGEST = 200   # characters of a step


def clean_step(text):
    return ' '.join(''.join(ch if ch >= ' ' else ' ' for ch in str(text or '')).split())[:STEP_LONGEST]


STEPS_KEPT = 40   # 0.19.27: steps typed, kept for the other models (the last ones first)


def typed_steps(app):
    """0.19.27 (« « Étape… » propose les étapes déjà tapées dans tes autres modèles »): the steps he typed, in any model,
    the last ones first (preferences « montage_steps »)."""
    out = []
    for t in (app.__dict__.get('prefs') or {}).get('montage_steps') or ():
        t = clean_step(t) if isinstance(t, str) else ''
        if t and t not in out:
            out.append(t)
    return out[:STEPS_KEPT]


STEP_LONGEST_MINUTES = 10000.   # minutes of a step at most


def minutes_typed(text):
    """0.19.28: the minutes typed for a step (« 3 », « 2,5 »), None when nothing is typed (or 0: no time, as the prices
    of Réglages); ValueError when it is not a time."""
    text = str(text or '').strip().replace(',', '.')
    if not text:
        return None
    v = float(text)
    if not math.isfinite(v) or not 0 <= v <= STEP_LONGEST_MINUTES:
        raise ValueError(text)
    return round(v, 3) or None


def step_minutes(app):
    """0.19.28 (« un temps pour chaque étape, tapé une fois »): the minutes known for each step typed, any model (the
    preferences « step_minutes »)."""
    out = {}
    for t, v in ((app.__dict__.get('prefs') or {}).get('step_minutes') or {}).items():
        t = clean_step(t) if isinstance(t, str) else ''
        try:
            v = minutes_typed(v) if not isinstance(v, bool) else None
        except (TypeError, ValueError):
            v = None
        if t and v:
            out[t] = v
    return out


def remember_minutes(app, text, minutes):
    """The minutes of the step ``text`` kept for the other models (None: forgotten)."""
    prefs = app.__dict__.get('prefs')
    text = clean_step(text)
    if prefs is None or not text:
        return
    known = step_minutes(app)
    if (known.get(text) if minutes is None else minutes) is None or known.get(text) == minutes:
        return
    known.pop(text, None)
    if minutes is not None:
        known[text] = minutes   # (the last typed last: the oldest go first beyond 200)
    prefs['step_minutes'] = dict(list(known.items())[-200:])
    try:
        app.persist_preferences()
    except (OSError, AttributeError):
        pass


def minutes_shown(v):
    """minutes as typed back: up to 3 decimals (minutes_typed keeps 3), never in powers of ten"""
    return f'{v:.3f}'.rstrip('0').rstrip('.').replace('.', ',')


def ask_step(app, parent, text, minutes):
    """0.19.28: a step and its minutes changed (double-click in the bag's list): (text, minutes, the time touched: its
    field changed) or None."""
    from tkinter import messagebox
    win = app.dialog('Étape de montage')
    try:   # (second review: over the bag's window, not the main one)
        if parent is not None and parent.winfo_exists():
            win.transient(parent)
            win.geometry(f'+{parent.winfo_rootx() + 60}+{parent.winfo_rooty() + 80}')
    except tk.TclError:
        pass
    panel = app.p['panel']
    box = tk.Frame(win, bg=panel)
    box.pack(fill='x', padx=16, pady=(14, 6))
    shown = minutes_shown(minutes) if minutes else ''   # (review: exactly as kept)
    words, time = tk.StringVar(value=text), tk.StringVar(value=shown)
    app.label(box, 'Étape').grid(row=0, column=0, sticky='w')
    first = app.entry(box, words, 44)
    first.grid(row=0, column=1, sticky='we', padx=8)
    app.label(box, 'Temps (min)').grid(row=1, column=0, sticky='w', pady=(6, 0))
    app.entry(box, time, 7).grid(row=1, column=1, sticky='w', padx=8, pady=(6, 0))
    answer = []

    def ok(e=None):
        try:
            m = minutes_typed(time.get())
        except ValueError:
            messagebox.showerror('Étape de montage', 'Temps : un nombre de minutes (0 à 10 000), ou rien.', parent=win)
            return 'break'
        if clean_step(words.get()):
            answer.append((clean_step(words.get()), m, time.get().strip() != shown))
        win.destroy()
        return 'break'
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(6, 14))
    holder = tk.Frame(foot, bg=panel)
    holder.pack(side='right')
    valid = app.button(holder, 'Valider', ok)
    valid.pack(side='left')
    cancel = app.button(holder, 'Annuler', win.destroy)
    cancel.pack(side='left', padx=(6, 0))

    def enter(e=None):
        """Entrée: Valider, or « Annuler » when it has the focus (second review: Tab then Entrée validated)"""
        try:
            focus = win.focus_get()
        except (tk.TclError, KeyError):
            focus = None
        if focus is cancel:
            win.destroy()
            return 'break'
        return ok()
    for sequence in ('<Return>', '<KP_Enter>'):
        win.bind(sequence, enter)
    win.bind('<Escape>', lambda e: win.destroy())
    win._words, win._time, win._ok, win._enter, win._cancel = words, time, ok, enter, cancel   # (essais)
    app._step_dialog = win
    first.focus_set()
    app.wait_window(win)
    return answer[0] if answer else None


def remember_steps(app, texts, forget=False):
    """The steps ``texts`` kept first among the steps typed (``forget``: taken out), in the preferences."""
    prefs = app.__dict__.get('prefs')
    if prefs is None:
        return
    texts = [t for t in (clean_step(x) for x in texts) if t]
    kept = typed_steps(app)
    new = [t for t in kept if t not in texts] if forget else (texts + [t for t in kept if t not in texts])[:STEPS_KEPT]
    if new != kept:
        prefs['montage_steps'] = new
        try:
            app.persist_preferences()
        except (OSError, AttributeError):
            pass


def steps_proposed(app, rows=None):
    """0.19.26 (« il y a les étapes inter à prendre en compte »): the steps Craft sees on the pieces of the pairs kept,
    each with where it goes, before the first pair of its piece: [(text, its place in the list)]. For each piece, in this
    order: its parages (« FACE : parage rembord 7 »), its renforts and doublures by their names (« RENFORT FACE : coller
    sur FACE »), its surcoupe (a piece in a précoupe), its rembordé (a parage rembord), its teinture; before a pair with
    a jonc, « FACE / CAVOUR : poser le jonc ». A step already in the list is not proposed again. 0.19.29 ``rows``: the
    list to see them for (the Montage auto's), else the bag's."""
    import surcoupe
    from craft_tools import style
    rows = entries(app) if rows is None else rows
    have = {e['etape'] for e in rows if 'etape' in e}
    pieces = _pieces(app, every=True)
    names = piece_names(app, True)   # 0.19.27: read once
    first = {}   # piece (its key in the pairs) -> the place of its first pair in the list
    for i, e in enumerate(rows):
        if 'a' in e:
            for edge in [e['a'], e['b']] + list(e.get('more') or ()):   # (0.19.36 review: a fond mexicain's fond too)
                first.setdefault(edge['piece'], i)
    out = []

    def add(text, at):
        text = clean_step(text)
        if text and text not in have and all(text != t for t, _ in out):
            out.append((text, at))
    for key, at in sorted(first.items(), key=lambda kv: kv[1]):
        k = piece_index(app, key, pieces)
        if k is None:
            continue
        piece = app.items[k]
        name = _name(host(app, k)) or 'Pièce'
        owners = {piece.get('piece_id'), piece.get('owner_id'), host(app, k).get('piece_id')} - {None}
        zones = [q['preparation'] for q in app.items if isinstance(q.get('preparation'), dict) and q.get('owner_id') in owners]
        rembord = False
        for z in zones:
            if z.get('kind') == 'parage':
                add(f'{name} : {str(z.get("label") or "parage").strip().lower()}', at)
                rembord = rembord or 'REMBORD' in str(z.get('type') or '').upper()
        for j, layer, _ in layers(app, k, True, names):
            if _known_key(app, j, True) not in first:   # (a doublure sewn to the lining's other pieces: assembled, not glued)
                add(f'{layer} : coller sur {name}', at)
        if piece.get('owner_id') and not piece.get('piece_id') and style(piece)['role'] == surcoupe.ROLE:
            add(f'{name} : surcoupe', at)
        if rembord:
            add(f'{name} : rembordé', at)
        if any(z.get('kind') == 'teinte' for z in zones):
            add(f'{name} : teinture', at)
    for i, e in enumerate(rows):
        found = [piece_index(app, e[x]['piece'], pieces) for x in ('a', 'b')] if 'a' in e else None
        if found and (is_jonc(e) or e.get('seam') is None and None not in found and any(piping(app, k) for k in found)):
            if None not in found:   # (0.19.36: the pair with the jonc itself too: its 5 mm by itself)   # (second review: the seam it goes in, by both pieces, the larger first: FACE / CAVOUR)
                found.sort(key=lambda k: -_area(host(app, k)))
                add(' / '.join(_name(host(app, k)) or 'Pièce' for k in found) + ' : poser le jonc', i)
    if first:   # 0.19.29: at the end, the montage's own: a piqué retourné is turned; a piqûre extérieure on leather in bord
        if piqure(app) == 'retourne' or any(e.get('retourne') for e in rows if 'a' in e):   # franc has its tranches dyed
            add('Retourner le sac', len(rows))   # (« si rembordé … sinon c'est bord franc »; a fond rapporté piqué retourné)
        elif any(not fabric(app, k) and not rembord_width(app, k, portion(app, (k, e_sides(e[x])))[0])
                 for e in rows if 'a' in e for x in ('a', 'b')
                 for k in [piece_index(app, e[x]['piece'], pieces)] if k is not None and _sides_there(app, k, e[x])):
            add('Teinter les tranches', len(rows))
    return out


def _sides_there(app, k, edge):
    """the sides of ``edge`` are still those of piece ``k`` (its pair not « à refaire »)"""
    try:
        return len(sides(app.items[k])[0]) == edge['count'] and max(edge['sides']) < edge['count']
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        return False


def _area(s):
    from geometry import outline_area
    try:
        return abs(outline_area(s['points'], s.get('bulges') or [0.] * len(s['points'])))
    except (KeyError, TypeError, ValueError, ZeroDivisionError, IndexError):
        return 0.


def insert_steps(app, steps):
    """0.19.26: the steps [(text, place: before the line at that place in the list, None: at the end[, 0.19.28: its
    minutes])] put in the bag's list (several at one place: in their order; a step typed twice is put twice: review,
    « Encoller » before two seams); the line chosen in the bag's list stays the same line. The number put."""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    rows = entries(app)
    chosen = []
    for order, step in enumerate(steps):
        text, at, minutes = (tuple(step) + (None,))[:3]   # (0.19.28: its minutes too)
        text = clean_step(text)
        if text:
            chosen.append((len(rows) if at is None else min(max(0, at), len(rows)), order, text, minutes))
    for at, _, text, minutes in sorted(chosen, key=lambda c: c[:2], reverse=True):
        rows.insert(at, dict(etape=text, **({'minutes': minutes} if minutes else {})))
    if chosen:
        marks = app.__dict__.get('_bag_marks')
        if marks and marks.get('chosen') is not None:   # (review: the same line chosen, below the steps put above it)
            marks['chosen'] += sum(1 for at, _, _, _ in chosen if at <= marks['chosen'])
        _store(app, rows)
        win = app.__dict__.get('_bag_window')
        if win is not None and win.winfo_exists():
            win._refill()
    return len(chosen)


def steps_window(app, after=None):
    """0.19.26 « Étape… » (Contrôle d'assemblage du sac): a step typed, put after the line chosen in the list (or at its
    end); the steps Craft proposes (steps_proposed) to tick, each put before the first pair of its piece; 0.19.27: the
    steps he typed before, in this model or another (typed_steps), to tick too, put after the line chosen as typed;
    « Oublier » takes the one chosen out of them."""
    from tkinter import ttk
    old = app.__dict__.get('_steps_window')
    if old is not None and old.winfo_exists():
        old._after = after
        old._refill()
        old.lift()
        return old
    win = app.dialog('Étape de montage')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._steps_window = win
    win._after = after
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    line = tk.Frame(win, bg=panel)
    line.pack(fill='x', padx=14, pady=(12, 4))
    app.label(line, 'Étape').pack(side='left')
    typed = tk.StringVar()
    entry = app.entry(line, typed, 44)
    entry.pack(side='left', padx=8, fill='x', expand=True)
    time = tk.StringVar()   # 0.19.28: its minutes (kept with the step for the other models)
    app.label(line, 'Temps (min)').pack(side='left')
    time_entry = app.entry(line, time, 6)
    time_entry.pack(side='left', padx=(8, 0))
    head = tk.StringVar()
    tk.Label(win, textvariable=head, bg=panel, fg=ink, font=('Segoe UI', 9), justify='left', wraplength=520).pack(anchor='w', padx=14, pady=(4, 2))
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    table = ttk.Treeview(area, columns=('tick', 'text', 'min', 'from'), show='headings', height=8, selectmode='browse')
    table.heading('tick', text='')
    table.heading('text', text='Étapes proposées')
    table.heading('min', text='Min.')
    table.heading('from', text='Origine')
    table.column('tick', width=24, anchor='center', stretch=False)
    table.column('text', width=380, anchor='w', stretch=True)
    table.column('min', width=50, anchor='center', stretch=False)
    table.column('from', width=110, anchor='w', stretch=False)
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')
    state = dict(rows=[], ticked=set())

    def refill():
        seen = steps_proposed(app)
        have = {e['etape'] for e in entries(app) if 'etape' in e} | {t for t, _ in seen}
        state['rows'] = seen + [(t, None) for t in typed_steps(app) if t not in have]   # 0.19.27 (None: as typed)
        state['ticked'] = set()
        table.delete(*table.get_children())
        known = step_minutes(app)
        for n, (text, at) in enumerate(state['rows']):
            table.insert('', 'end', iid=str(n), values=('☐', text, _mm(known[text], 2) if text in known else '',
                                                        'sur les pièces' if at is not None else 'déjà tapée'))
        head.set('Taper une étape (elle va après la ligne choisie dans la liste du sac), ou cocher celles proposées : vues sur les '
                 'pièces (chacune avant le premier assemblage de sa pièce), déjà tapées (après la ligne choisie) ; l’ordre se '
                 'règle ensuite avec ▲ ▼.'
                 if state['rows'] else 'Taper une étape : elle va après la ligne choisie dans la liste du sac ; l’ordre se règle '
                 'ensuite avec ▲ ▼.')

    def toggle(n):
        state['ticked'] ^= {n}
        table.set(str(n), 'tick', '☑' if n in state['ticked'] else '☐')

    def clicked(e):
        row = table.identify_row(e.y)
        if row and table.identify_column(e.x) == '#1':
            toggle(int(row))

    def double(e):
        if table.identify_column(e.x) == '#1':
            return 'break'
        sel = table.selection()
        if sel:
            toggle(int(sel[0]))
        return 'break'
    table.bind('<Button-1>', clicked, add='+')
    table.bind('<Double-1>', double)

    def line_chosen():
        """the line chosen in the bag's list now (review: not when this window was opened)"""
        bag = app.__dict__.get('_bag_window')
        if bag is not None and bag.winfo_exists():
            picked = bag._table.selection()
            return int(picked[0]) if picked else None
        return win._after

    def add(e=None):
        text = clean_step(typed.get())
        try:
            minutes = minutes_typed(time.get())   # 0.19.28 (review: « 0 » typed is no time, never the one remembered)
            given = bool(time.get().strip())
        except ValueError:
            app.status.set('Temps : un nombre de minutes (0 à 10 000), ou rien.')
            return 'break' if e is not None else None
        rows = entries(app)
        known = step_minutes(app)
        steps = []
        at = line_chosen()
        after = len(rows) if at is None or at >= len(rows) else at + 1
        if text:
            steps.append((text, after, minutes if given else known.get(text)))   # (typed once: kept for the others)
        fresh = dict(steps_proposed(app))   # (review: where they go in the list as it is now; already put: not again)
        have = {r['etape'] for r in rows if 'etape' in r}
        used = [text] if text else []
        for n in sorted(state['ticked']):
            t, where = state['rows'][n]
            if where is None:   # 0.19.27: typed before: after the line chosen, as typed (not when in the list already)
                if t not in have and t != text:
                    steps.append((t, after, known.get(t)))
                    used.append(t)
            elif t in fresh:
                steps.append((t, fresh[t], known.get(t)))
        if not steps:
            app.status.set('Ces étapes sont déjà dans la liste.' if state['ticked'] else 'Taper une étape, ou cocher celles proposées.')
            refill()
            return 'break' if e is not None else None
        put = insert_steps(app, steps)
        if put:
            typed.set('')
            time.set('')
            app.status.set(f'{put} étape{"s" if put > 1 else ""} dans la liste du sac.')
            if used:
                remember_steps(app, used)   # 0.19.27: for the other models (the last used first)
            if text and minutes:
                remember_minutes(app, text, minutes)   # 0.19.28: its time too
        refill()
        return 'break' if e is not None else None
    entry.bind('<Return>', add)
    time_entry.bind('<Return>', add)

    def forget():
        """0.19.27: the step typed before chosen in the list taken out of the steps kept"""
        sel = table.selection()
        row = state['rows'][int(sel[0])] if sel else None
        if row is not None and row[1] is not None and row[0] in step_minutes(app):   # 0.19.28 (second review): one seen
            remember_minutes(app, row[0], None)   # on the pieces, its time remembered: that time forgotten
            app.status.set(f'Temps oublié : {row[0]}')
            refill()
            return
        if row is None or row[1] is not None:
            app.status.set('Choisir une étape « déjà tapée » (ou avec un temps retenu) à oublier.')
            return
        remember_steps(app, [row[0]], forget=True)
        remember_minutes(app, row[0], None)   # 0.19.28: its time too
        app.status.set(f'Étape oubliée : {row[0]}')
        refill()

    def done():
        app.__dict__.pop('_steps_window', None)
        win.destroy()
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Ajouter', add).pack(side='left')
    app.button(foot, 'Oublier', forget, kind='secondary').pack(side='left', padx=6)   # 0.19.27
    app.button(foot, 'Fermer', done).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win._refill = refill
    win._table = table
    win._toggle = toggle
    win._typed = typed
    win._time = time
    win._add = add
    win._forget = forget
    win._done = done
    win._state = state
    refill()
    entry.focus_set()
    return win


def bag(app):
    """Exporter › Contrôle d'assemblage du sac…: every pair kept, checked again at once. 0.19.26: the list is the order of
    montage (▲ ▼), with the steps between the seams (« Étape… »), numbered the same on the plan and on the fiche."""
    from tkinter import ttk
    old = app.__dict__.get('_bag_window')
    if old is not None and old.winfo_exists():
        old._refill()
        old.lift()
        return old
    win = app.dialog('Contrôle d’assemblage du sac')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):   # opened from a tool: stays open after it (Échap, Annuler, the next check)
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._bag_window = win
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    app.label(win, 'Chaque Contrôle d’assemblage fait est gardé avec le modèle ; ici, tous contrôlés d’un coup, à la couture, dans '
                   'l’ordre de montage (▲ ▼). Double-clic : ouvrir ce contrôle, ou changer l’étape.').pack(anchor='w', padx=14, pady=(12, 2))
    if app.__dict__.get('mozart_source') and not app.__dict__.get('filename'):   # a DWG Mozart cannot keep them
        app.label(win, 'DWG Mozart : la liste est gardée tant qu’il est ouvert ; Enregistrer sous… (.crft) la garde avec le modèle.').pack(anchor='w', padx=14, pady=(0, 2))
    import montage_auto
    kind_row = tk.Frame(win, bg=panel)   # 0.19.29: the bag's type, the Montage auto, the gammes, the piqûre of the model
    kind_row.pack(fill='x', padx=14, pady=(4, 0))
    kind_text = tk.StringVar()
    tk.Label(kind_row, textvariable=kind_text, bg=panel, fg=ink, font=('Segoe UI', 9), justify='left', wraplength=520).pack(side='left')
    app.button(kind_row, 'Gamme…', lambda: montage_auto.gamme_window(app), kind='secondary').pack(side='right')
    app.button(kind_row, 'Montage auto…', lambda: montage_auto.window(app), kind='secondary').pack(side='right', padx=6)
    piqure = montage_auto.piqure_row(app, win, lambda: refill())
    piqure.pack(anchor='w', padx=14, pady=(2, 0))
    head = tk.StringVar()
    tk.Label(win, textvariable=head, bg=panel, fg=ink, font=('Segoe UI', 10, 'bold'), justify='left').pack(anchor='w', padx=14, pady=2)
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    columns = (('n', 'N°', 4), ('a', 'Bord 1 · étape', 26), ('b', 'Bord 2', 22), ('seam', 'Couture', 8), ('len', 'Longueurs (mm)', 14),
               ('diff', 'Écart (mm)', 9), ('crans', 'Crans en face', 12), ('state', 'État', 26))
    table = ttk.Treeview(area, columns=[k for k, _, _ in columns], show='headings', height=11, selectmode='browse')
    for key, label, width in columns:
        table.heading(key, text=label)
        table.column(key, width=width * 7, anchor='center' if key == 'n' else 'w', stretch=key in ('a', 'b', 'state'))
    for state, colour in COLOUR.items():
        table.tag_configure(state, foreground=colour)
    table.tag_configure('etape', foreground=ink)
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    moves = tk.Frame(area, bg=panel)
    moves.pack(side='right', fill='y', padx=(6, 0))
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='left', fill='y')
    marks = app.__dict__.setdefault('_bag_marks', {})

    def refill():
        rows = montage_rows(app)
        marks.update(rows=rows, key=_fingerprint(app))
        try:
            kind_text.set(montage_auto.type_text(app))
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            kind_text.set('')
        piqure._var.set(piqure_of(app))
        chosen = marks.get('chosen')
        if chosen is not None and chosen >= len(rows):
            marks['chosen'] = chosen = None
        table.delete(*table.get_children())
        for n, r in enumerate(rows):
            if r['state'] == 'etape':
                table.insert('', 'end', iid=str(n), values=(r['n'], r['text'], '', '', '', '', '', 'étape' + (f' · {_mm(r["minutes"], 2)} min' if r.get('minutes') else '')),
                             tags=('etape',))
            else:
                table.insert('', 'end', iid=str(n), values=(r['n'], r['a_text'], r['b_text'], seam_text(r['seam'], r.get('seam_kind')), r['lengths'], r['diff'],
                                                            r['crans'], r['text']), tags=(r['state'],))
        if chosen is not None:
            table.selection_set(str(chosen))
            table.see(str(chosen))
        pairs = [r for r in rows if r['state'] != 'etape']
        count = {s: sum(1 for r in pairs if r['state'] == s) for s in COLOUR}
        steps = len(rows) - len(pairs)
        speed = sewing_prefs(app)[1]   # 0.19.28: the time of the montage, when known (as the fiche counts it)
        minutes = sum(r['minutes'] for r in rows if r['state'] == 'etape' and r.get('minutes')) + (
            sum(max(r['la'], r['lb']) for r in pairs if r['state'] in ('ok', 'bad', 'crans') and r.get('la') is not None
                and r.get('lb') is not None) / 10 / speed if speed else 0.)
        timed = f' ; montage ≈ {__import__("fiches").minutes_text(minutes)}' if minutes else ''
        if not pairs:
            head.set('Aucun assemblage gardé : « Paires probables… » (bords de même longueur aux crans en face), ou « Ajouter un '
                     'assemblage » puis cliquer les deux bords cousus ensemble.'
                     + (f' {steps} étape{"s" if steps > 1 else ""}{timed}.' if steps else ''))   # (review: steps alone, their time)
        else:
            parts = [f'{count["ok"]} bon{"s" if count["ok"] > 1 else ""}']
            if count['bad']:
                parts.append(f'{count["bad"]} avec un écart de plus de 0,5 mm')
            if count['crans']:
                parts.append(f'{count["crans"]} aux crans pas tous en face')
            if count['gone'] + count['changed']:
                parts.append(f'{count["gone"] + count["changed"]} à refaire')
            head.set(f'{len(pairs)} assemblage{"s" if len(pairs) > 1 else ""} : ' + ', '.join(parts)
                     + (f' ; {steps} étape{"s" if steps > 1 else ""} entre eux' if steps else '') + timed + '.')
        draw_bag(app)

    def chosen_row():
        picked = table.selection()
        return int(picked[0]) if picked else None

    def picked(e=None):
        n = chosen_row()
        again = n == marks.get('chosen')   # (second review: the list made again chose it again: what the status says stays)
        marks['chosen'] = n
        draw_bag(app)
        if not again and n is not None and n < len(marks.get('rows') or ()):
            r = marks['rows'][n]
            if r['state'] == 'etape':
                app.status.set(f'Étape {r["n"]} : {r["text"]}')
            else:
                app.status.set(f'{r["n"]}. {r["a_text"]} ↔ {r["b_text"]} : ' + (f'{r["lengths"]} mm {seam_words(r["seam"], r.get("seam_kind"))}, écart {r["diff"]}, crans {r["crans"]} · ' if r['lengths'] else '') + r['text'].lstrip('✓✗⚠— '))
    table.bind('<<TreeviewSelect>>', picked)

    def writable():
        if hasattr(app, 'licence_complet') and not app.licence_complet():
            app.read_only_said()
            return False
        return True

    def opened(e=None):
        n = chosen_row()
        rows = entries(app)
        if n is None or n >= len(rows):
            return 'break'
        if 'etape' in rows[n]:   # a step: its text changed (0.19.28: its minutes too)
            if not writable():
                return 'break'
            old_text, old_minutes = rows[n]['etape'], rows[n].get('minutes')
            got = ask_step(app, win, old_text, old_minutes)
            if got is None:
                return 'break'
            text, minutes, touched = (tuple(got) + (True,))[:3]
            if not touched:   # (review: renamed, its time as it was, or the one remembered for its new text)
                minutes = old_minutes or (step_minutes(app).get(text) if text != old_text else None)
            if text != old_text or minutes != old_minutes:
                if text != old_text:
                    remember_steps(app, [text])   # 0.19.27 (second review: only a step changed, typed by him)
                rows[n] = dict(etape=text, **({'minutes': minutes} if minutes else {}))
                _store(app, rows)
                if minutes and (touched or text not in step_minutes(app)):   # (second review: never over one typed before)
                    remember_minutes(app, text, minutes)   # 0.19.28: its time, for the other models
                refill()
            return 'break'
        if not open_pair(app, rows[n]):
            app.status.set('Pièce introuvable ou côtés changés : refaire ce contrôle (Ajouter un assemblage), puis retirer celui-ci.')
        return 'break'
    table.bind('<Double-1>', opened)

    def moved(step):
        """▲ ▼: the line chosen one place up or down in the order of montage"""
        if not writable():
            return
        n = chosen_row()
        rows = entries(app)
        if n is None or n >= len(rows):
            app.status.set('Choisir dans la liste la ligne à monter ou descendre.')
            return
        m = n + step
        if not 0 <= m < len(rows):
            return
        rows[n], rows[m] = rows[m], rows[n]
        marks['chosen'] = m
        _store(app, rows)
        refill()
    app.button(moves, '▲', lambda: moved(-1), kind='secondary').pack(fill='x', pady=(0, 4))
    app.button(moves, '▼', lambda: moved(1), kind='secondary').pack(fill='x')

    def removed():
        if not writable():
            return
        n = chosen_row()
        rows = entries(app)
        if n is None or n >= len(rows):
            app.status.set('Choisir dans la liste l’assemblage ou l’étape à retirer.')
            return
        gone = rows.pop(n)
        st = app.__dict__.get('assembly_state')
        if 'a' in gone and st and st.get('kept') == _ident(gone):   # (review: only the check whose pair it was forgets it)
            st.update(kept=None, added=False)
        marks['chosen'] = None
        _store(app, rows)
        refill()
        app.status.set('Étape retirée de la liste.' if 'etape' in gone else 'Assemblage retiré de la liste.')

    def added():
        start(app)
        app.status.set('Contrôle d’assemblage : cliquer le bord de la 1re pièce, puis le bord cousu dessus (gardé dans la liste du sac).')

    def step():
        """0.19.26 « Étape… »: a step between the seams"""
        if writable():
            steps_window(app, chosen_row())

    def fiche():
        """0.19.25: the fiche « Montage » (« Assemblages ») in its tab at the bottom (the list, to print)."""
        if not entries(app):
            app.status.set('Aucun assemblage gardé : rien à mettre sur la fiche.')
            return
        if hasattr(app, 'add_fiche'):
            app.add_fiche('fiche:assemblages')

    def done():
        for name in ('_proposal_window', '_steps_window', '_montage_window', '_gamme_window'):
            other = app.__dict__.get(name)
            if other is not None and other.winfo_exists():
                other._done()
        clear_bag(app)
        win.destroy()
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Ajouter un assemblage', added).pack(side='left')
    app.button(foot, 'Paires probables…', lambda: propose(app), kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.25
    app.button(foot, 'Étape…', step, kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.26
    app.button(foot, 'Crans en face', lambda: writable() and crans_in_front_bag(app), kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.27
    app.button(foot, 'Ajuster', lambda: writable() and adjust_bag(app), kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.30: every pair with an écart
    app.button(foot, 'Retirer de la liste', removed, kind='secondary').pack(side='left', padx=6)
    app.button(foot, 'Fermer', done).pack(side='right')
    app.button(foot, 'Fiche', fiche, kind='secondary').pack(side='right', padx=6)   # 0.19.25: the fiche « Montage »
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win.bind('<FocusIn>', lambda e: refill() if e.widget is win else None)   # back from the plan: checked again
    win._refill = refill
    win._table = table
    win._removed = removed
    win._opened = opened
    win._moved = moved
    win._step = step
    win._done = done
    win._head = head
    win._fiche = fiche
    win._kind_text = kind_text
    win._piqure = piqure._var
    refill()
    return win
