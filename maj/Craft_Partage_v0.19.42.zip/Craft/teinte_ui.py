"""0.19.39 « Teinte des bords » (« bien ajoute », 17/11/2026: the teinte in one click, proposed with 0.19.36).

A click on a side of a piece (Coupe externe, or a piece inside its précoupe) dyes it: a line of the « Préparation » type
``distance`` mm outside the side (3 mm: his RIDER, « lignes décalées de 3 mm à l'extérieur du bord teint ») and the zone
Teinte between the side and that line (« pas la pièce entière »), both attached to the piece (they move, turn, are copied
and are hidden with it). Each click adds a side: sides that follow one another make one band (its line mitred round their
corners as Décaler makes it, its ends square to the side); a click on a side already dyed takes it off; a double-click
dyes the whole piece round (one closed line). Another distance typed + Entrée (2 for Mozart's), right click: distance and
couches. The zone keeps the sides it dyes (``sides``, ``count``: how many sides the piece had then) and its line the same
``band`` as the zone: only those bands are joined, taken off and follow the piece reshaped (refit); a side under a zone
made otherwise (by hand, from Mozart) is said, never dyed twice."""
import math
import uuid
import copy
import tkinter as tk
from tkinter import messagebox

import preparations as prep

DEFAULTS = dict(distance=3., couches=1)
TAG = 'teinte_preview'
GEOMETRY = ('kind', 'x', 'y', 'w', 'h', 'r', 'points', 'closed', 'bulges', 'components', 'spline', 'ellipse', 'reversed')
PROBE = .05   # mm: a point just off a side, to know its outside


def settings(app):
    saved = (getattr(app, 'prefs', None) or {}).get('teinte_bords')
    out = dict(DEFAULTS)
    if isinstance(saved, dict):
        try:
            d = float(saved.get('distance', out['distance']))
            if math.isfinite(d) and .1 <= d <= 50:
                out['distance'] = d
        except (TypeError, ValueError):
            pass
        c = saved.get('couches')
        if isinstance(c, int) and not isinstance(c, bool) and 1 <= c <= 20:
            out['couches'] = c
    return out


def keep(app, **changes):
    st = settings(app)
    st.update(changes)
    app.prefs['teinte_bords'] = st
    try:
        app.persist_preferences()
    except OSError:
        pass


def fmt(v):
    return f'{v:.2f}'.rstrip('0').rstrip('.').replace('.', ',')


# ---------------------------------------------------------------- the geometry

def sides(piece):
    from assembly_ui import sides as cut
    return cut(piece)


def owner(app, k, make=False):
    """The piece id the bands of contour ``k`` are attached to: its own; a piece inside its précoupe (no id of its own):
    the précoupe's, which carries its data (assembly_ui.host), as the Préparation tool attaches its zones."""
    s = app.items[k]
    if s.get('piece_id') or not s.get('owner_id'):
        if make:
            from entity_rules import ensure_piece_id
            return ensure_piece_id(s)
        return s.get('piece_id')
    return s['owner_id']


def _halfway(pts):
    """The point half way along a run of points and the direction of the run there."""
    half = sum(math.dist(a, b) for a, b in zip(pts, pts[1:])) / 2
    for a, b in zip(pts, pts[1:]):
        L = math.dist(a, b)
        if L >= half and L > 1e-12:
            t = half / L
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t), ((b[0] - a[0]) / L, (b[1] - a[1]) / L)
        half -= L
    a, b = pts[-2], pts[-1]
    L = math.dist(a, b) or 1.
    return b, ((b[0] - a[0]) / L, (b[1] - a[1]) / L)


def outward(piece, run):
    """(the middle of a side, the unit normal pointing out of the piece there)."""
    from precision_geometry import inside
    m, (ux, uy) = _halfway(run)
    n = (-uy, ux)
    if inside(piece, (m[0] + n[0] * PROBE, m[1] + n[1] * PROBE)):
        n = (uy, -ux)
    return m, n


def groups(ids, n):
    """The sides ``ids`` cut into runs that follow one another (round the closing corner too)."""
    ids = sorted({i for i in ids if 0 <= i < n})
    if len(ids) == n:
        return [list(range(n))] if n else []
    out = []
    for i in ids:
        if out and i == out[-1][-1] + 1:
            out[-1].append(i)
        else:
            out.append([i])
    if len(out) > 1 and out[0][0] == 0 and out[-1][-1] == n - 1:
        out[0] = out.pop() + out[0]
    return out


# 0.19.42 (« la bande s'arrête au début de l'arrondi », GO 18/11/2026 16 h 10): a band can stop inside a side. An Arrondi
# between a dyed side and one not dyed makes one side of the three (the round is tangent to both): the band keeps what it
# dyed and stops where the round starts. Such a band keeps where it starts and ends (``part``: [[side, f], [side, f]], f a
# part of the side's length, along the contour), never the whole sides it touches.
ON = 1e-4      # mm: a point of the piece reshaped still on its contour before (an Arrondi leaves the rest where it was)
NEAR = .05     # mm: a chord of the piece reshaped along its contour before (the middle of a chord of an arc is off it)


def _length(run):
    return sum(math.dist(a, b) for a, b in zip(run, run[1:]))


def _walk(run, d):
    """The point ``d`` mm along a run of points."""
    for a, b in zip(run, run[1:]):
        L = math.dist(a, b)
        if d <= L and L > 1e-12:
            t = max(0., d) / L
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        d -= L
    return tuple(run[-1])


def _sub(run, f0, f1):
    """The points of a run from ``f0`` to ``f1`` (parts of its length, f0 <= f1)."""
    total = _length(run)
    lo, hi = max(0., min(1., f0)) * total, max(0., min(1., f1)) * total
    out = [_walk(run, lo)]
    travel = 0.
    for a, b in zip(run, run[1:]):
        travel += math.dist(a, b)
        if lo + 1e-9 < travel < hi - 1e-9:
            out.append(tuple(b))
    out.append(_walk(run, hi))
    return out


def _fraction(run, p):
    """(where ``p`` falls along a run, a part of its length; how far from it)."""
    total = _length(run)
    best, travel = (math.inf, 0.), 0.
    for a, b in zip(run, run[1:]):
        dx, dy = b[0] - a[0], b[1] - a[1]
        L2 = dx * dx + dy * dy
        t = 0. if L2 <= 0 else max(0., min(1., ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
        d = math.dist(p, (a[0] + t * dx, a[1] + t * dy))
        if d < best[0] - 1e-12:
            best = (d, travel + t * math.sqrt(L2))
        travel += math.sqrt(L2)
    return (min(1., max(0., best[1] / total)) if total > 1e-12 else 0.), best[0]


def _part(value, n):
    """A band's ``part`` when it is one for a piece of ``n`` sides, else None."""
    try:
        (ia, fa), (ib, fb) = value
    except (TypeError, ValueError):
        return None
    if not all(isinstance(i, int) and not isinstance(i, bool) and 0 <= i < n for i in (ia, ib)):
        return None
    if not all(isinstance(f, (int, float)) and not isinstance(f, bool) and -1e-9 <= f <= 1 + 1e-9 for f in (fa, fb)):
        return None
    return [[ia, min(1., max(0., float(fa)))], [ib, min(1., max(0., float(fb)))]]


def _pieces(part, n):
    """A part as [(side, f0, f1)] in the order of the contour (the sides it only touches at a corner left out)."""
    (ia, fa), (ib, fb) = part
    if ia == ib and fa <= fb:
        out = [(ia, fa, fb)]
    else:
        out = [(ia, fa, 1.)]
        j = (ia + 1) % n
        while j != ib:
            out.append((j, 0., 1.))
            j = (j + 1) % n
        out.append((ib, 0., fb))
    kept = [q for q in out if q[2] - q[1] > 1e-9]
    return kept or out[:1]


def _part_points(runs, part):
    pts = []
    for j, f0, f1 in _pieces(part, len(runs)):
        sub = _sub(runs[j][0], f0, f1)
        pts += sub if not pts else sub[1:]
    return pts


def _chains(pieces, n):
    """Pieces (side, f0, f1) put together where they follow one another, in the order of the contour: [(part, whole,
    sides)], ``whole`` when the chain runs from a corner to a corner (its band made on its sides as before)."""
    per = {}
    for j, f0, f1 in pieces:
        if f1 - f0 > 1e-9:
            per.setdefault(j, []).append([f0, f1])
    segs = []
    for j in sorted(per):
        ivs = sorted(per[j])
        merged = [ivs[0]]
        for a, b in ivs[1:]:
            if a <= merged[-1][1] + 1e-9:
                merged[-1][1] = max(merged[-1][1], b)
            else:
                merged.append([a, b])
        segs += [(j, a, b) for a, b in merged]
    chains = []
    for s in segs:
        last = chains[-1][-1] if chains else None
        if last is not None and last[2] >= 1 - 1e-9 and s[1] <= 1e-9 and s[0] == (last[0] + 1) % n:
            chains[-1].append(s)
        else:
            chains.append([s])
    if len(chains) > 1 and chains[-1][-1][2] >= 1 - 1e-9 and chains[0][0][1] <= 1e-9 \
            and chains[0][0][0] == (chains[-1][-1][0] + 1) % n:
        chains[0] = chains.pop() + chains[0]
    return [([[c[0][0], c[0][1]], [c[-1][0], c[-1][2]]], c[0][1] <= 1e-9 and c[-1][2] >= 1 - 1e-9, [s[0] for s in c])
            for c in chains]


def _touches(b, i, n):
    """A band ending at the corner before side ``i`` or starting at the one after it."""
    first, last = b['pieces'][0], b['pieces'][-1]
    return (last[0] == (i - 1) % n and last[2] >= 1 - 1e-9) or (first[0] == (i + 1) % n and first[1] <= 1e-9)


def _still_on(piece, run):
    """(review) The first point of ``run`` on the contour of ``piece`` and how far along ``run`` it is: (point, 0) when
    its start is on it, None when no point is (the run moved away with its side)."""
    from precision_geometry import contour_location

    def off(p):
        try:
            return math.dist(p, contour_location(piece, p)[1]) > 1e-6
        except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
            return False
    if not off(run[0]):
        return tuple(run[0]), 0.
    total = _length(run)
    steps = min(400, max(8, int(total / .25)))
    lo = 0.
    for k in range(1, steps + 1):
        hi = total * k / steps
        if not off(_walk(run, hi)):
            for _ in range(40):
                mid = (lo + hi) / 2
                if off(_walk(run, mid)):
                    lo = mid
                else:
                    hi = mid
            q = _walk(run, hi)
            # (a round is tangent to the side: a point a few µm into it is « on » it too) the start of the round itself
            from geometry import path
            near = min(path(piece)[0], key=lambda v: math.dist(v, q))
            return (tuple(near), hi) if math.dist(near, q) < .05 else (q, hi)
        lo = hi
    return None


def _moved_part(before, after, part, new=None):
    """A band stopping inside a side, its piece reshaped with more or fewer sides: each end where it falls on the piece
    as it is (at a corner, the start on the side after it, the end on the side before it). [part]. (review) An end the
    reshape took away (``new``: an Arrondi or a Chanfrein on the corner where the band stops: its end went to the middle
    of the round): back along the band to where it is still on the piece (the start of the round); none left: []."""
    out = []
    run = _part_points(before, part) if new is not None else None
    kept = [None, None]
    if run is not None and len(run) > 1:
        pieces = _pieces(part, len(before))
        for end, piece in ((0, pieces[0]), (1, pieces[-1])):
            found = _still_on(new, run if end == 0 else run[::-1])
            # only back inside the side it ends on (a grip that moved that whole side: as before, where it falls)
            if found is not None and found[1] < (piece[2] - piece[1]) * _length(before[piece[0]][0]) - .01:
                kept[end] = found
        if all(kept) and kept[0][1] + kept[1][1] >= _length(run) - .01:
            return []   # (the band's sides taken away by the round)
    for end, (j, f) in enumerate(part):
        q = _walk(before[j][0], f * _length(before[j][0]))
        if kept[end] is not None:
            q = kept[end][0]
        best = None
        for w in range(len(after)):
            g, gap = _fraction(after[w][0], q)
            key = (round(gap, 6), g >= 1 - 1e-9 if end == 0 else g <= 1e-9)
            if best is None or key < best[0]:
                best = (key, w, g)
        if best is None:
            return []
        out.append([best[1], best[2]])
    return [out]


def _trimmed(old, before, after, dyed, ids):
    """The band's sides ``ids`` of the piece reshaped when one of them also runs on a side it did not dye: [part], the
    parts of them still on the sides ``dyed`` before (with what is new between two of them: a round between two dyed
    sides), never what is new at their ends (the round between a dyed side and one not dyed). None when none does (the
    band on its sides as before)."""
    from precision_geometry import contour_location
    undyed = [v for v in range(len(before)) if v not in dyed]
    found = groups(ids, len(after))
    if not undyed or len(found) != 1:
        return None
    seen = {}

    def on(p, tol):
        key = (round(p[0], 9), round(p[1], 9), tol)
        if key not in seen:
            try:
                seen[key] = math.dist(p, contour_location(old, p)[1]) < tol
            except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
                seen[key] = False
        return seen[key]

    def undyed_chord(a, b):
        m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        return on(a, ON) and on(b, ON) and on(m, NEAR) and \
            min(range(len(before)), key=lambda v: _fraction(before[v][0], m)[1]) not in dyed

    # (review: the middle of a side not dyed only: a round taking more than half of it (R 40 on a side of 60), or a
    # Chanfrein then an Arrondi on what is left of it, left the band on the round and on what was left of the side) also
    # 0,5 mm from each of its ends, and the first and last chords of the band's sides (what is left of it at their end)
    middles = []
    for v in undyed:
        run = before[v][0]
        L = _length(run)
        middles += [_walk(run, min(L / 2, .5)), _halfway(run)[0], _walk(run, max(L / 2, L - .5))]
    if not any(_fraction(after[w][0], m)[1] < NEAR for w in found[0] for m in middles) and \
            not any(len(after[w][0]) > 1 and (undyed_chord(*after[w][0][:2]) or undyed_chord(*after[w][0][-2:]))
                    for w in found[0]):
        return None

    marks = []
    for w in found[0]:
        run = after[w][0]
        total = _length(run)
        travel = 0.
        for a, b in zip(run, run[1:]):
            L = math.dist(a, b)
            if L <= 1e-12 or total <= 1e-12:
                continue
            m = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
            if on(a, ON) and on(b, ON) and on(m, NEAR):
                v = min(range(len(before)), key=lambda v: _fraction(before[v][0], m)[1])
                kind = 'dyed' if v in dyed else 'undyed'
            else:
                kind = 'new'
            # (review: the sum of the chords over the side's length came to 1.0000000000000002 at its end: the part refused
            # by _part, the band no longer known to the tool, nor written in a DWG Mozart)
            f0, f1 = min(1., travel / total), min(1., (travel + L) / total)
            travel += L
            if marks and marks[-1][0] == w and marks[-1][3] == kind:
                marks[-1][2] = f1
            else:
                marks.append([w, f0, f1, kind])
    if not any(mark[3] == 'undyed' for mark in marks):
        return None   # (a probe near a corner only: the band on its sides as before)
    if len(found[0]) == len(after):
        # (review: a band round two corners (left, bottom, right), then an Arrondi between its end and the side not dyed:
        # its sides are all the sides of the piece, read from the first one: the band cut at the contour's first corner,
        # two bands, the mitre of that corner lost) read from the side not dyed
        k = next(k for k, mark in enumerate(marks) if mark[3] == 'undyed')
        marks = marks[k:] + marks[:k]
    out, chain = [], []
    for mark in marks + [None]:
        if mark is None or mark[3] == 'undyed':
            while chain and chain[-1][3] == 'new':
                chain.pop()
            while chain and chain[0][3] == 'new':
                chain.pop(0)
            if chain:
                out.append([[chain[0][0], chain[0][1]], [chain[-1][0], chain[-1][2]]])
            chain = []
        else:
            chain.append(mark)
    return out or None


def bare(q, name):
    """A new line from what an offset gave: only its geometry (never the piece's id, its piqûre, its names…)."""
    from geometry import path
    from cad import polygon
    if q.get('components') or q.get('spline'):
        pts, closed = path(q)
        return polygon(pts, name, closed)
    out = {k: copy.deepcopy(q[k]) for k in GEOMETRY if k in q}
    out['name'] = name
    return out


def _clear(piece, line):
    """No part of the line inside the piece (a band that would cut it: a slot narrower than the teinte, an end going
    back over the piece)."""
    from geometry import path
    pts, closed = path(line)
    tests = list(pts) + [((a[0] + b[0]) / 2, (a[1] + b[1]) / 2) for a, b in zip(pts, pts[1:] + (pts[:1] if closed else []))]
    for q in tests:
        if _in(piece, q):
            raise ValueError('La teinte couperait la pièce ici : réduire la distance.')


def _in(piece, q):
    """``q`` inside the piece, not on its contour."""
    from precision_geometry import inside, contour_location
    return inside(piece, q) and math.dist(contour_location(piece, q)[1], q) > 1e-3


def _crossings(piece, pts):
    """The points where the run of points ``pts`` crosses the piece's contour, in their order along it."""
    from geometry import path
    ring = list(path(piece)[0])
    edges = list(zip(ring, ring[1:] + ring[:1]))
    out = []
    travel = 0.
    for p, q in zip(pts, pts[1:]):
        L = math.dist(p, q)
        if L < 1e-12:
            continue
        x0, x1, y0, y1 = min(p[0], q[0]) - 1e-9, max(p[0], q[0]) + 1e-9, min(p[1], q[1]) - 1e-9, max(p[1], q[1]) + 1e-9
        rx, ry = q[0] - p[0], q[1] - p[1]
        for e, f in edges:
            if max(e[0], f[0]) < x0 or min(e[0], f[0]) > x1 or max(e[1], f[1]) < y0 or min(e[1], f[1]) > y1:
                continue
            sx, sy = f[0] - e[0], f[1] - e[1]
            den = rx * sy - ry * sx
            if abs(den) < 1e-15:
                continue
            t = ((e[0] - p[0]) * sy - (e[1] - p[1]) * sx) / den
            u = ((e[0] - p[0]) * ry - (e[1] - p[1]) * rx) / den
            if -1e-12 <= t <= 1 + 1e-12 and -1e-12 <= u <= 1 + 1e-12:
                out.append((travel + t * L, (p[0] + t * rx, p[1] + t * ry)))
        travel += L
    return [q for _, q in sorted(out)]


def _stopped(piece, line, part, a, b):
    """0.19.40 (an acute inside corner, a V notch: the end of the band square to its side went into the piece at any
    distance, neither side could be dyed alone and « réduire la distance » never helped): an end of the line inside the
    piece stops where the line meets the piece (the next side); the band goes along that side back to the corner.
    (line, the region's ring) or ValueError."""
    from geometry import path
    from precision_geometry import contour_location, contour_length, contour_slice
    pts = list(path(line)[0])
    if len(pts) < 2 or not (_in(piece, pts[0]) or _in(piece, pts[-1])):
        raise ValueError('La teinte couperait la pièce ici : réduire la distance.')
    total = contour_length(piece)
    L = contour_length(line)
    t0, t1, before, after = 0., L, [], []
    crossings = _crossings(piece, pts)   # (an end inside: the line meets the contour between it and the rest)
    if not crossings:
        raise ValueError('Ce côté ne peut pas être teinté.')
    if _in(piece, pts[0]):
        x = crossings[0]
        t0 = contour_location(line, x)[0]
        at = contour_location(piece, x)[0]
        back = (a - at) % total   # along the contour from where the line stops to the corner
        if back > total / 2 or back < 1e-6:
            raise ValueError('La teinte couperait la pièce ici : réduire la distance.')
        after = list(reversed(path(contour_slice(piece, at, at + back))[0]))   # the corner → the line
    if _in(piece, pts[-1]):
        y = crossings[-1]
        t1 = contour_location(line, y)[0]
        at = contour_location(piece, y)[0]
        ahead = (at - b) % total
        if ahead > total / 2 or ahead < 1e-6:
            raise ValueError('La teinte couperait la pièce ici : réduire la distance.')
        before = list(reversed(path(contour_slice(piece, b, b + ahead))[0]))   # the line → the corner
    if t1 - t0 < 1e-6:
        raise ValueError('Ce côté ne peut pas être teinté.')
    cut = contour_slice(line, t0, t1)
    out = {k: copy.deepcopy(cut[k]) for k in GEOMETRY if k in cut}
    out['name'] = line.get('name', 'Teinte')
    _clear(piece, out)
    ring = list(path(out)[0]) + before + list(reversed(path(part)[0])) + after
    return out, ring


def _line_out(piece, base, d, closed):
    """The offset of ``base`` (a part of the piece's contour, or the whole of it) ``d`` mm out of the piece."""
    from precision_geometry import shifted, inside, contour_length
    from geometry import path
    if closed:
        q = shifted(base, d)   # (a closed contour: positive is outside)
        return bare(q, 'Teinte')
    m0, out = outward(piece, list(path(base)[0]))   # (review: toward the side's own outside; « its middle not inside » took
    last = None                                     # the offset inward when the piece is thinner than d there: TILTED's 2 mm sides)
    for sign in (1, -1):
        try:
            q = shifted(base, sign * d)
        except ValueError as exc:
            last = exc
            continue
        pts = path(q)[0]
        if len(pts) < 2:
            continue
        m, _ = _halfway(pts)
        if (m[0] - m0[0]) * out[0] + (m[1] - m0[1]) * out[1] > 0 and not inside(piece, m):
            return bare(q, 'Teinte')
    raise last or ValueError('Ce côté ne peut pas être teinté.')


def band(piece, run_ids, runs, d, part=None):
    """(line, region) of a band dyeing the sides ``run_ids`` (following one another) of ``piece``: the line ``d`` mm out
    of them, the region between them and it (regions.region_at's form: points, holes). ``part`` (0.19.42): the band
    stops inside a side, from its start to its end (``run_ids`` unused). ValueError: why not."""
    from geometry import path
    from precision_geometry import contour_location, contour_length, contour_slice
    n = len(runs)
    if part is None and len(run_ids) == n:
        line = _line_out(piece, piece, d, True)
        _clear(piece, line)
        return line, dict(points=list(path(line)[0]), holes=[list(path(piece)[0])])
    pts = _part_points(runs, part) if part is not None else []
    for j in run_ids if part is None else ():
        run = runs[j][0]
        pts += run if not pts else run[1:]
    total = contour_length(piece)
    a = contour_location(piece, pts[0])[0]
    b = contour_location(piece, pts[-1])[0]
    m = contour_location(piece, _halfway(pts)[0])[0]
    span = (b - a) % total
    if (m - a) % total > span + 1e-7:   # the contour drawn the other way round from its sides
        a, b = b, a
        span = (b - a) % total
    if span < 1e-6:
        raise ValueError('Côté trop court.')
    part = contour_slice(piece, a, a + span)
    line = _line_out(piece, part, d, False)
    try:
        _clear(piece, line)
    except ValueError as exc:
        try:
            line, ring = _stopped(piece, line, part, a, a + span)
        except ValueError:
            raise exc from None   # (a slot narrower than the teinte: « réduire la distance » helps there)
        return line, dict(points=ring, holes=[])
    ring = list(path(line)[0]) + list(reversed(path(part)[0]))
    return line, dict(points=ring, holes=[])


def build(piece, ids, d, couches, uid=None, parts=None):
    """[(line, zone)] for the sides ``ids`` of ``piece`` at ``d`` mm (no piece attached yet); ``parts`` (0.19.42): bands
    stopping inside a side instead, one for each part."""
    from craft_tools import PROFILES
    runs, total = sides(piece)
    n = len(runs)
    out = []
    todo = [(g, None) for g in groups(ids, n)] if parts is None else \
        [(list(dict.fromkeys(q[0] for q in _pieces(part, n))), part) for part in parts]
    for run_ids, part in todo:
        line, region = band(piece, run_ids, runs, d, part)
        key = uid if uid and len(out) == 0 else uuid.uuid4().hex
        data = dict(kind='teinte', type='', thickness=None, width=d, couches=couches, sides=list(run_ids), count=n, band=key)
        if part is not None:
            data['part'] = [[int(part[0][0]), min(1., max(0., float(part[0][1])))],
                            [int(part[1][0]), min(1., max(0., float(part[1][1])))]]
        zone = prep.zone(region, data)
        line['profile'] = 'Préparation'
        line['style'] = {k: copy.deepcopy(v) for k, v in PROFILES['Préparation'].items()}
        line['teinte_band'] = key
        out.append((line, zone))
    return out


def _zones(app, pid):
    """The tool's zones Teinte attached to ``pid`` (any piece's state): [(index, zone)]."""
    return [(j, s) for j, s in enumerate(app.items)
            if s.get('owner_id') == pid and isinstance(s.get('preparation'), dict)
            and s['preparation'].get('kind') == 'teinte' and s['preparation'].get('band')]


def _line_of(app, pid, key, zone=None):
    """(review: a piece dyed, then made a précoupe in series: each piece to recut has a copy of the band, the same id on the
    same précoupe; the second one's click took the first one's line) the line on ``zone``'s outline when several are."""
    found = [j for j, s in enumerate(app.items) if s.get('teinte_band') == key and s.get('owner_id') == pid]
    if len(found) > 1 and zone is not None:
        from geometry import path
        try:
            ring = prep.ring_points(zone)
            return min(found, key=lambda j: min(math.dist(path(app.items[j])[0][0], v) for v in ring))
        except (ValueError, KeyError, TypeError, IndexError):
            pass
    return found[0] if found else None


def bands(app, k):
    """The bands the tool made on contour ``k``, still with its sides (as many as when they were made, and round it: a
    précoupe holds several pieces): [dict(zone, line, sides, width, couches)]."""
    piece = app.items[k]
    pid = owner(app, k)
    if not pid:
        return []
    runs, total = sides(piece)
    n = len(runs)
    out = []
    for j, z in _zones(app, pid):
        p = z['preparation']
        if p.get('count') != n:
            continue
        part = _part(p.get('part'), n)
        if part is not None:
            pieces = _pieces(part, n)
            ids = {q[0] for q in pieces}
        else:
            ids = {v for v in p.get('sides') or () if isinstance(v, int) and not isinstance(v, bool) and 0 <= v < n}
            pieces = [(j, 0., 1.) for g in groups(ids, n) for j in g]
        if not ids:
            continue
        try:
            width = float(p.get('width') or 0) or settings(app)['distance']
            m, nrm = outward(piece, _part_points(runs, part) if part is not None else runs[min(ids)][0])
            ring = prep.ring_points(z)
            # (0.19.40: a band stopped on the next side of an acute corner can be thinner than half its width there)
            if not any(prep.inside(ring, (m[0] + nrm[0] * t, m[1] + nrm[1] * t)) for t in (width / 2, 2 * PROBE)):
                continue
        except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
            continue
        couches = p.get('couches')
        couches = couches if isinstance(couches, int) and not isinstance(couches, bool) and couches >= 1 else 1
        out.append(dict(zone=j, line=_line_of(app, pid, p['band'], z), sides=ids, width=width, couches=couches,
                        part=part, pieces=pieces))
    return out


def foreign(app, k, i, mine):
    """A zone Teinte on side ``i`` the tool did not make (by hand, from Mozart, a piece reshaped since): its index, or
    None. Looked for just out of the side and just in (Mozart dyes inside the piece)."""
    piece = app.items[k]
    runs, total = sides(piece)
    m, n = outward(piece, runs[i][0])
    probes = [(m[0] + n[0] * s, m[1] + n[1] * s) for s in (.5, -.5)]
    own = {b['zone'] for b in mine}
    for j, z in enumerate(app.items):
        p = z.get('preparation')
        if j in own or not isinstance(p, dict) or p.get('kind') != 'teinte':
            continue
        try:
            ring = prep.ring_points(z)
            if any(prep.inside(ring, q) for q in probes):
                return j
        except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
            continue
    return None


FOREIGN = 'Ce côté a déjà une teinte (faite autrement) : outil Préparation, clic dans la zone, Supprimer.'


def change(app, k, i=None, whole=False):
    """What a click on side ``i`` of contour ``k`` does (``whole``: a double-click, the whole piece round), nothing done:
    dict(k, remove=[indices], add=[(line, zone)], dyed=sides dyed after, bands). ValueError: said where one clicked."""
    piece = app.items[k]
    runs, total = sides(piece)
    n = len(runs)
    if not n:
        raise ValueError('Contour trop court.')
    st = settings(app)
    d = st['distance']
    mine = bands(app, k)
    holding = []
    add = None
    if whole:
        affected = mine
        ids = set(range(n))
        width = d
        for j in range(n):
            if foreign(app, k, j, mine) is not None:
                raise ValueError(FOREIGN.replace('Ce côté a', 'Une partie du tour a'))
    else:
        holding = [b for b in mine if i in b['sides']]
        if holding and any(b['part'] is not None for b in holding):
            # (0.19.42) a band stopping inside a side: the side clicked taken off what each band on it dyes, the rest of
            # them kept as they were
            affected, add, ids = holding, [], set()
            width = holding[0]['width']
            for b in holding:
                for part, from_corner, run_ids in _chains([q for q in b['pieces'] if q[0] != i], n):
                    add += build(piece, run_ids if from_corner else (), b['width'], b['couches'],
                                 parts=None if from_corner else [part])
                    ids |= set(run_ids)
        elif holding:
            b = holding[0]
            affected = [b]
            ids = b['sides'] - {i}
            width = b['width']
        else:
            if foreign(app, k, i, mine) is not None:
                raise ValueError(FOREIGN)
            # (0.19.40: a band joined only at the distance and the couches set: with 2 couches set, a side next to a band
            # of 1 couche was added to it at 1 couche; 0.19.42: a band stopping inside a side, only where it reaches the
            # corner of the side clicked)
            near = [b for b in mine if abs(b['width'] - d) < 1e-6 and b['couches'] == st['couches']
                    and (_touches(b, i, n) if b['part'] is not None else b['sides'] & {(i - 1) % n, (i + 1) % n})]
            affected = near
            width = d
            if any(b['part'] is not None for b in near):
                add, ids = [], set()
                for part, from_corner, run_ids in _chains([q for b in near for q in b['pieces']] + [(i, 0., 1.)], n):
                    add += build(piece, run_ids if from_corner else (), d, st['couches'],
                                 parts=None if from_corner else [part])
                    ids |= set(run_ids)
            else:
                ids = set().union(*[b['sides'] for b in near]) | {i}
    # (0.19.40) a side taken off: its band keeps its couches; a side added or the whole round (at the distance set): the
    # couches set
    couches = holding[0]['couches'] if holding else st['couches']
    if add is None:
        add = build(piece, ids, width, couches) if ids else []
    remove = sorted({b['zone'] for b in affected} | {b['line'] for b in affected if b['line'] is not None})
    kept = set().union(*[b['sides'] for b in mine if b not in affected]) if len(mine) > len(affected) else set()
    return dict(k=k, piece=piece, remove=remove, add=add, dyed=len(kept | ids), width=width)


def apply(app, plan):
    """The change made (one Annuler)."""
    app.snapshot()
    piece = plan['piece']
    k = next((j for j, s in enumerate(app.items) if s is piece), None)
    if k is None:
        return
    pid = owner(app, k, make=True)
    for j in sorted(plan['remove'], reverse=True):
        del app.items[j]
    for line, zone in plan['add']:
        line['owner_id'] = zone['owner_id'] = pid
        app.items.append(zone)
        app.items.append(line)
    app.selected = None
    app.selected_set = set()


def refit(app, pieces):
    """``pieces``: piece id → (the piece as it was, as it is now) (advanced_ui.refit_stitches: a grip, a raccord, Échelle):
    the tool's bands on them made again on the piece as it is, at their width, with their couches and ids: the same sides
    when the piece has as many, else the sides nearest those dyed. (In the Annuler step of the change.) How many."""
    import surcoupe
    from entity_rules import closed_piece
    done = 0
    for pid, (old, new) in pieces.items():
        if not pid or surcoupe.is_precut(old) or not closed_piece(new):
            # (review: a précoupe's id holds the bands of the pieces inside it, never bands of its own sides; as the Piqûres
            # (refit_stitches): Décomposer leaves lines with the piece's id, never a band on one)
            continue
        zones = _zones(app, pid)
        if not zones:
            continue
        try:
            before, _ = sides(old)
            after, _ = sides(new)
        except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
            continue
        n0, n1 = len(before), len(after)
        for j, z in zones:
            p = z['preparation']
            ids = [v for v in p.get('sides') or () if isinstance(v, int) and not isinstance(v, bool) and 0 <= v < n0]
            if p.get('count') != n0 or not ids or not n1:
                continue
            parts = None
            part = _part(p.get('part'), n0)
            try:
                if part is not None:
                    # (0.19.42) a band stopping inside a side: the same place along its sides, or its ends where they fall
                    parts = [part] if n1 == n0 else _moved_part(before, after, part, new)
                    if not parts:
                        continue
                elif n1 != n0:
                    from assembly_ui import _gap
                    mapped = []
                    for v in ids:
                        m, _ = _halfway(before[v][0])
                        mapped.append(min(range(n1), key=lambda w: _gap(m, after[w][0])))
                    # (review) the whole round stays whole, and a band keeps the sides a raccord puts between its own (a
                    # corner chamfered: the band round it was left where it was, the whole round lost the new side)
                    run = [(mapped[0] + t) % n1 for t in range((mapped[-1] - mapped[0]) % n1 + 1)]
                    dyed = set(ids)
                    if len(ids) == n0:
                        ids = list(range(n1))
                    elif set(mapped) <= set(run) and len(run) <= len(ids) + max(0, n1 - n0):
                        ids = run
                    else:
                        ids = sorted(set(mapped))
                    # (0.19.42, « la bande s'arrête au début de l'arrondi ») a round between a dyed side and one not dyed
                    parts = _trimmed(old, before, after, dyed, ids)
                width = float(p.get('width') or 0)
                made = build(new, ids, width, p.get('couches') or 1, uid=p['band'], parts=parts) if width > 0 else []
            except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
                continue
            if not made or (parts is None and len(made) != 1):
                continue   # (the sides no longer follow one another: left as it was)
            for t, (line, zone) in enumerate(made):
                key = p['band'] if t == 0 else zone['preparation']['band']
                new_part = zone['preparation'].get('part')
                line['owner_id'] = zone['owner_id'] = pid
                zone['preparation'] = dict(p, **{k2: zone['preparation'][k2] for k2 in ('sides', 'count', 'width')})
                zone['preparation'].pop('part', None)
                if new_part is not None:
                    zone['preparation']['part'] = new_part
                zone['preparation']['band'] = key
                line['teinte_band'] = key
                if t:
                    # (0.19.42: an Arrondi on each side of a side not dyed between two dyed ones: two bands)
                    app.items.append(zone)
                    app.items.append(line)
                    continue
                at = _line_of(app, pid, p['band'], z)
                app.items[j] = zone
                if at is not None:
                    kept = {k2: copy.deepcopy(v) for k2, v in app.items[at].items() if k2 not in GEOMETRY}
                    kept.update({k2: line[k2] for k2 in GEOMETRY if k2 in line})
                    for k2 in GEOMETRY:
                        if k2 not in line:
                            kept.pop(k2, None)
                    app.items[at] = kept
                else:
                    app.items.append(line)
            done += 1
    return done


def drop_line(app, j):
    """0.19.39: a zone of the tool deleted (Préparation › Supprimer): its line with it. The index of the line, or None."""
    z = app.items[j]
    key = (z.get('preparation') or {}).get('band')
    return _line_of(app, z.get('owner_id'), key, z) if key and z.get('owner_id') else None


# ---------------------------------------------------------------- the tool

def reach(app):
    return 8 / max(app.scale, 1e-9)


def prompt(app, more=''):
    d = settings(app)['distance']
    app.status.set(f'Teinte des bords à {fmt(d)} mm : cliquer un côté (les côtés qui se suivent font une bande) · un côté teint : '
                   f'enlevé · double-clic : tout le tour · autre distance : la taper + Entrée.{more}')


def resume(app, more=''):
    app.tool.set('teinte_bord')
    app.last_command = ('tool', 'teinte_bord')
    app.teinte_state = dict(last=None)
    try:
        app.canvas.delete(TAG)
    except (AttributeError, tk.TclError):
        pass
    app.highlight_tools()
    prompt(app, more)


def start(app):
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    if not app.prefs.get('show_preparations', True):
        app.prefs['show_preparations'] = True   # one sees the bands one makes (they hide with the Préparations)
        try:
            app.persist_preferences()
        except OSError:
            pass
    resume(app)
    app.refresh()


def cancel(app):
    app.teinte_state = None
    try:
        app.canvas.delete(TAG)
    except (AttributeError, tk.TclError):
        pass


def _hit(app, e):
    from assembly_ui import side_at
    try:
        return side_at(app, app.raw(e), reach(app))
    except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
        return None


def words(plan):
    w = fmt(plan['width'])
    # 0.19.40 (« si les textes sont tous homogènes »): « … Échap pour finir. » as every tool in series (the status line
    # writes « · Échap pour finir »: a « · » before it was written twice)
    if not plan['dyed']:
        return 'Teinte enlevée de ce côté. Échap pour finir.'
    n = plan['dyed']
    return f'Teinte à {w} mm : {n} côté{"s" if n > 1 else ""} teint{"s" if n > 1 else ""} sur cette pièce. Échap pour finir.'


def act(app, e, whole=False):
    st = app.__dict__.get('teinte_state')
    if st is None:
        return 'break'
    hit = _hit(app, e)
    if hit is None:
        app.invalid_at(e, 'Cliquer le bord d’une pièce (Coupe externe).')
        return 'break'
    try:
        plan = change(app, hit[0], hit[1], whole)
    except ValueError as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    apply(app, plan)
    app.canvas.delete(TAG)
    st['last'] = (id(plan['piece']), hit[1])
    st['key'] = None
    app.refresh()
    app.status.set(('Tout le tour teint à ' + fmt(plan['width']) + ' mm. Échap pour finir.') if whole else words(plan))
    return 'break'


def click(app, e):
    return act(app, e)


def double(app, e):
    """A double-click on the side just clicked: the whole piece round (its first click did that side already)."""
    st = app.__dict__.get('teinte_state') or {}
    hit = _hit(app, e)
    if hit is not None and st.get('last') == (id(app.items[hit[0]]), hit[1]):
        return act(app, e, whole=True)
    return act(app, e)


def enter(app):
    """Entrée: a distance typed is kept for the next sides; else the tool is over."""
    text = app.command_value.get().strip()
    if text:
        try:
            # (0.19.40) read as every length typed (parse_length: the unit, cm, « 1+1 »: they fell to « Cliquez d'abord le
            # point de départ sur le dessin. »)
            v = app.parse_length(text)
        except ValueError:
            return None   # (a command's name: as before)
        if not (math.isfinite(v) and .1 <= v <= 50):
            app.status.set('Distance de la teinte : de 0,1 à 50 mm.')
            return 'break'
        keep(app, distance=round(v, 3))
        app.command_value.set('')
        try:
            app.command_entry.place_forget()
        except (AttributeError, tk.TclError):
            pass
        if app.__dict__.get('teinte_state') is not None:
            app.teinte_state['key'] = None
        prompt(app)
        return 'break'
    app.escape()
    app.status.set('Teinte des bords terminée.')
    return 'break'


def preview(app, e):
    """Under the mouse, before the click: the band it makes (dashed), or the one it takes off (red)."""
    c = app.canvas
    c.delete(TAG)
    st = app.__dict__.get('teinte_state')
    if st is None:
        return
    hit = _hit(app, e)
    if hit is None:
        return
    key = (app.__dict__.get('_doc_version'), id(app.items), len(app.items), hit, settings(app)['distance'])
    if st.get('key') != key:
        try:
            st['plan'] = change(app, *hit)
        except (ValueError, ZeroDivisionError, IndexError, TypeError, KeyError):
            st['plan'] = None
        st['key'] = key
    plan = st.get('plan')
    try:
        if plan is None:
            from assembly_ui import sides as cut
            run = cut(app.items[hit[0]])[0][hit[1]][0]
            c.create_line(*[v for q in run for v in app.to_screen(q)], fill='#e05050', width=3, tags=TAG)
            return
        for j in plan['remove']:
            if j < len(app.items) and app.items[j].get('preparation'):
                pts = prep.ring_points(app.items[j])
                c.create_polygon(*[v for q in pts for v in app.to_screen(q)], fill='', outline='#e05050', width=2, dash=(4, 3), tags=TAG)
        from geometry import path
        for line, zone in plan['add']:
            pts = prep.ring_points(zone)
            c.create_polygon(*[v for q in pts for v in app.to_screen(q)], fill='', outline=app.p['accent'], width=2, dash=(4, 3), tags=TAG)
            pts, closed = path(line)
            flat = [v for q in pts + (pts[:1] if closed else []) for v in app.to_screen(q)]
            if len(flat) >= 4:
                c.create_line(*flat, fill='#f4a6ca', width=2, tags=TAG)
    except (tk.TclError, ValueError, IndexError, TypeError):
        c.delete(TAG)


def dialog(app):
    """Right click: the distance and the couches of the next bands."""
    st = settings(app)
    win = app.dialog('Teinte des bords')
    panel = app.p['panel']
    form = tk.Frame(win, bg=panel)
    form.pack(fill='x', padx=16, pady=(14, 4))
    distance = tk.StringVar(value=fmt(st['distance']))
    coats = tk.StringVar(value=str(st['couches']))
    app.label(form, 'Distance du bord (mm)').grid(row=0, column=0, sticky='w', pady=3)
    first = app.entry(form, distance, 8)
    first.grid(row=0, column=1, sticky='w', padx=8, pady=3)
    app.label(form, 'Couche(s)').grid(row=1, column=0, sticky='w', pady=3)
    app.entry(form, coats, 4).grid(row=1, column=1, sticky='w', padx=8, pady=3)

    def valid(e=None):
        try:
            from command_catalog import length_field
            try:
                d = length_field(distance.get())   # 0.19.42: « 5 cm » too (before: mm only)
            except ValueError:
                raise ValueError('Distance : de 0,1 à 50 mm.') from None
            n = int(coats.get().strip())
            if not (math.isfinite(d) and .1 <= d <= 50):
                raise ValueError('Distance : de 0,1 à 50 mm.')
            if not 1 <= n <= 20:
                raise ValueError('Couche(s) : de 1 à 20.')
        except ValueError as exc:
            text = str(exc)
            messagebox.showerror('Teinte des bords', text if ' : ' in text else 'Distance en mm, couches : un nombre entier.', parent=win)
            return 'break'
        win.destroy()
        keep(app, distance=round(d, 3), couches=n)
        if app.__dict__.get('teinte_state') is not None:
            app.teinte_state['key'] = None
            prompt(app)
        app.canvas.focus_set()
        return 'break'
    win.bind('<Return>', valid)
    win.bind('<KP_Enter>', valid)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(8, 14))
    app.button(foot, 'Valider', valid).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', lambda: (win.destroy(), app.canvas.focus_set()))
    first.focus_set()
    first.select_range(0, 'end')
    return win
