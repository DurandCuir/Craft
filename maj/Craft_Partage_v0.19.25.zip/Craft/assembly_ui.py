"""0.19.13 Contrôle d'assemblage (« assemblages en 2D », 07/11: « tu calcules par rapport à l'épaisseur qu'aura sur
les assemblages la personne, mais ça il faudrait savoir quelle pièce va où et sur quoi »).

A click on the edge of a piece takes its side (between two corners, as the stitches cut a line: a smooth round
piece is one side); Maj + click adds the next side. A click on another piece takes the edge sewn on it (Maj + click:
its next side too). The window says both lengths and their difference, the crans in front of each other (the edges
taken in the direction that puts the most crans in front), the thickness at the seam (the refentes of both pieces,
1 mm when a piece has none; it can be typed), the points of the seam (points per cm of the Piqûre) and the thread
of a lock stitch: at each point, the length of the point and the thickness, for each of the two threads, without
margin. « Écrire sur le plan » leaves it written by the first edge; Entrée starts a new check; Échap ends.

0.19.14: the bag is sewn with the pieces surcoupées, not their précoupe (« ça va être avec les surcoupes que le sac sera
assemblé »): a click on a précoupe takes the side of its piece inside. The thickness at the seam follows the parage
of the edge: biseau, the middle of the bevel (« ça tombe au milieu du biseau »: between the edge and the leather);
rembord, the flap pared and folded on the leather itself (his way: leather + pared), or pared over twice its width
(2 × pared, to tick); another parage, its thickness; the renforts and doublures of the piece (by their names: RENFORT
FACE, DBL FACE…) are offered to tick.

0.19.24 (proposed on 13/11, « Fais les pistes aussi »: « le Contrôle d'assemblage de tout le sac d'un coup »): each check
done is kept with the model (its two edges: the pieces and their sides; Infos du modèle « assemblages », the .crft keeps
them, Annuler does not take them away); « Contrôle d'assemblage du sac… » (Exporter, « Tout le sac… » in the check's
window, typed « assemblage du sac ») checks them all again at once: lengths, écart, crans in front of each other, in a
list and on the plan (green: good; red: an écart over 0,5 mm; orange: crans not all in front; grey: a piece gone or its
sides changed, to check again). A double click opens the check of that pair; « Retirer de la liste ».

0.19.25 (« Go tes propositions et améliore toujours »): « Paires probables… » proposes the edges of two pieces of about
the same length with their crans in front of each other, to tick (proposals); the fiche « Assemblages » (fiches.py)
prints the pairs kept with their numbers, points and thread."""
import math
import tkinter as tk

COLORS = ('#ff9f1c', '#2ec4b6')
TOLERANCE = 1.   # mm: a cran in front of another one


def _pieces(app, every=False):
    """The edges that are sewn: the pieces (Coupe extérieure) but not the précoupes, and the pieces inside them.
    0.19.24 ``every``: also those of a layer hidden (the pairs kept)."""
    from entity_rules import closed_piece
    from craft_tools import style
    import surcoupe
    out = []
    hidden = __import__('preparation_ui').hidden_ids(app) if hasattr(app, 'prefs') and not every else set()   # 0.19.14: layers hidden
    for k, s in enumerate(app.items):
        if not closed_piece(s) or s.get('annotation') or k in hidden:
            continue
        role = style(s)['role']
        if role == 'external' and not surcoupe.is_precut(s) or role == surcoupe.ROLE and s.get('owner_id'):
            out.append(k)
    return out


def _precuts(app):
    import surcoupe
    hidden = __import__('preparation_ui').hidden_ids(app)   # 0.19.14: a hidden précoupe is not clicked
    return [k for k, s in enumerate(app.items) if surcoupe.is_precut(s) and k not in hidden]


def host(app, k):
    """The piece that carries the data of ``k`` (its précoupe for a piece inside one)."""
    s = app.items[k]
    if s.get('piece_id') or not s.get('owner_id'):
        return s
    return next((q for q in app.items if q.get('piece_id') == s['owner_id']), s)


_CACHE = {}


def sides(piece):
    """[(points, start distance along the contour, length)] between the corners, and the contour's length (kept for
    the same piece: the mouse moves over them)."""
    hit = _CACHE.get(id(piece))
    if hit is not None and hit[0] is piece:
        return hit[1]
    import stitching
    from geometry import path
    from craft_tools import locate
    pts, closed = path(piece)
    out = []
    for run in stitching._runs(pts, closed):
        length = sum(math.dist(a, b) for a, b in zip(run, run[1:]))
        if length > 1e-6:
            out.append((run, locate(piece, run[0])[0], length))
    value = (out, sum(r[2] for r in out))
    if len(_CACHE) > 500:
        _CACHE.clear()
    _CACHE[id(piece)] = (piece, value)
    return value


def _gap(p, run):
    best = 1e18
    for a, b in zip(run, run[1:]):
        dx, dy = b[0] - a[0], b[1] - a[1]
        L = dx * dx + dy * dy
        t = 0 if L == 0 else max(0, min(1, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L))
        best = min(best, math.dist(p, (a[0] + t * dx, a[1] + t * dy)))
    return best


def side_at(app, p, reach):
    """(piece index, side index) of the side nearest ``p`` within ``reach`` mm, or None. 0.19.14: on a précoupe, the
    nearest side of the piece inside it."""
    from geometry import bounds
    best = None
    for k in _pieces(app):
        s = app.items[k]
        x, y, X, Y = bounds([s])
        if not (x - reach <= p[0] <= X + reach and y - reach <= p[1] <= Y + reach):
            continue
        for i, (run, start, length) in enumerate(sides(s)[0]):
            d = _gap(p, run)
            if d <= reach and (best is None or d < best[0]):
                best = (d, k, i)
    if best:
        return best[1:]
    import surcoupe
    shown = set(_pieces(app))
    for k in _precuts(app):
        s = app.items[k]
        x, y, X, Y = bounds([s])
        if not (x - reach <= p[0] <= X + reach and y - reach <= p[1] <= Y + reach):
            continue
        if min(_gap(p, run) for run, _, _ in sides(s)[0]) > reach:
            continue
        for j in surcoupe.inner_contours(app.items, k):
            if j not in shown:
                continue
            for i, (run, start, length) in enumerate(sides(app.items[j])[0]):
                d = _gap(p, run)
                if best is None or d < best[0]:
                    best = (d, j, i)
    return best[1:] if best else None


def portion(app, chosen):
    """(points, start, length, total) of the sides ``chosen`` = (piece, [side indices]) taken in the contour's order."""
    k, ids = chosen
    runs, total = sides(app.items[k])
    ids = sorted(ids)
    # contiguous through the end of the contour (the last side then the first ones)
    n = len(runs)
    if len(ids) > 1 and ids[0] == 0 and ids[-1] == n - 1:
        cut = next(i for i in range(1, len(ids)) if ids[i] != ids[i - 1] + 1) if any(ids[i] != ids[i - 1] + 1 for i in range(1, len(ids))) else len(ids)
        ids = ids[cut:] + ids[:cut]
    pts, length = [], 0.
    for i in ids:
        pts += runs[i][0] if not pts else runs[i][0][1:]
        length += runs[i][2]
    return pts, runs[ids[0]][1], length, total


def in_one_run(app, k, ids):
    """0.19.22: the sides ``ids`` of piece ``k`` follow one another (one edge, round the closing corner too)."""
    n = len(sides(app.items[k])[0])
    taken = set(ids)
    return len(taken) == n or sum((j + 1) % n not in taken for j in taken) == 1


def adjacent(app, chosen, i):
    k, ids = chosen
    n = len(sides(app.items[k])[0])
    return any((i - j) % n in (1, n - 1) for j in ids)


def crans(app, k, start, length, total):
    """The crans of piece ``k`` on the portion: their distances from its start (0.19.14: a piece inside a précoupe, the
    crans of its précoupe on its contour)."""
    from craft_tools import cran_mark
    piece = app.items[k]
    owner = piece.get('piece_id') or piece.get('owner_id')
    out = []
    for s in app.items:
        if s.get('is_notch') and s.get('owner_id') and s.get('owner_id') == owner:
            mark = cran_mark(s, piece)
            if mark is not None:
                d = (mark['distance'] - start) % total if total else 0.
                if d <= length + .05:
                    out.append(min(d, length))
    return sorted(out)


def facing(a, la, b, lb):
    """(crans in front of each other, b reversed or not): the direction that puts the most of them in front."""
    def count(bs):
        left, n = list(bs), 0
        for x in a:
            hit = next((y for y in left if abs(x - y) <= TOLERANCE), None)
            if hit is not None:
                left.remove(hit)
                n += 1
        return n
    same, back = count(b), count([lb - y for y in b])
    return (back, True) if back > same else (same, False)


def thickness(app, k):
    """The refente of piece ``k`` in mm (« refente 10/10 » = 1 mm), None when it has none."""
    info = (host(app, k).get('piece_info') or {}).get('material') or {}
    try:
        v = float(str(info.get('refente', '')).replace(',', '.'))
    except ValueError:
        return None
    return v / 10 if v > 0 else None


def _along(pts, step=2.):
    """Points every ``step`` mm along a line."""
    out = []
    for a, b in zip(pts, pts[1:]):
        n = max(1, int(math.dist(a, b) / step))
        out += [(a[0] + (b[0] - a[0]) * j / n, a[1] + (b[1] - a[1]) * j / n) for j in range(n)]
    return out + pts[-1:]


def parage(app, k, pts):
    """The parage zone along most of the edge ``pts`` of piece ``k`` (its préparation data), or None."""
    from geometry import path
    import preparations as prep
    owners = {app.items[k].get('piece_id'), app.items[k].get('owner_id'), host(app, k).get('piece_id')} - {None}
    samples = _along(pts)
    best = None
    for s in app.items:
        data = s.get('preparation')
        if not data or data.get('kind') != 'parage' or s.get('owner_id') not in owners:
            continue
        try:
            ring = path(s)[0]
        except (ValueError, KeyError, TypeError):
            continue
        near = sum(1 for q in samples if prep.inside(ring, q) or _gap(q, ring + ring[:1]) < .3)
        if near >= len(samples) / 2 and (best is None or near > best[0]):
            best = (near, data)
    return best[1] if best else None


def edge_thickness(app, k, pts, double=False):
    """(thickness at the seam in mm, what it is made of, the refente known, a rembord found) of the edge ``pts``."""
    leather = thickness(app, k)
    e = leather if leather is not None else 1.
    data = parage(app, k, pts)
    if not data:
        return e, f'cuir {_mm(e, 2)}', leather is not None, False
    kind = str(data.get('type') or '').upper()
    try:
        t = float(data.get('thickness')) / 10
    except (TypeError, ValueError):
        t = None
    if not t or t <= 0:
        return e, f'cuir {_mm(e, 2)} (parage {kind.lower() or "sans épaisseur"} : épaisseur non donnée)', leather is not None, 'REMBORD' in kind
    if 'BISEAU' in kind:
        return (e + t) / 2, f'parage biseau à {_mm(t, 2)} : milieu du biseau {_mm((e + t) / 2, 2)}', leather is not None, False
    if 'REMBORD' in kind:
        if double:
            return 2 * t, f'rembord paré à {_mm(t, 2)}, plié : 2 × {_mm(t, 2)}', leather is not None, True
        return e + t, f'rembord paré à {_mm(t, 2)}, plié sur le cuir : {_mm(e, 2)} + {_mm(t, 2)}', leather is not None, True
    return t, f'parage {kind.lower()} à {_mm(t, 2)}', leather is not None, False


def _name(s):
    info = (s.get('piece_info') or {}).get('part_name') or {}
    values = info.get('values') or []
    return ' '.join(str(v) for v in values if v).strip().upper() or str(s.get('name') or '').strip().upper()


LAYER_WORDS = ('RENFORT', 'RFT', 'DOUBLURE', 'DBL', 'NON TISSE', 'NON TISSÉ')


def layers(app, k, every=False):
    """The renforts and doublures of piece ``k`` found by their names (« RENFORT FACE », « DBL FACE » for FACE):
    [(index, name, thickness in mm or None)]. 0.19.25 ``every``: also among the pieces of a layer hidden (the
    proposals look at every piece)."""
    import re
    name = _name(host(app, k))
    if not name:
        return []
    word = re.compile(r'(^|\W)' + re.escape(name) + r'(\W|$)')
    out = []
    for j in _pieces(app, every):
        other = _name(host(app, j))
        if j == k or other == name or not word.search(other) or not any(w in other for w in LAYER_WORDS):
            continue
        if any(other == o for _, o, _ in out):
            continue
        out.append((j, other, thickness(app, j)))
    return out


def thread(length, points, thick):
    """(points, thread in mm) of a lock stitch ``length`` mm long: each of the two threads lies along each point
    (10 / points per cm) and crosses the thickness once at each point."""
    n = max(1, round(length * points / 10))
    step = 10 / points
    return n, n * 2 * (step + thick)


def _drop_stale(app):
    """0.19.24 (review): the edges taken whose piece changed meanwhile (its sides fewer, the drawing changed under the
    tool: an IndexError at each move of the mouse) are let go: the check starts again."""
    st = app.__dict__.get('assembly_state')
    if not st:
        return False
    for key in ('a', 'b'):
        chosen = st.get(key)
        if not chosen:
            continue
        k, ids = chosen
        try:
            ok = bool(ids) and k < len(app.items) and max(ids) < len(sides(app.items[k])[0])
        except (IndexError, KeyError, TypeError, ValueError, ZeroDivisionError):
            ok = False
        if not ok:
            st.update(a=None, b=None, kept=None, added=False)
            return True
    return False


def result(app):
    """The numbers of the check (None while the second edge is not chosen)."""
    _drop_stale(app)
    st = app.__dict__.get('assembly_state') or {}
    if not st.get('a') or not st.get('b'):
        return None
    pa, sa, la, ta = portion(app, st['a'])
    pb, sb, lb, tb = portion(app, st['b'])
    ca, cb = crans(app, st['a'][0], sa, la, ta), crans(app, st['b'][0], sb, lb, tb)
    front, reversed_ = facing(ca, la, cb, lb)
    double = bool(st.get('double'))
    ta_, da, ka, ra = edge_thickness(app, st['a'][0], pa, double)
    tb_, db, kb, rb = edge_thickness(app, st['b'][0], pb, double)
    found = layers(app, st['a'][0]) + [x for x in layers(app, st['b'][0]) if x[0] not in {y[0] for y in layers(app, st['a'][0])}]
    ticked = [x for x in found if x[0] in (st.get('layers') or set())]
    extra = sum(x[2] if x[2] is not None else 1. for x in ticked)
    thick = st.get('thickness') if st.get('thickness') is not None else ta_ + tb_ + extra
    points = st.get('points') or round(10 / app.prefs.get('stitch_pitch', 10 / 3), 2)
    n, fil = thread(max(la, lb), points, thick)
    return dict(la=la, lb=lb, diff=la - lb, ca=len(ca), cb=len(cb), front=front, reversed=reversed_, thickness=thick,
                known=(ka, kb), points=points, n=n, thread=fil, a=pa, b=pb, made=(da, db), rembord=ra or rb, layers=found)


def _mm(v, digits=1):
    return f'{round(v, digits):g}'.replace('.', ',')


def summary(r):
    return (f'{_mm(r["la"])} / {_mm(r["lb"])} mm (écart {_mm(abs(r["diff"]))}) · crans {r["front"]} en face sur {r["ca"]} / {r["cb"]}'
            f' · {r["n"]} points · fil ≈ {_mm(r["thread"] / 10, 0)} cm')


# --- the tool -----------------------------------------------------------------------------------------------------

def start(app):
    if hasattr(app, 'plan_active') and not app.plan_active() and hasattr(app, 'select_section'):
        app.select_section('plan')   # 0.19.25 (review): the check is made on the plan, never over a fiche shown
    app.finish_action()
    app.cancel()
    app.selected = None
    app.selected_set = set()
    app.tool.set('assembly')
    app.last_command = ('tool', 'assembly')
    app.assembly_state = dict(a=None, b=None, thickness=None, points=None, kept=None, added=False)
    app.highlight_tools()
    prompt(app)
    app.refresh()


def resume(app):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return start(app)
    app.tool.set('assembly')   # 0.19.22: (Annuler / Rétablir left the Sélection under this prompt)
    app.last_command = ('tool', 'assembly')
    app.highlight_tools()
    st.update(a=None, b=None, kept=None, added=False)
    prompt(app)
    draw(app)


def prompt(app):
    st = app.assembly_state
    _drop_stale(app)
    if not st.get('a'):
        app.status.set("Contrôle d'assemblage : cliquer le bord de la 1re pièce (Maj + clic : ajouter le côté suivant).")
    elif not st.get('b'):
        app.status.set("Cliquer le bord cousu dessus, sur l'autre pièce (Maj + clic : ajouter un côté ; Entrée : même pièce).")
    else:
        r = result(app)
        app.status.set('Assemblage : ' + summary(r) + ' · Entrée : nouveau contrôle.')


def _reach(app):
    return 8 / max(app.scale, 1e-9)


def hover(app, e):
    draw(app, side_at(app, app.raw(e), _reach(app)))


def draw(app, under=None):
    c = app.canvas
    c.delete('assembly_preview')
    if hasattr(app, 'plan_active') and not app.plan_active():
        return   # (review) a fiche shown: nothing over it
    _drop_stale(app)
    st = app.__dict__.get('assembly_state') or {}
    for key, color in zip(('a', 'b'), COLORS):
        if st.get(key):
            pts = portion(app, st[key])[0]
            c.create_line(*[v for p in pts for v in app.to_screen(p)], fill=color, width=5, capstyle='round', tags=('assembly_preview',))
    if under is not None:
        run = sides(app.items[under[0]])[0][under[1]][0]
        c.create_line(*[v for p in run for v in app.to_screen(p)], fill=app.p.get('accent', '#61c9ee'), width=3, dash=(6, 4), tags=('assembly_preview',))


def click(app, e):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return None
    _drop_stale(app)
    found = side_at(app, app.raw(e), _reach(app))
    if found is None:
        app.invalid_at(e, 'Cliquer le bord d’une pièce (Coupe extérieure).')
        return 'break'
    k, i = found
    shift = bool(getattr(e, 'state', 0) & 1)

    def grow(key):
        """Maj + click on a side of the same piece: added if it follows, removed if it was taken."""
        k0, ids = st[key]
        if i in ids:
            if len(ids) > 1 and in_one_run(app, k0, [j for j in ids if j != i]):   # 0.19.22: an end of the edge only (a
                ids.remove(i)                                                     # side in its middle split it in two)
        elif adjacent(app, st[key], i):
            ids.append(i)
    if not st.get('a'):
        st.update(a=(k, [i]), thickness=None)   # 0.19.14: a thickness typed is for its own check
    elif not st.get('b'):
        if k == st['a'][0] and not st.get('switched'):
            if shift:
                grow('a')
            else:
                st.update(a=(k, [i]), thickness=None)
        else:
            st.update(b=(k, [i]), thickness=None)
    elif shift and k == st['b'][0]:
        grow('b')
    elif shift and k == st['a'][0]:
        grow('a')
    else:   # a new check from this edge
        st.update(a=(k, [i]), b=None, switched=False, thickness=None, kept=None, added=False)
    prompt(app)
    draw(app)
    if st.get('b'):
        remember(app)   # 0.19.24: kept with the model (Contrôle d'assemblage du sac)
        window(app)
    return 'break'


def enter(app):
    st = app.__dict__.get('assembly_state')
    if st is None:
        return 'break'
    if st.get('a') and not st.get('b'):
        st['switched'] = True   # the second edge on the same piece
        app.status.set("Cliquer le bord cousu dessus (sur la même pièce ou une autre).")
        return 'break'
    st.update(a=None, b=None, switched=False, thickness=None, kept=None, added=False)
    prompt(app)
    draw(app)
    return 'break'


def write(app):
    """The check written on the plan, by the middle of the first edge."""
    from craft_tools import annotation
    r = result(app)
    if r is None:
        return None
    pts = r['a']
    half, travel, at = r['la'] / 2, 0., pts[0]
    for a, b in zip(pts, pts[1:]):
        seg = math.dist(a, b)
        if travel + seg >= half:
            t = (half - travel) / seg if seg else 0
            at = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            break
        travel += seg
    text = annotation('Assemblage : ' + summary(r), (at[0] + 2, at[1] + 2), 2.5)
    text['assembly'] = dict(la=round(r['la'], 2), lb=round(r['lb'], 2), front=r['front'], points=r['points'], thickness=r['thickness'])
    app.snapshot()
    app.items.append(text)
    app.refresh()
    draw(app)
    return text


def window(app):
    """The numbers of the check, kept up to date; the thickness and the points per cm can be typed."""
    from tkinter import messagebox
    old = app.__dict__.get('_assembly_window')
    if old is not None and old.winfo_exists():
        old._refill()
        return old
    win = app.dialog("Contrôle d'assemblage")
    try:
        win.grab_release()
    except tk.TclError:
        pass
    app._assembly_window = win
    panel = app.p['panel']
    box = tk.Frame(win, bg=panel)
    box.pack(fill='x', padx=16, pady=(14, 4))
    labels = {}
    for row, (key, text) in enumerate((('a', 'Bord 1'), ('b', 'Bord 2'), ('diff', 'Écart'), ('crans', 'Crans en face'), ('n', 'Points'), ('thread', 'Fil (2 fils, sans marge)'))):
        app.label(box, text).grid(row=row, column=0, sticky='w', pady=2)
        labels[key] = tk.StringVar()
        tk.Label(box, textvariable=labels[key], bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 10, 'bold')).grid(row=row, column=1, sticky='w', padx=10)
    thick, points = tk.StringVar(), tk.StringVar()
    app.label(box, 'Épaisseur à la couture (mm)').grid(row=6, column=0, sticky='w', pady=2)
    app.entry(box, thick, 7).grid(row=6, column=1, sticky='w', padx=10)
    app.label(box, 'Points par cm').grid(row=7, column=0, sticky='w', pady=2)
    app.entry(box, points, 7).grid(row=7, column=1, sticky='w', padx=10)
    note = tk.StringVar()
    tk.Label(win, textvariable=note, bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), font=('Segoe UI', 9), justify='left', wraplength=330).pack(fill='x', padx=16)
    extras = tk.Frame(win, bg=panel)   # 0.19.14: the rembord's way, the renforts and doublures to add
    extras.pack(fill='x', padx=16)
    ticks = {}
    double = tk.BooleanVar(value=bool(app.assembly_state.get('double')))
    check = dict(bg=panel, fg=app.p.get('ui_ink', '#f1f3f5'), selectcolor=app.field_background(), activebackground=panel, font=('Segoe UI', 9))

    def changed():
        st = app.assembly_state
        st['double'] = double.get()
        st['layers'] = {j for j, v in ticks.items() if v.get()}
        st['thickness'] = None   # the thickness computed again
        refill()
        prompt(app)

    def build_extras(r):
        for w in extras.winfo_children():
            w.destroy()
        make = __import__('modern_style').make_check
        if r['rembord']:
            make(extras, text='Rembord paré sur 2 × sa largeur (sinon : rabat paré plié sur le cuir)', variable=double, command=changed, **check).pack(anchor='w')
        chosen = app.assembly_state.get('layers') or set()
        for j, name, t in r['layers']:
            v = ticks.setdefault(j, tk.BooleanVar(value=j in chosen))
            make(extras, text=f'+ {name} ({_mm(t, 2) + " mm" if t is not None else "1 mm compté"})', variable=v, command=changed, **check).pack(anchor='w')

    def refill():
        r = result(app)
        if r is None:
            for v in labels.values():
                v.set('—')
            return
        labels['a'].set(f'{_mm(r["la"])} mm')
        labels['b'].set(f'{_mm(r["lb"])} mm')
        labels['diff'].set(f'{_mm(abs(r["diff"]))} mm' + (' ✓' if abs(r['diff']) <= .5 else (' : bord 1 plus long' if r['diff'] > 0 else ' : bord 2 plus long')))
        labels['crans'].set(f'{r["front"]} (bord 1 : {r["ca"]}, bord 2 : {r["cb"]})' + (' · sens inverse' if r['reversed'] else ''))
        labels['n'].set(f'{r["n"]} ({_mm(r["points"], 2)} par cm)')
        labels['thread'].set(f'≈ {_mm(r["thread"] / 10, 0)} cm')
        thick.set(_mm(r['thickness'], 2))
        points.set(_mm(r['points'], 2))
        missing = [n for n, known in zip(('1', '2'), r['known']) if not known]
        note.set(f'Bord 1 : {r["made"][0]} · bord 2 : {r["made"][1]}.'
                 + (' 1 mm compté pour le cuir de la pièce ' + ' et '.join(missing) + ' (pas de refente dans sa matière).' if missing else '')
                 + ('' if r['layers'] else ' Renforts et doublures : à ajouter à l’épaisseur.'))
        key = (r['rembord'], tuple(j for j, _, _ in r['layers']))
        if win.__dict__.get('_extras_key') != key:
            win._extras_key = key
            build_extras(r)

    def typed(e=None):
        st = app.assembly_state
        try:
            t = float(thick.get().replace(',', '.'))
            p = float(points.get().replace(',', '.'))
            if not 0 < t <= 50 or not .5 <= p <= 20:
                raise ValueError
        except ValueError:
            messagebox.showerror("Contrôle d'assemblage", 'Épaisseur : 0 à 50 mm ; points par cm : 0,5 à 20.', parent=win)
            return 'break' if e is not None else False   # 0.19.22: (the button: nothing written)
        st['thickness'], st['points'] = t, p
        refill()
        prompt(app)
        return 'break' if e is not None else True
    for w in box.winfo_children():
        if isinstance(w, tk.Entry):
            w.bind('<Return>', typed)
            w.bind('<FocusOut>', lambda e: None)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=16, pady=(8, 14))
    app.button(foot, 'Écrire sur le plan', lambda: typed() and write(app)).pack(side='left')
    app.button(foot, 'Tout le sac…', lambda: bag(app), kind='secondary').pack(side='left', padx=6)   # 0.19.24
    app.button(foot, 'Fermer', win.destroy).pack(side='right')
    win._refill = refill
    refill()
    return win


# --- 0.19.24 the whole bag: every check done, kept with the model, checked again at once ----------------------------------

KEY = 'assemblages'
GOOD, BAD, WARN, GREY = '#34c759', '#ff3b30', '#ff9500', '#8e8e93'
ECART = .5   # mm: over it, the pair is in red (the check's ✓ above)


def piece_key(app, k):
    """What names piece ``k`` in a pair kept: its piece_id (given if it has none); a piece surcoupée: its précoupe's."""
    s = app.items[k]
    if s.get('piece_id'):
        return s['piece_id']
    import surcoupe
    from craft_tools import style
    if s.get('owner_id') and style(s)['role'] == surcoupe.ROLE:
        return 'dans:' + s['owner_id']   # (its copies in the précoupe are the same piece)
    from entity_rules import ensure_piece_id
    before = dict(s)
    key = ensure_piece_id(s)
    # (review) the same piece in the drawings Annuler / Rétablir bring back gets the same id: a change undone that did
    # not touch it never makes its pair « introuvable »
    for state in list(app.__dict__.get('undo_stack') or ()) + list(app.__dict__.get('redo_stack') or ()):
        for q in (state.get('items') or ()) if isinstance(state, dict) else ():
            if isinstance(q, dict) and not q.get('piece_id') and q == before:
                q['piece_id'] = key
    return key


def piece_index(app, key, pieces=None):
    """The piece named ``key`` (piece_key), or None when it is gone."""
    pieces = _pieces(app, every=True) if pieces is None else pieces
    if key.startswith('dans:'):
        owner = key[5:]
        return next((k for k in pieces if not app.items[k].get('piece_id') and app.items[k].get('owner_id') == owner), None)
    return next((k for k in pieces if app.items[k].get('piece_id') == key), None)


def edge_of(app, chosen):
    k, ids = chosen
    return dict(piece=piece_key(app, k), sides=sorted(set(ids)), count=len(sides(app.items[k])[0]))


def _ident(pair):
    """The same two edges, in either order."""
    return tuple(sorted((e['piece'], tuple(e['sides'])) for e in (pair['a'], pair['b'])))


def kept_pairs(app):
    return [dict(a=dict(p['a']), b=dict(p['b'])) for p in ((app.__dict__.get('infos') or {}).get(KEY) or [])]


def _store(app, pairs):
    """The pairs kept in the Infos du modèle (a new dict: the « * » of the tab compares it with the one saved)."""
    infos = dict(app.__dict__.get('infos') or {})
    if pairs:
        infos[KEY] = pairs
    else:
        infos.pop(KEY, None)
    app.infos = infos or None
    for name in ('update_window_title', 'rebuild_tabs'):
        if hasattr(app, name):
            getattr(app, name)()


def remember(app):
    """The check shown kept with the model: the same edges once; while a check goes on (a side added, the second edge
    taken again), the pair it added follows it."""
    st = app.__dict__.get('assembly_state') or {}
    if not st.get('a') or not st.get('b'):
        return
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        return   # (read-only: the check is shown, nothing is kept)
    pair = dict(a=edge_of(app, st['a']), b=edge_of(app, st['b']))
    new = _ident(pair)
    old = st.get('kept')
    pairs = kept_pairs(app)
    idents = [_ident(p) for p in pairs]
    if old is not None and old != new and st.get('added') and old in idents:   # the pair of this check follows its edges
        at = idents.index(old)
        if new in idents:   # now the same as another one kept: that one, its sides counted again
            del pairs[at]
            idents.pop(at)
            pairs[idents.index(new)] = pair
            added = False
        else:
            pairs[at] = pair
            added = True
    elif new in idents:
        at = idents.index(new)
        if pairs[at] == pair and old == new:
            return
        pairs[at] = pair   # (review) checked again: its sides counted again (« côtés changés » goes)
        added = st.get('added') if old == new else False
    else:
        pairs.append(pair)
        added = True
    st.update(kept=new, added=added)
    _store(app, pairs)
    win = app.__dict__.get('_bag_window')
    if win is not None and win.winfo_exists():
        win._refill()


def _side_text(app, k, ids):
    name = _name(host(app, k)) or 'Pièce'
    return name + (f' · {len(ids)} côtés' if len(ids) > 1 else '')


def check(app, pair, pieces=None):
    """The pair kept checked again: dict(state 'ok' / 'bad' (écart) / 'crans' / 'gone' / 'changed', its texts, the edges'
    points)."""
    pieces = _pieces(app, every=True) if pieces is None else pieces
    out = dict(a_text=pair['a']['piece'][:8], b_text=pair['b']['piece'][:8], lengths='', diff='', crans='', a=None, b=None)
    found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
    for key, k, e in zip(('a_text', 'b_text'), found, (pair['a'], pair['b'])):
        if k is not None:
            out[key] = _side_text(app, k, e['sides'])
    def shown(k, e):
        """(grey on the plan) the edge as it is when its sides are still there, else the whole contour"""
        if k is None:
            return None
        try:
            if max(e['sides']) < len(sides(app.items[k])[0]):
                return portion(app, (k, e_sides(e)))[0]
            pts, closed = __import__('geometry').path(app.items[k])
            return pts + pts[:1] if closed else pts
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            return None
    if None in found:
        return dict(out, state='gone', text='— pièce introuvable', a=shown(found[0], pair['a']), b=shown(found[1], pair['b']))
    for k, e in zip(found, (pair['a'], pair['b'])):
        if len(sides(app.items[k])[0]) != e['count'] or max(e['sides']) >= e['count']:
            return dict(out, state='changed', text='— côtés changés : refaire ce contrôle', a=shown(found[0], pair['a']), b=shown(found[1], pair['b']))
    try:
        pa, sa, la, ta = portion(app, (found[0], e_sides(pair['a'])))
        pb, sb, lb, tb = portion(app, (found[1], e_sides(pair['b'])))
        ca, cb = crans(app, found[0], sa, la, ta), crans(app, found[1], sb, lb, tb)
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        return dict(out, state='changed', text='— côtés changés : refaire ce contrôle')
    front, _ = facing(ca, la, cb, lb)
    diff = abs(la - lb)
    out.update(a=pa, b=pb, la=la, lb=lb, lengths=f'{_mm(la)} / {_mm(lb)}', diff=_mm(diff, 2), crans=f'{front} sur {len(ca)} / {len(cb)}')
    if diff > ECART:
        return dict(out, state='bad', text=f'✗ écart de {_mm(diff, 2)} mm')
    if not front == len(ca) == len(cb):
        return dict(out, state='crans', text=f'⚠ crans : {front} en face sur {len(ca)} / {len(cb)}')
    return dict(out, state='ok', text='✓ bon')


def e_sides(edge):
    return list(edge['sides'])


def checks(app):
    pieces = _pieces(app, every=True)
    return [check(app, pair, pieces) for pair in kept_pairs(app)]


COLOUR = dict(ok=GOOD, bad=BAD, crans=WARN, gone=GREY, changed=GREY)


def _fingerprint(app):
    """What the checks depend on: the pieces of the pairs and their crans (marshal: quick), the pairs."""
    import marshal
    pairs = kept_pairs(app)
    names = {e['piece'] for p in pairs for e in (p['a'], p['b'])}
    owners = {n[5:] if n.startswith('dans:') else n for n in names}
    parts = [s for s in app.items if s.get('piece_id') in owners or s.get('owner_id') in owners]
    try:
        return marshal.dumps((pairs, parts), 2)
    except ValueError:
        return None


def draw_bag(app):
    """The edges of the pairs kept on the plan (tag assembly_bag), in the colour of their state; the pair chosen in the
    list wider, in the check's two colours. Checked again when the pieces or their crans changed."""
    marks = app.__dict__.get('_bag_marks')
    c = app.canvas
    c.delete('assembly_bag')
    if not marks:
        return
    win = app.__dict__.get('_bag_window')
    if win is None or not win.winfo_exists():
        clear_bag(app)   # (its window gone another way)
        return
    if hasattr(app, 'plan_active') and not app.plan_active():
        return   # a fiche shown: nothing over it
    key = _fingerprint(app)
    if key is not None and key != marks.get('key'):
        return win._refill()   # the list and the plan checked again (it draws them)
    chosen = marks.get('chosen')
    for pts, pick in zip(marks.get('proposal') or (), COLORS):   # 0.19.25: the probable pair picked in its list
        if pts and len(pts) > 1:
            c.create_line(*[v for p in pts for v in app.to_screen(p)], fill=pick, width=6, capstyle='round', dash=(8, 4), tags=('assembly_bag',))
    for n, row in enumerate(marks['rows']):
        for edge, pick in (('a', COLORS[0]), ('b', COLORS[1])):
            pts = row.get(edge)
            if not pts or len(pts) < 2:
                continue
            xy = [v for p in pts for v in app.to_screen(p)]
            if n == chosen:
                c.create_line(*xy, fill=pick, width=6, capstyle='round', tags=('assembly_bag',))
            c.create_line(*xy, fill=COLOUR[row['state']], width=3 if n != chosen else 2, capstyle='round', tags=('assembly_bag',))
    c.tag_raise('assembly_bag')


def clear_bag(app):
    app.__dict__.pop('_bag_marks', None)
    try:
        app.canvas.delete('assembly_bag')
    except tk.TclError:
        pass


def open_pair(app, pair):
    """The check of a pair kept, in the tool (its window: the thickness, the points and the thread)."""
    pieces = _pieces(app, every=True)
    found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
    if None in found:
        return False
    for k, e in zip(found, (pair['a'], pair['b'])):
        if len(sides(app.items[k])[0]) != e['count'] or max(e['sides']) >= e['count']:
            return False   # (review: its sides changed: an IndexError at each move of the mouse)
    start(app)
    st = app.assembly_state
    # (review) corrected here (Maj + clic), the pair follows: never a second one beside it
    st.update(a=(found[0], e_sides(pair['a'])), b=(found[1], e_sides(pair['b'])), kept=_ident(pair), added=True)
    prompt(app)
    draw(app)
    window(app)
    return True


# --- 0.19.25 the fiche « Assemblages » (fiches.py): the pairs kept with their numbers, points and thread -------------------

WORDS = dict(ok='bon', bad='écart', crans='crans', gone='à refaire', changed='à refaire')


def fiche_rows(app):
    """The pairs kept for the fiche « Assemblages », in the list's order: [dict(a, b: the edges (ID unique, name, sides),
    lengths, diff, crans, state, word, thickness, n, thread (mm), la, lb)]. Thickness, points and thread as the check
    counts them before anything is typed: the refentes and parages of both edges (1 mm for a leather without refente),
    the points per cm of the Piqûre; a pair to check again: its numbers left out."""
    import piece_ids
    pieces = _pieces(app, every=True)
    prefs = app.__dict__.get('prefs') or {}
    points = round(10 / (prefs.get('stitch_pitch') or 10 / 3), 2)
    out = []
    for pair in kept_pairs(app):
        r = check(app, pair, pieces)
        found = [piece_index(app, e['piece'], pieces) for e in (pair['a'], pair['b'])]
        row = dict(a=r['a_text'], b=r['b_text'], lengths=r['lengths'], diff=r['diff'], crans=r['crans'], state=r['state'],
                   word=WORDS[r['state']], thickness=None, n=None, thread=None, points=points, la=r.get('la'), lb=r.get('lb'))
        for key, k in zip(('a', 'b'), found):
            number = piece_ids.number_of(app.items, k) if k is not None else None
            if number:
                row[key] = f'{number} · {row[key]}'
        if r['state'] in ('ok', 'bad', 'crans'):
            try:
                thick = edge_thickness(app, found[0], r['a'])[0] + edge_thickness(app, found[1], r['b'])[0]
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                thick = None
            if thick is not None:
                n, fil = thread(max(r['la'], r['lb']), points, thick)
                row.update(thickness=thick, n=n, thread=fil)
        out.append(row)
    return out


# --- 0.19.25 the pairs proposed (« Go tes propositions »: « Craft te propose les paires d'assemblage probables (même
# longueur, crans en face), tu n'as qu'à cocher ») ------------------------------------------------------------------------

NEAR = 3.          # mm: the lengths of a probable pair at most this far apart, or SPREAD of the longer
SPREAD = .03       # (the edges are measured at the cut: round corners make them a little longer than at the seam)
SHORTEST = 10.     # mm: a shorter edge is never proposed
LONGEST_RUN = 12   # sides in a row at most in one edge
MOST = 60          # proposals shown at most


def _known_key(app, k):
    """The name of piece ``k`` in the pairs kept, when it has one (nothing given: proposing changes nothing)."""
    s = app.items[k]
    if s.get('piece_id'):
        return s['piece_id']
    import surcoupe
    from craft_tools import style
    if s.get('owner_id') and style(s)['role'] == surcoupe.ROLE:
        return 'dans:' + s['owner_id']
    return None


def _cran_spots(app, k, total):
    """The crans of piece ``k``: their distances along its contour, from its start."""
    from craft_tools import cran_mark
    piece = app.items[k]
    owner = piece.get('piece_id') or piece.get('owner_id')
    if not owner:
        return []
    out = []
    for s in app.items:
        if s.get('is_notch') and s.get('owner_id') == owner:
            mark = cran_mark(s, piece)
            if mark is not None:
                out.append(mark['distance'] % total if total else 0.)
    return sorted(out)


def _alike(a, la, b, lb):
    """The crans ``a`` (along an edge ``la`` long) in front of the crans ``b`` once ``b`` is brought to that length, either
    way (3 mm or 1 % apart at most): round corners drift crans measured at the cut."""
    tol = max(3., .01 * la)
    k = la / lb if lb else 1.

    def count(bs):
        left, n = sorted(bs), 0
        for x in a:
            hit = next((y for y in left if abs(x - y) <= tol), None)
            if hit is not None:
                left.remove(hit)
                n += 1
        return n
    return max(count([y * k for y in b]), count([(lb - y) * k for y in b]))


def proposals(app):
    """0.19.25: the probable pairs of edges: two edges (a side, or several in a row, each end side with a cran) of two
    pieces of about the same length (NEAR mm or SPREAD apart at most, SHORTEST mm long at least) with about as many
    crans, most of them falling in front of each other (``_alike``); never a piece with its own renfort or doublure, nor
    an edge already in a pair kept. [dict(a=(k, ids), b=(k, ids), la, lb, ca, cb, front: in front as the check counts
    them)]: the most crans alike first, then the closest numbers of crans, then the closest lengths."""
    pieces = _pieces(app, every=True)
    taken = {}   # the sides of the edges kept: sewn already (review: nor an edge sharing a side with one)
    for pair in kept_pairs(app):
        for e in (pair['a'], pair['b']):
            taken.setdefault(e['piece'], set()).update(e['sides'])
    edges = []   # (length, k, ids, crans along the edge)
    for k in pieces:
        try:
            runs, total = sides(app.items[k])
            n = len(runs)
            spots = _cran_spots(app, k, total) if n and total > 0 else []   # (review: a cran it cannot read, as check())
        except (ValueError, KeyError, TypeError, ZeroDivisionError, IndexError):
            continue
        if not spots:
            continue
        def on(start, length):
            return sorted(min((d - start) % total, length) for d in spots if (d - start) % total <= length + .05)
        marked = [bool(on(start, length)) for _, start, length in runs]
        for i in range(n):   # each edge: from side i, one side or more in a row (round the closing corner too)
            if not marked[i]:
                continue
            start, length, ids = runs[i][1], 0., []
            for m in range(min(n, LONGEST_RUN)):
                j = (i + m) % n
                length += runs[j][2]
                ids.append(j)
                if length < SHORTEST or not marked[j] or m + 1 == n and i:   # (the whole contour: once)
                    continue
                edges.append((length, k, tuple(ids), on(start, length)))
    edges.sort(key=lambda e: e[0])
    own = {k: {j for j, _, _ in layers(app, k, True)} for k in pieces}   # a piece and its renforts / doublures (by their names)
    found = {}
    for x, (la, ka, ia, ca) in enumerate(edges):
        for lb, kb, ib, cb in edges[x + 1:]:
            if lb - la > max(NEAR, SPREAD * lb):
                break
            if kb == ka or kb in own[ka] or ka in own[kb] or abs(len(ca) - len(cb)) > max(1, round(.15 * max(len(ca), len(cb)))):
                continue
            key = tuple(sorted(((ka, tuple(sorted(ia))), (kb, tuple(sorted(ib))))))
            named = [_known_key(app, k) for k in (ka, kb)]
            if named[0] is not None and named[0] == named[1]:
                continue   # (review) two copies in one précoupe: the same piece for a pair kept
            if taken.get(named[0], set()) & set(ia) or taken.get(named[1], set()) & set(ib):
                continue
            alike = _alike(ca, la, cb, lb)
            if alike < max(1, (max(len(ca), len(cb)) + 1) // 2):
                continue   # their crans do not fall in front of each other: a coincidence of lengths
            front, _ = facing(ca, la, cb, lb)
            score = (-round(alike / max(len(ca), len(cb)), 1), abs(len(ca) - len(cb)), abs(la - lb))
            if key not in found or score < found[key][0]:
                found[key] = (score, dict(a=(ka, list(ia)), b=(kb, list(ib)), la=la, lb=lb, ca=len(ca), cb=len(cb), front=front,
                                          pieces=(app.items[ka], app.items[kb])))
    out = []
    for _, p in sorted(found.values(), key=lambda v: v[0]):   # the best first; one seam once (edges overlapping on both pieces)
        if not any({p['a'][0], p['b'][0]} == {q['a'][0], q['b'][0]} and all(
                set(dict((p['a'], p['b']))[k]) & set(dict((q['a'], q['b']))[k]) for k in {p['a'][0], p['b'][0]}) for q in out):
            out.append(p)
    return out[:MOST]


def add_pairs(app, chosen):
    """0.19.25: the proposals ``chosen`` kept with the model (each once); the number added."""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0
    pairs = kept_pairs(app)
    idents = {_ident(p) for p in pairs}
    added = 0
    for p in chosen:
        pair = dict(a=edge_of(app, p['a']), b=edge_of(app, p['b']))
        if _ident(pair) not in idents:
            pairs.append(pair)
            idents.add(_ident(pair))
            added += 1
    if added:
        _store(app, pairs)
    win = app.__dict__.get('_bag_window')
    if win is not None and win.winfo_exists():
        win._refill()
    return added


def propose(app):
    """0.19.25 « Paires probables… » (Contrôle d'assemblage du sac): the probable pairs in a list to tick; a click shows
    the pair on the plan; « Ajouter les paires cochées » keeps them with the model."""
    from tkinter import ttk
    old = app.__dict__.get('_proposal_window')
    if old is not None and old.winfo_exists():
        old._refill()
        old.lift()
        return old
    win = app.dialog('Paires probables')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._proposal_window = win
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    head = tk.StringVar()
    tk.Label(win, textvariable=head, bg=panel, fg=ink, font=('Segoe UI', 10), justify='left', wraplength=620).pack(anchor='w', padx=14, pady=(12, 4))
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    columns = (('tick', '', 3), ('a', 'Bord 1', 24), ('b', 'Bord 2', 24), ('len', 'Longueurs (mm)', 15), ('crans', 'Crans', 15))
    table = ttk.Treeview(area, columns=[k for k, _, _ in columns], show='headings', height=10, selectmode='browse')
    for key, label, width in columns:
        table.heading(key, text=label)
        table.column(key, width=width * 7, anchor='center' if key == 'tick' else 'w', stretch=key in ('a', 'b'))
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')
    state = dict(rows=[], ticked=set())

    def text(chosen):
        k, ids = chosen
        return _side_text(app, k, ids)

    def stale():
        """(review) the drawing changed under the list: its pieces are not where they were"""
        items = app.items
        return any(not all(k < len(items) and items[k] is s for k, s in zip((p['a'][0], p['b'][0]), p['pieces'])) for p in state['rows'])

    def refill():
        state['rows'] = rows = proposals(app)
        state['ticked'] = set()
        table.delete(*table.get_children())
        for n, p in enumerate(rows):
            table.insert('', 'end', iid=str(n), values=('☐', text(p['a']), text(p['b']), f'{_mm(p["la"])} / {_mm(p["lb"])}',
                                                        f'{p["ca"]} / {p["cb"]} ({p["front"]} en face)'))
        if rows:
            head.set(f'{len(rows)} paire{"s" if len(rows) > 1 else ""} de bords de même longueur (à 3 mm ou 3 % près), aux crans '
                     'en face : cocher celles qui sont cousues ensemble, puis « Ajouter les paires cochées ». Clic : la paire sur le plan.')
        else:
            head.set('Aucune paire probable : il faut des crans en face sur les deux bords (les bords déjà dans la liste du sac '
                     'ne sont pas proposés).')
        shown(None)

    def shown(n):
        marks = app.__dict__.get('_bag_marks')
        if marks is None:
            return
        if n is None or n >= len(state['rows']):
            marks.pop('proposal', None)
        else:
            p = state['rows'][n]
            try:
                marks['proposal'] = (portion(app, (p['a'][0], list(p['a'][1])))[0], portion(app, (p['b'][0], list(p['b'][1])))[0])
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                marks.pop('proposal', None)
        draw_bag(app)

    def toggle(n):
        if n in state['ticked']:
            state['ticked'].discard(n)
        else:
            state['ticked'].add(n)
        table.set(str(n), 'tick', '☑' if n in state['ticked'] else '☐')

    def clicked(e):
        row = table.identify_row(e.y)
        if row and table.identify_column(e.x) == '#1':
            toggle(int(row))

    def picked(e=None):
        if stale():
            return refill()
        sel = table.selection()
        shown(int(sel[0]) if sel else None)

    def key_toggle(e=None):
        sel = table.selection()
        if sel:
            toggle(int(sel[0]))
        return 'break'

    def double(e):
        if table.identify_column(e.x) == '#1':
            return 'break'   # (review) its first click ticked it already: the double click leaves it ticked
        return key_toggle(e)
    table.bind('<Button-1>', clicked, add='+')
    table.bind('<<TreeviewSelect>>', picked)
    table.bind('<space>', key_toggle)
    table.bind('<Double-1>', double)

    def add():
        chosen = [state['rows'][n] for n in sorted(state['ticked'])]
        if not chosen:
            app.status.set('Cocher les paires cousues ensemble.')
            return
        if stale():
            refill()
            app.status.set('Le dessin a changé : la liste est refaite, cocher à nouveau.')
            return
        added = add_pairs(app, chosen)
        if added:
            app.status.set(f'{added} assemblage{"s" if added > 1 else ""} ajouté{"s" if added > 1 else ""} au contrôle du sac.')
        refill()

    def done():
        marks = app.__dict__.get('_bag_marks')
        if marks is not None:
            marks.pop('proposal', None)
            draw_bag(app)
        app.__dict__.pop('_proposal_window', None)
        win.destroy()
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Ajouter les paires cochées', add).pack(side='left')
    app.button(foot, 'Fermer', done).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win.bind('<FocusIn>', lambda e: refill() if e.widget is win and stale() else None)   # back from the plan, changed
    win._refill = refill
    win._table = table
    win._toggle = toggle
    win._add = add
    win._done = done
    win._state = state
    refill()
    return win


def bag(app):
    """Exporter › Contrôle d'assemblage du sac…: every pair kept, checked again at once."""
    from tkinter import ttk
    old = app.__dict__.get('_bag_window')
    if old is not None and old.winfo_exists():
        old._refill()
        old.lift()
        return old
    win = app.dialog("Contrôle d'assemblage du sac")
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):   # opened from a tool: stays open after it (Échap, Annuler, the next check)
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._bag_window = win
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    app.label(win, 'Chaque Contrôle d’assemblage fait est gardé avec le modèle ; ici, tous contrôlés d’un coup. Double-clic : '
                   'ouvrir ce contrôle.').pack(anchor='w', padx=14, pady=(12, 2))
    if app.__dict__.get('mozart_source') and not app.__dict__.get('filename'):   # a DWG Mozart cannot keep them
        app.label(win, 'DWG Mozart : la liste est gardée tant qu’il est ouvert ; Enregistrer sous… (.crft) la garde avec le modèle.').pack(anchor='w', padx=14, pady=(0, 2))
    head = tk.StringVar()
    tk.Label(win, textvariable=head, bg=panel, fg=ink, font=('Segoe UI', 10, 'bold'), justify='left').pack(anchor='w', padx=14, pady=2)
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    columns = (('a', 'Bord 1', 24), ('b', 'Bord 2', 24), ('len', 'Longueurs (mm)', 15), ('diff', 'Écart (mm)', 9), ('crans', 'Crans en face', 13), ('state', 'État', 30))
    table = ttk.Treeview(area, columns=[k for k, _, _ in columns], show='headings', height=9, selectmode='browse')
    for key, label, width in columns:
        table.heading(key, text=label)
        table.column(key, width=width * 7, anchor='w', stretch=key in ('a', 'b', 'state'))
    for state, colour in COLOUR.items():
        table.tag_configure(state, foreground=colour)
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')
    marks = app.__dict__.setdefault('_bag_marks', {})

    def refill():
        rows = checks(app)
        marks.update(rows=rows, key=_fingerprint(app))
        chosen = marks.get('chosen')
        if chosen is not None and chosen >= len(rows):
            marks['chosen'] = chosen = None
        table.delete(*table.get_children())
        for n, r in enumerate(rows):
            table.insert('', 'end', iid=str(n), values=(r['a_text'], r['b_text'], r['lengths'], r['diff'], r['crans'], r['text']), tags=(r['state'],))
        if chosen is not None:
            table.selection_set(str(chosen))
        count = {s: sum(1 for r in rows if r['state'] == s) for s in COLOUR}
        if not rows:
            head.set('Aucun assemblage gardé : « Paires probables… » (bords de même longueur aux crans en face), ou « Ajouter un '
                     'assemblage » puis cliquer les deux bords cousus ensemble.')
        else:
            parts = [f'{count["ok"]} bon{"s" if count["ok"] > 1 else ""}']
            if count['bad']:
                parts.append(f'{count["bad"]} avec un écart de plus de 0,5 mm')
            if count['crans']:
                parts.append(f'{count["crans"]} aux crans pas tous en face')
            if count['gone'] + count['changed']:
                parts.append(f'{count["gone"] + count["changed"]} à refaire')
            head.set(f'{len(rows)} assemblage{"s" if len(rows) > 1 else ""} : ' + ', '.join(parts) + '.')
        draw_bag(app)

    def chosen_row():
        picked = table.selection()
        return int(picked[0]) if picked else None

    def picked(e=None):
        marks['chosen'] = chosen_row()
        draw_bag(app)
        n = marks['chosen']
        if n is not None and n < len(marks.get('rows') or ()):
            r = marks['rows'][n]
            app.status.set(f'{r["a_text"]} ↔ {r["b_text"]} : ' + (f'{r["lengths"]} mm, écart {r["diff"]}, crans {r["crans"]} · ' if r['lengths'] else '') + r['text'].lstrip('✓✗⚠— '))
    table.bind('<<TreeviewSelect>>', picked)

    def opened(e=None):
        n = chosen_row()
        pairs = kept_pairs(app)
        if n is None or n >= len(pairs):
            return 'break'
        if not open_pair(app, pairs[n]):
            app.status.set('Pièce introuvable ou côtés changés : refaire ce contrôle (Ajouter un assemblage), puis retirer celui-ci.')
        return 'break'
    table.bind('<Double-1>', opened)

    def removed():
        if hasattr(app, 'licence_complet') and not app.licence_complet():
            return app.read_only_said()
        n = chosen_row()
        pairs = kept_pairs(app)
        if n is None or n >= len(pairs):
            app.status.set('Choisir dans la liste l’assemblage à retirer.')
            return
        gone = _ident(pairs[n])
        del pairs[n]
        st = app.__dict__.get('assembly_state')
        if st and st.get('kept') == gone:   # (review: only the check whose pair it was forgets it)
            st.update(kept=None, added=False)
        marks['chosen'] = None
        _store(app, pairs)
        refill()
        app.status.set('Assemblage retiré de la liste.')

    def added():
        start(app)
        app.status.set("Contrôle d'assemblage : cliquer le bord de la 1re pièce, puis le bord cousu dessus (gardé dans la liste du sac).")

    def fiche():
        """0.19.25: the fiche « Assemblages » in its tab at the bottom (the pairs kept, to print)."""
        if not kept_pairs(app):
            app.status.set('Aucun assemblage gardé : rien à mettre sur la fiche.')
            return
        if hasattr(app, 'add_fiche'):
            app.add_fiche('fiche:assemblages')

    def done():
        proposal = app.__dict__.get('_proposal_window')
        if proposal is not None and proposal.winfo_exists():
            proposal._done()
        clear_bag(app)
        win.destroy()
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Ajouter un assemblage', added).pack(side='left')
    app.button(foot, 'Paires probables…', lambda: propose(app), kind='secondary').pack(side='left', padx=(6, 0))   # 0.19.25
    app.button(foot, 'Retirer de la liste', removed, kind='secondary').pack(side='left', padx=6)
    app.button(foot, 'Fermer', done).pack(side='right')
    app.button(foot, 'Fiche', fiche, kind='secondary').pack(side='right', padx=6)   # 0.19.25: the fiche « Assemblages »
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win.bind('<FocusIn>', lambda e: refill() if e.widget is win else None)   # back from the plan: checked again
    win._refill = refill
    win._table = table
    win._removed = removed
    win._opened = opened
    win._done = done
    win._head = head
    win._fiche = fiche
    refill()
    return win
