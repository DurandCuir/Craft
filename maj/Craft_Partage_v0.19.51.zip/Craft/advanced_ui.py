"""Craft 0.12: explicit contour construction and direct shape manipulation."""
import copy,math,time
import tkinter as tk
from types import SimpleNamespace
import tracking
from tkinter import messagebox
from ui_widgets import contrast_color,forget_zoom_marks,show_error
from geometry import path,bounds,validate,clone
from cad import polygon,shape
from curves import parts
from precision_geometry import canonical,primitives,at_primitive,ellipse_point,contour_location,contour_length
from editing import corner_poly,inherit,STRAP,strap_shape
CORNER_TOOLS=('fillet','chamfer','corner')+STRAP   # 0.19.5: they stay active after each raccord
from craft_tools import at_distance,notch_shapes,annotation,standalone_notch,locate,interior_side,notch_local_side,copy_independent_notches,new_cran
from advanced_edit import mirror,mirror_readable,raccord,raccord_document,ContourWalk
from selection import PICK_PROMPT

def walk_widgets(w):
    return [d for c in w.winfo_children() for d in [c]+walk_widgets(c)]

# 0.19.43: a smoothing waiting as a timer (Advanced.schedule_smooth) is made before any display asked by update_idletasks (a
# window placed by the mouse, a message shown at once…): Tk never shows the new lines raw before it, as when it came at idle.
_REAL_IDLE=tk.Misc.update_idletasks
def _smoothed_first(widget):
    try:root=widget._root()
    except (AttributeError,RuntimeError):root=None
    job=getattr(root,'__dict__',{}).get('_smooth_idle') if root is not None else None
    if job:
        try:root.after_cancel(job)
        except (tk.TclError,ValueError):pass
        try:root.smooth_now()
        except Exception:root.report_callback_exception(*__import__('sys').exc_info())   # (review: as Tk reports a callback's error, never into the window being placed)
    start=time.perf_counter()
    try:return _REAL_IDLE(widget)
    finally:
        # (0.19.51) in lenteurs.txt: what Tk does while asked to finish what waits (layout, displays): at his start, the
        # first drawing (« plus tard (<lambda>) · dessin 221–355 ms », 2–10 ms here) may be Windows laying the window out
        try:__import__('slow_log').add('update_idletasks',time.perf_counter()-start)
        except Exception:pass
tk.Misc.update_idletasks=_smoothed_first

# Tools that work on a whole piece (0.16.15 vocabulary: « Sélectionner polyligne »).
STEP_PROMPTS=('Sélectionner','Choisir','Placer','Cliquer','Cliquez','Survoler','Saisir','Tracer')
WHOLE_PIECE_TOOLS=frozenset({'notch','part_name','material','offset_all','offset_part','offset_vertex','explode','rect_path','copy_notch'})
from entity_rules import carrier   # (bug hunt 0.19.49)
STITCH_TOOLS=('stitch','stitch_part')
# 0.19.40: tools working on a piece's edge: a line of the « Préparation » type only when nothing else is within reach (pick)
PREP_SHY=frozenset({'notch','stitch','stitch_part','offset_all','offset_part','offset_vertex','strap_round','strap_point','strap_belt','belt_holes','buckle_slot','part_name','material','rect_path'})
# 0.19.16: what stays without a valid licence (lecture seule): select, measure, the checks (their changes ask for
# the licence through snapshot), the layers shown or hidden.
READ_ONLY_TOOLS=frozenset({'select','measure','assembly','assembly_bag','contours_check','prep_layer','precut_layer','recut_layer'})
# Tools that place points: the piece under the mouse shows its anchor points (0.16.30).
SIZED_RECTS=('rect','rect_center','rect_round')
ANCHOR_TOOLS=frozenset({'line','poly','rect','rect_center','rect_round','rect_rot','para','circle_radius','circle_diameter','circle_2p','circle_3p',
    'arc_radius','arc_3p','arc_center','spline_fit','ellipse_center','ellipse_box','ellipse_axis','measure','dimension','dimension_aligned','drill','strap_piece','toron'})
# 0.19.40: the tools that draw a shape point by point (Ctrl+Z takes back the shape under way, never the action before).
DRAWING_TOOLS=frozenset({'line','poly','rect','rect_center','rect_round','rect_rot','para','circle_radius','circle_diameter','circle_2p','circle_3p',
    'arc_radius','arc_3p','arc_center','spline_fit','ellipse_center','ellipse_box','ellipse_axis','measure','dimension','dimension_aligned',
    'radius','diameter','arc_length','angle_dimension','rect_path'})

def at_mark(host,mark):
    from craft_tools import at_distance
    return at_distance(host,mark['distance'])[0]


def arc_grip_origin(s,mode):
    """The point an arc grip ('start' / 'end') takes away, None for the other arc grips."""
    _,component,j,which=mode
    if which not in ('start','end'):return None
    from precision_geometry import primitives
    from curves import parts
    try:
        source=parts(s)[component] if s.get('components') else s;es=primitives(source)
        if j=='whole':return es[0]['a'] if which=='start' else es[-1]['b']
        j0,j1=j if isinstance(j,tuple) else (j,j)
        return es[j0]['a'] if which=='start' else es[j1]['b']
    except (IndexError,KeyError,TypeError,ValueError):return None


def primitives_of(s):
    from precision_geometry import primitives,canonical
    from curves import parts
    return [e for q in (parts(s) if s.get('components') else [canonical(s)]) for e in primitives(q)]


PLATFORM_LINE=object()   # (0.19.51) the place of « Python … · Tk … · Windows-… » in the lines given to diagnostic_written


def diagnostic_written(lines,picture=None,tk_level='?'):
    """0.19.47: the end of diagnostic.txt in a thread of work (never Tk): the pictures this computer reads and writes,
    the background picture's times (``picture``, read by Tk's thread), the DWG converter; then the file. 0.19.51: the line
    « Python … · Tk … · … » made here (PLATFORM_LINE: Tk's ``tk_level`` read by Tk's thread): platform.platform() asks
    Windows by WMI the first time (lenteurs.txt « write_diagnostic » 54–55 ms of Tk's thread at each start), Linux reads
    Python's own file (5 to 90 ms); with the short switch (display_render.switched): Tk's thread is never kept waiting."""
    try:
        import sys,platform,backdrop
        from app_paths import user_data_directory
        lines=[f'Python {platform.python_version()} · Tk {tk_level} · {platform.platform()}' if line is PLATFORM_LINE else line for line in lines]
        lines=lines+backdrop.self_test()
        if picture:lines.append(picture)
        if sys.platform=='win32':
            import exchange
            from pathlib import Path
            here=Path(exchange.__file__).resolve().parent
            try:ready=exchange.assemble_library(here)
            except OSError as exc:ready=None;lines.append('DWG : '+str(exc))
            lines.append('DWG : '+('prêt' if ready and (here/'dwg2dxf.exe').is_file() and (here/'dxf2dwg.exe').is_file() else 'convertisseur incomplet'))
        folder=user_data_directory();folder.mkdir(parents=True,exist_ok=True)
        (folder/'diagnostic.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    except Exception:pass


def enhance(Base):
 class Advanced(Base):
    def __init__(self):
        self.copy_crans=None;self.walk=None;self.walk_choices=[];self.mirror_axis=[];self.mirror_ids=[];self.mirror_mark=None;self.mirror_keep=True;self._mirror_question=None;self._report_question=None;self.copy_state=None;self.clipboard_items=[];self.mirror_phase='selection';self.mirror_box=None;self.notch_choice=None;self.notch_host=None;self.corner_result=None;self.pick_phase=None
        self._smooth_held=True   # 0.19.5: no smoothed picture before the view is first framed (see schedule_smooth)
        import slow_log
        slow_log.install()   # 0.19.21: lenteurs.txt (every moment slower than 50 ms, and a cross that stops following)
        super().__init__()
        slow_log.attach(self)
        self.after(600,self.release_smooth)
        self.status.trace_add('write',self.compact_status);self.hint.trace_add('write',self.compact_status)
        from window_caption import install
        self._caption_controller=install(self)
        from licence_ui import install as install_licence
        self._licence=install_licence(self)
        # 0.16.16: Ctrl+C / Ctrl+V copy the selected lines and paste them under the cursor.
        for key in ('<Control-c>','<Control-C>'):self.bind(key,self.clipboard_copy,add='+')
        for key in ('<Control-v>','<Control-V>'):self.bind(key,self.clipboard_paste,add='+')
        # 0.16.16: « Mise à jour disponible » when a newer Craft is installed meanwhile.
        try:
            from update_notice import watch
            self._update_notice=watch(self)
        except Exception:self._update_notice=None
        # 0.19.15: the shared edition (for his friends) looks for its updates on the Internet; nothing in his own Craft.
        try:
            from online_update import install as install_online
            install_online(self)
        except Exception:pass
        # 0.16.30: safety copies of the unsaved drawings (never the .patron files themselves).
        from autosave import install as install_autosave
        self._autosave=install_autosave(self)
        # 0.19.9: closed_for_good (the tabs answered while closing lose their copies there, then finish).
        __import__('ui_widgets').bind_own(self,'<Destroy>',lambda e:self.closed_for_good() if e.widget is self else None)   # 0.19.3: not for each widget inside
        # 0.19.47 (« encore le trace »): the window shown again (taskbar, start) looked at, painted again if Windows lost it
        if __import__('sys').platform=='win32':__import__('ui_widgets').bind_own(self,'<Map>',lambda e:__import__('gpu_display').shown_again(self) if e.widget is self else None)
        # 0.18.0: a double-click on a .crft opens Craft (association for this user only), and a
        # file double-clicked while Craft is open comes here, in a new tab.
        self.after(1500,self.register_crft);self.after(700,self.poll_open_requests);self.after(8000,self.write_diagnostic)
    def write_diagnostic(self):
        """0.18.0: diagnostic.txt in Craft's data folder (written again at each start): what this
        computer does for the display (smoothed plan and icons) and with pictures. 0.19.47 (vitesse): what only Tk knows
        read here; the pictures tried, the DWG converter checked and the file written by a thread of work (196 to 268 ms
        of a stopped window at each start on his PC, lenteurs.txt « plus tard (write_diagnostic) »): never a call of Tk
        there, the same lines in the same order."""
        try:
            import display_render,craft_version,threading
            lines=[f'Craft {craft_version.VERSION} — {time.strftime("%d/%m/%Y %H:%M")}',PLATFORM_LINE,   # (0.19.51: made by the thread)
                   'Lissage du plan : '+display_render.STATUS.get('plan','pas encore'),
                   'Lissage des icônes : '+display_render.STATUS.get('icons','pas encore'),
                   __import__('gpu_display').status()]   # 0.19.31
            try:
                import bootstrap
                started=bootstrap.startup_summary()
                if started:lines.insert(2,started)   # 0.19.5
            except Exception:pass
            import background_ui
            full,quick=background_ui.TIMES.get('full'),background_ui.TIMES.get('quick')
            picture=None
            if full:   # 0.19.7: what a view of the background picture costs here (sharp, and lighter during a gesture)
                s=lambda v:f'{v:.2f}'.replace('.',',')+' s'
                picture=f'Image de fond : {s(full[0])} ({full[1][0]} × {full[1][1]})'+(f', allégée {s(quick[0])}' if quick else '')
            thread=threading.Thread(target=display_render.switched,args=(diagnostic_written,lines,picture,self.tk.call('info','patchlevel')),name='Craft diagnostic',daemon=True)
            self._diagnostic_thread=thread;thread.start()   # (the tests wait for it)
        except Exception:pass
    def register_crft(self):
        import os,threading
        if os.name!='nt':return
        def work():
            try:
                import doc_files
                from craft_brand import ensure_icon
                doc_files.register_file_type(ensure_icon())
            except Exception as exc:
                try:
                    from craft_brand import brand_error
                    brand_error('Association .crft : '+str(exc))
                except Exception:pass
        threading.Thread(target=__import__('display_render').switched,args=(work,),daemon=True).start()   # (0.19.51: the short switch)
    def poll_open_requests(self):
        if self.__dict__.get('_waiting_work'):   # 0.19.49: a DWG Mozart being written (wait_for_work): opened after it
            try:self.after(700,self.poll_open_requests)
            except tk.TclError:pass
            return
        try:
            import doc_files
            from app_paths import running_directory
            files=doc_files.take_requests(running_directory())
        except Exception:files=[]
        for f in files:self.open_path(f)
        if files:self.bring_to_front()
        try:self.after(700,self.poll_open_requests)
        except tk.TclError:pass
    def bring_to_front(self):
        import os
        try:
            if self.wm_state()=='iconic':self.deiconify()   # (review 0.19.47: state() is the document's, copied whole)
            self.lift();self.focus_force()
            if os.name=='nt':
                import ctypes
                from ctypes import wintypes
                user=ctypes.windll.user32
                user.GetAncestor.argtypes=[wintypes.HWND,wintypes.UINT];user.GetAncestor.restype=wintypes.HWND
                user.SetForegroundWindow.argtypes=[wintypes.HWND];user.SetForegroundWindow.restype=wintypes.BOOL
                user.SetForegroundWindow(user.GetAncestor(self.winfo_id(),2))   # GA_ROOT: the taskbar window
        except Exception:pass
    def guard(self):
        ok=super().guard()
        if ok and self.__dict__.get('_autosave') and not getattr(self,'_skip_current_guard',False):   # 0.19.9: (not when not asked)
            closing=self.__dict__.get('_closing')
            if closing is None:self._autosave.settle_current()   # saved, or left unsaved on purpose
            elif self.__dict__.get('doc_key'):closing.append(self.doc_key)   # 0.19.9: settled once Craft really closes
        return ok
    def closing(self,run):
        """0.19.9: ``run`` (Quitter, mise à jour) asks every tab « Enregistrer ? » before Craft closes: a tab left
        unsaved keeps its safety copy until Craft really closes (closed_for_good). An Annuler on a later tab kept
        Craft open with an earlier tab still unsaved, its copy deleted."""
        outer=self.__dict__.get('_closing') is None
        if outer:self._closing=[]
        try:return run()
        finally:
            if outer:self._closing=None
    def close(self):
        if self.__dict__.get('_waiting_work'):self.bell();return None   # 0.19.49: a DWG Mozart being written (wait_for_work): never closed under it
        return self.closing(super().close)
    def update_from_zip(self,file=None):
        if self.__dict__.get('_waiting_work'):self.bell();return None   # 0.19.49 (as close)
        run=super().update_from_zip   # 0.19.15: ``file``, an update downloaded and checked (online_update)
        return self.closing(lambda:run(file))
    def closed_for_good(self):
        """0.19.9: the window is destroyed: the drawings answered on the way lose their copies, then the empty folder goes."""
        for key in self.__dict__.get('_closing') or ():self._autosave.forget(key)
        self._autosave.finish()
        __import__('slow_log').flush()   # 0.19.21: what was noted in the last seconds
    def save_doc(self):
        source=self.__dict__.get('mozart_source')
        from pathlib import Path
        self.space_settle()   # (review 0.19.49: « 50 », Espace, then Enregistrer: the value first, never given during the writing)
        self.__dict__.pop('_dwg_left',None)
        if self.filename and not Path(self.filename).parent.is_dir():
            # 0.19.22 (found before installing): its folder is gone (the USB key taken out): Enregistrer sous, not an error
            self.status.set('Dossier introuvable : '+str(Path(self.filename).parent)+' — choisir où enregistrer.')
            ok=self.save_as()
            if ok and self.__dict__.get('_autosave'):self._autosave.settle_current()
            return ok
        # 0.19.13 (aller-retour Craft ↔ Mozart): a pattern opened from a DWG Mozart is saved there again
        ok=self.save_mozart_dwg(source) if source and not self.filename else super().save_doc()
        # 0.19.22 (found before installing): what the DWG cannot keep (image de fond, image du modèle, fournitures) is
        # not lost: the tab stays « * » and Enregistrer sous offers a .crft that keeps everything
        if ok and source and not self.filename and self.dirty():
            if not self.__dict__.pop('_dwg_left',True):return ok   # (review 0.19.49) changed while it was written: « * », its safety copies go on
            ok=self.save_as()
        if ok and self.__dict__.get('_autosave'):self._autosave.settle_current()
        return ok
    def save_mozart_dwg(self,source):
        """0.19.13 Enregistrer (Ctrl+S) on a pattern opened from a DWG Mozart: written there again like Exporter ›
        DWG Mozart, no window. The file as it was opened is kept beside it once, as « <nom>.bak » (AutoCAD's way:
        renamed .dwg, it opens again). Enregistrer sous… still makes a .crft. An image de fond is not in a DWG."""
        import doc_files,model_info,shutil
        from pathlib import Path
        from mozart_export import export_mozart
        if self._action:self.finish_action()
        if getattr(self,'export_busy',False):self.status.set('Une conversion DWG est déjà en cours.');return False
        if hasattr(self,'licence_export') and not self.licence_export():return False
        if not self.items:return super().save_doc()
        target=Path(source['file']);backup=target.with_suffix('.bak')
        if not target.parent.is_dir():return super().save_doc()   # its folder is gone (a USB key taken out): Enregistrer sous
        infos=model_info.dated(self.__dict__.get('infos'),str(target),self.dirty())
        self.status.set('Enregistrement du DWG Mozart…');self.update_idletasks()
        kept=False
        # 0.19.49 (« enregistrer un gros DWG Mozart sans figer la fenêtre », Keith Haring 5 s): written by a worker thread
        # (as Exporter › DWG Mozart), waited for with the window still drawn (wait_for_work); what is written is what is clean
        # after (taken before: anything changed meanwhile stays « * »)
        written=(clone(self.items),clone(self.workspace),clone(self.__dict__.get('infos')))
        args=(target,clone(self.items),clone(self.workspace),clone(infos),clone(self.archives),model_info.model_name(self))   # 0.19.17: fast copies
        try:
            if not source.get('kept') and target.is_file():shutil.copyfile(target,backup);source['kept']=kept=True
            self.wait_for_work('Enregistrement du DWG Mozart…',target.name,lambda:export_mozart(*args))
        except Exception as exc:
            from cad import KeptBeside
            self.status.set('DWG Mozart enregistré à côté : '+exc.beside.name if isinstance(exc,KeptBeside) else 'DWG Mozart non enregistré.')
            show_error('Enregistrer',str(exc) if isinstance(exc,KeptBeside) else f'{target.name} : {exc}',self);return False
        back=self.__dict__.get('background')
        if self.__dict__.get('infos')==written[2]:self.infos=infos   # (review: changed during the writing: kept, still « * »)
        self.clean,self.clean_workspace=written[:2]
        lost=back or (infos or {}).get('image') or (infos or {}).get('fournitures')   # 0.19.24: not the assemblies of the bag (said below:
        # kept while the pattern is open; each check would otherwise ask « Enregistrer sous » at each Ctrl+S of a DWG)
        self._dwg_left=bool(lost)   # (review 0.19.49: save_doc asks « Enregistrer sous » for these only)
        if not lost:self.clean_background=dict(back) if back else None;self.clean_infos=clone(infos)   # 0.19.22: else still « * »
        doc_files.remember(self.prefs,str(target));self.persist_preferences()
        if hasattr(self,'rebuild_recent_menu'):self.rebuild_recent_menu()
        self.refresh()
        # 0.19.14: what a DWG cannot keep is said (the image of the Infos du modèle, the fournitures too)
        # (0.19.25: the angle of a turned text is kept: the converter fixed)
        left=[what for what,there in (('l’image de fond',back),('l’image du modèle',(infos or {}).get('image')),('les fournitures',(infos or {}).get('fournitures')),
                                      ('les assemblages du sac (gardés tant qu’il est ouvert)',(infos or {}).get('assemblages'))) if there]   # 0.19.24
        self.status.set('DWG Mozart enregistré : '+target.name+(f' (l’ancien gardé en {backup.name})' if kept else '')
                        +(' ; pas dans le DWG : '+', '.join(left)+' (Enregistrer sous… : un .crft les garde).' if left else '.'))
        return True
    def wait_for_work(self,title,detail,work):
        """(0.19.49, « enregistrer un gros DWG Mozart sans figer la fenêtre ») ``work()`` run by a worker thread (never a Tk
        call there: it is given copies), its end waited for with Craft's window still drawn and its timers running
        (wait_variable): a small window says what is under way and takes the mouse and the keyboard (grab; under
        Windows Craft's window is disabled meanwhile, as under a Windows dialog), the tabs do not change (_tabs_busy),
        another DWG work waits (export_busy), a file to open and the closing of Craft wait (poll_open_requests, close):
        the document written is the one shown. Its exception is raised here, in the main thread."""
        import os,queue,threading,modern_style,slow_log
        from craft_refined import shade
        from display_render import fast_switch
        done=queue.Queue();began=slow_log.wait_begins()   # (review 0.19.51: a message read meanwhile is in its time, taken off once)
        def run():
            try:
                with fast_switch():work()   # (Tk's thread never waits 5 ms for each of its calls: 170 → … ms)
                done.put(None)
            except BaseException as exc:done.put(exc)
        busy=(self.__dict__.get('_tabs_busy',False),getattr(self,'export_busy',False),self.__dict__.get('_waiting_work',False))
        try:focus=self.focus_get()
        except (tk.TclError,KeyError):focus=None
        self._tabs_busy=True;self.export_busy=True;self._waiting_work=True
        win=None;disabled=False;job=None;answer=[]
        try:
            panel=self.p['panel'];win=tk.Toplevel(self);win.withdraw();win.title(title.rstrip('…'));win.configure(bg=panel)
            win.transient(self);win.resizable(False,False);win.protocol('WM_DELETE_WINDOW',lambda:None)
            self.label(win,title).pack(padx=24,pady=(16,2),anchor='w')
            if detail:self.label(win,detail,fg=modern_style.tokens_for(self.p)['muted']).pack(padx=24,anchor='w')
            bar=tk.Canvas(win,width=240,height=6,bg=shade(panel,-12),highlightthickness=0);bar.pack(padx=24,pady=(10,18))
            block=bar.create_rectangle(0,0,60,6,fill=self.p['accent'],outline='')
            win.geometry(f'+{self.winfo_rootx()+160}+{self.winfo_rooty()+110}');win.deiconify()
            if os.name=='nt':
                try:self.attributes('-disabled',True);disabled=True
                except tk.TclError:pass
            try:win.grab_set()
            except tk.TclError:pass   # (not yet viewable: asked again below)
            win.focus_set()
            threading.Thread(target=run,daemon=True,name='craft-work').start()   # (its window made first: never waiting for the worker)
            ended=tk.BooleanVar(win,value=False);step=[0]
            def check():
                nonlocal job
                try:answer.append(done.get_nowait())
                except queue.Empty:
                    try:   # (its little window gone: still waited for, never a wait without end)
                        step[0]+=1;x=step[0]*6%300-60;bar.coords(block,x,0,x+60,6)
                        if win.grab_current() is None:win.grab_set()
                    except Exception:pass   # (review: also KeyError: a window of Tcl's own holding the grab, tk_messageBox, a ttk list…)
                    job=self.after(40,check);return
                ended.set(True)
            job=self.after(40,check)
            while not answer:win.wait_variable(ended)   # (Craft drawn, its timers run; returns at the end of the work)
        finally:
            if job is not None:
                try:self.after_cancel(job)
                except (ValueError,tk.TclError):pass
            if disabled:
                try:self.attributes('-disabled',False)   # (before the little window goes: Windows gives Craft back its focus)
                except tk.TclError:pass
            if win is not None:
                try:win.grab_release();win.destroy()
                except tk.TclError:pass
            self._tabs_busy,self.export_busy,self._waiting_work=busy
            slow_log.wait_ends(began)   # (the window answered meanwhile: never noted as a slowness)
            try:(focus if focus is not None and focus.winfo_exists() else self.canvas).focus_set()   # (review: where Ctrl+S was typed)
            except (tk.TclError,AttributeError):pass
        if answer and answer[0] is not None:raise answer[0]
    def write_doc(self,file):
        """0.18.5 (n° 13): an object beyond ±100 m cannot be saved: it is selected and shown, with a message."""
        far=self.far_objects()
        if far:
            from geometry import bounds as box_of
            import export_check
            i=far[0];self.finish_action() if self._action else None;self.cancel();self.tool.set('select')
            self.selected_set=set(far);self.selected=i
            rest=[s for j,s in enumerate(self.items) if j not in far]
            try:x,y,X,Y=box_of([self.items[i]])
            except (ValueError,KeyError,TypeError):x=y=X=Y=0
            try:
                a,b,A,B=box_of(rest) if rest else (0,0,0,0)
                gap=math.hypot(max(a-X,x-A,0),max(b-Y,y-B,0))
            except (ValueError,KeyError,TypeError):gap=max(abs(x),abs(y),abs(X),abs(Y))
            export_check.zoom_on(self,dict(ids=list(far)))
            what=self.object_noun(self.items[i])
            it='la' if what in ('Polyligne','Ligne','Spline','Piqûre','Mèche','Cote') else 'le'   # (review 0.19.49) « Cercle … : le supprimer »
            messagebox.showwarning('Enregistrer',f'{what} à {gap/1000:.0f} m du dessin : {it} supprimer ou {it} rapprocher avant d’enregistrer.'
                                   +(f'\n({len(far)} objets hors limites, sélectionnés.)' if len(far)>1 else ''),parent=self)
            return False
        try:return super().write_doc(file)
        except OSError as exc:   # 0.19.22: a clear message (a key taken out, a folder read-only, a disk full…), the work kept
            from pathlib import Path
            from cad import KeptBeside
            if isinstance(exc,KeptBeside):   # 0.19.44: written beside it (still « * »: Enregistrer again puts it in its place)
                self.status.set('Enregistré à côté : '+exc.beside.name)
                messagebox.showwarning('Enregistrer',f'{exc}\n\nUne fois {exc.target.name} fermé dans l’autre logiciel, Enregistrer le remplace.',parent=self)
                return False
            self.status.set('Pas enregistré.')
            messagebox.showerror('Enregistrer',f'{Path(file).name} n’a pas pu être écrit ({exc.strerror or exc}).\nRien n’est perdu : Enregistrer sous… un autre dossier.',parent=self)
            return False
    def far_objects(self):
        from geometry import bounds as box_of
        out=[]
        for i,s in enumerate(self.items):
            try:x,y,X,Y=box_of([s])
            except (ValueError,KeyError,TypeError,IndexError):continue
            if max(abs(x),abs(y),abs(X),abs(Y))>100000:out.append(i)
        return out
    def object_noun(self,s):
        if s.get('drill'):return 'Pointé' if s.get('drill_point') else 'Mèche'
        if s.get('is_notch'):return 'Cran'
        if s.get('annotation'):return 'Texte'
        if s.get('dimension_group'):return 'Cote'
        word=__import__('anchor_stack').object_word(s)
        return word.split()[-1].replace('l’','').capitalize()
    def save_as(self):
        ok=super().save_as()
        if ok and self.__dict__.get('_autosave'):self._autosave.settle_current()
        return ok
    def before_build(self):
        super().before_build();self.variants={};self.prefs['tool_variants']={}
    def build(self):
        super().build()
        from licence_ui import ajouter_menu
        ajouter_menu(self)
        try:__import__('online_update').ajouter_menu(self)   # 0.19.15: Aide › Rechercher une mise à jour (shared edition)
        except Exception:pass
        self.add_background_menu()
        self.add_second_step_exports()
        self.place_section_tabs()
        self.canvas.bind('<Configure>',self.canvas_configured)   # 0.18.5: replaces the immediate redraw (one drawing after the resize)
        self.canvas.bind('<ButtonRelease-2>',self.pan_end,add='+')   # 0.18.2: here, kept after « Personnaliser l'interface »
        self.canvas.bind('<Tab>',self.next_stacked)   # 0.18.5: next of the stacked anchors / grips
        if 'command_entry' in self.__dict__:
            self.command_entry.bind('<Tab>',self.next_stacked)   # 0.19.22: a value being typed (Tab went to the bottom bar)
            self.command_entry.bind('<KeyPress>',self.space_key,add='+')   # 0.19.42: « 5 cm » with a space
        __import__('dash_lines').install(self)   # 0.18.5: plan dashes drawn dash by dash (Tk under Windows ignores their lengths)
        self.install_value_bubble()
        # 0.19.0: the menu bar shows the menus added by every layer; every field of the window in the modern look.
        strip=self.__dict__.get('menu_strip')
        if strip is not None and hasattr(strip,'sync'):strip.sync()
        __import__('modern_style').restyle(self.root_frame)
        self.outline_footer()
    def outline_footer(self):
        """0.19.2: the buttons of the bottom bar (Recentrer, Ancrages, ORTHO, Grille…) each in a fine
        outline, their tiles (switch on, hover) inside it."""
        footer=self.__dict__.get('footer')
        if footer is None:return
        import modern_style
        stack=[footer]
        while stack:
            w=stack.pop()
            try:
                if w.winfo_class()=='Canvas' and getattr(w,'craft_icon',None):modern_style.outlined(w)
                stack.extend(w.winfo_children())
            except tk.TclError:pass
    def add_background_menu(self):
        """0.18.0: Fichier › Image de fond ▸, just before Quitter."""
        import background_ui
        try:
            menu=self.nametowidget(self.cget('menu'))
            for i in range(menu.index('end')+1):
                if menu.type(i)=='cascade' and menu.entrycget(i,'label')=='Fichier':
                    fichier=self.nametowidget(menu.entrycget(i,'menu'));end=fichier.index('end')
                    at=next((k for k in range(end+1) if fichier.type(k)=='command' and fichier.entrycget(k,'label').startswith('Quitter')),end+1)
                    fichier.insert_cascade(at,label='Image de fond',menu=background_ui.build_menu(self,fichier));break
        except tk.TclError:pass
    def add_second_step_exports(self):
        """0.18.1: Exporter › Surcoupe 2e étape (the menu and Fichier › Exporter): the pieces to
        recut in the précoupes, for the cutting machine."""
        def cascades(menu):
            end=menu.index('end')
            return [] if end is None else [(menu.entrycget(i,'label'),self.nametowidget(menu.entrycget(i,'menu'))) for i in range(end+1) if menu.type(i)=='cascade']
        try:
            bar=self.nametowidget(self.cget('menu'));menus=[]
            for label,sub in cascades(bar):
                if label=='Exporter':menus.append(sub)
                elif label=='Fichier':menus+=[m for name,m in cascades(sub) if name=='Exporter']
            for export in menus:
                # 0.19.8: the pattern written like Mozart's own, right after « DWG… »
                end=export.index('end');at=next((i+1 for i in range(end+1) if export.type(i)=='command' and export.entrycget(i,'label')=='DWG…'),end+1)
                # 0.19.10: « DXF Mozart » out (Mozart opens only the DWG; its DXF are the cutting files, made into MDX)
                export.insert_command(at,label='DWG Mozart…',command=lambda:self.export_mozart_file('dwg'))
                export.insert_command(at+1,label='DXF de coupe (AAMA-Teseo)…',command=self.export_cut_files)
                export.add_separator()
                for kind in ('dxf','dwg'):export.add_command(label=f'Surcoupe 2e étape · {kind.upper()}…',command=lambda k=kind:self.export_second_step(k))
                export.add_separator()   # 0.19.13: the open ends in red, the closed pieces in green, the small gaps closed
                export.add_command(label='Contrôle des contours…',command=lambda:__import__('contours_ui').show(self))
                export.add_command(label='Contrôle d’assemblage du sac…',command=lambda:__import__('assembly_ui').bag(self))   # 0.19.24
        except tk.TclError:pass
    def export_mozart_file(self,kind='dwg'):
        """0.19.8 Exporter › DWG Mozart… / DXF Mozart…: the whole drawing written like a Mozart pattern (each
        piece with its name and material blocks, its crans and pointés, the préparations, the base and the
        model sheet), so that Mozart takes the pieces for its own. No 30 mm check: Mozart places them itself."""
        import doc_files,queue,threading,model_info,fiches
        from pathlib import Path
        from tkinter import filedialog
        from mozart_export import export_mozart
        if getattr(self,'export_busy',False):self.status.set('Une conversion DWG est déjà en cours.');return None
        if not self.items:messagebox.showinfo('Export Mozart','Le dessin est vide.',parent=self);return None
        if hasattr(self,'licence_export') and not self.licence_export():return None
        model=model_info.model_name(self);name=fiches.safe(model or 'Patron')
        options=dict(parent=self,defaultextension='.'+kind,filetypes=[(f'{kind.upper()} Mozart (*.{kind})','*.'+kind)],initialfile=name+' - Mozart.'+kind);folder=doc_files.initial_dir(self.prefs)
        if folder:options['initialdir']=folder
        file=filedialog.asksaveasfilename(**options)
        if not file:return None
        doc_files.remember_folder(self.prefs,file);self.persist_preferences()
        args=(clone(self.items),clone(self.workspace),clone(self.__dict__.get('infos')),clone(self.archives),model)
        result=queue.Queue();self.export_busy=True;self.status.set('Export Mozart en cours…')
        def work():
            try:export_mozart(file,*args);result.put((True,file))
            except Exception as exc:result.put((False,str(exc)))
        threading.Thread(target=__import__('display_render').switched,args=(work,),daemon=True).start()   # (0.19.51: the short switch)
        def poll():
            try:ok,detail=result.get_nowait()
            except queue.Empty:self.after(100,poll);return
            self.export_busy=False
            if ok:self.status.set(f'{kind.upper()} Mozart exporté : '+Path(detail).name)
            else:self.status.set('Échec de l’export Mozart.');show_error('Export Mozart',detail,self)
        self.after(100,poll);return file
    def export_cut_files(self):
        """0.19.10 Exporter › DXF de coupe (AAMA-Teseo)…: one cutting DXF per material in a chosen folder, written
        like Mozart's (« Mozart-AAMA-Teseo »), named « <modèle> <matière>.dxf », for the cutting software's MDX.
        A piece without a material is left out (said). Existing files are replaced only when he says so."""
        import doc_files,model_info,fiches,os,tempfile
        from pathlib import Path
        from tkinter import filedialog
        from mozart_export import cut_files
        if not self.items:messagebox.showinfo('DXF de coupe','Le dessin est vide.',parent=self);return None
        if hasattr(self,'licence_export') and not self.licence_export():return None
        model=model_info.model_name(self) or 'Patron'
        try:files,missing=cut_files(clone(self.items),model)
        except (ValueError,KeyError,TypeError,IndexError) as exc:messagebox.showerror('DXF de coupe',str(exc),parent=self);return None
        if not files:
            messagebox.showinfo('DXF de coupe','Aucune pièce avec une matière : donner d’abord un nom et une matière aux pièces (Coupe externe).',parent=self);return None
        options=dict(parent=self,title='Dossier des DXF de coupe',mustexist=True);start=doc_files.initial_dir(self.prefs)
        if start:options['initialdir']=start
        folder=filedialog.askdirectory(**options)
        if not folder:return None
        names={}
        for material in files:
            base=fiches.safe(f'{model} {material}'.replace('/','-'));name=base+'.dxf';k=2
            while name.lower() in {n.lower() for n in names.values()}:name=f'{base} ({k}).dxf';k+=1
            names[material]=name
        existing=[n for n in names.values() if (Path(folder)/n).exists()]
        if existing and not messagebox.askyesno('DXF de coupe','Remplacer ces fichiers ?\n'+'\n'.join(existing),parent=self):return None
        written=[];beside=[]
        from cad import temporary_beside,finish_write,KeptBeside   # 0.19.44: tried again while Windows holds the file, never lost
        try:
            for material,text in files.items():
                target=Path(folder)/names[material]
                temp=temporary_beside(target,'.dxf')
                try:
                    from exchange import UNICODE_ESCAPE
                    with open(temp,'w',encoding='cp1252',errors=UNICODE_ESCAPE,newline='\n') as f:f.write(text)   # 0.19.22
                except BaseException:
                    temp.unlink(missing_ok=True);raise
                try:finish_write(temp,target)
                except KeptBeside as exc:beside.append(exc);continue   # (review) said below, the other matières written
                written.append(str(target))
        except OSError as exc:messagebox.showerror('DXF de coupe',f'Fichier non écrit : {exc}',parent=self);return None
        if beside:messagebox.showwarning('DXF de coupe','\n\n'.join(str(e) for e in beside),parent=self)
        if not written:return [str(e.beside) for e in beside]
        doc_files.remember_folder(self.prefs,written[0]);self.persist_preferences()
        n=len(written);self.status.set(f'DXF de coupe : {n} fichier{"s" if n>1 else ""}, un par matière'+(f' ; {missing} pièce{"s" if missing>1 else ""} sans matière non exportée{"s" if missing>1 else ""}' if missing else '')+'.')   # 0.19.40: plurals written out, as elsewhere
        return written
    def export_second_step(self,kind):
        """The pieces to recut in the précoupes (Coupe externe, with the précoupe's name and material,
        their crans and inner lines), where they are on the plan; no 30 mm check (they are recut in
        the glued précoupe)."""
        import surcoupe,doc_files,queue,threading
        from pathlib import Path
        from tkinter import filedialog
        if getattr(self,'export_busy',False):self.status.set('Une conversion DWG est déjà en cours.');return None
        try:items=surcoupe.second_step(self.items)
        except (ValueError,KeyError,TypeError,IndexError) as exc:messagebox.showerror('Surcoupe',str(exc),parent=self);return None
        if not items:messagebox.showinfo('Surcoupe 2e étape','Aucune précoupe avec un nom et une matière : faire d’abord une « Précoupe en série ».',parent=self);return None
        if hasattr(self,'licence_export') and not self.licence_export():return None
        import model_info
        import fiches
        name=fiches.safe(model_info.model_name(self) or 'Patron')
        options=dict(parent=self,defaultextension='.'+kind,filetypes=doc_files.export_types(kind),initialfile=name+' - surcoupe.'+kind);folder=doc_files.initial_dir(self.prefs)
        if folder:options['initialdir']=folder
        file=filedialog.asksaveasfilename(**options)
        if not file:return None
        doc_files.remember_folder(self.prefs,file);self.persist_preferences()
        items=clone(items)
        if kind=='dxf':
            from exchange import export_dxf
            try:export_dxf(file,items)
            except (ValueError,OSError) as exc:messagebox.showerror('Surcoupe 2e étape',str(exc),parent=self);return None
            self.status.set('Surcoupe (2e étape) exportée : '+Path(file).name);return file
        from exchange import export_dwg
        result=queue.Queue();self.export_busy=True;self.status.set('Conversion DWG en cours…')
        def work():
            try:export_dwg(file,items);result.put((True,file))
            except Exception as exc:result.put((False,str(exc)))
        threading.Thread(target=__import__('display_render').switched,args=(work,),daemon=True).start()   # (0.19.51: the short switch)
        def poll():
            try:ok,detail=result.get_nowait()
            except queue.Empty:self.after(150,poll);return
            self.export_busy=False
            if ok:self.status.set('Surcoupe (2e étape) exportée : '+Path(detail).name)
            else:self.status.set('Échec de l’export DWG.');show_error('Surcoupe 2e étape',detail,self)
        self.after(150,poll);return file
    def open_mozart(self,file):
        """0.17.1 « Ouvrir… » on a Mozart DXF or DWG: a new tab named after the file, with its pieces,
        crans, names, materials, preparations, pointés and base. Nothing is added to the archives;
        « Enregistrer » makes a .crft (0.18.0); 0.19.13: a DWG Mozart is written there again (save_mozart_dwg)."""
        from pathlib import Path
        import mozart_import
        if Path(file).suffix.lower()!='.dwg':
            try:result=mozart_import.read_mozart_dxf(file,self.p['guides'])
            except (ValueError,OSError) as exc:messagebox.showerror('Ouvrir',str(exc),parent=self);return None
            return self.show_mozart(result,file)
        # 0.18.0: the DWG converter is shipped with Craft (LibreDWG), nothing to install.
        if getattr(self,'export_busy',False):self.status.set('Une conversion DWG est déjà en cours.');return None
        import queue,threading
        done=queue.Queue();self.export_busy=True;self.status.set('Ouverture du DWG…')
        def work():
            try:done.put((True,mozart_import.read_mozart(file,self.p['guides'])))
            except Exception as exc:done.put((False,str(exc)))
        threading.Thread(target=__import__('display_render').switched,args=(work,),daemon=True).start()   # (0.19.51: the short switch)
        def poll():
            try:ok,value=done.get_nowait()
            except queue.Empty:self.after(150,poll);return
            self.export_busy=False
            if not ok:self.status.set('Ouverture du DWG impossible.');show_error('Ouvrir',value,self);return   # 0.19.19: converter blocked: what to do
            self.show_mozart(value,file)
            if hasattr(self,'adopt_leftover'):   # 0.19.44 (review): a save cut short, once the DWG is shown
                self.adopt_leftover(file);self.offer_unfinished(Path(file))
        self.after(150,poll);return None
    def show_mozart(self,result,file):
        from pathlib import Path
        import preparations as prep
        items=result['items']
        for s in items:
            data=s.get('preparation')
            if not data:continue
            # Craft's way: types capitalised, thickness in tenths, the same label as the Préparation tool.
            data['type']=(data.get('type') or '').capitalize()
            if data.get('thickness') and data['thickness']<10:data['thickness']=round(data['thickness']*10,2)
            if data.get('kind')=='surcoupe':data['thickness']=None   # 0.18.1: the band of a précoupe
            if data.get('kind') in ('parage','teinte','surcoupe'):
                data['label']=prep.label(data['kind'],'' if data['kind'] in ('teinte','surcoupe') else data['type'],data.get('length'),data.get('thickness'))
                s['style']=dict(s.get('style') or {},color=prep.BASE[data['kind']],role='preparation')
        report=result['report']
        # 0.18.1: Mozart's crans at their true size and shape (no longer 20 % smaller).
        with self.held_redraw():   # 0.18.7: one drawing instead of five
            self.reset_doc(items,result['workspace'],None,None,result.get('infos'))   # 0.19.13: with Mozart's model sheet
            self.display_name=Path(file).stem;self.project_model=report.get('model') or self.project_model or Path(file).stem
            # 0.19.13: a DWG Mozart is saved there again by Enregistrer (aller-retour Craft ↔ Mozart)
            self.mozart_source=dict(file=str(file),kept=False) if report.get('mozart') and Path(file).suffix.lower()=='.dwg' else None
            self.stash_doc();self.refresh()
        n=lambda key,word:f'{report[key]} {word}{"s" if report[key]>1 else ""}'   # (review 0.19.49) plurals written: « 1 pièce », never « 1 pièces »
        self.status.set(f"Mozart : {n('pieces','pièce')}, {n('crans','cran')}, {n('preparations','préparation')}, {n('drills','pointé')}.")
        if report.get('warnings'):messagebox.showinfo('Import Mozart','\n'.join(report['warnings'][:12]),parent=self)
        return items
    # 0.16.28: the typed value is drawn ON the plan (like the crosshair) instead of moving a
    # Windows entry window with the mouse, which left a trail of boxes when moving fast.
    # The real entry still receives the keys, placed out of sight.
    def install_value_bubble(self):
        entry=self.__dict__.get('command_entry')
        if entry is None:return
        real_place,real_forget=entry.place,entry.place_forget
        self._real_entry_place=real_place;self._bubble_at=None;self._bubble_placeholder=''
        def place(*args,**kw):
            x=kw.get('x',0);y=kw.get('y',0)
            if kw.get('relx') is not None or kw.get('in_') is not None:self._entry_parked=False;return real_place(*args,**kw)
            self.place_value_bubble(x,y)
        def forget():
            self._bubble_at=None;self._bubble_placeholder='';self._entry_parked=False
            try:self.canvas.delete('value_bubble')
            except tk.TclError:pass
            return real_forget()
        entry.place=place;entry.place_forget=forget
        if not self.__dict__.get('_bubble_traced'):   # (review 0.19.49) once: build() runs again at each rebuild_ui, command_value stays
            self._bubble_traced=True;self.command_value.trace_add('write',lambda *a:self.redraw_value_bubble())
    def value_bubble_width(self,text):
        from tkinter import font
        f=self.__dict__.get('_bubble_font')
        if f is None:f=self._bubble_font=font.Font(self.canvas,family='Segoe UI',size=10)
        return f.measure(text or ' ')+10
    def bubble_size(self):
        value=self.command_value.get();text=value or self._bubble_placeholder
        unit=self.bubble_unit(value) if value else ''   # 0.18.5 (B): the unit after a typed value, in grey
        return text,unit,self.value_bubble_width(text)+(self.value_bubble_width(unit)-6 if unit else 0)
    def place_value_bubble(self,x,y,center=False):
        text,unit,w=self.bubble_size();h=21
        if center:x,y=x-w/2,y-h/2
        W,H=self.canvas.winfo_width(),self.canvas.winfo_height()
        x=max(2,min(W-w-2,x));y=max(2,min(H-h-2,y))
        self._bubble_at=(x,y)
        if not self.__dict__.get('_entry_parked'):
            try:self._real_entry_place(x=-4000,y=-4000,width=60,height=21);self._entry_parked=True   # keys only, out of sight
            except tk.TclError:pass
        self.redraw_value_bubble()
    def redraw_value_bubble(self):
        at=self.__dict__.get('_bubble_at')
        if 'canvas' not in self.__dict__:return
        self.canvas.delete('value_bubble')
        if at is None:return
        self.canvas.delete('live_value')   # 0.18.5: the typed value replaces the live one
        value=self.command_value.get();text,unit,w=self.bubble_size()
        x,y=at;h=21
        self.canvas.create_rectangle(x,y,x+w,y+h,fill='#ffffff',outline='#7d8187',tags='value_bubble')
        self.canvas.create_text(x+5,y+h/2,text=text,anchor='w',fill='#000000' if value else '#9a9ea4',font=('Segoe UI',10),tags='value_bubble')
        if unit:self.canvas.create_text(x+self.value_bubble_width(value)+1,y+h/2,text=unit,anchor='w',fill='#9a9ea4',font=('Segoe UI',10),tags='value_bubble')
        caret=x+5+(self.value_bubble_width(value)-10 if value else 0)
        self.canvas.create_line(caret+1,y+4,caret+1,y+h-4,fill='#000000',tags='value_bubble')
        self.canvas.tag_raise('value_bubble');self.keep_hint_clear()
    def bubble_unit(self,value):
        """The unit of the value being typed: degrees for Rotation, % for Échelle, none for a number or
        coordinates, else the drawing's unit."""
        xf=self.__dict__.get('xform');t=self.tool.get()
        if xf and xf.get('phase')=='value':return '°' if xf['kind']=='rotate' else '%'
        if t in ('surcoupe','piece_id') or any(ch in value for ch in '@#<'):return ''
        if not any(ch.isdigit() for ch in value) or value.strip().lower().endswith(('mm','cm')):return ''
        return self.units.get()
    def keep_hint_clear(self):
        """The grey step text near the cursor goes under the value box, and the small tool
        icon beside the cursor is not shown half hidden behind it."""
        box=self.value_bubble_box()
        if not box:return
        meets=lambda b:b and b[0]<box[2] and b[2]>box[0] and b[1]<box[3] and b[3]>box[1]
        for item in self.canvas.find_withtag('step_hint'):
            b=self.canvas.bbox(item)
            if meets(b):self.canvas.move(item,0,box[3]+2-b[1])
        if meets(self.canvas.bbox('tool_cursor')):self.canvas.delete('tool_cursor')
    def value_bubble_box(self):
        items=[i for i in self.canvas.find_withtag('value_bubble') if self.canvas.type(i)=='rectangle'] or [i for i in self.canvas.find_withtag('live_value') if self.canvas.type(i)=='rectangle']
        return tuple(self.canvas.coords(items[0])) if items else None
    # 0.18.5 (n° 31): the measure the mouse is giving, beside the crosshair in every drawing tool (same box
    # as a typed value, in grey); a typed value replaces it.
    def live_value(self):
        if not self._inside_plan or self.grip_drag or self.move_state or self.__dict__.get('bg_tool'):return ''
        t=self.tool.get();p=self.__dict__.get('pointer_world');unit=' '+self.units.get()
        v=lambda n:self.cote_value(n).replace('.',',')   # French decimal comma, as in the typed values
        if p is None:return ''
        try:
            if t in ('line','poly') and self.start is not None:
                a=self.start;n=math.dist(a,p)
                return f'{v(n)}{unit} · {math.degrees(math.atan2(p[1]-a[1],p[0]-a[0])):.0f}°' if n>1e-9 else ''
            if t in ('rect','rect_center','rect_round') and self.start is not None:
                a=self.start;k=2 if t=='rect_center' else 1;w=self.numeric_width if self.numeric_width is not None else abs(p[0]-a[0])*k
                return f'{v(w)} × {v(abs(p[1]-a[1])*k)}{unit}'
            if t in ('rect_rot','para') and self.stage_points:
                pts=self.stage_points
                if len(pts)==1:return v(math.dist(pts[0],p))+unit
                a,b=pts[:2];n=math.dist(a,b) or 1
                if t=='para':return v(math.dist(b,p))+unit   # 0.19.40: the side, as typed (the height was shown)
                return v(abs((b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0]))/n)+unit
            if t=='circle_radius' and self.start is not None:return 'R '+v(math.dist(self.start,p))+unit
            if t in ('circle_diameter','circle_2p') and self.start is not None:return 'Ø '+v(math.dist(self.start,p))+unit
            if t=='circle_3p' and self.stage_points:
                if len(self.stage_points)==1:return v(math.dist(self.stage_points[0],p))+unit
                from cad import circle_three
                return 'R '+v(circle_three(*self.stage_points[:2],p)['w']/2)+unit
            if t in ('arc_3p','arc_radius','arc_center','spline_fit') and self.curve_points:
                pts=self.curve_points
                if t=='arc_center' and len(pts)==1:return 'R '+v(math.dist(pts[0],p))+unit
                if t=='spline_fit' or len(pts)<2:return v(math.dist(pts[-1],p))+unit
                q=self.curve_shape(p)
                if not q:return ''
                arcs=[e for e in primitives(q) if e['sweep']]
                if not arcs:return v(math.dist(pts[-1],p))+unit
                return f'R {v(arcs[0]["r"])}{unit} · {abs(math.degrees(sum(e["sweep"] for e in arcs))):.0f}°'
            if t in ('ellipse_center','ellipse_box','ellipse_axis') and self.oval_points:
                q=self.oval_shape(p)
                if not q:return ''
                # 0.19.40: Ovale (rectangle): its width × height, as typed and as Rectangle; 0.19.42: the three ovals (the same values
                # typed in each)
                if q.get('ellipse'):return f'{v(q["ellipse"]["rx"]*2)} × {v(q["ellipse"]["ry"]*2)}{unit}'
                return v(math.dist(self.oval_points[0],p)*(2 if t=='ellipse_center' else 1))+unit   # (review 0.19.42: Ovale (centre) its whole length, as typed)
            st=self.copy_state
            if t=='copy' and st and st.get('phase')=='place' and st.get('anchor') is not None:
                return v(math.hypot(*st.get('delta',(0,0))))+unit
            gain=self.__dict__.get('_extend_gain')
            if t=='extend' and gain and gain>1e-9:return '+'+v(gain)+unit
            if t=='mirror' and self.mirror_phase=='axis' and self.mirror_axis:
                a=self.mirror_axis[0];return f'{math.degrees(math.atan2(p[1]-a[1],p[0]-a[0])):.0f}°' if math.dist(a,p)>1e-9 else ''
        except (ValueError,KeyError,TypeError,IndexError,ZeroDivisionError,AttributeError):return ''
        return ''
    def draw_live_value(self):
        c=self.canvas;c.delete('live_value')
        if self.command_value.get().strip() or self.__dict__.get('_bubble_at') is not None:return
        text=self.live_value()
        if not text:return
        x,y=self.crosshair_screen();x+=16;y+=16;w=self.value_bubble_width(text);h=21
        W,H=c.winfo_width(),c.winfo_height();x=max(2,min(W-w-2,x));y=max(2,min(H-h-2,y))
        c.create_rectangle(x,y,x+w,y+h,fill='#ffffff',outline='#9a9ea4',tags='live_value')
        c.create_text(x+5,y+h/2,text=text,anchor='w',fill='#5f6368',font=('Segoe UI',10),tags='live_value')
    def place_section_tabs(self):
        """0.16.21, Mozart / AutoCAD layout: history lines, a « Entrez une commande » line,
        then the sheet tabs at the very bottom (Plan, other sheets, +)."""
        old=self.__dict__.get('section_tabs')
        if old is not None:old.destroy()
        prompt=self.__dict__.get('command_prompt')
        if prompt is not None:prompt.pack_forget()
        self.build_command_line()
        self.style_history()
        self.section_tabs=tk.Frame(self.footer,bg=self.p['panel']);self.section_tabs.pack(side='left',fill='y')
        self._section_signature=None;self.rebuild_sections()
    def style_history(self):
        """0.16.24, like Mozart: the last commands on 2 framed lines, lighter than the panel;
        « Commande : » is shown from the opening."""
        history=self.__dict__.get('history')
        if history is None:return
        t=__import__('modern_style').tokens_for(self.p)   # 0.19.0: muted lines, a fine edge
        history.configure(bg=t['field'],fg=t['muted'],height=2,highlightthickness=1,highlightbackground=t['outline'],highlightcolor=t['outline'],padx=8,pady=3,font=__import__('modern_style').font(10),relief='flat',bd=0,selectbackground=t['accent_soft'],selectforeground=t['text'])
        holder=history.master
        try:holder.configure(height=46);history.pack_configure(padx=12,pady=(3,0))
        except tk.TclError:pass
        if not self.__dict__.get('log_messages'):
            history.configure(state='normal');history.delete('1.0','end');history.insert('end','Commande :');history.configure(state='disabled')
    def build_command_line(self):
        if not hasattr(self,'search_frame'):return
        import modern_style
        p=self.p;field=self.field_background();t=modern_style.tokens_for(p)
        row=tk.Frame(self.root_frame,bg=p['panel']);row.pack(fill='x',before=self.footer,padx=12,pady=(3,4))
        # 0.19.0: a rounded field (its edge in the accent colour while it has the keyboard).
        box=modern_style.make_round(row,fill=field,edge=t['field_border']);box.pack(fill='x');self.command_box=box
        tk.Label(box,text='>_',bg=field,fg=t['accent'],font=('Consolas',9,'bold'),padx=8).pack(side='left',pady=3)
        line=tk.Entry(box,textvariable=self.search_value,bg=field,fg=t['text'],insertbackground=t['text'],relief='flat',bd=0,highlightthickness=0,font=modern_style.font(10))
        line.pack(side='left',fill='x',expand=True,ipady=3,padx=(0,8));line._modern_keep=True
        hint=tk.Label(box,text='Entrez une commande',bg=field,fg=t['muted'],font=modern_style.font(10,'italic'),cursor='xterm')
        self.command_line=line;self._command_placeholder=hint
        # The bottom line is now the only command entry; the floating list only shows suggestions.
        self.search_entry.pack_forget();self.search_entry=line
        for w in [self.search_frame]+walk_widgets(self.search_frame):
            try:w.configure(cursor='arrow')
            except tk.TclError:pass
        line.bind('<Return>',lambda e:self.search_accept());line.bind('<KP_Enter>',lambda e:self.search_accept());line.bind('<Escape>',lambda e:self.search_close())
        line.bind('<Down>',lambda e:self.search_step(1));line.bind('<Up>',lambda e:self.search_step(-1));line.bind('<Tab>',lambda e:self.search_complete())
        line.bind('<FocusIn>',lambda e:(self.show_command_suggestions(),self.paint_command_placeholder()))
        line.bind('<FocusOut>',lambda e:self.after(60,self.command_line_left))
        hint.bind('<Button-1>',lambda e:line.focus_set())
        self.search_value.trace_add('write',lambda *a:self.paint_command_placeholder())
        self.paint_command_placeholder()
        for sequence,edge in (('<FocusIn>',t['accent']),('<FocusOut>',t['field_border'])):
            line.bind(sequence,lambda e,edge=edge:getattr(box,'look',lambda **k:None)(fill=field,edge=edge),add='+')   # 0.19.0: lit by the keyboard
    def paint_command_placeholder(self):
        line=self.__dict__.get('command_line');hint=self.__dict__.get('_command_placeholder')
        if not line or not hint:return
        try:
            if self.search_value.get() or self.focus_get() is line:hint.place_forget()
            else:hint.place(in_=line,x=1,rely=.5,anchor='w')
        except (tk.TclError,KeyError):pass
    def show_command_suggestions(self):
        frame=self.__dict__.get('search_frame')
        if not frame or self.modal_active():return
        self.search_update();frame.place(x=4,rely=1,y=-4,anchor='sw');frame.lift()
    def command_line_left(self):
        try:
            focus=self.focus_get()
            if focus is self.command_line or focus is self.search_list:return
            x,y=self.winfo_pointerxy();under=self.winfo_containing(x,y)
            if under is not None and str(under).startswith(str(self.search_frame)):return
        except (tk.TclError,KeyError):pass
        self.search_close(focus=False)
    def search_open(self,char):
        if 'command_line' not in self.__dict__:return super().search_open(char)
        self.search_value.set(char);self.command_line.focus_set();self.command_line.icursor('end');self.show_command_suggestions()
    def search_close(self,focus=True):
        result=super().search_close(focus)
        if 'command_line' in self.__dict__ and self.search_value.get():self.search_value.set('')
        self.paint_command_placeholder();return result
    def command_label(self,key):
        """Readable command name for the history (« rect » → « Rectangle par coins »)."""
        names={'select':'Sélection','move_anchor':'Déplacer','copy':'Copier','mirror':'Symétrie'}
        if key in names:return names[key]
        for buttons in getattr(self,'toolgroups',{}).values():
            for _,variants in buttons:
                for v in variants:
                    if v[0]==key:return 'Déplacer' if key=='move_anchor' else v[1]
        return key
    def log_status(self):
        """Mozart history (0.16.26): every line is « Commande : » then the action. A command is
        written once and its step prompts are not repeated while it runs; older lines stay above."""
        history=self.__dict__.get('history')
        if history is None or not history.winfo_exists():return
        text=self.status.get().strip()
        if not text:return
        # Cursor distances are transient, not history.
        if text==(self.__dict__.get('_live_status') or '').strip() and self.__dict__.get('start') is not None:return   # 0.19.9: in every unit (was ' mm' only)
        log=self.log_messages;mark=self.__dict__.get('_log_command_at')
        start=mark[1] if mark and mark[0]==id(log) and mark[1]<len(log) else None
        if text.startswith('Commande : '):
            line='Commande : '+self.command_label(text[len('Commande : '):].strip())
            if start is not None and log[start]==line:return
            log.append(line);start=len(log)-1
        else:
            line='Commande : '+text
            if line in (log[start+1:] if start is not None else log[-1:]):return
            log.append(line)
        if len(log)>200:
            cut=len(log)-200;del log[:cut];start=None if start is None or start<cut else start-cut
        self._log_command_at=(id(log),start) if start is not None else None
        history.configure(state='normal');history.delete('1.0','end');history.insert('end','\n'.join(log));history.configure(state='disabled');history.see('end')
    def note_history(self,text):
        """0.17.0: a line in the last commands that is not a command (« Copie de secours 00:18 »)."""
        history=self.__dict__.get('history');log=self.__dict__.get('log_messages')
        if log is None:return
        log.append(text)
        if len(log)>200:
            del log[:len(log)-200];self._log_command_at=None
        if history is not None and history.winfo_exists():
            history.configure(state='normal');history.delete('1.0','end');history.insert('end','\n'.join(log));history.configure(state='disabled');history.see('end')
    def plan_active(self):return self.__dict__.get('active_section','plan')=='plan'
    def highlight_tools(self):
        super().highlight_tools();self.show_layer_button()
        # 0.18.0: a smoothed icon is a picture on its button's colour: drawn again when the colour changes.
        from display_render import paint
        for c,key in getattr(self,'tool_buttons',[]):
            try:
                colour=c.cget('background')
                if c.__dict__.get('_painted_on')!=colour:c._painted_on=colour;paint(c,icons=True)
            except tk.TclError:pass
    def show_layer_button(self):
        """0.18.0: the « Afficher / masquer les préparations » button shows the state of the layer:
        pressed and in colour while the zones are shown, grey and crossed out while hidden."""
        from craft_refined import shade
        from refined_icons import draw
        prep_ui=__import__('preparation_ui')
        states=dict(prep_layer=prep_ui.visible(self),precut_layer=prep_ui.cut_visible(self,'precut'),recut_layer=prep_ui.cut_visible(self,'recut'))   # 0.19.14
        for c,key in getattr(self,'tool_buttons',[]):
            if key not in states:continue
            shown=states[key]
            try:
                if c.__dict__.get('_layer_shown')!=shown:
                    c._layer_shown=shown;n=self.p['icon_size'];grey='#9a9ea4'
                    c._modern_ground=__import__('modern_style').tile_fill(c,'on' if shown else None)   # its soft fills on its tile
                    c.delete('all');draw(c,key,n,self.icon_color(key) if shown else grey)
                    if not shown:
                        for item in c.find_all():
                            if c.type(item)=='polygon':c.itemconfigure(item,fill='')
                        c.create_line(4+n*.08,4+n*.92,4+n*.92,4+n*.08,fill=grey,width=max(1,round(1.25*n/24)))
                    c._painted_on=c.cget('background');__import__('display_render').paint(c,icons=True)
                # 0.19.0: shown = on a rounded tile, like the tool in use (the toolbar never moves).
                __import__('modern_style').tile(c,'on' if shown else None)
            except tk.TclError:pass
    def add_section(self):
        """« + » : a new sheet tab. Its content (parage, refente…) is still to be defined: an empty page for now."""
        n=1+sum(1 for v in self.document_sections if v['id']!='plan')
        import uuid
        self.document_sections.append(dict(id='fiche-'+uuid.uuid4().hex[:8],title=f'Fiche {n}'));self.select_section(self.document_sections[-1]['id'])
    def shown_sections(self):
        """Plan, the fiches made with « Générer fiches » (0.18.0, no longer by themselves), then the
        sheets added with « + »."""
        return list(self.__dict__.get('document_sections') or [{'id':'plan','title':'Plan'}])
    def generate_fiches(self):
        """0.18.0 « Générer fiches »: a small window with the fiches that have something to show
        (Coupe, Parage, Teinte); one click makes it and opens it in its tab at the bottom."""
        import fiches
        offered=fiches.available(self.items,self.archives,self);win=self.dialog('Générer fiches');self._fiche_window=win
        if not offered:
            self.label(win,'Aucune fiche à générer : il faut une pièce finie (fermée, en Coupe externe, avec un nom et une matière).',wraplength=320,justify='left').pack(padx=18,pady=(16,10))
            self.button(win,'Fermer',win.destroy).pack(pady=(0,14))
        else:
            row=tk.Frame(win,bg=self.p['panel']);row.pack(padx=16,pady=(16,6))
            def make(key):
                win.destroy();self.canvas.focus_set();self.add_fiche(key)
            def make_all():
                win.destroy();self.canvas.focus_set()
                for f in offered:self.add_fiche(f['id'])
                self.select_section(offered[0]['id'])
            for k,f in enumerate(offered):self.button(row,f['title'],lambda key=f['id']:make(key)).grid(row=k//4,column=k%4,padx=4,pady=3,sticky='we')
            if len(offered)>1:self.button(win,'Toutes',make_all).pack(pady=(0,14))
        win.bind('<Escape>',lambda e:win.destroy())
        win.update_idletasks();x,y=self.winfo_pointerxy();w,h=win.winfo_reqwidth(),win.winfo_reqheight()
        x=max(0,min(self.winfo_screenwidth()-w,x+18));y=max(0,min(self.winfo_screenheight()-h,y+18))
        win.geometry(f'+{x}+{y}');win.focus_set()
        return win
    def add_fiche(self,key):
        """The fiche's tab (after the plan and the other fiches, in the order Coupe, Parage,
        Teinte), then shown."""
        import fiches
        order=[k for k,_ in fiches.AUTO];sections=self.document_sections
        if not any(v['id']==key for v in sections):
            at=1+sum(1 for v in sections if v['id'] in order and order.index(v['id'])<order.index(key))
            sections.insert(at,dict(id=key,title=dict(fiches.AUTO)[key]))
        self.select_section(key)
    # --- 0.18.0 Piqûre ------------------------------------------------------------------------
    def stitch_dialog(self,on_choose,edit=None):
        """Distance from the edge (0: the line chosen is the stitch) and pitch of the holes by hand;
        a click on « Machine » or « Main » chooses and starts. ``edit``: an existing stitch (its
        pitch only)."""
        import stitching,materials as mat
        from tkinter import ttk
        win=self.dialog('Piqûre');panel=self.p['panel'];self._stitch_window=win
        form=tk.Frame(win,bg=panel);form.pack(padx=16,pady=(14,6))
        distance=tk.StringVar(value=mat.fmt(self.prefs.get('stitch_distance',stitching.DISTANCE)) or '0')
        # 0.19.13: points per cm (« on calcule tjrs au cm »), the stitch keeping its pitch in mm
        pitch=tk.StringVar(value=mat.fmt(stitching.points_per_cm((edit or {}).get('pitch',self.prefs.get('stitch_pitch',10/stitching.POINTS_PER_CM)))))
        row=0
        if edit is None:
            self.label(form,'Distance du bord').grid(row=0,column=0,sticky='w',pady=3);self.entry(form,distance,7).grid(row=0,column=1,padx=8,sticky='w');self.label(form,'mm').grid(row=0,column=2,sticky='w');row=1
        self.label(form,'Points par cm (couture main)').grid(row=row,column=0,sticky='w',pady=3)
        ttk.Combobox(form,textvariable=pitch,values=stitching.POINTS,width=6).grid(row=row,column=1,padx=8,sticky='w');self.label(form,'points').grid(row=row,column=2,sticky='w')
        buttons=tk.Frame(win,bg=panel);buttons.pack(padx=16,pady=(6,14))
        def edge_distance():
            # (review 0.19.49) a length as in every window (0.19.42 « 5 cm » avec un espace accepté partout) and as Réglages ›
            # Piqûre : distance du bord: « 2,5 mm », « 0,3 cm », « 2+0,5 » (« nombre attendu » before)
            text=distance.get().strip()
            if not text:return 0.
            from command_catalog import length_field
            try:d=length_field(text)
            except ValueError:raise ValueError('Distance du bord : nombre attendu.') from None
            if not 0<=d<=100:raise ValueError('Distance du bord : 0 à 100.')
            return d
        def choose(how):
            try:
                d=0. if edit is not None else edge_distance()
                p=stitching.pitch_of(mat.number(pitch.get(),.5,20,'Points par cm') or stitching.POINTS_PER_CM)
            except ValueError as exc:messagebox.showerror('Piqûre',str(exc),parent=win);return
            if edit is None:self.prefs['stitch_distance']=d
            self.prefs['stitch_pitch']=p;self.prefs['stitch_kind']=how
            try:self.persist_preferences()
            except OSError:pass
            win.destroy();self.canvas.focus_set();on_choose(how,d,p)
        # 0.18.5: the kind used last (or the one edited) is highlighted; « Valider » / Entrée takes it.
        current=(edit or {}).get('kind') or self.prefs.get('stitch_kind','machine')
        for text,how in (('Machine','machine'),('Main','hand')):
            b=self.button(buttons,text,lambda how=how:choose(how));b.pack(side='left',padx=6)
            if how==current:b.configure(bg=self.p['accent'],fg=contrast_color(self.p['accent']))
        self.button(buttons,'Valider',lambda:choose(current)).pack(side='left',padx=(18,0))
        win.bind('<Return>',lambda e:choose(current));win.bind('<KP_Enter>',lambda e:choose(current))
        win.bind('<Escape>',lambda e:win.destroy())
        win.update_idletasks();x,y=self.winfo_pointerxy();w,h=win.winfo_reqwidth(),win.winfo_reqheight()
        x=max(0,min(self.winfo_screenwidth()-w,x+18));y=max(0,min(self.winfo_screenheight()-h,y+18))
        win.geometry(f'+{x}+{y}');win.focus_set()
        return win
    def start_stitch(self,t,how,distance,pitch):
        """« Piqûre »: a line chosen becomes the stitch (distance 0), or the stitch is drawn that far
        from the contour chosen, on the side shown by the mouse; « Piqûre sur une partie »: the
        portion between two points of a polyline, like « Décaler partie de polyligne »."""
        self.finish_action();self.cancel();self.tool.set(t);self.last_command=('tool',t)
        self._stitch=dict(kind=how,distance=distance,pitch=pitch,source=None)
        if t=='stitch_part':
            self.offset_state=dict(distance=distance,host=None,choices={},sign=1,asked=True)
            self.route_state=dict(mode='offset',host=None,points=[],choices=[],hover=0);self.status.set('Sélectionner la polyligne.')
        else:
            if distance>0:self.offset_state=dict(distance=distance,host=None,choices={},sign=1,asked=True)
            self.status.set('Sélectionner ligne')
        self.highlight_tools();self.canvas.focus_set();self.refresh()
    def stitch_click(self,e):
        """Distance 0: the line clicked becomes the stitch (never a cut line: its piece would be lost)."""
        i=self.pick(self.raw(e))
        if i is None:raise ValueError('Sélectionner ligne')
        from craft_tools import style
        s=self.items[i]
        if style(s)['role'] in ('external','internal'):raise ValueError('Ligne de coupe : donner une distance du bord.')
        st=self._stitch;q=__import__('stitching').stitched(s,st['kind'],st['pitch'],self.stitch_owner(s))
        self._stitch=None;self.replace_items([i],[q],'stitch');self.stitch_done(q)
    def stitch_owner(self,q):
        """The piece the stitch lies in (or on): it follows that piece and goes out with it."""
        from entity_rules import closed_piece,ensure_piece_id
        from craft_tools import style
        try:pts=path(q)[0]
        except (ValueError,KeyError,TypeError):return None
        pts=pts[::max(1,len(pts)//40)]+pts[-1:];best=None
        for k,s in enumerate(self.items):
            if not closed_piece(s) or style(s)['role']!='external':continue
            x,y,X,Y=bounds([s])
            if not all(x-.01<=p[0]<=X+.01 and y-.01<=p[1]<=Y+.01 for p in pts):continue
            from precision_geometry import inside
            if all(inside(s,p) or math.dist(contour_location(s,p)[1],p)<.01 for p in pts):
                area=(X-x)*(Y-y)
                if best is None or area<best[0]:best=(area,k)
        return ensure_piece_id(self.items[best[1]]) if best else None
    def stitch_done(self,q):
        import stitching
        if stitching.kind(q)=='hand':
            n=len(stitching.holes(q));real=stitching.real_pitch(q)
            self.status.set(f'Piqûre main : {n} trou{"s" if n>1 else ""}'+(f', {stitching.points_per_cm(real):g} points par cm'.replace('.',',') if real else '')+'.')
        else:self.status.set('Piqûre machine.')
    def add_items(self,items,command):
        st=self.__dict__.get('_stitch')
        if command in STITCH_TOOLS and st:
            import stitching
            items=[stitching.stitched(q,st['kind'],st['pitch'],self.stitch_owner(q)) for q in items];self._stitch=None
            result=super().add_items(items,command)
            if items:self.stitch_done(items[0])
            return result
        return super().add_items(items,command)
    def edit_stitch(self,i):
        """Double click on a stitch: machine or main, and the pitch of its holes."""
        s=self.items[i];self.selected=i;self.selected_set={i};self.refresh()
        def change(how,distance,pitch):
            if i<len(self.items) and self.items[i] is s:
                import stitching
                q=stitching.stitched(s,how,pitch,s.get('owner_id'))
                if q!=s:self.snapshot();self.items[i]=q   # (review 0.19.49) Valider without a change: no Annuler step (as a text, a cran)
                self.selected=None;self.selected_set=set();self.refresh();self.stitch_done(q)
        self.stitch_dialog(change,s['stitch']);return True
    def section_menu(self,e,key):
        if key=='plan':return
        m=self.menu()
        if not __import__('fiches').is_auto(key):m.add_command(label='Renommer…',command=lambda:self.rename_section(key))
        m.add_command(label='Supprimer l’onglet',command=lambda:self.remove_section(key))
        try:m.tk_popup(e.x_root,e.y_root)
        finally:m.grab_release()
    def rename_section(self,key):
        from tkinter import simpledialog
        section=next((v for v in self.document_sections if v['id']==key),None)
        if section is None:return
        value=simpledialog.askstring('Renommer l’onglet','Nom',initialvalue=section['title'],parent=self)
        if value and value.strip():section['title']=value.strip();self.rebuild_sections();self.stash_doc()
    def remove_section(self,key):
        self.document_sections=[v for v in self.document_sections if v['id']!=key]
        self.select_section('plan') if self.active_section==key else (self.rebuild_sections(),self.stash_doc())
    def select_section(self,key):
        if key!='plan' and self.plan_active():
            # 0.19.9: a series in progress (Crans, Couper, Rallonger…) is kept, like when another tool is chosen
            # (it was taken back without a word).
            self.finish_action();self.tool.set('select');self.selected=None;self.selected_set=set();self.highlight_tools()
        import fiches
        if fiches.is_auto(key):
            if not any(v['id']==key for v in self.shown_sections()):key='plan'
            else:
                if key!=self.__dict__.get('active_section'):self._fiche_scroll=0
                self.active_section=key;self.rebuild_sections();self.stash_doc();self.redraw();return
        super().select_section(key);self.redraw()
    # 0.16.27: when the view is framed (opening, Recentrer, Cadrer), the base columns go down
    # to the bottom of the drawing area; zooming out afterwards keeps that length (display only:
    # the base height setting and the file are unchanged).
    def fit_workspace(self):
        result=super().fit_workspace();self.columns_to_screen();self.release_smooth();return result
    def fit(self):
        result=super().fit();self.columns_to_screen();return result
    def columns_to_screen(self):
        w=self.workspace
        if not w or 'canvas' not in self.__dict__:return
        H=self.canvas.winfo_height();W=self.canvas.winfo_width()
        if H<50 or self.scale<=0:return
        # 0.16.28: same gap at the bottom as on the sides of the base.
        left=self.to_screen((w.get('origin_x',0),0))[0];right=W-self.to_screen((w.get('origin_x',0)+sum(w['widths']),0))[0]
        margin=max(8,min(left,right))
        bottom=max(w['header']+w['height'],(H-margin-self.oy)/self.scale)
        bottoms=self.__dict__.setdefault('_column_bottoms',{});old=bottoms.get(id(w))
        self._column_view=(self.scale,self.ox,self.oy,id(w))
        if old and old[0] is w and abs(old[1]-bottom)<1e-9:return
        bottoms[id(w)]=(w,bottom);self.redraw()
    def column_bottom(self,w):
        entry=self.__dict__.get('_column_bottoms',{}).get(id(w))
        return entry[1] if entry and entry[0] is w else None
    def canvas_configured(self,e=None):
        """0.18.5 (n° 2): the plan is drawn once, about 80 ms after the last size change (Aero Snap, plein
        écran): the bars and tabs are painted again first instead of staying black during two drawings."""
        job=self.__dict__.get('_resize_job')
        if job:
            try:self.after_cancel(job)
            except (tk.TclError,ValueError):pass
        self._resize_job=self.after(80,self.resize_settled)
    def resize_settled(self):
        self._resize_job=None
        try:
            if not self.winfo_exists():return
        except tk.TclError:return
        before=self.__dict__.get('_redraws',0);w=self.workspace
        if w and self.__dict__.get('_column_view')==(self.scale,self.ox,self.oy,id(w)):self.columns_to_screen()
        if self.__dict__.get('_redraws',0)==before:self.redraw()
    def licence_export(self):
        # Édition commerciale : export réservé à une licence ou à l'essai en cours.
        garde=self.__dict__.get('_licence')
        return garde.export_autorise() if garde else True
    # 0.19.16 « sans licence les personnes ne peuvent plus dessiner » (with a 15-day trial): read-only. Opening, looking,
    # measuring and saving stay (a drawing changed before the licence ended is never lost); every change is refused
    # before it starts: the tools that draw, the grips, dragging the selection, double-click edits, Annuler / Rétablir,
    # and, under all of them, snapshot() (each change of the drawing takes its Annuler step first). His own Craft: no guard.
    def licence_complet(self):
        garde=self.__dict__.get('_licence')
        return garde.complet() if garde else True
    def read_only_said(self):
        """The status line says why, and the licence window comes up (brought forward if already open)."""
        from licence_ui import LectureSeule
        self.status.set(str(LectureSeule()))
        garde=self.__dict__.get('_licence')
        if garde is not None:
            try:garde.dialogue()
            except tk.TclError:pass
        return None
    def grips_shown(self):
        return self.licence_complet() and super().grips_shown()   # 0.19.16: no grip to drag in read-only
    def error(self,typ,value,tb):
        from licence_ui import LectureSeule
        if isinstance(typ,type) and issubclass(typ,LectureSeule):return self.read_only_said()   # 0.19.16: said, not an error
        return super().error(typ,value,tb)
    def pdf(self):
        if not self.licence_export():return None
        # 0.19.11: pieces without a name or a material said before Imprimer / PDF (he can go on), when the drawing names its pieces
        try:
            from mozart_export import unnamed
            missing=unnamed(self.items)
        except Exception:missing=[]
        if missing:
            rows=['•  '+(name or 'Sans nom')+('' if material else ' · sans matière') for _,name,material in missing[:8]]
            more=len(missing)-8
            n=len(missing);text=f'{n} pièce{"s" if n>1 else ""} sans nom ou sans matière :\n'+'\n'.join(rows)+(f'\n… et {more} autre{"s" if more>1 else ""}' if more>0 else '')+'\n\nContinuer quand même ?'
            if not messagebox.askokcancel('Imprimer',text,parent=self):return None
        return super().pdf()
    def dxf(self):
        return super().dxf() if self.licence_export() else None
    def svg(self):
        return super().svg() if self.licence_export() else None
    def dwg(self):
        return super().dwg() if self.licence_export() else None
    def select_prompt(self):
        """0.16.15 vocabulary: « Sélectionner ligne » when lines are picked (one or
        several), « Sélectionner polyligne » when the tool works on a whole piece."""
        t=self.tool.get()
        if t=='diameter':return 'Sélectionner cercle ou arc'
        if t=='radius':return 'Sélectionner arc'
        if t=='arc_length':return 'Sélectionner arc ou courbe'
        if t=='angle_dimension':return 'Sélectionner deux côtés droits'
        return 'Sélectionner polyligne' if t in WHOLE_PIECE_TOOLS else 'Sélectionner ligne'
    def compact_status(self,*args):
        variable=self.hint if args and args[0]==str(self.hint) else self.status
        text=variable.get();compact=text;pick=self.select_prompt();whole=text;end=''
        if text.endswith(' Échap pour finir.'):text=compact=text[:-len(' Échap pour finir.')];end=' · Échap pour finir'   # 0.19.5: a tool in series
        if text.startswith(('Sélectionner le contour','Sélectionner la polyligne','Sélectionner un tracé','Sélectionner le tracé','Sélectionner les tracés','Choisir un tracé','Décomposer :','Rallonger :','Sélectionner ligne/polyligne','Sélectionner pièce')):
            compact='Sélectionner polyligne fermée' if text.startswith('Sélectionner pièce fermée') else pick
        elif text.startswith(('Placer les crans','Côté choisi :')):compact='Placer crans'
        elif text.startswith(('Premier cran :','Choisir l’orientation du cran','Le prochain cran demandera')):compact='Choisir orientation cran'
        elif 'Choisir le repère source' in text:compact='Choisir repère source'
        elif 'Choisir le repère cible' in text:compact='Choisir repère cible'
        elif text.startswith(('Choisir le point de référence','Choisir d’abord le point de référence','Choisir le repère','Choisir d’abord le repère')):compact='Choisir repère'
        elif text.startswith(('Point placé : orienter','Placer le premier point du texte')):compact='Placer texte' if text.startswith('Placer') else 'Choisir orientation texte'
        elif text.startswith('Cliquer pour ajouter un point'):compact='Ajouter point'
        elif text.startswith(('Rayon ','Chanfrein ')) and 'clic droit' in text:compact=pick
        elif text.startswith('Pointe ') and 'clic droit' in text:compact='Cliquer bout de sangle'
        elif text.startswith(('Choisir le deuxième côté','Choisir la deuxième ligne')):compact='Sélectionner deuxième côté' if self.tool.get()=='angle_dimension' else 'Sélectionner deuxième ligne'
        if ': sélectionner un tracé' in text:compact=pick
        if ' : choisir le premier point ou tracé.' in text:compact='Choisir premier point' if self.tool.get() in ('arc_3p','arc_radius','spline_fit') else 'Choisir centre' if self.tool.get()=='arc_center' else pick
        short={'Choisir le point suivant · clic droit : réglages.':'Choisir point suivant','Placer la base, puis saisir la hauteur.':'Placer base','Emplacement choisi : définir la hauteur à la souris ou au clavier.':'Saisir hauteur','Diriger la tangente avec la souris, puis cliquer.':'Choisir tangente','Placer la cote avec la souris, puis cliquer.':'Placer cote','Placer la ligne de cote, puis cliquer.':'Placer cote','Sélectionner les crans':'Sélectionner crans','Sélectionner les objets':'Sélectionner ligne','Sélectionner la portion à supprimer.':'Sélectionner portion à supprimer',
               # Same words everywhere: lines and polylines, never tracé/contour/pièce/objet.
               'Placer crans sur ligne/polyligne':'Placer crans sur polyligne','Choisir l’arc à coter.':'Sélectionner arc','Choisir un cercle ou un arc circulaire.':'Sélectionner cercle ou arc','Choisir un arc.':pick,'Ce contour ne possède pas de rayon.':pick,'Choisir un point sur le contour.':'Choisir point sur la polyligne','Choisir une courbe ou un arc.':'Sélectionner arc ou courbe','Choisir deux lignes droites.':'Sélectionner deux lignes droites','Choisir deux côtés droits.':'Sélectionner deux côtés droits',
               'Cliquer sur un tracé.':pick,'Cliquer sur un côté à raccorder.':pick,'Choisir deux lignes près du coin.':pick,'Cliquer le petit côté d’une pièce, ou ses deux bords près du bout.':'Cliquer bout de sangle','Cliquer le bout de la sangle.':'Cliquer bout de sangle','Cliquer le bord d’une pièce.':pick,'Cliquer le contour de la pièce à identifier.':'Sélectionner polyligne','Sélectionner un contour.':pick,'Choisir un tracé.':pick,'Sélectionner une polyligne.':'Sélectionner polyligne','Cet objet n’est pas une polyligne. Sélectionner une polyligne.':'Sélectionner polyligne',
               'Choisir les deux côtés du même angle.':'Sélectionner deux lignes du même angle','Sélectionnez au moins un objet à miroiter.':'Sélectionner au moins une ligne','Sélectionnez un tracé à dupliquer.':'Sélectionner ligne à dupliquer','Sélectionnez les tracés avec un rectangle, puis Joindre.':'Sélectionner ligne avec un rectangle, puis Joindre','Choisir une autre pièce cible.':'Sélectionner une autre polyligne cible',
               'Le contour n’est pas fermé.':'La polyligne n’est pas fermée.','Le choix intérieur / extérieur nécessite une pièce fermée.':'Le choix intérieur / extérieur nécessite une polyligne fermée.','Choisissez le départ correspondant sur le contour cible.':'Choisir repère cible'}
        compact=short.get(compact,compact)
        if compact.startswith(('Choisir le ','Choisir la ','Placer le ','Placer la ')):
            compact=compact.replace('Choisir le ','Choisir ',1).replace('Choisir la ','Choisir ',1).replace('Placer le ','Placer ',1).replace('Placer la ','Placer ',1).rstrip('.')
        if end:compact=compact.rstrip('. ·')+end   # 0.19.40: never « · · Échap pour finir »
        if compact!=whole:variable.set(compact)
    def configure_toolgroups(self):
        super().configure_toolgroups()
        self.toolgroups['Modifications'].append(('mirror',[('mirror','Miroir',None)]))
        group=self.toolgroups['Modifications'];at=next((k+1 for k,(icon,_) in enumerate(group) if icon=='move'),len(group))
        group.insert(at,('copy',[('copy','Copier',None)]))
        group.insert(at+1,('array',[('array','Réseau',None),('stretch','Étirer',None),('break_point','Couper au point',None)]))   # 0.19.13
        # 0.19.3: the end of a strap in one click (half round or point), next to Angle droit / Arrondi.
        at=next((k+1 for k,(icon,_) in enumerate(group) if icon=='corner'),len(group))
        # 0.19.6: Bout de ceinture, and a whole strap in one go (Sangle entière).
        group.insert(at,('strap_round',[('strap_round','Bout rond',None),('strap_point','Bout pointu',None),('strap_belt','Bout de ceinture',None),('strap_piece','Sangle entière',None),('toron','Poignée toron',None),('passant','Passant',None)]))   # 0.19.11 toron, 0.19.13 passant
        # 0.19.5: a row of mèches along a strap, with Pointés et mèches; 0.19.6: the slot of the buckle's tongue.
        for icon,variants in self.toolgroups['Assemblage']:
            if icon=='drill' and not any(v[0]=='belt_holes' for v in variants):variants+=[('belt_holes','Trous de ceinture',None),('buckle_slot','Fente d’ardillon',None)]
        self.toolgroups['Mesures']=[(variant[0],[variant]) for icon,variants in self.toolgroups['Mesures'] for variant in variants]
        # 0.17.0: zones to skive or dye, on their own layer.
        # 0.18.0 Piqûre (couture machine / main), with the crans and the mèches.
        self.toolgroups['Assemblage'].append(('stitch',[('stitch','Piqûre',None),('stitch_part','Piqûre sur une partie de polyligne',None)]))
        self.toolgroups['Assemblage'].append(('assembly',[('assembly','Contrôle d’assemblage',None)]))   # 0.19.13 assemblages 2D
        self.toolgroups['Préparations']=[('preparation',[('preparation','Préparation',None)]),('teinte_bord',[('teinte_bord','Teinte des bords',None)]),   # 0.19.39 la teinte en un clic
            ('prep_layer',[('prep_layer','Afficher / masquer les préparations',lambda:self.set_tool('prep_layer'))]),
            ('precut_layer',[('precut_layer','Afficher / masquer les précoupes',lambda:self.set_tool('precut_layer'))]),   # 0.19.14
            ('recut_layer',[('recut_layer','Afficher / masquer les surcoupes',lambda:self.set_tool('recut_layer'))]),
            ('fiches',[('fiches','Générer fiches',lambda:self.generate_fiches())])]
        # 0.18.5: the précoupe / surcoupe series is cut: it sits with Coupe externe / Coupe interne.
        group=self.toolgroups['Traits'];at=next((k+1 for k,(icon,_) in enumerate(group) if icon=='internal'),len(group))
        group.insert(at,('surcoupe',[('surcoupe','Précoupe / surcoupe en série',None),('surcoupe_simple','Précoupe simple',None)]))   # 0.19.11: simple
        # 0.18.1: Infos du modèle (créateur, atelier, saison, indice, dates, fournitures) and ID unique.
        self.toolgroups['Fichiers'].append(('model_info',[('model_info','Infos du modèle',lambda:self.model_info_dialog())]))
        self.toolgroups['Identification'].append(('piece_id',[('piece_id','ID unique',None)]))
    def model_info_dialog(self):
        if not self.plan_active():self.select_section('plan')
        import model_info
        return model_info.dialog(self)
    def refresh(self):
        # 0.18.1: a badge copied with its piece (Copier, Miroir, Coller) takes a new number; the
        # fiches are made again after a change (their pages are kept while one scrolls).
        self._doc_version=self.__dict__.get('_doc_version',0)+1
        self.close_grip_menu()   # 0.19.7: « Étirer / Allonger » goes with any change
        import piece_ids
        last=piece_ids.renumbered_copies(self.__dict__.get('items') or [],self.__dict__.get('infos'))
        if last is not None:piece_ids.remember_last(self,last)
        result=super().refresh()
        self.show_history()
        return result
    # 0.19.8 « quand je suis à la dernière étape réalisée, rends la flèche de droite grisée » : Annuler and
    # Rétablir greyed (their icons, the Édition menu, the right click) when there is nothing to undo / redo.
    def history_state(self):
        d=self.__dict__
        can_undo=bool(d.get('undo_stack')) or bool(d.get('_action')) or (d.get('move_state') or {}).get('keep') is not None
        return can_undo,bool(d.get('redo_stack'))
    def icon_color(self,name):
        if name in ('undo','redo') and 'undo_stack' in self.__dict__ and not self.history_state()[name=='redo']:
            return __import__('modern_style').tokens_for(self.p)['faint']
        return super().icon_color(name)
    def show_history(self):
        state=self.history_state()
        if state==self.__dict__.get('_history_shown'):return
        self._history_shown=state
        from display_render import paint
        stack=[self]
        while stack:
            w=stack.pop()
            try:
                if getattr(w,'craft_icon',None) in ('undo','redo') and self.redraw_icon(w):paint(w,icons=True)
                stack.extend(w.winfo_children())
            except tk.TclError:pass
        try:
            if not self.cget('menu'):return
            bar=self.nametowidget(self.cget('menu'))
            for i in range(bar.index('end')+1):
                if bar.type(i)!='cascade' or bar.entrycget(i,'label')!='Édition':continue
                menu=self.nametowidget(bar.entrycget(i,'menu'))
                for k in range(menu.index('end')+1):
                    if menu.type(k)!='command':continue
                    label=menu.entrycget(k,'label')
                    if label.startswith(('Annuler','Rétablir')):menu.entryconfigure(k,state='normal' if state[label.startswith('Rétablir')] else 'disabled')
        except (tk.TclError,KeyError,TypeError,AttributeError):pass
    def set_tool(self,t):
        self.space_settle()   # (review, 0.19.42) « 50 » + Espace, then a tool chosen at once: the value first (it was lost)
        if t not in READ_ONLY_TOOLS and not self.licence_complet():return self.read_only_said()   # 0.19.16
        self.drop_pending_box()   # 0.19.21: a rectangle under way goes with any tool chosen
        self.close_stack_choice();self.forget_stack_picks();self.close_grip_menu()
        if not self.plan_active():self.select_section('plan')  # any tool returns to the Plan sheet
        from entity_rules import tool_accepts
        ids=[i for i in self.selected_ids() if tool_accepts(t,self.items[i])]
        self.selected_set=set(ids);self.selected=min(ids) if ids else None
        self.walk=None;self.corner_result=None
        if t in STITCH_TOOLS:
            return self.stitch_dialog(lambda how,distance,pitch,t=t:self.start_stitch(t,how,distance,pitch))
        if t in ('rotate','scale'):
            import transform_ui
            return transform_ui.start(self,t)
        if t=='preparation':return __import__('preparation_ui').start(self)
        if t=='teinte_bord':return __import__('teinte_ui').start(self)   # 0.19.39
        if t=='prep_layer':return __import__('preparation_ui').toggle(self)
        if t in ('precut_layer','recut_layer'):return __import__('preparation_ui').toggle_cut(self,t[:-6])   # 0.19.14
        if t=='model_info':return self.model_info_dialog()
        if t=='piece_id':return __import__('piece_ids').start(self)
        if t=='surcoupe':return __import__('surcoupe_ui').start(self)
        if t=='surcoupe_simple':return __import__('surcoupe_ui').start(self,simple=True)   # 0.19.11
        if t=='belt_holes':return __import__('belt_holes_ui').start(self)   # 0.19.5
        if t=='buckle_slot':return __import__('strap_ui').slot_start(self)   # 0.19.6
        if t=='strap_piece':return __import__('strap_ui').piece_start(self)   # 0.19.6
        if t=='toron':return __import__('strap_ui').toron_start(self)   # 0.19.11
        if t=='assembly':return __import__('assembly_ui').start(self)   # 0.19.13
        if t=='contours_check':return __import__('contours_ui').show(self)   # 0.19.13
        if t=='assembly_bag':return __import__('assembly_ui').bag(self)   # 0.19.24
        if t=='passant':return __import__('strap_ui').passant_start(self)
        if t=='array':return __import__('edit_tools').array_start(self)
        if t=='stretch':return __import__('edit_tools').stretch_start(self)
        if t=='break_point':return __import__('edit_tools').break_start(self)
        if t=='copy_notch':
            ids=[i for i in self.selected_ids() if self.items[i].get('is_notch')]
            self.finish_action();self.cancel();self.copy_crans=dict(phase='selection',ids=ids,box=None,reverse=False)
            self.tool.set(t);self.last_command=('tool',t);self.selected_set=set(ids);self.selected=min(ids) if ids else None
            if ids:self.copy_crans['phase']='source'
            self.highlight_tools();self.refresh();self.status.set('Choisir le repère source.' if ids else 'Sélectionner les crans');return
        if t=='copy':
            ids=__import__('entity_rules').linked_selection(self.items,self.selected_ids())
            self.finish_action();self.cancel();self.tool.set(t);self.last_command=('tool',t)
            # (review 0.19.49, vitesse) fast copies (0.19.17): the whole of Keith Haring 80 → 13 ms, DIFORME 14 → 4 ms, the same objects
            self.copy_state=dict(phase='base' if ids else 'selection',ids=ids,box=None,source=clone([self.items[i] for i in ids]),anchor=None,delta=(0,0),drawn=None)
            self.selected_set=set(ids);self.selected=min(ids) if ids else None
            self.highlight_tools();self.refresh();self.status.set('Choisir le repère.' if ids else 'Sélectionner ligne');self.canvas.focus_set();return
        if t=='mirror':
            ids=__import__('entity_rules').linked_selection(self.items,self.selected_ids())
            self.finish_action();self.cancel();self.mirror_ids=ids;self.selected_set=set(ids);self.selected=min(ids) if ids else None;self.mirror_mark=None;self.mirror_axis=[];self.mirror_phase='axis' if ids else 'selection';self.mirror_box=None;self.tool.set(t);self.last_command=('tool',t);self.highlight_tools();self.status.set('Tracer l’axe.' if ids else 'Sélectionner ligne');self.refresh();return
        if t=='join' and len(ids)>=2:
            self.finish_action()   # 0.19.9: a series in progress ends first (it stayed open behind the Sélection)
            self.selected_set=set(ids);self.selected=min(ids);return super().join_selected()
        if t=='join':return self.start_pick_phase('join',ids,self.join_picked)   # 0.19.21: the objects, then Entrée
        if t=='notch':self.notch_choice=None
        result=super().set_tool(t)
        if t=='notch' and not self.preselect(t,ids):self.status.set('Sélectionner le contour support.')
        elif t!='notch':self.preselect(t,ids)
        if t=='strap_belt' and not self.__dict__.get('_corner_resume'):__import__('strap_ui').belt_dialog(self)   # 0.19.6: its window first
        return result
    def resume_corner(self,t):
        """0.19.5: a raccord tool in series set again (after Annuler / Rétablir) without its window."""
        self._corner_resume=True
        try:self.set_tool(t)
        finally:self._corner_resume=False
        self.last_command=('tool',t);self.status.set(self.corner_prompt(t)+' Échap pour finir.')
    def preselect(self,t,ids):
        """0.16.15: lines selected before choosing the tool replace its selection
        step; the tool opens directly at the following step. True when applied."""
        ids=[i for i in ids if i<len(self.items)]
        if not ids:return False
        if t=='notch' and len(ids)==1:
            from precision_geometry import contour_length
            i=ids[0];self.notch_host=i;self.selected=i;self.selected_set={i};self.notch_pending=None
            # No click point: the side of an open line is judged at its middle.
            self._notch_reference=contour_length(self.items[i])/2
            self.refresh();self.status.set('Placer cran');return True
        if t in ('part_name','material') and len(ids)==1:
            i=ids[0];self.pending_piece=i;self.selected=i;self.selected_set={i};self.refresh();self.identify_dialog(t);return True
        if t=='explode':
            self.selected_set=set(ids);self.selected=min(ids);self.explode_selected();return True
        if t=='delete':
            self.selected_set=set(ids);self.selected=min(ids);self.delete();return True
        if t=='offset_all' and len(ids)==1 and self.offset_state is not None:
            i=ids[0];self.selected=i;self.selected_set={i};self.prepare_offset(self.items[i]);self.refresh();return True
        if t=='offset_part' and len(ids)==1 and self.route_state is not None:
            from precision_geometry import is_contour
            i=ids[0]
            if not is_contour(self.items[i]):return False
            self.route_state['host']=copy.deepcopy(self.items[i]);self.selected=i;self.selected_set={i};self.refresh()
            self.status.set('Choisir le premier point de la portion.');return True
        return False
    def join_selected(self):self.set_tool('join')
    # 0.16.30: in a drawing tool, with snapping on, the piece lit under the mouse shows all
    # its anchor points, hollow; the point that will be snapped stays filled.
    def draw_hover(self):
        if self.__dict__.get('pan') and self.__dict__.get('_pan_moved'):return   # 0.18.4: the view moves: what is lit moves with the drawing
        # 0.19.42 (fluidité): the boxes the drawing kept, after a key too (Échap, Ctrl+Z: each object's box was worked out
        # again, 5 ms on DIFORME), as for a move of the mouse
        from geometry import pointer_frame
        with pointer_frame(self.items),__import__('deep_zoom').drawing(self):super().draw_hover()   # 0.18.5: fine curves, clipped, past 80 px/mm
        self.draw_piece_anchors()
        self.say_arc()
    def say_arc(self):
        """0.19.42 (« Donne moi le rayon de cet arrondi », 18/11/2026 14 h 41: proposed then, GO 16 h 10): the Sélection
        over an arc (an arc, a circle, a round of a contour) says its radius and its length at the bottom (« Arc : R 8,45 mm ·
        longueur 13,28 mm », a circle « Cercle : R 10 mm · Ø 20 mm »); off it, the words said before come back (unless
        something else was said since)."""
        words=None
        i=self.__dict__.get('_hovered')
        if i is not None and i<len(self.items) and self.tool.get()=='select' and not self.grip_drag and self._inside_plan \
                and not self.modal_active():
            try:words=self.arc_words(self.items[i],self.raw(SimpleNamespace(x=self.cursor_screen[0],y=self.cursor_screen[1])))
            except (ValueError,KeyError,TypeError,ZeroDivisionError,IndexError,AttributeError):words=None
        said=self.__dict__.get('_arc_said');current=self.status.get()
        if said is not None and current!=said[0]:
            # (something else said since: kept; review: and not covered while the mouse stays on this arc: a refusal, the
            # result of a command stay displayed)
            said=self._arc_said=None;self._arc_quiet=words
        if words and words==self.__dict__.get('_arc_quiet'):return
        self._arc_quiet=None
        if words:
            self._arc_said=(words,said[1] if said is not None else current)
            if current!=words:self.status.set(words)
        elif said is not None:
            self._arc_said=None;self.status.set(said[1])
    def arc_words(self,s,p):
        """The words of say_arc for the part of ``s`` nearest ``p`` (within 8 px), None on a straight part, a spline, an
        oval, a cote, a cran, a text, a zone."""
        if s.get('annotation') or s.get('is_notch') or s.get('preparation') or s.get('dimension_group') or s.get('text') is not None:return None
        from precision_geometry import piece_runs
        from geometry import geometry_key
        key=(id(s),geometry_key(s));memo=self.__dict__.get('_arc_memo')
        if memo is None or memo[0]!=key:
            try:es=primitives(s);runs=piece_runs(es,bool(s.get('closed'))) if any(e['sweep'] for e in es) else []
            except (ValueError,KeyError,TypeError,ZeroDivisionError,IndexError):es,runs=[],[]
            memo=self._arc_memo=(key,es,runs)
        es,runs=memo[1],memo[2]
        if not runs:return None
        def gap(e):
            if not e['sweep']:
                a,b=e['a'],e['b'];dx,dy=b[0]-a[0],b[1]-a[1];L2=dx*dx+dy*dy
                t=0. if L2<=0 else max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/L2))
                return math.dist(p,(a[0]+t*dx,a[1]+t*dy))
            turn=(math.atan2(p[1]-e['c'][1],p[0]-e['c'][0])-e['start'])*(1 if e['sweep']>0 else -1)%(2*math.pi)
            return abs(math.dist(p,e['c'])-e['r']) if turn<=abs(e['sweep']) else min(math.dist(p,e['a']),math.dist(p,e['b']))
        k=min(range(len(es)),key=lambda j:gap(es[j]))
        if not es[k]['sweep'] or gap(es[k])>8/max(self.scale,1e-9):return None
        run=next((r for r in runs if k in r),[k]);e=es[k]
        unit=self.units.get();f=10 if unit=='cm' else 1
        def n(v):return f'{v/f:.2f}'.rstrip('0').rstrip('.').replace('.',',')
        if abs(sum(es[j]['sweep'] for j in run))>=2*math.pi-1e-6:return f'Cercle : R {n(e["r"])} {unit} · Ø {n(2*e["r"])} {unit}'
        return f'Arc : R {n(e["r"])} {unit} · longueur {n(sum(es[j]["length"] for j in run))} {unit}'
    def anchors_wanted(self):
        t=self.tool.get()
        if not self.snap.get() or not self._inside_plan or self.modal_active() or not self.plan_active():return False
        if t=='mirror':return self.mirror_phase=='axis'
        if t=='copy':return bool(self.copy_state) and self.copy_state.get('phase') in ('base','place')
        if t=='move_anchor':return not self.move_state or bool(self.move_state.get('ids'))
        return t in ANCHOR_TOOLS
    def draw_piece_anchors(self):
        c=self.canvas;i=self.__dict__.get('_hovered')
        s=self.items[i] if i is not None and i<len(self.items) and self.anchors_wanted() else None
        from entity_rules import geometry_entity
        if s is None or not geometry_entity(s):c.delete('object_anchors');self._anchor_key=None;return
        from cad import object_anchors
        from geometry import geometry_key
        modes=frozenset(k for k,v in self.snap_vars.items() if v.get());color=self.prefs.get('anchor_color','#efcf4b')
        key=(i,geometry_key(s),modes,self.scale,self.ox,self.oy,color)
        if key!=self.__dict__.get('_anchor_key') or not c.find_withtag('object_anchors'):
            c.delete('object_anchors');self._anchor_key=key;shown=set();t=('object_anchors',)
            for q,kind in object_anchors(s):
                spot=(round(q[0],6),round(q[1],6))
                if kind not in modes or spot in shown:continue
                shown.add(spot);x,y=self.to_screen(q)
                if kind=='midpoint':c.create_polygon(x-5,y+4,x,y-5,x+5,y+4,fill='',outline=color,width=1.2,tags=t)
                elif kind=='quarter':c.create_polygon(x-3,y+2,x,y-3,x+3,y+2,fill='',outline=color,width=1.2,tags=t);c.create_line(x-5,y+5,x+5,y+5,fill=color,width=1.2,tags=t)   # 0.18.1 Quarts
                elif kind in ('center','quadrant'):c.create_oval(x-4,y-4,x+4,y+4,outline=color,width=1.2,tags=t)
                else:c.create_rectangle(x-4,y-4,x+4,y+4,outline=color,width=1.2,tags=t)
        c.tag_raise('object_anchors');c.tag_raise('anchor_hint')
    def pick(self,p):
        from entity_rules import geometry_entity
        stack=self.__dict__.get('_anchor_stack') or []
        if stack and self.__dict__.get('_stack_pick') and self.tool.get()!='select':
            # 0.18.5: the object of the anchor chosen among stacked ones (Tab / the question), when the click is on it.
            import anchor_stack
            entry=anchor_stack.chosen(stack,self._stack_pick)
            if entry:
                i=entry[2]
                if i<len(self.items) and geometry_entity(self.items[i]):
                    try:
                        from precision_geometry import contour_location as located
                        if math.dist(located(self.items[i],p)[1],p)<=10/self.scale:return i
                    except (ValueError,KeyError,TypeError,IndexError):pass
        if self.tool.get() in ('notch','join','explode','trim','extend','fillet','chamfer','corner','strap_round','strap_point','strap_belt','belt_holes','buckle_slot','offset_all','offset_part','offset_vertex','part_name','material','rect_path','stitch','stitch_part') or self.tool.get().startswith('paint_'):
            from precision_geometry import contour_location
            from geometry import near_box
            reach=10/self.scale
            # Exact distance only for contours whose box is within reach: the
            # others can never be picked, and splines are costly to measure.
            hidden=__import__('preparation_ui').hidden_ids(self)
            candidates=[(math.dist(contour_location(s,p)[1],p),i) for i,s in enumerate(self.items) if i not in hidden and geometry_entity(s) and near_box(s,p,reach)]
            if not candidates or min(candidates)[0]>reach:return None
            if self.tool.get() in PREP_SHY:
                # 0.19.40: as the raccords, a line of the « Préparation » type (a teinte's, 3 mm out of the edge) only when
                # nothing else is within reach: at a low zoom, Crans, Piqûre, Décaler, Bout de sangle, Nom de pièce… took it
                from craft_tools import prep_line
                candidates=[c for c in candidates if c[0]<=reach and not prep_line(self.items[c[1]])] or candidates
            first=self.__dict__.get('corner_first') if self.tool.get() in ('fillet','chamfer','corner') else None
            if first is not None or self.tool.get() in ('fillet','chamfer','corner'):
                # 0.19.20 (« je viens de cliquer sur ancrage pour sélectionner ma ligne », 09/11/2026): the second side of
                # a raccord is never the side already chosen when another one is within reach; on a point where
                # several meet (an anchor), the longest one (the side, not the small round of the corner).
                near=[c for c in candidates if c[0]<=reach]
                # 0.19.39: a line of the « Préparation » type (a teinte's, 3 mm round the piece: longer than its side, it
                # took the tie below) only when nothing else is within reach
                from craft_tools import prep_line
                near=[c for c in near if not prep_line(self.items[c[1]])] or near
                # (bug hunt 0.19.39) a Piqûre of the piece chosen first is never its second side (a click just inside the
                # edge took it: the piece opened, the Piqûre cut in four), nor its lines of the « Préparation » type (a
                # teinte's, 3 mm outside the edge: Teinte des bords)
                owner=self.items[first[0]].get('piece_id') if first is not None and first[0]<len(self.items) else None
                if owner:near=[c for c in near if not ((self.items[c[1]].get('stitch') or prep_line(self.items[c[1]])) and self.items[c[1]].get('owner_id')==owner)] or near
                others=[c for c in near if first is None or c[1]!=first[0]]
                if first is not None and others:
                    # 0.19.21: another side of the same piece is a side to raccord too (a curve and a side of one
                    # polyline), when it is clearly nearer than any other object (on a point they share: the other).
                    from advanced_edit import same_side
                    own=[c for c in near if c[1]==first[0]]
                    near=own if own and own[0][0]+1/self.scale<min(others)[0] and not same_side(self.items[first[0]],first[1],p) else others
                best=min(near)[0]
                from precision_geometry import contour_length
                def length(i):
                    try:return contour_length(self.items[i])
                    except (ValueError,KeyError,TypeError,ZeroDivisionError):return 0.
                return max((c for c in near if c[0]<=best+1/self.scale),key=lambda c:(length(c[1]),-c[1]))[1]
            return min(candidates)[1]
        found=super().pick(p)
        hidden=__import__('preparation_ui').hidden_ids(self)   # 0.19.14: hidden précoupes / surcoupes are not clicked
        if found is not None and found in hidden:found=self.visible_pick(p,hidden)
        if found is None and self.tool.get()=='select':
            import preparation_ui
            if preparation_ui.visible(self):found=preparation_ui.zone_at(self.items,p)   # 0.17.0: a click in a zone selects it
            if found is not None and found in hidden:found=None
        return found
    def visible_pick(self,p,hidden):
        """0.19.14: the object under ``p`` (as atelier_core.pick: its outline within 9 px, a text by its box) among
        those shown."""
        from geometry import bounds,path
        from cad import distance
        for i,s in reversed(list(enumerate(self.items))):
            if i in hidden or not s.get('annotation'):continue
            x,y,X,Y=bounds([s])
            if x<=p[0]<=X and y<=p[1]<=Y:return i
        best=None;reach=9/self.scale
        for i,s in enumerate(self.items):
            if i in hidden or s.get('preparation'):continue
            x,y,X,Y=bounds([s])
            if not x-reach<=p[0]<=X+reach or not y-reach<=p[1]<=Y+reach:continue
            try:pts,closed=path(s)
            except (ValueError,KeyError,TypeError):continue
            for a,b in zip(pts,pts[1:]+pts[:1] if closed else pts[1:]):
                d=distance(p,a,b)
                if d<=reach:best=i;reach=d
        return best
    def cancel(self,*args,**kw):
        self.copy_state=None;self.rect_sized=None;self.pick_phase=None
        for tag in ('copy_preview','copy_guide','copy_selection','pick_selection','array_preview'):self.canvas.delete(tag)
        self.array_state=None   # 0.19.22: Réseau polaire left (its preview with it)
        if self.__dict__.get('xform') is not None:__import__('transform_ui').cancel(self)
        if self.__dict__.get('prep_state') is not None:__import__('preparation_ui').cancel(self)
        if self.__dict__.get('teinte_state') is not None:__import__('teinte_ui').cancel(self)   # 0.19.39
        self.id_state=None   # 0.18.1 ID unique
        if self.__dict__.get('surcoupe_state') is not None:__import__('surcoupe_ui').cancel(self)
        if self.__dict__.get('belt_state') is not None:__import__('belt_holes_ui').cancel(self)
        if self.__dict__.get('slot_state') is not None:__import__('strap_ui').slot_cancel(self)   # 0.19.6
        if self.__dict__.get('strap_state') is not None:__import__('strap_ui').piece_cancel(self)
        if 'canvas' in self.__dict__:tracking.reset(self)
        self.copy_crans=None;self.canvas.delete('cran_copy');self.walk=None;self.walk_choices=[];self.corner_result=None;self.mirror_axis=[];self.notch_host=None;self.mirror_box=None;self.canvas.delete('mirror_selection');self.canvas.delete('corner_preview');self._stitch=None
        if self.__dict__.get('bg_tool'):
            cropping=self.bg_tool.get('kind')=='crop';self.bg_tool=None;self.canvas.delete('bg_preview')
            if cropping:__import__('background_ui').draw(self)   # 0.19.7: only the part kept again
        result=super().cancel(*args,**kw)
        if 'command_entry' in self.__dict__ and self.__dict__.get('_bubble_at') is not None:self.command_entry.place_forget()
        return result
    # 0.18.5: stacked anchors / grips under the pointer: Tab goes to the next one; a click asks which one.
    def grip_points(self,i):
        s=self.items[i];out=[(pt,mode) for mode,pt in self.deformation_grips(s)]
        if s.get('kind')=='line' and not s.get('dimension_group'):
            a,b=path(s)[0];out+=[(a,'endpoint'),(b,'endpoint'),(((a[0]+b[0])/2,(a[1]+b[1])/2),'move')]
        if s.get('ellipse'):out.append(((s['x'],s['y']),'move'))
        if s.get('spline') and hasattr(self,'spline_grips'):out+=[(pt,mode) for mode,pt,_ in self.spline_grips(s)]
        if s.get('components') or s.get('spline'):
            x,y,X,Y=bounds([s]);out.append((((x+X)/2,(y+Y)/2),'move'))
        return out
    def grip_stack(self,p):
        """Grips of the selection under the pointer at different places (one entry per place)."""
        if not self.grips_shown():return []   # 0.19.0: no grips: no Tab among them nor question
        reach=7/self.scale;hits=[]
        for i in self.selected_ids():
            if self.items[i].get('annotation') or self.items[i].get('is_notch') or self.items[i].get('dimension_group'):continue
            try:hits+=[(pt,mode,i) for pt,mode in self.grip_points(i) if math.dist(pt,p)<=reach]
            except (ValueError,KeyError,TypeError,IndexError):continue
        out=[]
        for pt,mode,i in sorted(hits,key=lambda h:math.dist(h[0],p)):
            if not any(math.dist(pt,q)<1e-6 for q,_,_ in out):out.append((pt,mode,i))
        return out if len(out)>=2 else []
    def next_stacked(self,e=None):
        import anchor_stack
        if not self.plan_active():return 'break'
        st=self.__dict__.get('_stack_choice')
        if st:st['hot']=(st['hot']+1)%len(st['order']);self.draw_stack_choice();return 'break'
        x,y=self.cursor_screen;ev=SimpleNamespace(x=x,y=y,state=0)
        if self.tool.get()=='select' and not self.grip_drag:
            st=self.grip_stack(self.raw(ev))
            if st:self._grip_pick=anchor_stack.next_pick(st,self.__dict__.get('_grip_pick'));self.draw_crosshair()
            return 'break'
        st=self.__dict__.get('_anchor_stack') or []
        if len(st)>=2:self._stack_pick=anchor_stack.next_pick(st,self.__dict__.get('_stack_pick'));self.motion(ev)
        return 'break'
    def forget_stack_picks(self):
        self._stack_pick=None;self._grip_pick=None;self._anchor_stack=[]
    def placing_point(self):
        """The click of the current tool places a point (not a selection, nor a side or a portion to pick)."""
        t=self.tool.get()
        if t in ANCHOR_TOOLS or t in ('radius','diameter','arc_length','angle_dimension','notch','offset_vertex','text','part_name','material'):return True
        if t=='move_anchor':return bool(self.move_state and self.move_state['ids'])
        if t=='copy':return bool(self.copy_state and self.copy_state.get('phase')!='selection')
        if t in ('rotate','scale'):return bool(self.__dict__.get('xform') and self.xform['phase']!='selection')
        if t=='mirror':return self.mirror_phase!='selection'
        if t=='copy_notch':return bool(self.copy_crans and self.copy_crans['phase']!='selection')
        return False
    def ask_stacked(self,e):
        """A click on stacked anchors (or grips at different places) asks which one is meant, unless Tab
        already chose it. Same point and same kind (two sides meeting) is never asked, nor the points of
        one object (Tab), nor a click right on one of them while the others are a little apart."""
        import anchor_stack
        t=self.tool.get()
        if t=='select':
            if self.grip_drag or getattr(e,'state',0)&1 or not self.selected_ids():return False
            entries=self.grip_stack(self.raw(e));grips=True;chosen=self.__dict__.get('_grip_pick')
        else:
            if not self.placing_point() or not self.snap.get():return False
            self.point(e);entries=self.__dict__.get('_anchor_stack') or [];grips=False;chosen=self.__dict__.get('_stack_pick')
        if len(entries)<2 or len({i for _,_,i in entries})<2:return False
        if not grips and not self.stack_matters(entries):return False   # 0.18.6: the same point whatever the choice
        if anchor_stack.chosen(entries,chosen):return False
        raw=self.raw(e)
        if len([q for q,_,_ in entries if math.dist(q,raw)*self.scale<=1.5])==1:return False   # right on one, the others apart
        # The question opens when the button is released (a menu opened under a held button could
        # take the release as a choice); a drag instead is a plain click at the press.
        order=anchor_stack.ordered(entries)
        self._stack_swallow=(entries,order,anchor_stack.labels(order,self.items,grips),grips,e.x,e.y,int(getattr(e,'x_root',e.x)),int(getattr(e,'y_root',e.y)))
        return True
    OBJECT_TOOLS=frozenset({'radius','diameter','arc_length','angle_dimension','notch','copy_notch','offset_vertex'})
    def stack_matters(self,entries):
        """0.18.6: choosing among stacked anchors changes something: points a little apart, or a tool that works
        on the object itself (cote of a radius, cran, Copier crans…). Points at the very same place for a tool
        that only needs a point give the same result: no question and no « Tab » label there."""
        if len(entries)<2:return False
        if len({(round(q[0],6),round(q[1],6)) for q,_,_ in entries})>1:return True
        return self.tool.get() in self.OBJECT_TOOLS
    def open_stack_question(self,e=None):
        entries,order,names,grips,x,y,X,Y=self._stack_swallow;self._stack_swallow=False
        if e is not None and math.hypot(e.x-x,e.y-y)>=4:
            # Dragged: no question, the press counts as a click (the closest anchor) and the release follows.
            self._stack_answer=True
            try:
                self.down(SimpleNamespace(x=x,y=y,state=0,num=1,x_root=x,y_root=y));self.motion(e);self.up(e)
            finally:self._stack_answer=False
            return
        # 0.18.6: the question is a small list drawn on the plan beside the point; Craft goes on (a Windows
        # menu held everything, the cross froze until it was answered).
        import anchor_stack
        closest=entries[0];hot=[anchor_stack.canon(q) for q in order].index(anchor_stack.canon(closest))
        self._stack_choice=dict(entries=entries,order=order,names=names,grips=grips,x=x,y=y,hot=hot,rows=[])
        self.draw_stack_choice()
    def draw_stack_choice(self):
        st=self.__dict__.get('_stack_choice');c=self.canvas;c.delete('stack_choice')
        if not st:return
        h=21;w=max(self.value_bubble_width(n) for n in st['names'])+8;n=len(st['names'])
        W,H=c.winfo_width(),c.winfo_height()
        x0=max(2,min(W-w-2,st['x']+14));y0=max(2,min(H-h*n-2,st['y']+14));st['rows']=[]
        for k,name in enumerate(st['names']):
            top=y0+k*h
            c.create_rectangle(x0,top,x0+w,top+h,fill='#cfe0f7' if k==st['hot'] else '#ffffff',outline='',tags='stack_choice')
            c.create_text(x0+6,top+h/2,text=name,anchor='w',fill='#000000',font=('Segoe UI',10),tags='stack_choice')
            st['rows'].append((x0,top,x0+w,top+h))
        c.create_rectangle(x0,y0,x0+w,y0+h*n,outline='#7d8187',tags='stack_choice')
        # the point of the line shown in colour on the plan
        px,py=self.to_screen(st['order'][st['hot']][0]);color=self.prefs.get('anchor_color','#efcf4b')
        c.create_oval(px-7,py-7,px+7,py+7,outline=color,width=2,tags='stack_choice')
        c.tag_raise('stack_choice')
    # 0.19.7 « clique sur point ancrage permet aussi de proposer "allonger" »: the mouse resting on an end of
    # the line selected (or of an open polyline): « Étirer / Allonger » beside it, like AutoCAD's grips.
    GRIP_MENU=('Étirer','Allonger')
    GRIP_MENU_DELAY=350   # ms
    def watch_end_grip(self,e):
        """In Sélection with nothing held: the list a moment after the mouse stops on such a grip; gone when
        the mouse leaves the grip and the list. True when the mouse is on one of its lines."""
        menu=self.__dict__.get('_grip_menu')
        if menu:
            k=self.grip_menu_row(e.x,e.y)
            if k is not None:
                if k!=menu['hot']:menu['hot']=k;self.draw_grip_menu()
                return True
            if math.hypot(e.x-menu['sx'],e.y-menu['sy'])<=10:return False
            self.close_grip_menu()
        selected=self.selected_ids()
        if self.grip_drag or getattr(self,'box_start',None) or self.__dict__.get('_box_pending') or self.move_state or len(selected)!=1:return self.wait_grip_menu(None)
        # Only near an end of a line or of an open polyline (read directly: every grip of a large polyline at each
        # move cost up to 15 ms more).
        s=self.items[next(iter(selected))]
        if not s.get('components'):
            if s['kind']=='line':ends=((s['x'],s['y']),(s['x']+s['w'],s['y']+s['h']))
            elif s['kind']=='poly' and not s.get('closed') and len(s.get('points') or ())>1 and not s.get('spline'):
                (x0,y0),(x1,y1)=s['points'][0],s['points'][-1];ends=((s['x']+x0,s['y']+y0),(s['x']+x1,s['y']+y1))
            else:ends=()
            if not any(math.hypot(e.x-x,e.y-y)<=12 for x,y in map(self.to_screen,ends)):return self.wait_grip_menu(None)
        grip=self.hit_grip(self.raw(e))
        if not grip:return self.wait_grip_menu(None)
        i,mode,anchor,fixed=grip
        if self.end_axis(dict(mode=mode,original=self.items[i],anchor=anchor,fixed=fixed)) is None:return self.wait_grip_menu(None)
        return self.wait_grip_menu((i,mode,anchor,fixed))
    def wait_grip_menu(self,grip):
        held=self.__dict__.get('_grip_menu_wait')
        if held and grip and held[0][:2]==grip[:2]:return False
        if held:
            try:self.after_cancel(held[1])
            except (tk.TclError,ValueError):pass
            self._grip_menu_wait=None
        if grip:self._grip_menu_wait=(grip,self.after(self.GRIP_MENU_DELAY,lambda:self.open_grip_menu(grip)))
        return False
    def open_grip_menu(self,grip):
        self._grip_menu_wait=None
        try:
            i,mode,anchor,fixed=grip;sx,sy=self.to_screen(anchor)
            # 0.19.22: nor when a rectangle, a press or Déplacer began meanwhile
            if self.grip_drag or self.box_pending() or self.__dict__.get('box_start') or self.move_state or i>=len(self.items) or math.hypot(self.cursor_screen[0]-sx,self.cursor_screen[1]-sy)>10:return
            self._grip_menu=dict(index=i,mode=mode,anchor=anchor,fixed=fixed,sx=sx,sy=sy,hot=0,rows=[]);self.draw_grip_menu()
        except tk.TclError:pass
    def draw_grip_menu(self):
        st=self.__dict__.get('_grip_menu');c=self.canvas;c.delete('grip_menu')
        if not st:return
        h=21;w=max(self.value_bubble_width(n) for n in self.GRIP_MENU)+8;n=len(self.GRIP_MENU);W,H=c.winfo_width(),c.winfo_height()
        x0=max(2,min(W-w-2,st['sx']+14));y0=max(2,min(H-h*n-2,st['sy']+14));st['rows']=[]
        for k,name in enumerate(self.GRIP_MENU):
            top=y0+k*h
            c.create_rectangle(x0,top,x0+w,top+h,fill='#cfe0f7' if k==st['hot'] else '#ffffff',outline='',tags='grip_menu')
            c.create_text(x0+6,top+h/2,text=name,anchor='w',fill='#000000',font=('Segoe UI',10),tags='grip_menu')
            st['rows'].append((x0,top,x0+w,top+h))
        c.create_rectangle(x0,y0,x0+w,y0+h*n,outline='#7d8187',tags='grip_menu');c.tag_raise('grip_menu')
    def grip_menu_row(self,x,y):
        st=self.__dict__.get('_grip_menu')
        if not st:return None
        return next((k for k,(a,b,A,B) in enumerate(st['rows']) if a<=x<=A and b<=y<=B),None)
    def close_grip_menu(self):
        if '_grip_menu_wait' in self.__dict__:self.wait_grip_menu(None)
        if self.__dict__.get('_grip_menu') is None:return False
        self._grip_menu=None
        try:self.canvas.delete('grip_menu')
        except tk.TclError:pass
        return True
    def choose_grip_menu(self,e):
        """A click on « Étirer » or « Allonger »: the end held (Allonger: on its axis, the length typed added)."""
        st=self.__dict__.get('_grip_menu');k=self.grip_menu_row(e.x,e.y);self.close_grip_menu()
        if st is None or k is None or st['index']>=len(self.items):return False
        i=st['index'];self.selected=i;self.selected_set={i}
        self.grip_drag=dict(index=i,mode=st['mode'],anchor=st['anchor'],fixed=st['fixed'],original=copy.deepcopy(self.items[i]),changed=False,redo=list(self.redo_stack),
                            linked={j:copy.deepcopy(self.items[j]) for j in __import__('entity_rules').linked_selection(self.items,[i]) if j!=i},lengthen=k==1)
        self.box_start=None;self.cursor_screen=(e.x,e.y)
        self.status.set('Allonger : taper la longueur à ajouter (moins pour raccourcir), ou cliquer sur l’axe.' if k==1 else 'Choisir l’arrivée ou saisir une distance.')
        self.draw_crosshair();return True
    def stack_choice_row(self,x,y):
        st=self.__dict__.get('_stack_choice')
        if not st:return None
        return next((k for k,(a,b,A,B) in enumerate(st['rows']) if a<=x<=A and b<=y<=B),None)
    def close_stack_choice(self):
        """The list closed without any click (Échap, another tool, the view moved, Annuler, regen)."""
        if self.__dict__.get('_stack_choice') is None:return False
        self._stack_choice=None
        try:self.canvas.delete('stack_choice')
        except tk.TclError:pass
        return True
    def choose_stack(self,entry=None,then=None):
        """The click that opened the list, done with ``entry`` (None: the closest point). ``then``: the pointer
        event to follow afterwards (the preview goes on from where the mouse is)."""
        st=self.__dict__.get('_stack_choice')
        if not st:return
        self.close_stack_choice()
        self.answer_stacked(st['entries'],entry or st['entries'][0],st['grips'],st['x'],st['y'])
        if then is not None:
            self.cursor_screen=(then.x,then.y);self.motion(then)
    def answer_stacked(self,entries,entry,grips,x,y):
        import anchor_stack
        setattr(self,'_grip_pick' if grips else '_stack_pick',anchor_stack.pick_of(entries,entry));self._stack_swallow=False
        ev=SimpleNamespace(x=x,y=y,state=0,num=1,x_root=x,y_root=y);self._stack_answer=True
        try:
            self.cursor_screen=(x,y);self.motion(ev);self.down(ev);self.up(ev)
        finally:self._stack_answer=False
    def start_selection_move(self,e):
        """0.18.5: with several objects selected, any of their grips moves the WHOLE selection, that grip being
        the repère (like Déplacer: follows the mouse, snaps, ORTHO, typed distance, a click places it, one Annuler).
        One object (with its own linked parts) keeps its grips' usual roles (vertex, radius, middle…)."""
        from entity_rules import linked_selection
        ids=self.selected_ids()
        if len(ids)<2:return False
        grip=self.hit_grip(self.raw(e))
        if grip is None:return False
        shared=self.shared_grips(grip[2])
        if len(shared)>=2:return self.start_joint_grip(shared,e)   # 0.19.7: a point several of them share
        if set(linked_selection(self.items,ids))<=set(linked_selection(self.items,[grip[0]])):return False
        keep=set(self.selected_set);self.set_tool('move_anchor')
        if not self.move_state or not self.move_state['ids']:return False
        self.move_state.update(anchor=grip[2],keep=keep,grip_press=(e.x,e.y))
        self.selected_set=set(self.move_state['ids']);self.cursor_screen=(e.x,e.y)
        self.status.set('Choisir l’arrivée ou saisir une distance.');self.motion(e);self.show_history();return True   # 0.19.8: Ctrl+Z drops the move
    def shared_grips(self,P,tol=1e-6):
        """0.19.7 « quand j'ai 2 lignes sélectionnées et que je prends le point d'ancrage commun, ça ne déplace pas
        mais modifie ce point pour les 2 »: the selected objects with an end, a vertex or a fit point on P,
        [(index, grip, point, fixed end, shape)], one per object."""
        out=[]
        for i in self.selected_ids():
            s=self.items[i];found=None
            if s.get('dimension_group') or s.get('annotation') or s.get('drill') or s.get('is_notch') or s.get('piece_badge'):continue
            if s['kind']=='line':
                a,b=path(s)[0]
                found=('endpoint',a,b) if math.dist(a,P)<=tol else ('endpoint',b,a) if math.dist(b,P)<=tol else None
            elif s.get('spline'):
                fit=s['spline'].get('fit') or []
                k=next((k for k,(x,y) in enumerate(fit) if math.dist((s['x']+x,s['y']+y),P)<=tol),None)
                if k is not None:found=(('spline_fit',k),P,P)
            else:
                for mode,pt in self.deformation_grips(s):
                    if isinstance(mode,tuple) and (mode[0]=='pvertex' or mode[0]=='arc' and mode[3] in ('start','end')) and math.dist(pt,P)<=tol:found=(mode,pt,pt);break
            if found:out.append((i,)+found+(copy.deepcopy(s),))
        return out
    def start_joint_grip(self,shared,e):
        i=shared[0][0]
        # The other objects as « linked »: Échap puts them all back (and a zone moved with them is attached).
        linked={j:copy.deepcopy(self.items[j]) for j,*_ in shared[1:]}
        self.grip_drag=dict(index=i,mode='joint',anchor=shared[0][2],fixed=shared[0][2],original=copy.deepcopy(self.items[i]),changed=False,redo=list(self.redo_stack),linked=linked,joint=shared)
        self.box_start=None;self.cursor_screen=(e.x,e.y)
        self.status.set(f'Point commun à {len(shared)} objets : choisir l’arrivée ou saisir une distance.');self.draw_crosshair();return True
    def joint_shape(self,s,mode,anchor,fixed,p):
        """The shape ``s`` with its grip ``mode`` (at ``anchor``) brought to p."""
        if mode=='endpoint':
            if math.dist(p,fixed)<.001:raise ValueError('Ligne trop courte.')
            q=copy.deepcopy(s);start=math.dist((s['x'],s['y']),anchor)<1e-6;A,B=(p,fixed) if start else (fixed,p)
            if q.get('notches'):
                delta=math.dist(A,B)-math.hypot(s['w'],s['h']) if start else 0
                q['notches']=[dict(copy.deepcopy(m),distance=m['distance']+delta) for m in s['notches']]
                if any(not 0<=m['distance']<=math.dist(A,B) for m in q['notches']):raise ValueError('La ligne devient trop courte pour ses crans.')
            q.update(x=A[0],y=A[1],w=B[0]-A[0],h=B[1]-A[1]);return q
        if mode[0]=='spline_fit':
            from curves import spline
            from finish_ui import retain_marks
            pts=[(s['x']+x,s['y']+y) for x,y in s['spline']['fit']];pts[mode[1]]=p
            return retain_marks(inherit(spline(pts,s.get('closed',False),s['name'],s['spline'].get('tangents')),s),s)
        if mode[0]=='arc':
            from native_edit import edit_arc
            return edit_arc(s,mode,p)
        base=self.as_polyline(s);V=[(base['x']+x,base['y']+y) for x,y in base['points']];n=len(V);k=mode[1];V[k]=p
        closed=bool(base.get('closed'));B=(list(base.get('bulges') or [])+[0]*n)[:n]
        if any(math.dist(V[k],V[m])<1e-6 for m in ((k-1)%n,(k+1)%n) if closed or abs(m-k)==1):raise ValueError('Point confondu avec le suivant.')
        q=polygon(V,base['name'],closed);q.update({key:copy.deepcopy(v) for key,v in base.items() if key not in ('kind','x','y','w','h','r','points','closed','name','bulges')})
        if any(B):q['bulges']=B if closed else B[:n-1]+[0]
        # (review R4) as the corner grip of one piece (move_vertex): the point two pieces share never makes one cross itself
        if __import__('geometry').newly_crossed(base,q,{(k-1)%n,k} if closed else {m for m in (k-1,k) if 0<=m<n-1}):raise ValueError('Le contour se croise.')
        return q
    def move_joint_grip(self,e):
        """0.19.7: the point several selected objects share goes to the mouse for all of them (they stay joined)."""
        g=self.grip_drag;p=self.point(e)
        if not g['changed'] and math.dist(p,g['anchor'])<.1/self.scale:self.draw_crosshair();return
        try:
            new={i:self.joint_shape(s,mode,anchor,fixed,p) for i,mode,anchor,fixed,s in g['joint']};validate(list(new.values()))
        except ValueError as exc:self.invalid_at(e,str(exc));return
        if not g['changed']:self.snapshot();g['changed']=True
        for i,s in new.items():self.items[i]=s
        for i,mode,anchor,fixed,s in g['joint']:
            if s.get('piece_id'):
                # a piece keeps its crans, as with its own grip (Échap puts them back too)
                sub=g.setdefault('pieces',{}).setdefault(i,dict(original=s));self.reattach_crans(sub,self.items[i],(anchor,p))
                for j,cran in sub.get('linked',{}).items():g['linked'].setdefault(j,cran)
        self.refresh();self.draw_crosshair()
    def commit_move(self):
        keep=(self.move_state or {}).get('keep')
        super().commit_move()
        if keep is not None:
            # A selection moved by one of its grips stays selected, like after a grip drag.
            self.selected_set={i for i in keep if i<len(self.items)};self.selected=min(self.selected_set) if self.selected_set else None
            self.last_command=('tool','select');self.refresh()
    def down(self,e):
        if not self.plan_active():return
        self.settle_view()   # 0.18.2: a click just after the wheel works on the full drawing
        self._box_closed=False
        if self.box_pending():return self.close_box_click(e)   # 0.19.21: the second click of a rectangle
        if self.__dict__.get('_grip_menu'):
            if self.choose_grip_menu(e):return 'break'
        if self.__dict__.get('bg_tool'):
            # 0.18.0 Image de fond: Déplacer / Caler.
            self._advanced_press=True;self.cursor_screen=(e.x,e.y);self.canvas.focus_set()
            return __import__('background_ui').click(self,e)
        last=self.__dict__.get('_choice_click')
        if last and not self.__dict__.get('_stack_answer'):
            self._choice_click=None
            if time.monotonic()-last[0]<.45 and math.hypot(e.x-last[1],e.y-last[2])<5:
                self._choice_release=True;return 'break'   # the second click of a double click on a line of the list
        if self.__dict__.get('_stack_choice') is not None and not self.__dict__.get('_stack_answer'):
            # 0.18.6: a line of the list chooses; a click elsewhere does the first click with the closest point,
            # then counts as usual.
            k=self.stack_choice_row(e.x,e.y)
            if k is not None:
                self.choose_stack(self._stack_choice['order'][k],e);self._choice_release=True
                self._choice_click=(time.monotonic(),e.x,e.y);return 'break'
            self.choose_stack(None)
        self._stack_swallow=False
        if not self.__dict__.get('_stack_answer') and self.ask_stacked(e):return 'break'
        # (review 0.19.42) Espace waiting for a unit: the value first, as Espace gave it, then the click as a click (as in
        # 0.19.41, « un clic … donne la valeur comme avant »; typed_click took the value toward the click and ate the click:
        # Polyligne « 50 », Espace, clic: no point where one clicked)
        self.space_settle()
        if self.typed_click(e):return 'break'   # 0.19.40: a value typed, then a click: as Entrée, toward the click
        if self.__dict__.get('rect_sized') and self.tool.get() in SIZED_RECTS:
            self._advanced_press=True;self.cursor_screen=(e.x,e.y);self.canvas.focus_set()
            a,b=self.sized_corners(self.point(e));self.rect_sized=None;self.start=a
            try:self.commit_current(b);self.status.set('')
            except ValueError as exc:self.start=None;self.invalid_at(e,str(exc))
            return 'break'
        t=self.tool.get();self._advanced_press=t in ('copy_notch','join','array','mirror','notch','fillet','chamfer','corner','strap_round','strap_point','strap_belt','copy','rotate','scale','preparation','teinte_bord','piece_id','surcoupe','belt_holes','buckle_slot','strap_piece','toron','passant','assembly','array_centre','stretch','break_point') or (t=='stitch' and bool(self.__dict__.get('_stitch')) and not self.__dict__.get('offset_state'))
        if not self._advanced_press:
            st=self.offset_state
            if st is not None and st.get('asking'):
                # 0.16.29: a click while the value is asked only validates it (like Entrée);
                # the offset then appears and the next click chooses the side.
                self.cursor_screen=(e.x,e.y);self.enter_dimension();return 'break'
            if t=='select' and not self.grip_drag and not getattr(e,'state',0)&1 and self.start_selection_move(e):return 'break'
            # 0.16.30: a single click on a text only selects it (double click: edit; drag: move).
            held=self.grip_drag is not None;before=set(self.selected_set);result=super().down(e)
            if self.grip_drag is not None:self.draw_crosshair()
            elif held:self.end_grip_input()
            if t=='select':
                self.expand_dimension_selection(before)
                if self.selected_set and self.selected_set!=before:self._selection_serial=self.__dict__.get('_command_serial',0)
            return result
        self.cursor_screen=(e.x,e.y);self.canvas.focus_set();p=self.raw(e)
        try:
            if t=='stitch':return self.stitch_click(e)
            if t=='copy':return self.copy_click(e)
            if t in ('rotate','scale') and self.__dict__.get('xform'):return __import__('transform_ui').click(self,e)
            if t=='preparation':return __import__('preparation_ui').click(self,e)
            if t=='teinte_bord':return __import__('teinte_ui').click(self,e)   # 0.19.39
            if t=='piece_id':return __import__('piece_ids').click(self,e)
            if t=='surcoupe':return __import__('surcoupe_ui').click(self,e)
            if t=='belt_holes':return __import__('belt_holes_ui').click(self,e)
            if t=='buckle_slot':return __import__('strap_ui').slot_click(self,e)   # 0.19.6
            if t=='strap_piece':return __import__('strap_ui').piece_click(self,e)
            if t=='toron':return __import__('strap_ui').toron_click(self,e)
            if t=='assembly':return __import__('assembly_ui').click(self,e)   # 0.19.13
            if t=='array_centre':return __import__('edit_tools').array_centre_click(self,e)
            if t=='passant':return __import__('strap_ui').passant_click(self,e)
            if t=='stretch':return __import__('edit_tools').stretch_click(self,e)
            if t=='break_point':return __import__('edit_tools').break_click(self,e)
            if t=='copy_notch':return self.copy_crans_click(e)
            if self.pick_phase and t==self.pick_phase['tool']:self.pick_phase['box']=(e.x,e.y,p);return   # 0.19.21 Réseau, Joindre
            if t=='join':return self.walk_click(p)
            if t=='array':return
            if t=='mirror':
                if self.mirror_phase=='selection':
                    self.mirror_box=(e.x,e.y,p);return
                if len(self.mirror_axis)>=2:return
                q=self.point(e)
                if self.mirror_axis and math.dist(self.mirror_axis[0],q)<EPS:   # 0.19.9: a double-click gives no axis
                    self.status.set('Choisir un deuxième point de l’axe, différent du premier.');return
                self.mirror_axis.append(q)
                if len(self.mirror_axis)==2:self.ask_mirror_keep()
                else:self.status.set('Choisir le deuxième point de l’axe.')
                return
            if t=='notch':
                p=self.point(e)
                if self.notch_host is None:
                    i=self.pick(self.raw(e))
                    if i is None or self.items[i].get('annotation') or self.items[i].get('is_notch'):raise ValueError('Sélectionner le contour support.')
                    self.notch_host=i;self.selected=i;self.selected_set={i};self.notch_pending=None
                    self._notch_reference=locate(self.items[i],p)[0]
                    self.refresh();self.status.set('Placer cran');return
                if self.notch_choice is None and self.notch_pending is not None:
                    # 0.16.28: the first cran's point is placed; this click gives its orientation and places it.
                    self.notch_choice=self.notch_side_at(self.raw(e));return self.place_notch(self.notch_choice)
                i=self.notch_host
                if math.dist(locate(self.items[i],self.raw(e))[1],self.raw(e))>10/self.scale:raise ValueError('Placer crans sur ligne/polyligne')
                self.notch_pending=(i,locate(self.items[i],p)[0])
                if self.notch_choice is None:
                    self._notch_reference=self.notch_pending[1];self.status.set('Choisir orientation cran');self.refresh();return
                return self.place_notch(self.notch_choice)
            if self.corner_result is not None:return self.commit_corner()
            i=self.pick(p)
            if i is None:raise ValueError('Cliquer le bout de la sangle.' if t in STRAP else 'Cliquer sur un côté à raccorder.')
            if t in STRAP and self.corner_first is None:
                # 0.19.3: the end side of a piece (rectangle, polyline) in one click; two edges otherwise.
                done=strap_shape(self.items[i],p,t,self.corner_value(t))
                if done is not None:self.corner_result=({i},[done],t);return self.commit_corner()
                self.corner_first=(i,p);self.status.set('Choisir la deuxième ligne.');return
            if self.corner_first is None:self.corner_first=(i,p);self.status.set('Choisir le deuxième côté à raccorder.');return
            j,q=self.corner_first;value=self.corner_value(t)
            ids,new=raccord_document(self.items,j,i,q,p,t,value)
            self.corner_result=(ids,new,t)
            self.commit_corner()
        except (ValueError,IndexError) as exc:self.invalid_at(e,str(exc))
    # 0.19.40 (night review « dessin »): a value typed, then a click instead of Entrée, in a drawing tool: the value is taken
    # toward the click, as Entrée does (and as Copier, Déplacer, Rotation, Échelle, a grip: LIRE_MOI « une valeur puis Entrée
    # ou un clic s'applique »). The click used to win and the value was dropped (Ligne, Cercle, Rectangle, Arc, Ovale), or
    # it stayed in the box and went to a later point (Polyligne: the Entrée that should end it added a side; Arc (centre)).
    # Only where a value is taken at that step (a tool that takes none, Cercle (3 points)…: the click as before).
    def typed_click(self,e):
        t=self.tool.get();d=self.__dict__
        if not self.command_value.get().strip() or self.grip_drag or self.move_state or d.get('_forced_point') is not None:return False
        if t in ('line','poly','circle_radius','circle_diameter','circle_2p','rect_rot','para'):waited=self.start is not None
        elif t in SIZED_RECTS:waited=True   # before the first point: « largeur;hauteur », the click places it
        elif t=='arc_radius':waited=len(d.get('curve_points') or ())==2
        elif t=='arc_center':waited=len(d.get('curve_points') or ())==1
        elif t=='spline_fit':waited=bool(d.get('curve_points'))
        elif t in ('ellipse_center','ellipse_box','ellipse_axis'):waited=bool(d.get('oval_points'))
        elif t in __import__('finish_ui').TOOL_VALUE:
            self.enter_dimension();return False   # (review) a radius typed then a side clicked: the radius taken, the click is the side's
        else:waited=False
        if not waited:return False
        sized=t in SIZED_RECTS and self.start is None
        self._advanced_press=True;self.cursor_screen=(e.x,e.y);self.canvas.focus_set()
        self.pointer_world=self.point(e)   # the direction (ORTHO, anchors) as the mouse gives it
        self.enter_dimension()
        if sized and d.get('rect_sized') and not self.command_value.get().strip():return False   # sized: placed by this click (below)
        return True
    def drawing_under_way(self):
        """0.19.40: a shape being drawn (a point placed, a rectangle sized before its first point, a cote begun…)."""
        t=self.tool.get();d=self.__dict__
        if t not in DRAWING_TOOLS:return False
        return (d.get('start') is not None or bool(d.get('pending')) or bool(d.get('stage_points')) or bool(d.get('curve_points'))
                or bool(d.get('oval_points')) or bool(d.get('extra_points')) or bool(d.get('new_cote')) or d.get('cote_host') is not None
                or d.get('rect_sized') is not None or d.get('numeric_width') is not None or d.get('radius_target') is not None
                or d.get('route_state') is not None or d.get('rect_reference') is not None)
    def up(self,e):
        if not self.plan_active():return
        if self.__dict__.get('_box_closed'):self._box_closed=False;return 'break'   # 0.19.21: the click that closed a rectangle
        if self.__dict__.get('_choice_release'):self._choice_release=False;return 'break'   # the click on a line of the list
        if self.__dict__.get('_stack_swallow'):self.open_stack_question(e);return 'break'   # 0.18.5: which of the stacked anchors
        if self.tool.get()=='copy' and self.copy_state and self.copy_state['phase']=='selection' and self.copy_state['box']:return self.copy_release(e)
        if self.pick_phase and self.pick_phase['box'] and self.tool.get()==self.pick_phase['tool']:return self.pick_release(e)
        st=self.__dict__.get('xform')
        if self.tool.get() in ('rotate','scale') and st and st['phase']=='selection' and st['box']:return __import__('transform_ui').release(self,e)
        if self.tool.get()=='copy_notch' and self.copy_crans and self.copy_crans['phase']=='selection':
            st=self.copy_crans;box=st['box'];st['box']=None;self._advanced_press=False;self.canvas.delete('cran_copy')
            if not box:return
            x,y,a=box
            from selection import select,shift_held
            # 0.18.0: clicks and rectangles add crans (Maj removes), without Ctrl.
            def crans(a,b):return {i for i in select(self.items,a,b) if self.items[i].get('is_notch')}
            if math.hypot(e.x-x,e.y-y)>=4:return self.crans_take(crans(a,self.raw(e)),shift_held(e))
            i=self.pick_cran(self.raw(e))
            if i is None:   # 0.19.21: a click in the void starts the rectangle
                return self.start_pending_box('cran_copy',a,lambda a,b,remove:self.crans_take(crans(a,b),remove),shift_held(e))
            return self.crans_take({i},shift_held(e))
        if self.tool.get()=='mirror' and self.mirror_phase=='selection' and self.mirror_box:
            x,y,a=self.mirror_box;self.mirror_box=None;self._advanced_press=False;self.canvas.delete('mirror_selection')
            from selection import select,shift_held
            if math.hypot(e.x-x,e.y-y)>=4:return self.mirror_take(select(self.items,a,self.raw(e)),shift_held(e))
            i=self.pick(self.raw(e))
            if i is None:   # 0.19.21: a click in the void starts the rectangle
                return self.start_pending_box('mirror_selection',a,lambda a,b,remove:self.mirror_take(select(self.items,a,b),remove),shift_held(e))
            return self.mirror_take({i},shift_held(e))
        if getattr(self,'_advanced_press',False):self._advanced_press=False;return
        st=self.move_state
        if st and st.get('grip_press') and st['anchor'] is not None:
            # 0.18.5: a grip of a multiple selection dragged and released places the selection there;
            # a simple click leaves it following the mouse until the next click.
            x,y=st.pop('grip_press')
            if math.hypot(e.x-x,e.y-y)>=4:
                self._stack_answer=True   # released on stacked anchors: the closest one (or Tab's), no question
                try:return self.down(e)
                finally:self._stack_answer=False
            return 'break'
        held=self.grip_drag is not None;before=set(self.selected_set);result=super().up(e)
        self.selection_changed(before)
        if held and self.grip_drag is None:self.end_grip_input()
        elif self.grip_drag is not None:self.draw_crosshair()
        return result
    def selection_changed(self,before):
        """What a click or a rectangle of the Sélection changed: never hidden preparations (0.17.0, they still follow
        their piece), nor hidden précoupes / surcoupes (0.19.14); a whole cote (0.16.26); noted as chosen since the
        last command. 0.19.21: also after the second click of a rectangle."""
        if self.tool.get()!='select':return
        if self.selected_set!=before and not __import__('preparation_ui').visible(self):
            kept={i for i in self.selected_set if i<len(self.items) and not self.items[i].get('preparation')}
            if kept!=self.selected_set:self.selected_set=kept;self.selected=min(kept) if kept else None;self.refresh()
        hidden=__import__('preparation_ui').hidden_ids(self) if self.selected_set!=before else set()
        if hidden and self.selected_set&hidden:
            kept=set(self.selected_set)-hidden;self.selected_set=kept;self.selected=min(kept) if kept else None;self.refresh()
        if self.selected_set!=before:
            self.expand_dimension_selection(before)
            self._selection_serial=self.__dict__.get('_command_serial',0)   # chosen since the last command
    def finish_select_box(self,a,b,remove):
        """0.19.22 (found before installing: 230 to 300 ms for the second click of a rectangle): what is hidden (zones,
        précoupes) is left out before the drawing (selection_changed took it out after: the plan drawn twice)."""
        from selection import combined,select
        from geometry import pointer_frame
        # (review 0.19.49, vitesse) the boxes the drawing kept, as the rectangle's lighting (light_box_hits): each object's box
        # was worked out again (DIFORME 6,9 → 0,7 ms, Keith Haring 16,6 → 0,8 ms), the same objects taken
        with pointer_frame(self.items):found=select(self.items,a,b)
        if found and not __import__('preparation_ui').visible(self):found={i for i in found if not self.items[i].get('preparation')}
        if found:found-=__import__('preparation_ui').hidden_ids(self)
        self.selected_set=combined(self.selected_set,found,remove)
        self.selected=min(self.selected_set) if self.selected_set else None;self.sync_fields();self.refresh()
    def close_box_click(self,e):
        """0.19.21: the second click of a rectangle closes it, whatever is under it (like AutoCAD); its release
        does nothing more."""
        before=set(self.selected_set);self.cursor_screen=(e.x,e.y);self.canvas.focus_set()
        try:self.close_pending_box(e)
        except (ValueError,IndexError) as exc:self.invalid_at(e,str(exc))
        self.selection_changed(before);self._box_closed=True;self.draw_crosshair();return 'break'
    # 0.16.30: with the arrow, the same gestures for texts, cotes and crans: the mouse over it
    # lights it, a click selects it, a double click edits it, a drag moves it.
    def double(self,e):
        """0.18.0: Tk sends a quick second click only here (never to down): it stays a click,
        except a real double-click on a text, a cote or a cran (edit) and the end of a polyline."""
        again=True
        if self.plan_active() and self.box_pending():
            # 0.19.21: a quick second click elsewhere closes the rectangle; on the very spot of the first one it is a
            # double-click (the picture's frame…), not a rectangle.
            ax,ay=self.to_screen(self._box_pending['anchor'])
            if math.hypot(e.x-ax,e.y-ay)>=4:self.down(e);return 'break'
            self.drop_pending_box();again=False
            if self.tool.get()!='select':return 'break'
        if not self.licence_complet():return None   # 0.19.16: read-only, no edit by double-click (a click stays a click)
        if not self.plan_active():return super().double(e)
        self.settle_view()
        t=self.tool.get()
        if t=='select':
            if not self.grip_drag and self.hit_grip(self.raw(e)) is None:
                i=self.pick(self.raw(e))
                if i is not None and self.edit_object(i):return 'break'
                import background_ui
                if i is None and background_ui.under(self,e.x,e.y):
                    background_ui.start_tool(self,'move');return 'break'   # 0.19.7: a double-click on the picture: its frame, like Word
            if again:self.down(e)
            return 'break'
        if t=='poly':return super().double(e)
        if t=='teinte_bord':return __import__('teinte_ui').double(self,e)   # 0.19.39: the whole piece round
        self.down(e);return 'break'
    def edit_object(self,i):
        s=self.items[i]
        if s.get('dimension_group'):return self.edit_cote(i)
        if s.get('is_notch'):return self.edit_cran(i)
        if s.get('stitch'):return self.edit_stitch(i)
        if s.get('piece_badge'):return __import__('piece_ids').edit_number(self,i)
        if s.get('text_runs'):
            kind=s.get('identification',{}).get('kind','part_name' if len(s['text_runs'])>1 and s['text_runs'][0].get('underline') else 'material')
            self.selected=i;self.selected_set={i};self.identify_dialog(kind,i);return True
        if s.get('annotation'):return self.edit_text(i)
        return False
    def edit_text(self,i,title='Texte'):
        """Free text or cote value: one field, filled in and selected; Entrée validates."""
        s=self.items[i];value=tk.StringVar(value=s.get('label',''));win=self.dialog(title)
        field=self.entry(win,value,34);field.pack(fill='x',padx=16,pady=(14,8))
        def valid(e=None):
            text=value.get().strip()
            if not text:messagebox.showerror(title,'Saisir un texte.',parent=win);return 'break'
            if len(text)>200:messagebox.showerror(title,'Texte trop long.',parent=win);return 'break'
            win.destroy()
            if i<len(self.items) and self.items[i] is s and text!=s.get('label'):
                from craft_tools import retexted
                self.snapshot();self.items[i]=retexted(s,text);self.refresh();self.status.set('Texte modifié.')
            self.canvas.focus_set();return 'break'
        self.button(win,'Valider',valid).pack(anchor='e',padx=16,pady=(2,12));win.bind('<Escape>',lambda e:(win.destroy(),self.canvas.focus_set()))
        field.bind('<Return>',valid);field.select_range(0,'end');field.icursor('end');field.focus_set();return True
    def edit_cote(self,i):
        group=self.items[i].get('dimension_group')
        label=next((j for j,s in enumerate(self.items) if s.get('dimension_group')==group and s.get('annotation')),None)
        if label is None:return False
        self.selected_set={j for j,s in enumerate(self.items) if s.get('dimension_group')==group};self.selected=i;self.refresh()
        return self.edit_text(label,'Cote')
    def edit_cran(self,i):
        """Depth and side of a cran, filled in; it stays at the same place on its piece."""
        from craft_tools import cran_host,cran_mark,rebuilt_cran
        cran=self.items[i];h=cran_host(self.items,cran)
        if h is None:return False
        host=self.items[h];mark=cran_mark(cran,host)
        if mark is None:return False
        try:inward=interior_side(host) if path(host)[1] else None
        except ValueError:inward=None
        self.selected=i;self.selected_set={i};self.refresh()
        win=self.dialog('Cran');panel=self.p['panel'];row=tk.Frame(win,bg=panel);row.pack(fill='x',padx=16,pady=(14,6))
        depth=tk.StringVar(value=self.format_length(round(mark['depth'],4)))
        self.label(row,'Profondeur ('+self.units.get()+')').pack(side='left');field=self.entry(row,depth,8);field.pack(side='left',padx=8)
        side=tk.StringVar(value='inside' if inward is not None and mark['side']==inward else 'outside');flip=tk.BooleanVar(value=False)
        options=dict(bg=panel,fg=self.p['ui_ink'],selectcolor=self.field_background(),activebackground=panel,font=('Segoe UI',10))
        if inward is not None:
            for text,key in (('Intérieur','inside'),('Extérieur','outside')):__import__('modern_style').make_radio(win,text=text,variable=side,value=key,**options).pack(anchor='w',padx=12)
        else:__import__('modern_style').make_check(win,text='Inverser le côté',variable=flip,**options).pack(anchor='w',padx=12)
        def valid(e=None):
            try:
                d=self.parse_length(depth.get())
                if not .5<=d<=200:raise ValueError('Profondeur : 0,5 à 200 mm.')
            except ValueError as exc:messagebox.showerror('Cran',str(exc),parent=win);return 'break'
            new=dict(mark,depth=d)
            # 0.18.1: a longer or shorter cran keeps its proportions (bar, cap, cut stem).
            for key in ('width','cap_width'):
                if mark.get(key) and mark.get('depth'):new[key]=mark[key]*d/mark['depth']
            if inward is not None:new['side']=inward if side.get()=='inside' else -inward
            elif flip.get():new['side']=-mark['side']
            win.destroy()
            if i<len(self.items) and self.items[i] is cran and new!=mark:
                self.snapshot();self.items[i]=rebuilt_cran(cran,host,new);self.selected=i;self.selected_set={i};self.refresh();self.status.set('Cran modifié.')
            self.canvas.focus_set();return 'break'
        self.button(win,'Valider',valid).pack(anchor='e',padx=16,pady=(8,12));win.bind('<Escape>',lambda e:(win.destroy(),self.canvas.focus_set()))
        field.bind('<Return>',valid);field.select_range(0,'end');field.icursor('end');field.focus_set();return True
    def drag_plan(self,original):
        """How a drag moves the pressed objects when it is not a plain translation: crans slide
        along their piece; a straight cote moves its dimension line (its extension lines stay
        on the measured points). None: everything is translated."""
        from craft_tools import cran_host,cran_mark,rebuilt_cran,along_contour,linear_cote,cote_normal,shifted_cote
        ids=sorted(original)
        if ids and all(original[j].get('is_notch') for j in ids):
            plans=[]
            for j in ids:
                h=cran_host(self.items,original[j])
                if h is None:return None
                host=self.items[h];mark=cran_mark(original[j],host)
                if mark is None:return None
                plans.append((j,host,mark))
            def slide(p,a):
                out={}
                for j,host,mark in plans:
                    start=locate(host,a)[0];now=locate(host,p)[0]
                    out[j]=rebuilt_cran(original[j],host,dict(mark,distance=along_contour(host,now+mark['distance']-start)))
                return out
            return slide
        groups={original[j].get('dimension_group') for j in ids}
        if len(groups)==1 and None not in groups:
            members=[original[j] for j in ids];parts=linear_cote(members)
            if parts is None:return None
            nx,ny=cote_normal(members,parts)
            def shift(p,a):
                return dict(zip(ids,shifted_cote(members,parts,(p[0]-a[0])*nx+(p[1]-a[1])*ny)))
            return shift
        return None
    def special_drag(self,e):
        st=self._contour_drag;x,y,a,i=self.box_start
        if not st['changed'] and math.hypot(e.x-x,e.y-y)<4:return False
        if 'special' not in st:st['special']=self.drag_plan(st['original'])
        plan=st['special']
        if plan is None:return False
        self.cursor_screen=(e.x,e.y);self._inside_plan=True
        try:new=plan(self.point(e),a)
        except (ValueError,ZeroDivisionError):self.draw_crosshair();return True
        if not st['changed']:self.snapshot();st['changed']=True
        for j,s in new.items():self.items[j]=s
        self.refresh();self.draw_crosshair();return True
    def prepare_offset(self,host):
        # 0.16.28: right after the polyline is chosen, a small box asks the offset value
        # (like a line length); Entrée keeps the value shown in grey, then the side is clicked.
        st=self.offset_state
        if self.tool.get()=='stitch' and self.__dict__.get('_stitch'):self._stitch['source']=copy.deepcopy(host)
        first=st is not None and not st.get('asked') and 'command_entry' in self.__dict__ and self.tool.get() in ('offset_all','offset_part')
        if first:st['asked']=True;st['asking']=True
        result=super().prepare_offset(host)
        if first:
            if self.command_value.get():self.command_value.set('')
            self._bubble_placeholder=self.format_length(st['distance'])
            x,y=self.cursor_screen;self.command_entry.place(x=x+16,y=y+16,width=60,height=21);self.command_entry.focus_set()
            self.status.set('Valeur du décalage')
        return result
    def end_offset_question(self):
        st=self.offset_state
        if st is None or not st.get('asking'):return
        st['asking']=False
        if self.command_value.get():self.command_value.set('')
        self.command_entry.place_forget()
    def enter_dimension(self,e=None):
        self.drop_pending_box()   # 0.19.21: Entrée drops a rectangle under way, then goes on
        if self.pick_phase and self.tool.get()==self.pick_phase['tool']:return self.pick_enter()
        if self.tool.get()=='assembly' and not self.command_value.get().strip():return __import__('assembly_ui').enter(self)   # 0.19.13
        if self.tool.get()=='teinte_bord' and self.__dict__.get('teinte_state') is not None:   # 0.19.39: a distance typed, else the end
            done=__import__('teinte_ui').enter(self)
            if done is not None:return done
        st=self.__dict__.get('stretch_state')
        if self.tool.get()=='stretch' and st and st.get('base') is not None and self.command_value.get().strip():   # 0.19.13: Étirer by a length typed
            try:
                d=self.parse_length(self.command_value.get().strip());a=st['base'];p=getattr(self,'pointer_world',None) or a   # (bug hunt 0.19.39) read like every typed length: in cm, 5 is 50 mm; « 20+30 »
                vx,vy=p[0]-a[0],p[1]-a[1]
                if self.ortho.get():vx,vy=(vx,0) if abs(vx)>=abs(vy) else (0,vy)
                n=math.hypot(vx,vy) or 1.;self.command_value.set('')
                return __import__('edit_tools').stretch_finish(self,d*vx/n,d*vy/n)
            except ValueError:self.status.set('Étirer : une longueur en '+self.units.get()+'.');return 'break'
        st=self.__dict__.get('_stack_choice')
        if st:self.choose_stack(st['order'][st['hot']]);return 'break'   # 0.18.6: Entrée = the highlighted line
        return self.enter_dimension_checked(e)
    def enter_dimension_checked(self,e=None):
        """0.18.5 (n° 13): a typed value that is refused is cleared at once (message kept): it can never be
        glued to the next digits typed (« 14 » refused then « 5 » used to give 145 mm)."""
        before=self.command_value.get().strip()
        result=self.enter_value(e)
        if before and self.command_value.get().strip()==before:
            self.command_value.set('')
            asking=(self.offset_state or {}).get('asking') or (self.__dict__.get('rect_reference') or {}).get('asking')
            if not asking and 'command_entry' in self.__dict__:self.command_entry.place_forget()
            self.canvas.focus_set()
        return result
    def enter_value(self,e=None):
        if self.__dict__.get('bg_tool'):
            done=__import__('background_ui').enter(self)
            if done:return done
        text=self.command_value.get().strip()
        if text and tracking.active(self):
            # 0.17.0 Repérage: a distance typed while held on a dotted line places the point there.
            # 0.19.9: read like every typed length (units, calculations): in cm, 5 is 50 mm (it was 5 mm).
            try:value=self.parse_length(text)
            except ValueError:value=None
            if self.tool.get() in SIZED_RECTS and self.start is None and len(__import__('command_catalog').dimension_chunks(text,True))>1:
                value=None   # « 100*70 » sizes the rectangle, as before (not a calculation of 7000 mm along the dotted line)
            q=tracking.typed_point(self,value)
            if q is not None:
                self.command_value.set('');self.command_entry.place_forget();self._forced_point=q
                try:
                    x,y=self.to_screen(q);ev=SimpleNamespace(x=x,y=y,state=0,char='',keysym='',x_root=x,y_root=y)
                    self.down(ev);self.up(ev)
                finally:self._forced_point=None
                return 'break'
            # 0.19.9: only a drawing tool waits for the dotted line. Moving (grips, Déplacer, Copier, Rotation,
            # Échelle, Symétrie), the value typed + Entrée is placed towards the mouse and ends, point kept or not.
            # 0.19.40: before the first point only, or in a tool that takes no value (an Arc, an Ovale, a Spline keep their points
            # elsewhere than ``start``: their radius, half-width or distance typed was refused as soon as a Repérage point was kept)
            if self.tool.get()=='drill' or ((not self.drawing_under_way() or self.tool.get() in ('arc_3p','measure','dimension','dimension_aligned')) and tracking.state(self)['points'] and self.tool.get() in tracking.TOOLS and self.tool.get() not in ('rect','rect_center','rect_round')):
                try:float(text.replace(',','.'));plain=True
                except ValueError:plain=False
                if plain:self.status.set('Glisser le long du pointillé, puis taper la distance.');return 'break'
        if text and self.tool.get() in SIZED_RECTS and self.start is None and not text.startswith(('@','#')) and '..' not in text:
            return self.size_rectangle(text)   # 0.18.5 (n° 11), after the Repérage (a distance on a dotted line places the corner)
        st=self.offset_state
        if st is not None and st.get('asking'):
            if self.command_value.get().strip():
                result=super().enter_dimension(e)
                if self.command_value.get().strip():return result   # value refused: the box stays open
            self.end_offset_question();self.canvas.focus_set()
            if self.offset_state is not None:
                self.status.set('Choisir intérieur / extérieur avec la souris, puis cliquer.')
                x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))   # the offset appears at once
            return 'break'
        if self.grip_drag:
            if self.command_value.get().strip():
                if self.grip_drag.get('lengthen'):
                    added=self.grip_added_length()
                    if added is None:self.status.set('Taper la longueur à ajouter (moins pour raccourcir).');return 'break'
                    axis=self.end_axis(self.grip_drag)
                    if axis and added<=1e-3-math.dist(axis[0],axis[1]):
                        self.status.set('Raccourcir de moins que sa longueur ('+self.format_length(math.dist(axis[0],axis[1])).replace('.',',')+' '+self.units.get()+').');return 'break'
                elif self.grip_typed_value() is None:
                    # 0.19.49: why, as the other values (« abc », « 1e9 » were said « positive »)
                    try:self.parse_length(self.command_value.get().strip());said='La distance doit être positive.'
                    except ValueError as exc:said=str(exc) or 'Valeur invalide.'
                    self.status.set(said);return 'break'
                x,y=self.cursor_screen;refused=self.__dict__.get('_refusals',0);self.move_grip(SimpleNamespace(x=x,y=y,state=0))
                # 0.19.23: the distance typed refused (its reason written beside the cross): the grip stays held, the value
                # can be changed (before, the place shown by the mouse was kept instead)
                if self.__dict__.get('_refusals',0)!=refused:return 'break'
            g=self.grip_drag;changed=g['changed'];self.grip_drag=None;self.end_grip_input()
            if changed:self.last_command=('tool','select');self.grip_done(g)
            self.refresh();return 'break'
        if self.tool.get()=='copy' and self.copy_state:return self.copy_enter()
        if self.tool.get() in ('rotate','scale') and self.__dict__.get('xform'):return __import__('transform_ui').enter(self)
        if self.tool.get()=='preparation' and self.__dict__.get('prep_state') is not None:return __import__('preparation_ui').enter(self)
        if self.tool.get()=='piece_id' and self.__dict__.get('id_state') is not None:return __import__('piece_ids').enter(self)
        if self.tool.get()=='surcoupe' and self.__dict__.get('surcoupe_state') is not None:return __import__('surcoupe_ui').enter(self)
        if self.tool.get()=='copy_notch' and self.copy_crans and self.copy_crans['phase']=='selection':
            if not self.copy_crans['ids']:self.status.set('Sélectionner au moins un cran à copier.');return 'break'
            self.copy_crans['phase']='source';self.status.set('Choisir le repère source.');return 'break'
        if self.tool.get()=='mirror' and self.mirror_phase=='selection':
            if not self.mirror_ids:self.status.set('Sélectionnez au moins un objet à miroiter.');return 'break'
            self.mirror_phase='axis';self.mirror_box=None;self.canvas.delete('mirror_selection');self.status.set('Tracer l’axe.');return 'break'
        if self.tool.get()=='mirror' and self.mirror_phase=='axis' and len(self.mirror_axis)==1 and self.command_value.get().strip():
            # 0.19.9: a value typed after the first point of the axis is its angle in degrees (the value shown
            # beside the cross), then the same question as after the second click.
            try:
                angle=float(self.command_value.get().strip().rstrip('°').strip().replace(',','.'))
                if not math.isfinite(angle):raise ValueError   # (review 0.19.49) « 1e400 », « inf »: math.cos raised; « nan »: an axis of NaN
            except ValueError:self.status.set('Taper l’angle de l’axe en degrés.');return 'break'
            a=self.mirror_axis[0];r=math.radians(angle)
            self.mirror_axis.append((a[0]+100*math.cos(r),a[1]+100*math.sin(r)))
            self.command_value.set('');self.command_entry.place_forget()
            x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y,state=0))   # the preview shows the typed axis
            self.ask_mirror_keep();return 'break'
        if self.corner_result is not None:self.commit_corner();return 'break'
        return super().enter_dimension(e)
    def commit_corner(self):
        ids,new,t=self.corner_result;self.corner_result=None
        # 0.19.5: in series: Arrondi, Chanfrein, Angle droit, Bout rond / pointu stay for the next corner or
        # the other end (each raccord its own Annuler); Échap or a click on their icon ends them.
        stays=t in CORNER_TOOLS and self.tool.get()==t and not self._action;self._corner_stays=t if stays else None
        self._refresh_held=True   # (hunt 0.19.49) drawn once, below
        try:self.replace_items(ids,new,t)
        finally:self._corner_stays=None;self._refresh_held=False
        # A second side is the final click, including tools previously running as a series.
        if self._action:self.finish_action()
        if stays and self.tool.get()==t:self.refresh();return
        self.complete_command(t);self.refresh()
    def finish_action(self):
        running=self.__dict__.get('_action') is not None;result=super().finish_action()
        if running:self.command_over()   # (set_tool also calls it, with nothing running)
        self.show_history()   # 0.19.8
        return result
    def begin_action(self,t):
        result=super().begin_action(t);self.show_history();return result   # 0.19.8: Ctrl+Z cancels the series tool
    def command_over(self):
        """A command ends: what it leaves selected is noted (once the event is over) so that a recall
        does not take it again."""
        self._command_serial=serial=self.__dict__.get('_command_serial',0)+1
        def note():
            if self.__dict__.get('_command_serial')==serial:self._left_selection=frozenset(self.selected_set)
        note();self.after(0,note)   # after the event (update_idletasks inside a redraw must not note it early)
    def repeat_last(self,e=None):
        # 0.17.0: a recalled command (Espace / Entrée) starts again at its first step. What the
        # previous command left selected is not taken again; a selection made since then is.
        chosen=self.__dict__.get('_selection_serial')==self.__dict__.get('_command_serial',0)
        if self.selected_set and not chosen and frozenset(self.selected_set)==self.__dict__.get('_left_selection'):
            self.selected=None;self.selected_set=set();self.refresh()
        return super().repeat_last(e)
    def complete_command(self,name,action=False):
        if name==self.__dict__.get('_corner_stays') and self.tool.get()==name:
            self._corner_stays=None;self.command_over();tracking.reset(self);self.last_command=('tool',name)
            self.start=None;self.pending=[];self.stage_points=[];self.numeric_width=None;self.mouse_started=False;self.snap_marker=None;self.command_value.set('');self.dimension_axis=None
            self.corner_first=None;self.selected=None;self.selected_set=set();self.canvas.delete('corner_preview')
            self.status.set(self.corner_prompt(name)+' Échap pour finir.');self.highlight_tools();self.draw_input_bubble();return
        self.command_over();tracking.reset(self)
        before=self.status.get();result=super().complete_command(name,action)
        # 0.17.0: once a command is over, its last step prompt (« Choisir le repère cible »,
        # « Sélectionner deuxième ligne »…) no longer shows as if Craft were still waiting.
        if self.tool.get()=='select' and self.status.get()==before and before.startswith(STEP_PROMPTS):self.status.set('')
        return result
    def draw_change_preview(self,before,after,tag):
        """0.17.0: only what an action changes is previewed: new sides / arcs in plain grey, the parts
        that will disappear dashed over the drawing; the rest of the piece stays untouched and sharp
        (the whole piece used to be redrawn with a pixelated grey screen)."""
        from precision_geometry import primitives,at_primitive
        from curves import parts as split
        def edges(shapes):
            out=[]
            for s in shapes:
                for q in (split(s) if s.get('components') else [s]):
                    if q.get('spline') or q.get('ellipse'):out.append(dict(points=path(q)[0]));continue
                    out+= [dict(points=[at_primitive(e,k/24) for k in range(25)] if e['sweep'] else [e['a'],e['b']],sweep=e['sweep']) for e in primitives(q)]
            return out
        def keys(e):
            pts=e['points'];ends=(pts[0],pts[len(pts)//2],pts[-1])
            return {tuple(round(v,5) for p in seq for v in p) for seq in (ends,ends[::-1])}
        old,new=edges(before),edges(after);width=self.line_px()
        known_old=set().union(*(keys(e) for e in old)) if old else set();known_new=set().union(*(keys(f) for f in new)) if new else set()
        for e in old:
            if not keys(e)&known_new:
                self.canvas.create_line(*[v for p in e['points'] for v in self.to_screen(p)],fill=self.p['canvas'],width=width+1,dash=(4,4),tags=tag)
        for f in new:
            if not keys(f)&known_old:
                self.canvas.create_line(*[v for p in f['points'] for v in self.to_screen(p)],fill='#a3a8aa',width=width,tags=tag)
    def pick_cran(self,p):
        from cad import nearest
        hits=[(math.dist(nearest(p,s),p),i) for i,s in enumerate(self.items) if s.get('is_notch')]
        return min(hits)[1] if hits and min(hits)[0]<=10/self.scale else None
    def copy_contour(self,p,source=None,only=None):
        """0.16.31: a reference point may lie where several lines meet (a line drawn across the
        piece as a marker): the source is the contour carrying the selected crans; the target,
        among the contours meeting there, one of the same kind (closed piece or line) as the
        source, another one than the source if possible. 0.18.0: ``only``, the polyline the crans
        are carried over to again (« Reporter »)."""
        from entity_rules import geometry_entity
        from craft_tools import cran_mark
        if only is not None:
            if only>=len(self.items) or math.dist(locate(self.items[only],p)[1],p)>10/self.scale:raise ValueError('Cliquer sur la même polyligne.')
            return only
        from geometry import near_box
        reach=10/self.scale
        # 0.19.9: only the contours whose box is within reach are measured (the others are never chosen): the
        # target preview of Copier crans measured every object of the plan at each move of the mouse.
        # 0.19.40: never what the layers hide (a « Préparation » line, a précoupe…: the crans went onto an invisible line)
        hidden=__import__('preparation_ui').hidden_ids(self)
        hits=sorted((math.dist(locate(s,p)[1],p),i) for i,s in enumerate(self.items) if i not in hidden and geometry_entity(s) and near_box(s,p,reach))
        # 0.17.0: the source piece is never a target (no copy sliding along its own contour).
        hits=[h for h in hits if h[0]<=reach and h[1]!=source]
        from craft_tools import prep_line
        hits=[h for h in hits if not prep_line(self.items[h[1]])] or hits   # 0.19.40: as the other tools (pick, PREP_SHY)
        if not hits:raise ValueError('Cliquer le point de repère sur une ligne ou polyligne support.' if source is None else 'Choisir le repère cible sur une autre pièce.')
        if source is None:
            crans=[self.items[j] for j in self.copy_crans['ids']]
            return next((i for _,i in hits if all(cran_mark(c,self.items[i]) is not None for c in crans)),hits[0][1])
        kind=path(self.items[source])[1];meeting=[h for h in hits if h[0]<=hits[0][0]+2/self.scale]
        return min(meeting,key=lambda h:(path(self.items[h[1]])[1]!=kind,h[0]))[1]
    def copy_crans_result(self,p):
        st=self.copy_crans;j=self.copy_contour(p,st['source'],st.get('only'))
        result=copy_independent_notches([self.items[i] for i in st['ids']],self.items[st['source']],self.items[j],st['reference'],p,st['reverse'])
        for cran in result:
            cran.pop('owner_id',None)
            owner=self.items[j].get('piece_id') or self.items[j].get('owner_id')   # 0.19.39: a précoupe's piece to recut: the précoupe's
            if owner:cran['owner_id']=owner
        return result
    def copy_crans_click(self,e):
        st=self.copy_crans;p=self.raw(e) if st['phase']=='selection' else self.point(e)
        if st['phase']=='selection':st['box']=(e.x,e.y,p);return
        if st['phase']=='source':
            i=self.copy_contour(p)
            # Verify every selected cran belongs to this source before proceeding.
            copy_independent_notches([self.items[j] for j in st['ids']],self.items[i],self.items[i],p,p)
            st.update(phase='target',source=i,reference=locate(self.items[i],p)[1]);self.status.set('Choisir le repère cible.');return
        result=self.copy_crans_result(p);target=self.copy_contour(p,st['source'],st.get('only'))
        # 0.18.0: the tool is over and nothing stays selected (no « Crans copiés. »); a small window
        # offers to carry the same crans over again on the same polyline.
        self.add_items(result,'copy_notch');self.copy_crans=None;self.canvas.delete('cran_copy');self.status.set('');self.refresh()
        self.ask_report_crans(dict(st,phase='target',only=target))
    def ask_report_crans(self,state):
        """0.18.0: « Reporter ces crans sur la même polyligne ? ». Oui: choose a new target reference
        on that polyline (the crans and the source reference are kept); Non: the tool ends."""
        win=self.dialog('Copier crans');self._report_question=win
        self.label(win,'Reporter ces crans sur la même polyligne ?').pack(padx=24,pady=(16,10))
        row=tk.Frame(win,bg=self.p['panel']);row.pack(padx=16,pady=(0,14))
        def close():
            self._report_question=None
            try:win.destroy()
            except tk.TclError:pass
            self.canvas.focus_set()
        def yes():
            close()
            if not all(i<len(self.items) and self.items[i].get('is_notch') for i in state['ids']) or state['only']>=len(self.items):return
            self.finish_action();self.cancel();self.tool.set('copy_notch');self.last_command=('tool','copy_notch');self.highlight_tools()
            self.copy_crans=dict(state);self.selected_set=set(state['ids']);self.selected=min(state['ids']) if state['ids'] else None
            self.status.set('Choisir le repère cible.');self.refresh();self.draw_crosshair()
        def no():close();self.status.set('');self.draw_crosshair()
        for text,command in (('Oui',yes),('Non',no)):
            b=self.button(row,text,command);b.pack(side='left',padx=6)
            if text=='Oui':b.configure(bg=self.p['accent'],fg=contrast_color(self.p['accent']))
        win.bind('<Return>',lambda e:yes());win.bind('<KP_Enter>',lambda e:yes())
        win.bind('<Escape>',lambda e:no());win.protocol('WM_DELETE_WINDOW',no)
        win.update_idletasks();x,y=self.winfo_pointerxy();w,h=win.winfo_reqwidth(),win.winfo_reqheight()
        x=max(0,min(self.winfo_screenwidth()-w,x+18));y=max(0,min(self.winfo_screenheight()-h,y+18))
        win.geometry(f'+{x}+{y}');win.focus_set()
        return win
    def toggle_copy_crans(self):
        self.copy_crans['reverse']=not self.copy_crans['reverse'];self.status.set('Sens de parcours inversé.' if self.copy_crans['reverse'] else 'Sens de parcours normal.')
    def notch_side_at(self,raw):
        """Side of the pending cran given by the pointer: inside/outside on a closed piece,
        left/right of the contour on an open line."""
        host=self.items[self.notch_host]
        if path(host)[1]:
            from precision_geometry import inside
            return 'inside' if inside(host,raw) else 'outside'
        pt,n=at_distance(host,self._notch_reference)
        return 1 if (raw[0]-pt[0])*n[0]+(raw[1]-pt[1])*n[1]>=0 else -1
    def place_notch(self,choice):
        i,d=self.notch_pending;side=notch_local_side(self.items[i],choice)
        # Retain inside/outside, then recompute the normal at every placement.
        from entity_rules import ensure_piece_id
        settings=new_cran(d,side);bisector=self.corner_bisector(self.items[i],d,side)
        if bisector:settings['direction']=bisector   # 0.19.22: on a corner, along its bisector (it lay along the next side)
        # 0.19.39: on the piece to recut inside a précoupe (no id of its own), the précoupe's, as make_precut gives its crans
        # (craft_tools.cran_host): it gave the inner contour an id: left out of Surcoupe 2e étape, left behind when it moved
        self.snapshot();host=self.items[i];mark=standalone_notch(host,settings);mark['owner_id']=host.get('piece_id') or host.get('owner_id') or ensure_piece_id(host);self.items.append(mark)
        self.notch_pending=None;self.refresh()
        label={'inside':'intérieur','outside':'extérieur'}.get(choice,'côté choisi')
        self.status.set('Placer crans')
    def corner_bisector(self,host,d,side):
        """0.19.22 (found before installing): a cran put on a corner of its piece (an anchor there) goes along the corner's
        bisector, on the side chosen; None away from a corner (where the side's normal is its direction)."""
        try:
            from craft_tools import at_distance
            from precision_geometry import contour_length
            total=contour_length(host);e=min(.05,total/1000)
            if total<1e-6:return None
            closed=bool(path(host)[1])
            if not closed and (d<e or d>total-e):return None
            (_,n1),(_,n2)=at_distance(host,(d-e)%total if closed else d-e),at_distance(host,(d+e)%total if closed else d+e)
            if n1[0]*n2[0]+n1[1]*n2[1]>math.cos(math.radians(10)):return None   # no corner there
            b=(n1[0]+n2[0],n1[1]+n2[1]);L=math.hypot(*b)
            if L<1e-6:return None   # a half turn: no inside to point to
            return [b[0]/L*side,b[1]/L*side]
        except (ValueError,ZeroDivisionError,IndexError):return None
    def choose_notch_side(self,choice):
        self.notch_choice=choice
        if self.notch_pending:self.place_notch(choice)
        else:self.status.set('Côté choisi : cliquer sur le contour pour poser le prochain cran.')
    def canvas_context(self,e):
        t=self.tool.get();picking=self.pick_phase and t==self.pick_phase['tool']
        if self.drop_pending_box() and not picking:self.draw_crosshair();return 'break'   # 0.19.21: it drops the rectangle under way
        if picking and self.pick_phase['ids']:return self.pick_enter()   # 0.19.21: = Entrée, as AutoCAD
        if t=='copy_notch' and self.copy_crans:
            m=self.menu();m.add_command(label=('✓ ' if self.copy_crans['reverse'] else '')+'Inverser le sens sur la cible',command=self.toggle_copy_crans);m.add_command(label='Terminer l’outil',command=self.escape);return self.show_context(m,e)   # 0.19.40: as every tool (« Annuler » is Ctrl+Z in the menus)
        if t=='mirror':
            m=self.menu();m.add_command(label=('✓ ' if self.mirror_keep else '')+'Conserver l’original',command=self.toggle_mirror);m.add_command(label='Terminer l’outil',command=self.escape);return self.show_context(m,e)
        if t=='notch':
            m=self.menu();m.add_command(label='Choisir un autre contour support',command=self.change_notch_host)
            if self.notch_host is not None and path(self.items[self.notch_host])[1]:
                m.add_command(label=('✓ ' if self.notch_choice=='inside' else '')+'Crans vers l’intérieur',command=lambda:self.choose_notch_side('inside'))
                m.add_command(label=('✓ ' if self.notch_choice=='outside' else '')+'Crans vers l’extérieur',command=lambda:self.choose_notch_side('outside'))
            m.add_command(label='Choisir à nouveau le côté du cran',command=self.reset_notch);m.add_command(label='Terminer l’outil',command=self.escape);return self.show_context(m,e)
        return super().canvas_context(e)
    def toggle_mirror(self):self.mirror_keep=not self.mirror_keep
    # 0.16.16 Copier: lines, Entrée, base point, the copy follows the cursor, click to place.
    def copy_click(self,e):
        st=self.copy_state
        if st['phase']=='selection':st['box']=(e.x,e.y,self.raw(e));return
        q=self.point(e)
        if st['phase']=='base':
            st.update(anchor=q,delta=(0,0),phase='place',drawn=None);self.command_value.set('');self.draw_copy_preview();self.draw_copy_guide()
            self.status.set('Choisir le point d’arrivée ou saisir une distance.');return
        a=st['anchor']
        if self.command_value.get().strip():
            # 0.19.9: a distance typed, then a click: the copy goes at that distance in the click's direction, as
            # shown and as with Déplacer (the click used to drop it at the mouse).
            st['direction']=(q[0]-a[0],q[1]-a[1]);return self.copy_enter()
        st['delta']=(q[0]-a[0],q[1]-a[1])
        if math.hypot(*st['delta'])<EPS:raise ValueError('Choisir un point d’arrivée différent du repère.')
        self.commit_copy()
    def copy_release(self,e):
        st=self.copy_state;x,y,a=st['box'];st['box']=None;self._advanced_press=False;self.canvas.delete('copy_selection')
        from selection import select,shift_held
        if math.hypot(e.x-x,e.y-y)>=4:return self.copy_take(select(self.items,a,self.raw(e)),shift_held(e))
        i=self.pick(self.raw(e))
        if i is None:   # 0.19.21: a click in the void starts the rectangle
            return self.start_pending_box('copy_selection',a,lambda a,b,remove:self.copy_take(select(self.items,a,b),remove),shift_held(e))
        self.copy_take({i},shift_held(e))
    def shown_only(self,found):
        """0.19.36 (review): what a rectangle took, without what the layers hide (a « Préparation » line, a précoupe…);
        0.19.40 (review): nor a zone while the Préparations are hidden (as the Sélection's rectangle, box_accepts)"""
        import preparation_ui
        hidden=preparation_ui.hidden_ids(self);zones=not preparation_ui.visible(self)
        return {i for i in found if i not in hidden and not (zones and i<len(self.items) and self.items[i].get('preparation'))} if hidden or zones else set(found)
    def crans_take(self,found,remove):
        st=self.copy_crans
        if not st or st['phase']!='selection':return
        from selection import combined
        ids=combined(set(st['ids']),found,remove)
        st['ids']=sorted(ids);self.selected_set=ids;self.selected=min(ids) if ids else None;self.refresh()
        n=len(ids);self.status.set(f'{n} cran{"s" if n>1 else ""} sélectionné{"s" if n>1 else ""}')
    def mirror_take(self,found,remove):
        if self.tool.get()!='mirror' or self.mirror_phase!='selection':return
        from selection import combined
        found=self.shown_only(found)   # (0.19.36 review: never what is hidden; its piece's own follow it, below)
        ids=combined(set(self.mirror_ids),found,remove)
        from entity_rules import linked_selection
        ids=set(linked_selection(self.items,ids)) if ids else set()   # 0.19.22: its crans, texts, stitches go with a piece (as Rotation)
        self.mirror_ids=sorted(ids);self.selected_set=ids;self.selected=min(ids) if ids else None;self.refresh()
        n=len(ids);self.status.set(f'Miroir : {n} ligne{"s" if n>1 else ""} sélectionnée{"s" if n>1 else ""}')
    def box_accepts(self,tag,s):
        import preparation_ui
        # 0.19.22 (review): what the Sélection's rectangle never takes is not lit either (finish_select_box); 0.19.36 (review):
        # no rectangle takes nor lights what is hidden (a « Préparation » line, a précoupe…)
        if (s.get('preparation') and not preparation_ui.visible(self)) or preparation_ui.hidden_cut(self,s):return False
        if tag=='cran_copy':return bool(s.get('is_notch'))   # Copier crans takes crans only
        if tag=='selection_box':return True
        if tag=='pick_selection' and self.pick_phase:
            from entity_rules import tool_accepts
            return tool_accepts(self.pick_phase['tool'],s)
        return super().box_accepts(tag,s)
    def pending_box_motion(self,e):
        """0.19.21: the rectangle started by a click follows the mouse; nothing is snapped nor lit meanwhile."""
        self.cursor_screen=(e.x,e.y);self._inside_plan=True;self.snap_marker=None;self.anchor_candidate=None
        self.canvas.delete('hover');self._hover_key=None
        self.follow_pending_box(e.x,e.y);self.draw_crosshair()
        try:self.canvas.update_idletasks()
        except tk.TclError:pass
    # 0.19.21 (« quand je clique direct sur réseau sans avoir sélectionné une pièce il ne se passe rien, c'est pas
    # clair », 09/11/2026): Réseau and Joindre without what they work on stay on and ask for it beside the cursor
    # (« Sélectionner les objets, puis Entrée »): clicks and rectangles add (Maj removes), Entrée or the right click
    # goes on: Réseau opens its window; Joindre joins them, or follows the contour from a single one (as before).
    def start_pick_phase(self,t,ids,then):
        self.finish_action();self.cancel();self.tool.set(t);self.last_command=('tool',t)
        ids=sorted(i for i in ids if i<len(self.items))
        self.pick_phase=dict(tool=t,ids=ids,box=None,then=then,points={})
        self.selected_set=set(ids);self.selected=min(ids) if ids else None
        self.highlight_tools();self.refresh();self.status.set(PICK_PROMPT);self.canvas.focus_set()
    def pick_release(self,e):
        st=self.pick_phase;x,y,a=st['box'];st['box']=None;self._advanced_press=False;self.canvas.delete('pick_selection')
        from selection import select,shift_held
        if math.hypot(e.x-x,e.y-y)>=4:return self.pick_take(select(self.items,a,self.raw(e)),shift_held(e))
        i=self.pick(self.raw(e))
        if i is None:return self.start_pending_box('pick_selection',a,lambda a,b,remove:self.pick_take(select(self.items,a,b),remove),shift_held(e))
        st['points'][i]=self.raw(e);self.pick_take({i},shift_held(e))
    def pick_take(self,found,remove):
        st=self.pick_phase
        if not st or self.tool.get()!=st['tool']:return
        from selection import combined
        from entity_rules import tool_accepts
        found={i for i in self.shown_only(found) if i<len(self.items) and tool_accepts(st['tool'],self.items[i])}   # (0.19.36 review: never hidden)
        ids=combined(set(st['ids']),found,remove)
        st['ids']=sorted(ids);self.selected_set=set(ids);self.selected=min(ids) if ids else None;self.refresh()
        self.status.set(PICK_PROMPT if not ids else f'{len(ids)} sélectionné{"s" if len(ids)>1 else ""} · Entrée pour continuer')
    def pick_motion(self,e):
        st=self.pick_phase;self.cursor_screen=(e.x,e.y);self._inside_plan=True;box=st['box']
        if box and math.hypot(e.x-box[0],e.y-box[1])>=4:self.draw_selection_box(box[0],box[1],e.x,e.y,'pick_selection')
        else:self.canvas.delete('pick_selection')
        self.draw_crosshair()
    def pick_enter(self):
        st=self.pick_phase;ids=[i for i in st['ids'] if i<len(self.items)]
        if not ids:self.status.set(PICK_PROMPT);return 'break'
        self.canvas.delete('pick_selection')
        st['then'](ids,st['points']);return 'break'
    def join_picked(self,ids,points):
        """Joindre: two objects or more joined in one polyline; a single one: the contour followed from it (at an
        intersection, a click gives the way). Refused: said, the selection stays (to change it, then Entrée)."""
        if len(ids)==1:
            i=ids[0];p=points.get(i)
            if p is None:
                try:p=at_distance(self.items[i],contour_length(self.items[i])/2)[0]   # selected by a rectangle: its middle
                except (ValueError,IndexError,KeyError,ZeroDivisionError):p=path(self.items[i])[0][0]
            self.pick_phase=None;self.selected_set=set();self.selected=None
            try:return self.walk_click(p)
            except (ValueError,IndexError) as exc:
                self.walk=None;self.start_pick_phase('join',ids,self.join_picked);self.status.set(str(exc));return
        from editing import join_shapes,closed_gap,gap_words
        try:new,gap=closed_gap(join_shapes([self.items[i] for i in ids]))   # 0.19.40: a gap under 0,1 mm closed and said, as above
        except ValueError as exc:self.status.set(str(exc));return
        self.pick_phase=None
        try:self.replace_items(ids,[new],'join')
        except ValueError as exc:self.start_pick_phase('join',ids,self.join_picked);self.status.set(str(exc));return
        if gap:self.status.set(gap_words(gap))
    def copy_take(self,found,remove):
        st=self.copy_state
        if not st or st['phase']!='selection':return
        from selection import combined
        ids=combined(set(st['ids']),self.shown_only(found),remove)   # (0.19.36 review: never what is hidden)
        st['ids']=sorted(ids);self.selected_set=set(ids);self.selected=min(ids) if ids else None;self.refresh()
        n=len(ids);self.status.set(f'Copier : {n} ligne{"s" if n>1 else ""} sélectionnée{"s" if n>1 else ""}' if ids else 'Sélectionner ligne')
    def copy_enter(self):
        st=self.copy_state;text=self.command_value.get().strip()
        if st['phase']=='selection':
            if not st['ids']:self.status.set('Sélectionner au moins une ligne.');return 'break'
            from entity_rules import linked_selection
            ids=linked_selection(self.items,st['ids']);st.update(ids=ids,source=[copy.deepcopy(self.items[i]) for i in ids],phase='base')
            self.selected_set=set(ids);self.selected=min(ids);self.canvas.delete('copy_selection');self.refresh();self.status.set('Choisir le repère.');return 'break'
        if st['phase']=='base':self.status.set('Choisir le repère.');return 'break'
        try:
            if text:
                value=self.parse_length(text);dx,dy=st.get('direction',st['delta']);n=math.hypot(dx,dy)
                if value<=0:raise ValueError('La distance doit être positive.')
                if n<EPS:raise ValueError('Donner d’abord une direction avec la souris.')
                st['delta']=(dx/n*value,dy/n*value)
            if math.hypot(*st['delta'])<EPS:raise ValueError('Choisir un point d’arrivée différent du repère.')
            self.commit_copy()
        except ValueError as exc:self.status.set(str(exc))
        return 'break'
    def copy_motion(self,e):
        st=self.copy_state;self.cursor_screen=(e.x,e.y);self._inside_plan=True
        if st['phase']=='selection':
            # 0.18.5: the box is drawn again in place (never deleted first: it follows the mouse at once).
            box=st['box']
            if box and math.hypot(e.x-box[0],e.y-box[1])>=4:self.draw_selection_box(box[0],box[1],e.x,e.y,'copy_selection')
            else:self.canvas.delete('copy_selection')
            self.draw_crosshair();return
        self.canvas.delete('snap');q=self.point(e);self.pointer_world=q
        if self.snap_marker:self.draw_snap_point(*self.snap_marker)
        if st['phase']=='place':
            a=st['anchor'];dx,dy=q[0]-a[0],q[1]-a[1];st['direction']=(dx,dy);text=self.command_value.get().strip()
            if text:
                try:
                    value=self.parse_length(text);n=math.hypot(dx,dy)
                    if value>0 and n>EPS:dx,dy=dx/n*value,dy/n*value
                except ValueError:pass
            st['delta']=(dx,dy);self.shift_copy_preview();self.draw_copy_guide()
        self.draw_crosshair()
    def copy_shapes(self,source,dx,dy):
        """Translated copies: a copied piece gets new identifiers and keeps its own labels.
        0.19.9: a cran copied without its piece is no longer tied to that piece (moving the piece took the copy
        along, wherever it was put); commit_copy gives it the contour it is put on. (0.19.49, review R4) a piece inside its
        précoupe copied alone is a piece of its own holding the copies of its marks. (Full review 0.19.49: the same rules as
        Réseau and Symétrie, edit_tools.fresh_copies.)"""
        copies=__import__('edit_tools').fresh_copies(source)
        for s in copies:s['x']+=dx;s['y']+=dy
        return copies
    def draw_copy_preview(self):
        st=self.copy_state;self.canvas.delete('copy_preview')
        if not st or st['anchor'] is None:return
        for s in self.copy_shapes(st['source'],*st['delta']):self.draw_shape(s,self.p['accent'],1,('copy_preview',))
        for item in self.canvas.find_withtag('copy_preview'):
            kind=self.canvas.type(item)
            if kind in ('line','text'):self.canvas.itemconfigure(item,fill=self.p['accent'])
            elif kind in ('oval','polygon','rectangle','arc'):self.canvas.itemconfigure(item,outline=self.p['accent'])
        st['drawn']=(st['delta'],(self.scale,self.ox,self.oy))
    def shift_copy_preview(self):
        """The copy sticks to the cursor: shift the drawn copy instead of redrawing it."""
        st=self.copy_state;drawn=st.get('drawn')
        if not drawn or drawn[1]!=(self.scale,self.ox,self.oy) or not self.canvas.find_withtag('copy_preview'):return self.draw_copy_preview()
        (px,py),view=drawn;dx,dy=st['delta']
        if (dx,dy)!=(px,py):
            x0,y0=self.to_screen((px,py));x1,y1=self.to_screen((dx,dy));self.canvas.move('copy_preview',x1-x0,y1-y0)
        st['drawn']=((dx,dy),view)
        __import__('gpu_display').dragged(self)   # 0.19.33: drawn by the graphics card (Tk only shifts)
    def draw_copy_guide(self):
        """0.16.19: the copy simply follows the cursor, without Déplacer marks."""
        self.canvas.delete('copy_guide')
    def commit_copy(self):
        st=self.copy_state;copies=self.copy_shapes(st['source'],*st['delta'])
        self.snapshot();start=len(self.items);self.items.extend(copies)
        # 0.19.9: a cran copied without its piece belongs to the contour it is put on, as with the Cran tool (none: free); 0.19.22:
        # a text, an ID, a Piqûre, a zone is the piece's it is put in (full review 0.19.49: Réseau and Symétrie too, edit_tools)
        __import__('edit_tools').own_marks(self,zip(st['source'],copies))
        for tag in ('copy_preview','copy_guide'):self.canvas.delete(tag)
        self.copy_state=None;self.command_value.set('');self.complete_command('copy')
        self.selected_set=set(range(start,len(self.items)));self.selected=start;self.refresh()
        n=len(copies);self.status.set(f'{n} élément{"s" if n>1 else ""} copié{"s" if n>1 else ""}.')
    def text_focus(self):
        w=self.focus_get()
        return w is not None and w is not self.canvas and w.winfo_class() in ('Entry','TEntry','Text','Spinbox','TSpinbox','TCombobox')
    def clipboard_copy(self,e=None):
        if self.text_focus() or self.modal_active():return None
        from entity_rules import linked_selection
        ids=linked_selection(self.items,self.selected_ids())
        if not ids:self.status.set('Sélectionner ligne, puis Ctrl+C.');return 'break'
        self.clipboard_items=[copy.deepcopy(self.items[i]) for i in ids]
        n=len(ids);self.status.set(f'{n} élément{"s" if n>1 else ""} copié{"s" if n>1 else ""} · Ctrl+V pour coller.');return 'break'
    def clipboard_paste(self,e=None):
        if self.text_focus() or self.modal_active():return None
        if not self.clipboard_items:self.status.set('Rien à coller : sélectionner ligne, puis Ctrl+C.');return 'break'
        x,y,X,Y=bounds(self.clipboard_items);base=((x+X)/2,(y+Y)/2)
        self.finish_action();self.cancel();self.tool.set('copy');self.last_command=('tool','copy');self.highlight_tools()
        q=self.raw(SimpleNamespace(x=self.cursor_screen[0],y=self.cursor_screen[1]))
        self.copy_state=dict(phase='place',ids=[],box=None,source=copy.deepcopy(self.clipboard_items),anchor=base,delta=(q[0]-base[0],q[1]-base[1]),drawn=None)
        self.selected=None;self.selected_set=set();self.refresh();self.canvas.focus_set()
        self.status.set('Choisir le point d’arrivée ou saisir une distance.');return 'break'
    def ask_mirror_keep(self):
        """0.16.16: once the axis is drawn, ask whether the original stays.
        Entrée = last choice, Échap = draw the axis again."""
        win=self.dialog('Symétrie');self._mirror_question=win
        self.label(win,'Garder l’élément de base ?').pack(padx=24,pady=(16,10))
        row=tk.Frame(win,bg=self.p['panel']);row.pack(padx=16,pady=(0,14))
        def choose(keep):
            self._mirror_question=None;win.destroy();self.canvas.focus_set();self.mirror_keep=keep
            try:self.apply_mirror(keep)
            except ValueError as exc:   # 0.19.9: the axis is drawn again instead of staying stuck
                self.mirror_axis=[];self.canvas.delete('preview');self.status.set(str(exc)+' Tracer l’axe.')
        def cancel():
            self._mirror_question=None;win.destroy();self.canvas.focus_set();self.mirror_axis=[];self.canvas.delete('preview');self.status.set('Tracer l’axe.')
        for text,keep in (('Garder',True),('Supprimer',False)):
            b=self.button(row,text,lambda keep=keep:choose(keep));b.pack(side='left',padx=6)
            if keep==self.mirror_keep:b.configure(bg=self.p['accent'],fg=contrast_color(self.p['accent']))
        self.button(row,'Valider',lambda:choose(self.mirror_keep)).pack(side='left',padx=(14,6))   # 0.18.5: the choice shown in colour
        win.bind('<Return>',lambda e:choose(self.mirror_keep));win.bind('<KP_Enter>',lambda e:choose(self.mirror_keep))
        win.bind('<Escape>',lambda e:cancel());win.protocol('WM_DELETE_WINDOW',cancel)
        # 0.16.20: opened beside the mouse, so the answer is one short move away.
        win.update_idletasks();x,y=self.winfo_pointerxy();w,h=win.winfo_reqwidth(),win.winfo_reqheight()
        x=max(0,min(self.winfo_screenwidth()-w,x+18));y=max(0,min(self.winfo_screenheight()-h,y+18))
        win.geometry(f'+{x}+{y}');win.focus_set()
        return win
    def apply_mirror(self,keep):
        axis=self.mirror_axis
        if self.mirror_mark is not None:
            from curves import compound
            i,j,marks=self.mirror_mark;new=compound([mirror(v,*axis) for v in marks],'Cran',False)
            self.snapshot()
            if not keep:self.items[i]['notches'].pop(j)
            self.items.append(new);self.complete_command('mirror');self.refresh()
        elif keep:
            # 0.19.22: texts readable; (full review 0.19.49) a mark mirrored without its piece is the piece's it is put on, as
            # Copier (it stayed the original piece's: moved, turned and deleted with it)
            import edit_tools
            sources=[self.items[i] for i in self.mirror_ids];start=len(self.items)
            self.add_items(edit_tools.fresh_copies([mirror_readable(s,*axis) for s in sources]),'mirror')
            if edit_tools.own_marks(self,zip(sources,self.items[start:])):self.refresh()
        else:self.replace_items(self.mirror_ids,[mirror_readable(self.items[i],*axis) for i in self.mirror_ids],'mirror')
    def change_notch_host(self):
        self.notch_host=None;self.notch_pending=None;self.notch_choice=None;self.canvas.delete('notch_host');self.status.set('Sélectionner le contour support.')
    def reset_notch(self):self.notch_choice=None;self.status.set('Le prochain cran demandera le côté : intérieur ou extérieur sur une pièce fermée.')
    def walk_click(self,p):
        if self.walk is None:
            self.walk=ContourWalk(self.items)
            if not self.walk.edges:self.walk=None;raise ValueError('Aucun tracé disponible.')
            k=min(range(len(self.walk.edges)),key=lambda k:math.dist(contour_location(self.walk.edges[k]['shape'],p)[1],p))
            edge=self.walk.edges[k];v=edge['shape'];d,_=contour_location(v,p)
            if math.dist(contour_location(v,p)[1],p)>10/self.scale:self.walk=None;raise ValueError('Cliquer sur le tracé de départ.')
            closed=self.walk.take(k,d<=contour_length(v)/2)
        else:
            choices=self.walk.choices()
            if not choices:raise ValueError(self.show_dead_end())
            def score(choice):
                k,forward=choice;pts=path(self.walk.edges[k]['shape'])[0];pts=pts if forward else list(reversed(pts));origin=pts[0];target=next((q for q in pts[1:] if math.dist(q,origin)>EPS),pts[-1]);u=(target[0]-origin[0],target[1]-origin[1]);v=(p[0]-origin[0],p[1]-origin[1]);return -(u[0]*v[0]+u[1]*v[1])/(math.hypot(*u)*max(EPS,math.hypot(*v)))
            closed=self.walk.take(*min(choices,key=score))
        if closed or self.walk.advance():
            gaps=[gap for gap,*_ in self.walk.bridged]
            try:ids,new=self.walk.result()
            finally:self.walk=None   # 0.19.8: a contour refused (« Jonction ambiguë »…) does not leave a closed walk behind
            self.replace_items(ids,new,'join')
            if gaps:   # 0.19.8: the gaps under 0,1 mm closed by Joindre are said
                said=' et '.join(f'{g:.2f}'.replace('.',',') for g in gaps)
                self.status.set('Contour fermé : '+(f'écart de {said} mm fermé.' if len(gaps)==1 else f'{len(gaps)} écarts fermés ({said} mm).'))
            return
        self.refresh()
        if self.walk.choices():self.draw_walk();self.status.set('Intersection ? Cliquer dans la direction à suivre.')
        else:self.show_dead_end()
    def show_dead_end(self):
        """0.19.8 « indiquer où est le problème »: where Joindre stops, ringed in red, the view centred on it, and
        the gap to the nearest end said; returns the message."""
        p,gap=self.walk.dead_end();self.walk.stuck=p
        W,H=max(100,self.canvas.winfo_width()),max(100,self.canvas.winfo_height());x,y=self.to_screen(p)
        if not (40<=x<=W-40 and 40<=y<=H-40):self.ox=W/2-p[0]*self.scale;self.oy=H/2-p[1]*self.scale;self.redraw()   # centred when it is not in view
        self.draw_walk()
        text='Polyligne ouverte ici (rond rouge) : '+('aucun autre trait.' if gap is None else 'l’extrémité la plus proche est à '+f'{gap:.2f}'.replace('.',',')+' mm.')
        self.status.set(text);return text
    def draw_walk(self):
        if self.walk is None:return
        self.canvas.delete('walk')
        for s in self.walk.route:self.draw_shape(s,self.p['accent'],2,('walk',))
        stuck=self.walk.__dict__.get('stuck')
        if stuck is not None:
            x,y=self.to_screen(stuck);self.canvas.create_oval(x-14,y-14,x+14,y+14,outline='#ee4444',width=2.5,tags='walk')
        origin=self.walk.nodes[self.walk.current];x,y=self.to_screen(origin)
        for k,forward in self.walk.choices():
            pts=path(self.walk.edges[k]['shape'])[0];pts=pts if forward else list(reversed(pts));p=next((p for p in pts[1:] if math.dist(p,origin)>EPS),pts[-1]);d=math.dist(p,origin)
            if d<EPS:continue
            X,Y=x+(p[0]-origin[0])/d*35,y+(p[1]-origin[1])/d*35
            self.canvas.create_line(x,y,X,Y,fill='#ffe251',width=2,arrow='last',tags='walk');self.canvas.create_text(X+8,Y-8,text='?',fill='#ffe251',font=('Segoe UI',-15,'bold'),tags='walk')
    # 0.18.5 (n° 11): width and height typed before the first point (« 30;20 », Entrée): the rectangle
    # follows the mouse by its bottom-left corner (its centre for Rectangle centré), a click places it.
    def size_rectangle(self,text):
        from command_catalog import length_expression,dimension_chunks
        try:
            values=[length_expression(v.strip(),self.units.get()) for v in dimension_chunks(text,True) if v.strip()]
            if not values or len(values)>2:raise ValueError('Taper largeur;hauteur, par exemple 30;20.')
            if any(v<=0 for v in values):raise ValueError('Les dimensions doivent être positives.')
        except ValueError as exc:self.status.set(str(exc));return 'break'
        w,h=values if len(values)==2 else values*2
        self.rect_sized=(w,h);self.command_value.set('');self.command_entry.place_forget();self.canvas.focus_set()
        self.status.set(f'Rectangle {self.cote_value(w)} × {self.cote_value(h)} {self.units.get()} : placer '.replace('.',',')+('son centre.' if self.tool.get()=='rect_center' else 'son coin bas-gauche.'))   # 0.19.40: unit and decimal comma
        x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y,state=0));return 'break'
    def sized_corners(self,p):
        w,h=self.rect_sized
        if self.tool.get()=='rect_center':return p,(p[0]+w/2,p[1]+h/2)
        return p,(p[0]+w,p[1]-h)   # model Y goes down the screen: the bottom-left corner is (x min, y max)
    def motion(self,e):
        wait=self.__dict__.get('_space_wait')
        if wait is not None and math.hypot(e.x-wait[2][0],e.y-wait[2][1])>4:
            # (review 0.19.42: « 50 », Espace, then the mouse aiming the next side at once: the side went where the mouse was
            # 450 ms later, (0, 50) instead of (50, 0)) the value first, toward where the mouse was at Espace, as before
            self.space_settle()
        if getattr(e,'type',None) is not None:self._moved_at=time.monotonic()   # 0.19.29: the mouse moved (full_settle waits for it)
        if getattr(e,'state',0)&0x100 and not self.licence_complet():return   # 0.19.16: read-only, nothing dragged (left button held)
        if not self.plan_active():self.pointer_cursor('arrow');return
        if self.__dict__.get('bg_tool'):return __import__('background_ui').motion(self,e)
        if self.box_pending():return self.pending_box_motion(e)   # 0.19.21
        if self.tool.get()=='select' and self.watch_end_grip(e):
            self.cursor_screen=(e.x,e.y)
            for tag in ('crosshair','tool_cursor','step_hint','live_value','anchor_hint'):self.canvas.delete(tag)
            self.pointer_cursor('arrow');return
        st=self.__dict__.get('_stack_choice')
        if st:
            k=self.stack_choice_row(e.x,e.y)
            if k is not None:
                if k!=st['hot']:st['hot']=k;self.draw_stack_choice()
                self.cursor_screen=(e.x,e.y)
                for tag in ('crosshair','tool_cursor','step_hint','live_value','anchor_hint'):self.canvas.delete(tag)
                self.pointer_cursor('arrow');return
        if self.__dict__.get('rect_sized') and self.tool.get() in SIZED_RECTS:
            from cad import construct
            self.cursor_screen=(e.x,e.y);self._inside_plan=True;p=self.point(e);self.pointer_world=p;self.canvas.delete('preview')
            try:self.draw_shape(construct(self.tool.get(),list(self.sized_corners(p)),'Pièce',self.read_radius()),self.p['accent'],1,('preview',))
            except (ValueError,KeyError,TypeError):pass
            self.draw_crosshair();return
        # 0.16.26: plain hover (no shape being changed): shape boxes computed once per event.
        import deep_zoom
        __import__('dash_lines').reset(self.canvas)
        with deep_zoom.drawing(self,fine=False):   # 0.18.5: hover and previews clipped too, past 80 px/mm
            # 0.19.9: Déplacer and Copier only move the plan's items (the drawing itself changes when they are placed).
            if self.grip_drag or self.__dict__.get('_contour_drag') or self.trim_stroke is not None:
                result=self.pointer_motion(e)
            else:
                from geometry import pointer_frame
                with pointer_frame(self.items):result=self.pointer_motion(e)
        # 0.16.28: show this position now, even when the mouse moves fast (Windows otherwise
        # delays the redisplay until the mouse slows down). 0.19.22 (his lenteurs.txt of 12/11: 120 to 190 ms per move
        # of the mouse between two notches of the wheel): not while the wheel turns: the plan is then its raw lines,
        # which Windows drew again at each move; Tk shows them once the events waiting are handled.
        if not (self.__dict__.get('_settle_job') and not self.__dict__.get('_settle_is_pan')):
            try:self.canvas.update_idletasks()
            except tk.TclError:pass
        return result
    def accept_route(self):
        st=self.route_state;stitch=self.__dict__.get('_stitch')
        if self.tool.get()=='stitch_part' and st and stitch:
            stitch['source']=st['host']
            if not stitch['distance']:
                # On the polyline itself: the portion chosen is the stitch.
                q,length=st['choices'][st['hover']];self.route_state=None;self.offset_state=None;self._route_marks=[]
                self.canvas.delete('preview');self.canvas.delete('route_marks');self.add_items([copy.deepcopy(q)],'stitch_part');return
        result=super().accept_route();ref=self.rect_reference
        if ref is not None and ref.get('height') is None and 'command_entry' in self.__dict__:
            # 0.17.0 (Mesurer sur polyligne): the height is asked at once, nothing is drawn until
            # it is typed; then the whole rectangle follows the pointer and a click places it.
            ref['asking']=True;self.canvas.delete('preview');self._bubble_placeholder=''
            if self.command_value.get():self.command_value.set('')
            x,y=self.cursor_screen;self.place_value_bubble(x+16,y+16);self.command_entry.focus_set()
            self.status.set('Saisir hauteur')
        return result
    def commit_reference_rect(self,p,height=None):
        ref=self.rect_reference
        if ref is not None and ref['phase']=='place' and ref.get('height') is None:
            if height is None:raise ValueError('Saisir la hauteur.')
            result=super().commit_reference_rect(p,height)
            ref['asking']=False;self.command_entry.place_forget();self.canvas.focus_set();self.status.set('Placer rectangle')
            x,y=self.cursor_screen;self.pointer_motion(SimpleNamespace(x=x,y=y,state=0));return result
        return super().commit_reference_rect(p,height)
    def reference_motion(self,e):
        p=self.point(e);self.pointer_world=p;self.cursor_screen=(e.x,e.y);self._inside_plan=True;self.canvas.delete('preview')
        ref=self.rect_reference
        if ref['phase']!='place' or ref.get('height'):
            q=self.reference_rect(p)
            if q['h']>1e-6:self.draw_shape(q,self.p['ink'],1,('preview',))
        self.draw_crosshair();self.draw_input_bubble()
    def track_hover(self):
        # 0.18.0: Repérage also while copying, turning, scaling, mirroring and dragging a grip.
        if tracking.active(self):tracking.hover(self);tracking.draw(self)
    def pointer_motion(self,e):
        if self.__dict__.get('rect_reference') and self.tool.get()=='rect_path':return self.reference_motion(e)
        if self.tool.get()=='select' and self.__dict__.get('box_start') is not None and self.__dict__.get('_contour_drag') and self.special_drag(e):return
        if self.tool.get()=='copy' and self.copy_state:result=self.copy_motion(e);self.track_hover();return result
        if self.pick_phase and self.tool.get()==self.pick_phase['tool']:return self.pick_motion(e)
        if self.tool.get() in ('rotate','scale') and self.__dict__.get('xform'):result=__import__('transform_ui').motion(self,e);self.track_hover();return result
        if self.tool.get()=='preparation' and self.__dict__.get('prep_state'):return __import__('preparation_ui').motion(self,e)
        if self.tool.get() in ('fillet','chamfer','corner')+STRAP and self.corner_first is not None:
            self.cursor_screen=(e.x,e.y);self._inside_plan=True;self.canvas.delete('corner_preview');self.snap_marker=None;self.anchor_candidate=None
            i=self.pick(self.raw(e));j,q=self.corner_first;t=self.tool.get()
            if i is not None:
                try:
                    value=self.corner_value(t)
                    ids,new=raccord_document(self.items,j,i,q,self.raw(e),t,value)
                    self.draw_change_preview([self.items[k] for k in ids],new,'corner_preview')
                except (ValueError,IndexError,ZeroDivisionError):pass
            self.draw_crosshair();return
        if self.tool.get()=='copy_notch' and self.copy_crans:
            self.cursor_screen=(e.x,e.y);self._inside_plan=True;st=self.copy_crans
            box=st['box'] if st['phase']=='selection' else None
            if not (box and math.hypot(e.x-box[0],e.y-box[1])>=4):self.canvas.delete('cran_copy')
            if st['phase']=='selection' and st['box']:
                x,y,p=st['box']
                if math.hypot(e.x-x,e.y-y)>=4:self.draw_selection_box(x,y,e.x,e.y,'cran_copy')
            elif st['phase']=='target':
                try:
                    for s in self.copy_crans_result(self.point(e)):self.draw_shape(s,self.p['accent'],1,('cran_copy',))
                except ValueError:pass
            elif st['phase']=='source':self.point(e)
            self.draw_crosshair();return
        if self.tool.get()=='mirror' and self.mirror_phase=='selection':
            self.cursor_screen=(e.x,e.y);self._inside_plan=True;box=self.mirror_box
            if box and math.hypot(e.x-box[0],e.y-box[1])>=4:self.draw_selection_box(box[0],box[1],e.x,e.y,'mirror_selection')
            else:self.canvas.delete('mirror_selection')
            self.draw_crosshair();return
        if self.tool.get()=='mirror' and self.mirror_axis:
            # 'snap' is otherwise only cleared by the drawing preview: remove the previous marker.
            self.cursor_screen=(e.x,e.y);self.canvas.delete('preview');self.canvas.delete('snap');p=self.point(e);a=self.mirror_axis[0]
            if len(self.mirror_axis)>1:p=self.mirror_axis[1]  # axis fixed while the keep/delete question is open
            if self.snap_marker:self.draw_snap_point(*self.snap_marker)
            self.canvas.create_line(*self.to_screen(a),*self.to_screen(p),fill=self.p['accent'],tags='preview',**self.guide_style())
            if math.dist(a,p)>EPS:
                sources=self.mirror_mark[2] if self.mirror_mark is not None else [self.items[i] for i in self.mirror_ids]
                for s in sources:self.draw_shape(mirror_readable(s,a,p),'#a3a8aa',1,('preview',))
                for item in self.canvas.find_withtag('preview'):
                    if self.canvas.type(item)=='line':self.canvas.itemconfigure(item,fill='#a3a8aa',stipple='gray50')
            self.track_hover();self.draw_crosshair();return
        if self.corner_result is not None:self.cursor_screen=(e.x,e.y);self.snap_marker=None;self.draw_crosshair();return
        result=super().motion(e);self.draw_walk();self.draw_notch_host()
        if self.tool.get() in STRAP and self.corner_first is None:self.strap_preview(e)
        if self.tool.get()=='belt_holes':__import__('belt_holes_ui').preview(self,e)   # 0.19.5
        elif self.tool.get()=='buckle_slot':__import__('strap_ui').slot_preview(self,e)   # 0.19.6
        elif self.tool.get()=='strap_piece':__import__('strap_ui').piece_preview(self,e)
        elif self.tool.get()=='toron':__import__('strap_ui').toron_preview(self,e)
        elif self.tool.get()=='assembly':__import__('assembly_ui').hover(self,e)   # 0.19.13
        elif self.tool.get()=='teinte_bord':__import__('teinte_ui').preview(self,e)   # 0.19.39
        elif self.tool.get()=='stretch':__import__('edit_tools').stretch_preview(self,e)
        elif self.tool.get()=='passant':__import__('strap_ui').passant_preview(self,e)
        elif self.tool.get()=='array_centre':__import__('edit_tools').centre_preview(self,e)   # 0.19.22
        if tracking.active(self):tracking.hover(self);tracking.draw(self)
        self.canvas.delete('notch_preview')
        if self.tool.get()=='notch' and self.notch_host is not None and self.notch_host<len(self.items) and (self.notch_choice is not None or self.notch_pending is not None):
            host=self.items[self.notch_host]
            if self.notch_choice is None:d,choice,near=self.notch_pending[1],self.notch_side_at(self.raw(e)),True   # orienting the first cran
            else:
                # 0.16.31: the preview follows the snapped point, where the click puts the cran.
                spot=self.snap_marker[0] if self.snap_marker else self.raw(e)
                d,p=locate(host,spot);choice=self.notch_choice;near=math.dist(p,spot)<=10/self.scale
            if near:self.draw_cran_preview(host,new_cran(d,notch_local_side(host,choice)))
        return result
    def corner_value(self,t):
        """The value a raccord tool uses: Arrondi its radius, Chanfrein its distance, Bout pointu (0.19.5) the
        length of its point (0: at 45°); 0.19.6: Bout rond how far from the end its round starts (0: a half
        round), Bout de ceinture (taper, tip, round)."""
        if t=='strap_belt':return __import__('strap_ui').belt_value(self)
        return self.fillet_radius if t=='fillet' else self.angle_value if t=='chamfer' else self.__dict__.get('point_length',0.) if t=='strap_point' else self.__dict__.get('round_depth',0.) if t=='strap_round' else 0
    def strap_preview(self,e):
        """0.19.3: Bout rond / Bout pointu: the end of the strap shown on the side of a piece under the
        mouse, before the click."""
        self.canvas.delete('corner_preview')
        p=self.raw(e);i=self.pick(p)
        if i is None:return
        try:
            done=strap_shape(self.items[i],p,self.tool.get(),self.corner_value(self.tool.get()))
            if done is not None:self.draw_change_preview([self.items[i]],[done],'corner_preview')
        except (ValueError,IndexError,ZeroDivisionError):pass
    def draw_cran_preview(self,host,mark):
        """0.18.0: the cran about to be placed is drawn on whole pixels around the centre of the
        anchor square, so it stays centred on it at every zoom (a short line rounded on its own
        leans to one side when the cran is only a few pixels long)."""
        c=self.canvas;fx,fy=self.to_screen(at_distance(host,mark['distance'])[0])
        dx,dy=math.floor(fx+.5)-fx,math.floor(fy+.5)-fy   # Tk rounds the square the same way
        stem=None
        for q in notch_shapes(dict(host,notches=[mark])):
            pts=path(q)[0]
            if len(pts)<2:continue
            (ax,ay),(bx,by)=[(x+dx,y+dy) for x,y in (self.to_screen(pts[0]),self.to_screen(pts[-1]))]
            if abs(ay-by)<.01 or abs(ax-bx)<.01:
                # A filled band one pixel wide: the stem from the foot pixel to the tip (0.18.1: and
                # the end of a cut stem up to the cap's pixel), a bar with as many pixels on both
                # sides of its middle.
                flat=abs(ay-by)<.01;u,v=(ax,bx) if flat else (ay,by);across=math.floor((ay if flat else ax)+.5)
                if stem is None and math.hypot(ax-fx-dx,ay-fy-dy)<.01:stem=flat
                if stem==flat:lo,hi=sorted((math.floor(u+.5),math.floor(v+.5)))
                else:mid=math.floor((u+v)/2+.5);k=round(abs(v-u)/2);lo,hi=mid-k,mid+k
                box=(lo,across,hi+1,across+1) if flat else (across,lo,across+1,hi+1)
                c.create_rectangle(*box,fill='#a3a8aa',outline='',tags='notch_preview')
            else:c.create_line(ax,ay,bx,by,fill='#a3a8aa',width=1,tags='notch_preview')
    def redraw(self):
        __import__('geometry').forget_boxes()   # 0.19.9: the boxes kept between pointer events are computed again
        if self.__dict__.get('_hold_redraw'):self._redraw_wanted=True;return
        if not (self.__dict__.get('_gesture_redraw') or self.__dict__.get('_settling')):__import__('gpu_display').stop(self,keep=True)   # 0.19.31: anything else drawn (review: also during a gesture's settle delay): Tk's own drawing (0.19.35: the plan read for the card kept while this drawing changes none of the objects' items: _plan_count)
        if self.__dict__.get('_settle_is_pan') and not self.__dict__.get('pan'):self.cancel_settle()   # 0.18.4: this full drawing is the one due after the move
        # Smoothing re-renders the whole plan: during a drag or a zoom, only once the gesture is over;
        # otherwise (0.17.0) at once, before Tk shows the raw lines: no more flash of thick lines.
        drag=self.__dict__.get('_contour_drag')
        moving=bool(self.translating_ids() or self.grip_drag or (drag and drag.get('special') and drag.get('changed')))
        moving=moving or self.view_gesture()   # 0.18.2: no smoothing while the wheel turns or the view moves
        view=time.monotonic()-self.__dict__.get('_view_moved',0)<.25
        smooth=self.prefs.get('smooth_display',True)
        import background_ui
        settling=self.__dict__.get('_settling')   # 0.19.30: the full drawing of a settle: smoothed in the background after it
        if moving or view or settling:self.drop_smooth()
        elif smooth and self.plan_active():self.schedule_smooth()   # 0.19.7: over a background picture too (it goes under the smoothed lines)
        else:
            self.drop_smooth()
            __import__('display_render').cancel_soon(self.canvas)   # 0.19.30 (review): « Plan lissé » off, a fiche: none in the background either
        if not self.plan_active():
            # 0.17.0: the fiches made from the plan (Coupe, Parage, Teinte); another sheet tab is an empty page.
            __import__('fiches').draw(self,self.active_section);return
        import deep_zoom
        __import__('dash_lines').reset(self.canvas)   # 0.18.5: a budget of dashes for this drawing
        c=self.canvas;view_key=(self.scale,self.ox,self.oy,c.winfo_width(),c.winfo_height(),self.__dict__.get('_view_epoch',0))
        if self.__dict__.get('_clip_key')!=view_key:   # 0.19.30 (review): what this view draws whole (deep_zoom.clipped; draw_cache keeps nothing drawn for another view)
            self._clip_box=None;self._clip_last=None;self._clip_key=view_key
        # 0.19.9: selection_drawing: the selection is looked up once for all the objects drawn.
        self._redrawing=True   # (review 0.19.35) the card never starts inside this drawing (gpu_display.boxed): _plan_count comes after
        try:
            with deep_zoom.drawing(self),self.selection_drawing():super().redraw()   # 0.18.5: past 80 px/mm, finer curves clipped to the screen
        finally:self._redrawing=False
        c._drawn_count=c.__dict__.get('_drawn_count',0)+1   # 0.19.30 (review): a smoothing in the background put in before it never shown
        drawing=c.__dict__.get('_draw_cache')   # 0.19.35: the objects' items changed (the graphics card reads the plan again then)
        if drawing is None or drawing.changed:c._plan_count=c.__dict__.get('_plan_count',0)+1
        self._base_scale=self.scale;self.cancel_full_settle()   # (0.19.39 hunt: the base's scale, quick_base)
        if drawing is not None and drawing.approx:   # 0.19.41: groups carried over the wheel, as it showed them: drawn again exactly once the hand rests
            self._quick_since=True;self._full_job=self.after(self.FULL_SETTLE,self.full_settle)
        else:self._drawn_scale=self.scale;self._quick_since=False   # 0.19.29: the scale of the last full drawing (quick_settle)
        self.draw_walk();self.draw_notch_host();self.redraw_value_bubble()
        self.show_history()   # 0.19.8: also after Échap / Ctrl+Z inside a tool (cancel ends in a redraw), a series tool begun…
        if self.__dict__.get('_stack_choice'):self.draw_stack_choice()
        __import__('preparation_ui').lower_fills(self)
        if not self.__dict__.get('_zooming'):background_ui.draw(self)   # 0.18.0: the picture under everything (0.18.2: hidden while zooming)
        if tracking.active(self):tracking.draw(self)
        if self.__dict__.get('_export_marks'):__import__('export_check').draw_marks(self)
        if self.__dict__.get('_bag_marks'):__import__('assembly_ui').draw_bag(self)   # 0.19.24: the pairs of the bag, while its window is open
        if self.tool.get()=='assembly':__import__('assembly_ui').redrawn(self)   # 0.19.30: the check's edges kept on the plan (a resize, a settle)
        if self.copy_state and self.copy_state['phase']=='place':self.copy_state['drawn']=None;self.draw_copy_preview();self.draw_copy_guide()
        from display_render import cancel_paint
        if moving or settling:cancel_paint(self.canvas)
        elif smooth and view and self.plan_active():self.smooth_soon()   # a click just after the wheel: smoothed a moment after its drawing (0.19.30: in the background, queue_paint before)
        elif smooth and self.selection_soon():self.drop_smooth();self.smooth_soon(hide=True)
        if not (moving or view or settling):self.card_later()
    # 0.19.33 (« c'est le but d'avoir un logiciel fluide »): a selection of many objects (a rectangle, Échap) changes only
    # their colours: smoothed in the background, the picture shown kept until the new one (its lines hidden at once);
    # a few objects: at once, as before (only their part of the picture made again).
    SOON_FROM=24   # items whose look changed or objects drawn again (review: a selection shown by grips alone changes none)
    # 0.19.33: after any drawing of the plan (a selection, a change), the plan read for the graphics card once the hand rests
    # (gpu_display.prepare): the first notch of the wheel or move of the view no longer reads it (about 50 ms on his PC)
    CARD_LATER=400   # ms
    def card_later(self):
        job=self.__dict__.get('_card_job')
        if job is not None:
            try:self.after_cancel(job)
            except (tk.TclError,ValueError):pass
        try:self._card_job=self.after(self.CARD_LATER,self.card_now)
        except tk.TclError:self._card_job=None
    def card_now(self):
        self._card_job=None
        self.prepare_at_rest()
    # 0.19.37 (fluidity; his essai on TILTED, 17/11/2026 20 h 03: the first notch of the wheel 56 to 78 ms, the next ones 18 ms;
    # the texts' list of the wheel made at the first notch: 10 ms instead of 4): made while the hand rests
    def prepare_at_rest(self,tries=8):
        """Once the hand rests after a drawing of the plan: ready_for_gestures, then the plan read for the graphics card."""
        gpu=__import__('gpu_display')
        try:
            busy=self.view_gesture() or self.__dict__.get('pan') or self.grip_drag or self.translating_ids() or gpu._smoothing(self)
            if busy or time.monotonic()-self.__dict__.get('_moved_at',0)<gpu.RESTED:
                if tries:self.after(gpu.PREPARE,self.prepare_at_rest,tries-1)
                return
            self.ready_for_gestures()
        except tk.TclError:return
        gpu.prepare(self)
    def ready_for_gestures(self):
        """The texts and dashes the wheel resizes looked for (craft_zoom_ready: what is drawn before the first notch is added
        then). (Not the pieces around the view drawn ahead: zoomed in, three to eight times the items for every smoothing.)"""
        c=self.canvas
        if not self.plan_active() or not c.winfo_exists():return
        try:
            if not c.tk.call('info','procs','craft_zoom_ready'):c.tk.eval(self.ZOOM_PROC)
            c.tk.call('craft_zoom_ready',c._w,self.scale,self.zoom_fixed())
        except tk.TclError:pass
    def zoom_fixed(self):
        """What the wheel never resizes: the interface's texts, and (review 0.19.37) the selection rectangles, whose edges
        change their dash in place with their colour (green dashed, blue solid: the dash of the list made while the hand
        rested came back on a blue one)."""
        return self.FIXED_TEXT_TAGS+__import__('gpu_display').BOXES
    def selection_soon(self):
        c=self.canvas;drawing=c.__dict__.get('_draw_cache')
        # (review) picture_current: the picture kept shows the previous drawing (a change drawn just before, its smoothing still
        # pending, would stay on the screen until the picture made in the background); changed_items: grips alone change no line
        if drawing is None or not drawing.same_geometry or not drawing.picture_current or drawing.changed_items()<self.SOON_FROM:return False
        if not self.__dict__.get('_smooth_idle') or not self.plan_active() or not c.find_withtag('_smooth_display'):return False
        return not (c.find_withtag('background_image') and c.itemcget('background_image','state')!='hidden')
    def draw_context(self):
        """0.18.7: what the drawing of every object depends on besides the object and its selection
        (draw_cache keeps the groups of unchanged objects while it stays the same); None: everything
        is drawn again (a sheet is shown instead of the plan)."""
        if not self.plan_active():return None
        import marshal,craft_tools
        c=self.canvas;skip=self.NOT_DRAWN_PREFS
        try:
            colours=marshal.dumps({k:v for k,v in self.p.items() if k not in skip},2)
            prefs=colours if self.prefs is self.p else marshal.dumps({k:v for k,v in self.prefs.items() if k not in skip},2)
            # 0.19.0: grips shown or not (GRIP_LIMIT) changes the drawing of every selected object (0.19.33: in the key of each
            # selected object, draw_cache.Drawing.key: no longer the whole plan drawn again past 100 selected objects)
            return (self.scale,self.ox,self.oy,c.winfo_width(),c.winfo_height(),self.__dict__.get('_view_epoch',0),colours,prefs,marshal.dumps(craft_tools.PROFILES,2))
        except (ValueError,TypeError):return None
    # Preferences that never change how an object is drawn (the profiles of the toolbar: an object
    # carries its own style; craft_tools.PROFILES is in the context): a change of them keeps the drawing.
    NOT_DRAWN_PREFS=frozenset(('profiles','line_types','line_type','line_type_widths','toolbar_layout','tool_variants','recent_files','last_folder',
                               'grid','ortho','snaps','snap_enabled','stitch_pitch','stitch_kind','stitch_distance','pdf_square_test_offered',
                               'fiche_choice','precut','cursor_hints','cross_color','interface_profile','interface_profiles',
                               'fillet_radius','angle_value','round_depth','point_length','toron','toron_profiles','toron_profile',
                               'thread_price','sewing_speed','hourly_cost','montage_steps','step_minutes','toron_price',
                               'sale_coefficient','gammes','vat_rate','gpu_display'))   # 0.19.29 (review; 0.19.30: vat_rate)   # 0.19.9: the values kept of Arrondi, Chanfrein, Bout rond, Bout pointu (0.19.13: Poignée toron; 0.19.27: the montage's cost, on the fiches)
    def view_changed(self):
        """0.18.7: the items of the plan are moved or resized where they are (wheel, move of the view):
        none is kept by the next drawing, nor read again from memory by the smoothing."""
        self._view_epoch=self.__dict__.get('_view_epoch',0)+1
        __import__('display_render').stale_rows(self.canvas)   # 0.19.30: only their coordinates read again
    def draw_notch_host(self):
        self.canvas.delete('notch_host')
        if self.tool.get()=='notch' and self.notch_host is not None and self.notch_host<len(self.items):
            pts,closed=path(self.items[self.notch_host]);pts=pts+pts[:1] if closed else pts
            if len(pts)>1:self.canvas.create_line(*[v for pt in pts for v in self.to_screen(pt)],fill='#c696cf',width=2,tags='notch_host')
    def schedule_smooth(self):
        if self.__dict__.get('_smooth_idle') or 'canvas' not in self.__dict__:return
        from display_render import cancel_paint
        cancel_paint(self.canvas)
        try:   # (review) a canvas not laid out yet (just made): laid out first, as before, the drawing made for its size
            if self.canvas.winfo_width()<=1 or self.canvas.winfo_height()<=1:self.canvas.update_idletasks()
        except tk.TclError:return
        # 0.19.5: at start, the plan is smoothed once its view is framed (the picture made before was made
        # again at once: about 0,1 s lost).
        if self.__dict__.get('_smooth_held'):return
        # 0.19.43 (fluidity; his PC, essai d'affichage of 18/11/2026: Échap 221 → 116 ms on TILTED, 131 → 69 ms on DIFORME):
        # the smoothing is a timer, made before Tk shows anything (Tk shows what changed only once nothing else is due, at
        # idle). Before, what Tk had to show was shown first (update_idletasks: on his PC the whole plan again, 50 to 115 ms)
        # so that a smoothing at idle came before the new lines; any update_idletasks meanwhile makes it first (_smoothed_first).
        if not self.__dict__.get('_smooth_idle'):self._smooth_idle=self.after(0,self.smooth_now)
    def release_smooth(self):
        if self.__dict__.get('_smooth_held'):self._smooth_held=False;self.schedule_smooth()
    def drop_smooth(self):
        job=self.__dict__.get('_smooth_idle');self._smooth_idle=None
        if job:
            try:self.after_cancel(job)
            except tk.TclError:pass
    # 0.19.30: Python's garbage collector stopped Craft 15 to 37 ms now and then (a full collection walks every object:
    # DIFORME, 49 000): once a document is open, what is there is frozen out of the collections (gc.freeze); what was
    # frozen before (a document closed since) is collected first.
    MEMORY_SETTLE=600   # ms after a document is opened (later while the view moves)
    def add_doc(self,items,workspace,filename=None,background=None,infos=None):
        result=super().add_doc(items,workspace,filename,background,infos)
        self.settle_memory_later()
        return result
    def settle_memory_later(self,delay=None):
        job=self.__dict__.get('_memory_job')
        if job is not None:
            try:self.after_cancel(job)
            except (tk.TclError,ValueError):pass
        try:self._memory_job=self.after(self.MEMORY_SETTLE if delay is None else delay,self.settle_memory)
        except tk.TclError:self._memory_job=None
    def settle_memory(self):
        self._memory_job=None
        if self.view_gesture() or self.__dict__.get('pan') or self.grip_drag or self.translating_ids():return self.settle_memory_later(300)
        import gc
        try:gc.unfreeze();gc.collect();gc.freeze()
        except Exception:pass
        self.prepare_at_rest()   # 0.19.31: the document opened read for the card (its first notch at once); 0.19.37: ready_for_gestures
    def smooth_soon(self,hide=False):
        """0.19.30: the view moved (the wheel stopped, the view let go): smoothed in the background (display_render.paint_soon:
        Craft never waits for it; a notch, a move of the view, a drawing smoothed at once meanwhile drop it). ``hide``: the
        lines just drawn hidden at once under the picture kept until the new one comes (full_settle)."""
        self.drop_smooth()
        from display_render import paint_soon,drop_picture
        try:
            self.canvas._soon_wanted=self.smoothing_wanted   # (review: asked again when it comes)
            if self.canvas.winfo_exists() and self.plan_active() and self.prefs.get('smooth_display',True):paint_soon(self.canvas,hide)
            elif hide:drop_picture(self.canvas)
        except tk.TclError:pass
    def smoothing_wanted(self):
        """0.19.30 (review): a smoothing made in the background still shown when it comes (never once « Plan lissé » is
        turned off or a fiche is shown)."""
        try:return bool(self.prefs.get('smooth_display',True)) and self.plan_active() and bool(self.canvas.winfo_exists())
        except tk.TclError:return False
    def rebuild_ui(self):
        """0.19.30 (review): the window built again (mm / cm, the bar, the colours, a profile): the old one, frozen by
        settle_memory (its canvas and its drawing hold each other), collected a moment later."""
        result=super().rebuild_ui()
        self.settle_memory_later()
        return result
    def smooth_now(self):
        self._smooth_idle=None
        from display_render import paint
        try:
            if self.canvas.winfo_exists() and self.plan_active():paint(self.canvas)
        except tk.TclError:pass
        import sys
        marks=getattr(sys.modules.get('bootstrap'),'MARKS',None)
        if marks is not None and 'window' in marks and 'ready' not in marks:marks['ready']=time.perf_counter()   # 0.19.5: Démarrage in diagnostic.txt
    # 0.18.2 Zoom and move of the view: what is drawn is scaled or moved at once; the full drawing
    # and its smoothing come once the wheel stops or the button is let go (SETTLE). 0.18.4: while the
    # view moves, the smoothed picture stays and moves with the drawing (keep_picture); the pieces
    # around are drawn as the view comes near them (extend_drawing, half a screen ahead).
    SETTLE=100   # ms after the last wheel notch: its settle (0.18.7: 300 before; 0.19.30: 200 before, the smoothing now in the background)
    SETTLE_SMOOTH=60   # ms after it: the smoothing (a click or another notch meanwhile goes first; 0.18.7: 200 before)
    PAN_SETTLE=80   # 0.18.7: ms after the view is let go: its settle (SETTLE before; 0.19.30: 150 before)
    SCREEN_TAGS=('crosshair','tool_cursor','step_hint','value_bubble','input_bubble','live_value','assembly_hint')   # stay at the pointer, at their size (0.19.36 review: the check's hint too)
    # 0.18.3: what has a size on the plan follows each notch like the lines (texts: names, materials,
    # column titles, numbers…; dashes); the interface's texts keep theirs; the markers (grips,
    # anchors) follow their point at their size.
    FIXED_TEXT_TAGS=('value_bubble','input_bubble','live_value','walk','grip_guide','preview','ruler_value','export_check','step_hint','move_guide','xform','snap','scale_bar','crosshair','tool_cursor','assembly_hint')
    KEEP_SIZE_TAGS=('grips','object_anchors','anchor_hint','snap','curve_anchor','invalid')
    # A size kept in a « zoom:t=<mm> » / « zoom:d=<mm,…> » tag (ui_widgets.zoom_tag) is given exactly
    # as the full drawing gives it (Python's round: half to even); any other is scaled from its size.
    ZOOM_PROC=r'''proc craft_bround {x} {
    set f [expr {floor($x)}]
    set d [expr {$x - $f}]
    if {$d > 0.5 || ($d == 0.5 && fmod($f, 2.0) != 0.0)} {return [expr {wide($f) + 1}]}
    return [expr {wide($f)}]
}
proc craft_zoom_add {c i sold fixed} {
    global craft_zoom_ids craft_zoom_base
    set t [$c type $i]
    if {$t eq "line"} {
        set d [$c itemcget $i -dash]
        if {$d eq ""} return
    } elseif {$t eq "text"} {
        set f [$c itemcget $i -font]
        if {[llength $f] < 2} return
        set s [lindex $f 1]
        if {![string is integer -strict $s] || $s == 0} return
    } else return
    set world {}
    foreach g [$c gettags $i] {
        if {[lsearch -exact $fixed $g] >= 0} return
        if {[string match zoom:* $g]} {set world [string range $g 5 end]}
    }
    if {$t eq "text"} {
        if {[string match t=* $world] && $s < 0} {
            set craft_zoom_base($i) [list fontw [string range $world 2 end] 0]
        } else {
            set craft_zoom_base($i) [list font $s $sold]
        }
    } else {
        if {[string match d=* $world]} {
            set craft_zoom_base($i) [list dashw [split [string range $world 2 end] ,] 0]
        } else {
            foreach x $d {if {![string is integer -strict $x]} return}
            set craft_zoom_base($i) [list dash $d $sold]
        }
    }
    lappend craft_zoom_ids $i
}
proc craft_zoom_list {c sold fixed} {
    # 0.19.37: the texts and dashes the wheel resizes, looked for once a drawing (at its first notch, or while the hand
    # rests: craft_zoom_ready); the highest item then (craft_zoom_top). A line without dash (nearly all: the dashes of the
    # plan are drawn dash by dash, dash_lines) is left at once, before its tags are looked at (the same list as before)
    global craft_zoom_ids craft_zoom_base craft_zoom_top
    set craft_zoom_ids {}
    catch {unset craft_zoom_base}
    set top 0
    foreach i [$c find all] {
        if {$i > $top} {set top $i}
        set t [$c type $i]
        if {$t eq "line"} {
            set d [$c itemcget $i -dash]
            if {$d eq ""} continue
        } elseif {$t eq "text"} {
            set f [$c itemcget $i -font]
            if {[llength $f] < 2} continue
            set s [lindex $f 1]
            if {![string is integer -strict $s] || $s == 0} continue
        } else continue
        set skip 0
        set world {}
        foreach g [$c gettags $i] {
            if {[lsearch -exact $fixed $g] >= 0} {set skip 1;break}
            if {[string match zoom:* $g]} {set world [string range $g 5 end]}
        }
        if {$skip} continue
        if {$t eq "text"} {
            if {[string match t=* $world] && $s < 0} {
                set craft_zoom_base($i) [list fontw [string range $world 2 end] 0]
            } else {
                set craft_zoom_base($i) [list font $s $sold]
            }
        } else {
            if {[string match d=* $world]} {
                set craft_zoom_base($i) [list dashw [split [string range $world 2 end] ,] 0]
            } else {
                set ok 1
                foreach x $d {if {![string is integer -strict $x]} {set ok 0;break}}
                if {!$ok} continue
                set craft_zoom_base($i) [list dash $d $sold]
            }
        }
        lappend craft_zoom_ids $i
    }
    set craft_zoom_top $top
}
proc craft_zoom_ready {c sold fixed} {
    # 0.19.37: made while the hand rests (advanced_ui.ready_for_gestures): what is drawn before the first notch is added then
    global craft_zoom_ids craft_zoom_ready
    if {[info exists craft_zoom_ids]} return
    craft_zoom_list $c $sold $fixed
    set craft_zoom_ready 1
}
proc craft_zoom_grow {} {
    # 0.19.37: pieces drawn over the plan without a full drawing (extend_drawing, the base again after a quick settle):
    # added to the list at the next notch (items made since are numbered after craft_zoom_top), never looked for again
    global craft_zoom_ids craft_zoom_ready
    if {[info exists craft_zoom_ids]} {set craft_zoom_ready 1}
}
proc craft_zoom_marks {c sold snew fixed keep {fresh {}}} {
    global craft_zoom_ids craft_zoom_base craft_zoom_top craft_zoom_ready
    if {[info exists craft_zoom_ids]} {
        if {[info exists craft_zoom_ready]} {
            # 0.19.37: the list made while the hand rested: what was drawn since (the highlight under the mouse, a preview…)
            unset craft_zoom_ready
            set top $craft_zoom_top
            foreach i [$c find all] {
                if {$i > $craft_zoom_top} {
                    if {$i > $top} {set top $i}
                    if {![info exists craft_zoom_base($i)]} {craft_zoom_add $c $i $sold $fixed}
                }
            }
            set craft_zoom_top $top
        }
        # 0.19.36: what is drawn again over the plan between two full drawings (the highlight under the mouse, the preview
        # of Ajuster) is resized too (it kept its size: a label's highlight smaller than its text after a few notches)
        foreach tag $fresh {
            foreach i [$c find withtag $tag] {
                if {![info exists craft_zoom_base($i)]} {craft_zoom_add $c $i $sold $fixed}
            }
        }
    } else {
        craft_zoom_list $c $sold $fixed
        catch {unset craft_zoom_ready}
    }
    set live {}
    foreach i $craft_zoom_ids {
        # (review 0.19.37) an item gone since (drawn again: the highlight under the mouse, the base of a quick settle) leaves
        # the list: it was kept until the next full drawing and every notch went through it
        if {[$c type $i] eq ""} {unset -nocomplain craft_zoom_base($i);continue}
        lappend live $i
        lassign $craft_zoom_base($i) kind v k0
        if {$kind eq "fontw" || $kind eq "font"} {
            if {$kind eq "fontw"} {
                set n [craft_bround [expr {$v*$snew}]]
                if {$n < 1} {set n 1}
                set n [expr {-$n}]
            } else {
                set n [expr {round($v*double($snew)/$k0)}]
                if {$n == 0} {set n [expr {$v < 0 ? -1 : 1}]}
            }
            if {abs($n) > 4000} {set n [expr {$n < 0 ? -4000 : 4000}]}
            if {[catch {$c itemcget $i -font} f] || $f eq ""} continue
            catch {$c itemconfigure $i -font [lreplace $f 1 1 $n]}
        } else {
            set nd {}
            foreach x $v {
                if {$kind eq "dashw"} {set y [craft_bround [expr {$x*$snew}]]} else {set y [expr {round($x*double($snew)/$k0)}]}
                if {$y < 1} {set y 1} elseif {$y > 255} {set y 255}
                lappend nd $y
            }
            catch {$c itemconfigure $i -dash $nd}
        }
    }
    set craft_zoom_ids $live
    set inv [expr {double($sold)/$snew}]
    foreach tag $keep {
        foreach i [$c find withtag $tag] {
            set t [$c type $i]
            if {$t ne "rectangle" && $t ne "oval" && $t ne "polygon"} continue
            set xy [$c coords $i]
            set x0 [lindex $xy 0];set x1 $x0;set y0 [lindex $xy 1];set y1 $y0
            foreach {x y} $xy {
                if {$x < $x0} {set x0 $x};if {$x > $x1} {set x1 $x}
                if {$y < $y0} {set y0 $y};if {$y > $y1} {set y1 $y}
            }
            $c scale $i [expr {($x0+$x1)/2.0}] [expr {($y0+$y1)/2.0}] $inv $inv
        }
    }
}'''
    def zoom_marks(self,old,new):
        """After a notch scaled the drawing: the texts' fonts and the dashes at the new scale, the
        markers back to their size (one Tcl call)."""
        c=self.canvas
        fresh=self.FRESH_TAGS if self.__dict__.pop('_zoom_fresh',False) else ()   # 0.19.36: drawn again since the last notch
        try:
            if not c.tk.call('info','procs','craft_zoom_marks'):c.tk.eval(self.ZOOM_PROC)
            c.tk.call('craft_zoom_marks',c._w,old,new,self.zoom_fixed(),self.KEEP_SIZE_TAGS,fresh)
        except tk.TclError:pass
    def zoom_marks_grow(self):
        """0.19.37: what was just drawn over the plan without a full drawing (extend_drawing, the base after a quick settle)
        is added to the texts' list of the wheel at its next notch (before: the list made again over every item, 13 ms at
        the first notch out on TILTED)."""
        c=self.canvas
        try:
            if not c.tk.call('info','procs','craft_zoom_grow'):c.tk.eval(self.ZOOM_PROC)
            c.tk.call('craft_zoom_grow')
        except tk.TclError:forget_zoom_marks(c)
    # 0.19.36 (his capture of 17/11 15 h 33, « en zoom dezoom rapide »: a label under the mouse doubled, its highlight
    # smaller and beside it): what is drawn again as the mouse moves, with sizes that follow the zoom
    FRESH_TAGS=('hover','edit_preview')
    OVERLAYS=('scale_bar','preview','hover','grips','spline_grips','anchor_hint','export_check','export_highlight','crosshair','tool_cursor','step_hint','live_value','stack_choice')
    def extend_drawing(self,box=None,reach=.5):
        """0.18.4: the pieces the last full drawing left out that come within ``box`` (plan mm; by
        default the view and ``reach`` screen around it) are drawn, under what is drawn over the
        plan; the others wait until the view comes nearer (a long move never draws all again)."""
        if not self.__dict__.get('_drawn_box') or not self.plan_active():return
        if self.translating_ids():self.redraw_wide();return   # shapes being moved: the full drawing keeps their quick moves
        c=self.canvas;W,H=c.winfo_width(),c.winfo_height()
        if box is None:
            mx,my=W*reach,H*reach
            box=((-mx-self.ox)/self.scale,(-my-self.oy)/self.scale,(W+mx-self.ox)/self.scale,(H+my-self.oy)/self.scale)
        near=[];far=[]
        for entry in self.__dict__.get('_culled') or ():
            i,s,(x,y,X,Y)=entry
            if i>=len(self.items) or self.items[i] is not s:continue
            (near if X>=box[0] and x<=box[2] and Y>=box[1] and y<=box[3] else far).append(entry)
        drawing=c.__dict__.get('_draw_cache')   # 0.19.41: as groups of the last drawing, each in its place (kept by the next one)
        with __import__('deep_zoom').drawing(self),self.selection_drawing():   # 0.19.9: the selection looked up once
            entries=[(i,s,self.p['accent'] if i==self.selected else self.p['ink'],2 if i==self.selected else 1.2) for i,s,_ in near]
            if drawing is not None and entries and drawing.extend(entries):c.tag_raise('spline_grips')
            else:
                for i,s,color,width in entries:self.draw_shape(s,color,width)
        self._culled=far;self._drawn_box=box;self._drawn_wide=True
        grid=self.grid.get()
        if grid:   # over the whole box
            self.draw_grid(max(0,self.ox+box[2]*self.scale-W,-(self.ox+box[0]*self.scale)),max(0,self.oy+box[3]*self.scale-H,-(self.oy+box[1]*self.scale)))
        if not near and not grid:return
        self.zoom_marks_grow()   # its texts resized too (0.19.37: added to the list, no longer looked for again over all)
        __import__('preparation_ui').lower_fills(self)
        import background_ui
        c.tag_lower(background_ui.TAG)   # the same layers as a full drawing: picture, zones, grid, lines
        if c.find_withtag('pan_under'):c.tag_raise('_smooth_display','pan_under')   # the kept picture over the lines it hides (0.19.25: and the zones)
        # (review 0.19.41) the grips of the objects' groups stay in their group, as a full drawing stacks them (raised over the
        # whole plan, the drawing that follows kept them there: over the other objects' texts and lines, also once at rest)
        for tag in self.OVERLAYS:c.tag_raise('grips&&!_obj' if tag=='grips' else tag)
    EXTEND_NOW=.15   # 0.19.39: what a notch zooming out draws at once around the view (a part of the screen)
    def extend_soon(self):
        """0.19.39 (fluidity: the first notch zooming out drew and read half a screen of pieces around the view before its
        picture): the pieces within half a screen of the view drawn when Tk has nothing else to do (the notches of a quick
        turn of the wheel first; the card's picture of this one shown first), while the wheel still turns; the card reads
        them at once then (gpu_display.touched)."""
        if self.__dict__.get('_extend_job') is not None:return
        def run():
            self._extend_job=None
            try:
                if not self.view_gesture() or not self.plan_active() or self.drawn_around(.5):return
                self.extend_drawing()
                __import__('gpu_display').touched(self)
            except tk.TclError:pass
        self._extend_job=self.after_idle(run)
    def drawn_around(self,keep=.25):
        """The view and a quarter of a screen around it lie in what is drawn."""
        box=self.__dict__.get('_drawn_box')
        if not box:return False
        W,H=self.canvas.winfo_width(),self.canvas.winfo_height();mx,my=W*keep,H*keep
        x0,y0=(-mx-self.ox)/self.scale,(-my-self.oy)/self.scale;x1,y1=(W+mx-self.ox)/self.scale,(H+my-self.oy)/self.scale
        e=1e-6*max(1.,abs(x0),abs(x1),abs(y0),abs(y1))
        return box[0]-e<=x0 and box[1]-e<=y0 and x1<=box[2]+e and y1<=box[3]+e
    def redraw_wide(self):
        self._wide_draw=True;self._gesture_redraw=True   # 0.19.31: drawn again by the gesture itself (the card goes on)
        try:self.redraw()
        finally:self._wide_draw=False;self._gesture_redraw=False
    def view_gesture(self):
        """A wheel zoom waiting for its full drawing, or a move of the view in progress."""
        return self.__dict__.get('_settle_job') is not None or bool(self.__dict__.get('pan') and self.__dict__.get('_pan_moved'))
    def drawn_view(self):
        """The whole screen lies in what the last full drawing covered."""
        box=self.__dict__.get('_drawn_box')
        if not box:return False
        W,H=self.canvas.winfo_width(),self.canvas.winfo_height()
        x0,y0=-self.ox/self.scale,-self.oy/self.scale;x1,y1=(W-self.ox)/self.scale,(H-self.oy)/self.scale
        e=1e-6*max(1.,abs(x0),abs(x1),abs(y0),abs(y1))
        return box[0]-e<=x0 and box[1]-e<=y0 and x1<=box[2]+e and y1<=box[3]+e
    def clip_covers(self):
        """0.19.30 (review): the whole screen inside what the drawings since the view was last drawn made whole: the dashed
        lines (Piqûres) and, past 80 px/mm, every line and zone are cut one screen beyond the view (deep_zoom.clipped).
        True when nothing was cut."""
        box=self.__dict__.get('_clip_box')
        if box is None:return True
        W,H=self.canvas.winfo_width(),self.canvas.winfo_height()
        x0,y0=-self.ox/self.scale,-self.oy/self.scale;x1,y1=(W-self.ox)/self.scale,(H-self.oy)/self.scale
        e=1e-6*max(1.,abs(x0),abs(x1),abs(y0),abs(y1))
        return box[0]-e<=x0 and box[1]-e<=y0 and x1<=box[2]+e and y1<=box[3]+e
    def show_raw_view(self):
        """The lines instead of the smoothed picture, a pending smoothing dropped."""
        from display_render import show_raw
        self.drop_smooth()
        try:show_raw(self.canvas)
        except tk.TclError:pass
    def cancel_settle(self):
        """The full drawing due after the wheel or a move of the view is dropped (it is done now or
        comes otherwise); True if one was due."""
        job=self.__dict__.get('_settle_job');self._settle_job=None;self._settle_is_pan=False
        if job is None:return False
        try:self.after_cancel(job)
        except (tk.TclError,ValueError):pass
        return True
    def settle_view(self,at_once=False):
        """The wheel stopped (or a click / a key came first): the full drawing, its smoothing and
        the tool's preview at the new scale. 0.19.22 (« laggy quand je suis zoomé »; his lenteurs.txt: the raw lines
        shown, then smoothed 60 ms later: 150 to 250 ms in all): the wheel stopped by itself (settle_wheel): smoothed
        at once, as after a move of the view (the raw lines are never shown); a click or a key first: a moment later."""
        if not self.cancel_settle():return
        if not at_once:self._view_moved=time.monotonic()   # (a click or a key first: its own drawing smoothed in the background too)
        try:
            if not self.canvas.winfo_exists():return
            self._settling=True   # 0.19.30: its smoothing in the background (the lines shown meanwhile, as during the gesture)
            try:self.redraw()
            finally:self._settling=False
            if self._inside_plan and self.plan_active():
                x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))   # the tool's preview, as zoom did before
            self.smooth_soon()
            self.after(__import__('gpu_display').PREPARE,self.prepare_at_rest)   # (review 0.19.37: as full_settle; the first notch or move after it read the whole plan for the card, 40 to 65 ms on his PC)
        except tk.TclError:pass
    def settle_wheel(self):
        try:
            if self.quick_settle():return None   # 0.19.29
            return self.settle_view(at_once=True)
        finally:__import__('gpu_display').settled(self)   # 0.19.31: the card's picture until Tk's smoothed one is there
    # 0.19.29 (« tjrs des latences importantes sur les zooms entre les fichiers avec peu de pièces et ceux remplis comme
    # TILTED »; his lenteurs.txt: 100 to 160 ms each time the wheel stops on TILTED or DIFORME, the drawing made again
    # about a third of it): the wheel stopped within QUICK_ZOOM of the scale of the last full drawing (and on the same
    # side of 80 px/mm), the lines scaled by the wheel are the drawing: only smoothed (as the full drawing would be:
    # the dashes are in mm, the texts and the marks follow each notch); the full drawing comes FULL_SETTLE ms later
    # when nothing else came meanwhile (finer curves, a dash shorter than 4 px drawn plain until then).
    QUICK_ZOOM=8   # 0.19.30 (1,75 before): under 80 px/mm the curves are cut the same at any scale (deep_zoom.tolerance)
    FULL_SETTLE=1200
    IDLE_SETTLE=.5   # s the mouse rests before the full drawing
    def quick_settle(self):
        """The wheel stopped: smoothed without drawing again when the drawing scaled by the wheel still holds; True then."""
        import background_ui
        if self.__dict__.get('_settle_job') is None:return True   # (nothing was due)
        try:
            if not self.canvas.winfo_exists() or not self.plan_active() or not self.prefs.get('smooth_display',True):return False
            if not self.quick_zoom_holds(self.__dict__.get('_drawn_scale')) or not self.drawn_view() or not self.clip_covers():return False
            if background_ui.visible(self):return False
            if self.translating_ids() or self.grip_drag or self.__dict__.get('pan') or self.__dict__.get('_hold_redraw'):return False
        except tk.TclError:return False
        self.cancel_settle()
        try:
            self.quick_base()
            self.restacked()
            self._quick_since=True
            if self._inside_plan:
                x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))   # the tool's preview, as the full drawing does
            self.smooth_soon()   # 0.19.30: in the background
        except tk.TclError:pass
        self.cancel_full_settle();self._full_job=self.after(self.FULL_SETTLE,self.full_settle)
        return True
    def restacked(self):
        """0.19.41: after a move of the view (keep_picture put the smoothed lines under the picture), the objects stacked
        again as a full drawing stacks them before the smoothing (the drawing that follows keeps them: a click no longer
        draws the whole plan again): the zones under all, the picture over them, the spline grips on top."""
        if not __import__('draw_cache').restack(self):return
        import background_ui
        c=self.canvas;__import__('preparation_ui').lower_fills(self);c.tag_lower(background_ui.TAG);c.tag_raise('spline_grips')
    def quick_zoom_holds(self,drawn):
        """The lines the wheel scaled from the last full drawing (at ``drawn``) still hold at this scale: within
        QUICK_ZOOM of it, on the same side of 80 px/mm, past it never cut coarser than this scale needs (review: curves
        cut for the scale drawn). 0.19.39 (hunt): quick_settle's and quick_pan's (a move of the view within SETTLE ms of
        the last notch takes the wheel's settle over)."""
        import deep_zoom
        if not drawn or not 1/self.QUICK_ZOOM<=self.scale/drawn<=self.QUICK_ZOOM:return False
        if (self.scale>deep_zoom.FINE_FROM)!=(drawn>deep_zoom.FINE_FROM):return False
        return not (self.scale>deep_zoom.FINE_FROM and deep_zoom.tolerance(self.scale)<deep_zoom.tolerance(drawn))
    def quick_base(self):
        """The base's columns and titles (their words placed by their measured widths) and the grid (its step chosen
        again for the scale: never 5 times too dense) drawn again for this scale, stacked as a full drawing stacks them
        (the zones under all: the picture is raised just over them)."""
        c=self.canvas
        if c.find_withtag('guides'):
            c.delete('guides');self.draw_guides();c.tag_lower('guides')
            self.zoom_marks_grow()
        if self.grid.get():
            W,H=c.winfo_width(),c.winfo_height();self.draw_grid(*((W,H) if self.__dict__.get('_drawn_wide') else (20,20)))
        __import__('preparation_ui').lower_fills(self)
        self._base_scale=self.scale
    def full_settle(self):
        """The full drawing after a quick settle (review: whenever one came since the last full drawing, the scale the
        same or not), once the mouse has rested IDLE_SETTLE s (never in the middle of its moves); the tool's preview with it."""
        self._full_job=None
        if not self.__dict__.get('_quick_since') or self.view_gesture() or self.translating_ids() or self.grip_drag:return
        rested=time.monotonic()-self.__dict__.get('_moved_at',0)
        if rested<self.IDLE_SETTLE:
            self._full_job=self.after(int((self.IDLE_SETTLE-rested)*1000)+20,self.full_settle);return
        try:
            if self.canvas.winfo_exists() and self.plan_active():
                # 0.19.30: the picture of the quick settle stays shown until the new one is made in the background, the new
                # lines hidden under it at once (no flash of raw lines; draw_cache.begin keeps it: _keep_picture)
                self._settling=True;self._keep_picture=True;self._exact_pass=True   # (0.19.41: the groups carried over the wheel drawn again)
                try:self.redraw()
                finally:self._settling=False;self._keep_picture=False;self._exact_pass=False
                if self._inside_plan:
                    x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))   # (review: the tool's preview, as settle_view)
                self.smooth_soon(hide=True)
                self.after(__import__('gpu_display').PREPARE,self.prepare_at_rest)   # 0.19.31: read for the card while the hand rests (0.19.37: ready_for_gestures)
        except tk.TclError:pass
    def cancel_full_settle(self):
        job=self.__dict__.get('_full_job');self._full_job=None
        if job is not None:
            try:self.after_cancel(job)
            except (tk.TclError,ValueError):pass
    def zoom(self,e,f=None):
        if not self.plan_active():return __import__('fiches').scroll(self,e)   # a fiche scrolls
        self.close_stack_choice()   # 0.18.6: the view changes: the list goes (click again on the closer view)
        self.close_grip_menu()   # 0.19.7: « Étirer / Allonger » too (it would stay invisible, still clickable)
        p=self.raw(e);new=__import__('deep_zoom').clamp(self.scale*(f if f else (1.15 if e.delta>0 else 1/1.15)))   # 0.18.5: up to 2 000 px/mm
        if new==self.scale:return
        old=self.scale;k=new/old
        self.cursor_screen=(e.x,e.y);self.view_changed()
        self.cancel_settle();self.cancel_full_settle();self._settle_job=self.after(self.SETTLE,self.settle_wheel)
        c=self.canvas
        import background_ui
        self._zooming=True
        try:
            self.show_raw_view()
            c.itemconfigure(background_ui.TAG,state='hidden')   # Tk does not scale a picture: a lighter one below, at the new scale
            if k<1:   # zooming out: the pieces coming into view (0.19.39: at once; half a screen around the new view a moment
                W,H=c.winfo_width(),c.winfo_height();nox,noy=e.x-p[0]*new,e.y-p[1]*new   # later: extend_soon)
                mx,my=W*self.EXTEND_NOW,H*self.EXTEND_NOW
                box=((-mx-nox)/new,(-my-noy)/new,(W+mx-nox)/new,(H+my-noy)/new);drawn=self.__dict__.get('_drawn_box')
                if not (drawn and drawn[0]<=box[0] and drawn[1]<=box[1] and box[2]<=drawn[2] and box[3]<=drawn[3]):
                    self.extend_drawing(box)   # (never a box drawn already: it took the place of the larger one)
                self.extend_soon()
            self.scale=new;self.ox=e.x-p[0]*new;self.oy=e.y-p[1]*new
            if self.__dict__.get('pan'):self.pan=(e.x,e.y,self.ox,self.oy)   # the wheel while moving the view: the move goes on from here
            if not self.drawn_view():
                self.redraw_wide()   # zoomed out beyond what was drawn: drawn again at once (no smoothing yet)
                if self._inside_plan:self.motion(SimpleNamespace(x=e.x,y=e.y))   # with the tool's preview
                return
            c.scale('all',e.x,e.y,k,k)
            for tag in self.SCREEN_TAGS:c.scale(tag,e.x,e.y,1/k,1/k)   # the cross stays where it is, at its size
            self.zoom_marks(old,new)   # 0.18.3: the texts grow with the drawing, the markers keep their size
            self.draw_scale_bar()
        finally:
            self._zooming=False
            # 0.19.7: the background picture follows each notch (lighter: a third of the resolution), sharp
            # with the full drawing (it was hidden until the wheel stopped).
            # 0.19.31: drawn by the graphics card (Tk draws nothing meanwhile); 0.19.33: the background picture too, Tk's own
            # lighter one only when the card does not draw this notch (review: refused at a notch, or its first one)
            if not __import__('gpu_display').moved(self,('zoom',e.x,e.y,k)) and background_ui.visible(self):background_ui.picture(self,quick=True)
    def pan_start(self,e):
        self.close_stack_choice();self.close_grip_menu()
        if self.cancel_settle():self._settle_pending=True   # 0.18.4: let go a moment ago (or the wheel just turned): the gesture goes on
        self.cursor_screen=(e.x,e.y);super().pan_start(e);self.draw_crosshair()
    def pan_move(self,e):
        self.cursor_screen=(e.x,e.y);shift=None
        if self.pan:
            ox,oy=self.pan[2]+e.x-self.pan[0],self.pan[3]+e.y-self.pan[1];dx,dy=ox-self.ox,oy-self.oy
            if dx or dy:
                # 0.17.0: panning moves what is drawn instead of redrawing 1600 objects at every
                # mouse move. 0.18.4: the smoothed picture moves with it (one picture for Tk to show,
                # not every line); the pieces ahead are drawn as the view comes near them.
                plan=self.plan_active()   # a fiche shown instead of the plan only slides
                self.view_changed()
                if plan and not self.__dict__.get('_pan_moved'):self.keep_picture()   # once per gesture
                self.ox,self.oy=ox,oy;self.canvas.move('all',dx,dy);self.canvas.move('scale_bar',-dx,-dy);self._pan_moved=True
                if plan and not self.drawn_around():self.extend_drawing()
                if plan:shift=(dx,dy)
        self.snap_marker=None;self.draw_crosshair()
        # 0.19.31: drawn by the graphics card; 0.19.33 (review): the background picture too, Tk's own only when it does not draw
        if shift and not __import__('gpu_display').moved(self,('move',*shift)):self.keep_background()
    def pan_end(self,e=None):
        # 0.18.4: the full drawing and its smoothing a moment after the release (SETTLE), not at once:
        # the view taken again meanwhile goes on moving at once; a full drawing asked meanwhile (an
        # action, a key) takes its place (redraw).
        moved=self.__dict__.pop('_pan_moved',False);pending=self.__dict__.pop('_settle_pending',False)
        if moved or pending:
            self.cancel_settle();self._settle_job=self.after(self.PAN_SETTLE,self.settle_pan);self._settle_is_pan=True
    def settle_pan(self):
        """The view was let go a moment ago: the full drawing (smoothed at once) and the tool's
        preview. A click coming first does it through settle_view. 0.19.30 (his lenteurs.txt: 90 to 140 ms): what the move
        left drawn covers the view: only smoothed, in the background (quick_pan); else the full drawing, smoothed in the
        background."""
        self._settle_job=None;self._settle_is_pan=False
        try:
            if not self.canvas.winfo_exists():return
            if self.quick_pan():return
            self._settling=True
            try:self.redraw()
            finally:self._settling=False
            if self._inside_plan and self.plan_active():
                x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))
            self.smooth_soon()
            self.after(__import__('gpu_display').PREPARE,self.prepare_at_rest)   # (review 0.19.37: as full_settle)
        except tk.TclError:pass
        finally:__import__('gpu_display').settled(self)   # 0.19.31
    def quick_pan(self):
        """0.19.30: the view let go, what the move drew covering it: smoothed in the background without drawing again (the
        same lines: moved, the pieces ahead drawn as the view came near them); the full drawing once the mouse rests
        (full_settle: the objects' stacking again). True then."""
        import background_ui
        try:
            if not self.plan_active() or not self.prefs.get('smooth_display',True) or not self.drawn_view() or not self.clip_covers():return False   # (review: a Piqûre cut beyond the view)
            if background_ui.visible(self) or self.translating_ids() or self.grip_drag or self.__dict__.get('pan') or self.__dict__.get('_hold_redraw'):return False
            # (0.19.39 hunt) the wheel's settle taken over by this move (pan_start): quick_settle's checks too (past 80 px/mm,
            # curves cut for the scale drawn shown up to 5 px off their place)
            if not self.quick_zoom_holds(self.__dict__.get('_drawn_scale')):return False
        except tk.TclError:return False
        try:
            self.canvas.dtag('all','pan_under')   # (the lines kept under the moving picture: the plan's again)
            self.restacked()
        except tk.TclError:return False
        if self.__dict__.get('_base_scale')!=self.scale:
            try:self.quick_base()   # (0.19.39 hunt: the base's titles and the grid as the wheel scaled them: drawn again, as quick_settle)
            except tk.TclError:return False
        self._quick_since=True
        if self._inside_plan:
            x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y))   # the tool's preview, as the full drawing does
        self.smooth_soon()
        self.under_picture()
        self.cancel_full_settle();self._full_job=self.after(self.FULL_SETTLE,self.full_settle)
        return True
    UNDER_PICTURE=r'''proc craft_under_picture {c ids bg} {
    set top {}
    foreach i [lreverse $ids] {
        if {[$c type $i] eq ""} continue
        $c lower $i
        if {$top eq ""} {set top $i}
    }
    if {$top ne ""} {catch {$c raise _smooth_display $top}}
    $c lower $bg
}'''
    def under_picture(self):
        """0.19.41 (review: a flash of raw lines when the view is let go): the objects stacked again for the smoothing (restacked)
        and its lines read (smooth_soon), the lines the moving picture kept under it put back there until the new picture comes
        in the background (those crossing its edge are shown: over it, they were drawn raw over their smoothed selves); the
        next drawing stacks them again (restack_all)."""
        c=self.canvas;ids=c.__dict__.pop('_pan_lines',None);job=c.__dict__.get('_soon')
        if not ids or job is None or not c.find_withtag('_smooth_display'):return
        mirror=c.__dict__.get('_gpu_mirror')
        if mirror is not None and getattr(mirror,'state',None) in ('active','settling'):return   # the card's picture covers Tk's until its smoothed one
        import background_ui,display_render
        try:
            if not c.tk.call('info','procs','craft_under_picture'):c.tk.eval(self.UNDER_PICTURE)
            c.tk.call('craft_under_picture',c._w,ids,background_ui.TAG)
            job.read=display_render.read_plan(c)   # (the same lines, in another order: the picture made for the order put back by the next drawing)
        except tk.TclError:return
        c._pan_restack=True
    # 0.18.4: the lines the smoothed picture hides, tagged « pan_under » (until the next full drawing)
    # and put under it; those going beyond it shown again (their part on it stays smoothed); the
    # background picture stays under everything.
    PAN_PROC=r'''proc craft_pan_keep {c ids x0 y0 x1 y1 bg} {
    set kept {}
    foreach i $ids {
        if {[catch {$c coords $i} xy]} continue
        $c addtag pan_under withtag $i
        set inside 1
        foreach {x y} $xy {
            if {$x < $x0 || $x > $x1 || $y < $y0 || $y > $y1} {set inside 0;break}
        }
        if {$inside} {lappend kept $i} else {$c itemconfigure $i -state normal}
    }
    $c lower pan_under
    $c raise _smooth_display pan_under
    $c lower $bg
    return $kept
}'''
    def keep_picture(self):
        """0.18.4: the view starts to move: the smoothed picture stays and moves with the drawing
        (Tk shows one picture instead of every line); the lines it hides that go beyond it are shown
        again, under it; the pieces around the screen are drawn (extend_drawing). Without a picture
        (smoothing off, background picture shown, zoom not settled): the lines, as in 0.18.2."""
        c=self.canvas;ids=c.__dict__.get('_smooth_hidden')
        box=c.bbox('_smooth_display') if ids and not c.__dict__.get('_smooth_stale') else None   # 0.18.7: not a picture waiting to be made again
        if not box:self.show_raw_view();self.extend_drawing();return False
        self.drop_smooth()
        from display_render import cancel_paint
        import background_ui
        cancel_paint(c);x0,y0,x1,y1=box
        try:
            if not c.tk.call('info','procs','craft_pan_keep'):c.tk.eval(self.PAN_PROC)
            # 0.19.24: what is left as it is under the picture (0.19.25: the zones) goes down with the others, in their
            # order (the pieces' lines shown beyond the picture stay over them)
            ids=list(ids)+[i for i in c.__dict__.get('_smooth_under') or () if i not in set(ids)]
            c._smooth_hidden=[int(v) for v in c.tk.splitlist(c.tk.call('craft_pan_keep',c._w,ids,x0+2,y0+2,x1-2,y1-2,background_ui.TAG))]
            c._pan_restack=True   # 0.19.41: the objects stacked again when the view is let go (restacked) or by the next drawing
            c._pan_lines=ids   # (review 0.19.41: put back under the picture after that, until the new one comes: under_picture)
        except tk.TclError:self.show_raw_view();self.extend_drawing();return False
        self.extend_drawing()   # after: its zones and grid go under the picture, as in a full drawing
        return True
    def keep_background(self):
        """0.18.4: while the view moves, the background picture (drawn at the screen's size) is
        drawn again once it covers less than two thirds of what it should cover on the screen."""
        import background_ui
        b=background_ui.current(self)
        if not b or not b.get('visible',True):return
        c=self.canvas;W,H=c.winfo_width(),c.winfo_height()
        x,y,w,h=background_ui.visible_rect(self)   # 0.19.7: the part kept (« Recadrer »)
        x0,y0=self.to_screen((x,y));x1,y1=self.to_screen((x+w,y+h))
        x0,y0,x1,y1=max(0,x0),max(0,y0),min(W,x1),min(H,y1)
        if x1<=x0 or y1<=y0:return
        box=c.bbox(background_ui.TAG) if c.find_withtag(background_ui.TAG) and c.itemcget(background_ui.TAG,'state')!='hidden' else None
        have=max(0,min(x1,box[2])-max(x0,box[0]))*max(0,min(y1,box[3])-max(y0,box[1])) if box else 0
        # 0.19.7: lighter (sharp at the end of the move), the smoothed lines kept sliding over it
        if have<(x1-x0)*(y1-y0)*2/3:background_ui.picture(self,quick=True,keep_smooth=True);background_ui.overlay(self)   # (0.19.33: not while the card draws it: pan_move)
    def expand_dimension_selection(self,before=()):
        """0.16.26: selecting any part of a dimension selects the whole dimension;
        removing a part (Maj+clic) removes the whole dimension."""
        from entity_rules import dimension_members
        items=self.items;current={i for i in self.selected_set if i<len(items)}
        dropped={items[i].get('dimension_group') for i in set(before)-current if i<len(items)};dropped.discard(None)
        if dropped:current={i for i in current if items[i].get('dimension_group') not in dropped}
        full=dimension_members(items,current)
        if full==self.selected_set:return
        self.selected_set=full
        if self.selected not in full:self.selected=min(full) if full else None
        self.refresh()
    def deformation_grips(self,s):
        if s.get('dimension_group'):return []
        from native_edit import circular_grips
        arcs=circular_grips(s) if s.get('kind')!='circle' else []
        # 0.17.0: every vertex between straight sides has its own grip, also on polylines with
        # arcs, crans or made with Joindre (a side can be stretched alone).
        if arcs:return arcs+self.vertex_grips(s)+self.side_grips(s)+(self.rect_side_grips(s) if s['kind']=='rect' else [])
        if s.get('annotation') or s.get('drill') or s.get('spline'):return []
        if s.get('components'):return self.vertex_grips(s)+self.side_grips(s)
        if s.get('ellipse') and s.get('closed'):
            return [(('ellipse_axis',k),ellipse_point(s,k*math.pi/2)) for k in range(4)]
        if s['kind']=='circle':
            # 0.18.5: plus its centre, which moves the circle (and, in a multiple selection, the whole selection).
            c=(s['x']+s['w']/2,s['y']+s['h']/2);return [('move',c)]+[(('circle_axis',k),(c[0]+s['w']/2*math.cos(k*math.pi/2),c[1]+s['w']/2*math.sin(k*math.pi/2))) for k in range(4)]
        if s['kind']=='rect':
            if s.get('notches') or s.get('r'):return []
            # 0.16.23: a rectangle corner resizes the whole rectangle (opposite corner fixed).
            pts=self.rect_corners(s);return self.rect_side_grips(s)+[(('corner',j),pt) for j,pt in enumerate(pts)]
        if s.get('closed') and not s.get('notches') and not any(s.get('bulges') or []) and self.axis_rectangle(s):
            # a rectangle drawn as a polyline: its sides as a rectangle's (a side may cross the other one: 0.16.23)
            pts=path(s)[0];return [(('edge',j),((a[0]+b[0])/2,(a[1]+b[1])/2)) for j,(a,b) in enumerate(zip(pts,pts[1:]+pts[:1]))]+self.vertex_grips(s)
        # 0.19.22: every polyline (piece, open or not): a grip in the middle of each straight side (side_grips)
        return self.vertex_grips(s)+self.side_grips(s)
    def axis_rectangle(self,s):
        try:pts,closed=path(s)
        except (ValueError,KeyError,TypeError):return False
        return closed and len(pts)==4 and len({round(p[0],7) for p in pts})==2 and len({round(p[1],7) for p in pts})==2
    def rect_corners(self,s):
        x,y,w,h=s['x'],s['y'],s['w'],s['h'];return [(x,y),(x+w,y),(x+w,y+h),(x,y+h)]
    def rect_side_grips(self,s):
        """The middles of a rectangle's sides (0.19.22: a rounded one too: its rounds kept)."""
        pts=self.rect_corners(s)
        return [(('edge',j),((a[0]+b[0])/2,(a[1]+b[1])/2)) for j,(a,b) in enumerate(zip(pts,pts[1:]+pts[:1])) if math.dist(a,b)>1e-9]
    def side_grips(self,s):
        """0.19.22 (« milieux ne s'affichent pas », OUI le 12/11/2026, comme AutoCAD): a grip in the middle of each
        straight side of a polyline (a piece with rounds and curves too): held, the side moves across itself
        (move_side, advanced_edit.side_moved). (0.19.9: none on a side of zero length: its corner's grip is taken.)
        Straight sides in line (a point left between them: Mozart, Couper) are one side: one grip, in its middle."""
        from advanced_edit import side_elements
        q=self.as_polyline(s)
        if q is None:return []
        return [(('side',e['segs'][0]),((e['a'][0]+e['b'][0])/2,(e['a'][1]+e['b'][1])/2)) for e in side_elements(q) if e['kind']=='line']
    def side_ends(self,g):
        """The two ends of the side held by a « Milieu du côté » grip, as it was."""
        mode=g['mode'];s=g['original'];k=mode[1]
        if mode[0]=='side':
            if 'side_run' in g:return g['side_run']
            from advanced_edit import side_elements
            q=g.get('polyline') or self.as_polyline(s)
            if q is None:return None
            g['polyline']=q;run=next(((e['a'],e['b']) for e in side_elements(q) if e['kind']=='line' and k in e['segs']),None)
            g['side_run']=run;return run
        else:V=self.rect_corners(s) if s.get('kind')=='rect' else path(s)[0]
        if not 0<=k<len(V):return None
        return V[k],V[(k+1)%len(V)]
    def move_side(self,e):
        """0.19.22: the side held moves across itself (its middle follows the mouse across it, or a distance typed)."""
        from advanced_edit import side_moved
        g=self.grip_drag;p=self.point(e)
        if not g['changed'] and math.dist(p,g['anchor'])<.1/self.scale:self.draw_crosshair();return   # put back where taken: no Annuler step
        ends=self.side_ends(g)
        if ends is None:return
        (a,b),base=ends,g['polyline'];L=math.dist(a,b)
        if L<1e-9:return
        n=(-(b[1]-a[1])/L,(b[0]-a[0])/L);d=(p[0]-g['anchor'][0])*n[0]+(p[1]-g['anchor'][1])*n[1]
        try:
            arcs=[];q,moved=side_moved(base,g['mode'][1],d,arcs);validate([q])
        except ValueError as exc:self.invalid_at(e,str(exc));return
        if not g['changed']:self.snapshot();g['changed']=True
        self.items[g['index']]=q;self.reattach_crans(g,q,moved,arcs);self.refresh();self.draw_crosshair()
    def as_polyline(self,s):
        """The shape as ONE polyline with bulges (Joindre compounds of lines and arcs included),
        or None (cran, text, dimension, spline, ellipse, rectangle…)."""
        if s.get('annotation') or s.get('drill') or s.get('is_notch') or s.get('dimension_group') or s.get('filled') or s.get('spline') or s.get('ellipse'):return None
        if s.get('components'):
            from editing import chain_polyline
            from curves import parts
            return chain_polyline(parts(s),s,bool(s.get('closed')))
        if s.get('kind')!='poly' or s.get('notches'):return None
        from precision_geometry import without_micro
        return without_micro(s)
    def vertex_grips(self,s):
        q=self.as_polyline(s)
        if q is None:return []
        V=[(q['x']+x,q['y']+y) for x,y in q['points']];n=len(V);closed=bool(q.get('closed'));B=(list(q.get('bulges') or [])+[0]*n)[:n]
        out=[]
        for k in range(n):
            before=B[k-1] if k>0 or closed else 0;after=B[k] if k<n-1 or closed else 0
            if not before and not after:out.append((('pvertex',k),V[k]))
        return out
    def move_vertex(self,e):
        """0.17.0: a vertex grip moves that point only; the sides reaching it stretch, the crans on
        them keep their distance from the other end of their side. An open end brought onto the
        other end closes the polyline."""
        from cad import polygon
        g=self.grip_drag;k=g['mode'][1];p=self.point(e)
        if not g['changed'] and math.dist(p,g['anchor'])<.1/self.scale:self.draw_crosshair();return   # 0.19.9: put back where taken: no Annuler step
        base=g.get('polyline') or self.as_polyline(g['original'])
        if base is None:return
        g['polyline']=base
        V=[(base['x']+x,base['y']+y) for x,y in base['points']];n=len(V);closed=bool(base.get('closed'));old=V[k];V[k]=p
        B=(list(base.get('bulges') or [])+[0]*n)[:n]
        if any(math.dist(V[k],V[m])<1e-6 for m in ((k-1)%n,(k+1)%n) if closed or abs(m-k)==1):return
        hot={(k-1)%n,k} if closed else {m for m in (k-1,k) if 0<=m<n-1}   # the two sides that reach it
        if not closed and n>2 and k in (0,n-1) and math.dist(V[0],V[-1])<=.02:
            if k==0:V=V[1:];B=B[1:n-1]+[B[0]]   # the first side becomes the closing side
            else:V=V[:-1];B=B[:n-1]
            closed=True;hot=None
        q=polygon(V,base['name'],closed);q.update({key:copy.deepcopy(v) for key,v in base.items() if key not in ('kind','x','y','w','h','r','points','closed','name','bulges')})
        if any(B):q['bulges']=B if closed else B[:len(V)-1]+[0]
        # 0.19.49 (« poignée de coin qui croise le contour ») never across the contour where it did not cross (as a side's grip)
        if __import__('geometry').newly_crossed(base,q,hot):self.invalid_at(e,'Le contour se croise.');return
        if not g['changed']:self.snapshot();g['changed']=True
        self.items[g['index']]=q;self.reattach_crans(g,q,(old,p));self.refresh();self.draw_crosshair()
    def grip_done(self,g):
        """0.19.22: a piece reshaped by a grip: the Piqûres made round it follow it (stitching.refit). 0.19.40 (review): the
        point several selected pieces share (start_joint_grip): every one of them (only the first one's followed)."""
        i=g.get('index');old=g.get('original')
        found=[(j,s) for j,_mode,_at,_fixed,s in g['joint']] if g.get('joint') else [(i,old)]
        pairs={carrier(s):(s,self.items[j]) for j,s in found if isinstance(j,int) and j<len(self.items) and s and carrier(s)}
        if pairs:self.refit_stitches(pairs)
    def refit_stitches(self,pieces,before=None):
        """``pieces``: piece id → (the piece as it was, as it is now): their Piqûres round them made again, at their
        distance from the edge (``before``: index → a Piqûre as it was, when it changed with its piece: Échelle).
        (In the same Annuler step as the change: called once it is made.)"""
        from entity_rules import closed_piece
        import stitching
        def refit(was,old,now):
            try:return stitching.refit(was,old,now)
            except stitching.Lost as exc:lost.append(exc.distance);return False
        n=0;lost=[]
        for j,s in enumerate(self.items):
            pair=pieces.get(s.get('owner_id')) if s.get('stitch') and s.get('owner_id') else None
            # (bug hunt 0.19.49) a précoupe's id: several pieces (the pieces inside it first), each Piqûre round the one it was round
            for old,now in (pair if isinstance(pair,list) else [pair] if pair else ()):
                if not closed_piece(now):continue
                was=(before or {}).get(j,s)
                # (review 0.19.49) a précoupe's own side moved: a Piqûre round a piece inside it stays round that piece (it was
                # made round the précoupe, 0,5 mm outside the piece after a side moved 3 mm)
                if __import__('surcoupe').is_precut(old) and any(stitching.refit(was,q,q) is not None for q in self.items
                        if q.get('owner_id')==s.get('owner_id') and (q.get('style') or {}).get('role')=='surcoupe' and closed_piece(q)):break
                q=refit(was,old,now)
                if q is False:break   # 0.19.49: it was round it, it cannot be made again round it: left, said below
                if q is not None:self.items[j]=q;n+=1;break
        if lost:self.say_lost_stitches(lost)
        return n+__import__('teinte_ui').refit(self,pieces,before)   # 0.19.39: the bands of « Teinte des bords » follow too
    def say_lost_stitches(self,lost):
        """(0.19.49, « une piqûre qui ne peut plus suivre sa pièce : le dire ») A Piqûre round a piece changed (a grip, a
        raccord, Échelle, Étirer, F4…) that cannot be made again at its distance from the edge of the piece as it is now
        (left where it was; with Échelle, turned and scaled with it): said in the status line once the tool has said its
        own words (after: its message would cover it) and kept in the last commands."""
        def number(d):return f'{d:.2f}'.rstrip('0').rstrip('.').replace('.',',')
        far={number(d) for d in lost}
        at=f'à {next(iter(far))} mm du bord' if len(far)==1 else 'à leur distance du bord'
        text=(f'Piqûre à refaire : elle ne tient plus {at} de la pièce modifiée.' if len(lost)==1 else
              f'{len(lost)} piqûres à refaire : elles ne tiennent plus {at} de la pièce modifiée.')
        def say():
            try:self.status.set(text)
            except tk.TclError:return
            # (review R4) the last commands shown: log_status wrote it (« Commande : … »), after the tool's line; else kept here
            # (written at once before: twice, and above the tool's own line)
            history=self.__dict__.get('history')
            if history is None or not history.winfo_exists():self.note_history(text)
        try:self.after(0,say)   # a timer: after the tool's own message (never run by an update_idletasks)
        except tk.TclError:self.note_history(text)
    def replace_items(self,indices,new,command):
        """0.19.22: a raccord (Arrondi, Chanfrein…) on a piece: its Piqûres follow."""
        import surcoupe
        mark=lambda s:(carrier(s),bool(surcoupe.is_precut(s)))   # (review) a précoupe and the piece inside it share one id
        old={mark(self.items[i]):self.items[i] for i in indices if i<len(self.items) and carrier(self.items[i])}
        held=self.__dict__.get('_refresh_held');self._refresh_held=True
        try:result=super().replace_items(indices,new,command)
        finally:self._refresh_held=held
        if old and result is not False:   # (review) nothing changed: nothing follows (the last objects were taken for the new ones)
            # (bug hunt 0.19.49) a piece inside its précoupe (its marks are the précoupe's): the piece made again, the last ones
            # (review: only those; a piece inside its précoupe decomposed paired with the précoupe: its marks went onto it)
            now={mark(s):s for s in self.items[len(self.items)-len(new):] if mark(s) in old and not s.get('is_notch')} if new else {}
            pairs={}
            for k in sorted(now,key=lambda k:k[1]):pairs.setdefault(k[0],[]).append((old[k],now[k]))   # the piece inside first
            self.refit_stitches(pairs);self.reseat_crans({k:v[0] for k,v in pairs.items()})
        # (hunt 0.19.49, fluidity) the plan drawn once, its Piqûres, teintes and crans followed (two or three times before;
        # commit_corner, which draws it at its end, holds it)
        if not held:self.refresh()
        return result
    def reseat_crans(self,pieces):
        """(bug hunt 0.19.39) piece id → (the piece as it was, as it is now) after a raccord (Arrondi, Chanfrein, Angle droit,
        Bout rond / pointu…): a cran that stood on the piece as it was and is no longer on it (on the corner rounded, on the
        part of a side taken by the round) goes to the nearest point of the new contour, as a grip puts it back on the piece
        (reattach_crans); the others stay as they are. In the same Annuler step (called once the change is made)."""
        from craft_tools import cran_mark,rebuilt_cran,locate
        from entity_rules import closed_piece
        n=0
        for j,c in enumerate(self.items):
            pair=pieces.get(c.get('owner_id')) if c.get('is_notch') and c.get('owner_id') else None
            if not pair or not closed_piece(pair[0]) or not closed_piece(pair[1]):continue
            was,now=pair
            if cran_mark(c,now) is not None:continue   # still on the piece
            mark=cran_mark(c,was)
            if mark is None:continue   # not on the piece before either (a précoupe's cran on its inner contour…)
            try:self.items[j]=rebuilt_cran(c,now,dict(mark,distance=locate(now,at_mark(was,mark))[0]));n+=1
            except (ValueError,KeyError,ZeroDivisionError,TypeError):pass
        return n
    def reattach_crans(self,g,host,moved=None,arcs=()):
        """The crans of a reshaped piece stay on it: those on a straight side reaching the moved
        point keep their distance from the other end of that side, the others the closest point.
        0.19.9: ``moved`` is (old, new) of the point moved, or a list of them (a corner or a side of a
        rectangle moves several points): a side whose two ends move keeps the distance from the end that
        moves least (a side moved parallel to itself takes its crans along). Where each cran sits on the
        piece as it was, and the straight sides through it, are worked out once per grip drag (kept in
        ``g``), no longer again at each move of the mouse. 0.19.22: ``arcs``, ((centre, radius, start, sweep) as it
        was, as it is) of the arcs remade (side_moved): a cran on one keeps its place along it (the closest point
        slid along a round moved)."""
        from craft_tools import cran_mark,rebuilt_cran,locate
        from geometry import distance
        original=g['original'];owner=original.get('piece_id') or original.get('owner_id')   # 0.19.39: a précoupe's piece to recut: its crans are the précoupe's (those on it are found below)
        if not owner:return
        if 'crans' not in g:
            g['crans']={j:copy.deepcopy(c) for j,c in enumerate(self.items) if c.get('is_notch') and c.get('owner_id')==owner}
            linked=g.setdefault('linked',{})
            for j,c in g['crans'].items():linked.setdefault(j,copy.deepcopy(c))   # Échap puts them back
        if 'cran_feet' not in g:   # 0.19.9: once per drag (the piece as it was does not change)
            feet={}
            for j,cran in g['crans'].items():
                mark=cran_mark(cran,original)
                if mark is not None:feet[j]=(mark,at_mark(original,mark))
            g['cran_feet']=feet
        moves=moved if isinstance(moved,list) else [moved] if moved else []
        if moves and 'cran_sides' not in g:
            edges=[(e['a'],e['b']) for e in primitives_of(original) if not e['sweep']]
            g['cran_sides']={j:[(a,b) for a,b in edges if distance(foot,a,b)<=1e-6] for j,(_,foot) in g['cran_feet'].items()}
        for j,(mark,foot) in g['cran_feet'].items():
            if j>=len(self.items):continue
            target=None
            def along(c,a,s,p):
                """How far round the arc (centre c, from a, sweep s) p is, as a part of it (0 at a, 1 at its end)."""
                v,w=(a[0]-c[0],a[1]-c[1]),(p[0]-c[0],p[1]-c[1]);turn=math.atan2(v[0]*w[1]-v[1]*w[0],v[0]*w[0]+v[1]*w[1])
                if s>0 and turn<-1e-9:turn+=2*math.pi
                elif s<0 and turn>1e-9:turn-=2*math.pi
                return turn/s if s else -1
            for (c0,r0,a0,s0),(c1,r1,a1,s1) in arcs:
                if abs(math.dist(foot,c0)-r0)>.02:continue   # (the foot is found on the arc cut in small chords)
                f=along(c0,a0,s0,foot)
                if not -1e-9<=f<=1+1e-9:continue
                a=math.atan2(a1[1]-c1[1],a1[0]-c1[0])
                if math.dist(c0,c1)<1e-6 and abs(r0-r1)<1e-6:
                    # 0.19.23: the curve keeps its circle (one end slid on it): the cran stays where it is, at the end that
                    # went past it if one did
                    g1=along(c1,a1,s1,foot)   # (0 to 1 on the arc now; beyond: past its end, or before its start)
                    if g1>1:g1=1. if (g1-1)*abs(s1)<=2*math.pi-g1*abs(s1) else 0.
                    angle=a+max(0.,g1)*s1
                else:angle=a+f*s1   # a round remade, a curve turned or scaled: the same place along it
                target=(c1[0]+r1*math.cos(angle),c1[1]+r1*math.sin(angle));break
            sides=g['cran_sides'][j] if moves and target is None else ()
            if target is None:target=foot
            for a,b in sides:
                na=next((q for o,q in moves if math.dist(a,o)<1e-6),None);nb=next((q for o,q in moves if math.dist(b,o)<1e-6),None)
                if na is None and nb is None:continue
                if nb is not None and (na is None or len(moves)==1):base,start,end=a,a,nb   # the distance from the end that stays
                elif nb is None:base,start,end=b,b,na
                else:base,start,end=(a,na,nb) if math.dist(a,na)<=math.dist(b,nb) else (b,nb,na)
                reach=math.dist(start,end)
                if reach>1e-9:t=min(math.dist(base,foot),reach)/reach;target=(start[0]+(end[0]-start[0])*t,start[1]+(end[1]-start[1])*t)
                break
            try:self.items[j]=rebuilt_cran(g['crans'][j],host,dict(mark,distance=locate(host,target)[0]))   # same measure as the crans
            except (ValueError,KeyError,ZeroDivisionError,TypeError):pass
    def hit_grip(self,p):
        if not self.grips_shown():return None   # 0.19.0: more than GRIP_LIMIT objects selected: no grip to take, in any layer
        pick=self.__dict__.get('_grip_pick')
        if pick and not self.__dict__.get('_grip_exact'):
            import anchor_stack
            entry=anchor_stack.chosen(self.grip_stack(p),pick)
            if entry:
                pt,_,i=entry;ids=self.selected_set;old=self.selected
                self._grip_exact=True;self.selected_set={i};self.selected=i
                try:return self.hit_grip(pt)
                finally:self._grip_exact=False;self.selected_set=ids;self.selected=old
        hits=[(math.dist(pt,p),i,mode,pt) for i in self.selected_ids() for mode,pt in self.deformation_grips(self.items[i]) if math.dist(pt,p)<=7/self.scale]
        if hits:
            # 0.19.23: at the same place, a side's grip before a point's (a point left in the middle of a side: Couper,
            # Fermer les écarts)
            near=min(h[0] for h in hits)
            _,i,mode,pt=min((h for h in hits if h[0]<=near+1e-6),key=lambda h:(0 if isinstance(h[2],tuple) and h[2][0] in ('side','edge') else 1,h[0]))
            return i,mode,pt,pt
        # 0.16.26: the parts of a dimension have no grips; the dimension moves as one object.
        # 0.16.30: texts and crans neither: they are moved by dragging them.
        dims={i for i in self.selected_ids() if self.items[i].get('dimension_group') or self.items[i].get('annotation') or self.items[i].get('is_notch')}
        if not dims:return super().hit_grip(p)
        ids=self.selected_set;old=self.selected
        try:
            self.selected_set=set(self.selected_ids())-dims
            if old in dims:self.selected=None
            return super().hit_grip(p)
        finally:self.selected_set=ids;self.selected=old
    # 0.16.19: dragging a grip shows the Déplacer marks (cross on the start point, dotted guide,
    # distance beside it); a typed value is written there and Entrée applies it along the mouse.
    def grip_typed_value(self):
        text=self.command_value.get().strip() if self.grip_drag else ''
        if not text:return None
        try:
            value=self.parse_length(text);return value if value>0 else None
        except ValueError:return None
    def point(self,e):
        forced=self.__dict__.get('_forced_point')
        if forced is not None:self.snap_marker=None;return forced
        p=super().point(e);g=self.grip_drag;value=self.grip_typed_value()
        if g is not None:
            held=self.on_end_axis(g,p,e)
            if held is not None:return held
        if g is None or value is None:
            if tracking.active(self):
                # 0.17.0 Repérage: held on the vertical / horizontal of a kept anchor point.
                a=self.constraint_origin() if self.ortho.get() else None
                locked='y' if a and abs(p[1]-a[1])<1e-9 and abs(p[0]-a[0])>1e-9 else 'x' if a and abs(p[0]-a[0])<1e-9 and abs(p[1]-a[1])>1e-9 else None
                q=tracking.align(self,p,self.snap_marker[1] if self.snap_marker else None,locked)
                if q!=p and self.snap_marker and self.snap_marker[1] in tracking.SOFT:self.snap_marker=None;self.anchor_candidate=None   # 0.19.13: held by the dotted line
                p=q
            return p
        q=self.grip_cursor_point();a=g['anchor'];n=math.dist(q,a)
        if n<1e-9:return p
        target=(a[0]+(q[0]-a[0])/n*value,a[1]+(q[1]-a[1])/n*value);g['pointer']=target;self.snap_marker=None;return target
    def end_axis(self,g):
        """0.19.7 « quand je veux allonger une ligne diagonale, avoir un axe aimanté légèrement »: (fixed end,
        end held, outward unit direction) when the grip held is an end of a line, or the end of an open
        polyline whose last side is straight; None otherwise."""
        mode=g['mode'];s=g['original']
        if mode=='endpoint' and s['kind']=='line':F,A=g['fixed'],g['anchor']
        elif isinstance(mode,tuple) and mode[0]=='pvertex':
            base=g.get('polyline') or self.as_polyline(s)
            if base is None or base.get('closed'):return None
            V=[(base['x']+x,base['y']+y) for x,y in base['points']];n=len(V);k=mode[1];B=(list(base.get('bulges') or [])+[0]*n)[:n]
            if n<2 or k not in (0,n-1) or (k==0 and B[0]) or (k==n-1 and B[n-2]):return None
            F,A=(V[1],V[0]) if k==0 else (V[n-2],V[n-1])
        else:return None
        L=math.dist(F,A)
        return (F,A,((A[0]-F[0])/L,(A[1]-F[1])/L)) if L>1e-9 else None
    def grip_added_length(self):
        """0.19.7 « Allonger »: the length typed, added to the line (minus: shortened)."""
        text=self.command_value.get().strip() if self.grip_drag else ''
        if not text:return None
        try:return self.parse_length(text)
        except ValueError:return None
    def on_end_axis(self,g,p,e):
        """0.19.7: the end held on its line's own axis: always with « Allonger » (a length typed: added), else
        when the mouse passes within 8 px of it (a light magnet, like an anchor; an anchor found wins)."""
        axis=self.end_axis(g)
        if axis is None:g['on_axis']=False;return None
        F,A,u=axis
        def on(q):
            d=(q[0]-F[0])*u[0]+(q[1]-F[1])*u[1];return (F[0]+u[0]*d,F[1]+u[1]*d),d
        if g.get('lengthen'):
            added=self.grip_added_length()
            target,d=on((A[0]+u[0]*added,A[1]+u[1]*added)) if added is not None else on(p)
            if d<=1e-3:target=A   # never through its other end
            g['on_axis']=True;g['pointer']=target;self.snap_marker=None;return target
        marker=self.snap_marker
        if self.grip_typed_value() is not None or marker and marker[1] not in ('nearest','guides'):g['on_axis']=False;return None
        raw=self.raw(e);q,d=on(raw)
        if d>1e-3 and math.dist(raw,q)*self.scale<=8:
            g['on_axis']=True;g['pointer']=q;self.snap_marker=None;return q
        g['on_axis']=False;return None
    def grip_label_position(self):
        A=self.to_screen(self.grip_drag['anchor']);B=self.to_screen(self.grip_cursor_point());n=math.dist(A,B)
        nx,ny=((A[1]-B[1])/n,(B[0]-A[0])/n) if n>1e-9 else (0,-1)
        if ny>0:nx,ny=-nx,-ny
        return ((A[0]+B[0])/2+nx*14,(A[1]+B[1])/2+ny*14)
    def draw_crosshair(self):
        if hasattr(self,'canvas') and not self.plan_active():
            for tag in ('crosshair','tool_cursor','step_hint','anchor_hint','hover','live_value'):self.canvas.delete(tag)
            self.pointer_cursor('arrow');return
        super().draw_crosshair()
        if hasattr(self,'canvas') and self.__dict__.get('_grip_pick') and self.tool.get()=='select' and not self.grip_drag and self._inside_plan:
            # 0.18.5: the grip Tab has chosen among those stacked under the pointer.
            import anchor_stack
            x,y=self.cursor_screen;st=self.grip_stack(self.raw(SimpleNamespace(x=x,y=y)));entry=anchor_stack.chosen(st,self._grip_pick)
            if entry:
                gx,gy=self.to_screen(entry[0]);color=self.prefs.get('anchor_color','#efcf4b')
                self.canvas.create_line(gx-7,gy-7,gx+7,gy-7,gx+7,gy+7,gx-7,gy+7,gx-7,gy-7,fill=color,width=1.4,tags='anchor_hint')
                self.canvas.create_text(gx+12,gy-12,text=anchor_stack.label_of(st,self.items,entry,True)+' · Tab',anchor='sw',fill=color,font=('Segoe UI',-11),tags='anchor_hint')
            else:self._grip_pick=None   # the pointer left that stack: the choice is forgotten (no search at each move)
        if hasattr(self,'canvas') and self.plan_active():
            self.draw_live_value()
            if self.__dict__.get('_bubble_at') is not None or self.canvas.find_withtag('live_value'):self.keep_hint_clear()
        if not self.grip_drag or not hasattr(self,'canvas'):return
        # Classic arrow while a grip is held: no crosshair, no tool icon.
        self.canvas.delete('crosshair');self.canvas.delete('tool_cursor');self.canvas.delete('step_hint');self.pointer_cursor('arrow')
        a=self.grip_drag['anchor'];ax,ay=self.to_screen(a)
        for sign in (-1,1):self.canvas.create_line(ax-5,ay-sign*5,ax+5,ay+sign*5,fill=self.p['ink'],width=1.4,tags='grip_guide')
        text=self.command_value.get().strip();x,y=self.grip_label_position();g=self.grip_drag
        label=self.format_length(round(math.dist(a,self.grip_cursor_point()),1)).replace('.',',')   # 0.19.40 (review): a comma, as the live values
        axis=self.end_axis(g) if g.get('on_axis') or g.get('lengthen') else None
        if axis:
            # 0.19.7: on the line's axis: the axis dotted beyond the end, the length added (« + », or « − »)
            F,A,u=axis;P=self.grip_cursor_point();delta=(P[0]-F[0])*u[0]+(P[1]-F[1])*u[1]-math.dist(F,A)
            label=('+' if delta>=0 else '−')+self.format_length(round(abs(delta),1)).replace('.',',')
            sx,sy=self.to_screen(P);fx,fy=self.to_screen(F);n=math.hypot(sx-fx,sy-fy) or 1
            self.canvas.create_line(fx,fy,sx+(sx-fx)/n*60,sy+(sy-fy)/n*60,fill=self.prefs.get('anchor_color','#efcf4b'),tags='grip_guide',**self.guide_style())
        self.canvas.create_text(x,y,text=text or label,fill=self.p['ink'],font=('Segoe UI',10),tags='grip_guide')
        if text:self.draw_input_bubble()
    def draw_input_bubble(self):
        result=self.input_bubble_chain()
        # 0.18.5 (n° 13 B): a value being typed is always shown beside the crosshair, also before any
        # first point (Pointés et mèches, Repérage, rectangle sized first…).
        if 'command_entry' in self.__dict__ and self.command_value.get().strip() and self.__dict__.get('_bubble_at') is None and self.plan_active() and not self.searching():
            x,y=self.crosshair_screen();self._bubble_placeholder='';self.place_value_bubble(x+16,y+16)
        return result
    def searching(self):
        frame=self.__dict__.get('search_frame')
        try:return frame is not None and bool(frame.winfo_manager())
        except tk.TclError:return False
    def input_bubble_chain(self):
        text=self.command_value.get().strip();st=self.offset_state;ref=self.__dict__.get('rect_reference')
        if (st is not None and st.get('asking') or ref is not None and ref.get('asking')) and 'command_entry' in self.__dict__:
            x,y=self.cursor_screen;self.place_value_bubble(x+16,y+16);return
        xf=self.__dict__.get('xform')
        if xf and xf['phase']=='value' and 'command_entry' in self.__dict__:
            if text:x,y=self.cursor_screen;self._bubble_placeholder='';self.place_value_bubble(x+16,y+16)
            else:self.command_entry.place_forget()
            return
        if self.grip_drag and text and hasattr(self,'command_entry'):
            x,y=self.grip_label_position();self.place_value_bubble(x,y,center=True);return
        if self.tool.get()=='surcoupe' and self.__dict__.get('surcoupe_state') is not None and 'command_entry' in self.__dict__:
            # 0.18.1: the piece of the précoupe chosen by its ID unique number.
            if text:x,y=self.cursor_screen;self._bubble_placeholder='';self.place_value_bubble(x+16,y+16)
            else:self.command_entry.place_forget()
            return
        return super().draw_input_bubble()
    def key_input(self,e):
        __import__('gpu_display').keyed(self,e)   # 0.19.31: a key: Tk's own drawing at once (0.19.33: a distance typed for Déplacer: the card's)
        self.settle_view()
        if self.__dict__.get('_stack_choice') and getattr(e,'char','') and e.char.isprintable() and e.char not in ' \t':
            self.choose_stack(None)   # 0.18.6: a value typed while the list shows: the closest point, then the value
        st=self.__dict__.get('xform')
        if st and st['phase']=='value' and not e.state&4 and self.focus_get() is self.canvas and e.char and e.char in '0123456789.,-(':
            self.command_entry.insert('end',e.char);self.draw_input_bubble();self.command_entry.focus_set();return 'break'
        # 0.19.9: Allonger takes a minus too (« -5 » shortens; it was dropped and the end lengthened by 5).
        if self.grip_drag and not e.state&4 and self.focus_get() is self.canvas and e.char and e.char in '0123456789.,('+('-+' if self.grip_drag.get('lengthen') else ''):
            self.command_entry.insert('end',e.char);self.draw_input_bubble();self.command_entry.focus_set();return 'break'
        if self.tool.get()=='surcoupe' and self.__dict__.get('surcoupe_state') is not None and not e.state&4 and self.focus_get() is self.canvas and e.char and e.char in '0123456789':
            self.command_entry.insert('end',e.char);self.draw_input_bubble();self.command_entry.focus_set();return 'break'
        return super().key_input(e)
    def command_preview(self):
        super().command_preview()
        if self.grip_drag:
            x,y=self.cursor_screen;self.move_grip(SimpleNamespace(x=x,y=y,state=0))
    def snapshot(self):
        if not self.licence_complet():raise __import__('licence_ui').LectureSeule()   # 0.19.16: before anything changes
        __import__('export_check').clear_marks(self)   # the pieces marked by the export check have changed
        __import__('geometry').forget_boxes()   # 0.19.9: the drawing is about to change
        __import__('cad')._PRIMITIVES.clear()   # (full review 0.19.50, reviewer D) the snaps' parts kept by object: one moved in place (Déplacer of several) kept its old place
        return super().snapshot()
    def regen(self):
        """0.18.5 « regen » / « re » (like AutoCAD): after a hitch, everything is let go: the command in
        progress is left like Échap (back to the Sélection), nothing stays selected, the typed value is
        emptied, every temporary mark is erased, then the plan is drawn again in full and smoothed. The
        drawing and the Annuler history are not touched."""
        self.close_stack_choice()
        if self.__dict__.get('_action') is not None:self.finish_action()
        if self.grip_drag:self.cancel()   # a grip half moved goes back, like Échap
        self.grip_drag=None;self.box_start=None;self._contour_drag=None;self.forget_stack_picks()
        try:self.end_grip_input()
        except Exception:pass
        self.cancel();self.selected=None;self.selected_set=set();self.command_value.set('')
        try:self.command_entry.place_forget()
        except (AttributeError,tk.TclError):pass
        tracking.reset(self);self.cancel_settle();self._hover_key=None;self.__dict__.pop('_box_tint',None)
        c=self.canvas
        for tag in ('hover','edit_preview','selection_box','copy_selection','mirror_selection','cran_copy','xform','tracking','preview','anchor_hint',
                    'input_bubble','object_anchors','tool_cursor','trim_path','ruler_value','live_value','value_bubble'):c.delete(tag)
        forget_zoom_marks(c);self.refresh();self.status.set('Régénéré.')
    SPACE_WAIT=450   # ms (0.19.42): Espace after a value typed waits this long for its unit (« 5 cm »)
    UNIT_KEYS=frozenset('cmCM')
    WAITING_KEYS=frozenset({'Shift_L','Shift_R','Control_L','Control_R','Alt_L','Alt_R','Caps_Lock','ISO_Level3_Shift'})
    def space_command(self,e=None):
        """0.19.42 (« 5 cm » avec un espace accepté partout, GO 18/11/2026): Espace after a value typed in the box by the
        mouse gives it a moment later: « c » or « m » goes on with the value (« 5 cm », then Espace or Entrée), BackSpace
        takes the space back; any other key, a click, Échap or the moment past: the value as Espace gave it at once before
        (0.16.31: Espace = Entrée). A second Espace: the value, then Espace again (a polyline finished, as before)."""
        import re
        entry=self.__dict__.get('command_entry')
        if entry is not None and self.focus_get() is entry and self.__dict__.get('_space_wait') is None:
            text=self.command_value.get()
            # (review: « 10x7 » as « 10;7 »: its x is no command name; « 10x7 », Espace, « cm » made 10 × 7 mm at once)
            sizes=re.sub(r'(?<=[\d)])\s*[xX]\s*(?=[\d(])',';',text)
            if re.search(r'[\d)]\s+$',text) and not re.search(r'[^\W\d_]',sizes) and self.tool.get() not in ('rotate','scale'):   # (review: degrees, a factor: no unit)
                self._space_wait=(self.after(self.SPACE_WAIT,self.space_settle),text,tuple(self.cursor_screen))
                return 'break'
        self.space_settle()
        return super().space_command(e)
    def space_settle(self):
        """The wait of Espace over: the value given now (as Espace gave it), unless it changed since (a click took it)."""
        wait=self.__dict__.pop('_space_wait',None)
        if wait is None:return False
        try:self.after_cancel(wait[0])
        except (ValueError,tk.TclError):pass
        if self.command_value.get()!=wait[1]:return False
        self.enter_dimension(None)
        return True
    def space_key(self,e):
        """A key in the value box while Espace waits (the box's own Entrée, Échap, Tab come before: Entrée gives the value,
        Échap gives it first)."""
        wait=self.__dict__.get('_space_wait')
        if wait is None or e.keysym in self.WAITING_KEYS:return None
        if (e.char and e.char in self.UNIT_KEYS) or e.keysym=='BackSpace':
            self.__dict__.pop('_space_wait',None)
            try:self.after_cancel(wait[0])
            except (ValueError,tk.TclError):pass
            return None   # the unit goes on with the value (or the space taken back)
        self.space_settle()
        if e.keysym=='space':
            # a second Espace before the moment is past: the value, then this Espace as on the plan, as before (« 50 », Espace,
            # Espace: the polyline finished; review: not when the value stayed in the box, refused)
            if not self.command_value.get().strip():self.space_command(e)
            return 'break'
        if e.keysym in ('Return','KP_Enter'):return 'break'   # (that was its job)
        # the key then as on the plan: a digit starts the next value, a letter the search of commands
        if self.command_value.get().strip() or not (e.char and e.char.isprintable()):return None
        try:self.command_entry.place_forget()
        except tk.TclError:pass
        self.canvas.focus_set()
        return self.key_input(e) or 'break'
    def escape(self):
        self.space_settle()   # 0.19.42: Espace then Échap: the value given first, as before
        if self.drop_pending_box():self.draw_crosshair();return 'break'   # 0.19.21: the rectangle under way first; the selection stays
        if self.close_stack_choice():return 'break'   # 0.18.6: Échap closes the list; the click is not done
        if self.close_grip_menu():return 'break'   # 0.19.7: « Étirer / Allonger » too
        __import__('export_check').clear_marks(self);self.forget_stack_picks()
        if self.grip_drag:
            keep=set(self.selected_set),self.selected;self.cancel();self.end_grip_input();self.selected_set,self.selected=keep;self.refresh();return 'break'
        keep=(self.move_state or {}).get('keep')
        if keep is not None:
            # 0.18.5: a selection taken by one of its grips stays selected, as after Échap on a grip.
            result=super().escape();self.selected_set={i for i in keep if i<len(self.items)};self.selected=min(self.selected_set) if self.selected_set else None
            self.refresh();return result
        return super().escape()
    def undo(self):
        if not self.licence_complet():return self.read_only_said()   # 0.19.16: Annuler changes the drawing too
        self.close_stack_choice()
        # 0.18.5: Ctrl+Z while a selection taken by a grip follows the mouse drops that move only.
        if (self.move_state or {}).get('keep') is not None:return self.escape()
        if self.grip_drag:return self.escape()   # 0.19.9: the grip held is let go (the step before it was taken back too)
        if self.drawing_under_way():return self.undo_point()   # 0.19.40: the shape under way only, never the action before too
        t=self.tool.get();result=super().undo()
        if t in CORNER_TOOLS and self.tool.get()!=t:
            # 0.19.5: Annuler in a series of raccords takes back the last one; the tool stays for doing it again.
            self.resume_corner(t)
        else:self.resume_series(t)
        return result
    def undo_point(self):
        """0.19.40 (night review « dessin »): Ctrl+Z while a shape is being drawn took back the action before as well (the
        shape under way dropped too: two steps for one, unlike a grip, 0.19.9). Polyligne and Spline: their last point
        (as « retour » / « Retirer le dernier point »); the other tools: the shape under way, as Échap."""
        t=self.tool.get()
        if t=='poly' and self.pending:
            self.pending.pop();self.start=self.pending[-1] if self.pending else None
        elif t=='spline_fit' and self.curve_points:self.curve_points.pop()
        else:return self.escape()
        self.command_value.set('');self.command_entry.place_forget();self.canvas.delete('preview')
        x,y=self.cursor_screen;self.motion(SimpleNamespace(x=x,y=y,state=0))
        if t=='poly':self.set_hint()
        return 'break'
    def resume_series(self,t):
        """0.19.5 / 0.19.6: Trous de ceinture, Fente d'ardillon, Sangle entière stay after Annuler / Rétablir."""
        if self.tool.get()==t:return
        if t=='belt_holes':__import__('belt_holes_ui').resume(self,' Échap pour finir.')
        elif t=='buckle_slot':__import__('strap_ui').slot_resume(self,' Échap pour finir.')
        elif t=='strap_piece':__import__('strap_ui').piece_resume(self,' Échap pour finir.')
        elif t=='toron':__import__('strap_ui').toron_resume(self,' Échap pour finir.')
        elif t=='assembly':__import__('assembly_ui').resume(self)
        elif t=='passant':__import__('strap_ui').passant_resume(self,' Échap pour finir.')
        elif t=='teinte_bord':__import__('teinte_ui').resume(self,' Échap pour finir.')   # 0.19.39
    def redo(self):
        if not self.licence_complet():return self.read_only_said()
        t=self.tool.get();result=super().redo()
        if t in CORNER_TOOLS and self.tool.get()!=t:self.resume_corner(t)   # 0.19.5: like Annuler, Rétablir keeps a tool in series
        else:self.resume_series(t)
        return result
    def rebuild_sections(self):
        """Mozart / AutoCAD sheet tabs: flat names separated by thin lines, the active one framed and light, then « + »."""
        if 'section_tabs' not in self.__dict__:return
        sections=self.shown_sections()
        if __import__('fiches').is_auto(self.active_section) and not any(v['id']==self.active_section for v in sections):
            self.active_section='plan'   # its zones are gone: back to the plan
            # 0.19.43 (review): a timer, as its smoothing (schedule_smooth): at idle it ran inside the update_idletasks of the next
            # mouse move (motion), where its smoothing cannot come first: the whole plan shown raw
            self.after(0,self.redraw)
        signature=('acad',self.current_doc,self.active_section,self.p['panel'],self.p['ui_ink'],self.field_background(),tuple((v['id'],v['title']) for v in sections))
        if signature==self.__dict__.get('_section_signature') and self.section_tabs.winfo_children():return
        self._section_signature=signature
        for child in self.section_tabs.winfo_children():child.destroy()
        import modern_style
        panel=self.p['panel'];t=modern_style.tokens_for(self.p)
        for k,section in enumerate(sections):
            active=section['id']==self.active_section
            # 0.19.0: rounded tabs: the sheet shown raised, the others lit under the mouse.
            f=tk.Frame(self.section_tabs,bg=panel)
            f.pack(side='left',padx=(0,2),pady=2)
            label=modern_style.make_pill(f,text=section['title'],fill=t['raised'] if active else None,ink=t['text'] if active else t['muted'],hover='' if active else t['hover'],padx=12,pady=2,edge=t['outline'])   # 0.19.2: every tab outlined
            label.pack()
            for w in (f,label):
                w.bind('<Button-1>',lambda e,key=section['id']:self.select_section(key))
                w.bind('<Button-3>',lambda e,key=section['id']:self.section_menu(e,key))
        plus=modern_style.make_pill(self.section_tabs,text='+',ink=t['muted'],hover=t['hover'],padx=7,pady=2,size=11,edge=t['outline']);plus.pack(side='left',pady=2)
        plus.bind('<Button-1>',lambda e:self.add_section())
    def end_grip_input(self):
        if self.command_value.get():self.command_value.set('')
        self.command_entry.place_forget();self.canvas.focus_set()
        # 0.19.9: the grip is placed or let go: the Repérage points kept on the way are forgotten (a later grip
        # was still pulled onto their dotted lines).
        tracking.reset(self)
    def translating_ids(self):
        g=self.grip_drag
        if g and g['mode']=='move' and g.get('changed') and 'offset' in g:return (g['index'],)+tuple(g.get('linked',{}))
        return super().translating_ids()
    def translation_offset(self):
        g=self.grip_drag
        if g and g['mode']=='move' and 'offset' in g:return g['offset']
        return super().translation_offset()
    def move_whole_grip(self,e):
        """Centre grip: the shape is translated; after the first redraw only its canvas items move."""
        g=self.grip_drag;p=self.point(e);first=not g['changed']
        if first:
            if math.dist(p,g['anchor'])<.1/self.scale:self.draw_crosshair();return
            self.snapshot();g['changed']=True
        dx,dy=p[0]-g['anchor'][0],p[1]-g['anchor'][1]
        for i,original in [(g['index'],g['original'])]+list(g.get('linked',{}).items()):
            self.items[i]=copy.deepcopy(original);self.items[i]['x']+=dx;self.items[i]['y']+=dy
        g['offset']=(dx,dy)
        if first or not self.fast_translate(g['offset']):self.refresh()
        self.draw_crosshair()
    def move_grip(self,e):
        g=self.grip_drag;mode=g['mode']
        if mode=='joint':return self.move_joint_grip(e)
        if mode=='move':return self.move_whole_grip(e)
        if isinstance(mode,tuple) and mode[0]=='pvertex':return self.move_vertex(e)
        if isinstance(mode,tuple) and mode[0]=='side':return self.move_side(e)   # 0.19.22
        if isinstance(mode,tuple) and mode[0]=='arc':
            from native_edit import edit_arc
            p=self.point(e)
            if not g['changed'] and math.dist(p,g['anchor'])<.1/self.scale:self.draw_crosshair();return   # 0.19.9: put back where taken: no Annuler step
            try:s=edit_arc(g['original'],mode,p);validate([s])
            except ValueError as exc:self.invalid_at(e,str(exc));return
            if not g['changed']:self.snapshot();g['changed']=True
            origin=arc_grip_origin(g['original'],mode)
            self.items[g['index']]=s;self.reattach_crans(g,s,(origin,p) if origin else None);self.refresh();self.draw_crosshair();return
        if isinstance(mode,tuple) and mode[0]=='corner':
            s=copy.deepcopy(g['original']);p=self.point(e);corners=path(s)[0];fixed=corners[(mode[1]+2)%4]
            if not g['changed'] and math.dist(p,g['anchor'])<.1/self.scale:self.draw_crosshair();return   # 0.19.9: put back where taken: no Annuler step
            w,h=abs(p[0]-fixed[0]),abs(p[1]-fixed[1])
            if min(w,h)<EPS:return
            s.update(x=min(p[0],fixed[0]),y=min(p[1],fixed[1]),w=w,h=h)
            if not g['changed']:self.snapshot();g['changed']=True
            # 0.19.9: its crans stay on it (they stayed where they were): each corner goes where the new rectangle puts it.
            a=corners[mode[1]];moved=[(q,(p[0] if abs(q[0]-a[0])<EPS else fixed[0],p[1] if abs(q[1]-a[1])<EPS else fixed[1])) for q in corners]
            self.items[g['index']]=s;self.reattach_crans(g,s,moved);self.refresh();self.draw_crosshair();return
        if not isinstance(mode,tuple) or mode[0] not in ('edge','ellipse_axis','circle_axis'):return super().move_grip(e)
        s=copy.deepcopy(g['original']);p=self.point(e);moved=None
        if not g['changed'] and math.dist(p,g['anchor'])<.1/self.scale:self.draw_crosshair();return   # 0.19.9: put back where taken: no Annuler step
        try:
            if mode[0]=='edge':
                pts=self.rect_corners(s) if s['kind']=='rect' else path(s)[0];j=mode[1];k=(j+1)%len(pts);a,b=pts[j],pts[k];length=math.dist(a,b)
                if length<1e-9:return   # 0.19.9: a side of zero length has no direction
                n=(-(b[1]-a[1])/length,(b[0]-a[0])/length);d=(p[0]-g['anchor'][0])*n[0]+(p[1]-g['anchor'][1])*n[1]
                for index in (j,k):pts[index]=(pts[index][0]+d*n[0],pts[index][1]+d*n[1])
                moved=[(a,pts[j]),(b,pts[k])]   # 0.19.9: for its crans (the side moved takes them along)
                # Reject collapsed or inverted corners while dragging.
                original=self.rect_corners(s) if s['kind']=='rect' else path(s)[0];area=lambda v:sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(v,v[1:]+v[:1]))
                rectangle=s['kind']=='rect' or len(original)==4 and len({round(p[0],7) for p in original})==2 and len({round(p[1],7) for p in original})==2
                if not rectangle and area(original)*area(pts)<=EPS:raise ValueError('Ligne/polyligne inversée')
                if s['kind']=='rect':
                    xs=[v[0] for v in pts];ys=[v[1] for v in pts];s.update(x=min(xs),y=min(ys),w=max(xs)-min(xs),h=max(ys)-min(ys))
                    if min(s['w'],s['h'])<EPS:return
                    if s.get('r') and min(s['w'],s['h'])<2*s['r']-1e-9:raise ValueError('Le rectangle devient trop petit pour ses arrondis.')   # 0.19.22
                else:s=inherit(polygon(pts,s['name'],True),s)
            elif mode[0]=='ellipse_axis':
                from precision_geometry import ellipse
                E=s['ellipse'];angle=E['angle']+(mode[1]%2)*math.pi/2;n=(math.cos(angle),math.sin(angle));sign=1 if mode[1]<2 else -1;fixed=(s['x']-sign*(E['rx'] if mode[1]%2==0 else E['ry'])*n[0],s['y']-sign*(E['rx'] if mode[1]%2==0 else E['ry'])*n[1]);length=sign*((p[0]-fixed[0])*n[0]+(p[1]-fixed[1])*n[1])
                if length<.002:raise ValueError('Axe trop court.')
                c=(fixed[0]+sign*length/2*n[0],fixed[1]+sign*length/2*n[1]);rx,ry=E['rx'],E['ry']
                if mode[1]%2==0:rx=length/2
                else:ry=length/2
                s=inherit(ellipse(c,rx,ry,E['angle'],name=s['name']),s)
            else:
                c=(s['x']+s['w']/2,s['y']+s['h']/2);r=math.dist(c,p)
                if r<.001:return
                s.update(x=c[0]-r,y=c[1]-r,w=2*r,h=2*r)
            validate([s])
        except ValueError as exc:self.invalid_at(e,str(exc));return
        if not g['changed']:self.snapshot();g['changed']=True
        self.items[g['index']]=s;self.reattach_crans(g,s,moved);self.refresh();self.draw_crosshair()   # 0.19.9: its crans stay on it
    def draw_shape(self,s,color,width,tags=()):
        # 0.16.15: shapes being translated (Déplacer, glisser une pièce) are tagged
        # 'moving' during the full redraw, so later pointer moves only shift them.
        capture=self.__dict__.get('_capture_ids')
        if capture is not None and not tags and id(s) in capture:
            from ui_widgets import tag_created
            with tag_created(self.canvas,'moving') as created:
                result=self._draw_shape(s,color,width,tags)
            self._captured.add(capture[id(s)])   # 0.19.22: drawn, or drawing nothing on purpose (a zone or a précoupe hidden): nothing else to move
            return result
        return self._draw_shape(s,color,width,tags)
    def _draw_shape(self,s,color,width,tags=()):
        # Text labels do not have a drawing-centre handle.
        ids=self.selected_set;old=self.selected
        index=self.selection_index();k=index.get(id(s)) if index is not None else None   # 0.19.9: the selection looked up once per drawing of the plan
        if index is None:chosen=not tags and any(self.items[i] is s for i in self.selected_ids())
        else:chosen=not tags and k is not None and self.items[k] is s and (k in ids if ids else k==old)
        if not tags and __import__('preparation_ui').hidden_cut(self,s):return None   # 0.19.14: précoupes / surcoupes hidden
        if s.get('preparation'):return __import__('preparation_ui').draw_zone(self,s,tags,chosen)
        if s.get('piece_badge'):return __import__('piece_ids').draw_badge(self,s,tags,chosen)   # 0.18.1 ID unique
        # 0.16.30: nor the parts of a cote (one object): they are only lit.
        if s.get('annotation') or s.get('dimension_group'):
            if index is None:self.selected_set={i for i in ids if self.items[i] is not s}
            elif k is not None and k in ids:self.selected_set=ids-{k} if self.items[k] is s else {i for i in ids if self.items[i] is not s}   # (not selected: the same set)
            if old is not None and self.items[old] is s:self.selected=None
        # 0.19.0: above GRIP_LIMIT the selected pieces have no grips: they are drawn in the selection colour instead.
        lit=chosen and (bool(s.get('annotation') or s.get('is_notch') or s.get('dimension_group')) or not self.grips_shown())
        try:
            if lit:
                from ui_widgets import tag_created
                with tag_created(self.canvas,'lit'):result=super().draw_shape(s,color,width,tags)
            else:result=super().draw_shape(s,color,width,tags)
        finally:self.selected_set=ids;self.selected=old
        if lit:self.light_selected(s)
        if s.get('stitch'):self.draw_stitch_holes(s,tags,chosen)
        if chosen and self.grips_shown():
            for mode,p in self.deformation_grips(s):
                x,y=self.to_screen(p);self.canvas.create_rectangle(x-3,y-3,x+3,y+3,outline=self.prefs.get('anchor_color','#efcf4b'),fill=self.prefs.get('anchor_color','#efcf4b'),tags='grips')
        return result
    def draw_stitch_holes(self,s,tags,chosen):
        """0.18.0: the holes of a hand stitch, as dots (not drawn when they would touch each other)."""
        import stitching
        if stitching.kind(s)!='hand' or float(s['stitch'].get('pitch',0))*self.scale<6:return
        c=self.canvas;r=max(1.8,stitching.HOLE/2*self.scale);ink=self.p['accent'] if chosen else stitching.COLOR;t=tags or ('marks',)
        for x,y in stitching.holes(s):
            X,Y=self.to_screen((x,y));c.create_oval(X-r,Y-r,X+r,Y+r,fill=ink,outline='',tags=t)
    def light_selected(self,s):
        """0.16.30: a selected text, cote value or cran is drawn in the selection colour; a text
        also gets a dashed frame, so a single click shows what is selected."""
        c=self.canvas;accent=self.p['accent'];texts=[]
        for item in c.find_withtag('lit'):
            kind=c.type(item)
            if kind in ('text','line'):c.itemconfigure(item,fill=accent)
            elif kind=='polygon':c.itemconfigure(item,fill=accent if c.itemcget(item,'fill') else '',outline=accent if c.itemcget(item,'outline') else '')
            elif kind in ('rectangle','oval'):c.itemconfigure(item,outline=accent)
            if kind=='text':texts.append(item)
        c.dtag('lit','lit')
        box=c.bbox(*texts) if s.get('annotation') and not s.get('dimension_group') and texts else None
        if box:   # 0.19.9: none when deep zoom hid letters too big to draw (it raised and stopped the drawing)
            x,y,X,Y=box   # around the letters as they are shown
            c.create_rectangle(x-3,y-2,X+3,Y+2,outline=accent,dash=(3,3),width=1)
 EPS=1e-6
 return Advanced

EPS=1e-6
