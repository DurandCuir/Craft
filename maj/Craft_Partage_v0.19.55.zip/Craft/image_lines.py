"""0.19.53 (ses idées du 25/11/2026, validées le 26/11 à 11 h 46 : « Création de lignes auto avec image », « ajustage
auto d’une image à partir d’un carré ou une forme géométrique présente sur l’image ») : ce que montre l’image de fond,
lu sans aucun module installé, depuis les pixels de sa copie légère (backdrop.rgb_of : GDI+ sous Windows, Pillow ici).
Rien ici n’appelle Tk : tout peut tourner dans un fil de travail (``stop`` : abandonné quand il rend vrai).

- ``trace`` : les lignes de l’image. Les pixels plus foncés (ou plus clairs) que le seuil font des taches (``label``) ;
  une tache fine (``thickness`` : 2 × aire / périmètre) est un trait, suivi en son milieu (``skeleton`` : Zhang-Suen,
  puis ``strokes`` : les morceaux entre les bouts et les croisements, enchaînés deux à deux au plus droit à travers
  eux ; deux traits qui se croisent en biais font un seul croisement) ; les trous d’un trait sautés (``bridged`` : deux
  bouts face à face, un coin ou un T que le crayon a manqués) ; une tache épaisse est une forme, suivie par son bord au
  sous-pixel (``loop`` : les carrés qui marchent sur le gris), ses trous aussi. Chaque ligne simplifiée à ``tol``
  (Douglas-Peucker), ses coins remis où ses côtés se croisent (``simplified`` : arrondis par le flou d’une photo). Une
  texture (le grain du cuir, d’une table) n’est pas un dessin : ``TooMany``.
- ``shape_at`` : la forme fermée autour d’un point (un carré, un rectangle, un rond) : sa tache (``flood``), son bord,
  ses quatre côtés (droites des moindres carrés, coins à leurs croisements) ou son ellipse (moments de son aire) ; une
  forme tracée d’un trait mesurée au milieu de son trait (``line_width``). ``grid_of`` : la grille dont ce carré est
  une case (un tapis de coupe), case par case autour de lui, et la projection qui passe par tous ses coins.
- ``homography`` / ``warp`` : l’image redressée : chaque pixel de la nouvelle image pris dans l’ancienne.

Coordonnées des pixels : le centre du pixel (x, y) est le point (x, y) ; son bord gauche est x − ½."""
import math
import re

RUN = re.compile(b'\x01+')
ON = re.compile(b'\x01')


class TooMany(Exception):
    """So many spots (a grain, a texture, a threshold far off) that they are no drawing: ``args[0]`` how many."""


MANY = 300     # spots: more than that covering more than INKY of the part read are a texture (a drawing's lines
INKY = .08     # cover a few hundredths of it; a few shapes, more), as are a third as many covering 2.5 times as much
MOST = 5000    # spots: more than that, never a drawing


class Stopped(Exception):
    """The work was given up (a newer one is asked, the window was closed)."""


def _never():
    return False


# --- gray, threshold, ink ------------------------------------------------------------------------------------------

# the gray of a pixel as the eye sees it (0.299 R + 0.587 G + 0.114 B), each part rounded on its own: never more than
# 255 in all, so the three parts are added byte by byte as three big numbers (no byte carries into the next)
_LUMA = tuple(bytes(round(k * v) for v in range(256)) for k in (.299, .587, .114))


def gray_of(rgb):
    """The gray of each pixel (its luminance: a black leather on a green cutting mat stays darker than the mat; a line
    of any dark colour on white paper is dark). 0.45 s with the darkest channel, 0.05 s so (2400 × 1800, Linux)."""
    n = len(rgb) // 3
    total = 0
    for k in range(3):
        total += int.from_bytes(rgb[k::3].translate(_LUMA[k]), 'big')
    return total.to_bytes(n, 'big')


def histogram(gray, w=None, h=None, box=None, step=3):
    """The count of each gray level (one pixel in ``step`` of each row read), in ``box`` = (x0, y0, x1, y1) or all.
    0.19.54 (vitesse) : comptés en une lecture (Counter) au lieu de 256 (bytes.count) : la photo entière (2400 × 1800,
    « Créer les lignes d’après l’image… » à l’ouverture, sa photo du porte-cartes) 46 → 15 ms, les mêmes nombres."""
    from collections import Counter
    if box is None or w is None:
        sample = gray[::step]
    else:
        x0, y0, x1, y1 = box
        sample = b''.join(gray[y * w + x0:y * w + x1:step] for y in range(y0, y1, step))
    seen = Counter(sample)
    return [seen.get(v, 0) for v in range(256)]


def otsu(hist):
    """The gray level that best splits the picture in two (Otsu): the pixels at it or below are the dark ones."""
    total = sum(hist)
    if not total:
        return 127
    every = sum(i * n for i, n in enumerate(hist))
    below = 0
    weight = 0
    best = -1.
    level = 127
    for t in range(255):
        weight += hist[t]
        if not weight:
            continue
        rest = total - weight
        if not rest:
            break
        below += t * hist[t]
        between = weight * rest * (below / weight - (every - below) / rest) ** 2
        if between > best:
            best, level = between, t
    return level


def contrast(hist, level):
    """How far the two halves of the picture are (gray levels between their means): 0 for a plain picture."""
    low = sum(hist[:level + 1])
    high = sum(hist[level + 1:])
    if not low or not high:
        return 0.
    return sum(i * n for i, n in enumerate(hist[level + 1:], level + 1)) / high - sum(i * n for i, n in enumerate(hist[:level + 1])) / low


def edge_level(hist, level):
    """The gray where the edge of the ink is drawn: half way between the mean of the dark pixels and the mean of the
    light ones (a blurred edge is crossed there), at least the threshold's own half-step."""
    low = sum(hist[:level + 1])
    high = sum(hist[level + 1:])
    if not low or not high:
        return level + .5
    dark = sum(i * n for i, n in enumerate(hist[:level + 1])) / low
    light = sum(i * n for i, n in enumerate(hist[level + 1:], level + 1)) / high
    return (dark + light) / 2


def default_level(hist):
    """The threshold proposed for a picture: halfway between the gray of its ink and that of its paper (where the
    edge of a blurred spot is), the ink and the paper split by ``otsu``."""
    return int(edge_level(hist, otsu(hist)))


def border_dark(gray, w, h, level, box=None):
    """The share of the edge of the picture (or of its part ``box``) that is dark: the paper shows there mostly."""
    x0, y0, x1, y1 = box or (0, 0, w, h)
    edge = gray[y0 * w + x0:y0 * w + x1] + gray[(y1 - 1) * w + x0:(y1 - 1) * w + x1]
    edge += bytes(gray[y * w + x0] for y in range(y0, y1)) + bytes(gray[y * w + x1 - 1] for y in range(y0, y1))
    return sum(1 for v in edge if v <= level) / max(1, len(edge))


def mask_of(gray, w, h, level, dark=True, box=None):
    """1 for the ink (the pixels at ``level`` or darker when ``dark``, the lighter ones else), 0 for the paper; only in
    ``box`` = (x0, y0, x1, y1) when given (0 around)."""
    table = bytes(((v <= level) == bool(dark)) for v in range(256))
    m = gray.translate(table)
    if box and tuple(box) != (0, 0, w, h):
        x0, y0, x1, y1 = box
        out = bytearray(len(m))
        for y in range(y0, y1):
            out[y * w + x0:y * w + x1] = m[y * w + x0:y * w + x1]
        m = bytes(out)
    return m


def row_runs(mask, w, h):
    """The runs of ink of each row: [[(x0, x1), …], …] (x1 excluded)."""
    out = []
    for y in range(h):
        k = y * w
        out.append([(m.start() - k, m.end() - k) for m in RUN.finditer(mask, k, k + w)])
    return out


def _find(parent, i):
    root = i
    while parent[root] != root:
        root = parent[root]
    while parent[i] != root:
        parent[i], i = root, parent[i]
    return root


def label(runs, diagonal=True):
    """The groups of runs touching each other (8 neighbours when ``diagonal``, else 4): [[(y, x0, x1), …], …], in
    reading order of their first run."""
    parent = []
    ids = []
    k = 0
    d = 1 if diagonal else 0
    for y, row in enumerate(runs):
        here = list(range(k, k + len(row)))
        k += len(row)
        parent.extend(here)
        ids.append(here)
        if y and row and runs[y - 1]:
            above, above_ids = runs[y - 1], ids[y - 1]
            i = j = 0
            while i < len(row) and j < len(above):
                a0, a1 = row[i]
                b0, b1 = above[j]
                if a0 < b1 + d and b0 < a1 + d:
                    ra, rb = _find(parent, here[i]), _find(parent, above_ids[j])
                    if ra != rb:
                        parent[max(ra, rb)] = min(ra, rb)
                if a1 <= b1:
                    i += 1
                else:
                    j += 1
    groups = {}
    for y, row in enumerate(runs):
        for (x0, x1), i in zip(row, ids[y]):
            groups.setdefault(_find(parent, i), []).append((y, x0, x1))
    return [groups[r] for r in sorted(groups)]


def _overlaps(row, other):
    """For each run of ``row``: how many of its pixels have ink straight above (or below) in ``other``."""
    out = []
    j = 0
    for x0, x1 in row:
        n = 0
        while j < len(other) and other[j][1] <= x0:
            j += 1
        k = j
        while k < len(other) and other[k][0] < x1:
            n += min(x1, other[k][1]) - max(x0, other[k][0])
            k += 1
        out.append(n)
    return out


def exposure(runs):
    """{(y, x0): pixel edges of that run touching the paper}: its two ends, and the pixels with paper above or below."""
    out = {}
    for y, row in enumerate(runs):
        up = _overlaps(row, runs[y - 1]) if y else [0] * len(row)
        down = _overlaps(row, runs[y + 1]) if y + 1 < len(runs) else [0] * len(row)
        for (x0, x1), a, b in zip(row, up, down):
            out[(y, x0)] = 2 + 2 * (x1 - x0) - a - b
    return out


def stats(group, exposed=None):
    """(area, perimeter, box) of a group of runs: box = (x0, y0, x1, y1), x1 and y1 excluded."""
    area = sum(x1 - x0 for _, x0, x1 in group)
    ys = [y for y, _, _ in group]
    box = (min(x0 for _, x0, _ in group), min(ys), max(x1 for _, _, x1 in group), max(ys) + 1)
    per = sum(exposed[(y, x0)] for y, x0, _ in group) if exposed is not None else 0
    return area, per, box


def thickness(area, perimeter):
    """The width of a stroke (2 × area / perimeter: a long line of width e gives e; a square of side s, s / 2)."""
    return 2. * area / perimeter if perimeter else 0.


# --- the edge of ink, under the pixel (marching squares on the gray) ------------------------------------------------

# Cell (x, y): its corners TL (x, y) = 8, TR (x + 1, y) = 4, BR (x + 1, y + 1) = 2, BL (x, y + 1) = 1; its edges
# 0 top, 1 right, 2 bottom, 3 left. The ink of two corners only touching by a point goes through the middle (the
# inks are 8-connected, as ``label``), so a saddle cuts off its two paper corners.
PAIRS = {1: {3: 2, 2: 3}, 2: {2: 1, 1: 2}, 3: {3: 1, 1: 3}, 4: {0: 1, 1: 0}, 5: {3: 0, 0: 3, 1: 2, 2: 1},
         6: {0: 2, 2: 0}, 7: {3: 0, 0: 3}, 8: {3: 0, 0: 3}, 9: {0: 2, 2: 0}, 10: {0: 1, 1: 0, 2: 3, 3: 2},
         11: {0: 1, 1: 0}, 12: {3: 1, 1: 3}, 13: {1: 2, 2: 1}, 14: {3: 2, 2: 3}}
NEXT = {0: (0, -1, 2), 1: (1, 0, 3), 2: (0, 1, 0), 3: (-1, 0, 1)}
EDGE = {0: ((0, 0), (1, 0)), 1: ((1, 0), (1, 1)), 2: ((1, 1), (0, 1)), 3: ((0, 1), (0, 0))}


def loop(gray, mask, w, h, level, start, outside, stop=_never):
    """The edge between ink and paper through ``start`` = (cell x, cell y, edge it is entered by), all round, as points
    at the threshold's level between the pixel centres (``outside``: the gray of the paper beyond the picture)."""
    def ink(x, y):
        return 0 <= x < w and 0 <= y < h and mask[y * w + x]

    paper_high = outside > level

    def value(x, y, inked):
        # the gray of a point, always on its own side of the level: ink as it is; paper as it is, or the paper's
        # (``outside``) beyond the picture or the part read (a dark pixel left out of the part is paper there)
        if 0 <= x < w and 0 <= y < h:
            v = gray[y * w + x]
            if inked or (v > level) == paper_high:
                return v
        return outside

    cx, cy, edge = start
    first = (cx, cy, edge)
    out = []
    limit = 4 * (w + 2) * (h + 2)
    for step in range(limit):
        if not step & 4095 and stop():
            raise Stopped()
        (ax, ay), (bx, by) = EDGE[edge]
        px, py, qx, qy = cx + ax, cy + ay, cx + bx, cy + by
        pi, qi = ink(px, py), ink(qx, qy)
        vp, vq = value(px, py, pi), value(qx, qy, qi)
        if pi == qi or vp == vq:
            s = .5
        else:
            s = max(0., min(1., (level - vp) / (vq - vp)))
        out.append((px + s * (qx - px), py + s * (qy - py)))
        case = ink(cx, cy) * 8 + ink(cx + 1, cy) * 4 + ink(cx + 1, cy + 1) * 2 + ink(cx, cy + 1)
        exit_ = PAIRS.get(case, {}).get(edge)
        if exit_ is None:
            raise ValueError('Bord perdu.')
        dx, dy, edge = NEXT[exit_]
        cx, cy = cx + dx, cy + dy
        if (cx, cy, edge) == first:
            return out
    raise ValueError('Bord sans fin.')


def outer_start(group):
    """The crossing left of the first pixel of a group's top run: where its outer edge is followed from."""
    y, x0, _ = min(group)
    return (x0 - 1, y, 0)


def hole_start(group):
    """The crossing above-left of the first paper pixel of a hole (a group of paper runs): its edge from there."""
    y, x0, _ = min(group)
    return (x0, y - 1, 3)


# --- the middle of strokes (Zhang-Suen thinning) -------------------------------------------------------------------

def _tables():
    first, second = bytearray(256), bytearray(256)
    for code in range(256):
        p = [(code >> k) & 1 for k in range(8)]   # P2 (N), P3 (NE), P4 (E), P5 (SE), P6 (S), P7 (SW), P8 (W), P9 (NW)
        b = sum(p)
        a = sum(1 for k in range(8) if not p[k] and p[(k + 1) % 8])
        if 2 <= b <= 6 and a == 1:
            n, e, s, west = p[0], p[2], p[4], p[6]
            first[code] = not (n and e and s) and not (e and s and west)
            second[code] = not (n and e and west) and not (n and s and west)
    return bytes(first), bytes(second)


THIN = _tables()


class TooWide(Exception):
    """A spot taken for a stroke that is wider than that (its thinning would go on and on): a shape."""


def skeleton(group, stop=_never, most=None):
    """The middle line of a stroke (a group of runs), one pixel wide: (grid, width, x origin, y origin) where grid[i]
    is 1 on the line (a padded copy of the group's box). ``most``: thinned that many times at most (a pixel off each
    side each time), else TooWide."""
    _, _, (bx0, by0, bx1, by1) = stats(group)
    W = bx1 - bx0 + 2
    H = by1 - by0 + 2
    g = bytearray(W * H)
    for y, x0, x1 in group:
        k = (y - by0 + 1) * W + 1 - bx0
        g[k + x0:k + x1] = b'\x01' * (x1 - x0)
    offs = (-W, -W + 1, 1, W + 1, W, W - 1, -1, -W - 1)
    # (the code of the 8 neighbours written out in each comprehension: a call for each pixel cost a third of the time)
    cand = {i for y, x0, x1 in group for i in range((y - by0 + 1) * W + 1 + x0 - bx0, (y - by0 + 1) * W + 1 + x1 - bx0)
            if not (g[i - W] and g[i - W + 1] and g[i + 1] and g[i + W + 1] and g[i + W] and g[i + W - 1] and g[i - 1]
                    and g[i - W - 1])}
    step = idle = 0
    while idle < 2:
        if stop():
            raise Stopped()
        if most is not None and step >= 2 * most:
            raise TooWide()
        lut = THIN[step & 1]
        gone = [i for i in cand if lut[g[i - W] | g[i - W + 1] << 1 | g[i + 1] << 2 | g[i + W + 1] << 3 | g[i + W] << 4
                                       | g[i + W - 1] << 5 | g[i - 1] << 6 | g[i - W - 1] << 7]]
        if gone:
            for i in gone:
                g[i] = 0
            fresh = {i + o for i in gone for o in offs if g[i + o]}
            cand.difference_update(gone)
            cand |= fresh
            idle = 0
        else:
            idle += 1
        step += 1
    return g, W, bx0 - 1, by0 - 1


def _links(g, W, i):
    """The pixels of the line next to ``i``: the straight ones, and a diagonal one only without a straight one between."""
    n, e, s, west = g[i - W], g[i + 1], g[i + W], g[i - 1]
    out = [j for j, on in ((i - W, n), (i + 1, e), (i + W, s), (i - 1, west)) if on]
    if g[i - W + 1] and not n and not e:
        out.append(i - W + 1)
    if g[i + W + 1] and not s and not e:
        out.append(i + W + 1)
    if g[i + W - 1] and not s and not west:
        out.append(i + W - 1)
    if g[i - W - 1] and not n and not west:
        out.append(i - W - 1)
    return out


def _branches(g, W):
    """The skeleton cut at its ends and crossings: (pieces, nodes): each piece a list of pixel indices from one node (or
    free end) to the next, a closed one starting and ending on the same pixel; nodes: the pixels kept as ends."""
    on = [m.start() for m in ON.finditer(g)]   # (review: found by re, not read pixel by pixel: a long stroke's box is
    # most of the picture, 32 → 2 ms each)
    links = {i: _links(g, W, i) for i in on}
    # a link seen from both sides (a diagonal is kept or dropped the same way from both pixels)
    links = {i: [j for j in js if i in links.get(j, ())] for i, js in links.items()}
    nodes = {i for i, js in links.items() if len(js) != 2}
    seen = set()
    pieces = []
    for a in sorted(nodes):
        for b in links[a]:
            if (a, b) in seen:
                continue
            piece = [a, b]
            seen.add((a, b))
            seen.add((b, a))
            prev, cur = a, b
            while cur not in nodes:
                nxt = next((j for j in links[cur] if j != prev), None)
                if nxt is None:
                    break
                seen.add((cur, nxt))
                seen.add((nxt, cur))
                piece.append(nxt)
                prev, cur = cur, nxt
                if cur == a:
                    break
            pieces.append(piece)
    for a in on:   # rings with no end nor crossing
        if a in nodes or all((a, b) in seen for b in links[a]):
            continue
        b = links[a][0]
        piece = [a, b]
        seen.add((a, b))
        seen.add((b, a))
        prev, cur = a, b
        while cur != a:
            nxt = next((j for j in links[cur] if j != prev and (cur, j) not in seen), None)
            if nxt is None:
                break
            seen.add((cur, nxt))
            seen.add((nxt, cur))
            piece.append(nxt)
            prev, cur = cur, nxt
        pieces.append(piece)
    return pieces, nodes, links


def _direction(points, from_end, k):
    """The way a piece leaves its end (``from_end``: its last point, else its first), over ``k`` pixels."""
    seq = points[::-1] if from_end else points
    a = seq[0]
    b = seq[min(len(seq) - 1, k)]
    d = math.dist(a, b)
    return ((b[0] - a[0]) / d, (b[1] - a[1]) / d) if d else (0., 0.)


def _leaving(points, from_end, near, far):
    """The way a piece leaves its end, between its points ``near`` and ``far`` from it (fewer on a short piece)."""
    seq = points[::-1] if from_end else points
    n = len(seq)
    a = seq[min(near, max(0, n - 3))]
    b = seq[min(far, n - 1)]
    d = math.dist(a, b)
    if not d:
        return _direction(points, from_end, far)
    return ((b[0] - a[0]) / d, (b[1] - a[1]) / d)


def strokes(group, width, stop=_never, most=None):
    """The middle lines of a stroke group: [(points, closed, first end free, last end free), …] in pixel coordinates.
    The pieces between ends and crossings, without the short spurs of the thinning (shorter than one and a half
    widths), joined through each crossing two by two, the straightest first (two lines crossing at a narrow angle run
    together for a while: one crossing); a free end lengthened by half the width (thinning eats it), an end at a
    crossing put on the line it meets."""
    g, W, ox, oy = skeleton(group, stop, most)
    pieces, nodes, links = _branches(g, W)
    if not pieces:
        return []

    def xy(i):
        return (float(i % W + ox), float(i // W + oy))

    spur = max(3., 1.5 * width)
    ends = {i for i in nodes if len(links[i]) == 1}
    crossing = {i for i in nodes if len(links[i]) >= 3}
    # a crossing is often a few pixels of the skeleton, all with three links: one node (the pieces between them go)
    parent = {i: i for i in crossing}

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    inner = max(3, int(2 * width) + 1)   # pixels: a crossing's own pieces are shorter than that
    shared = max(inner, int(4 * width) + 1)   # two lines crossing at a narrow angle run together as long as that
    narrow = max(shared, int(12 * width) + 1)   # … and as long as that at 20°
    look = max(3, int(round(width)) + 2)
    raw = {}
    for k, p in enumerate(pieces):
        if (p[0] != p[-1] or len(p) <= 2) and not (len(p) < spur and (p[0] in ends or p[-1] in ends)):
            raw.setdefault(p[0], []).append((k, 0))
            raw.setdefault(p[-1], []).append((k, 1))

    near = int(1.5 * width)   # pixels: near a crossing, its branches bend toward each other
    far = near + int(3 * width) + look

    def leaves(k, side):
        p = pieces[k]
        return _leaving([xy(i) for i in (p[:far + 1] if side == 0 else p[-far - 1:])], side == 1, near, far)

    def runs_on(k, side):
        # another line leaves the node the other way (the piece is where two lines run together, not a rung)
        u = leaves(k, side)
        return any(1 + u[0] * v[0] + u[1] * v[1] <= .3 for v in
                   (leaves(j, s) for j, s in raw.get(pieces[k][0 if side == 0 else -1], ()) if (j, s) != (k, side)))
    def crosses(k):
        # the lines at the two ends of the piece go on through it two by two, each along it (a narrow crossing: never
        # two branches on either side of a line)
        p = pieces[k]
        a, b = xy(p[0]), xy(p[-1])
        c = _unit((b[0] - a[0], b[1] - a[1]))
        e1 = [leaves(j, s) for j, s in raw.get(p[0], ()) if (j, s) != (k, 0)]
        e2 = [leaves(j, s) for j, s in raw.get(p[-1], ()) if (j, s) != (k, 1)]
        e1 = [u for u in e1 if -(u[0] * c[0] + u[1] * c[1]) >= .7]
        e2 = [v for v in e2 if v[0] * c[0] + v[1] * c[1] >= .7]
        good = [(i, j) for i, u in enumerate(e1) for j, v in enumerate(e2) if 1 + u[0] * v[0] + u[1] * v[1] <= .3]
        return any(i != i2 and j != j2 for i, j in good for i2, j2 in good)
    joint = set()
    for k, p in enumerate(pieces):
        if p[0] in crossing and p[-1] in crossing and p[0] != p[-1] and (
                len(p) <= inner or (len(p) <= shared and runs_on(k, 0) and runs_on(k, 1)) or
                (len(p) <= narrow and crosses(k))):
            joint.add(k)
            a, b = root(p[0]), root(p[-1])
            if a != b:
                parent[max(a, b)] = min(a, b)

    def node_of(i):
        return root(i) if i in crossing else i
    kept = []
    for k, p in enumerate(pieces):
        if len(p) < 2:
            continue
        a, b = node_of(p[0]), node_of(p[-1])
        if p[0] in crossing and p[-1] in crossing and a == b and (len(p) <= inner or k in joint):
            continue   # inside a crossing
        free = (p[0] in ends) + (p[-1] in ends)
        joined = (p[0] in crossing) + (p[-1] in crossing)
        if free == 1 and joined == 1 and len(p) < spur:
            continue   # a spur of the thinning
        kept.append(p)
    if not kept:
        kept = [max(pieces, key=len)]
    # the ends meeting at each node, paired the straightest first (two ends of the same line through a crossing)
    at = {}
    for k, p in enumerate(kept):
        if p[0] == p[-1] and len(p) > 2:
            continue   # a ring
        at.setdefault(node_of(p[0]), []).append((k, 0))
        at.setdefault(node_of(p[-1]), []).append((k, 1))
    pts = [[xy(i) for i in p] for p in kept]
    cut = max(1, int(width))   # pixels left out on each side of a crossing (bent toward the other lines)
    partner = {}
    for node, es in at.items():
        if len(es) < 2:
            continue
        if len(es) == 2:   # the same line (a corner of it, or a crossing whose other lines were spurs)
            a, b = es
            partner[a], partner[b] = b, a
            continue
        dirs = {e: _leaving(pts[e[0]], e[1] == 1, near, far) for e in es}
        pairs = sorted((1 + dirs[a][0] * dirs[b][0] + dirs[a][1] * dirs[b][1], a, b) for n, a in enumerate(es)
                       for b in es[n + 1:])
        used = set()
        for cost, a, b in pairs:
            if a in used or b in used or cost > 1.:   # more than a right angle away from straight: not the same line
                continue
            partner[a], partner[b] = b, a
            used.update((a, b))
    out = []
    done = set()
    for k in range(len(kept)):
        if k in done:
            continue
        if kept[k][0] == kept[k][-1] and len(kept[k]) > 2:
            done.add(k)
            out.append((pts[k][:-1], True))
            continue
        # back to the start of the chain this piece is in (or once round, when it closes)
        cur, side = k, 0
        for _ in range(len(kept) + 1):
            back = partner.get((cur, side))
            if back is None or back[0] == k:
                break
            cur, side = back[0], 1 - back[1]
        start = (cur, side)
        chain = []
        closed = False
        for _ in range(len(kept) + 1):
            done.add(cur)
            seq = pts[cur] if side == 0 else pts[cur][::-1]
            if chain:
                node = kept[cur][0] if side == 0 else kept[cur][-1]
                if node in crossing:   # through a crossing: its pixels and those next to it (pulled toward the other
                    # lines) left out, the line goes straight across
                    drop = min(cut + 1, len(chain) - 2)
                    if drop > 0:
                        del chain[-drop:]
                    seq = seq[max(0, min(cut + 1, len(seq) - 2)):]
                elif chain[-1] == seq[0]:
                    seq = seq[1:]
            chain.extend(seq)
            nxt = partner.get((cur, 1 - side))
            if nxt is None:
                break
            if nxt == start:
                closed = True
                break
            if nxt[0] in done:
                break
            cur, side = nxt
        if closed:
            node = kept[start[0]][0] if start[1] == 0 else kept[start[0]][-1]
            if node in crossing and len(chain) > 4 * (cut + 1):   # closed through a crossing: as above
                del chain[-(cut + 1):]
                del chain[:cut + 1]
            elif len(chain) > 2 and chain[0] == chain[-1]:
                chain.pop()
        out.append((chain, closed))
    # free ends lengthened by half the stroke (the thinning shortens a line by that much); an end at a crossing put on
    # the line it meets there (the crossing's pixel is often one off)
    half = width / 2.
    free = {xy(i) for i in ends}
    met = {xy(i) for i in crossing}
    longer = []
    for points, closed in out:
        loose = [False, False]
        if not closed and len(points) >= 2:
            points = list(points)
            for n, which in enumerate((0, -1)):
                if points[which] in free:
                    loose[n] = True
                    # its last pixels often turn aside (the thinning of a slanting stroke's end): left out, the line
                    # carried on straight from where it is still straight
                    hook = int(width / 2)
                    more = half
                    if hook and len(points) > 4 * hook + 4:
                        more += hook
                        if which == 0:
                            del points[:hook]
                        else:
                            del points[-hook:]
                    dx, dy = _direction(points, which == -1, 2 * look)
                    x, y = points[which]
                    points[which] = (x - dx * more, y - dy * more)
        longer.append((points, closed, loose[0], loose[1]))
    boxes = [(min(q[0] for q in p), min(q[1] for q in p), max(q[0] for q in p), max(q[1] for q in p)) if p else None
             for p, *_ in longer]
    reach = width + cut + 2
    for k, (points, closed, _, _) in enumerate(longer):
        if closed:
            continue
        for which in (0, -1):
            if points[which] not in met:
                continue
            # an end at a crossing whose line goes on no farther (a T): its last pixels (pulled toward the other line)
            # left out, then carried along its way onto the line it meets
            drop = min(cut + 1, len(points) - 2)
            if drop > 0:
                if which == 0:
                    del points[:drop]
                else:
                    del points[-drop:]
            d = _direction(points, which == -1, look)
            a, u = points[which], (-d[0], -d[1])
            hit = near = None
            for j, (other, oc, _, _) in enumerate(longer):
                bx = boxes[j]
                if j == k or bx is None or not (bx[0] - reach <= a[0] <= bx[2] + reach and
                                                bx[1] - reach <= a[1] <= bx[3] + reach):
                    continue
                for q0, q1 in zip(other, other[1:] + (other[:1] if oc else [])):
                    h = _ray_hit(a, u, q0, q1)
                    if h is not None and h[0] <= reach and (hit is None or h[0] < hit[0]):
                        hit = h
                    q = _nearest_on(a, q0, q1)
                    e = math.dist(q, a)
                    if e <= reach and (near is None or e < near[0]):
                        near = (e, q)
            to = hit[1] if hit else near[1] if near else None
            if to is not None and math.dist(to, a) > 1e-9:
                points.insert(0, to) if which == 0 else points.append(to)
    return longer


REACH = 3.    # stroke widths: a gap in a line (a lighter speck, the pen lifted) as wide as that is jumped
REACH_MOST = 40.   # pixels
FACING = math.cos(math.radians(30))


def _reach(width):
    return min(REACH_MOST, max(4., REACH * width))


def bridged(lines, stop=_never):
    """Lines with gaps closed: ``lines`` [(points, closed, first end free, last end free, width), …] → [(points,
    closed, width), …]. Two free ends facing each other (30° at most each way) are joined straight; two whose ways
    meet (a corner the pen missed) are joined through that point; an end whose way meets another line (a T the pen
    missed) is carried onto it. Never farther than ``REACH`` widths of the line, the nearest first."""
    lines = [(list(p), c, f0, f1, w) for p, c, f0, f1, w in lines]
    ends = []
    for k, (p, c, f0, f1, w) in enumerate(lines):
        if c or len(p) < 2:
            continue
        look = max(3, int(round(w)) + 2)
        for side, loose in ((0, f0), (1, f1)):
            if loose:
                d = _direction(p, side == 1, look)
                ends.append(((k, side), p[-1 if side else 0], (-d[0], -d[1]), _reach(w)))
    if not ends:
        return [(p, c, w) for p, c, _, _, w in lines]
    cell = max(r for *_, r in ends)
    grid = {}
    for n, (_, (x, y), _, _) in enumerate(ends):
        grid.setdefault((int(x // cell), int(y // cell)), []).append(n)
    found = []
    for n, (ea, a, ua, ra) in enumerate(ends):
        if stop():
            raise Stopped()
        cx, cy = int(a[0] // cell), int(a[1] // cell)
        for m in (m for gx in (cx - 1, cx, cx + 1) for gy in (cy - 1, cy, cy + 1) for m in grid.get((gx, gy), ())):
            if m <= n:
                continue
            eb, b, ub, rb = ends[m]
            if ea == eb:
                continue
            r = (ra + rb) / 2
            v = (b[0] - a[0], b[1] - a[1])
            d = math.hypot(*v)
            if d > r:
                continue
            if eb[0] == ea[0] and length(lines[ea[0]][0]) < 4 * r:
                continue   # a short line closed on itself: a speck
            if d < 1:
                if ua[0] * ub[0] + ua[1] * ub[1] <= -FACING:
                    found.append((d, n, m, ()))
                continue
            if (ua[0] * v[0] + ua[1] * v[1]) / d >= FACING and -(ub[0] * v[0] + ub[1] * v[1]) / d >= FACING:
                found.append((d, n, m, ()))
                continue
            x = _meet((a, ua), (b, ub))
            if x is None:
                continue
            s = (x[0] - a[0]) * ua[0] + (x[1] - a[1]) * ua[1]
            t = (x[0] - b[0]) * ub[0] + (x[1] - b[1]) * ub[1]
            turn = math.degrees(math.acos(max(-1., min(1., -(ua[0] * ub[0] + ua[1] * ub[1])))))
            if 0 < s <= r and 0 < t <= r and 30 <= turn <= 150:
                found.append((s + t, n, m, (x,)))
    link = {}
    for _, n, m, via in sorted(found, key=lambda f: f[0]):
        ea, eb = ends[n][0], ends[m][0]
        if ea in link or eb in link:
            continue
        link[ea] = (eb, via)
        link[eb] = (ea, via[::-1])
    # an end left free whose way meets a line
    segs = {}
    lengths = []
    for k, (p, c, *_ ) in enumerate(lines):
        acc = [0.]
        for q0, q1 in zip(p, p[1:]):
            acc.append(acc[-1] + math.dist(q0, q1))
        lengths.append(acc)
        pairs = list(zip(range(len(p) - 1), range(1, len(p)))) + ([(len(p) - 1, 0)] if c and len(p) > 2 else [])
        for i, j in pairs:
            (x0, y0), (x1, y1) = p[i], p[j]
            for gx in range(int(min(x0, x1) // cell), int(max(x0, x1) // cell) + 1):
                for gy in range(int(min(y0, y1) // cell), int(max(y0, y1) // cell) + 1):
                    segs.setdefault((gx, gy), []).append((k, i, j))
    onto = {}
    for e, a, u, r in ends:
        if e in link:
            continue
        if stop():
            raise Stopped()
        k, side = e
        b = (a[0] + u[0] * r, a[1] + u[1] * r)
        mine = lengths[k][-1] if side else 0.
        best = None
        seen = set()
        for gx in range(int(min(a[0], b[0]) // cell), int(max(a[0], b[0]) // cell) + 1):
            for gy in range(int(min(a[1], b[1]) // cell), int(max(a[1], b[1]) // cell) + 1):
                for s in segs.get((gx, gy), ()):
                    if s in seen:
                        continue
                    seen.add(s)
                    j, i0, i1 = s
                    if j == k and abs(lengths[k][i0] - mine) < 3 * r:
                        continue   # the line's own end
                    q0, q1 = lines[j][0][i0], lines[j][0][i1]
                    hit = _ray_hit(a, u, q0, q1)
                    if hit is not None and hit[0] <= r and (best is None or hit[0] < best[0]):
                        best = hit
        if best is not None:
            onto[e] = best[1]
    # the chains
    out = []
    done = set()
    for k in range(len(lines)):
        if k in done:
            continue
        p, c, _, _, w = lines[k]
        if c:
            done.add(k)
            out.append((p, True, w))
            continue
        cur, side = k, 0
        for _ in range(len(lines) + 1):
            back = link.get((cur, side))
            if back is None or back[0][0] == k:
                break
            cur, side = back[0][0], 1 - back[0][1]
        start = (cur, side)
        chain = []
        closed = False
        width = 0.
        if start in onto:
            chain.append(onto[start])
        for _ in range(len(lines) + 1):
            done.add(cur)
            q, _, _, _, w = lines[cur]
            width = max(width, w)
            chain.extend(q if side == 0 else q[::-1])
            nxt = link.get((cur, 1 - side))
            if nxt is None:
                if (cur, 1 - side) in onto:
                    chain.append(onto[(cur, 1 - side)])
                break
            chain.extend(nxt[1])
            if nxt[0] == start:
                closed = True
                break
            if nxt[0][0] in done:
                break
            cur, side = nxt[0]
        if not closed and len(chain) > 3 and math.dist(chain[0], chain[-1]) <= max(1.5, width / 2) and \
                length(chain) > 4 * _reach(width):   # come back to its start (carried onto its own first side)
            chain.pop()
            closed = True
        out.append((chain, closed, width))
    return out


def _ray_hit(a, u, q0, q1):
    """(distance along the way ``u`` from ``a``, point) where it meets the segment q0–q1, or None."""
    ex, ey = q1[0] - q0[0], q1[1] - q0[1]
    den = u[0] * ey - u[1] * ex
    if abs(den) < 1e-12:
        return None
    wx, wy = q0[0] - a[0], q0[1] - a[1]
    s = (wx * ey - wy * ex) / den
    t = (wx * u[1] - wy * u[0]) / den
    if s < 0 or t < -1e-9 or t > 1 + 1e-9:
        return None
    return s, (a[0] + u[0] * s, a[1] + u[1] * s)


def _nearest_on(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    L2 = dx * dx + dy * dy
    t = 0. if not L2 else max(0., min(1., ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2))
    return (a[0] + t * dx, a[1] + t * dy)


# --- lines ---------------------------------------------------------------------------------------------------------

def smoothed(points, closed, passes=2, corner=50.):
    """A pixel staircase evened out (1-2-1, ``passes`` times), the corners (a turn of more than ``corner`` degrees over
    two pixels each way) and the ends kept where they are."""
    n = len(points)
    if n < 5:
        return list(points)
    cos_corner = math.cos(math.radians(180 - corner))
    pts = list(points)
    fixed = set()
    for i in range(n):
        if not closed and (i < 2 or i > n - 3):
            fixed.add(i)
            continue
        a, b, c = pts[(i - 2) % n], pts[i], pts[(i + 2) % n]
        u = (a[0] - b[0], a[1] - b[1])
        v = (c[0] - b[0], c[1] - b[1])
        du, dv = math.hypot(*u), math.hypot(*v)
        if du and dv and (u[0] * v[0] + u[1] * v[1]) / (du * dv) > cos_corner:   # sharper than 180 − corner
            fixed.update(((i - 1) % n, i, (i + 1) % n))
    for _ in range(passes):
        new = list(pts)
        for i in range(n):
            if i in fixed:
                continue
            a, b, c = pts[(i - 1) % n], pts[i], pts[(i + 1) % n]
            new[i] = ((a[0] + 2 * b[0] + c[0]) / 4, (a[1] + 2 * b[1] + c[1]) / 4)
        pts = new
    return pts


def _unit(u):
    d = math.hypot(*u)
    return (u[0] / d, u[1] / d) if d else (0., 0.)


def _dp(points, tol):
    """Douglas-Peucker on an open line (its two ends kept)."""
    return [points[i] for i in _dp_kept(points, tol)]


def _dp_kept(points, tol):
    """The indices Douglas-Peucker keeps on an open line (its two ends always)."""
    if len(points) < 3:
        return list(range(len(points)))
    keep = [False] * len(points)
    keep[0] = keep[-1] = True
    todo = [(0, len(points) - 1)]
    tol2 = tol * tol
    while todo:
        a, b = todo.pop()
        ax, ay = points[a]
        bx, by = points[b]
        dx, dy = bx - ax, by - ay
        L2 = dx * dx + dy * dy
        best, far = -1., None
        for i in range(a + 1, b):   # the distance to the segment a–b (written out: min and max cost half the time)
            px, py = points[i]
            ux, uy = px - ax, py - ay
            t = ux * dx + uy * dy
            if t <= 0. or not L2:
                d = ux * ux + uy * uy
            elif t >= L2:
                vx, vy = px - bx, py - by
                d = vx * vx + vy * vy
            else:
                c = ux * dy - uy * dx
                d = c * c / L2
            if d > best:
                best, far = d, i
        if far is not None and best > tol2:
            keep[far] = True
            todo.append((a, far))
            todo.append((far, b))
    return [i for i, k in enumerate(keep) if k]


def simplified(points, closed, tol, cut=0.):
    """The fewest points within ``tol`` of the line (Douglas-Peucker, then the points not needed dropped; a closed line
    cut at its two farthest points). Each corner (one turn of ``SHARP`` degrees or more, or a few turns along ``cut``
    pixels at most: a corner rounded by the blur of a photo or cut off by the thinning) put back where its two sides
    meet, each side the straight line nearest its own points, before the line is simplified again."""
    kept = _kept(points, closed, tol)
    if kept is None:
        return list(points)
    sharp = _sharp(points, kept, closed, tol, cut) if cut > 0 else None
    if sharp is not None:
        again = _kept(sharp, closed, tol)
        if again is not None:
            return [sharp[i] for i in again]
    return [points[i] for i in kept]


def _kept(points, closed, tol):
    n = len(points)
    if n < 3:
        return None
    if not closed:
        return _lean(points, _dp_kept(points, tol), False, tol)
    far = max(range(n), key=lambda i: (points[i][0] - points[0][0]) ** 2 + (points[i][1] - points[0][1]) ** 2)
    a = max(range(n), key=lambda i: (points[i][0] - points[far][0]) ** 2 + (points[i][1] - points[far][1]) ** 2)
    if a > far:
        a, far = far, a
    first = [a + i for i in _dp_kept(points[a:far + 1], tol)]
    second = [(far + i) % n for i in _dp_kept(points[far:] + points[:a + 1], tol)]
    kept = first[:-1] + second[:-1]
    if len(kept) < 3:
        return None
    return _lean(points, kept, True, tol)


def _off(p, line):
    (cx, cy), (ux, uy) = line
    return abs((p[0] - cx) * uy - (p[1] - cy) * ux)


def _sharp(points, kept, closed, tol, cut):
    """``points`` with each corner put back (see ``simplified``); None when there is none."""
    n = len(points)
    m = len(kept)
    if m < 3:
        return None
    acc = [0.]
    for a, b in zip(points, points[1:]):
        acc.append(acc[-1] + math.dist(a, b))
    total = acc[-1] + (math.dist(points[-1], points[0]) if closed else 0.)

    def along(i, j):   # from i forward to j
        d = acc[j] - acc[i]
        return d + total if d < 0 else d

    def turn_at(j):
        prev, p, nxt = points[kept[j - 1]], points[kept[j]], points[kept[(j + 1) % m]]
        u = (p[0] - prev[0], p[1] - prev[1])
        v = (nxt[0] - p[0], nxt[1] - p[1])
        if not (u[0] or u[1]) or not (v[0] or v[1]):
            return 0.
        return abs(math.degrees(math.atan2(u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1])))
    # the corners: kept points turning, those along ``cut`` pixels at most one corner
    marks = [j for j in range(m) if (closed or 0 < j < m - 1) and turn_at(j) >= SHARP / 2]
    if not marks:
        return None
    groups = [[marks[0]]]
    for j in marks[1:]:
        if along(kept[groups[-1][-1]], kept[j]) <= cut and along(kept[groups[-1][0]], kept[j]) <= cut:
            groups[-1].append(j)
        else:
            groups.append([j])
    if closed and len(groups) > 1 and along(kept[groups[-1][-1]], kept[groups[0][0]]) <= cut and \
            along(kept[groups[-1][0]], kept[groups[0][-1]]) <= cut:
        groups[0] = groups.pop() + groups[0]
    spans = [(kept[g[0]], kept[g[-1]]) for g in groups]
    put = {}
    gone = set()
    for k, (g0, g1) in enumerate(spans):
        # the side before: from the corner before (or the line's start) to this one, away from both by half ``cut``
        if closed or k:
            start = spans[k - 1][1] if len(spans) > 1 else g1
            room = along(start, g0) if (start != g1 or len(spans) > 1) else total - along(g0, g1)
        else:
            start, room = 0, acc[g0]
        if closed or k < len(spans) - 1:
            end = spans[(k + 1) % len(spans)][0] if len(spans) > 1 else g0
            room2 = along(g1, end) if (end != g0 or len(spans) > 1) else total - along(g0, g1)
        else:
            end, room2 = n - 1, acc[-1] - acc[g1]
        if min(room, room2) < 2 * cut:
            continue   # sides that short: a curve (a polygon's corners), or a shape too small to tell
        side1 = _stretch(points, g0, -1, cut / 2, min(room - cut / 2, 6 * cut + 4), n, closed, along)
        side2 = _stretch(points, g1, 1, cut / 2, min(room2 - cut / 2, 6 * cut + 4), n, closed, along)
        if len(side1) < 3 or len(side2) < 3:
            continue
        l1, l2 = _fit_line([points[i] for i in side1]), _fit_line([points[i] for i in side2])
        if max(_off(points[i], l1) for i in side1) > 2 * tol or max(_off(points[i], l2) for i in side2) > 2 * tol:
            continue   # not straight: a curve
        u1, u2 = l1[1], l2[1]
        a1 = points[side1[0]]
        if (points[g0][0] - a1[0]) * u1[0] + (points[g0][1] - a1[1]) * u1[1] < 0:
            u1 = (-u1[0], -u1[1])
        b2 = points[side2[-1]]
        if (b2[0] - points[g1][0]) * u2[0] + (b2[1] - points[g1][1]) * u2[1] < 0:
            u2 = (-u2[0], -u2[1])
        if math.degrees(math.acos(max(-1., min(1., u1[0] * u2[0] + u1[1] * u2[1])))) < SHARP:
            continue
        x = _meet(l1, l2)
        if x is None or math.dist(x, points[g0]) > 2 * cut + 2 or math.dist(x, points[g1]) > 2 * cut + 2:
            continue
        lo, hi = g0, g1
        while lo != side1[0] and _off(points[lo], l1) > tol:
            lo = (lo - 1) % n
        while hi != side2[0] and _off(points[hi], l2) > tol:
            hi = (hi + 1) % n
        inside = {(lo + s) % n for s in range(1, (hi - lo) % n)} | {g0}
        if inside & gone or (not closed and (lo > g0 or hi < g1)):
            continue
        gone |= inside
        put[g0] = x
    if not put:
        return None
    return [put[i] if i in put else points[i] for i in range(n) if i in put or i not in gone]


def _stretch(points, at, way, skip, most, n, closed, along):
    """The indices of the points going ``way`` (1: on, −1: back) from ``at``, ``skip`` pixels away from it or more and
    ``most`` at most (never round a closed line more than once, nor past an open line's end), the nearest first."""
    out = []
    i = at
    for _ in range(n - 1):
        i = i + way
        if closed:
            i %= n
        elif not 0 <= i < n:
            break
        d = along(i, at) if way < 0 else along(at, i)
        if d > most:
            break
        if d >= skip:
            out.append(i)
    return out


def _lean(points, kept, closed, tol):
    """``kept`` without the points that are not needed (Douglas-Peucker cuts where the farthest point is, not
    always at a corner; a closed line where it was cut in two): a point goes when the line between its neighbours stays
    within ``tol`` of all the points it stood for."""
    kept = list(kept)
    least = 3 if closed else 2
    for _ in range(2):
        j = 0 if closed else 1
        while len(kept) > least and j < len(kept) - (0 if closed else 1):
            if _within(points, kept[j - 1], kept[(j + 1) % len(kept)], tol):
                del kept[j]
            else:
                j += 1
    return kept


def _within(points, a, b, tol):
    """All the points from index ``a`` to index ``b`` (round a closed line) within ``tol`` of the segment between
    them."""
    n = len(points)
    (ax, ay), (bx, by) = points[a], points[b]
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    i = a
    while i != b:
        px, py = points[i]
        t = max(0., min(1., ((px - ax) * dx + (py - ay) * dy) / L2)) if L2 else 0.
        if (ax + t * dx - px) ** 2 + (ay + t * dy - py) ** 2 > tol * tol:
            return False
        i = (i + 1) % n
    return True


SHARP = 20.   # degrees: a turn that big between two sides is a corner


def length(points, closed=False):
    out = sum(math.dist(a, b) for a, b in zip(points, points[1:]))
    return out + (math.dist(points[-1], points[0]) if closed and len(points) > 1 else 0.)


EDGE_TOL = .75   # pixels: an edge without blur (a scan made black and white) steps by whole pixels
WIDEST = 2.      # « Le milieu des traits »: a spot wider than that many strokes is a shape all the same (its edge)
CUT = 12.        # pixels: a corner rounded by the blur of a photo, as much as that


def trace(gray, w, h, level, dark=True, box=None, mode='auto', stroke_most=6., smallest=8., tol=.5, stop=_never):
    """The lines of the picture: [(points, closed), …] in pixel coordinates.

    ``level``: the gray of the threshold (``dark``: the ink is at it or darker); ``box``: the part read; ``mode``: 'auto'
    (a stroke as wide as ``stroke_most`` pixels or less is followed in its middle, a wider spot by its edge), 'strokes'
    (all in their middle, but a spot ``WIDEST`` times wider: a shape all the same), 'edges' (all by their edges); ``smallest``: a spot smaller than that (pixels, the diagonal of
    its box) is dropped, a spot covering more than half the part read or touching three of its sides is the paper (or
    the table) and dropped too; ``tol``: the lines kept within that of the pixels' (Douglas-Peucker). An edge is drawn where
    the gray crosses the threshold's half-step (``default_level``: the gray halfway between the ink and the paper)."""
    box = tuple(box) if box else (0, 0, w, h)
    mask = mask_of(gray, w, h, level, dark, box)
    runs = row_runs(mask, w, h)
    if stop():
        raise Stopped()
    groups = label(runs, True)
    exposed = exposure(runs)
    bx0, by0, bx1, by1 = box
    whole = (bx1 - bx0) * (by1 - by0)
    outside = 255 if dark else 0
    thresh = level + .5
    lines = []
    thin = []
    filled = {}
    chosen = []
    for group in groups:
        area, per, (x0, y0, x1, y1) = stats(group, exposed)
        if math.hypot(x1 - x0, y1 - y0) < smallest:
            continue
        sides = (x0 <= bx0) + (y0 <= by0) + (x1 >= bx1) + (y1 >= by1)
        if area > whole / 2 or sides >= 3:
            continue
        chosen.append((group, area, per))
    ink = sum(c[1] for c in chosen)
    if len(chosen) > MOST or (len(chosen) > MANY and ink > INKY * whole) or (len(chosen) > MANY // 3 and ink > 2.5 * INKY * whole):
        raise TooMany(len(chosen))
    for group, area, per in chosen:
        if stop():
            raise Stopped()
        width = thickness(area, per)
        widest = WIDEST * stroke_most if mode == 'strokes' else stroke_most
        try:
            if mode != 'edges' and width <= widest:
                thin.extend((points, closed, f0, f1, width) for points, closed, f0, f1 in
                            strokes(group, width, stop, int(widest / 2) + 2))
                continue
        except TooWide:   # (a ragged spot looks thin by its area and its edge: a shape)
            pass
        points = loop(gray, mask, w, h, thresh, outer_start(group), outside, stop)
        lines.append((simplified(smoothed(points, True, 3), True, max(tol, EDGE_TOL), CUT), True))
        for y, rx0, _ in group:
            filled[(y, rx0)] = len(lines) - 1
    for points, closed, width in bridged(thin, stop):
        if length(points, closed) >= smallest:
            lines.append((simplified(smoothed(points, closed), closed, tol, 2 * width + 2), closed))
    if filled:   # the holes of the shapes followed by their edges (never the inside of a stroke's ring)
        holes = label(row_runs(_paper(mask, w, h, box), w, h), False)
        for hole in holes:
            if stop():
                raise Stopped()
            area, _, (x0, y0, x1, y1) = stats(hole)
            if x0 <= bx0 or y0 <= by0 or x1 >= bx1 or y1 >= by1:
                continue   # the paper around everything
            if math.hypot(x1 - x0, y1 - y0) < smallest:
                continue
            y, hx0, _ = min(hole)
            above = next((rx0 for rx0, rx1 in runs[y - 1] if rx0 <= hx0 < rx1), None) if y else None
            if above is None or (y - 1, above) not in filled:
                continue   # inside a stroke's ring (or a spot left out)
            points = loop(gray, mask, w, h, thresh, hole_start(hole), outside, stop)
            lines.append((simplified(smoothed(points, True, 3), True, max(tol, EDGE_TOL), CUT), True))
    return lines


FLIP = b'\x01' + bytes(255)


def _paper(mask, w, h, box):
    """1 for the paper inside ``box``, 0 for the ink and outside it."""
    x0, y0, x1, y1 = box
    if (x0, y0, x1, y1) == (0, 0, w, h):
        return mask.translate(FLIP)
    out = bytearray(len(mask))
    for y in range(y0, y1):
        out[y * w + x0:y * w + x1] = mask[y * w + x0:y * w + x1].translate(FLIP)
    return bytes(out)


# --- the shape around a point ----------------------------------------------------------------------------------------

def flood(mask, w, h, seed, most):
    """The 8-connected ink around the pixel ``seed`` = (x, y): its runs [(y, x0, x1), …]; None when it touches the edge
    of the picture or is bigger than ``most`` pixels."""
    sx, sy = seed
    if not (0 <= sx < w and 0 <= sy < h) or not mask[sy * w + sx]:
        return None
    seen = {}
    out = []
    todo = [(sy, sx)]
    area = 0
    while todo:
        y, x = todo.pop()
        k = y * w
        if not mask[k + x]:
            continue
        left = mask.rfind(b'\x00', k, k + x) + 1 or k
        left = max(left, k)
        right = mask.find(b'\x00', k + x, k + w)
        right = k + w if right < 0 else right
        x0, x1 = left - k, right - k
        row = seen.setdefault(y, set())
        if x0 in row:
            continue
        row.add(x0)
        out.append((y, x0, x1))
        area += x1 - x0
        if area > most or x0 == 0 or x1 == w or y == 0 or y == h - 1:
            return None
        for ny in (y - 1, y + 1):
            nk = ny * w
            for m in RUN.finditer(mask, nk + max(0, x0 - 1), nk + min(w, x1 + 1)):
                todo.append((ny, m.start() - nk))
    return sorted(out)


def _hull(points):
    pts = sorted(set(points))
    if len(pts) < 3:
        return pts

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return lower[:-1] + upper[:-1]


def _fewest(poly, n):
    """``poly`` (convex) cut to its ``n`` most telling corners: the one making the smallest triangle with its two
    neighbours dropped, again and again."""
    pts = list(poly)
    while len(pts) > n:
        k = min(range(len(pts)), key=lambda i: abs((pts[i - 1][0] - pts[i][0]) * (pts[(i + 1) % len(pts)][1] - pts[i][1])
                                                   - (pts[i - 1][1] - pts[i][1]) * (pts[(i + 1) % len(pts)][0] - pts[i][0])))
        pts.pop(k)
    return pts


def _fit_line(points):
    """The straight line nearest the points (least squares across it): (centre, unit direction)."""
    n = len(points)
    cx = sum(p[0] for p in points) / n
    cy = sum(p[1] for p in points) / n
    sxx = sum((p[0] - cx) ** 2 for p in points)
    syy = sum((p[1] - cy) ** 2 for p in points)
    sxy = sum((p[0] - cx) * (p[1] - cy) for p in points)
    angle = .5 * math.atan2(2 * sxy, sxx - syy)
    return (cx, cy), (math.cos(angle), math.sin(angle))


def _meet(l1, l2):
    (ax, ay), (ux, uy) = l1
    (bx, by), (vx, vy) = l2
    d = ux * vy - uy * vx
    if abs(d) < 1e-9:
        return None
    t = ((bx - ax) * vy - (by - ay) * vx) / d
    return (ax + t * ux, ay + t * uy)


def quad_of(points):
    """The four corners of a quadrilateral edge (its points in order round it), from its four sides fitted as lines
    (the points near the corners left out: a corner printed or cut a little round); with the distance of its points to
    their sides (root mean square, pixels). ValueError when it is not one."""
    hull = _hull(points)
    if len(hull) < 4:
        raise ValueError('Forme trop petite.')
    corners = _fewest(hull, 4)
    # the points of each side, between two corners, the eighth of the side nearest each corner left out
    index = {p: i for i, p in enumerate(points)}
    order = sorted(corners, key=lambda c: index.get(c, 0))
    ks = [index[c] for c in order]
    n = len(points)
    sides = []
    for j in range(4):
        a, b = ks[j], ks[(j + 1) % 4]
        span = (b - a) % n
        if span < 8:
            raise ValueError('Forme trop petite.')
        cut = max(1, span // 8)
        sides.append([points[(a + t) % n] for t in range(cut, span - cut + 1)])
    lines = [_fit_line(s) for s in sides]
    out = []
    for j in range(4):
        p = _meet(lines[j - 1], lines[j])
        if p is None:
            raise ValueError('Côtés parallèles.')
        out.append(p)
    err = 0.
    count = 0
    for (c, u), s in zip(lines, sides):
        for p in s:
            err += ((p[0] - c[0]) * u[1] - (p[1] - c[1]) * u[0]) ** 2
            count += 1
    return out, math.sqrt(err / max(1, count))


def area_moments(points):
    """(area, centre, (mxx, myy, mxy)) of the closed line ``points``: the second moments of its surface about its
    centre, divided by its area."""
    a = cx = cy = ixx = iyy = ixy = 0.
    n = len(points)
    for i in range(n):
        x0, y0 = points[i]
        x1, y1 = points[(i + 1) % n]
        c = x0 * y1 - x1 * y0
        a += c
        cx += (x0 + x1) * c
        cy += (y0 + y1) * c
        ixx += (x0 * x0 + x0 * x1 + x1 * x1) * c
        iyy += (y0 * y0 + y0 * y1 + y1 * y1) * c
        ixy += (x0 * y1 + 2 * x0 * y0 + 2 * x1 * y1 + x1 * y0) * c
    a /= 2
    if abs(a) < 1e-9:
        raise ValueError('Forme plate.')
    cx /= 6 * a
    cy /= 6 * a
    mxx = ixx / (12 * a) - cx * cx
    myy = iyy / (12 * a) - cy * cy
    mxy = ixy / (24 * a) - cx * cy
    return abs(a), (cx, cy), (mxx, myy, mxy)


def ellipse_of(points):
    """(centre, half axes (a ≥ b), angle of a) of an elliptic edge from the moments of its surface (a filled ellipse:
    a² / 4 and b² / 4); with how far its points are from that ellipse (root mean square of r − 1)."""
    _, c, (mxx, myy, mxy) = area_moments(points)
    tr = mxx + myy
    det = mxx * myy - mxy * mxy
    root = math.sqrt(max(0., tr * tr / 4 - det))
    l1, l2 = tr / 2 + root, tr / 2 - root
    if l2 <= 0:
        raise ValueError('Forme plate.')
    a, b = 2 * math.sqrt(l1), 2 * math.sqrt(l2)
    angle = .5 * math.atan2(2 * mxy, mxx - myy)
    ca, sa = math.cos(angle), math.sin(angle)
    err = 0.
    for x, y in points:
        u = (x - c[0]) * ca + (y - c[1]) * sa
        v = -(x - c[0]) * sa + (y - c[1]) * ca
        err += (math.hypot(u / a, v / b) - 1) ** 2
    return c, (a, b), angle, math.sqrt(err / len(points))


QUAD_RMS = .9        # pixels: a side that straight (and 0.4 % of its length on a big one)
ELLIPSE_RMS = .02    # of the radius


def shape_at(gray, w, h, seed, box=None):
    """The closed shape around the pixel ``seed`` (inside it, or on its line): dict(kind='quad', corners, rms) or
    dict(kind='ellipse', centre, axes, angle, rms), with its ``edge`` (points round it) and the gray ``level`` used.
    ValueError (said to him) when there is none."""
    sx, sy = (int(seed[0]), int(seed[1]))
    if not (0 <= sx < w and 0 <= sy < h):
        raise ValueError('Cliquer sur l’image.')
    r = max(48, min(w, h) // 4)
    while True:   # around the point, wider until there are two grays
        window = (max(0, sx - r), max(0, sy - r), min(w, sx + r), min(h, sy + r))
        hist = histogram(gray, w, h, window, 2)
        level = otsu(hist)
        if contrast(hist, level) >= 24:
            break
        if window == (0, 0, w, h):
            raise ValueError('Image trop pâle ici pour y trouver une forme.')
        r *= 2
    dark = gray[sy * w + sx] <= level
    mask = mask_of(gray, w, h, level, dark, box)
    group = flood(mask, w, h, (sx, sy), w * h // 2)
    if group is None:
        raise ValueError('Pas de forme fermée autour de ce point : cliquer dans le carré ou le rond.')
    # the threshold again, from the shape and what is round it (the first one only from around the point clicked:
    # inside a big shape, all of one gray)
    _, _, (x0, y0, x1, y1) = stats(group)
    m = max(8, (max(x1 - x0, y1 - y0)) // 10)
    around = (max(0, x0 - m), max(0, y0 - m), min(w, x1 + m), min(h, y1 + m))
    again = histogram(gray, w, h, around, 2)
    second = otsu(again)
    if contrast(again, second) >= 24 and (gray[sy * w + sx] <= second) == dark:
        mask2 = mask_of(gray, w, h, second, dark, box)
        group2 = flood(mask2, w, h, (sx, sy), w * h // 2)
        if group2:
            hist, level, mask, group = again, second, mask2, group2
    # its edge where the gray is halfway between the shape's and what is round it (the pixels split there: an edge
    # always between a pixel at the threshold or below and one above it)
    half = int(edge_level(hist, level))
    if (gray[sy * w + sx] <= half) == dark:
        mask3 = mask_of(gray, w, h, half, dark, box)
        group3 = flood(mask3, w, h, (sx, sy), w * h // 2)
        if group3:
            level, mask, group = half, mask3, group3
    area = sum(x1 - x0 for _, x0, x1 in group)
    if area < 200:
        raise ValueError('Forme trop petite : cliquer dans un carré ou un rond plus grand.')
    at = level + .5
    edge = loop(gray, mask, w, h, at, outer_start(group), 255 if dark else 0)
    out = dict(edge=edge, level=level, dark=dark)
    # a shape drawn with a line: measured on the middle of its line (its edge moved by half the line's width)
    inside, centre, _ = area_moments(edge)
    if area < .5 * inside:   # clicked on the line itself: its outer edge, inward
        move = -area / length(edge, True) / 2
    else:   # inside the line (the paper in a square drawn, a cell of a cutting mat): its inner edge, outward (nothing
        # when no line of the other gray goes round it)
        move = line_width(gray, w, h, edge, centre, at, max(6., .1 * math.sqrt(inside)), dark) / 2
    out['moved'] = move
    try:
        corners, rms = quad_of(edge)
        sides = [math.dist(corners[j], corners[(j + 1) % 4]) for j in range(4)]
        angles = []
        for j in range(4):
            a, b, c = corners[j - 1], corners[j], corners[(j + 1) % 4]
            u = (a[0] - b[0], a[1] - b[1])
            v = (c[0] - b[0], c[1] - b[1])
            angles.append(math.degrees(math.acos(max(-1., min(1., (u[0] * v[0] + u[1] * v[1]) / (math.hypot(*u) * math.hypot(*v)))))))
        if rms <= max(QUAD_RMS, .004 * min(sides)) and min(sides) >= 8 and all(25 <= t <= 155 for t in angles):
            out.update(kind='quad', corners=offset_quad(corners, move) if move else corners, rms=rms)
            return out
    except (ValueError, ZeroDivisionError):
        pass
    c, axes, angle, rms = ellipse_of(edge)
    if rms <= ELLIPSE_RMS:
        out.update(kind='ellipse', centre=c, axes=(axes[0] + move, axes[1] + move), angle=angle, rms=rms)
        return out
    raise ValueError('Forme pas assez nette : ni un carré, ni un rectangle, ni un rond.')


def ordered(corners):
    """The four corners round from the one at the top left (y goes down), clockwise on the screen."""
    cx = sum(p[0] for p in corners) / 4
    cy = sum(p[1] for p in corners) / 4
    out = sorted(corners, key=lambda p: math.atan2(p[1] - cy, p[0] - cx))
    first = min(range(4), key=lambda k: abs((math.atan2(out[k][1] - cy, out[k][0] - cx) + math.radians(135) + math.pi)
                                            % (2 * math.pi) - math.pi))
    return out[first:] + out[:first]


GRID_MOST = 150    # cells of a grid read at most round the one clicked
GRID_NEAR = .25    # of a cell: how far a corner found may be from where the grid puts it


def grid_of(gray, w, h, first, stop=_never, most=GRID_MOST):
    """The cells of the grid the quadrilateral ``first`` (``shape_at``) is in, when it is one (a cutting mat): from
    cell to cell round it, each found where the grid seen so far puts it (``GRID_NEAR``), the same gray and the same
    line. ``(cells, lattice)``: cells {(i, j): corners from the top left}, the cell clicked (0, 0); ``lattice`` the
    projective map from the grid's (i, j) (a cell's corners at whole numbers) to the pixels, fitted to all the corners
    found. None when fewer than ``GRID_LEAST`` cells are found."""
    from collections import deque
    level, dark, move = first['level'], first['dark'], first.get('moved', 0.)
    mask = mask_of(gray, w, h, level, dark)
    at = level + .5
    outside = 255 if dark else 0
    unit = [(0, 0), (1, 0), (1, 1), (0, 1)]
    cells = {(0, 0): ordered(first['corners'])}
    lattice = homography(unit, cells[(0, 0)])
    todo = deque([(1, 0), (-1, 0), (0, 1), (0, -1)])
    seen = {(0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)}
    fitted = 1
    while todo and len(cells) < most:
        if stop():
            raise Stopped()
        i, j = todo.popleft()
        try:
            want = [apply(lattice, (i + u, j + v)) for u, v in unit]
            cx, cy = apply(lattice, (i + .5, j + .5))
        except ValueError:
            continue
        if not (0 <= cx < w and 0 <= cy < h):
            continue
        sides = [math.dist(want[k], want[(k + 1) % 4]) for k in range(4)]
        size = sum(sides) / 4
        if min(sides) < 8:
            continue
        seed = (int(cx + .5), int(cy + .5))
        if not (0 <= seed[0] < w and 0 <= seed[1] < h) or not mask[seed[1] * w + seed[0]]:
            continue
        area = abs(sum(want[k][0] * want[(k + 1) % 4][1] - want[(k + 1) % 4][0] * want[k][1] for k in range(4))) / 2
        group = flood(mask, w, h, seed, int(2 * area) + 50)
        if group is None or not .5 * area <= sum(x1 - x0 for _, x0, x1 in group) <= 1.5 * area:
            continue
        try:
            corners, rms = quad_of(loop(gray, mask, w, h, at, outer_start(group), outside))
        except (ValueError, ZeroDivisionError):
            continue
        if rms > max(QUAD_RMS, .004 * size):
            continue
        q = ordered(offset_quad(corners, move) if move else corners)
        if any(math.dist(q[k], want[k]) > GRID_NEAR * size for k in range(4)):
            continue
        cells[(i, j)] = q
        for n in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)):
            if n not in seen:
                seen.add(n)
                todo.append(n)
        if len(cells) >= 2 * fitted:   # the grid fitted again to all the corners found (farther cells then better put)
            fitted = len(cells)
            lattice = _lattice(cells)
    if len(cells) < GRID_LEAST:
        return None
    lattice = _lattice(cells)
    for _ in range(3):   # (review) a cell partly hidden (a sheet laid on the mat, over less than a quarter of it) was taken
        # with its corners where the sheet's edge is (2.9 px off a grid of 100 px cells), squares side by side that are
        # no grid too (a gap between them, another size: the one clicked 5 % off): the cells off the grid fitted to all of
        # them left out, the grid fitted again
        far = [k for k, q in cells.items() if k != (0, 0) and _off_grid(lattice, k, q)]
        if not far:
            break
        for k in far:
            del cells[k]
        if len(cells) < GRID_LEAST:
            return None
        lattice = _lattice(cells)
    return cells, lattice


GRID_FIT = .05     # of a cell (1 pixel at least): a corner farther than that from the grid fitted to all of them is not one
GRID_LEAST = 3     # cells (review): two pull the grid half way to each other (a square 15 % bigger beside the one clicked:
                   # the one clicked 4 % off), never told apart; the cell alone then, as without a grid


def _off_grid(lattice, key, q):
    """Whether a corner of the cell ``key`` = (i, j), found at ``q``, is off the grid ``lattice``."""
    i, j = key
    most = max(1., GRID_FIT * sum(math.dist(q[k], q[(k + 1) % 4]) for k in range(4)) / 4)
    try:
        return any(math.dist(apply(lattice, (i + u, j + v)), p) > most for (u, v), p in zip(((0, 0), (1, 0), (1, 1), (0, 1)), q))
    except ValueError:
        return True


def _lattice(cells):
    src, dst = [], []
    for (i, j), q in cells.items():
        for (u, v), p in zip(((0, 0), (1, 0), (1, 1), (0, 1)), q):
            src.append((i + u, j + v))
            dst.append(p)
    return homography_fit(src, dst)


def line_width(gray, w, h, edge, centre, at, most, dark=False):
    """The width of the line round a shape (``edge``: its inner edge, the gray ``at``; ``dark``: the shape is the dark
    one, its line light), from the edge outward to where the shape's gray comes back: the middle value of 24 places
    round it; 0 when there is no such line (``most`` pixels at most: wider, it is a background)."""
    n = len(edge)
    found = []
    for k in range(24):
        i = k * n // 24
        (x0, y0), (x1, y1) = edge[(i - 2) % n], edge[(i + 2) % n]
        u = _unit((y1 - y0, x0 - x1))
        px, py = edge[i]
        if (px - centre[0]) * u[0] + (py - centre[1]) * u[1] < 0:
            u = (-u[0], -u[1])
        s, before = 0., float(at)
        while s < most:
            s += .5
            value = _sampled(gray, w, h, px + u[0] * s, py + u[1] * s)
            if value is None:
                break
            if (value <= at) if dark else (value > at):   # back on the shape's gray: where it crossed ``at``
                found.append(s - .5 + .5 * (at - before) / (value - before) if value != before else s)
                break
            before = value
    if len(found) < 12:
        return 0.
    found.sort()
    return found[len(found) // 2]


def _sampled(gray, w, h, x, y):
    """The gray at the point (x, y), between the four pixels round it; None outside the picture."""
    i, j = math.floor(x), math.floor(y)
    if not (0 <= i < w - 1 and 0 <= j < h - 1):
        return None
    fx, fy = x - i, y - j
    k = j * w + i
    top = gray[k] + (gray[k + 1] - gray[k]) * fx
    low = gray[k + w] + (gray[k + w + 1] - gray[k + w]) * fx
    return top + (low - top) * fy


def offset_quad(corners, d):
    """The quadrilateral with each side moved by ``d`` (outward when positive)."""
    cx = sum(p[0] for p in corners) / 4
    cy = sum(p[1] for p in corners) / 4
    lines = []
    for j in range(4):
        a, b = corners[j], corners[(j + 1) % 4]
        u = _unit((b[0] - a[0], b[1] - a[1]))
        n = (u[1], -u[0])
        if (a[0] - cx) * n[0] + (a[1] - cy) * n[1] < 0:
            n = (-n[0], -n[1])
        lines.append(((a[0] + n[0] * d, a[1] + n[1] * d), u))
    out = []
    for j in range(4):
        p = _meet(lines[j - 1], lines[j])
        out.append(p if p is not None else corners[j])
    return out


# --- straightening ------------------------------------------------------------------------------------------------------

def _solve(a, b):
    """``a`` x = ``b`` (Gauss, partial pivoting)."""
    n = len(b)
    m = [row[:] + [v] for row, v in zip(a, b)]
    for col in range(n):
        piv = max(range(col, n), key=lambda r: abs(m[r][col]))
        if abs(m[piv][col]) < 1e-12:
            raise ValueError('Points alignés.')
        m[col], m[piv] = m[piv], m[col]
        for r in range(n):
            if r != col:
                f = m[r][col] / m[col][col]
                if f:
                    m[r] = [x - f * y for x, y in zip(m[r], m[col])]
    return [m[r][n] / m[r][r] for r in range(n)]


def _normalizing(points):
    cx = sum(p[0] for p in points) / len(points)
    cy = sum(p[1] for p in points) / len(points)
    d = sum(math.hypot(p[0] - cx, p[1] - cy) for p in points) / len(points) or 1.
    s = math.sqrt(2) / d
    return [[s, 0, -s * cx], [0, s, -s * cy], [0, 0, 1]]


def _mul(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]


def inverse(m):
    (a, b, c), (d, e, f), (g, h, i) = m
    det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g)
    if abs(det) < 1e-18:
        raise ValueError('Transformation impossible.')
    return [[(e * i - f * h) / det, (c * h - b * i) / det, (b * f - c * e) / det],
            [(f * g - d * i) / det, (a * i - c * g) / det, (c * d - a * f) / det],
            [(d * h - e * g) / det, (b * g - a * h) / det, (a * e - b * d) / det]]


def homography(src, dst):
    """The 3 × 3 projective map sending the four points ``src`` onto ``dst`` (normalized coordinates, Hartley)."""
    ns, nd = _normalizing(src), _normalizing(dst)
    s = [apply(ns, p) for p in src]
    d = [apply(nd, p) for p in dst]
    a, b = [], []
    for (x, y), (u, v) in zip(s, d):
        a.append([x, y, 1, 0, 0, 0, -x * u, -y * u])
        b.append(u)
        a.append([0, 0, 0, x, y, 1, -x * v, -y * v])
        b.append(v)
    h = _solve(a, b)
    m = [[h[0], h[1], h[2]], [h[3], h[4], h[5]], [h[6], h[7], 1.]]
    out = _mul(inverse(nd), _mul(m, ns))
    k = out[2][2] or 1.
    return [[v / k for v in row] for row in out]


def homography_fit(src, dst):
    """The projective map sending the points ``src`` onto ``dst`` at best (least squares on the normalized points:
    4 points or more)."""
    if len(src) == 4:
        return homography(src, dst)
    ns, nd = _normalizing(src), _normalizing(dst)
    s = [apply(ns, p) for p in src]
    d = [apply(nd, p) for p in dst]
    ata = [[0.] * 8 for _ in range(8)]
    atb = [0.] * 8
    for (x, y), (u, v) in zip(s, d):
        for row, rhs in (((x, y, 1., 0., 0., 0., -x * u, -y * u), u), ((0., 0., 0., x, y, 1., -x * v, -y * v), v)):
            for a in range(8):
                ra = row[a]
                if ra:
                    atb[a] += ra * rhs
                    line = ata[a]
                    for b in range(8):
                        line[b] += ra * row[b]
    h = _solve(ata, atb)
    m = [[h[0], h[1], h[2]], [h[3], h[4], h[5]], [h[6], h[7], 1.]]
    out = _mul(inverse(nd), _mul(m, ns))
    k = out[2][2] or 1.
    return [[v / k for v in row] for row in out]


def apply(m, p):
    x, y = p
    z = m[2][0] * x + m[2][1] * y + m[2][2]
    if abs(z) < 1e-15:
        raise ValueError('Point à l’infini.')
    return ((m[0][0] * x + m[0][1] * y + m[0][2]) / z, (m[1][0] * x + m[1][1] * y + m[1][2]) / z)


def warp(rgb, sw, sh, to_source, origin, step, W, H, stop=_never):
    """The new picture (W × H pixels, RGB bytes from the top row): its pixel (u, v) shows the point origin + (u + ½,
    v + ½) × step of the plan, taken in the old picture (sw × sh, RGB) at ``to_source`` of it (a projective map plane →
    the old picture's pixel edges: its pixel (i, j) covers [i, i + 1) × [j, j + 1)); white where the old one is not."""
    planes = [rgb[k::3] + b'\xff' for k in range(3)]
    white = sw * sh
    out = bytearray(W * H * 3)
    (a, b, c), (d, e, f), (g, hh, i) = to_source
    ox, oy = origin
    us = range(W)
    A, D, G = a * step, d * step, g * step
    gets = [p.__getitem__ for p in planes]
    for v in range(H):
        if not v & 31 and stop():
            raise Stopped()
        y = oy + (v + .5) * step
        x0 = ox + .5 * step
        X0 = a * x0 + b * y + c
        Y0 = d * x0 + e * y + f
        Z0 = g * x0 + hh * y + i
        zs = [z if z > 1e-12 else 1e-12 for z in (G * u + Z0 for u in us)]
        idx = [(int(Y) * sw + int(X)) if 0 <= X < sw and 0 <= Y < sh else white
               for X, Y in (((A * u + X0) / z, (D * u + Y0) / z) for u, z in zip(us, zs))]
        row = v * W * 3
        for k in range(3):
            out[row + k:row + 3 * W:3] = bytes(map(gets[k], idx))
    return bytes(out)


# --- 0.19.54 « contour d’une pièce en un clic », « une peau prise en photo » : la pièce entière autour d’un clic -----------

def color_at(rgb, w, h, seed, k=3):
    """The colour round the pixel ``seed``: each channel's middle value over the (2k + 1)² pixels round it."""
    sx, sy = seed
    out = []
    for c in range(3):
        vals = sorted(rgb[(y * w + x) * 3 + c] for y in range(max(0, sy - k), min(h, sy + k + 1))
                      for x in range(max(0, sx - k), min(w, sx + k + 1)))
        out.append(vals[len(vals) // 2])
    return tuple(out)


def distance_of(rgb, color):
    """How far each pixel's colour is from ``color``: (|r − r0| + |g − g0| + |b − b0|) / 3, a byte each (0: the same
    colour). A white cardboard is far from the green of a cutting mat, near its white lines (``opened`` cuts those off);
    a strong light reflection on a black leather is far from the leather too: one touching its edge leaves a dent there
    (review 0.19.54: up to 6 mm; a photo in a soft light). Each part a third of its channel's difference at most 85: the
    three added byte by byte as big numbers (no byte carries)."""
    n = len(rgb) // 3
    total = 0
    for k in range(3):
        table = bytes(abs(v - color[k]) // 3 for v in range(256))
        total += int.from_bytes(rgb[k::3].translate(table), 'big')
    return total.to_bytes(n, 'big')


_COLUMNS = {}   # (0.19.55) the column masks of _Morph._shifted, by (row width, pixels, shift); the oldest dropped
COLUMNS_MOST = 32_000_000   # bytes the masks kept take at most (a pixel a byte each)
_COLUMNS_LOCK = __import__('threading').Lock()


class _Morph:
    """Erosion and dilation of a mask (a byte 0 or 1 a pixel) by the 3 × 3 square, each row of pixels a byte of one big
    number: no Python loop over the pixels (3 × 3: the eight neighbours; beyond the picture: nothing)."""

    def __init__(self, w, h):
        self.n = w * h
        self.first = int.from_bytes((b'\x00' + b'\x01' * (w - 1)) * h, 'little')   # every pixel but the first of its row
        self.last = int.from_bytes((b'\x01' * (w - 1) + b'\x00') * h, 'little')    # every pixel but the last of its row
        self.full = int.from_bytes(b'\x01' * self.n, 'little')
        self.row = 8 * w

    def erode(self, v, r):
        for _ in range(r):
            across = v & ((v << 8) & self.first) & ((v >> 8) & self.last)
            v = across & ((across << self.row) & self.full) & (across >> self.row)
        return v

    def dilate(self, v, r):
        for _ in range(r):
            across = v | ((v << 8) & self.first) | ((v >> 8) & self.last)
            v = (across | (across << self.row) | (across >> self.row)) & self.full
        return v

    def bytes_of(self, v):
        return v.to_bytes(self.n, 'little')

    def _columns(self, s):
        """(every pixel but the first s of its row, every pixel but the last s), kept for the same size (the same crop
        is opened again and again)."""
        w = self.row // 8
        key = (w, self.n, s)
        held = _COLUMNS.get(key)
        if held is None:
            k = min(s, w)
            held = (int.from_bytes((b'\x00' * k + b'\x01' * (w - k)) * (self.n // w), 'little'),
                    int.from_bytes((b'\x01' * (w - k) + b'\x00' * k) * (self.n // w), 'little'))
            with _COLUMNS_LOCK:   # (the lines' window and a piece's contour may each be read in a worker thread)
                while _COLUMNS and sum(2 * n for _, n, _ in _COLUMNS) + 2 * self.n > COLUMNS_MOST:   # (review: by size)
                    _COLUMNS.pop(next(iter(_COLUMNS)))
                _COLUMNS[key] = held
        return held

    def _shifted(self, v, s, union):
        first, last = self._columns(s)
        if union:
            across = v | ((v << 8 * s) & first) | ((v >> 8 * s) & last)
            return (across | (across << self.row * s) | (across >> self.row * s)) & self.full
        across = v & ((v << 8 * s) & first) & ((v >> 8 * s) & last)   # (beyond the picture: nothing)
        return across & ((across << self.row * s) & self.full) & (across >> self.row * s)

    def grow(self, v, r):
        """(0.19.55) As dilate(v, r) (the square of 2r + 1 pixels), in a few steps for a big r: a square of half side t
        and the 9 points {−s, 0, s}² make the square of half side t + s while s ≤ 2t + 1. (Review: each step is cut at
        the picture's edge: a pixel set within r / 3 of it may miss some of its square there; every crop opened here
        keeps r + 2 pixels round what is set, so the same pixels: only a piece within 6 mm of the photo's edge in
        _sheen, harmless. Exact at the edge too with s ≤ t + 1: 10 ms more a piece.)"""
        t = 0
        while t < r:
            s = min(2 * t + 1, r - t)
            v = self._shifted(v, s, True)
            t += s
        return v

    def shrink(self, v, r):
        """(0.19.55) As erode(v, r), in a few steps (the same squares)."""
        t = 0
        while t < r:
            s = min(2 * t + 1, r - t)
            v = self._shifted(v, s, False)
            t += s
        return v


LINE_MM = .6     # mm: a line as thin as that touching the piece (a line of a cutting mat of the piece's colour) is cut off
OPEN_MOST = 8    # pixels: the most the piece is opened by (the lines of a mat thicker than that: the piece is said to leak)


def _runs_mask(group, w, h, box=None):
    """The mask (1 byte a pixel) of a group of runs, within ``box`` = (x0, y0, x1, y1) (its own coordinates) or all."""
    x0, y0, x1, y1 = box or (0, 0, w, h)
    cw = x1 - x0
    out = bytearray(cw * (y1 - y0))
    one = b'\x01' * cw
    for y, a, b in group:
        k = (y - y0) * cw - x0
        out[k + a:k + b] = one[:b - a]
    return bytes(out)


def _nearest_set(mask, w, h, seed, reach):
    """The set pixel nearest ``seed`` within ``reach`` pixels (the seed itself first), None when there is none."""
    sx, sy = seed
    best = None
    for y in range(max(0, sy - reach), min(h, sy + reach + 1)):
        k = y * w
        for x in range(max(0, sx - reach), min(w, sx + reach + 1)):
            if mask[k + x]:
                d = (x - sx) ** 2 + (y - sy) ** 2
                if best is None or d < best[0]:
                    best = (d, x, y)
    return None if best is None else (best[1], best[2])


def opened(mask, w, h, seed, radius):
    """The part of ``mask`` round ``seed`` once what is thinner than 2 × radius + 1 pixels is cut off it (an opening:
    eroded, the part round the seed kept, dilated back): its runs, None when nothing of it is left round the seed or it
    still reaches the picture's edge (a piece may fill most of the picture: only its edge tells the background)."""
    m = _Morph(w, h)
    v = int.from_bytes(mask, 'little')
    eroded = m.bytes_of(m.shrink(v, radius))
    start = _nearest_set(eroded, w, h, seed, radius + 2)
    if start is None:
        return None
    core = flood(eroded, w, h, start, w * h)
    if core is None:
        return None
    grown = m.bytes_of(m.grow(int.from_bytes(_runs_mask(core, w, h), 'little'), radius) & v)
    return flood(grown, w, h, start, w * h)


def _region(dist, w, h, seed, level, box, radius):
    """The piece's runs at the colour distance ``level``: the pixels as near the clicked colour, round the click, opened
    (in the piece's own box when it does not leak; the whole picture when it does). ValueError when it reaches the
    picture's edge (or the part of it shown)."""
    mask = mask_of(dist, w, h, level, True, box)
    group = flood(mask, w, h, seed, w * h)
    if group is not None:
        _, _, (x0, y0, x1, y1) = stats(group)
        p = radius + 2
        crop = (max(0, x0 - p), max(0, y0 - p), min(w, x1 + p), min(h, y1 + p))
        cw, ch = crop[2] - crop[0], crop[3] - crop[1]
        inner = _runs_mask(group, w, h, crop)
        local = opened(inner, cw, ch, (seed[0] - crop[0], seed[1] - crop[1]), radius)
        if local:   # (a piece thinner than the opening is kept as it is)
            group = [(y + crop[1], a + crop[0], b + crop[0]) for y, a, b in local]
    else:
        group = opened(mask, w, h, seed, radius)
    if group is None:
        raise ValueError('La pièce touche le bord de la photo, ou rien ne la sépare de ce qui l’entoure : '
                         'la photo doit montrer toute la pièce, sur un fond d’une autre couleur.')
    _, _, (x0, y0, x1, y1) = stats(group)
    bx0, by0, bx1, by1 = box or (0, 0, w, h)
    if x0 <= bx0 or y0 <= by0 or x1 >= bx1 or y1 >= by1:
        raise ValueError('La pièce touche le bord de la photo : la photo doit montrer toute la pièce.')
    return _runs_mask(group, w, h), sorted(group)


def _signed_area(pts):
    return .5 * sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(pts, pts[1:] + pts[:1]))


def _outward(edge, i, sign):
    (x0, y0), (x1, y1) = edge[(i - 2) % len(edge)], edge[(i + 2) % len(edge)]
    tx, ty = _unit((x1 - x0, y1 - y0))
    return (ty * sign, -tx * sign)


def ring_width(gray, w, h, edge, at, most, places=48):
    """The width of a line drawn round the shape (``edge``: its inner edge, where ``gray`` crosses ``at``; the shape the
    low values), from the edge outward to where the shape's values come back: their middle value over ``places`` places
    round it, only when they all agree (a pattern drawn on paper, its line of one width); 0 else (a piece on a cutting
    mat: the gaps to the mat's lines change along it; or nothing comes back)."""
    n = len(edge)
    if n < 16:
        return 0.
    sign = 1 if _signed_area(edge) > 0 else -1
    found = []
    for k in range(places):
        i = k * n // places
        ox, oy = _outward(edge, i, sign)
        px, py = edge[i]
        s, before = 0., float(at)
        while s < most:
            s += .5
            value = _sampled(gray, w, h, px + ox * s, py + oy * s)
            if value is None:
                break
            if value <= at:
                back = s - .5 + .5 * (at - before) / (value - before) if value != before else s
                # (review 0.19.54) the shape's colour goes on beyond the line (the paper round a pattern drawn), not
                # only a thin line of it (a white cardboard put 2 mm inside the white lines of a cutting mat: the green
                # between was « its line », the piece made 2 mm too big each way): else on beyond that thin line
                t, beyond = s, value
                while t < s + max(2., back) and beyond is not None and beyond <= at:
                    t += .5
                    beyond = _sampled(gray, w, h, px + ox * t, py + oy * t)
                if beyond is None or beyond <= at:
                    found.append(back)
                    break
                s, before = t, beyond
                continue
            before = value
    if len(found) < .85 * places:
        return 0.
    found.sort()
    q1, mid, q3 = found[len(found) // 4], found[len(found) // 2], found[3 * len(found) // 4]
    if q3 - q1 > max(1.5, .35 * mid):
        return 0.
    return mid


def pushed(edge, d):
    """The edge moved outward by d pixels (each point along the normal of its neighbours)."""
    sign = 1 if _signed_area(edge) > 0 else -1
    out = []
    for i, (x, y) in enumerate(edge):
        ox, oy = _outward(edge, i, sign)
        out.append((x + ox * d, y + oy * d))
    return out


def _nearest_class(hist, level, wide):
    """(review 0.19.54) (level, upper): the threshold that parts the colour clicked from the NEAREST other one. Otsu over
    a window mostly of mat (a strap of black leather, 15 to 30 mm wide, on the green mat with its white lines; navy blue
    or dark green leather 80 mm wide too) parted the leather AND the green from the white lines: the strap and the cells
    round it were « the piece » (9 to 13 mm off, up to 44 false crans), or it was refused. Its lower class split again
    while it holds two colours apart: 16 of contrast, almost nothing between them, the farther a WIDE part of the picture
    (``wide``: the cells of the mat), never only thin lines (the blur of the white lines round a white cardboard, the
    edge's own blur); ``upper``: the end of the nearer colour (the edge half way to it, not to the white lines)."""
    upper = 255
    while level > 0:
        lower = hist[:level + 1] + [0] * (255 - level)
        sub = otsu(lower)
        low, high = sum(lower[:sub + 1]), sum(lower[sub + 1:])
        if sub >= level or contrast(lower, sub) < 16 or high < .1 * (low + high):
            break
        smooth = [sum(lower[max(0, k - 2):k + 3]) / 5 for k in range(level + 1)]
        if min(smooth[max(0, sub - 2):sub + 3]) > .2 * min(max(smooth[:sub + 1]), max(smooth[sub + 1:])):
            break
        if not wide(sub, level):
            break
        upper, level = level, sub
    return level, upper


def _wide(dist, w, box, radius):
    """For _nearest_class: whether the colours from ``low`` (excluded) to ``high`` fill a wide part of ``box`` (a quarter
    of them still there once eroded by radius + 2 pixels: the mat's cells, not its lines nor the blur of an edge)."""
    x0, y0, x1, y1 = box
    held = []

    def wide(low, high):
        if not held:   # (read once, only when a lower class is split)
            held.extend((b''.join(dist[y * w + x0:y * w + x1] for y in range(y0, y1)), _Morph(x1 - x0, y1 - y0)))
        rows, m = held
        band = rows.translate(bytes(int(low < v <= high) for v in range(256)))
        total = band.count(1)
        return bool(total) and m.shrink(int.from_bytes(band, 'little'), radius + 2).bit_count() >= .25 * total
    return wide


def piece_region(rgb, w, h, seed, box=None, px_mm=None, stop=_never):
    """The piece round the pixel ``seed`` (a click inside it): dict(edge (points all round it, pixels: where the colour
    turns half way from the piece's to what is round it; drawn with a line on paper: the middle of the line), color,
    level, width (of the line drawn round it, 0 for a piece), area (pixels), radius (of the opening)). The colour
    clicked against what is round it (``distance_of``, then the threshold as ``shape_at``: round the click, wider until
    two colours are found, then round the piece found); the lines of a cutting mat of the piece's colour touching it cut
    off (``opened``, ``LINE_MM``). ValueError when there is no piece (said to him)."""
    sx, sy = int(seed[0]), int(seed[1])
    if not (0 <= sx < w and 0 <= sy < h):
        raise ValueError('Cliquer sur l’image.')
    color = color_at(rgb, w, h, (sx, sy))
    dist = distance_of(rgb, color)
    if stop():
        raise Stopped()
    r = max(48, min(w, h) // 4)
    while True:
        window = (max(0, sx - r), max(0, sy - r), min(w, sx + r), min(h, sy + r))
        hist = histogram(dist, w, h, window, 2)
        level = otsu(hist)
        if contrast(hist, level) >= 16:
            break
        if window == (0, 0, w, h):
            raise ValueError('Pas de bord autour de ce point : la pièce et ce qui l’entoure ont la même couleur.')
        r *= 2
    radius = max(1, min(OPEN_MOST, math.ceil((LINE_MM / px_mm - 1) / 2))) if px_mm else 2
    level, _ = _nearest_class(hist, level, _wide(dist, w, window, radius))
    region, group = _region(dist, w, h, (sx, sy), level, box, radius)
    if stop():
        raise Stopped()
    # the threshold again, from the piece and what is round it, its edge half way between their colours
    _, _, (x0, y0, x1, y1) = stats(group)
    m = max(8, max(x1 - x0, y1 - y0) // 10)
    around = (max(0, x0 - m), max(0, y0 - m), min(w, x1 + m), min(h, y1 + m))
    again = histogram(dist, w, h, around, 2)
    second = otsu(again)
    if contrast(again, second) >= 16:
        second, upper = _nearest_class(again, second, _wide(dist, w, around, radius))
        half = int(edge_level(again[:upper + 1] + [0] * (255 - upper), second))
        if dist[sy * w + sx] <= half:
            try:
                region, group = _region(dist, w, h, (sx, sy), half, box, radius)
                level = half
            except ValueError:
                pass
    region, group, dist = _sheen(rgb, w, h, region, group, dist, color, px_mm, (sx, sy), level)   # 0.19.55: a reflection at the edge
    size = sum(b - a for _, a, b in group)
    if size < 200:
        raise ValueError('Pièce trop petite : cliquer dans une pièce plus grande, ou zoomer la photo.')
    at = level + .5
    edge = loop(dist, region, w, h, at, outer_start(group), 255, stop)
    width = 0.
    if px_mm:
        width = ring_width(dist, w, h, edge, at, max(4., 3. / px_mm))
        if width:
            edge = pushed(edge, width / 2)
    return dict(edge=edge, color=color, level=level, width=width, area=size, radius=radius)


# --- 0.19.55 « toutes les pièces d’une photo d’un coup » (proposé le 27/11/2026, « 3 propositions ok ») ---------------
SEEDS_MM = .5      # mm: the photo read every that much to find the pieces on it (each then traced as a click in it)
SEEDS_OPEN = 1.5   # mm: what is thinner than twice that (a cutting mat's lines, its figures) is no piece
SEEDS_LEAST = 150.   # mm²: a smaller spot is no piece (a speck, a mark of the mat)


def piece_seeds(rgb, w, h, box=None, px_mm=None, stop=_never):
    """A pixel well inside each piece lying on the photo's background (the colour all round the photo's edge): the
    photo read every ``SEEDS_MM``, what is not of the background's colour (Otsu) opened by ``SEEDS_OPEN`` (the mat's
    lines cut off), each spot of ``SEEDS_LEAST`` at least clear of the photo's edge: the middle of the longest run of
    its middle row (of its longest one when the middle row has none). (The seeds (x, y, the spot's area in mm²) in
    reading order, how many spots of SEEDS_LEAST at least touch the photo's edge (review: said to him, as LIRE_MOI
    says)); ([], 0) when nothing stands out."""
    x0, y0, x1, y1 = box or (0, 0, w, h)
    px = px_mm or 1.
    s = max(1, round(SEEDS_MM / px))
    sw, sh = len(range(x0, x1, s)), len(range(y0, y1, s))
    if sw < 8 or sh < 8:
        return [], 0
    small = bytearray(sw * sh * 3)
    for j, y in enumerate(range(y0, y1, s)):
        row = rgb[(y * w + x0) * 3:(y * w + x1) * 3]
        k = j * sw * 3
        for c in range(3):
            small[k + c:k + sw * 3:3] = row[c::3 * s][:sw]
    if stop():
        raise Stopped()
    ring = [i for j in (0, 1, sh - 2, sh - 1) for i in range(j * sw, (j + 1) * sw)]
    ring += [i for j in range(2, sh - 2) for i in (j * sw, j * sw + 1, j * sw + sw - 2, j * sw + sw - 1)]
    from collections import Counter   # the background: the commonest colour all round (a line of the mat on the edge
    binned = lambda i: (small[i * 3] >> 3, small[i * 3 + 1] >> 3, small[i * 3 + 2] >> 3)   # moved the middle one)
    mean = lambda own: tuple(round(sum(small[i * 3 + c] for i in own) / len(own)) for c in range(3))
    top = Counter(map(binned, ring)).most_common(1)[0][0]
    back = mean([i for i in ring if binned(i) == top])
    found = _seeds_on(small, sw, sh, ring, back, px, s, (x0, y0), stop)
    # (review) the mat smaller than the photo (the table all round it, or along a side): the pieces lie on the colour
    # the photo has most of, not on the table (before: the mat one spot, a square of it made a piece, the pieces lost);
    # the reading that finds more pieces kept, never counting a spot of the colour round the photo (a big piece filling
    # most of the photo: its holes, the mat seen through them)
    every = range(0, sw * sh, 7)   # (one sample in 7 tells the commonest)
    most = Counter(map(binned, every)).most_common(1)[0][0]
    if most != top:
        own = [i for i in every if binned(i) == most]
        other = mean(own)
        apart = lambda colour: max(abs(a - b) for a, b in zip(colour, back)) >= 24
        if apart(other):
            seeds, cut = _seeds_on(small, sw, sh, own, other, px, s, (x0, y0), stop)
            at = lambda x, y: (((y - y0) // s) * sw + (x - x0) // s) * 3
            seeds = [(x, y, a) for x, y, a in seeds if apart(small[at(x, y):at(x, y) + 3])]
            if len(seeds) > len(found[0]):
                found = seeds, cut
    return found


def _seeds_on(small, sw, sh, own, back, px, s, origin, stop):
    """piece_seeds on the background colour ``back`` (``own``: samples of it, where its own spread is read)."""
    x0, y0 = origin
    dist = distance_of(bytes(small), back)
    hist = histogram(dist, sw, sh, (0, 0, sw, sh), 1)
    level = otsu(hist)
    if contrast(hist, level) < 16:
        return [], 0
    r = max(1, round(SEEDS_OPEN / (px * s)))
    # the background's end: the first gap of the colours after its own (a black leather is nearer the green mat than
    # its white lines, and too little of the photo for Otsu: with the mat)
    own_hist = [0] * 256
    for i in own:
        own_hist[dist[i]] += 1
    run, low = 0, .001 * sum(hist)
    for v in range(max(range(256), key=own_hist.__getitem__) + 1, 256):
        run = run + 1 if hist[v] <= low else 0
        if run >= 8:
            level = min(level, v - run)
            break
    mask = mask_of(dist, sw, sh, level, False)
    m = _Morph(sw, sh)
    v = int.from_bytes(mask, 'little')
    opened_mask = m.bytes_of(m.grow(m.shrink(v, r), r) & v)
    if stop():
        raise Stopped()
    out, cut = [], 0
    for group in label(row_runs(opened_mask, sw, sh)):
        area, _, (gx0, gy0, gx1, gy1) = stats(group)
        if area * (px * s) ** 2 < SEEDS_LEAST:
            continue
        if gx0 <= 1 or gy0 <= 1 or gx1 >= sw - 1 or gy1 >= sh - 1:
            cut += gx1 - gx0 < .9 * sw and gy1 - gy0 < .9 * sh   # (a strip of table along a side, all its length: no piece)
            continue
        middle = (gy0 + gy1 - 1) // 2
        runs = [run for run in group if run[0] == middle] or group
        y, a, b = max(runs, key=lambda run: run[2] - run[1])
        out.append((x0 + (a + b - 1) // 2 * s, y0 + y * s, area * (px * s) ** 2))
    return out, cut


# --- 0.19.55 « un reflet au bord d’un cuir noir sans creux dans le contour » (proposé le 27/11/2026, « 3 propositions ok »)
SHEEN_MM = 6.    # mm: a light reflection on the piece reaching its edge, at most that far in (a lamp on a glossy leather)
SHEEN_LINE = 1.2   # mm: a spot of it thinner than that is a line of the mat (a reflection, wider, is kept)


def _channel_rows(rgb, w, crop):
    x0, y0, x1, y1 = crop
    return b''.join(rgb[(y * w + x0) * 3:(y * w + x1) * 3] for y in range(y0, y1))


def _rows_mask(rows, n):
    out = bytearray(n)
    for a, b in rows:
        out[a:b] = b'\x01' * (b - a)
    return bytes(out)


def _sheen(rgb, w, h, region, group, dist, color, px_mm, seed, level):
    """The pixels of a reflection on the piece where it reaches its edge (a glossy black leather under a lamp: a dent up
    to 6 mm in the edge before, or a false cran) given back to the piece: next to it, within ``SHEEN_MM``, of none of the
    hue of what lies round it (a green mat, its shadows: green; the reflection gray or white), in spots wider than a line
    of the mat (``SHEEN_LINE``: opened), never reaching SHEEN_MM away (a line, another piece). (region, group, dist), the
    pixels added at distance 0 (the edge drawn where they meet the mat); as they were when what lies round the piece has
    no hue of its own (a gray table, white paper: a reflection would be them) or the piece has the same."""
    if not px_mm:
        return region, group, dist
    _, _, (gx0, gy0, gx1, gy1) = stats(group)
    g = math.ceil(SHEEN_MM / px_mm)
    crop = (max(0, gx0 - g - 2), max(0, gy0 - g - 2), min(w, gx1 + g + 2), min(h, gy1 + g + 2))
    cx0, cy0, cx1, cy1 = crop
    cw, ch = cx1 - cx0, cy1 - cy0
    m = _Morph(cw, ch)
    reg = int.from_bytes(b''.join(region[y * w + cx0:y * w + cx1] for y in range(cy0, cy1)), 'little')
    pixels = _channel_rows(rgb, w, crop)
    # what lies round the piece: the commonest colour on the rectangle 1,5 mm round its box
    d = math.ceil(1.5 / px_mm)
    rx0, ry0, rx1, ry1 = max(cx0, gx0 - d), max(cy0, gy0 - d), min(cx1 - 1, gx1 - 1 + d), min(cy1 - 1, gy1 - 1 + d)
    step = max(1, (2 * (rx1 - rx0 + ry1 - ry0)) // 4000)
    seen = [((y - cy0) * cw + x - cx0) for x in range(rx0, rx1 + 1, step) for y in (ry0, ry1)]
    seen += [((y - cy0) * cw + x - cx0) for y in range(ry0, ry1 + 1, step) for x in (rx0, rx1)]
    from collections import Counter
    bins = Counter((pixels[i * 3] >> 3, pixels[i * 3 + 1] >> 3, pixels[i * 3 + 2] >> 3) for i in seen)
    top = bins.most_common(1)[0][0]
    alike = [i for i in seen if (pixels[i * 3] >> 3, pixels[i * 3 + 1] >> 3, pixels[i * 3 + 2] >> 3) == top]
    back = [sum(pixels[i * 3 + c] for i in alike) / len(alike) for c in range(3)]
    mx, mz = back[0] - back[1], back[2] - back[1]
    hue = math.hypot(mx, mz)
    if hue < 24 or ((color[0] - color[1]) * mx + (color[2] - color[1]) * mz) / hue >= .5 * hue:
        return region, group, dist
    # each pixel's hue along the mat's (r·a + g·b + b·c, a + b + c = 0), a sixth of it plus 147 a byte: three tables added
    # byte by byte as big numbers (each part at most 86, 121, 86: no byte carries)
    coef = (mx / hue, -(mx + mz) / hue, mz / hue)
    total = 0
    for k, base in enumerate((43, 61, 43)):
        table = bytes(round(coef[k] * v / 6) + base for v in range(256))
        total += int.from_bytes(pixels[k::3].translate(table), 'big')
    along = total.to_bytes(cw * ch, 'big')
    other = int.from_bytes(along.translate(bytes(int(v < 147 + hue / 12) for v in range(256))), 'little')
    clear = int.from_bytes(along.translate(bytes(int(v < 147 + hue / 24) for v in range(256))), 'little')
    far = m.grow(reg, g)
    loose = other & far & ~reg & m.full
    r = max(1, math.ceil((SHEEN_LINE / px_mm - 1) / 2))
    cand = m.grow(m.shrink(loose, r), r) & loose
    if not cand:
        return region, group, dist
    # (review) and less than half the hue a pixel of the mat's colour as bright has: never a shadow on the mat (its
    # colour, darker: less hue, as much for its brightness; before, one at 35 % of its light, 2 mm wide along two sides,
    # made a card or a natural leather 2,7 mm bigger): hue − λ·(r + g + b) < 0, three tables again (only when there is
    # something to take: the opening of less is less)
    lam = .5 * hue / max(1., sum(back))   # (any mat: the parts at most 155 together, no byte carries)
    cs = [c - lam for c in coef]
    bases = [math.ceil(max(0., -c) * 255 / 6) + 1 for c in cs]
    rel = 0
    for k in range(3):
        rel += int.from_bytes(pixels[k::3].translate(bytes(round(cs[k] * v / 6) + bases[k] for v in range(256))), 'big')
    pale = int.from_bytes(rel.to_bytes(cw * ch, 'big').translate(bytes(int(v < sum(bases)) for v in range(256))), 'little')
    clear &= pale
    loose &= pale
    cand = m.grow(m.shrink(loose, r), r) & loose
    if not cand:
        return region, group, dist
    touch = m.bytes_of(m.grow(reg, 1) & cand)
    edge = m.bytes_of(cand & ~m.shrink(far, 1))
    kept = 0
    for spot in label(row_runs(m.bytes_of(cand), cw, ch)):
        rows = [(y * cw + a, y * cw + b) for y, a, b in spot]
        if any(b'\x01' in touch[a:b] for a, b in rows) and not any(b'\x01' in edge[a:b] for a, b in rows):
            kept |= int.from_bytes(_rows_mask(rows, cw * ch), 'little')
    if not kept:
        return region, group, dist
    # the spot whole again: the slivers the opening took from it where it meets the edge (not the blur round it, half
    # the mat's hue: the edge would be pushed out)
    added = m.bytes_of(m.grow(kept, r + 1) & loose & clear | kept)
    # the distances there on the hue's own scale (the edge where the mat's hue is half way, as the piece's elsewhere)
    scale = (level + .5) * 12 / hue
    inner = bytes(min(level, max(0, round((v - 147) * scale))) for v in range(256))
    outer = bytes(min(255, max(level + 1, round((v - 147) * scale))) for v in range(256))
    beside = m.bytes_of(m.grow(int.from_bytes(added, 'little'), 2) & ~reg & ~int.from_bytes(added, 'little') & m.full)
    region, dist = bytearray(region), bytearray(dist)
    for mask, table, ink in ((added, inner, True), (beside, outer, False)):
        for found in RUN.finditer(mask):
            a, b = found.start(), found.end()
            while a < b:   # (row by row)
                y, x = divmod(a, cw)
                n = min(b, (y + 1) * cw) - a
                k = (y + cy0) * w + cx0 + x
                if ink:
                    region[k:k + n] = b'\x01' * n
                dist[k:k + n] = along[a:a + n].translate(table)
                a += n
    region, dist = bytes(region), bytes(dist)
    return region, flood(region, w, h, seed, w * h) or group, dist
