"""0.19.29 Montage auto (« peut-être demander quel type de montage de sac c'est pour comprendre, ou alors Craft comprend
tout seul et propose un montage direct », 14/11/2026): the bag's type recognised from its pieces (a cavour or soufflet
between the face and the dos, with or without a jonc; a fond mexicain, its corners cut out and sewn on themselves; a fond
rapporté, the partie haute closed by its two ends and its fond sewn all round, piqué retourné; à plat; bande allemande),
said at the top of the Contrôle d'assemblage du sac, a list to change it, and its whole montage proposed (the seams and
the steps in their order) to tick and put in the bag's list; the piqûre of the model (« piqûre extérieure donc on pique
à 2,5 ou piqué retourné donc 5 mm du bord »). The gammes types (« enregistrer le montage d'un modèle et l'appliquer en un
clic à un nouveau modèle du même type »): kept in the preferences (« gammes »), applied by the pieces' names."""
import marshal
import math
import tkinter as tk

import assembly_ui as A

TYPES = (('cavour', 'Cavour / soufflet'), ('cavour_jonc', 'Cavour / soufflet avec jonc'), ('mexicain', 'Fond mexicain'),
         ('rapporte', 'Fond rapporté'), ('plat', 'À plat (face et dos)'),
         ('seau', 'Bande allemande, type seau (bande et fond)'),
         ('gousset', 'Bande allemande, gousset et bande (face et dos sans fond)'), ('autre', 'Autre montage'))
NAMES = dict(TYPES)
BAND_WORDS = ('CAVOUR', 'SOUFFLET', 'BANDE', 'GOUSSET')
JONC_WORDS = ('JONC', 'PASSEPOIL')
LINING_STEP = 'Poser la doublure'


def _names(app, ks):
    return ' et '.join(dict.fromkeys(A._name(A.host(app, k)) or 'Pièce' for k in ks))


def _edges(p, k):
    """the sides of piece ``k`` in the proposal ``p`` (both when it is sewn on itself)"""
    return [i for e in (p['a'], p['b']) if e[0] == k for i in e[1]]


def band_of(app, props):
    """(C, A, B): a piece C (a cavour, a soufflet) with two edges of its own, apart, sewn to two other pieces A and B (the
    one named FACE first), the face and the dos of the outside; None"""
    found = bands_of(app, props)
    return found[0] if found else None


def _band_like(app, k):
    """piece ``k`` is a band: named so (CAVOUR, SOUFFLET, BANDE, GOUSSET) or long and narrow (3 times at least)"""
    from geometry import bounds
    if any(w in A._name(A.host(app, k)) for w in BAND_WORDS):
        return True
    try:
        x, y, X, Y = bounds([app.items[k]])
    except (ValueError, KeyError, TypeError, IndexError):
        return False
    return min(X - x, Y - y) > 0 and max(X - x, Y - y) >= 3 * min(X - x, Y - y)


def bands_of(app, props):
    """[(C, A, B)] every band between two pieces (TILTED's two soufflets), the outside's first, the best first"""
    best = {}
    for p in props:
        if p.get('kind') or p['a'][0] == p['b'][0]:
            continue
        for C in (p['a'][0], p['b'][0]):
            if C in best or not _band_like(app, C):
                continue
            partners = {}
            for q in props:
                if q.get('kind') or q['a'][0] == q['b'][0] or C not in (q['a'][0], q['b'][0]):
                    continue
                other = q['b'][0] if q['a'][0] == C else q['a'][0]
                partners.setdefault(other, set()).update(_edges(q, C))
            ks = list(partners)
            for x, a in enumerate(ks):
                for b in ks[x + 1:]:
                    if partners[a] & partners[b] or A.lining(app, a) != A.lining(app, b) or A.lining(app, C) != A.lining(app, a):
                        continue
                    first, second = (a, b) if A._name(A.host(app, a)).startswith(A.FRONT_WORDS) or not A._name(
                        A.host(app, b)).startswith(A.FRONT_WORDS) else (b, a)
                    rank = (not A.lining(app, C), any(w in A._name(A.host(app, C)) for w in BAND_WORDS), A._area(A.host(app, first)))
                    if C not in best or rank > best[C][0]:
                        best[C] = (rank, (C, first, second))
    return [v[1] for v in sorted(best.values(), key=lambda v: v[0], reverse=True)]


def jonc_in(app, props):
    return any(A.is_jonc(p) for p in props) or any(
        any(w in A._name(A.host(app, k)) for w in JONC_WORDS) for k in A._pieces(app, every=True))


_SEEN = {}


def recognize(app, props=None):
    """dict(type, why: what Craft saw, props: the probable pairs) of the bag"""
    if props is None:
        try:
            key = (id(app), tuple(map(id, app.items)), marshal.dumps((app.items, A.montage(app)), 2))   # (review: the
            # proposals hold the pieces themselves: those of Annuler are others, of the same content)
        except (ValueError, TypeError):
            key = None
        hit = _SEEN.get(id(app))
        if key is not None and hit and hit[0] == key:
            return hit[1]
        props = A.proposals(app, every=True)
    else:
        key = None
    out = _recognized(app, props)
    if key is not None:
        _SEEN.clear()
        _SEEN[id(app)] = (key, out)
    return out


def _recognized(app, props):
    tubes = [p for p in props if p.get('kind') == 'fond']
    coins = [p for p in props if p.get('kind') == 'coin']
    if tubes:
        p = tubes[0]
        k, f = p['a'][0], p['b'][0]
        name = A._name(A.host(app, k)) or 'Pièce'
        kind = 'seau' if 'BANDE' in name else 'rapporte'
        return dict(type=kind, props=props, why=f'{name} fermée par ses deux bouts, {A._name(A.host(app, f)) or "le fond"} '
                                                 'cousu tout autour')
    if coins:
        return dict(type='mexicain', props=props, why=f'{len(coins)} coins découpés sur {_names(app, [p["a"][0] for p in coins])}')
    band = band_of(app, props)
    if band:
        C, a, b = band
        names = [A._name(A.host(app, k)) for k in A._pieces(app, every=True)]
        if 'BANDE' in A._name(A.host(app, C)) and any('GOUSSET' in n for n in names):
            return dict(type='gousset', props=props, why=f'{_names(app, [C])} entre {_names(app, [a])} et {_names(app, [b])}, un gousset')
        jonc = jonc_in(app, props)
        same = [c for c, x, y in bands_of(app, props) if {x, y} == {a, b}]   # (two soufflets between the same face and dos)
        return dict(type='cavour_jonc' if jonc else 'cavour', props=props,
                    why=f'{_names(app, same or [C])} entre {_names(app, [a])} et {_names(app, [b])}' + (', jonc' if jonc else ''))
    outside = [p for p in props if not p.get('kind') and p['a'][0] != p['b'][0] and not A.lining(app, p['a'][0])]
    if outside:
        a, b = outside[0]['a'][0], outside[0]['b'][0]
        return dict(type='plat', props=props, why=f'{_names(app, [a])} et {_names(app, [b])} cousus bord à bord')
    return dict(type='autre', props=props, why='aucun montage reconnu' if props else 'aucune paire de bords de même longueur')


def _opening(app, group):
    """the pairs of ``group`` that look like the opening of a bag sewn à plat: between two pieces sewn along several
    edges, the shortest one, a straight side on both"""
    out = []
    by = {}
    for p in group:
        if p.get('kind') or p['a'][0] == p['b'][0]:
            continue
        by.setdefault(frozenset((p['a'][0], p['b'][0])), []).append(p)
    for ps in by.values():
        if len(ps) < 2:
            continue
        short = min(ps, key=lambda p: max(p['la'], p['lb']))
        try:
            straight = all(len(e[1]) == 1 and A._straight(A.sides(app.items[e[0]])[0][e[1][0]][0]) for e in (short['a'], short['b']))
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
            straight = False
        if straight and short.get('nocran'):
            out.append(short)
    return out


def _arranged(app, kind, group):
    """the pairs of ``group`` (the outside's, or the lining's) in the order of montage of ``kind``: [(pair, ticked)]"""
    if kind in ('cavour', 'cavour_jonc', 'gousset'):
        first = []
        for C, a, b in bands_of(app, group):
            for other in (a, b):
                first += [p for p in group if {p['a'][0], p['b'][0]} == {C, other} and not any(p is q for q in first)]
        rest = [p for p in group if not any(p is q for q in first)]
        return [(p, True) for p in first] + [(p, not p.get('nocran')) for p in rest]
    if kind == 'mexicain':
        coins = [p for p in group if p.get('kind') == 'coin']
        notched = {}
        for p in coins:
            notched.setdefault(p['a'][0], set()).update(p['a'][1] + p['b'][1])
        side = []
        for p in group:
            if p.get('kind') or p['a'][0] == p['b'][0] or not {p['a'][0], p['b'][0]} <= set(notched):
                continue
            beside = all(any((i + step) % len(A.sides(app.items[k])[0]) in notched[k] for i in ids for step in (-1, 1))
                         for k, ids in (p['a'], p['b']))   # (the sides and the bottom reach a corner cut out; the opening never)
            side.append((p, beside))
        rest = [p for p in group if not any(p is q for q in coins) and not any(p is q for q, _ in side)]
        return side + [(p, True) for p in coins] + [(p, not p.get('nocran')) for p in rest]
    if kind in ('rapporte', 'seau'):
        bouts = [p for p in group if p.get('kind') == 'bout']
        fonds = [p for p in group if p.get('kind') == 'fond']
        rest = [p for p in group if not p.get('kind')]
        return [(p, True) for p in bouts + fonds] + [(p, not p.get('nocran')) for p in rest + [
            q for q in group if q.get('kind') == 'coin']]
    if kind == 'plat':
        opening = _opening(app, group)
        return [(p, not any(p is q for q in opening) and (not p.get('nocran') or p['a'][0] != p['b'][0])) for p in group
                if not p.get('kind')] + [(p, False) for p in group if p.get('kind')]
    return [(p, not p.get('nocran')) for p in group]


END_STEPS = ('Retourner le sac', 'Teinter les tranches')


def lines(app, kind=None, props=None):
    """The montage proposed for the type ``kind`` (the one recognised when None): [dict(pair=proposal, ticked) |
    dict(etape=text, ticked)] in their order: the steps Craft sees on the pieces (steps_proposed) before the first seam
    of their piece, the outside's seams, then « Retourner le sac » (piqué retourné) or « Teinter les tranches » (bord
    franc), the lining's seams, « Poser la doublure »."""
    seen = recognize(app) if props is None else _recognized(app, props)
    kind = kind or seen['type']
    props = seen['props']
    outside = [p for p in props if not (A.lining(app, p['a'][0]) and A.lining(app, p['b'][0]))]
    inside = [p for p in props if not any(p is q for q in outside)]
    first, second = _arranged(app, kind, outside), _arranged(app, kind, inside)
    out = [dict(pair=p, ticked=t) for p, t in first]
    ends = len(out)   # (where the outside ends: its own end steps there)
    out += [dict(pair=p, ticked=t) for p, t in second]
    if any(t for _, t in first) and any(t for _, t in second):
        out.append(dict(etape=LINING_STEP, ticked=True))
    rows = []
    for line in out:
        if 'pair' in line and line['ticked']:
            p = line['pair']
            try:   # (review: never an id given to a piece by looking)
                row = dict(a=A.peek_edge(app, p['a']), b=A.peek_edge(app, p['b']))
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                continue
            for key in ('seam', 'retourne'):
                if p.get(key) is not None:
                    row[key] = p[key]
            rows.append(row)
            line['row'] = len(rows) - 1
    try:
        steps = A.steps_proposed(app, rows)
    except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
        steps = []
    places = []
    for order, (text, at) in enumerate(steps):
        place = next((n for n, line in enumerate(out) if line.get('row') == at), None)
        if text in END_STEPS or place is None:
            place = ends   # (after the outside's seams, before the lining's and its steps)
        places.append((place, -1 if text in END_STEPS else order, text))
    for place, _, text in sorted(places, reverse=True):
        out.insert(place, dict(etape=text, ticked=True))
    for line in out:
        line.pop('row', None)
    return dict(type=kind, recognised=seen['type'], why=seen['why'], lines=out)


def add_lines(app, chosen, kind=None):
    """The lines ``chosen`` put at the end of the bag's list in their order (a pair kept already, a step already there:
    not again); the type kept with the model. (pairs added, steps added)"""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0, 0
    rows = A.entries(app)
    idents = {A._ident(r) for r in rows if 'a' in r}
    steps = {r['etape'] for r in rows if 'etape' in r}
    pairs = added = 0
    for line in chosen:
        if 'pair' in line:
            p = line['pair']
            row = dict(a=A.edge_of(app, p['a']), b=A.edge_of(app, p['b']))
            if p.get('seam') is not None:
                row['seam'] = p['seam']
                if p.get('retourne'):
                    row['retourne'] = True
            if p.get('points') is not None:
                row['points'] = A.points_of(p['points'])   # (a gamme's)
            if p.get('double'):
                row['double'] = True
            if A._ident(row) in idents:
                continue
            idents.add(A._ident(row))
            rows.append(row)
            pairs += 1
        elif line.get('etape') and line['etape'] not in steps:
            minutes = line.get('minutes') or A.step_minutes(app).get(line['etape'])   # (a gamme's own minutes first)
            rows.append(dict(etape=line['etape'], **({'minutes': minutes} if minutes else {})))
            steps.add(line['etape'])
            added += 1
    if kind:
        set_montage(app, type=kind)
    if pairs or added:
        A._store(app, rows)
    return pairs, added


def set_montage(app, **changes):
    """The Infos du modèle « montage » (piqure, type) changed (a new dict: the « * » of the tab)."""
    data = A.montage(app)
    data.update({k: v for k, v in changes.items() if v is not None})
    infos = dict(app.__dict__.get('infos') or {})
    infos['montage'] = data
    app.infos = infos
    for name in ('update_window_title', 'rebuild_tabs'):
        if hasattr(app, name):
            getattr(app, name)()


def type_text(app):
    """What the bag's window says of the type: the one kept with the model, else the one recognised."""
    kept = A.montage(app).get('type')
    seen = recognize(app)
    if kept in NAMES:
        return f'Montage : {NAMES[kept]}' + ('' if kept == seen['type'] else f' (reconnu : {NAMES[seen["type"]]})')
    return f'Montage reconnu : {NAMES[seen["type"]]} ({seen["why"]})'


def piqure_row(app, parent, after=None):
    """« Piqûre : (•) extérieure (2,5 mm) ( ) piqué retourné (5 mm) », kept with the model; ``after`` called when it
    changes (the bag's list measured again)."""
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    row = tk.Frame(parent, bg=panel)
    tk.Label(row, text='Piqûre :', bg=panel, fg=ink, font=('Segoe UI', 9)).pack(side='left')
    var = tk.StringVar(value=A.piqure(app))
    style = dict(bg=panel, fg=ink, selectcolor=app.field_background(), activebackground=panel, font=('Segoe UI', 9))

    def changed():
        if hasattr(app, 'licence_complet') and not app.licence_complet():
            app.read_only_said()
            var.set(A.piqure(app))
            return
        if var.get() != A.piqure(app):
            set_montage(app, piqure=var.get())
            app.status.set('Piqûre du modèle : ' + dict(A.PIQURES)[var.get()].lower() + ' (les coutures mesurées à nouveau).')
            if after:
                after()
            for name in ('_bag_window', '_montage_window', '_assembly_window'):   # (review: the other windows open follow)
                other = app.__dict__.get(name)
                if other is not None and other is not row.winfo_toplevel() and other.winfo_exists():
                    other._refill()
            if (app.__dict__.get('assembly_state') or {}).get('b'):
                A.draw(app)
    for value, text in A.PIQURES:
        __import__('modern_style').make_radio(row, text=text, variable=var, value=value, command=changed, **style).pack(side='left', padx=(6, 0))
    row._var = var
    return row


def window(app):
    """« Montage auto… » (Contrôle d'assemblage du sac): the type recognised and why, a list to change it, the piqûre,
    the montage proposed (seams and steps in their order) to tick; « Ajouter au montage » puts the lines ticked at the
    end of the bag's list."""
    from tkinter import ttk
    old = app.__dict__.get('_montage_window')
    if old is not None and old.winfo_exists():
        old._refill()
        old.lift()
        return old
    win = app.dialog('Montage auto')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._montage_window = win
    panel = app.p['panel']
    ink = app.p.get('ui_ink', '#f1f3f5')
    head = tk.StringVar()
    tk.Label(win, textvariable=head, bg=panel, fg=ink, font=('Segoe UI', 10, 'bold'), justify='left', wraplength=640).pack(anchor='w', padx=14, pady=(12, 2))
    top = tk.Frame(win, bg=panel)
    top.pack(fill='x', padx=14, pady=2)
    tk.Label(top, text='Type :', bg=panel, fg=ink, font=('Segoe UI', 9)).pack(side='left')
    kind = tk.StringVar()
    box = ttk.Combobox(top, textvariable=kind, values=[t for _, t in TYPES], width=44, state='readonly')
    box.pack(side='left', padx=6)
    state = dict(lines=[], ticked=set(), kind=None)
    stitched = piqure_row(app, win, lambda: refill())
    stitched.pack(anchor='w', padx=14, pady=2)
    note = tk.StringVar()
    tk.Label(win, textvariable=note, bg=panel, fg=ink, font=('Segoe UI', 9), justify='left', wraplength=640).pack(anchor='w', padx=14, pady=(2, 4))
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    columns = (('tick', '', 3), ('n', 'N°', 4), ('a', 'Bord 1 · étape', 26), ('b', 'Bord 2', 22), ('seam', 'Couture', 9),
               ('len', 'Longueurs (mm)', 14), ('crans', 'Crans', 18))
    table = ttk.Treeview(area, columns=[k for k, _, _ in columns], show='headings', height=12, selectmode='browse')
    for key, label, width in columns:
        table.heading(key, text=label)
        table.column(key, width=width * 7, anchor='center' if key in ('tick', 'n') else 'w', stretch=key in ('a', 'b'))
    scroll = ttk.Scrollbar(area, orient='vertical', command=table.yview)
    table.configure(yscrollcommand=scroll.set)
    table.pack(side='left', fill='both', expand=True)
    scroll.pack(side='right', fill='y')

    def text(e):
        return A._side_text(app, e[0], e[1])

    def refill(chosen=None):
        try:
            got = lines(app, chosen or state.get('kind'))
        except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError) as exc:
            note.set(f'Montage auto impossible ici : {exc}')
            return
        state.update(lines=got['lines'], kind=got['type'], ticked={n for n, line in enumerate(got['lines']) if line['ticked']})
        kind.set(NAMES[got['type']])
        stitched._var.set(A.piqure(app))
        head.set(f'Reconnu : {NAMES[got["recognised"]]} ({got["why"]}).' + (
            '' if got['type'] == got['recognised'] else f' Choisi : {NAMES[got["type"]]}.'))
        table.delete(*table.get_children())
        for n, line in enumerate(got['lines']):
            tick = '☑' if n in state['ticked'] else '☐'
            if 'etape' in line:
                table.insert('', 'end', iid=str(n), values=(tick, n + 1, line['etape'], '', '', '', 'étape'))
            else:
                p = line['pair']
                d, what = A.seam_info(app, p.get('seam'), (p['a'][0], p['b'][0]), p.get('retourne'))
                table.insert('', 'end', iid=str(n), values=(tick, n + 1, text(p['a']), text(p['b']), A.seam_text(d, what),
                                                            f'{A._mm(p["la"])} / {A._mm(p["lb"])}', A.proposal_crans(p)))
        pairs = [line for line in got['lines'] if 'pair' in line]
        unsure = sum(1 for line in pairs if line['pair'].get('nocran'))
        note.set(f'{len(pairs)} couture{"s" if len(pairs) > 1 else ""} et {len(got["lines"]) - len(pairs)} étape'
                 f'{"s" if len(got["lines"]) - len(pairs) > 1 else ""} dans l’ordre de montage, celles cochées proposées'
                 + (f' ; {unsure} sans crans, par leurs longueurs : à vérifier' if unsure else '')
                 + '. Clic sur ☐ : cocher ou décocher ; « Ajouter au montage » les met au bout de la liste du sac (▲ ▼ : l’ordre).')
        shown(None)

    def shown(n):
        marks = app.__dict__.get('_bag_marks')
        if marks is None:
            return
        line = state['lines'][n] if n is not None and n < len(state['lines']) else None
        if line is None or 'pair' not in line:
            marks.pop('proposal', None)
        else:
            p = line['pair']
            try:
                marks['proposal'] = (A.portion(app, (p['a'][0], list(p['a'][1])))[0], A.portion(app, (p['b'][0], list(p['b'][1])))[0])
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                marks.pop('proposal', None)
        A.draw_bag(app)

    def toggle(n):
        if n in state['ticked']:
            state['ticked'].discard(n)
        else:
            state['ticked'].add(n)
        table.set(str(n), 'tick', '☑' if n in state['ticked'] else '☐')

    def clicked(e):
        row = table.identify_row(e.y)
        if row and table.identify_column(e.x) == '#1':
            toggle(int(row))

    def picked(e=None):
        sel = table.selection()
        shown(int(sel[0]) if sel else None)

    def key_toggle(e=None):
        sel = table.selection()
        if sel:
            toggle(int(sel[0]))
        return 'break'
    table.bind('<Button-1>', clicked, add='+')
    table.bind('<<TreeviewSelect>>', picked)
    table.bind('<space>', key_toggle)

    def typed(e=None):
        chosen = next((k for k, t in TYPES if t == kind.get()), None)
        if chosen and chosen != state.get('kind'):
            refill(chosen)
    box.bind('<<ComboboxSelected>>', typed)

    def add():
        chosen = [state['lines'][n] for n in sorted(state['ticked']) if n < len(state['lines'])]
        if not chosen:
            app.status.set('Cocher les coutures et les étapes à mettre dans la liste du sac.')
            return
        stale = any(not all(k < len(app.items) and app.items[k] is s for k, s in zip((line['pair']['a'][0], line['pair']['b'][0]), line['pair']['pieces']))
                    for line in chosen if 'pair' in line)
        if stale:
            refill()
            app.status.set('Le dessin a changé : le montage est refait, cocher à nouveau.')
            return
        pairs, steps = add_lines(app, chosen, state.get('kind'))
        bag = app.__dict__.get('_bag_window')
        if bag is not None and bag.winfo_exists():
            bag._refill()
        app.status.set(f'Montage {NAMES.get(state.get("kind"), "")} : {pairs} couture{"s" if pairs != 1 else ""} et {steps} étape'
                       f'{"s" if steps != 1 else ""} ajoutée{"s" if pairs + steps != 1 else ""} au bout de la liste du sac'
                       + (' (le reste y était déjà).' if pairs + steps < len(chosen) else '.'))

    def done():
        marks = app.__dict__.get('_bag_marks')
        if marks is not None:
            marks.pop('proposal', None)
            A.draw_bag(app)
        app.__dict__.pop('_montage_window', None)
        win.destroy()
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Ajouter au montage', add).pack(side='left')
    app.button(foot, 'Fermer', done).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win._refill = refill
    win._table = table
    win._toggle = toggle
    win._add = add
    win._done = done
    win._state = state
    win._kind = kind
    win._typed = typed
    win._head = head
    win._note = note
    refill()
    return win


# --- gammes types ---------------------------------------------------------------------------------------------------

GAMMES_KEPT = 40     # gammes at most in the preferences
GAMME_LINES = 300    # lines of one gamme at most


def gammes(app):
    """{name: dict(type, piqure, lines: [dict(etape, minutes) | dict(a, b: pieces' names, seam, retourne, points,
    double)])} kept in the preferences"""
    data = (app.__dict__.get('prefs') or {}).get('gammes')
    return dict(data) if isinstance(data, dict) else {}


def gamme_of(app):
    """The bag's list as a gamme: each pair by its pieces' names and its edges (their sides, and how many sides each piece
    has: review, two pieces sewn along several edges), each step as it is (its minutes too)."""
    pieces = A._pieces(app, every=True)
    out = []
    for row in A.entries(app):
        if 'etape' in row:
            out.append(dict(etape=row['etape'], **({'minutes': row['minutes']} if row.get('minutes') else {})))
            continue
        ks = [A.piece_index(app, e['piece'], pieces) for e in (row['a'], row['b'])]
        if None in ks:
            continue
        line = dict(a=A._name(A.host(app, ks[0])) or 'Pièce', b=A._name(A.host(app, ks[1])) or 'Pièce',
                    sides_a=list(row['a']['sides']), count_a=row['a']['count'], sides_b=list(row['b']['sides']), count_b=row['b']['count'])
        for key in ('seam', 'retourne', 'points', 'double'):
            if row.get(key) is not None:
                line[key] = row[key]
        out.append(line)
    return out[:GAMME_LINES]


def save_gamme(app, name):
    """The bag's list kept as the gamme ``name`` (replacing one of that name); False when there is nothing to keep."""
    name = ' '.join(str(name or '').split())[:60]
    got = gamme_of(app)
    if not name or not got:
        return False
    data = gammes(app)
    data.pop(name, None)
    pieces = sorted({A._name(A.host(app, k)) for k in A._pieces(app, every=True)} - {''})[:200]
    data[name] = dict(type=A.montage(app).get('type') or recognize(app)['type'], piqure=A.piqure(app), lines=got, pieces=pieces)
    while len(data) > GAMMES_KEPT:
        data.pop(next(iter(data)))
    app.prefs['gammes'] = data
    if hasattr(app, 'persist_preferences'):
        app.persist_preferences()
    return True


def forget_gamme(app, name):
    data = gammes(app)
    if data.pop(name, None) is None:
        return False
    app.prefs['gammes'] = data
    if hasattr(app, 'persist_preferences'):
        app.persist_preferences()
    return True


def apply_gamme(app, name):
    """The gamme ``name`` put at the end of the bag's list: its steps as they are (with their minutes; a step of a piece
    of the gamme's model that this one has not: left out), each of its seams on this model's pieces of the same names
    (the same edges when the piece has as many sides; else the probable pair between them, by their names then their
    names without their copy's number or side; the pairs kept already: not again); its type and its piqûre kept with
    the model once something is put. (pairs added, steps added, [the seams not found: 'A / B'])"""
    if hasattr(app, 'licence_complet') and not app.licence_complet():
        app.read_only_said()
        return 0, 0, []
    g = gammes(app).get(name)
    if not g:
        return 0, 0, []
    pieces = A._pieces(app, every=True)
    named = {}
    for k in pieces:
        named.setdefault(A._name(A.host(app, k)), []).append(k)
    props = []
    used = set()

    def piece_for(want, count):
        """this model's piece of that name with as many sides (else of that name without its copy's mark)"""
        for k in list(named.get(want, ())) + [k for k in pieces if _base(want) and A.base_name(app, k) == _base(want)]:
            try:
                if len(A.sides(app.items[k])[0]) == count:
                    return k
            except (ValueError, KeyError, TypeError, IndexError, ZeroDivisionError):
                continue
        return None

    def proposed(a, b):
        if not props:
            props.extend(A.proposals(app, every=True) or [None])
        for exact in (True, False):
            for n, p in enumerate(props):
                if p is None or n in used:
                    continue
                ka, kb = p['a'][0], p['b'][0]
                names = (A._name(A.host(app, ka)), A._name(A.host(app, kb))) if exact else (A.base_name(app, ka), A.base_name(app, kb))
                want = (a, b) if exact else (_base(a), _base(b))
                if names == want or names == want[::-1]:
                    used.add(n)
                    return p
        return None
    chosen, missing = [], []
    here = set(named)
    there = set(g.get('pieces') or [])
    for line in g.get('lines') or []:
        if 'etape' in line:
            said = line['etape'].split(' : ', 1)[0] if ' : ' in line['etape'] else ''
            names = [n.strip().upper() for n in said.split(' / ')] if said else []
            if names and all(n in there for n in names) and any(n not in here for n in names):
                continue   # (a step of a piece this model has not: « CAVOUR : rembord 7 » on a bag without a cavour)
            chosen.append(dict(etape=line['etape'], **({'minutes': line['minutes']} if line.get('minutes') else {})))
            continue
        p = None
        ka, kb = piece_for(line.get('a'), line.get('count_a')), piece_for(line.get('b'), line.get('count_b'))
        if line.get('a') == line.get('b') and ka is not None:
            kb = ka   # (a piece with itself: its corners, its two ends)
        if ka is not None and kb is not None and line.get('sides_a') and line.get('sides_b'):
            p = dict(a=(ka, list(line['sides_a'])), b=(kb, list(line['sides_b'])), pieces=(app.items[ka], app.items[kb]))
        else:
            p = proposed(line.get('a'), line.get('b'))
        if p is None:
            missing.append(f'{line.get("a")} / {line.get("b")}')
            continue
        p = dict(p)
        p.pop('seam', None)
        p.pop('retourne', None)
        for key in ('seam', 'retourne', 'points', 'double'):   # (as in the gamme: its jonc, its points per cm…)
            if line.get(key) is not None:
                p[key] = line[key]
        chosen.append(dict(pair=p))
    pairs, steps = add_lines(app, chosen)
    if pairs:   # (review: no seam put, the model's type and piqûre unchanged)
        set_montage(app, type=g.get('type') if g.get('type') in NAMES else None,
                    piqure=g.get('piqure') if g.get('piqure') in dict(A.PIQURES) else None)
    return pairs, steps, missing


def _base(name):
    import re
    words = re.findall(r'[^\W_]+', str(name or '').upper())
    while words and words[0] in A.STAGE_WORDS:
        words = words[1:]
    while len(words) > 1 and (words[-1] in A.COPY_WORDS or words[-1].isdigit()):
        words = words[:-1]
    return ' '.join(words)


def gamme_window(app):
    """« Gamme… » (Contrôle d'assemblage du sac): the bag's list kept as a gamme type by its name, the gammes kept to put
    on this model in one click (« Appliquer »), or to forget."""
    from tkinter import ttk
    old = app.__dict__.get('_gamme_window')
    if old is not None and old.winfo_exists():
        old._refill()
        old.lift()
        return old
    win = app.dialog('Gammes types')
    try:
        win.grab_release()
    except tk.TclError:
        pass
    if app.__dict__.get('_tool_dialogs'):
        app._tool_dialogs = [w for w in app._tool_dialogs if w is not win]
    app._gamme_window = win
    panel = app.p['panel']
    app.label(win, 'Une gamme type garde le montage de ce modèle (les étapes et l’ordre des coutures, par les noms des '
                   'pièces) ; « Appliquer » la met sur un autre modèle du même type, en un clic.').pack(anchor='w', padx=14, pady=(12, 4))
    row = tk.Frame(win, bg=panel)
    row.pack(fill='x', padx=14, pady=4)
    app.label(row, 'Nom').pack(side='left')
    name = tk.StringVar(value=NAMES.get(A.montage(app).get('type') or recognize(app)['type'], 'Mon montage'))
    app.entry(row, name, 34).pack(side='left', padx=6)

    def saved():
        if not A.entries(app):
            app.status.set('Rien à garder : la liste du sac est vide.')
            return
        if save_gamme(app, name.get()):
            app.status.set(f'Gamme « {" ".join(name.get().split())[:60]} » enregistrée ({len(gamme_of(app))} lignes).')
            refill()
    app.button(row, 'Enregistrer ce montage', saved).pack(side='left', padx=6)
    area = tk.Frame(win, bg=panel)
    area.pack(fill='both', expand=True, padx=14, pady=4)
    table = ttk.Treeview(area, columns=('name', 'type', 'lines'), show='headings', height=8, selectmode='browse')
    for key, label, width in (('name', 'Gamme', 26), ('type', 'Type', 30), ('lines', 'Lignes', 8)):
        table.heading(key, text=label)
        table.column(key, width=width * 7, stretch=key != 'lines')
    table.pack(fill='both', expand=True)

    def refill():
        table.delete(*table.get_children())
        for n, (key, g) in enumerate(gammes(app).items()):
            table.insert('', 'end', iid=str(n), values=(key, NAMES.get(g.get('type'), '—'), len(g.get('lines') or ())))

    def chosen():
        sel = table.selection()
        keys = list(gammes(app))
        return keys[int(sel[0])] if sel and int(sel[0]) < len(keys) else None

    def applied(e=None):
        key = chosen()
        if key is None:
            app.status.set('Choisir dans la liste la gamme à appliquer.')
            return
        pairs, steps, missing = apply_gamme(app, key)
        bag = app.__dict__.get('_bag_window')
        if bag is not None and bag.winfo_exists():
            bag._refill()
        app.status.set(f'Gamme « {key} » : {pairs} couture{"s" if pairs != 1 else ""} et {steps} étape{"s" if steps != 1 else ""} '
                       'mises au bout de la liste du sac'
                       + (f' ; sans paire trouvée ici : {", ".join(missing[:6])}{"…" if len(missing) > 6 else ""} '
                          '(« Ajouter un assemblage »)' if missing else '') + '.')

    def forgot():
        key = chosen()
        if key is not None and forget_gamme(app, key):
            app.status.set(f'Gamme « {key} » oubliée.')
            refill()
    table.bind('<Double-1>', applied)
    foot = tk.Frame(win, bg=panel)
    foot.pack(fill='x', padx=14, pady=(6, 12))
    app.button(foot, 'Appliquer', applied).pack(side='left')
    app.button(foot, 'Oublier', forgot, kind='secondary').pack(side='left', padx=6)

    def done():
        app.__dict__.pop('_gamme_window', None)
        win.destroy()
    app.button(foot, 'Fermer', done).pack(side='right')
    win.protocol('WM_DELETE_WINDOW', done)
    win.bind('<Escape>', lambda e: done())
    win._refill = refill
    win._gamme_name = name
    win._saved = saved
    win._applied = applied
    win._forgot = forgot
    win._table = table
    win._done = done
    refill()
    return win
