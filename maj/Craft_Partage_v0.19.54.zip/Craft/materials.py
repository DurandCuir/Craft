"""0.17.0 Matières: the materials archive organised by type, the Matière window filters, the label
written on the piece and the costs of the fiche de coupe.

archives.json keeps its list of names (``materials``) as before; what is known about each material
lives beside it in ``material_info`` (type, épaisseur in tenths of mm, prix au m², taux de chute,
0.18.1 couleur / référence shown on the fiches like Mozart's: « 2024 », « BLANCHE »…).
A material without information is shown as « Autre » and nothing is ever rewritten by force."""
import math
import unicodedata

TYPES=('Cuir','Tissu','Renfort','Gabarit','Autre')
# 0.18.0: « Doublure » became « Tissu » (a lining may be in leather). A material archived before as
# « Doublure » is read as Tissu; the archive itself is not rewritten.
OLD_TYPES={'Doublure':'Tissu'}
WASTE=15.
# 0.18.0: the Refente list, in tenths of a millimetre (another value may be typed).
REFENTES=tuple(str(k) for k in range(4,21))
# 0.19.47 (« Prix au pied carré dans Archives : beaucoup de tanneries vendent à ce prix, Craft le convertirait en m² »,
# « bien » 19/11, « Finis » 20/11): a material priced by the square foot (unit 'ft2'): its price and its skin's surface
# typed in pieds carrés, kept as typed (price_ft2, skin_area_ft2) and in m² beside them (price, skin_area: the costs,
# and what an earlier Craft reads)
FT2=.09290304   # m² in a square foot


def number(text,low=None,high=None,label='Valeur'):
    """'7' / '7,5' → 7.5; '' → None. Raises ValueError with a short French message."""
    text=str(text if text is not None else '').strip().replace(',','.')
    if not text:return None
    try:value=float(text)
    except ValueError:raise ValueError(f'{label} : nombre attendu.') from None
    if not math.isfinite(value) or (low is not None and value<low) or (high is not None and value>high):
        # (review 0.19.47) the bounds as they are (« 0,001 à 100 » for a surface in m², never « 0 à 100 »: 0 is refused)
        bound=lambda v:fmt(v) if round(v,2)==v else area_text(v)
        raise ValueError(f'{label} : {bound(low)} à {bound(high)}.' if low is not None and high is not None else f'{label} invalide.')
    return value


def fmt(value):
    """7.0 → '7', 7.5 → '7,5' (French decimal comma)."""
    if value is None:return ''
    return f'{value:.2f}'.rstrip('0').rstrip('.').replace('.',',')


def thickness_label(value):
    return f'{fmt(value)}/10e' if value else ''


def refente_label(value):
    text=fmt(value) if isinstance(value,(int,float)) else str(value or '').strip().replace('.',',')
    return f'refente {text}/10' if text else ''


def label_text(quantity,name,refente=''):
    """The text written on the piece: « 2 VEAU refente 7/10 » or « 2 VEAU »."""
    extra=refente_label(refente)
    return f'{quantity} {name}'+(f' {extra}' if extra else '')


def _positive(value):
    """A number of the archive (``None`` for anything else: text, 0, negative, NaN, a boolean)."""
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:return None
    return float(value)


def info(archives,name):
    """What is known about a material, with defaults (type Autre, chute 15 %). 0.19.45 (« pour les matieres exotiques il
    faudra rajouter une facon de mettre le prix au cm […] et rajouter une zone genre taille de peau », 19/11): an exotic
    skin sold by the centimetre of its width (``per_cm`` €/cm, ``skin_width`` cm: a croco of 50 cm at 30 €/cm, 1 500 € the
    skin; ``skin_area``: its surface in m², what the pieces take a share of)."""
    data=(archives or {}).get('material_info',{}).get(name) or {}
    kind=OLD_TYPES.get(data.get('type'),data.get('type'));kind=kind if kind in TYPES else 'Autre'
    color=data.get('color');color=color.strip()[:60] if isinstance(color,str) else ''
    price,area=data.get('price'),_positive(data.get('skin_area'))
    unit='ft2' if data.get('unit')=='ft2' else 'm2'
    price_ft2=area_ft2=None
    if unit=='ft2':   # 0.19.47: what was typed in pieds carrés first (the m² beside it is its conversion)
        typed=data.get('price_ft2')
        if isinstance(typed,(int,float)) and not isinstance(typed,bool) and math.isfinite(typed) and typed>=0:price_ft2=float(typed);price=price_ft2/FT2
        elif isinstance(price,(int,float)) and not isinstance(price,bool):price_ft2=price*FT2
        area_ft2=_positive(data.get('skin_area_ft2'))
        if area_ft2 is not None:area=area_ft2*FT2
        elif area is not None:area_ft2=area/FT2
    return dict(type=kind,thickness=data.get('thickness'),price=price,waste=data.get('waste',WASTE) if data.get('waste') is not None else WASTE,color=color,
                hidden=data.get('hidden') is True,   # 0.19.13: a material « cachée » (Mozart's Cachés)
                per_cm=_positive(data.get('per_cm')),skin_width=_positive(data.get('skin_width')),skin_area=area,
                whole=data.get('whole_skins') is True,   # 0.19.46: bought by whole skins (their count rounded up, its cost)
                unit=unit,price_ft2=price_ft2,skin_area_ft2=area_ft2)   # 0.19.47


def shown_price(d):
    """0.19.47: the price by area as the window shows it (by the square foot for a material in pieds carrés)."""
    return d.get('price_ft2') if d.get('unit')=='ft2' else d.get('price')


def shown_area(d):
    """0.19.47: the skin's surface as the window shows it (in pieds carrés for a material in pieds carrés)."""
    return d.get('skin_area_ft2') if d.get('unit')=='ft2' else d.get('skin_area')


def area_words(d):
    """0.19.47: « 1,5 m² », « 18 pi² » (the material's own unit), '' without a skin's surface."""
    a=shown_area(d)
    return '' if a is None else f'{area_text(a)} '+('pi²' if d.get('unit')=='ft2' else 'm²')


def skin_price(d):
    """0.19.45: the price of one skin (€: its width × its price by cm), None when it is not sold by the cm."""
    return d['per_cm']*d['skin_width'] if d.get('per_cm') and d.get('skin_width') else None


def price_m2(d):
    """0.19.45: the price of a m² the costs count: a skin sold by the cm, its price over its surface; else the price
    au m² (None without either)."""
    whole=skin_price(d)
    if whole is not None:return whole/d['skin_area'] if d.get('skin_area') else None
    return d.get('price')


def skins(d,area_m2):
    """0.19.45: the skins ``area_m2`` takes (0,35 : a third of one), None without the skin's surface (0.19.46: of any
    material, sold by the cm or by the m²; (review) a share that cannot be counted, a surface of 1e-320 written by hand:
    None, never an OverflowError in bought)."""
    share=area_m2/d['skin_area'] if d.get('skin_area') else None
    return share if share is not None and math.isfinite(share) else None


def skin_cost(d):
    """0.19.46: the price of one whole skin: sold by the cm, its width × its price by cm; else its surface × its price au
    m² (None without them)."""
    whole=skin_price(d)
    if whole is not None:return whole
    return d['price']*d['skin_area'] if d.get('price') is not None and d.get('skin_area') else None


def bought(d,area_m2):
    """0.19.46 (« Peau entière », 19/11): the whole skins to buy for ``area_m2`` (its share of a skin rounded up: 0,42 → 1,
    1,3 → 2), None unless the material is bought by whole skins (with a skin's surface)."""
    share=skins(d,area_m2)
    if not d.get('whole') or share is None:return None
    return math.ceil(share-1e-9) if share>0 else 0


def describe(archives,name):
    """« Cuir · 7/10e · 45 €/m² · chute 15 % » for the selected line of a list (0.19.45: « 30 €/cm · peau de 50 cm :
    1 500 € (0,8 m²) » for a skin sold by the cm; 0.19.46: « peau de 1,5 m² » by the m², « peaux entières »)."""
    d=info(archives,name);parts=[d['type']]
    if d['color']:parts.append(d['color'])
    if d['thickness']:parts.append(thickness_label(d['thickness']))
    if skin_price(d) is not None:
        parts.append(f'{fmt(d["per_cm"])} €/cm · peau de {fmt(d["skin_width"])} cm : {money(skin_price(d))} €'+(f' ({area_words(d)})' if d['skin_area'] else ''))
    else:
        if d['price'] is not None:parts.append(f'{fmt(shown_price(d))} €/pi²' if d['unit']=='ft2' else f'{fmt(d["price"])} €/m²')   # 0.19.47
        if d['skin_area']:parts.append(f'peau de {area_words(d)}')   # 0.19.46
    if d['whole'] and d['skin_area']:parts.append('peaux entières')
    parts.append(f'chute {fmt(d["waste"])} %')
    if d['hidden']:parts.append('cachée')
    return ' · '.join(parts)


def area_text(value):
    """(review) a skin's surface as typed (0,375; 0,004), never rounded to 2 decimals."""
    return '' if value is None else f'{value:.6g}'.replace('.',',')


def money(value):
    """1500 → '1 500', 1234.5 → '1 234,50' (0.19.45: a skin's price)."""
    whole=abs(value-round(value))<.005
    text=f'{value:,.0f}' if whole else f'{value:,.2f}'
    return text.replace(',',' ').replace('.',',')


def store(archives,name,kind,thickness=None,price=None,waste=WASTE,old_name=None,color=None,hidden=False,per_cm=None,skin_width=None,skin_area=None,whole=False,unit='m2'):
    """Adds or updates a material (rename included) in the archive dict, in place (0.19.45: a skin sold by the cm:
    ``per_cm``, ``skin_width``, ``skin_area``; 0.19.46 ``whole``: bought by whole skins, with a skin's surface; 0.19.47
    ``unit`` 'ft2': ``price`` by the square foot and ``skin_area`` in pieds carrés, kept as typed and in m² beside)."""
    names=archives.setdefault('materials',[]);table=archives.setdefault('material_info',{})
    if kind not in TYPES:raise ValueError('Type de matière inconnu.')
    # (review) refused before anything is changed, as the other refusals (a rename lost the old line's information)
    if whole and _positive(skin_area) is None:raise ValueError('Peaux entières : taper la surface de la peau.')
    if old_name and old_name in names and old_name!=name:
        if name in names:raise ValueError('Cette matière existe déjà.')
        names[names.index(old_name)]=name;table.pop(old_name,None)
    elif name not in names:names.append(name)
    entry=dict(type=kind,waste=WASTE if waste is None else waste)
    if thickness:entry['thickness']=thickness
    feet=unit=='ft2'
    if feet:entry['unit']='ft2'
    if price is not None:
        if feet:entry['price_ft2']=float(price);entry['price']=float(price)/FT2
        else:entry['price']=price
    if color and str(color).strip():entry['color']=str(color).strip()[:60]
    if hidden:entry['hidden']=True
    for key,value in (('per_cm',per_cm),('skin_width',skin_width)):
        if _positive(value) is not None:entry[key]=float(value)
    if _positive(skin_area) is not None:
        if feet:entry['skin_area_ft2']=float(skin_area);entry['skin_area']=float(skin_area)*FT2
        else:entry['skin_area']=float(skin_area)
    if whole:entry['whole_skins']=True
    table[name]=entry
    return archives


def remove(archives,name):
    if name in archives.get('materials',[]):archives['materials'].remove(name)
    archives.get('material_info',{}).pop(name,None)


def sort_key(text):
    """Alphabetical order without case or accents (É with E)."""
    return ''.join(c for c in unicodedata.normalize('NFD',str(text).casefold()) if unicodedata.category(c)!='Mn')


def sorted_names(names):
    return sorted(names,key=sort_key)


ORDERS=('Nom','Classe','Code')   # 0.19.13: as Mozart's list (classe = type, code = couleur / référence)


def filtered(archives,kinds,hidden=False,search='',order='Nom'):
    """Material names of the ticked types, sorted by name (or by type, or by couleur / référence, then name); 0.19.13:
    the « cachées » only when asked, those containing ``search`` (without case or accents) only."""
    key=sort_key(search.strip())
    names=[n for n in archives.get('materials',[]) if info(archives,n)['type'] in kinds and (hidden or not info(archives,n)['hidden']) and key in sort_key(n)]
    if order=='Classe':return sorted(names,key=lambda n:(TYPES.index(info(archives,n)['type']),sort_key(n)))
    if order=='Code':return sorted(names,key=lambda n:(not info(archives,n)['color'],sort_key(info(archives,n)['color']),sort_key(n)))
    return sorted_names(names)


def column_at(workspace,x):
    """Index of the base column under x (piece centre), None outside the base."""
    if not workspace:return None
    left=workspace.get('origin_x',0.)
    for i,w in enumerate(workspace.get('widths',[])):
        if left<=x<left+w:return i
        left+=w
    return None


def default_kinds(workspace,x):
    """The types ticked when the Matière window opens for a piece centred at x: Dessus → Cuir,
    Doublures → Tissu and Cuir, Renforts → Renfort, Aides → Gabarit, elsewhere every type."""
    from cad import column_types   # 0.19.13: what the base's column holds (bases libres)
    kinds=column_types(workspace,column_at(workspace,x)) if x is not None and workspace else None
    return set(kinds) if kinds else set(TYPES)


def has_refente(archives,name):
    """0.18.0: a Tissu is not split (no Refente); any other or unknown material may be."""
    return not (name in (archives or {}).get('materials',[]) and info(archives,name)['type']=='Tissu')


def next_match(values,char,current=None):
    """Letter jump in a list: the first value starting with ``char``, or the next one after
    ``current`` when it already starts with it (a second press goes to the next word)."""
    key=sort_key(char)
    if not key:return None
    hits=[i for i,v in enumerate(values) if sort_key(v).startswith(key)]
    if not hits:return None
    if current is not None and current in hits:
        later=[i for i in hits if i>current]
        return later[0] if later else hits[0]
    return hits[0]


def bind_letter_jump(box,on_pick=None):
    """A key pressed in the list goes to the next word starting with that letter."""
    def jump(e):
        if not e.char or not e.char.isprintable() or e.char.isspace() or e.state & 0x4:return None
        values=list(box.get(0,'end'));sel=box.curselection();i=next_match(values,e.char,sel[0] if sel else None)
        if i is None:return 'break'
        box.selection_clear(0,'end');box.selection_set(i);box.activate(i);box.see(i)
        if on_pick:on_pick(i)
        else:box.event_generate('<<ListboxSelect>>')
        return 'break'
    box.bind('<KeyPress>',jump,add='+')
    return jump


# --- Fiche de coupe ------------------------------------------------------------------------

def surface_mm2(s):
    """Surface of a piece: its outer contour (holes are NOT deducted, as asked)."""
    from geometry import path
    pts,_=path(s)
    if len(pts)<3:return 0.
    return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(pts,pts[1:]+pts[:1])))/2


def cost(surface_m2,quantity,price,waste):
    """surface × quantité × prix/m² × (1 + chute %); None without a price."""
    if price is None:return None
    return surface_m2*quantity*price*(1+(waste or 0)/100)
