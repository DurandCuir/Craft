"""0.17.0 « Préparation » tool and « Préparations » layer (see preparations.py).

Click inside a zone: the first click asks Parage (type, longueur pre-filled with the measured
width of the zone, épaisseur in tenths) or Teinte; the next clicks apply the same preparation to
other zones (each with its own width, unless a length was typed); Entrée ends. A click inside a
zone already prepared opens it again (to change it or « Supprimer »)."""
import math
import tkinter as tk
from tkinter import ttk,messagebox
import preparations as prep
from regions import region_at

FILL_TAG='prep_fill'


def visible(app):return bool(app.prefs.get('show_preparations',True))


def toggle(app):
    """« Afficher / masquer les préparations »: hidden, the zones and (0.19.36) the lines of the « Préparation » type go."""
    app.prefs['show_preparations']=not visible(app)
    try:app.persist_preferences()
    except OSError:pass
    if not visible(app):
        from craft_tools import prep_line
        zones={i for i in app.selected_ids() if app.items[i].get('preparation') or prep_line(app.items[i])}
        if zones:app.selected_set=set(app.selected_set)-zones;app.selected=min(app.selected_set) if app.selected_set else None
        if app.tool.get()=='preparation':app.set_tool('select')
    app.status.set('Préparations affichées.' if visible(app) else 'Préparations masquées.');app.refresh();app.highlight_tools()


# 0.19.14 « un genre de calque qui fait voir ou non les précoupes ou surcoupes » (in Préparations): hidden, they are
# neither drawn nor clicked nor snapped to; the exports, the PDF and the fiches keep them.
CUT_KEYS={'precut':'show_precuts','recut':'show_recuts'}


def cut_visible(app,which):return bool(app.prefs.get(CUT_KEYS[which],True))


def hidden_cut(app,s):
    """A précoupe (and its band) while « Précoupes » is hidden, a piece surcoupée (inside its précoupe) while
    « Surcoupes » is hidden; 0.19.36: a line of the « Préparation » type while the Préparations are hidden (neither
    drawn nor clicked nor snapped to)."""
    prefs=getattr(app,'prefs',None) or {}
    st=s.get('style')
    if (st.get('role')=='prep_line' if isinstance(st,dict) and 'role' in st else s.get('profile')=='Préparation'):
        return not prefs.get('show_preparations',True)
    if prefs.get('show_precuts',True) and prefs.get('show_recuts',True):return False
    if s.get('annotation'):return False
    if not prefs.get('show_precuts',True) and (s.get('surcoupe') or (s.get('preparation') or {}).get('kind')=='surcoupe'):return True
    return not prefs.get('show_recuts',True) and bool(s.get('owner_id')) and (s.get('style') or {}).get('role')=='surcoupe'


_HIDDEN={}


def hidden_ids(app):
    """The objects hidden by the layers (hidden_cut); 0.19.36: kept for the same drawing (with the Préparations hidden, the
    lines of the « Préparation » type are looked for at every move of the mouse: snaps, pick): a frozenset."""
    prefs=getattr(app,'prefs',None) or {}
    flags=(prefs.get('show_precuts',True),prefs.get('show_recuts',True),prefs.get('show_preparations',True))
    if all(flags):return set()
    version=app.__dict__.get('_doc_version') if hasattr(app,'__dict__') else None
    key=None if version is None else (id(app),id(app.items),len(app.items),version,flags)
    if key is not None and _HIDDEN.get('key')==key:return _HIDDEN['value']
    out=frozenset(i for i,s in enumerate(app.items) if hidden_cut(app,s))
    if key is not None:_HIDDEN.clear();_HIDDEN.update(key=key,value=out)
    return out


def toggle_cut(app,which):
    key=CUT_KEYS[which];app.prefs[key]=not cut_visible(app,which)
    try:app.persist_preferences()
    except OSError:pass
    hidden=hidden_ids(app)
    if hidden and app.selected_set&hidden:
        app.selected_set=set(app.selected_set)-hidden;app.selected=min(app.selected_set) if app.selected_set else None
    name='Précoupes' if which=='precut' else 'Surcoupes'
    app.status.set(f'{name} affichées.' if cut_visible(app,which) else f'{name} masquées (exports, PDF et fiches les gardent).');app.refresh();app.highlight_tools()


def start(app):
    app.finish_action();app.cancel();app.tool.set('preparation');app.last_command=('tool','preparation')
    app.selected=None;app.selected_set=set();app.prep_state=dict(settings=None,hover=None)
    if not visible(app):app.prefs['show_preparations']=True   # one sees the zones one prepares
    app.highlight_tools();app.refresh();app.status.set('Cliquer dans la zone à préparer.')


def cancel(app):
    app.prep_state=None
    try:app.canvas.delete('prep_hover')
    except Exception:pass


def host_of(items,p,region=None):
    """The piece holding the click: the smallest piece in Coupe externe around it; 0.19.36: else the piece in Coupe
    externe the zone ``region`` borders (a band of teinte outside the piece, between its edge and a line of the
    « Préparation » type: it went to that line), else the smallest closed shape (zones and those lines excluded)."""
    from entity_rules import closed_piece
    from precision_geometry import inside
    from geometry import bounds
    from craft_tools import style
    best=None
    for i,s in enumerate(items):
        if not closed_piece(s):continue
        st=style(s)
        if st['role']=='prep_line':continue
        x,y,X,Y=bounds([s])
        if not(x<=p[0]<=X and y<=p[1]<=Y) or not inside(s,p):continue
        key=(st['role']!='external',(X-x)*(Y-y))
        if best is None or key<best[0]:best=(key,i)
    if (best is None or best[0][0]) and region:
        k=bordered(items,region)
        if k is not None:return k
    return None if best is None else best[1]


BORDER=.05   # mm: a point of a zone's outline on a piece's contour


def bordered(items,region):
    """0.19.36: the piece in Coupe externe whose contour the outline of ``region`` (regions.region_at) runs along the
    most (some of its points on it, at BORDER), or None."""
    from entity_rules import closed_piece
    from geometry import bounds
    from craft_tools import style
    from precision_geometry import contour_location
    rings=[list(region.get('points') or ())]+[list(h) for h in region.get('holes') or ()]
    pts=[q for ring in rings for q in ring]
    if len(pts)<2:return None
    step=max(1,len(pts)//400);pts=pts[::step]
    x0=min(q[0] for q in pts)-1;y0=min(q[1] for q in pts)-1;x1=max(q[0] for q in pts)+1;y1=max(q[1] for q in pts)+1
    best=None
    for i,s in enumerate(items):
        if not closed_piece(s) or style(s)['role']!='external':continue
        try:
            a,b,A,B=bounds([s])
            if A<x0 or a>x1 or B<y0 or b>y1:continue
            near=[q for q in pts if a-BORDER<=q[0]<=A+BORDER and b-BORDER<=q[1]<=B+BORDER]
            on=sum(1 for q in near if math.dist(contour_location(s,q)[1],q)<=BORDER)
        except (ValueError,KeyError,TypeError,IndexError,ZeroDivisionError):continue
        if on>=2 and (best is None or on>best[0]):best=(on,i)
    return None if best is None else best[1]


ON_PIECE=.05   # mm: an end of a « Préparation » line on a piece's contour
OFFSET_MOST=10.   # mm: 0.19.39 an open « Préparation » line this near a piece's edge all along it (a teinte's) is the piece's
ALONG=.05   # mm: at one distance from the edge to this


def owner_of_line(items,i):
    """0.19.36 (review: hidden with the Préparations, a « Préparation » line stayed behind when its piece moved): the
    piece in Coupe externe the line ``i`` belongs to, or None: the smallest one its middle is inside (a line of a zone
    inside the piece); an open line, the piece both its ends are on (a teinte along some edges, 3 mm outside them), else
    (0.19.39) the only piece it runs along at one distance (OFFSET_MOST at most: a teinte of « Teinte des bords », its
    ends square to the edge); a closed line, the only piece it goes round (a teinte all round)."""
    from entity_rules import closed_piece
    from craft_tools import style
    from geometry import bounds,path
    from precision_geometry import inside,contour_location
    try:
        pts,closed=path(items[i])
        if len(pts)<2:return None
        x,y,X,Y=bounds([items[i]])
    except (ValueError,KeyError,TypeError,IndexError):return None
    middle=pts[len(pts)//2] if closed else __import__('craft_tools').at_distance(items[i],__import__('craft_tools').perimeter(items[i])/2)[0]
    pieces=[]
    for k,s in enumerate(items):
        if k==i or not closed_piece(s) or style(s)['role']!='external':continue
        try:pieces.append((k,s,bounds([s])))
        except (ValueError,KeyError,TypeError):continue
    def at(s,b,q):
        return b[0]-ON_PIECE<=q[0]<=b[2]+ON_PIECE and b[1]-ON_PIECE<=q[1]<=b[3]+ON_PIECE
    try:
        holding=[(b[2]-b[0])*(b[3]-b[1]) for k,s,b in pieces]
        within=[(area,k) for area,(k,s,b) in zip(holding,pieces) if at(s,b,middle) and inside(s,middle)]
        if within:return min(within)[1]
        if not closed:
            ends=[k for k,s,b in pieces if all(at(s,b,q) and math.dist(contour_location(s,q)[1],q)<=ON_PIECE for q in (pts[0],pts[-1]))]
            if len(ends)==1:return ends[0]
            if ends:return None
            # 0.19.39: a line at one distance all along a piece's edge (a teinte's, 3 mm outside: Teinte des bords; its
            # piece lost through a DWG Mozart): that piece, when it is the only one
            # (review) measured at the middles of its parts: a band round a sharp corner has its mitre d·√2 from the piece,
            # one ending on a side going in has its end on it (as Teinte des bords makes them: both lost their piece)
            middles=[((a[0]+b[0])/2,(a[1]+b[1])/2) for a,b in zip(pts,pts[1:])]
            if len(middles)==1:middles=[(pts[0][0]+(pts[1][0]-pts[0][0])*t,pts[0][1]+(pts[1][1]-pts[0][1])*t) for t in (.25,.5,.75)]
            samples=middles[::max(1,len(middles)//24)]
            along=[]
            for k,s,b in pieces:
                if x<b[0]-OFFSET_MOST or X>b[2]+OFFSET_MOST or y<b[1]-OFFSET_MOST or Y>b[3]+OFFSET_MOST:continue
                ds=[math.dist(contour_location(s,q)[1],q) for q in samples]
                if max(ds)-min(ds)<=ALONG and ON_PIECE<min(ds)<=OFFSET_MOST:along.append(k)
            return along[0] if len(along)==1 else None
        from precision_geometry import inside as within_line
        round_=[k for k,s,b in pieces if x<=b[0] and y<=b[1] and b[2]<=X and b[3]<=Y and within_line(items[i],path(s)[0][0])]
        return round_[0] if len(round_)==1 else None
    except (ValueError,KeyError,TypeError,IndexError,ZeroDivisionError):return None


def attach_lines(items,ids=None):
    """0.19.36 (review): the « Préparation » lines (``ids``, else all) without a piece given the piece they belong to
    (owner_of_line): they then move, turn and are copied with it, also hidden. How many were attached."""
    from craft_tools import prep_line
    from entity_rules import ensure_piece_id
    count=0
    for i in (range(len(items)) if ids is None else ids):
        if not 0<=i<len(items):continue
        s=items[i]
        if s.get('owner_id') or not prep_line(s):continue
        k=owner_of_line(items,i)
        if k is None:continue
        s['owner_id']=ensure_piece_id(items[k]);count+=1
    return count


def attach_loose(items,ids):
    """0.18.1: a zone without piece (a Mozart zone left beside its piece) moved onto a piece is
    attached to it: it then moves, turns and is copied with it. Returns how many were attached."""
    from entity_rules import ensure_piece_id
    count=0
    for i in ids:
        if not 0<=i<len(items):continue
        s=items[i]
        if not s.get('preparation') or s.get('owner_id'):continue
        try:centre=prep.placement(s)[0]
        except (ValueError,ZeroDivisionError,IndexError,TypeError):continue
        host=host_of(items,centre)
        if host is None:continue
        s['owner_id']=ensure_piece_id(items[host]);count+=1
    return count


def zone_at(items,p):
    """Index of the prepared zone under p (the smallest), or None."""
    best=None
    for i,s in enumerate(items):
        if not s.get('preparation'):continue
        pts=prep.ring_points(s)
        if prep.inside(pts,p):
            a=prep.area(pts)
            if best is None or a<best[0]:best=(a,i)
    return None if best is None else best[1]


def shown_items(app):
    """0.19.14: the objects the Préparation tool sees (not the précoupes / surcoupes hidden)."""
    hidden=hidden_ids(app)
    return [s for i,s in enumerate(app.items) if i not in hidden] if hidden else app.items


def region(app,p):
    try:return region_at(shown_items(app),p,app.scale)
    except (ValueError,KeyError,TypeError,ZeroDivisionError,IndexError):return None


def zone_width(s):
    """0.19.9: the width of a zone already there: the one measured when it was made, else w of the band
    of its area and outline (A = w·L, P = 2L + 2w, as regions.region_at)."""
    width=(s.get('preparation') or {}).get('width')
    if width:return float(width)
    pts=prep.ring_points(s);A=prep.area(pts);half=sum(math.dist(a,b) for a,b in zip(pts,pts[1:]+pts[:1]))/2;disc=half*half-4*A
    return round(2*A/(half+math.sqrt(disc)) if disc>=0 and half>0 else math.sqrt(max(A,0)),1)


def click(app,e):
    st=app.prep_state;p=app.raw(e)
    if st is None:return
    # 0.19.9: a zone already there first (reopened with its own outline, even where no region closes around
    # the click: 6 of the 20 zones of DIFORME, every Teinte); else the region of a new zone.
    existing=zone_at(app.items,p);found=None
    if existing is not None and hidden_cut(app,app.items[existing]):existing=None   # 0.19.14: a hidden précoupe's band
    if existing is None:
        found=region(app,p)
        if found is None:app.invalid_at(e,'Aucune zone fermée ici : cliquer entre des lignes qui se touchent.');return
    host=None
    if existing is None:
        shown=shown_items(app);k=host_of(shown,p,found)
        host=None if k is None else next(i for i,s in enumerate(app.items) if s is shown[k])
    if st['settings'] is None:return dialog(app,found,host,existing)   # first zone of the series
    if existing is not None and (app.items[existing].get('preparation') or {}).get('kind') not in prep.KINDS:
        return dialog(app,found,host,existing)   # 0.19.9: a zone with no button (« autre », précoupe) is asked, not changed by the series
    apply(app,found,host,existing,st['settings'])


def apply(app,found,host,existing,settings):
    from entity_rules import ensure_piece_id
    zone=app.items[existing] if existing is not None and existing<len(app.items) else None   # 0.19.9
    if zone is None and found is None:return   # 0.19.9: the zone reopened is no longer there
    width=found['width'] if zone is None else zone_width(zone)
    own=(zone.get('preparation') or {}).get('length') if zone is not None else None   # 0.19.9: its own length, as the window shows it
    data=dict(kind=settings['kind'],type=settings.get('type',''),thickness=settings.get('thickness'),width=width)
    if settings['kind']=='parage':data['length']=settings['length'] if settings.get('typed') else own or round(width,1)
    if settings['kind']=='teinte':data['couches']=settings.get('couches',1)   # 0.18.1 « Couche(s) » of the fiche
    app.snapshot()
    if zone is not None:z=zone;edit_zone(z,data)
    else:
        owner=ensure_piece_id(app.items[host]) if host is not None else None
        z=prep.zone(found,data,owner);app.items.append(z)
        attach_lines(app.items)   # 0.19.36 (review): the « Préparation » lines without a piece go to theirs
    app.canvas.delete('prep_hover');app.refresh()
    app.status.set(f'{z["preparation"]["label"].capitalize()} · cliquer la zone suivante.')


def edit_zone(s,data):
    """0.19.9: a zone already there keeps its outline and its piece, only what it prepares changes (it took
    the region found under the click: a rembord of DIFORME, 420 mm², became its whole piece, 34 180 mm²).
    What the window does not show stays (the width measured, the type of a Mozart teinte)."""
    old=s.get('preparation') or {};kind=data['kind']
    new=dict(old) if old.get('kind')==kind else {k:v for k,v in data.items() if k!='width'}
    new.update((k,data[k]) for k in {'parage':('type','length','thickness'),'teinte':('couches',)}.get(kind,()))
    if old.get('width') is not None:new['width']=old['width']
    new['label']=prep.label(kind,'' if kind=='teinte' else new.get('type',''),new.get('length'),new.get('thickness'))   # as an import (show_mozart)
    s['preparation']=new
    if old.get('kind')!=kind:s['style']=dict(s.get('style') or {},color=prep.BASE.get(kind,prep.BASE['autre']),role='preparation')


def remove(app,existing):
    if existing is None or existing>=len(app.items):return
    line=__import__('teinte_ui').drop_line(app,existing)   # 0.19.39: a band of « Teinte des bords »: its line with it
    app.snapshot()
    for j in sorted({existing}|({line} if line is not None else set()),reverse=True):del app.items[j]
    app.refresh();app.status.set('Préparation supprimée · cliquer une autre zone.')


def dialog(app,found,host,existing):
    """Parage (type, longueur, épaisseur) or Teinte; filled in from the zone already there."""
    old=app.items[existing]['preparation'] if existing is not None else {}
    win=app.dialog('Préparation');panel=app.p['panel'];measured=round(found['width'],1) if found is not None else zone_width(app.items[existing])   # 0.19.9
    kind=tk.StringVar(value=old.get('kind','parage'));kind_type=tk.StringVar(value=old.get('type','Rembord') if old.get('kind','parage')=='parage' else 'Rembord')
    length=tk.StringVar(value=prep.fmt(old.get('length') if old.get('length') else measured));thick=tk.StringVar(value=prep.fmt(old.get('thickness')))
    coats=tk.StringVar(value=str(old.get('couches',1)) if old.get('kind')=='teinte' else '1')
    options=dict(bg=panel,fg=app.p['ui_ink'],selectcolor=app.field_background(),activebackground=panel,font=('Segoe UI',10))
    row=tk.Frame(win,bg=panel);row.pack(fill='x',padx=16,pady=(14,6))
    form=tk.Frame(win,bg=panel);form.pack(fill='x',padx=16)
    dye=tk.Frame(win,bg=panel);dye.pack(fill='x',padx=16)
    def refresh_form():
        for w in form.winfo_children():
            w.grid() if kind.get()=='parage' else w.grid_remove()
        for w in dye.winfo_children():
            w.grid() if kind.get()=='teinte' else w.grid_remove()
    for value,text in (('parage','Parage'),('teinte','Teinte')):__import__('modern_style').make_radio(row,text=text,variable=kind,value=value,command=refresh_form,**options).pack(side='left',padx=(0,12))
    app.label(form,'Type').grid(row=0,column=0,sticky='w',pady=3);ttk.Combobox(form,textvariable=kind_type,values=list(prep.PARAGE_TYPES),width=14).grid(row=0,column=1,sticky='w',padx=8)
    app.label(form,f'Longueur (mm) · zone {prep.fmt(measured)}').grid(row=1,column=0,sticky='w',pady=3);field=app.entry(form,length,8);field.grid(row=1,column=1,sticky='w',padx=8)
    app.label(form,'Épaisseur (/10, facultatif)').grid(row=2,column=0,sticky='w',pady=3);app.entry(form,thick,8).grid(row=2,column=1,sticky='w',padx=8)
    app.label(dye,'Couche(s)').grid(row=0,column=0,sticky='w',pady=3);app.entry(dye,coats,4).grid(row=0,column=1,sticky='w',padx=8)
    refresh_form()
    def number(text,label,low,high,length=False):
        text=text.strip().replace(',','.')
        if not text:return None
        try:v=__import__('command_catalog').length_field(text) if length else float(text)   # 0.19.42: a length, « 5 cm » too
        except ValueError:raise ValueError(f'{label} : nombre attendu.') from None
        if not low<=v<=high:raise ValueError(f'{label} : {prep.fmt(low)} à {prep.fmt(high)}.')
        return v
    def valid(e=None):
        if kind.get() not in prep.KINDS:
            # 0.19.9: a kind without its button (a Mozart « autre » zone, a surcoupe) is kept as it is (it became
            # « PARAGE » and lost its type); the next click asks again.
            win.destroy();app.canvas.focus_set();return 'break'
        try:
            settings=dict(kind=kind.get())
            if kind.get()=='teinte':
                coats_n=number(coats.get(),'Couche(s)',1,20) or 1
                if coats_n!=int(coats_n):raise ValueError('Couche(s) : un nombre entier de 1 à 20.')   # (review 0.19.49: « 2,5 » became 2 without a word)
                settings['couches']=int(coats_n)
            if kind.get()=='parage':
                value=number(length.get(),'Longueur',.1,500,True)
                settings.update(type=kind_type.get().strip(),thickness=number(thick.get(),'Épaisseur',.1,99),length=value if value is not None else measured,typed=value is not None and abs(value-measured)>.05)
        except ValueError as exc:messagebox.showerror('Préparation',str(exc),parent=win);return 'break'
        win.destroy();app.canvas.focus_set()
        if app.prep_state is None:return 'break'
        app.prep_state['settings']=settings;apply(app,found,host,existing,settings);return 'break'
    buttons=tk.Frame(win,bg=panel);buttons.pack(fill='x',padx=16,pady=(10,14))
    if existing is not None:app.button(buttons,'Supprimer',lambda:(win.destroy(),remove(app,existing))).pack(side='left')
    app.button(buttons,'Valider',valid).pack(side='right')
    win.bind('<Return>',valid);field.focus_set();field.select_range(0,'end')
    win.protocol('WM_DELETE_WINDOW',lambda:(win.destroy(),app.canvas.focus_set()))
    return win


def enter(app):
    """Entrée: the series of zones is over."""
    app.prep_state=None;app.canvas.delete('prep_hover');app.complete_command('preparation');app.highlight_tools();app.refresh()
    app.status.set('Préparations terminées.');return 'break'


def motion(app,e):
    """The zone under the pointer is outlined before the click (like a hatch preview)."""
    app.cursor_screen=(e.x,e.y);app._inside_plan=True;st=app.prep_state;p=app.raw(e)
    c=app.canvas;key=(round(e.x/3),round(e.y/3))
    if st.get('hover_key')!=key:
        st['hover_key']=key;c.delete('prep_hover');existing=zone_at(app.items,p)
        if existing is not None and hidden_cut(app,app.items[existing]):existing=None   # 0.19.14
        found=region(app,p) if existing is None else None   # 0.19.9: the zone a click reopens, else the new region
        pts=prep.ring_points(app.items[existing]) if existing is not None else prep.keyhole(found['points'],found.get('holes')) if found else None
        if pts:
            c.create_polygon(*[v for q in pts for v in app.to_screen(q)],fill='',outline=app.p['accent'],width=2,dash=(4,3),tags='prep_hover')
    app.draw_crosshair()


def draw_zone(app,s,tags,chosen):
    """The zone: its fill under the lines and its label in the middle; hidden with the layer."""
    if not visible(app):return None
    c=app.canvas;pts=prep.ring_points(s)
    if len(pts)<3:return None
    flat=[v for p in pts for v in app.to_screen(p)];kind=(s.get('preparation') or {}).get('kind','autre')
    if tags:return c.create_polygon(*flat,fill='',outline=app.p['accent'],width=1,tags=tags)   # a preview: outline only
    fill=prep.fill_colour(kind,app.p.get('canvas','#484b50'))
    item=c.create_polygon(*flat,fill=fill,outline=app.p['accent'] if chosen else '',width=2 if chosen else 0,tags=FILL_TAG)
    text=(s.get('preparation') or {}).get('label','')
    if text:
        (x,y),angle,height=prep.placement(s);px=height*app.scale
        if px>=5:
            from ui_widgets import contrast_color,zoom_tag
            c.create_text(*app.to_screen((x,y)),text=text,angle=angle,fill=contrast_color(fill),font=('Segoe UI',-max(1,round(px)),'bold'),tags=zoom_tag('prep_label','t',height))
    return item


def lower_fills(app):
    """Fills under every line. 0.19.25: the smoothed picture just over them (display_render: their inside shows through
    its empty parts; the lines over them are in it)."""
    c=app.canvas
    if c.find_withtag(FILL_TAG):
        # 0.19.43 (fluidity): already so, nothing restacked (Tk would show the whole picture and every zone again)
        if __import__('display_render').fills_in_place(c):return
        c.tag_lower(FILL_TAG)
        if c.find_withtag('_smooth_display'):c.tag_raise('_smooth_display',FILL_TAG)
