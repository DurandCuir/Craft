"""0.19.13 Réseau, Étirer, Couper au point (as his AutoCAD; proposed on 05/11, « go » on 07/11).

Réseau: the selection (with what belongs to its pieces: crans, texts, stitches, zones) copied in columns and rows
(the step between two copies, in mm) or round a centre clicked (a number of copies over an angle, turned or not).
Étirer: a window drawn by two corners; the points of the lines and polylines inside it move by the displacement
given by two more clicks (or a value typed, ORTHO); an object entirely inside moves whole.
Couper au point: a click on a line, a polyline or an arc cuts it there in two (a closed outline is opened there)."""
import copy
import math
import time
import uuid
from types import SimpleNamespace


# --- Réseau ---------------------------------------------------------------------------------------------------------

def _copies(items, ids):
    """The objects ``ids`` and what belongs to their pieces, copied with new ids (their links kept between them)."""
    from entity_rules import linked_selection
    group = linked_selection(items, ids)
    return group, fresh_copies([items[i] for i in group])


def fresh_copies(source):
    """Copies of ``source`` with new identifiers (Copier, Ctrl+V, Réseau, Symétrie « Garder »): a copied piece keeps its own
    marks; 0.19.9 / 0.19.22: a mark copied without its piece is no longer tied to that piece (own_marks gives it the contour
    or the piece it is put on); 0.19.49 (review R4): a piece inside its précoupe copied alone is a piece of its own holding
    the copies of its marks. (Full review 0.19.49: Réseau and Symétrie kept a cran copied alone to the original piece:
    moved, turned and deleted with it, wherever it was put.)"""
    from entity_rules import fresh_copy_ids, inner_piece, carrier
    copies = fresh_copy_ids([copy.deepcopy(s) for s in source])
    groups = {}
    pieces = {s.get('piece_id') for s in copies}
    alone = {}
    for s in copies:
        if inner_piece(s) and carrier(s) not in pieces:
            alone.setdefault(carrier(s), []).append(s)
    for c, found in alone.items():
        if len(found) != 1:
            continue   # (several pieces of one précoupe: as before, each mark to the piece it is put on)
        s = found[0]
        s.pop('owner_id', None)
        s['piece_id'] = uuid.uuid4().hex
        pieces.add(s['piece_id'])
        for q in copies:
            if q is not s and q.get('owner_id') == c:
                q['owner_id'] = s['piece_id']
    for s in copies:
        if s.get('dimension_group'):
            s['dimension_group'] = groups.setdefault(s['dimension_group'], uuid.uuid4().hex)
        if s.get('owner_id') and s.get('owner_id') not in pieces:
            s.pop('owner_id', None)
    return copies


def own_marks(app, pairs):
    """(source, copy) of copies just added to the drawing (after its snapshot): a mark copied without its piece (left
    without one by fresh_copies) belongs to where it is put, as with Copier (0.19.9): a cran to the contour it stands on
    (none: free), a text, an ID, a Piqûre or a zone to the piece it is in (0.19.22). The number of marks given a piece."""
    from craft_tools import cran_host
    from entity_rules import ensure_piece_id
    import piece_ids
    n = 0
    for s, q in pairs:
        # (review R3 0.19.50) never a piece: a piece inside its précoupe copied alone (a piece of its own, fresh_copies) put on
        # another piece became that piece's, moved and deleted with it, its own crans and Piqûre left where they were
        if not s.get('owner_id') or q.get('owner_id') or q.get('piece_id'):
            continue
        if q.get('is_notch'):
            h = cran_host(app.items, q)
            if h is not None:   # (0.19.39: as place_notch)
                q['owner_id'] = app.items[h].get('piece_id') or app.items[h].get('owner_id') or ensure_piece_id(app.items[h])
        else:
            h = piece_ids.host_at(app.items, piece_ids.centre(q))
            if h is not None:
                q['owner_id'] = ensure_piece_id(app.items[h])
        n += bool(q.get('owner_id'))
    return n


def _sources(items, ids, new):
    """The object each new one of a Réseau copies (_copies: the objects of the selection in their order, copy after copy)."""
    from entity_rules import linked_selection
    group = linked_selection(items, ids)
    return [items[group[k % len(group)]] for k in range(len(new))] if group else []


def rectangular(items, ids, columns, rows, dx, dy):
    """The new objects of a rectangular array (the original stays at column 1, row 1)."""
    from transform import moved
    columns, rows = int(columns), int(rows)
    if columns < 1 or rows < 1 or columns * rows < 2 or columns * rows > 500:
        raise ValueError('Réseau : de 2 à 500 exemplaires (colonnes × rangées).')
    out = []
    for r in range(rows):
        for c in range(columns):
            if r == 0 and c == 0:
                continue
            group, copies = _copies(items, ids)
            out += [moved(s, c * dx, r * dy) for s in copies]
    return out


def polar(items, ids, centre, count, angle=360., turn=True):
    """The new objects of a polar array: ``count`` copies in all (the original included) over ``angle`` degrees
    (360: evenly round a whole turn), turned with the array or only moved. 0.19.22: clockwise, as Rotation (``angle``
    negative: the other way); transform.affine turns the other way for a positive angle."""
    from entity_rules import linked_selection
    out = []
    for place in polar_places(items, linked_selection(items, ids), centre, count, angle, turn):
        group, copies = _copies(items, ids)
        out += [place(s) for s in copies]
    return out


def polar_places(items, group, centre, count, angle=360., turn=True):
    """For each copy of a polar array (the original left out): a function giving a shape's copy there (the objects
    ``group`` turned about ``centre``, or only moved with the middle of all of them)."""
    from transform import transform, moved, affine
    from geometry import bounds
    count = int(count)
    if not 2 <= count <= 500:
        raise ValueError('Réseau polaire : de 2 à 500 exemplaires.')
    if not 0 < abs(angle) <= 360:
        raise ValueError('Angle : de 1 à 360°.')
    step = angle / count if abs(angle) >= 360 - 1e-9 else angle / (count - 1)
    if not turn:
        x, y, X, Y = bounds([items[i] for i in group])
        c = ((x + X) / 2, (y + Y) / 2)
    out = []
    for k in range(1, count):
        a = -step * k
        if turn:
            out.append(lambda s, a=a: transform(s, centre, a))
        else:
            q = affine(centre, a)(c)
            out.append(lambda s, d=(q[0] - c[0], q[1] - c[1]): moved(s, *d))
    return out


# --- Étirer ---------------------------------------------------------------------------------------------------------

def _inside(p, box):
    x0, y0, x1, y1 = box
    return min(x0, x1) - 1e-9 <= p[0] <= max(x0, x1) + 1e-9 and min(y0, y1) - 1e-9 <= p[1] <= max(y0, y1) + 1e-9


def stretched(s, box, dx, dy):
    """``s`` with its points inside ``box`` moved by (dx, dy); None when nothing of it is inside."""
    from geometry import bounds, path
    from transform import moved
    from cad import polygon
    try:
        x, y, X, Y = bounds([s])
    except (ValueError, KeyError, TypeError):
        return None
    if _inside((x, y), box) and _inside((X, Y), box):
        return moved(s, dx, dy)
    if s.get('annotation') or s.get('drill') or s.get('is_notch') or s.get('components'):
        ref = (s['x'] + s['w'] / 2, s['y'] + s['h'] / 2) if s.get('drill') else (s.get('x', 0), s.get('y', 0))
        return moved(s, dx, dy) if _inside(ref, box) else None
    # (full review 0.19.49, fluidity: the preview went through every point of every polyline at each move of the mouse, 22 ms
    # on Keith Haring) a line or a polyline whose box does not meet the window has none of its points in it
    if X < min(box[0], box[2]) - 1e-6 or x > max(box[0], box[2]) + 1e-6 or Y < min(box[1], box[3]) - 1e-6 or y > max(box[1], box[3]) + 1e-6:
        return None
    if s.get('kind') == 'line':
        a, b = (s['x'], s['y']), (s['x'] + s['w'], s['y'] + s['h'])
        a2 = (a[0] + dx, a[1] + dy) if _inside(a, box) else a
        b2 = (b[0] + dx, b[1] + dy) if _inside(b, box) else b
        if (a2, b2) == (a, b):
            return None
        q = copy.deepcopy(s)
        q.update(x=a2[0], y=a2[1], w=b2[0] - a2[0], h=b2[1] - a2[1])
        return q
    if s.get('spline') or s.get('ellipse') or s.get('kind') == 'circle':
        return None   # (a curve only moves when it is entirely inside)
    if s.get('kind') == 'rect':
        # (full review 0.19.49) a rectangle becomes the polyline of its corners (and rounds) carrying what it carried: its
        # outline alone came out (a piece lost its Coupe externe, its id and its fiche: its crans, texts and Piqûre without it)
        from precision_geometry import canonical
        s = dict(s, **canonical(s))
    if s.get('kind') != 'poly':
        return None
    pts = [(s['x'] + px, s['y'] + py) for px, py in s['points']]
    moved_any = False
    out = []
    for p in pts:
        if _inside(p, box):
            out.append((p[0] + dx, p[1] + dy))
            moved_any = True
        else:
            out.append(p)
    if not moved_any:
        return None
    q = polygon(out, s.get('name', ''), bool(s.get('closed')))
    for key, value in s.items():
        if key not in q and key not in ('points',):
            q[key] = copy.deepcopy(value)
    if s.get('bulges'):
        q['bulges'] = list(s['bulges'])
    return q


def stretch(items, box, dx, dy):
    """[(index, new object)] of what the window ``box`` stretches."""
    out = []
    for i, s in enumerate(items):
        q = stretched(s, box, dx, dy)
        if q is not None:
            out.append((i, q))
    return out


# --- Couper au point ----------------------------------------------------------------------------------------------

def _split_bulge(q, p):
    """The two bulges of the arc ``q`` (precision_geometry.primitives) cut at ``p``."""
    a = math.atan2(p[1] - q['c'][1], p[0] - q['c'][0])
    d = (a - q['start']) % (2 * math.pi) if q['sweep'] > 0 else -((q['start'] - a) % (2 * math.pi))
    d = max(min(d, q['sweep']), 0.) if q['sweep'] > 0 else min(max(d, q['sweep']), 0.)
    return math.tan(d / 4), math.tan((q['sweep'] - d) / 4)


def _without_empty_sides(s):
    """The polyline ``s`` without the points that start a side of no length, as primitives() leaves those sides out: its
    points and its parts in step. (Review 0.19.50) a Rectangle (arrondi) whose rounds meet (a strap 10 mm wide with its
    5 mm: two half rounds; 10 x 10: a circle) or a point given twice: Couper au point took the part k for the side k of
    the points (the outline came out longer and beside itself, 71,4 → 79,5 mm; a closed polyline: IndexError)."""
    from cad import polygon
    pts = [(s['x'] + x, s['y'] + y) for x, y in s['points']]
    n, closed = len(pts), bool(s.get('closed'))
    empty = {i for i in range(n if closed else n - 1) if math.dist(pts[i], pts[(i + 1) % n]) < 1e-10}
    if not empty or len(empty) > n - 2:
        return s
    bulges = (list(s.get('bulges') or ()) + [0.] * n)[:n]
    kept = [i for i in range(n) if i not in empty]
    q = dict(s, **polygon([pts[i] for i in kept], s.get('name', ''), closed))
    q.pop('bulges', None)
    if any(bulges):
        q['bulges'] = [bulges[i] for i in kept]
    return q


def cut_at(s, p):
    """``s`` cut at its point nearest ``p``: [two objects] (an open line or polyline, an arc) or [one] (a closed outline
    opened there). ValueError: what cannot be cut."""
    from cad import polygon
    from precision_geometry import canonical, primitives
    if s.get('spline') or s.get('ellipse') or s.get('kind') == 'circle' or s.get('annotation') or s.get('drill') or s.get('is_notch'):
        raise ValueError('Couper au point : une ligne, une polyligne ou un arc.')
    if s.get('kind') == 'line':
        a, b = (s['x'], s['y']), (s['x'] + s['w'], s['y'] + s['h'])
        L = math.dist(a, b)
        t = max(0., min(1., ((p[0] - a[0]) * (b[0] - a[0]) + (p[1] - a[1]) * (b[1] - a[1])) / (L * L))) if L else 0.
        m = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        if min(math.dist(m, a), math.dist(m, b)) < 1e-6:
            raise ValueError('Couper au point : pas sur un bout.')
        one, two = copy.deepcopy(s), copy.deepcopy(s)
        one.update(w=m[0] - a[0], h=m[1] - a[1])
        two.update(x=m[0], y=m[1], w=b[0] - m[0], h=b[1] - m[1])
        return [one, two]
    if s.get('components'):
        # (full review 0.19.49) a shape made by Joindre (curves.compound) is cut as the one polyline of its lines and arcs; never
        # through its own points (two copies of the whole shape came out, the second one moved; closed: « tracé vide »)
        from curves import parts
        from editing import chain_polyline
        s = chain_polyline(parts(s), s, bool(s.get('closed')))
        if s is None:   # (a spline or an oval in it)
            raise ValueError('Couper au point : une ligne, une polyligne ou un arc.')
    # (full review 0.19.49) a rectangle: the polyline of its corners (and rounds) carrying what it carried (its outline alone:
    # a piece opened there lost its Coupe externe, its id and its fiche)
    s = dict(s, **canonical(s)) if s.get('kind') == 'rect' else canonical(s)
    if s.get('kind') != 'poly':
        raise ValueError('Couper au point : une ligne, une polyligne ou un arc.')
    s = _without_empty_sides(s)
    prims = primitives(s)
    best = None
    for k, q in enumerate(prims):
        if not q['sweep']:
            a, b = q['a'], q['b']
            L2 = (b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2
            t = max(0., min(1., ((p[0] - a[0]) * (b[0] - a[0]) + (p[1] - a[1]) * (b[1] - a[1])) / L2)) if L2 else 0.
            m = (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        else:
            ang = math.atan2(p[1] - q['c'][1], p[0] - q['c'][0])
            m = (q['c'][0] + q['r'] * math.cos(ang), q['c'][1] + q['r'] * math.sin(ang))
            d = (ang - q['start']) % (2 * math.pi) if q['sweep'] > 0 else (q['start'] - ang) % (2 * math.pi)
            if d > abs(q['sweep']):
                m = q['a'] if min(d - abs(q['sweep']), 2 * math.pi - d) == 2 * math.pi - d else q['b']
        dist = math.dist(m, p)
        if best is None or dist < best[0]:
            best = (dist, k, m)
    if best is None:
        raise ValueError('Couper au point : tracé vide.')
    _, k, m = best
    pts = [(s['x'] + x, s['y'] + y) for x, y in s['points']]
    bulges = list(s.get('bulges') or [0.] * len(prims))
    q = prims[k]
    b1, b2 = _split_bulge(q, m) if q['sweep'] else (0., 0.)
    keep = {key: copy.deepcopy(v) for key, v in s.items() if key not in ('points', 'bulges', 'closed', 'x', 'y', 'w', 'h', 'kind', 'notches', 'piece_id', 'piece_info')}
    at_vertex = math.dist(m, q['a']) < 1e-6 or math.dist(m, q['b']) < 1e-6
    if s.get('closed'):
        # opened at m: from m round the whole outline back to m
        n = len(pts)
        order = [(k + 1 + j) % n for j in range(n)]
        if math.dist(m, q['b']) < 1e-6:   # on a corner: the outline starts there
            seq = [pts[i] for i in order]
            bs = [bulges[(k + 1 + j) % n] for j in range(n)]
            seq.append(seq[0])
        elif math.dist(m, q['a']) < 1e-6:
            order = [(k + j) % n for j in range(n)]
            seq = [pts[i] for i in order] + [pts[k]]
            bs = [bulges[(k + j) % n] for j in range(n)]
        else:
            seq = [m] + [pts[i] for i in order] + [m]
            bs = [b2] + [bulges[(k + 1 + j) % n] for j in range(n - 1)] + [b1]
        out = polygon(seq, s.get('name', ''), False)
        out.update(keep)
        # 0.19.22 (found before installing): opened in one part, it stays the same piece: its texts, crans, ID… are
        # its own again once it is closed (Contrôle des contours, Joindre)
        for key in ('piece_id', 'piece_info'):
            if key in s:
                out[key] = copy.deepcopy(s[key])
        if any(bs):
            out['bulges'] = (bs + [0.])[:len(seq)]   # 0.19.22: one per point (13 for 14: « Arcs de polyligne invalides » at Enregistrer)
        return [out]
    if at_vertex and (k == 0 and math.dist(m, q['a']) < 1e-6 or k == len(prims) - 1 and math.dist(m, q['b']) < 1e-6):
        raise ValueError('Couper au point : pas sur un bout.')
    first = pts[:k + 1] + ([m] if math.dist(m, pts[k]) > 1e-6 else [])
    second = ([m] if math.dist(m, pts[k + 1]) > 1e-6 else []) + pts[k + 1:]
    b_first = bulges[:k] + ([b1] if math.dist(m, pts[k]) > 1e-6 else [])
    b_second = ([b2] if math.dist(m, pts[k + 1]) > 1e-6 else []) + bulges[k + 1:]
    if len(first) < 2 or len(second) < 2:
        raise ValueError('Couper au point : pas sur un bout.')
    one, two = polygon(first, s.get('name', ''), False), polygon(second, s.get('name', ''), False)
    for piece, bs in ((one, b_first), (two, b_second)):
        piece.update(keep)
        if any(bs):
            piece['bulges'] = (bs + [0.] * len(piece['points']))[:len(piece['points'])]   # 0.19.22: one per point
    return [one, two]


# --- the tools ------------------------------------------------------------------------------------------------------

def array_start(app):
    """Réseau: the selection, then the window. 0.19.21 (« quand je clique direct sur réseau sans avoir sélectionné une
    pièce il ne se passe rien »): without one, Réseau stays on and asks for it (« Sélectionner les objets, puis
    Entrée »); Entrée or the right click opens the window."""
    ids = sorted(app.selected_set or ({app.selected} if app.selected is not None else set()))
    if not ids:
        return app.start_pick_phase('array', [], lambda ids, points: array_picked(app, ids))
    return array_dialog(app, ids)


def array_picked(app, ids):
    app.pick_phase = None
    app.tool.set('select')
    app.highlight_tools()
    return array_dialog(app, ids)


def spacing(items, ids):
    """0.19.21 (« je vois pas l'utilité de réseau », 09/11/2026: copies 20 mm apart lay on each other): the steps
    between columns and between rows, the width and the height of what is copied plus 5 mm (to the tenth above)."""
    from entity_rules import linked_selection
    from geometry import bounds
    try:
        x, y, X, Y = bounds([items[i] for i in linked_selection(items, ids)])
    except (ValueError, KeyError, TypeError, IndexError):
        return 20., 20.
    return math.ceil(round((X - x + 5) * 10, 6)) / 10, math.ceil(round((Y - y + 5) * 10, 6)) / 10


def array_dialog(app, ids):
    import strap_ui
    st = dict(dict(kind='rect', columns=3, rows=1, dx=20., dy=20., count=6, angle=360., turn=True), **(app.prefs.get('array') or {}))
    st['dx'], st['dy'] = spacing(app.items, ids)   # 0.19.21: each time from what is copied (not the last piece's)
    kinds = [('rect', 'Rectangulaire'), ('polar', 'Polaire (centre au clic)')]

    def read(v):
        out = dict(kind=v['kind'])
        try:
            out['columns'] = int(v['columns'])
            out['rows'] = int(v['rows'])
            out['count'] = int(v['count'])
        except ValueError:
            raise ValueError('Colonnes, rangées, nombre : des nombres entiers.')
        out['dx'] = strap_ui._number(v['dx'])
        out['dy'] = strap_ui._number(v['dy'])
        # (review 0.19.42: strap_ui._number reads a length now, « 36 cm » = 360: degrees as before)
        # (full review 0.19.49: « 90° » taken as the Rotation takes it; a wrong angle said in French, not in Python's words)
        try:
            out['angle'] = float(str(v['angle']).strip().rstrip('°').strip().replace(',', '.'))
        except ValueError:
            out['angle'] = math.nan
        if not math.isfinite(out['angle']):
            raise ValueError('Polaire : taper l’angle total en degrés.')
        out['turn'] = bool(v['turn'])
        return out

    def done(chosen):
        if chosen['kind'] == 'rect':
            try:
                new = rectangular(app.items, ids, chosen['columns'], chosen['rows'], chosen['dx'], chosen['dy'])
            except ValueError as exc:
                app.status.set(str(exc))
                return
            _add(app, new, f'Réseau : {chosen["columns"]} × {chosen["rows"]}.', _sources(app.items, ids, new))
        else:
            app.tool.set('array_centre')
            app.array_state = dict(ids=ids, settings=chosen)
            app.highlight_tools()
            app.status.set('Réseau polaire : cliquer le centre.')
    win = strap_ui.form(app, 'Réseau', [('choice', 'Type', 'kind', kinds, st['kind']),
                                        ('entry', 'Colonnes', 'columns', str(st['columns'])), ('entry', 'Rangées', 'rows', str(st['rows'])),
                                        ('entry', 'Pas entre colonnes (mm)', 'dx', strap_ui.mm(st['dx'])),
                                        ('entry', 'Pas entre rangées (mm)', 'dy', strap_ui.mm(st['dy'])),
                                        ('entry', 'Polaire : nombre d’exemplaires', 'count', str(st['count'])),
                                        ('entry', 'Polaire : angle total (°)', 'angle', strap_ui.mm(st['angle'])),
                                        ('check', 'Polaire : tourner les copies', 'turn', st['turn'])], read, 'array', done)
    # 0.19.22 (proposed 11/11: « Réseau : aperçu des copies avant Valider », GO 13/11/2026): the copies drawn on the plan,
    # light, as the numbers are typed (a polar array: as its centre is chosen, after Valider).
    v = getattr(win, '_form', None)
    if not v:
        return win

    def show():
        app.__dict__.pop('_array_job', None)
        if not win.winfo_exists():
            return
        try:
            if next((value for value, text in kinds if text == v['kind'].get()), 'rect') != 'rect':
                raise ValueError
            columns, rows = int(v['columns'].get()), int(v['rows'].get())
            dx, dy = strap_ui._number(v['dx'].get()), strap_ui._number(v['dy'].get())
            if columns < 1 or rows < 1 or not 2 <= columns * rows <= 500:
                raise ValueError
            from transform import moved
            parts = shown_parts(app.items, ids, columns * rows - 1, PREVIEW_SHAPES)
            new = frames(app.items, ids, columns, rows, dx, dy) if parts is None else \
                [moved(app.items[i], c * dx, r * dy) for r in range(rows) for c in range(columns) if r or c for i in parts]
        except (ValueError, TypeError, OverflowError):
            new = []
        preview(app, new)

    def later(*_):
        job = app.__dict__.get('_array_job')
        if job:
            app.after_cancel(job)
        app._array_job = app.after(60, show)   # once the typing pauses
    for name in ('kind', 'columns', 'rows', 'dx', 'dy'):
        v[name].trace_add('write', later)
    win.bind('<Destroy>', lambda e: preview(app, []) if e.widget is win else None, add='+')
    show()
    return win


PREVIEW_MOST = 60   # copies drawn in a preview; more: their frames only
# 0.19.22 (review: 5 pieces of DIFORME with their marks × 60 copies, 14 000 items, Craft busy 0,7 s at each value typed;
# the polar one 88 ms at each move of the mouse): the shapes drawn at most (copies × objects), the outlines alone beyond
# (no crans, texts, marks), then frames; the polar preview, which follows the mouse, at most 25 times a second.
PREVIEW_SHAPES = 400
PREVIEW_MOVING = 120
PREVIEW_EVERY = .04


def _mark(s):
    return bool(s.get('annotation') or s.get('is_notch') or s.get('piece_badge') or s.get('drill') or s.get('dimension_group'))


def shown_parts(items, ids, copies, most):
    """The objects a preview of ``copies`` copies draws: those copied (with their pieces' marks) while that stays
    under ``most`` shapes, else their outlines alone; None: too many, frames instead."""
    from entity_rules import linked_selection
    if copies + 1 > PREVIEW_MOST:
        return None
    group = linked_selection(items, ids)
    if copies * len(group) <= most:
        return group
    lines = [i for i in group if not _mark(items[i])]
    return lines if lines and copies * len(lines) <= most else None


def frames(items, ids, columns, rows, dx, dy):
    """The frame of each copy of a large rectangular array (its preview)."""
    from cad import shape
    from entity_rules import linked_selection
    from geometry import bounds
    columns, rows = int(columns), int(rows)
    if columns < 1 or rows < 1 or columns * rows < 2 or columns * rows > 500:
        raise ValueError('Réseau : de 2 à 500 exemplaires (colonnes × rangées).')
    x, y, X, Y = bounds([items[i] for i in linked_selection(items, ids)])
    return [shape('rect', '', x + c * dx, y + r * dy, X - x, Y - y) for r in range(rows) for c in range(columns) if r or c]


def preview(app, shapes):
    c = app.canvas
    c.delete('array_preview')
    for s in shapes:
        try:
            app.draw_shape(s, '#a3a8aa', 1, ('array_preview',))
        except (ValueError, KeyError, TypeError, IndexError):
            continue
    for item in c.find_withtag('array_preview'):
        if c.type(item) == 'line':
            c.itemconfigure(item, fill='#a3a8aa')


def centre_preview(app, e=None):
    """0.19.22: Réseau polaire: the copies round the point under the mouse, before its click (at most every
    PREVIEW_EVERY s: the last place of the mouse drawn a moment later)."""
    st = app.__dict__.get('array_state')
    if not st:
        return
    job = st.pop('_job', None)
    if job:
        try:
            app.after_cancel(job)
        except Exception:
            pass
    wait = st.get('_at', 0.) + PREVIEW_EVERY - time.monotonic()
    if wait > 0:
        st['_job'] = app.after(max(1, int(wait * 1000)), centre_preview, app)
        return
    st['_at'] = time.monotonic()
    s = st['settings']
    try:
        from entity_rules import linked_selection
        from geometry import bounds
        from cad import polygon
        group = linked_selection(app.items, st['ids'])
        places = polar_places(app.items, group, app.pointer_world, s['count'], s['angle'], s['turn'])
        parts = shown_parts(app.items, st['ids'], len(places), PREVIEW_MOVING)
        if parts is None:
            x, y, X, Y = bounds([app.items[i] for i in group])
            shapes = [polygon([(x, y), (X, y), (X, Y), (x, Y)], '', True)]
        else:
            shapes = [app.items[i] for i in parts]
        new = [place(q) for place in places for q in shapes]
    except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError):
        new = []
    preview(app, new)


def _add(app, new, message, sources=()):
    if not new:
        return
    app.snapshot()
    start = len(app.items)
    app.items.extend(new)
    own_marks(app, zip(sources, new))   # (full review 0.19.49) a mark copied without its piece: where it is put, as Copier
    app.selected_set = set(range(start, len(app.items)))
    app.selected = start
    app.tool.set('select')
    app.highlight_tools()
    app.refresh()
    app.status.set(message)


def array_centre_click(app, e):
    st = app.__dict__.get('array_state')
    if not st:
        return None
    c = app.point(e)
    s = st['settings']
    try:
        new = polar(app.items, st['ids'], c, s['count'], s['angle'], s['turn'])
    except ValueError as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    app.array_state = None
    app.canvas.delete('array_preview')
    _add(app, new, f'Réseau polaire : {s["count"]} exemplaires.', _sources(app.items, st['ids'], new))
    return 'break'


def stretch_start(app):
    app.finish_action()
    app.cancel()
    app.tool.set('stretch')
    app.last_command = ('tool', 'stretch')
    app.stretch_state = dict(corners=[], base=None)
    app.highlight_tools()
    app.status.set('Étirer : premier coin de la fenêtre (ce qui est dedans bouge).')


def stretch_click(app, e):
    st = app.__dict__.get('stretch_state')
    if st is None:
        return None
    p = app.point(e)
    if len(st['corners']) < 2:
        st['corners'].append(p)
        app.status.set('Étirer : coin opposé.' if len(st['corners']) == 1 else 'Étirer : point de base.')
        return 'break'
    if st['base'] is None:
        st['base'] = p
        app.status.set('Étirer : point d’arrivée (ou une distance tapée + Entrée).')
        return 'break'
    return stretch_finish(app, p[0] - st['base'][0], p[1] - st['base'][1])


def stretch_finish(app, dx, dy):
    st = app.stretch_state
    box = (*st['corners'][0], *st['corners'][1])
    changes = stretch(app.items, box, dx, dy)
    from geometry import newly_crossed
    from entity_rules import geometry_entity
    # (review R4) only what is drawn and cut: a zone (a teinte band outside the piece, a rembord band inside it, a précoupe's
    # band), a Piqûre or the line of a teinte follow their piece afterwards (refit_stitches): the window cutting through one
    # of them refused a piece that stays clean (a corner moved 5 mm past its teinte band: « le contour se croise »)
    crossed = [i for i, q in changes if geometry_entity(q) and not q.get('stitch') and not q.get('teinte_band')
               and newly_crossed(app.items[i], q)]
    if crossed:
        # 0.19.49 (« Étirer qui croise le contour ») refused, the tool still waiting for its point d'arrivée (another one, or
        # another distance typed)
        x, y = getattr(app, 'cursor_screen', (0, 0))
        if hasattr(app, 'invalid_at'):
            app.invalid_at(SimpleNamespace(x=x, y=y), 'Étirer : le contour se croise.')
        else:
            app.status.set('Étirer : le contour se croise.')
        return 'break'
    if not changes:
        app.status.set('Étirer : rien dans la fenêtre.')
    else:
        app.snapshot()
        old = {i: app.items[i] for i, q in changes}
        for i, q in changes:
            app.items[i] = q
        if hasattr(app, 'refit_stitches'):
            # 0.19.49: the Piqûres and the « Teinte des bords » bands of a piece stretched follow it, as after a grip or Échelle
            # (each point of a Piqûre in the window moved with it: on an arc it came 0,09 to 4,85 mm from the edge of COIN)
            # (hunt 0.19.49, reviewer C) a piece inside its précoupe too (its marks carry the précoupe's id: entity_rules.carrier, the
            # piece inside first), and its crans put back on its contour (a cran on a slanted side stretched was left beside it)
            from entity_rules import carrier
            import surcoupe
            pairs = {}
            for i, q in sorted(changes, key=lambda e: surcoupe.is_precut(e[1])):
                if carrier(q) and not q.get('is_notch'):
                    pairs.setdefault(carrier(q), []).append((old[i], q))
            app.refit_stitches(pairs, old)
            if hasattr(app, 'reseat_crans'):
                app.reseat_crans({k: v[0] for k, v in pairs.items()})
        app.status.set(f'Étirer : {len(changes)} objet{"s" if len(changes) > 1 else ""}.')
    app.stretch_state = dict(corners=[], base=None)
    app.canvas.delete('stretch_preview')
    app.refresh()
    return 'break'


def stretch_preview(app, e):
    st = app.__dict__.get('stretch_state')
    c = app.canvas
    c.delete('stretch_preview')
    if not st or not st['corners']:
        return
    p = app.point(e)
    a = st['corners'][0]
    b = st['corners'][1] if len(st['corners']) > 1 else p
    (x0, y0), (x1, y1) = app.to_screen(a), app.to_screen(b)
    c.create_rectangle(x0, y0, x1, y1, outline=app.p.get('accent', '#61c9ee'), dash=(6, 4), width=1.5, tags=('stretch_preview',))
    if st['base'] is not None:
        dx, dy = p[0] - st['base'][0], p[1] - st['base'][1]
        box = (*st['corners'][0], *st['corners'][1])
        for i, q in stretch(app.items, box, dx, dy):
            app.draw_shape(q, app.p['accent'], 1, ('stretch_preview',))


def break_start(app):
    app.finish_action()
    app.cancel()
    app.tool.set('break_point')
    app.last_command = ('tool', 'break_point')
    app.highlight_tools()
    app.status.set('Couper au point : cliquer sur la ligne, la polyligne ou l’arc, là où la couper.')


def break_click(app, e):
    raw = app.raw(e)
    i = app.pick(raw)
    if i is None:
        app.invalid_at(e, 'Cliquer sur une ligne, une polyligne ou un arc.')
        return 'break'
    p = app.point(e)
    try:
        parts = cut_at(app.items[i], p)
    except (ValueError, ZeroDivisionError) as exc:
        app.invalid_at(e, str(exc))
        return 'break'
    app.snapshot()
    app.items[i:i + 1] = parts
    app.status.set('Coupé en deux.' if len(parts) == 2 else 'Contour ouvert à ce point.')
    app.refresh()
    return 'break'


# --- Lisser --------------------------------------------------------------------------------------------------------

def smoothed(s):
    """0.19.13 « Lisser » (proposed on 03/11: « elle passe d'un coup à la spline lisse de la 0.19.7, ses points
    gardés »): the spline made again through its points (its fit points, else the ends of its pieces) with a
    continuous curvature; its start / end tangents and everything else it carries kept."""
    from curves import spline, cubics
    sp = s.get('spline') or {}
    if not sp:
        raise ValueError('pas une spline.')
    closed = bool(s.get('closed'))
    if sp.get('fit'):
        pts = [(s['x'] + x, s['y'] + y) for x, y in sp['fit']]
    else:
        cs = cubics(s)
        pts = [tuple(c[0]) for c in cs] + ([tuple(cs[-1][3])] if cs and not closed else [])
    if closed and len(pts) > 2 and math.dist(pts[0], pts[-1]) < 1e-6:
        pts = pts[:-1]
    clean = [p for k, p in enumerate(pts) if k == 0 or math.dist(p, pts[k - 1]) > 1e-6]
    q = spline(clean, closed, s.get('name', 'Spline'), tangents=None if closed else sp.get('tangents'))
    for key, value in s.items():
        if key not in q and key not in ('points', 'bulges', 'spline', 'closed', 'kind', 'x', 'y', 'w', 'h'):
            q[key] = copy.deepcopy(value)
    return q
