"""0.19.13 Fiche de pièce comme Mozart (proposed on 05/11: « coups de presse, morceaux dans l'emporte-pièce, morceaux
pour le modèle, refentes 2 à 4 avec tolérance, reflétés, écart géométrique %, multiplier surface, couleur, couper
avec »): the fields kept with the piece's Matière (piece_info['material'] and its label's identification), beside its
Quantité (Mozart's « morceaux pour le modèle ») and its Refente.

Mozart's block PITDATIM: where each value is (0.19.44, from his piece TEST made in Mozart: see MAP below; 0.19.13 had
guessed from his 32 DWG, where most of them are equal or 0). Where Mozart keeps the tolérances is not known yet: every
field also goes in Craft's own data of the block (extended data CRAFT), so that it comes back from a DWG Mozart. The
attributes of a block read from a Mozart file are kept (``mozart``) and written back as they were when Craft has
nothing else for them."""
import math

APP = 'CRAFT'
# key, label in the window, kind, default
FIELDS = (
    ('ep', 'Morceaux dans l’emporte-pièce', 'count', '1'),
    ('coups', 'Coups de presse', 'count', ''),   # '' : morceaux pour le modèle ÷ morceaux dans l'emporte-pièce
    ('tolerance', 'Tolérance', 'tenths', ''),
    ('refente2', 'Refente 2', 'tenths', ''), ('tolerance2', 'Tolérance', 'tenths', ''),
    ('refente3', 'Refente 3', 'tenths', ''), ('tolerance3', 'Tolérance', 'tenths', ''),
    ('refente4', 'Refente 4', 'tenths', ''), ('tolerance4', 'Tolérance', 'tenths', ''),
    ('reflected', 'Reflétés', 'zero', '0'),
    ('surface', 'Multiplier la surface', 'factor', '1'),
    ('ecart', 'Écart géométrique (%)', 'percent', '0'),
    ('couleur', 'Couleur', 'text', ''),
    ('couper_avec', 'Couper avec', 'text', ''),
)
KEYS = tuple(f[0] for f in FIELDS)
DEFAULTS = {k: d for k, _, _, d in FIELDS}
LABELS = {k: label for k, label, _, _ in FIELDS}


def _num(text):
    text = str(text if text is not None else '').strip().replace(',', '.')
    if not text:
        return None
    value = float(text)
    if not math.isfinite(value):
        raise ValueError
    return value


def fmt(value):
    """7.0 → '7', 7.5 → '7,5'."""
    if value is None:
        return ''
    return f'{value:.3f}'.rstrip('0').rstrip('.').replace('.', ',')


def values(data):
    """The fields of a Matière (its identification), as typed, with their defaults."""
    data = data or {}
    return {k: str(data.get(k, DEFAULTS[k]) if data.get(k) is not None else DEFAULTS[k]) for k in KEYS}


def check(fields, quantity=1):
    """The fields typed in the window, checked: {key: text} (French decimal comma); a short French message otherwise."""
    out = {}
    for key, label, kind, default in FIELDS:
        text = str(fields.get(key, default) if fields.get(key) is not None else default).strip()
        if kind == 'text':
            if len(text) > 60:
                raise ValueError(f'{label} : 60 caractères au plus.')
            out[key] = text
            continue
        try:
            value = _num(text)
        except ValueError:
            raise ValueError(f'{label} : nombre attendu.') from None
        if value is None:
            out[key] = default
            continue
        if kind == 'count':
            if value != int(value) or not 1 <= value <= 999:
                raise ValueError(f'{label} : nombre entier de 1 à 999.')
        elif kind == 'zero':
            if value != int(value) or not 0 <= value <= quantity:
                raise ValueError(f'{label} : nombre entier de 0 à {quantity} (la quantité).')
        elif kind == 'tenths':
            if not 0 <= value <= 99 or (value == 0 and not key.startswith('tolerance')):
                raise ValueError(f'{label} : 0,1 à 99 dixièmes.')
        elif kind == 'factor':
            if not .01 <= value <= 100:
                raise ValueError(f'{label} : 0,01 à 100.')
        elif kind == 'percent':
            if not 0 <= value <= 100:
                raise ValueError(f'{label} : 0 à 100 %.')
        out[key] = fmt(value)
    if out['coups'] == str(auto_coups(quantity, out['ep'])):
        out['coups'] = ''   # follows the quantity
    return out


def number(data, key):
    try:
        value = _num(values(data)[key])
    except ValueError:
        value = None
    return _num(DEFAULTS[key]) if value is None and DEFAULTS[key] else value


def auto_coups(quantity, ep):
    try:
        per = max(1, int(_num(ep) or 1))
    except ValueError:
        per = 1
    return max(1, math.ceil(max(1, int(quantity)) / per))


def coups(data, quantity):
    """Coups de presse: as typed, else the quantity ÷ morceaux dans l'emporte-pièce, rounded up."""
    typed = number(data, 'coups')
    return int(typed) if typed else auto_coups(quantity, values(data)['ep'])


def lines(data, quantity):
    """What the fiches say besides the name, the quantity and the refente: [« Refente 2 : 12/10 », …]."""
    v = values(data)
    out = []
    if v['tolerance']:
        out.append(f'Tolérance ± {v["tolerance"]}/10')
    for n in (2, 3, 4):
        if v[f'refente{n}']:
            out.append(f'Refente {n} : {v[f"refente{n}"]}/10' + (f' ± {v[f"tolerance{n}"]}/10' if v[f'tolerance{n}'] else ''))
    per = number(data, 'ep') or 1
    if per > 1 or v['coups']:
        out.append(f'{coups(data, quantity)} coup{"s" if coups(data, quantity) > 1 else ""} de presse' + (f' ({fmt(per)} par emporte-pièce)' if per > 1 else ''))
    if (number(data, 'reflected') or 0) > 0:
        n = int(number(data, 'reflected'))
        out.append(f'dont {n} reflété{"s" if n > 1 else ""}')
    if (number(data, 'surface') or 1) != 1:
        out.append(f'Surface × {v["surface"]}')
    if (number(data, 'ecart') or 0) > 0:
        out.append(f'Écart géométrique {v["ecart"]} %')
    if v['couleur']:
        out.append('Couleur ' + v['couleur'])
    if v['couper_avec']:
        out.append('Couper avec ' + v['couper_avec'])
    return out


def cut_lines(data, quantity):
    """For the fiche de coupe (at most two lines): « 2 coups de presse (2 par emporte-pièce) · dont 1 reflété »,
    « Couleur NOIR · Couper avec 2024 »."""
    every = lines(data, quantity)
    first = [x for x in every if 'coup' in x and 'presse' in x or x.startswith('dont ')]
    second = [x for x in every if x.startswith(('Couleur ', 'Couper avec '))]
    return [' · '.join(part) for part in (first, second) if part]


def refente_lines(data):
    """For the fiche refente and the nomenclature: the tolérance and the refentes 2 to 4, in one line (or none)."""
    every = [x for x in lines(data, 1) if x.startswith(('Tolérance', 'Refente '))]
    return [' · '.join(every)] if every else []


# --- Mozart ------------------------------------------------------------------------------------------------------
def _mm(tenths):
    try:
        value = _num(tenths)
    except ValueError:
        value = None
    return f'{value / 10:.6g}' if value and value > 0 else '0'


# 0.19.44 (his piece TEST made in the lycée's Mozart, 19/11, every box of « Déclaration des données de la pièce » with
# its own value; and his DIFORME and TILTED, 79 pieces): where Mozart keeps each one in PITDATIM. NPEZZI coups de presse
# (the number of TESTO1), AREANETTA morceaux pour le modèle, TIPOLOGIA morceaux dans l'emporte-pièce, NUM9 reflétés,
# NUM3 multiplier la surface, NUM1 / NUM2 / NUM4 / NUM5 refentes 1 to 4 (mm), NUM6 the matière's code in Mozart's
# archive, NUM8 couleur, NUM12 couper avec, SFRIDOGEO écart géométrique; TESTO2 to TESTO5 the lines Mozart shows under
# the name: the couleur, the reflétés (« 0 D - 2 G »), « Refente à 1,1 », « 2ème ref. à 1,2 ». (Craft 0.19.13 to
# 0.19.43 had NPEZZI / AREANETTA / NUM3 / NUM6 otherwise: its files, marked by none of « map=2 », read as before.)
MAP = 'map=2'


def _comma(mm):
    return mm.replace('.', ',')


def shown_lines(data, quantity, refente=''):
    """The lines Mozart shows under the matière (TESTO2 to TESTO5), in its order."""
    v = values(data)
    out = []
    if v['couleur']:
        out.append(v['couleur'])
    reflected = int(number(data, 'reflected') or 0)
    if reflected:
        out.append(f'{max(0, coups(data, quantity) - reflected)} D - {reflected} G')
    if _mm(refente) != '0':
        out.append('Refente à ' + _comma(_mm(refente)))
    if _mm(v['refente2']) != '0':
        out.append('2ème ref. à ' + _comma(_mm(v['refente2'])))
    return (out + [''] * 4)[:4]


def pieces_per_model(data, quantity):
    """« pour 1,5 pf »: the models the press cuts make, when they are not one (Mozart's TESTO1: 2 coups of 3 pieces for
    a model of 4); '' otherwise."""
    per = number(data, 'ep') or 1
    ratio = coups(data, quantity) * per / max(1, int(quantity))
    return '' if abs(ratio - 1) < 1e-9 else ' pour ' + fmt(ratio) + ' pf'


def mozart_attributes(data, quantity, refente=''):
    """{tag: value} of the PITDATIM block for this Matière: the attributes read from Mozart's file (``mozart``) with
    what Craft knows put in its place."""
    data = data or {}
    out = {k: str(v) for k, v in (data.get('mozart') or {}).items() if isinstance(k, str)}
    v = values(data)
    out.update(NPEZZI=str(coups(data, quantity)), AREANETTA=str(max(1, int(quantity))), TIPOLOGIA=str(int(number(data, 'ep') or 1)),
               NUM9=str(int(number(data, 'reflected') or 0)), NUM3=f'{number(data, "surface") or 1:.6g}',
               NUM1=_mm(refente), NUM2=_mm(v['refente2']), NUM4=_mm(v['refente3']), NUM5=_mm(v['refente4']),
               NUM8=v['couleur'], SFRIDOGEO=f'{number(data, "ecart") or 0:.6g}')
    kept = str(out.get('NUM12') or '')
    out['NUM12'] = kept if v['couper_avec'] and kept.split('  ')[0].strip() == v['couper_avec'] else v['couper_avec']
    for tag, line in zip(('TESTO2', 'TESTO3', 'TESTO4', 'TESTO5'), shown_lines(data, quantity, refente)):
        out[tag] = line
    return out


def xdata(data):
    """Craft's own data of the block: every field, « clé=valeur » (0.19.44: and MAP, Mozart's places)."""
    v = values(data)
    return [(1001, APP), (1002, '{')] + [(1000, f'{k}={v[k]}'[:250]) for k in KEYS] + [(1000, MAP), (1002, '}')]


def legacy(craft):
    """True for the data of a block written by Craft 0.19.13 to 0.19.43 (its own places for NPEZZI, AREANETTA, NUM3, NUM6)."""
    craft = [str(x) for x in craft or ()]
    return bool(craft) and MAP not in craft


def from_mozart(attributes, craft=(), quantity=1):
    """The fields of a Matière read from a PITDATIM block (its attributes {tag: value}) and Craft's data of the block
    (« clé=valeur » strings): Craft's first, Mozart's attributes over them (Mozart may have changed them since)."""
    out = {}
    for item in craft or ():
        key, _, value = str(item).partition('=')
        if key in DEFAULTS:
            out[key] = value.strip()[:60]

    def tenths(tag):
        try:
            mm = _num(attributes.get(tag))
        except ValueError:
            return None
        return fmt(round(mm * 10, 3)) if mm and mm > 0 else ''

    def whole(tag):
        try:
            return int(_num(attributes.get(tag)) or 0)
        except (ValueError, OverflowError):
            return 0
    old = legacy(craft)   # 0.19.44: Mozart's places (MAP), or those of Craft 0.19.13 to 0.19.43
    ep = whole('NUM3' if old else 'TIPOLOGIA')
    if ep >= 1:
        out['ep'] = str(min(999, ep))
    hits = whole('AREANETTA' if old else 'NPEZZI')
    if hits >= 1:
        out['coups'] = '' if hits == auto_coups(quantity, out.get('ep', '1')) else str(min(999, hits))
    for n, tag in ((2, 'NUM2'), (3, 'NUM4'), (4, 'NUM5')):
        if old and n > 2:
            break
        value = tenths(tag)
        if value is not None and tag in attributes:
            out[f'refente{n}'] = value
    if not old:
        if 'NUM9' in attributes and 0 <= whole('NUM9') <= quantity:
            out['reflected'] = str(whole('NUM9'))
        try:
            factor = _num(attributes.get('NUM3'))
        except ValueError:
            factor = None
        if factor is not None and .01 <= factor <= 100:
            out['surface'] = fmt(factor)
    for tag, key in (('NUM8', 'couleur'), ('NUM6' if old else 'NUM12', 'couper_avec')):
        if tag in attributes:
            value = str(attributes.get(tag) or '')
            typed = out.get(key) or ''
            if not old and key == 'couper_avec' and typed and value.startswith(typed):
                continue   # (review: « VEAU  NOIR » typed in Craft, kept whole)
            out[key] = (value if old else value.split('  ')[0]).strip()[:60]   # (Mozart's NUM12: the matière's line of its archive)
    try:
        gap = _num(attributes.get('SFRIDOGEO'))
    except ValueError:
        gap = None
    if gap is not None and 0 <= gap <= 100:
        out['ecart'] = fmt(gap)
    raw = {k: str(v) for k, v in attributes.items()}
    if old:
        raw.pop('NUM6', None)   # (Craft's « couper avec » there: Mozart keeps the matière's code of its archive in it)
    try:
        return dict(check(values(out), quantity), mozart=raw)
    except ValueError:   # 0.19.44: a value out of Craft's limits by default, the others kept (and the attributes)
        good = {}
        for key, value in values(out).items():
            try:
                check(dict(values(good), **{key: value}), quantity)
            except ValueError:
                continue
            good[key] = value
        try:
            return dict(check(values(good), quantity), mozart=raw)
        except ValueError:
            return dict(values({}), mozart=raw)


# --- the Matière window ------------------------------------------------------------------------------------------
def build(app, frame, data, quantity):
    """The fields in the Matière window, under Quantité and Refente (``frame``: packed by the caller; ``quantity``:
    the window's Quantité, which the coups de presse follow until another number is typed there):
    dict(variables={key: StringVar}, refentes=[the widgets a Tissu hides], read=the fields as typed)."""
    import tkinter as tk
    v = values(data)
    variables = {k: tk.StringVar(value=v[k]) for k in KEYS}
    auto = [None]

    def count():
        try:
            return max(1, int(str(quantity.get()).strip()))
        except (ValueError, tk.TclError):
            return None

    def follow(*args):
        q = count()
        if q is None:
            return
        new = auto_coups(q, variables['ep'].get() or '1') if str(variables['ep'].get()).strip().isdigit() else auto[0]
        if new is None:
            return
        if variables['coups'].get().strip() in ('', str(auto[0])):
            variables['coups'].set(str(new))
        auto[0] = new
    follow()
    quantity.trace_add('write', follow)
    variables['ep'].trace_add('write', follow)

    def label(text, r, c):
        w = app.label(frame, text)
        w.grid(row=r, column=c, sticky='w', padx=(0 if c == 0 else 14, 6), pady=2)
        return w

    def field(key, r, c, width=5):
        e = app.entry(frame, variables[key], width)
        e.grid(row=r, column=c, sticky='w', pady=2)
        return e
    label('Morceaux dans l’emporte-pièce', 0, 0), field('ep', 0, 1), label('Coups de presse', 0, 2), field('coups', 0, 3)
    refentes = [label('Tolérance de la refente (± /10)', 1, 0), field('tolerance', 1, 1)]
    for row, n in ((2, 2), (3, 3), (4, 4)):
        refentes += [label(f'Refente {n} (/10)', row, 0), field(f'refente{n}', row, 1), label('Tolérance (± /10)', row, 2), field(f'tolerance{n}', row, 3)]
    label('Reflétés', 5, 0), field('reflected', 5, 1), label('Multiplier la surface', 5, 2), field('surface', 5, 3)
    label('Écart géométrique (%)', 6, 0), field('ecart', 6, 1)
    label('Couleur', 7, 0), field('couleur', 7, 1, 14), label('Couper avec', 7, 2), field('couper_avec', 7, 3, 14)

    def read():
        out = {k: variables[k].get() for k in KEYS}
        q = count()
        if q is not None and out['coups'].strip() == str(auto_coups(q, out['ep'] or '1')):
            out['coups'] = ''
        return out
    return dict(variables=variables, refentes=refentes, read=read)
