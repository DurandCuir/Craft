"""0.19.54 « Contour d’une pièce en un clic » (proposé le 26/11/2026, « ok je pense c bien oui », go du 27/11 à 0 h 14) :
le bord d’une pièce prise en photo (``image_lines.piece_region`` : des points serrés, à peu près un par pixel, ici en mm)
fait comme une pièce dessinée : des côtés droits et des arcs, chaque point du bord à ``tol`` au plus de ce qui est fait.

- les coins (``corners``) : un virage d’au moins ``CORNER`` degrés sur ``span`` mm de part et d’autre, qui ne tourne guère
  plus sur le double (un arrondi, lui, tourne deux fois plus) ;
- les crans (``notches``) : une encoche dans le bord (en V ou en U, de ``DEPTH_LEAST`` à ``DEPTH_MOST`` de profondeur,
  ``MOUTH_MOST`` de large au plus, entre deux parties du bord dans le même alignement) : retirée du bord, sa place gardée
  pour un cran de Craft ;
- entre deux coins, le plus long côté droit qui tienne, sinon le plus long arc (``_Sums`` : sommes cumulées, chaque essai
  sans relire les points ; le résultat vérifié point par point) ; deux voisins qui tiennent ensemble sont réunis ;
- les jonctions : deux côtés droits à leur croisement ; un arc presque tangent à ses deux côtés droits devient l’arrondi
  exact entre eux (tangent aux deux, du rayon qui suit le mieux ses points) ; sinon au croisement le plus proche.

Rien ici n’appelle Tk."""
import math

CORNER = 35.        # degrees: a turn that big within ``span`` each way is a corner (if not much bigger within twice that)
FILLET = 12.        # degrees: an arc whose ends turn that little from the sides beside it is their rounding
MOUTH_MOST = 4.     # mm: the widest mouth of a notch
DEPTH_LEAST = .7    # mm: a dent less deep is the edge itself (a cut not quite straight)
DEPTH_MOST = 6.     # mm: deeper, a part of the piece (a slot), never a notch
ALIGNED = 35.       # degrees: the edge before and after a notch goes the way of its mouth (at most that far from it)
RMS_SHARE = .42     # of ``tol``: the root mean square a side or an arc is first tried with (each point then checked)
LEAST = 3           # points: the fewest a side or an arc is made of
SPLIT = 90.         # degrees: an arc wider than that is cut in equal parts (as Craft's own arcs, curves.arc)
MOST_POINTS = 4000  # points: a piece cut in more is no piece (a polyline keeps 5 000 points at most: geometry.validate)


def _turn(u, v):
    """The signed angle (degrees) from the direction u to the direction v."""
    return math.degrees(math.atan2(u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1]))


def _unit(u):
    d = math.hypot(*u)
    return (u[0] / d, u[1] / d) if d else (0., 0.)


def area(pts):
    """The signed area of the closed line (shoelace): positive when its inside is on the left of its way."""
    return .5 * sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(pts, pts[1:] + pts[:1]))


def _lengths(pts):
    acc = [0.]
    for a, b in zip(pts, pts[1:]):
        acc.append(acc[-1] + math.dist(a, b))
    return acc, acc[-1] + math.dist(pts[-1], pts[0])


def _reach(acc, total, width):
    """For each point of a closed line, the index ``width`` mm before it and the one ``width`` mm after it."""
    n = len(acc)
    width = min(width, total / 3)

    def at(k):   # the length along the line of the unwrapped index k
        return acc[k % n] + (k // n) * total
    after, before = [0] * n, [0] * n
    j = 1
    for i in range(n):
        j = max(j, i + 1)
        while j < i + n - 1 and at(j) - at(i) < width:
            j += 1
        after[i] = j % n
    k = -n + 1
    for i in range(n):
        while k + 1 < i and at(i) - at(k + 1) >= width:
            k += 1
        before[i] = k % n
    return before, after


def corners(pts, span):
    """The indices of the corners of the closed line ``pts`` (see the module), in order."""
    n = len(pts)
    if n < 8:
        return []
    acc, total = _lengths(pts)
    b1, a1 = _reach(acc, total, span)
    b2, a2 = _reach(acc, total, 2 * span)

    def turn(i, b, a):
        p, q, r = pts[b], pts[i], pts[a]
        u, v = (q[0] - p[0], q[1] - p[1]), (r[0] - q[0], r[1] - q[1])
        if not (u[0] or u[1]) or not (v[0] or v[1]):
            return 0.
        return _turn(u, v)
    found = []
    for i in range(n):
        t1 = abs(turn(i, b1[i], a1[i]))
        if t1 < CORNER:
            continue
        if abs(turn(i, b2[i], a2[i])) > 1.4 * t1 + 8:   # turning on twice as far: a rounding, not a corner
            continue
        found.append((t1, i))
    found.sort(reverse=True)
    kept = []
    near = bytearray(n)   # (review 0.19.54, speed: a ragged edge 1 → 0,02 s) the points within span of a corner kept, marked
    for t1, i in found:   # by it: the same as comparing each with every corner kept; the sharpest of each place
        if near[i]:
            continue
        kept.append(i)
        for way in (1, -1):
            j = i
            for _ in range(n):
                d = abs(acc[i] - acc[j])
                if min(d, total - d) > span:
                    break
                near[j] = 1
                j = (j + way) % n
    return sorted(kept)


# --- notches ---------------------------------------------------------------------------------------------------------

def notches(pts, marks, inside):
    """The notches between corners ``marks`` of the closed line ``pts`` (``inside`` = 1 when its inside is on the left of
    its way, -1 else): [(first index, last index, mouth middle, depth)], not overlapping, in order."""
    n = len(pts)
    m = len(marks)
    if m < 2:
        return []
    acc, total = _lengths(pts)

    def along(i, j):
        d = acc[j] - acc[i]
        return d + total if d < 0 else d

    def heading(i, j):   # the way from index i to j
        return _unit((pts[j][0] - pts[i][0], pts[j][1] - pts[i][1]))

    def step_from(i, length, forward):   # the index about ``length`` mm from i, forward or back
        k = i
        for _ in range(n):
            nk = (k + 1) % n if forward else (k - 1) % n
            if (along(i, nk) if forward else along(nk, i)) > length:
                return nk
            k = nk
        return k
    found = []
    for k in range(m):
        for span in range(1, min(4, m - 1) + 1):
            a, b = marks[k], marks[(k + span) % m]
            chord = math.dist(pts[a], pts[b])
            path = along(a, b)
            if not (.1 <= chord <= MOUTH_MOST) or path > 2 * DEPTH_MOST + MOUTH_MOST or path < chord + 2 * DEPTH_LEAST * .8:
                continue
            u = heading(a, b)
            normal = (-u[1] * inside, u[0] * inside)   # toward the inside
            deepest, low, tip = 0., 0., None
            i = a
            while i != b:
                i = (i + 1) % n
                d = (pts[i][0] - pts[a][0]) * normal[0] + (pts[i][1] - pts[a][1]) * normal[1]
                if d > deepest:
                    deepest, tip = d, i
                low = min(low, d)
            if tip is None or not (DEPTH_LEAST <= deepest <= DEPTH_MOST) or low < -.3 or deepest < .5 * chord:
                continue
            s = (pts[tip][0] - pts[a][0]) * u[0] + (pts[tip][1] - pts[a][1]) * u[1]
            if not (-.25 * chord <= s <= 1.25 * chord):
                continue
            before = heading(step_from(a, 1.5, False), a)
            after = heading(b, step_from(b, 1.5, True))
            if abs(_turn(before, u)) > ALIGNED or abs(_turn(u, after)) > ALIGNED:
                continue
            found.append((chord, a, b, deepest))
    found.sort()
    taken = []
    out = []
    for chord, a, b, depth in found:
        if any(_overlap(a, b, c, d, n) for c, d in taken):
            continue
        taken.append((a, b))
        out.append((a, b, ((pts[a][0] + pts[b][0]) / 2, (pts[a][1] + pts[b][1]) / 2), depth))
    out.sort(key=lambda e: e[0])
    return out


def _overlap(a, b, c, d, n):
    def inside(x, lo, hi):
        return lo <= x <= hi if lo <= hi else x >= lo or x <= hi
    return inside(a, c, d) or inside(b, c, d) or inside(c, a, b) or inside(d, a, b)


def without_notches(pts, found, step):
    """The closed line with each notch's points replaced by its mouth (straight, a point each ``step`` mm)."""
    n = len(pts)
    drop = set()
    mouth = {}
    for a, b, _, _ in found:
        i = a
        while i != b:
            i = (i + 1) % n
            if i != b:
                drop.add(i)
        k = max(1, int(math.dist(pts[a], pts[b]) / step))
        mouth[a] = [(pts[a][0] + (pts[b][0] - pts[a][0]) * t / k, pts[a][1] + (pts[b][1] - pts[a][1]) * t / k) for t in range(1, k)]
    out = []
    for i in range(n):
        if i in drop:
            continue
        out.append(pts[i])
        out.extend(mouth.get(i, ()))
    return out


# --- sides and arcs ----------------------------------------------------------------------------------------------------

class _Sums:
    """Cumulated sums of a run of points (about its first one): the straight line and the circle nearest any part of it,
    each in a few operations."""

    def __init__(self, q):
        ox, oy = q[0]
        self.o = (ox, oy)
        keys = 10
        sums = [[0.] * (len(q) + 1) for _ in range(keys)]
        acc = [0.] * keys
        for k, (x, y) in enumerate(q, 1):
            x -= ox
            y -= oy
            z = x * x + y * y
            for j, v in enumerate((1., x, y, x * x, y * y, x * y, z, z * x, z * y, z * z)):
                acc[j] += v
                sums[j][k] = acc[j]
        self.s = sums

    def part(self, i, j):   # the sums of the points i..j (both kept)
        return [col[j + 1] - col[i] for col in self.s]

    def line_rms(self, i, j):
        n, sx, sy, sxx, syy, sxy = self.part(i, j)[:6]
        mx, my = sx / n, sy / n
        cxx, cyy, cxy = sxx / n - mx * mx, syy / n - my * my, sxy / n - mx * my
        least = (cxx + cyy) / 2 - math.sqrt(max(0., ((cxx - cyy) / 2) ** 2 + cxy * cxy))
        return math.sqrt(max(0., least))

    def circle(self, i, j):
        """(centre, radius, rms) of the circle nearest the points i..j (Kåsa, about their own middle: the sums about the
        run's first point give an ill-posed system far from it), None when they are on a line."""
        n, sx, sy, sxx, syy, sxy, sz, szx, szy, szz = self.part(i, j)
        mx, my = sx / n, sy / n
        c0 = mx * mx + my * my
        suu = sxx - n * mx * mx
        svv = syy - n * my * my
        suv = sxy - n * mx * my
        sw = sz - 2 * mx * sx - 2 * my * sy + n * c0   # w = u² + v² (u, v about the middle)
        swu = szx - 2 * mx * sxx - 2 * my * sxy + c0 * sx - mx * sw
        swv = szy - 2 * mx * sxy - 2 * my * syy + c0 * sy - my * sw
        sww = (szz + 4 * mx * mx * sxx + 4 * my * my * syy + n * c0 * c0 - 4 * mx * szx - 4 * my * szy + 2 * c0 * sz
               + 8 * mx * my * sxy - 4 * mx * c0 * sx - 4 * my * c0 * sy)
        det = suu * svv - suv * suv
        if det <= 1e-12 * max(1e-30, (suu + svv) ** 2):
            return None
        d = (-swu * svv + swv * suv) / det
        e = (-swv * suu + swu * suv) / det
        f = -sw / n
        rr = d * d / 4 + e * e / 4 - f
        if rr <= 0:
            return None
        radius = math.sqrt(rr)
        res = sww + d * d * suu + e * e * svv + f * f * n + 2 * d * swu + 2 * e * swv + 2 * f * sw + 2 * d * e * suv
        rms = math.sqrt(max(0., res) / n) / (2 * radius)
        return (self.o[0] + mx - d / 2, self.o[1] + my - e / 2), radius, rms


def _solve3(a, b):
    (a11, a12, a13), (a21, a22, a23), (a31, a32, a33) = a
    det = a11 * (a22 * a33 - a23 * a32) - a12 * (a21 * a33 - a23 * a31) + a13 * (a21 * a32 - a22 * a31)
    scale = max(abs(v) for row in a for v in row) or 1.
    if abs(det) <= 1e-12 * scale ** 3:
        return None
    out = []
    for k in range(3):
        m = [list(row) for row in a]
        for row in range(3):
            m[row][k] = b[row]
        out.append((m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                    + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])) / det)
    return out


def fit_line(q):
    """(a point, its unit direction along q's way) of the straight line nearest the points q (least squares across it)."""
    n = len(q)
    cx = sum(p[0] for p in q) / n
    cy = sum(p[1] for p in q) / n
    sxx = sum((p[0] - cx) ** 2 for p in q)
    syy = sum((p[1] - cy) ** 2 for p in q)
    sxy = sum((p[0] - cx) * (p[1] - cy) for p in q)
    angle = .5 * math.atan2(2 * sxy, sxx - syy)
    u = (math.cos(angle), math.sin(angle))
    if (q[-1][0] - q[0][0]) * u[0] + (q[-1][1] - q[0][1]) * u[1] < 0:
        u = (-u[0], -u[1])
    return (cx, cy), u


def line_off(q, line):
    (cx, cy), (ux, uy) = line
    return max(abs((p[0] - cx) * uy - (p[1] - cy) * ux) for p in q)


BUMP = 1.2    # mm: a bump or a dent along the edge as short as that (the root of a mat's line of the piece's colour, a
OVER = 2.2    # speck, the blur where a white line meets a black edge) may go up to OVER × tol off: a side stays one side


def _holds(dists, q, tol):
    """Each point within tol of what is made, but short runs of them (``BUMP`` mm at most, ``OVER`` × tol at most)."""
    if not dists or max(dists) > OVER * tol:
        return False
    if math.sqrt(sum(d * d for d in dists) / len(dists)) > .5 * tol:   # a curve's points all a little off (not a bump)
        return False
    run = 0.
    for k, d in enumerate(dists):
        if d > tol:
            if k:
                run += math.dist(q[k], q[k - 1])
            if run > BUMP:
                return False
        else:
            run = 0.
    return True


def line_holds(q, line, tol):
    (cx, cy), (ux, uy) = line
    return _holds([abs((p[0] - cx) * uy - (p[1] - cy) * ux) for p in q], q, tol)


def arc_holds(q, centre, radius, tol):
    return _holds([abs(math.dist(p, centre) - radius) for p in q], q, tol)


def refine_circle(q, centre, radius, rounds=4):
    """Gauss-Newton on the distances of the points to the circle (the circle of the sums is nearest by its squares)."""
    cx, cy = centre
    r = radius
    for _ in range(rounds):
        jtj = [[0.] * 3 for _ in range(3)]
        jtr = [0.] * 3
        for x, y in q:
            dx, dy = x - cx, y - cy
            d = math.hypot(dx, dy)
            if d < 1e-12:
                continue
            g = (-dx / d, -dy / d, -1.)
            res = d - r
            for a in range(3):
                jtr[a] += g[a] * res
                for b in range(3):
                    jtj[a][b] += g[a] * g[b]
        step = _solve3(jtj, [-v for v in jtr])
        if step is None:
            break
        cx, cy, r = cx + step[0], cy + step[1], r + step[2]
        if r <= 0:
            return None
        if max(abs(v) for v in step) < 1e-9 * max(1., r):
            break
    return (cx, cy), r


def arc_of(q, centre, radius):
    """The sweep (radians, signed: the way the points go round the centre) of the arc through q, None when they do not
    go round it one way only (a point going back more than a degree) or round it all."""
    cx, cy = centre
    total = 0.
    back = 0.
    prev = math.atan2(q[0][1] - cy, q[0][0] - cx)
    for x, y in q[1:]:
        a = math.atan2(y - cy, x - cx)
        d = (a - prev + math.pi) % (2 * math.pi) - math.pi
        total += d
        prev = a
    if abs(total) < 1e-9:
        return None
    sign = 1 if total > 0 else -1
    prev = math.atan2(q[0][1] - cy, q[0][0] - cx)
    for x, y in q[1:]:
        a = math.atan2(y - cy, x - cx)
        d = ((a - prev + math.pi) % (2 * math.pi) - math.pi) * sign
        if d < 0:
            back -= d
            if back > math.radians(1.):
                return None
        else:
            back = 0.
        prev = a
    if abs(total) > math.radians(340):
        return None
    return total


def arc_off(q, centre, radius):
    return max(abs(math.dist(p, centre) - radius) for p in q)


def _line_prim(q):
    line = fit_line(q)
    return dict(kind='line', pts=q, line=line)


def _arc_prim(q, tol, guess=None):
    """The arc through the points q, within tol of each of them, or None."""
    if len(q) < LEAST:
        return None
    if guess is None:
        s = _Sums(q).circle(0, len(q) - 1)
        if s is None:
            return None
        guess = s[:2]
    found = refine_circle(q, *guess)
    if found is None:
        return None
    centre, radius = found
    if radius > 1e5 or not arc_holds(q, centre, radius, tol):
        return None
    sweep = arc_of(q, centre, radius)
    if sweep is None:
        return None
    # an arc whose middle is within tol of its chord is a side (its centre is far and ill known)
    a, b = q[0], q[-1]
    chord = math.dist(a, b)
    sag = radius * (1 - math.cos(min(abs(sweep), math.pi) / 2)) if abs(sweep) <= math.pi else radius
    if sag <= tol * .5 and chord > 0:
        return None
    return dict(kind='arc', pts=q, centre=centre, radius=radius, sweep=sweep)


def _longest(i, last, ok):
    """The largest j in [i + LEAST - 1, last] for which ok(j) holds (ok true then false along j; the fewest points always
    taken)."""
    good = min(last, i + LEAST - 1)
    step = 1
    while good < last:
        nxt = min(last, good + step)
        if not ok(nxt):
            bad = nxt
            while bad - good > 1:
                mid = (good + bad) // 2
                if ok(mid):
                    good = mid
                else:
                    bad = mid
            return good
        good = nxt
        step *= 2
    return good


def run_fit(q, tol):
    """The sides and arcs along the open run of points q (no corner inside it), from its first point: each time the longest
    side, or the longest arc when it goes notably further."""
    m = len(q)
    if m < 2:
        return []
    if m <= LEAST:
        return [_line_prim(list(q))]
    sums = _Sums(q)
    rms = tol * RMS_SHARE
    out = []
    i = 0
    while i < m - 1:
        last = m - 1
        if last - i < LEAST:   # a few points left: on to the side before, or a side of their own
            if out and out[-1]['kind'] == 'line':
                merged = out[-1]['pts'] + q[i + 1:]
                line = fit_line(merged)
                if line_holds(merged, line, tol):
                    out[-1] = dict(kind='line', pts=merged, line=line)
                    break
            out.append(_line_prim(q[i:]))
            break
        jl = _longest(i, last, lambda j: sums.line_rms(i, j) <= rms)
        part = q[i:jl + 1]
        line = fit_line(part)
        if not line_holds(part, line, tol):   # checked point by point; shorter until it holds
            lo, hi = i + LEAST - 1, jl
            while hi - lo > 1:
                mid = (lo + hi) // 2
                p = q[i:mid + 1]
                if line_holds(p, fit_line(p), tol):
                    lo = mid
                else:
                    hi = mid
            jl = lo
        def arc_ok(j):
            c = sums.circle(i, j)
            return c is not None and c[2] <= rms and c[1] < 1e5
        ja = _longest(i, last, arc_ok)
        arc = None
        if ja > jl + max(LEAST, (jl - i) // 10):
            arc = _arc_prim(q[i:ja + 1], tol)
            if arc is None:   # shorter until it holds (or no better than the side)
                lo, hi = jl, ja
                while hi - lo > 1:
                    mid = (lo + hi) // 2
                    if _arc_prim(q[i:mid + 1], tol) is not None:
                        lo = mid
                    else:
                        hi = mid
                if lo > jl + max(LEAST, (jl - i) // 10):
                    ja = lo
                    arc = _arc_prim(q[i:ja + 1], tol)
        if arc is not None:
            out.append(arc)
            i = ja
        else:
            out.append(_line_prim(q[i:jl + 1]))
            i = jl
    return _settled(q, out, sums, tol)


SHIFT = 3.   # mm: how far a join between a side and an arc may move to where they fit best


def _settled(q, prims, sums, tol):
    """Each join between two primitives of the run moved to where both fit best (the longest side took a few of the
    arc's points, within tol: its direction leant toward the arc and the arc began late), each kept within tol."""
    if len(prims) < 2:
        return prims
    spans = []
    k = 0
    for p in prims:   # their places in q
        spans.append([k, k + len(p['pts']) - 1, p])
        k += len(p['pts']) - 1
    step = max(1e-9, sum(math.dist(a, b) for a, b in zip(q, q[1:])) / max(1, len(q) - 1))
    width = max(LEAST, int(SHIFT / step))

    def cost(kind, i, j):
        n = j - i + 1
        if kind == 'line':
            return n * sums.line_rms(i, j) ** 2
        c = sums.circle(i, j)
        return math.inf if c is None else n * c[2] ** 2
    for _ in range(2):
        for k in range(len(spans) - 1):
            a, b = spans[k], spans[k + 1]
            if a[2]['kind'] == b[2]['kind'] == 'line':
                continue
            lo = max(a[0] + LEAST - 1, a[1] - width)
            hi = min(b[1] - LEAST + 1, a[1] + width)
            best, at = math.inf, a[1]
            for j in range(lo, hi + 1):
                c = cost(a[2]['kind'], a[0], j) + cost(b[2]['kind'], j, b[1])
                if c < best:
                    best, at = c, j
            if at == a[1]:
                continue
            pa = _remade(q[a[0]:at + 1], a[2], tol)
            pb = _remade(q[at:b[1] + 1], b[2], tol)
            if pa is not None and pb is not None:
                a[1] = b[0] = at
                a[2], b[2] = pa, pb
    return [s[2] for s in spans]


def absorbed(prims, tol, closed=True):
    """A primitive between two others taken in by them when they hold with it shared between them at the best place (an
    arc going on a little into the side after a rounding, made of a bump where a mat's line crosses it: the rounding
    and the side again)."""
    changed = True
    rounds = 0
    while changed and len(prims) > 3 and rounds < 4:
        changed = False
        rounds += 1
        k = 0
        while k < len(prims) and len(prims) > 3:
            m = len(prims)
            if not closed and (k == 0 or k == m - 1):
                k += 1
                continue
            p, q, r = prims[k - 1], prims[k], prims[(k + 1) % m]
            if p is r:
                break
            pts = p['pts'] + q['pts'][1:] + r['pts'][1:]
            sums = _Sums(pts)
            lo = len(p['pts']) - 1
            hi = lo + len(q['pts']) - 1

            def cost(kind, i, j):
                n = j - i + 1
                if n < LEAST:
                    return math.inf
                if kind == 'line':
                    return n * sums.line_rms(i, j) ** 2
                c = sums.circle(i, j)
                return math.inf if c is None else n * c[2] ** 2
            best, at = math.inf, None
            for s in range(lo, hi + 1):
                c = cost(p['kind'], 0, s) + cost(r['kind'], s, len(pts) - 1)
                if c < best:
                    best, at = c, s
            if at is not None:
                a = _remade(pts[:at + 1], p, tol)
                b = _remade(pts[at:], r, tol) if a is not None else None
                if a is not None and b is not None:
                    if k == 0:   # (the first taken in: the last and the first of the closed edge)
                        prims[-1:] = [a]
                        prims[0:2] = [b]
                    elif k == m - 1:
                        prims[k - 1:k + 1] = [a]
                        prims[0] = b
                    else:
                        prims[k - 1:k + 2] = [a, b]
                    changed = True
                    continue
            k += 1
    return prims


def settled_pairs(prims, tol, corner, closed=True):
    """_settled again on each join of the whole edge (after neighbours were made one; also the join where the edge
    began), never on a corner: each pair read on its own."""
    m = len(prims)
    for k in range(m if closed else m - 1):
        if corner[k]:
            continue
        a, b = prims[k], prims[(k + 1) % m]
        if a['kind'] == b['kind'] == 'line' or a is b:
            continue
        q = a['pts'] + b['pts'][1:]
        got = _settled(q, [dict(a), dict(b)], _Sums(q), tol)
        if len(got) == 2:
            prims[k], prims[(k + 1) % m] = got
    return prims


def _remade(q, like, tol):
    """The primitive of the kind of ``like`` through the points q, within tol, or None."""
    if len(q) < 2:
        return None
    if like['kind'] == 'line':
        line = fit_line(q)
        return dict(kind='line', pts=q, line=line) if line_holds(q, line, tol) else None
    return _arc_prim(q, tol, (like['centre'], like['radius']))


def _joined(a, b, tol):
    """One side or one arc for the primitives a then b (their points one after the other), or None."""
    q = a['pts'] + b['pts'][1:]
    if a['kind'] == 'line' and b['kind'] == 'line':
        line = fit_line(q)
        if line_holds(q, line, tol):
            return dict(kind='line', pts=q, line=line)
        return _arc_prim(q, tol)   # a gentle curve the longest sides cut in two
    guess = None
    for p in (a, b):
        if p['kind'] == 'arc':
            guess = (p['centre'], p['radius'])
            break
    return _arc_prim(q, tol, guess)


def merged(prims, tol, closed_corners):
    """Neighbours that hold together within tol made one (never across a corner: ``closed_corners`` = the indices k
    whose join with k + 1 is one)."""
    prims = list(prims)
    corner = list(closed_corners)
    changed = True
    while changed and len(prims) > 1:
        changed = False
        k = 0
        while k < len(prims) - 1:
            j = _joined(prims[k], prims[k + 1], tol)   # (across a corner too: a true corner never holds as one)
            if j is not None:
                prims[k:k + 2] = [j]
                corner[k:k + 2] = [corner[k + 1]]
                changed = True
                continue
            k += 1
    return prims, corner


# --- joins ---------------------------------------------------------------------------------------------------------------

def _meet(l1, l2):
    (ax, ay), (ux, uy) = l1
    (bx, by), (vx, vy) = l2
    d = ux * vy - uy * vx
    if abs(d) < 1e-9:
        return None
    t = ((bx - ax) * vy - (by - ay) * vx) / d
    return (ax + t * ux, ay + t * uy)


def _foot(p, line):
    (cx, cy), (ux, uy) = line
    t = (p[0] - cx) * ux + (p[1] - cy) * uy
    return (cx + t * ux, cy + t * uy)


def _line_circle(line, centre, radius):
    (px, py), (ux, uy) = line
    fx, fy = px - centre[0], py - centre[1]
    b = fx * ux + fy * uy
    disc = b * b - (fx * fx + fy * fy - radius * radius)
    if disc < 0:
        return []
    root = math.sqrt(disc)
    return [(px + ux * t, py + uy * t) for t in (-b - root, -b + root)]


def _circles(c1, r1, c2, r2):
    d = math.dist(c1, c2)
    if d < 1e-12 or d > r1 + r2 or d < abs(r1 - r2):
        return []
    a = (r1 * r1 - r2 * r2 + d * d) / (2 * d)
    h = math.sqrt(max(0., r1 * r1 - a * a))
    ux, uy = (c2[0] - c1[0]) / d, (c2[1] - c1[1]) / d
    mx, my = c1[0] + ux * a, c1[1] + uy * a
    return [(mx - uy * h, my + ux * h), (mx + uy * h, my - ux * h)]


def _tangent_at(p, prim, start):
    """The unit direction of the primitive's way at its start (or end) point p."""
    if prim['kind'] == 'line':
        return prim['line'][1]
    cx, cy = prim['centre']
    r = (p[0] - cx, p[1] - cy)
    t = (-r[1], r[0]) if prim['sweep'] > 0 else (r[1], -r[0])
    return _unit(t)


def _join_point(a, b, near, reach):
    """Where the primitive a ends and b begins: their crossing nearest the points' own join ``near`` (within ``reach``),
    a tangent point when a side and an arc just touch, else the middle of the join seen from each."""
    candidates = []
    if a['kind'] == 'line' and b['kind'] == 'line':
        if abs(_turn(a['line'][1], b['line'][1])) >= 1.:
            p = _meet(a['line'], b['line'])
            if p is not None:
                candidates.append(p)
    elif a['kind'] == 'line' or b['kind'] == 'line':
        line, arc = (a, b) if a['kind'] == 'line' else (b, a)
        candidates.extend(_line_circle(line['line'], arc['centre'], arc['radius']))
        foot = _foot(arc['centre'], line['line'])
        if abs(math.dist(foot, arc['centre']) - arc['radius']) <= reach:
            candidates.append(foot)   # a side the arc's tangent: its tangent point
    else:
        candidates.extend(_circles(a['centre'], a['radius'], b['centre'], b['radius']))
    best = min(candidates, key=lambda p: math.dist(p, near), default=None)
    if best is not None and math.dist(best, near) <= reach:
        return best
    seen = [_closest(near, a), _closest(near, b)]
    return ((seen[0][0] + seen[1][0]) / 2, (seen[0][1] + seen[1][1]) / 2)


def _closest(p, prim):
    if prim['kind'] == 'line':
        return _foot(p, prim['line'])
    c, r = prim['centre'], prim['radius']
    u = _unit((p[0] - c[0], p[1] - c[1]))
    return (c[0] + u[0] * r, c[1] + u[1] * r)


def _straightened(prims, tol):
    """Each side fitted again without its ends where an arc begins (the longest side took a few of the arc's points,
    within tol: its direction leant toward the arc)."""
    n = len(prims)
    for k, p in enumerate(prims):
        if p['kind'] != 'line' or len(p['pts']) < 8:
            continue
        q = p['pts']
        lead = q[0]
        total = sum(math.dist(a, b) for a, b in zip(q, q[1:]))
        cut0 = cut1 = 0.
        prev, nxt = prims[k - 1], prims[(k + 1) % n]
        if prev['kind'] == 'arc':
            cut0 = min(.3 * total, math.sqrt(2 * prev['radius'] * tol))
        if nxt['kind'] == 'arc':
            cut1 = min(.3 * total, math.sqrt(2 * nxt['radius'] * tol))
        if not cut0 and not cut1:
            continue
        acc = 0.
        keep = []
        for a, b in zip([lead] + q, q):
            acc += math.dist(a, b)
            if cut0 <= acc <= total - cut1:
                keep.append(b)
        if len(keep) >= 5:
            line = fit_line(keep)
            if line_holds(q, line, tol * 1.5):
                p['line'] = line


UTURN = 175.   # degrees: two sides turned that much from each other, an arc between them: a round end (a half circle)


def _uturn(l1, arc, l2, tol):
    """The half circle between two sides going back the way they came (the round end of a strap): the sides made
    parallel, the circle tangent to both (radius: half their distance), its centre where the arc's points put it; as
    _fillet, the sides' lines set parallel; None when it does not hold."""
    u1, u2 = l1['line'][1], l2['line'][1]
    u = _unit((u1[0] - u2[0], u1[1] - u2[1]))
    if not (u[0] or u[1]):
        return None
    nn = (-u[1], u[0])
    p1, p2 = l1['line'][0], l2['line'][0]
    o1 = p1[0] * nn[0] + p1[1] * nn[1]
    o2 = p2[0] * nn[0] + p2[1] * nn[1]
    r = abs(o1 - o2) / 2
    mid = (o1 + o2) / 2
    if r <= tol:
        return None
    pts = arc['pts']
    along = sorted(p[0] * u[0] + p[1] * u[1] - math.sqrt(max(0., r * r - (p[0] * nn[0] + p[1] * nn[1] - mid) ** 2)) for p in pts)
    cu = along[len(along) // 2]
    c = (cu * u[0] + mid * nn[0], cu * u[1] + mid * nn[1])
    if not arc_holds(pts, c, r, tol * 1.5):
        return None
    t1 = (cu * u[0] + o1 * nn[0], cu * u[1] + o1 * nn[1])
    t2 = (cu * u[0] + o2 * nn[0], cu * u[1] + o2 * nn[1])
    s1, s2 = l1['pts'][0], l2['pts'][-1]
    if (t1[0] - s1[0]) * u[0] + (t1[1] - s1[1]) * u[1] <= tol or (t2[0] - s2[0]) * u[0] + (t2[1] - s2[1]) * u[1] <= tol:
        return None
    sweep = math.pi if arc['sweep'] > 0 else -math.pi
    l1['line'] = (t1, u)
    l2['line'] = (t2, (-u[0], -u[1]))
    return t1, c, r, t2, sweep


def _fillet(l1, arc, l2, tol):
    """The exact rounding between the sides l1 and l2 for the arc between them: (tangent point on l1, centre, radius,
    tangent point on l2, sweep), or None when it does not hold (the arc not tangent, its points off it)."""
    u1, u2 = l1['line'][1], l2['line'][1]
    q0, q1 = arc['pts'][0], arc['pts'][-1]
    if abs(_turn(u1, _tangent_at(q0, arc, True))) > FILLET or abs(_turn(_tangent_at(q1, arc, False), u2)) > FILLET:
        return None
    phi = math.radians(_turn(u1, u2))
    if abs(math.degrees(phi)) >= UTURN or abs(math.sin(phi)) < 1e-3:
        return _uturn(l1, arc, l2, tol)
    if abs(phi) < math.radians(2.):
        return None
    corner = _meet(l1['line'], l2['line'])
    if corner is None:
        return None
    w = _unit((u2[0] - u1[0], u2[1] - u1[1]))   # into the turn, along the bisector of the angle between the sides
    half = abs(phi) / 2   # half the turn: the centre is r / cos(half) from the corner, each tangent point r·tan(half)
    pts = arc['pts']

    def cost(r):
        c = (corner[0] + w[0] * r / math.cos(half), corner[1] + w[1] * r / math.cos(half))
        return sum((math.dist(p, c) - r) ** 2 for p in pts)
    lo, hi = arc['radius'] / 3, arc['radius'] * 3
    g = (math.sqrt(5) - 1) / 2
    a, b = hi - g * (hi - lo), lo + g * (hi - lo)
    fa, fb = cost(a), cost(b)
    for _ in range(60):
        if fa < fb:
            hi, b, fb = b, a, fa
            a = hi - g * (hi - lo)
            fa = cost(a)
        else:
            lo, a, fa = a, b, fb
            b = lo + g * (hi - lo)
            fb = cost(b)
    r = (lo + hi) / 2
    c = (corner[0] + w[0] * r / math.cos(half), corner[1] + w[1] * r / math.cos(half))
    if not arc_holds(pts, c, r, tol * 1.5):
        return None
    t = r * math.tan(half)
    t1 = (corner[0] - u1[0] * t, corner[1] - u1[1] * t)
    t2 = (corner[0] + u2[0] * t, corner[1] + u2[1] * t)
    # some of each side must stay before the rounding
    s1 = l1['pts'][0]
    s2 = l2['pts'][-1]
    if (t1[0] - s1[0]) * u1[0] + (t1[1] - s1[1]) * u1[1] <= tol or (s2[0] - t2[0]) * u2[0] + (s2[1] - t2[1]) * u2[1] <= tol:
        return None
    return t1, c, r, t2, phi


def fit(pts, tol, px, find_notches=True):
    """The piece of the closed edge ``pts`` (mm, about ``px`` mm apart): dict(points, bulges, crans (the middle of each
    notch's mouth), sides, arcs). ValueError when there is no piece."""
    pts = [p for k, p in enumerate(pts) if not k or math.dist(p, pts[k - 1]) > 1e-9]
    if len(pts) > 2 and math.dist(pts[0], pts[-1]) <= 1e-9:
        pts.pop()
    if len(pts) < 8:
        raise ValueError('Pièce trop petite.')
    inside = 1 if area(pts) > 0 else -1
    span = max(3.5 * px, .45)
    marks = corners(pts, span)
    crans = []
    if find_notches:
        found = notches(pts, marks, inside)
        if found:
            crans = [middle for _, _, middle, _ in found]
            pts = without_notches(pts, found, px)
            marks = corners(pts, span)
    n = len(pts)
    # the runs between corners (none: the whole line from its first point)
    runs = []
    if marks:
        for k, a in enumerate(marks):
            b = marks[(k + 1) % len(marks)]
            run = [pts[a]]
            i = a
            while True:   # (review 0.19.54) one corner (a drop): all round back to it (it was one point: « Pièce plate. »)
                i = (i + 1) % n
                run.append(pts[i])
                if i == b:
                    break
            runs.append(run)
    else:
        runs.append(pts + [pts[0]])
    prims = []
    corner = []
    for run in runs:
        got = run_fit(run, tol)
        prims.extend(got)
        corner.extend([False] * (len(got) - 1) + [bool(marks)])
    prims, corner = merged(prims, tol, corner)
    if not marks and len(prims) > 2:   # round all: the last and the first may be one
        j = _joined(prims[-1], prims[0], tol)
        if j is not None:
            prims = [j] + prims[1:-1]
            prims, corner = merged(prims, tol, [False] * len(prims))
    if len(prims) > 1:
        prims = settled_pairs(prims, tol, corner)
        prims = absorbed(prims, tol)
        prims = settled_pairs(prims, tol, [False] * len(prims))
    if len(prims) == 1:   # one arc all round (a round piece) or one side: cut it at its middle
        p = prims[0]
        if p['kind'] != 'arc':
            raise ValueError('Pièce plate.')
        half = len(p['pts']) // 2
        prims = [dict(p, pts=p['pts'][:half + 1]), dict(p, pts=p['pts'][half:])]
        for q in prims:
            q['sweep'] = arc_of(q['pts'], q['centre'], q['radius']) or p['sweep'] / 2
        corner = [False, False]
    _straightened(prims, tol)
    m = len(prims)
    reach = 4 * tol + 3 * px
    # the roundings between two sides: exact (tangent to both; a round end makes its two sides parallel), before the
    # joins are found (they read the sides' lines)
    exact = {}
    for k in range(m):
        a, b, c = prims[k - 1], prims[k], prims[(k + 1) % m]
        if b['kind'] == 'arc' and a['kind'] == 'line' and c['kind'] == 'line' and m >= 3:
            f = _fillet(a, b, c, tol)
            if f is not None:
                exact[k] = f
    joins = [_join_point(prims[k - 1], prims[k], prims[k]['pts'][0], reach) for k in range(m)]
    for k, f in exact.items():
        joins[k] = f[0]
        joins[(k + 1) % m] = f[3]
    points = []
    bulges = []
    for k in range(m):
        a, b = joins[k], joins[(k + 1) % m]
        p = prims[k]
        if math.dist(a, b) < 1e-6:
            continue
        if p['kind'] == 'line':
            points.append(a)
            bulges.append(0.)
            continue
        if k in exact:
            _, centre, radius, _, sweep = exact[k]
        else:
            centre, radius = p['centre'], p['radius']
            sweep = _sweep(a, b, centre, p['sweep'])
            if abs(sweep - p['sweep']) > math.pi / 2:   # its ends moved past each other: a side between them
                points.append(a)
                bulges.append(0.)
                continue
        parts = max(1, math.ceil(abs(math.degrees(sweep)) / SPLIT - 1e-4))   # (a quarter of a circle found at 90.000 1°: one part)
        start = math.atan2(a[1] - centre[1], a[0] - centre[0])
        r = (math.dist(a, centre) + math.dist(b, centre)) / 2
        for j in range(parts):
            q = a if not j else (centre[0] + r * math.cos(start + sweep * j / parts), centre[1] + r * math.sin(start + sweep * j / parts))
            points.append(q)
            bulges.append(math.tan(sweep / parts / 4))
    if len(points) < 3 and not any(bulges):   # (review 0.19.54: two sides there and back, a sliver of 0,4 mm: no area)
        raise ValueError('Pièce plate.')
    if len(points) > MOST_POINTS:
        raise ValueError('Contour trop découpé pour une pièce.')
    return dict(points=points, bulges=bulges, crans=crans,
                sides=sum(1 for p in prims if p['kind'] == 'line'), arcs=sum(1 for p in prims if p['kind'] == 'arc'))


def _sweep(a, b, centre, way):
    """The sweep from a to b round centre, the way ``way`` goes (its sign)."""
    s = math.atan2(b[1] - centre[1], b[0] - centre[0]) - math.atan2(a[1] - centre[1], a[0] - centre[0])
    if way > 0:
        s %= 2 * math.pi
    else:
        s = -((-s) % (2 * math.pi))
    return s


def outline(pts, tol):
    """A skin's edge (no arcs, no notches): the fewest straight sides within tol (image_lines.simplified)."""
    import image_lines
    out = image_lines.simplified(list(pts), True, tol)
    while len(out) > 4000:   # (a polyline keeps 5 000 points at most: geometry.validate)
        tol *= 1.5
        out = image_lines.simplified(list(pts), True, tol)
    if len(out) < 3:
        raise ValueError('Peau trop petite.')
    return out
