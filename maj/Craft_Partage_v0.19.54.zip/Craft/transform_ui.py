"""0.17.0: Rotation and Échelle tools (Modifications, after Déplacer).

Selection (or the objects already selected), then the fixed point (pivot / point fixe), then the
mouse turns or scales the selection; a typed value + Entrée gives it exactly: degrees for Rotation
(0.18.0: 90 = a quarter turn clockwise, -90 anticlockwise), a percentage for Échelle (120 = +20 %).

0.19.53 « par une ligne » (« échelle par ligne », 25/11/2026, as AutoCAD's Référence): after the point, a right click
« Par une ligne… »; a side of a line clicked (or two points) is the reference; its wanted length typed (Échelle: the
selection scaled by wanted / its length now) or its wanted angle (Rotation: 0 horizontal, 90 vertical, anticlockwise as
in the properties; the smallest turn that gives it, or the direction of the mouse).

0.19.54 « Aligner » (sa proposition acceptée le 26/11/2026, « bien » ; go du 27/11 0 h 14), as AutoCAD's ALIGN: the
selection, then a first point of it and where it goes, a second point of it and the point on whose line it goes; the
selection moved and turned (its first point on the first point given, its second on the line through the second); when
the two distances differ, « Mettre à l’échelle ? » (O : oui, Entrée : non). Entrée after the first pair: moved only."""
import math
from types import SimpleNamespace
from transform import transform,selection_reach,rigid,reference,relabel
from geometry import bounds

LABELS={'rotate':'Rotation','scale':'Échelle','align':'Aligner'}
KINDS=('rotate','scale','align')
ALIGN=('src1','dst1','src2','dst2','ask')   # Aligner's phases after the selection


def start(app,t):
    from entity_rules import linked_selection
    ids=linked_selection(app.items,app.selected_ids())
    app.finish_action();app.cancel();app.tool.set(t);app.last_command=('tool',t)
    first='src1' if t=='align' else 'base'
    app.xform=dict(kind=t,phase=first if ids else 'selection',ids=sorted(ids),box=None,base=None,value=None)
    app.selected_set=set(ids);app.selected=min(ids) if ids else None
    app.highlight_tools();app.refresh();prompt(app)
    follow_typing(app)


def follow_typing(app):
    """0.19.53 (review B: the preview waited for a move of the mouse after a value typed): each key typed, the preview
    follows (the ghost: its points only)."""
    var=app.__dict__.get('command_value')
    if var is None or app.__dict__.get('_xform_typing') is var:return
    def typed_now(*args):
        if app.__dict__.get('_xform_typing_job') is None:app._xform_typing_job=app.after_idle(refresh_typed)
    def refresh_typed():
        app._xform_typing_job=None;st=app.__dict__.get('xform')
        if not st or st['phase'] not in WANTED or app.tool.get() not in ('rotate','scale') or not app.winfo_exists():return
        x,y=app.cursor_screen;motion(app,SimpleNamespace(x=x,y=y,state=0))
    app._xform_typing=var;app._xform_typing_job=None;var.trace_add('write',typed_now)


# 0.18.0: the same words in the status line and beside the cursor (no « Entrée » reminder).
STEPS={'rotate':{'selection':'Sélectionner ligne','base':'Choisir centre de rotation','value':'Tourner à la souris · angle au clavier · clic droit : par une ligne',
                  'ref':'Cliquer ligne ou premier point','ref2':'Choisir second point','target':'Angle voulu au clavier ou à la souris'},
       'scale':{'selection':'Sélectionner ligne','base':'Choisir point fixe','value':'Glisser à la souris · % au clavier · clic droit : par une ligne',
                'ref':'Cliquer ligne ou premier point','ref2':'Choisir second point','target':'Longueur voulue au clavier'},
       'align':{'selection':'Sélectionner ligne','src1':'Choisir premier point source','dst1':'Choisir premier point de destination',
                'src2':'Choisir second point source · Entrée : déplacer seulement','dst2':'Choisir second point de destination',
                'ask':'Mettre à l’échelle ? O : oui · Entrée : non'}}
WANTED=('value','target')   # the phases where a value is typed (or given by the mouse)
REFERENCE=('value','ref','ref2','target')   # where « Par une ligne… » can be asked
SIDE_SNAPS=(None,'nearest','midpoint','quarter')   # a click caught by these on a straight side takes the side
ALONG=('extension','guides')   # (review 0.19.53) a point projected on a line: along the side clicked, the side too


def prompt(app):
    st=app.xform;t=st['kind']
    text=STEPS[t][st['phase']]
    if st['phase']=='target':text+=' · ligne : '+reference_words(app)
    app.status.set(text)


def by_line(app):
    """0.19.53 « Par une ligne… » (the right click once the point is given): the reference is asked."""
    st=app.__dict__.get('xform')
    if not st or st['phase'] not in REFERENCE:return
    st.update(phase='ref',ref=None,first=None,value=None)
    if app.command_value.get():app.command_value.set('')
    if 'command_entry' in app.__dict__:app.command_entry.place_forget()
    app.canvas.delete('xform');prompt(app);app.draw_crosshair()


def step_back(app):
    """(review 0.19.53) Ctrl+Z once the point is given, as while a shape is drawn (0.19.40): the step under way only (the
    reference clicked again, the mouse again, the point again), never the action before as well (the piece drawn just
    before went, the tool ended)."""
    st=app.xform;phase=st['phase']
    if st['kind']=='align':   # 0.19.54: the point given before, again
        back={'dst1':'src1','src2':'dst1','dst2':'src2','ask':'dst2'}.get(phase)
        if back:
            st['phase']=back;st.pop(back,None);st.update(value=None)
            if back=='src1':st.update(base=None,ghost=None);app.canvas.delete('xform')
            prompt(app)
        x,y=app.cursor_screen;motion(app,SimpleNamespace(x=x,y=y,state=0))
        return 'break'
    if phase in ('ref2','target'):by_line(app)
    elif phase=='ref':st.update(phase='value',value=None);prompt(app)
    else:
        st.update(phase='base',value=None,ghost=None);app.canvas.delete('xform')
        if app.command_value.get():app.command_value.set('')
        if 'command_entry' in app.__dict__:app.command_entry.place_forget()
        prompt(app)
    x,y=app.cursor_screen;motion(app,SimpleNamespace(x=x,y=y,state=0))
    return 'break'


def reference_at(app,e):
    """The straight side of a line under the click (its two ends; straight parts in line: one side), or a circle's
    diameter (Échelle); None."""
    marker=app.__dict__.get('snap_marker')
    if marker and marker[1] not in SIDE_SNAPS+ALONG:return None   # an end, a centre, a crossing: a point
    p=app.raw(e);i=app.pick(p)
    if i is None or i>=len(app.items):return None
    s=app.items[i]
    if s.get('annotation') or s.get('is_notch') or s.get('preparation') or s.get('dimension_group') or s.get('text') is not None \
            or s.get('spline') or s.get('ellipse') or s.get('components'):return None
    from precision_geometry import primitives,piece_runs
    try:es=primitives(s)
    except (ValueError,KeyError,TypeError,ZeroDivisionError,IndexError):return None
    if not es:return None
    def gap(q):
        if not q['sweep']:
            a,b=q['a'],q['b'];dx,dy=b[0]-a[0],b[1]-a[1];L2=dx*dx+dy*dy
            t=0. if L2<=0 else max(0.,min(1.,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/L2))
            return math.dist(p,(a[0]+t*dx,a[1]+t*dy))
        turn=(math.atan2(p[1]-q['c'][1],p[0]-q['c'][0])-q['start'])*(1 if q['sweep']>0 else -1)%(2*math.pi)
        return abs(math.dist(p,q['c'])-q['r']) if turn<=abs(q['sweep']) else min(math.dist(p,q['a']),math.dist(p,q['b']))
    k=min(range(len(es)),key=lambda j:gap(es[j]))
    if gap(es[k])>8/max(app.scale,1e-9):return None
    q=es[k];run=next((r for r in piece_runs(es,bool(s.get('closed'))) if k in r),[k])
    if marker and marker[1] in ALONG:
        # (review 0.19.53) the Extension of a side in line with this one (two pieces in line in the base, a face cut in the
        # middle of its top: the click was a point): the side; an extension across it: the point where they meet
        if q['sweep']:return None
        a,b=q['a'],q['b'];dx,dy=b[0]-a[0],b[1]-a[1];t=((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy)
        if math.dist(marker[0],(a[0]+t*dx,a[1]+t*dy))>.5/max(app.scale,1e-9):return None
    if not q['sweep']:return (es[run[0]]['a'],es[run[-1]]['b'])   # (review) straight parts in line (a point left in it): one side
    if app.xform['kind']=='scale':
        if abs(sum(es[j]['sweep'] for j in run))>=2*math.pi-1e-6:   # a circle: its diameter
            c,r=q['c'],q['r'];return ((c[0]-r,c[1]),(c[0]+r,c[1]))
    return None


def reference_taken(app,a,b):
    st=app.xform;st.update(ref=(a,b),first=None,phase='target',value=None,way=None)
    if app.command_value.get():app.command_value.set('')
    prompt(app)


def line_angle(a,b):
    """The direction of a → b in degrees, 0 horizontal and anticlockwise as the properties show it (Craft's y goes down),
    in [0, 180)."""
    return math.degrees(math.atan2(-(b[1]-a[1]),b[0]-a[0]))%180


def reference_words(app):
    st=app.xform;a,b=st['ref']
    if st['kind']=='scale':
        unit=app.units.get();f=10 if unit=='cm' else 1
        return f'{math.dist(a,b)/f:.2f}'.rstrip('0').rstrip('.').replace('.',',')+' '+unit
    return f'{line_angle(a,b):.1f}'.rstrip('0').rstrip('.').replace('.',',')+'°'


def turn_to(app,wanted):
    """The Rotation (clockwise degrees, as typed in the tool) that gives the reference the direction ``wanted``
    (degrees, anticlockwise): the smallest one."""
    a,b=app.xform['ref'];delta=(wanted-line_angle(a,b)+90)%180-90
    if abs(delta+90)<1e-9:delta=90.
    return -delta


def target_value(app,p=None):
    """The value of the phase « target »: typed (a length: Échelle; an angle: Rotation), else (Rotation) the direction
    of the mouse from the centre; None when there is none. ValueError when it cannot be used."""
    st=app.xform;a,b=st['ref'];text=app.command_value.get().strip()
    if st['kind']=='scale':
        if not text:return None
        wanted=app.parse_length(text)
        if wanted<=0:raise ValueError('La longueur doit être positive.')
        factor=wanted/math.dist(a,b);base=st.get('base');box=st.get('extent')
        if base and box and max(abs(base[k%2]+(box[k]-base[k%2])*factor) for k in range(4))>100000:raise ValueError('Échelle hors limites (±100 m).')
        if st.get('reach',1)*factor<.001:raise ValueError('Échelle trop petite.')
        return factor
    if text:
        from command_catalog import length_expression
        try:wanted=length_expression(text[:-1] if text.endswith('°') else text)
        except ValueError as exc:
            if 'hors limites' in str(exc):raise ValueError('Angle hors limites.') from None
            raise
        return turn_to(app,wanted)
    if p is None:return None
    base=st['base']
    if math.dist(p,base)<1e-9:return None
    # by the mouse: the reference follows it by one of its ends, the one nearer the mouse when it starts, kept after (the
    # smallest turn of a typed angle made the selection jump by 180° as the mouse went past the line's normal)
    seen=math.degrees(math.atan2(-(p[1]-base[1]),p[0]-base[0]))
    if app.ortho.get():seen=90*round(seen/90)
    a,b=st['ref'];way=math.degrees(math.atan2(-(b[1]-a[1]),b[0]-a[0]))
    if st.get('way') is None:st['way']=0. if abs((seen-way+180)%360-180)<=90 else 180.
    return -((seen-way-st['way']+180)%360-180)


def click(app,e):
    st=app.xform
    if st['phase']=='selection':st['box']=(e.x,e.y,app.raw(e));return
    if st['kind']=='align':return align_click(app,e)
    if st['phase']=='ref':   # 0.19.53: a side clicked, or the first of two points
        q=app.point(e);side=reference_at(app,e)
        if side:reference_taken(app,*side);motion(app,e);return
        st.update(first=q,phase='ref2');prompt(app);motion(app,e);return
    if st['phase']=='ref2':
        q=app.point(e)
        if math.dist(q,st['first'])<1e-6:raise ValueError('Choisir un second point différent.')
        reference_taken(app,st['first'],q);motion(app,e);return
    if st['phase']=='target':
        value=target_value(app,app.point(e))
        if value is None:app.status.set('Taper la longueur voulue, puis Entrée.' if st['kind']=='scale' else 'Taper l’angle voulu, ou bouger la souris.');return
        apply(app,value);return
    if st['phase']=='base':
        p=app.point(e);st.update(base=p,phase='value',reach=selection_reach([app.items[i] for i in st['ids']],p) or 1.)
        try:st['extent']=bounds([app.items[i] for i in st['ids'] if i<len(app.items)])   # 0.19.9: for the limits of a typed Échelle
        except (ValueError,KeyError,TypeError):pass
        if app.command_value.get():app.command_value.set('')
        prompt(app);motion(app,e);return
    # 0.19.9: a typed value is the one shown: the click applies it (the mouse's only without one)
    value=typed(app)
    if value is None:value=current(app,app.point(e))
    if value is None:raise ValueError('Éloignez le curseur du point choisi.')
    apply(app,value)


def release(app,e):
    st=app.xform;x,y,a=st['box'];st['box']=None;app._advanced_press=False;app.canvas.delete('xform')
    from selection import select,shift_held
    if math.hypot(e.x-x,e.y-y)>=4:return take(app,select(app.items,a,app.raw(e)),shift_held(e))
    i=app.pick(app.raw(e))
    if i is None:   # 0.19.21: a click in the void starts the rectangle, closed by the next click
        return app.start_pending_box('xform',a,lambda a,b,remove:take(app,select(app.items,a,b),remove),shift_held(e))
    take(app,{i},shift_held(e))


def take(app,found,remove):
    st=app.__dict__.get('xform')
    if not st or st['phase']!='selection':return
    from selection import combined
    if hasattr(app,'shown_only'):found=app.shown_only(found)   # 0.19.40 (review): never what is hidden, as Copier, Symétrie (its piece's own follow it, below)
    ids=combined(set(st['ids']),found,remove)
    from entity_rules import linked_selection
    ids=set(linked_selection(app.items,ids)) if ids else set()
    st['ids']=sorted(ids);app.selected_set=set(ids);app.selected=min(ids) if ids else None;app.refresh()
    n=len(ids);app.status.set(f'{LABELS[st["kind"]]} : {n} ligne{"s" if n>1 else ""} sélectionnée{"s" if n>1 else ""}' if ids else STEPS[st['kind']]['selection'])   # 0.19.40: plurals written out


def current(app,p):
    """Angle in degrees (rotation) or factor (scale) given by the pointer p."""
    st=app.xform;b=st['base'];dx,dy=p[0]-b[0],p[1]-b[1]
    if math.hypot(dx,dy)<1e-9:return None
    if st['kind']=='rotate':
        angle=math.degrees(math.atan2(dy,dx))   # 0.18.0: clockwise on screen (Craft's y axis points down)
        if app.ortho.get():angle=90*round(angle/90)
        return angle
    return math.hypot(dx,dy)/st['reach']


def typed(app):
    """0.19.9: read like Craft's other typed values (« 90/2 », « 45° », « 120 % », « 1,5 »): None when nothing is
    typed; ValueError when it cannot be used (still being typed, zero, the drawing beyond ±100 m…)."""
    text=app.command_value.get().strip()
    if not text:return None
    from command_catalog import length_expression
    st=app.xform;rotate=st['kind']=='rotate'
    try:value=length_expression(text[:-1] if text.endswith('°' if rotate else '%') else text)
    except ValueError as exc:
        if rotate and 'hors limites' in str(exc):raise ValueError('Angle hors limites.') from None   # not « ±100 m »
        raise
    if rotate:return value
    if value<=0:raise ValueError('Le pourcentage doit être positif.')
    factor=value/100;b=st.get('base');box=st.get('extent')
    if b and box and max(abs(b[k%2]+(box[k]-b[k%2])*factor) for k in range(4))>100000:raise ValueError('Échelle hors limites (±100 m).')
    if b and st.get('reach',1)*factor<.001:raise ValueError('Échelle trop petite.')
    return factor


def label(app,value):
    # 0.19.40 (review): a French decimal comma, as every value Craft writes (« Rotation : 22.5°. »)
    if app.xform['kind']=='rotate':return f'{value:.1f}'.rstrip('0').rstrip('.').replace('.',',')+'°'
    return f'{value*100:.1f}'.rstrip('0').rstrip('.').replace('.',',')+' %'


def motion(app,e):
    app.cursor_screen=(e.x,e.y);app._inside_plan=True;st=app.xform
    if st['phase']=='selection':
        box=st['box']
        # 0.18.0: blue / green as everywhere; 0.18.5: drawn again in place (follows the mouse at once).
        if box and math.hypot(e.x-box[0],e.y-box[1])>=4:app.draw_selection_box(box[0],box[1],e.x,e.y,'xform')
        else:app.canvas.delete('xform')
        app.draw_crosshair();return
    c=app.canvas;c.delete(LIVE)
    p=app.point(e);value=None
    if st['kind']=='align':return align_motion(app,p)
    if st['phase'] in ('ref2','target'):   # 0.19.53: the reference line, and what it gives
        a,b=(st['first'],p) if st['phase']=='ref2' else st['ref']
        c.create_line(*app.to_screen(a),*app.to_screen(b),fill=app.p['accent'],width=3,tags=('xform',LIVE))
        if st['phase']=='target':
            try:value=target_value(app,p)
            except ValueError:value=None
            if value is not None:
                st['value']=value
                if st['kind']=='rotate' and not app.command_value.get().strip():
                    c.create_line(*app.to_screen(st['base']),*app.to_screen(p),fill=app.p['accent'],tags=('xform',LIVE),**app.guide_style())
                x,y=app.to_screen(p);c.create_text(x+14,y-14,text=label(app,value),anchor='sw',fill=app.p['ink'],font=('Segoe UI',10),tags=('xform',LIVE))
    if st['phase']=='value':
        try:value=typed(app)
        except ValueError:value=None
        if value is None:value=current(app,p)
        if value is not None:
            st['value']=value;b=st['base']
            c.create_line(*app.to_screen(b),*app.to_screen(p),fill=app.p['accent'],tags=('xform',LIVE),**app.guide_style())
            x,y=app.to_screen(p);c.create_text(x+14,y-14,text=label(app,value),anchor='sw',fill=app.p['ink'],font=('Segoe UI',10),tags=('xform',LIVE))
    ghost(app,value if st['phase'] in WANTED else None)
    app.draw_crosshair();app.draw_input_bubble()


def draw_preview(app,value,tags=('xform',)):
    st=app.xform
    if st['kind']=='align':   # 0.19.54: value = (dx, dy) plan, clockwise degrees
        for i in st['ids']:
            if i<len(app.items):
                try:app.draw_shape(aligned(app.items[i],st['base'],(value[0],value[1]),value[2],1.),'#a3a8aa',1,tags)
                except (ValueError,KeyError,TypeError,ZeroDivisionError):pass
        return
    deg,factor=(-value,1.) if st['kind']=='rotate' else (0.,value)   # value: clockwise degrees
    for i in st['ids']:
        if i<len(app.items):
            try:app.draw_shape(transform(app.items[i],st['base'],deg,factor),'#a3a8aa',1,tags)
            except (ValueError,KeyError,TypeError,ZeroDivisionError):pass


# 0.19.53 (fluidité: Rotation / Échelle of all of DIFORME, 41 ms a move of the mouse, Linux): the preview is drawn once as
# the selection is (0°, 100 %), then at each move only its items' points turned or scaled about the point, on the screen
# (texts: their angle, their size); drawn again when the view changes, past 80 px/mm as before (lines cut to the screen).
GHOST='xform_ghost'
LIVE='xform_live'   # what follows the mouse besides it: the guide, the value
DEEP=80.   # px/mm (deep_zoom)
# (review 0.19.53) what the preview drawn in full only moves, carried by its reference point (transform.reference): with
# Échelle what keeps its size (transform.rigid: texts, crans, mèches, arrows, ID: they were made bigger, a text's lines spread),
# with Rotation a mèche (its circle, its cross and its diameter stay upright: the cross and the number were turned)
BLOCK='xform_block'
BOXED=('oval','rectangle','arc')   # (review) drawn by their box (an ID, the holes of a Piqûre main): their centre follows,
                                   # their size stays (their two corners turned: a line at 45°)


def kept_whole(s,kind):
    return bool(s.get('drill')) if kind in ('rotate','align') else rigid(s)   # (Aligner: turned as Rotation; its scale only at the end)


def ghost(app,value):
    st=app.xform;c=app.canvas
    if value is None or app.scale>DEEP:
        # (review 0.19.53) drawn in full with the ghost's tag: the drawing of the move before goes (past 80 px/mm they piled up)
        c.delete(GHOST);st['ghost']=None
        if value is not None:draw_preview(app,value,('xform',GHOST));c.tag_raise(LIVE)
        return
    key=(app.scale,app.ox,app.oy,c.winfo_width(),c.winfo_height(),tuple(st['ids']),st['base'],len(app.items))
    g=st.get('ghost')
    if g and (g['key']!=key or len(c.find_withtag(GHOST))!=len(g['items'])):g=None
    if g is None:
        c.delete(GHOST)
        bx,by=app.to_screen(st['base']);refs={}
        for n,i in enumerate(st['ids']):   # as draw_preview (0°, 100 %), what moves as one piece tagged by its object
            if i>=len(app.items):continue
            s=app.items[i];whole=kept_whole(s,st['kind']);tags=('xform',GHOST,BLOCK,f'{BLOCK}:{n}') if whole else ('xform',GHOST)
            try:app.draw_shape(transform(s,st['base'],0.,1.),'#a3a8aa',1,tags)
            except (ValueError,KeyError,TypeError,ZeroDivisionError):continue
            if whole:
                try:rx,ry=app.to_screen(reference(s))
                except (KeyError,TypeError,IndexError):rx,ry=bx,by
                refs[f'{BLOCK}:{n}']=(rx-bx,ry-by,bool(s.get('annotation') and s.get('dimension_group')))
        held=set(c.find_withtag(BLOCK));items=[]
        for i in c.find_withtag(GHOST):
            kind=c.type(i);xy=c.coords(i)
            rel=[v-(bx if k%2==0 else by) for k,v in enumerate(xy)]
            ref=next((refs[t] for t in c.gettags(i) if t in refs),None) if i in held else None
            if ref is None and kind in BOXED and len(rel)==4:ref=((rel[0]+rel[2])/2,(rel[1]+rel[3])/2,False)
            extra=None
            if kind=='text':
                font=list(c.tk.splitlist(c.itemcget(i,'font')))
                try:size=int(font[1])
                except (IndexError,ValueError):size=None
                extra=(float(c.itemcget(i,'angle') or 0.),font,size,c.itemcget(i,'text') if ref and ref[2] else None)
            items.append((i,kind,rel,extra,ref))
        g=st['ghost']=dict(key=key,items=items,base=(bx,by),value=None)
        c.tag_raise(LIVE)
    if g['value']==value:return
    g['value']=value;bx,by=g['base'];call,w=c.tk.call,c._w   # (review) Tcl's coords / itemconfigure as they are (tkinter's spelled each out)
    if st['kind']=='align':   # 0.19.54: moved by (tx, ty) pixels and turned by deg about the first point source
        tx,ty,deg=value;t=math.radians(deg);cs,sn=math.cos(t),math.sin(t);bx,by=bx+tx,by+ty
        for i,kind,rel,extra,ref in g['items']:
            if ref is not None:
                rx,ry=ref[0],ref[1];dx,dy=bx+cs*rx-sn*ry-rx,by+sn*rx+cs*ry-ry
                call(w,'coords',i,*[v+(dy if k%2 else dx) for k,v in enumerate(rel)]);continue
            xs,ys=rel[0::2],rel[1::2]
            call(w,'coords',i,*[v for dx,dy in zip(xs,ys) for v in (bx+cs*dx-sn*dy,by+sn*dx+cs*dy)])
            if extra:call(w,'itemconfigure',i,'-angle',(extra[0]-deg)%360)
        return
    if st['kind']=='rotate':
        t=math.radians(value);cs,sn=math.cos(t),math.sin(t)   # clockwise on the screen (its y goes down)
        for i,kind,rel,extra,ref in g['items']:
            if ref is not None:   # moved as one piece with its reference point (an oval: its centre)
                rx,ry=ref[0],ref[1];dx,dy=bx+cs*rx-sn*ry-rx,by+sn*rx+cs*ry-ry
                call(w,'coords',i,*[v+(dy if k%2 else dx) for k,v in enumerate(rel)]);continue
            xs,ys=rel[0::2],rel[1::2]
            new=[v for dx,dy in zip(xs,ys) for v in (bx+cs*dx-sn*dy,by+sn*dx+cs*dy)]
            call(w,'coords',i,*new)
            if extra:call(w,'itemconfigure',i,'-angle',(extra[0]-value)%360)
    else:
        f=value
        for i,kind,rel,extra,ref in g['items']:
            if ref is not None:
                dx,dy=bx+(f-1)*ref[0],by+(f-1)*ref[1]
                call(w,'coords',i,*[v+(dy if k%2 else dx) for k,v in enumerate(rel)])
                if extra and extra[3] is not None:call(w,'itemconfigure',i,'-text',relabel(extra[3],f))   # a cote's value, as in full
                continue
            call(w,'coords',i,*[(bx if k%2==0 else by)+f*v for k,v in enumerate(rel)])
            if extra and extra[2]:
                font=list(extra[1]);font[1]=str(min(-1,round(extra[2]*f)) if extra[2]<0 else max(1,round(extra[2]*f)))
                c.itemconfigure(i,font=tuple(font))


def enter(app):
    st=app.xform
    if st['phase']=='selection':
        if not st['ids']:app.status.set('Sélectionner au moins un objet.');return 'break'
        st['phase']='src1' if st['kind']=='align' else 'base';prompt(app);return 'break'
    if st['kind']=='align':return align_enter(app)
    if st['phase']=='base':app.status.set('Choisir d’abord le point.');return 'break'
    if st['phase'] in ('ref','ref2'):app.status.set('Cliquer d’abord la ligne de référence.');return 'break'
    if st['phase']=='target':   # 0.19.53
        try:value=target_value(app)
        except ValueError as exc:app.command_value.set('');app.status.set(str(exc) or 'Valeur invalide.');return 'break'
        if value is None:value=st.get('value') if st['kind']=='rotate' else None
        if value is None:app.status.set('Taper la longueur voulue, puis Entrée.' if st['kind']=='scale' else 'Taper l’angle voulu, ou bouger la souris.');return 'break'
        try:apply(app,value)
        except ValueError as exc:app.status.set(str(exc) or 'Valeur invalide.')
        return 'break'
    try:value=typed(app)
    except ValueError as exc:app.status.set(str(exc) if str(exc) else 'Valeur invalide.');return 'break'
    if value is None:value=st.get('value')
    if value is None:app.status.set('Bougez la souris ou tapez une valeur.');return 'break'
    # 0.19.9: a result the drawing cannot take (beyond ±100 m…) is said in the status line, not in an error window
    try:apply(app,value)
    except ValueError as exc:app.status.set(str(exc) or 'Valeur invalide.')
    return 'break'


def apply(app,value):
    st=app.xform;deg,factor=(-value,1.) if st['kind']=='rotate' else (0.,value)   # value: clockwise degrees
    if st['kind']=='scale' and factor<=0:raise ValueError('Le pourcentage doit être positif.')
    new={i:transform(app.items[i],st['base'],deg,factor) for i in st['ids'] if i<len(app.items)}
    from geometry import validate
    validate(list(new.values()))
    app.snapshot()
    old={i:app.items[i] for i in new}
    for i,s in new.items():app.items[i]=s
    if st['kind']=='scale' and hasattr(app,'refit_stitches'):
        # 0.19.22 (found before installing: 120 % put the Piqûre 3 mm from the edge instead of 2,5): it keeps its distance
        # (bug hunt 0.19.49) a précoupe holds the Piqûres and teintes of the pieces inside it: refit round those (first), never
        # round the précoupe's own contour (its inward offset can be the Piqûre's: 1,5 mm from the piece instead of 2,5)
        from entity_rules import carrier
        import surcoupe
        pairs={}
        for i,s in sorted(new.items(),key=lambda e:surcoupe.is_precut(e[1])):
            if carrier(s) and not s.get('is_notch'):pairs.setdefault(carrier(s),[]).append((old[i],s))
        app.refit_stitches(pairs,old)
    kind=st['kind'];text=label(app,value);ids=sorted(new)
    app.xform=None;app.canvas.delete('xform')
    if app.command_value.get():app.command_value.set('')
    if 'command_entry' in app.__dict__:app.command_entry.place_forget()
    app.complete_command(kind)   # 0.18.0: nothing stays selected after the action
    app.status.set(f'{LABELS[kind]} : {text}.');app.refresh()


def cancel(app):
    app.xform=None
    try:app.canvas.delete('xform')
    except Exception:pass



# --- 0.19.54 « Aligner » -----------------------------------------------------------------------------------------------

def aligned(s,base,shift,degrees,factor):
    """``s`` turned by ``degrees`` (clockwise on the screen, as Rotation's value) and scaled by ``factor`` about ``base``,
    then moved by ``shift``."""
    from transform import moved
    q=transform(s,base,-degrees,factor) if degrees or factor!=1 else s
    return moved(q,shift[0],shift[1])


def align_turn(st,p=None):
    """The turn (clockwise degrees) that puts the line source1 → source2 along destination1 → p (or destination2)."""
    a,b=st['src1'],st['src2'];c=st['dst1'];d=p if p is not None else st['dst2']
    if math.dist(c,d)<1e-9:return 0.
    turn=math.degrees(math.atan2(d[1]-c[1],d[0]-c[0])-math.atan2(b[1]-a[1],b[0]-a[0]))
    return (turn+180)%360-180


def align_factor(st):
    a,b=st['src1'],st['src2'];return math.dist(st['dst1'],st['dst2'])/math.dist(a,b)


def align_click(app,e):
    st=app.xform;p=app.point(e);phase=st['phase']
    if phase=='src1':st.update(src1=p,base=p,phase='dst1')
    elif phase=='dst1':st.update(dst1=p,phase='src2')
    elif phase=='src2':
        if math.dist(p,st['src1'])<1e-6:raise ValueError('Choisir un second point différent du premier.')
        st.update(src2=p,phase='dst2')
    elif phase=='dst2':
        if math.dist(p,st['dst1'])<1e-6:raise ValueError('Choisir un second point différent du premier.')
        st['dst2']=p
        if abs(align_factor(st)-1)<=1e-6 or abs(math.dist(st['dst1'],p)-math.dist(st['src1'],st['src2']))<=.005:
            return apply_align(app,False)
        st['phase']='ask'
    elif phase=='ask':return apply_align(app,False)   # a click: Entrée (no scale)
    prompt(app);align_motion(app,p)


def align_enter(app):
    st=app.xform;phase=st['phase']
    # (review 0.19.54) Entrée alone: a value typed there is no « déplacer seulement » (it was dropped, the selection moved)
    if phase=='src2' and not app.command_value.get().strip():return said_align(app,False,moved_only=True)   # as AutoCAD: one pair, the selection moved
    if phase=='ask':
        text=app.command_value.get().strip().lower()
        if text in ('','n','non','no'):return said_align(app,False)
        if text in ('o','oui','y','yes'):return said_align(app,True)
        app.command_value.set('');app.status.set('Taper O (mettre à l’échelle) ou N, puis Entrée.');return 'break'
    app.status.set('Choisir d’abord le point.');return 'break'


def said_align(app,scale,moved_only=False):
    """(review 0.19.54) apply_align by Entrée, O / N or the right click: a result the drawing cannot take (beyond ±100 m)
    said in the status line as Rotation / Échelle say it (0.19.9), never in an error window; the tool stays (a click: said
    beside the cross, invalid_at)."""
    try:return apply_align(app,scale,moved_only)
    except ValueError as exc:app.status.set(str(exc) or 'Valeur invalide.');return 'break'


def align_key(app,char):
    """In « Mettre à l’échelle ? »: O or N at once (no Entrée)."""
    st=app.__dict__.get('xform')
    # (review 0.19.54) only while Aligner is the tool: Suppr or Dupliquer end it but leave app.xform; « o » typed later in the
    # Sélection aligned the objects now at those places of the list
    if not st or st.get('kind')!='align' or st['phase']!='ask' or not char or app.tool.get()!='align':return None
    if char in 'oOyY':return said_align(app,True)
    if char in 'nN':return said_align(app,False)
    return None


def align_motion(app,p):
    st=app.xform;c=app.canvas;phase=st['phase'];value=None;guide=[]
    if phase=='dst1':value=(p[0]-st['src1'][0],p[1]-st['src1'][1],0.);guide.append((st['src1'],p))
    elif phase in ('src2','dst2','ask'):
        shift=(st['dst1'][0]-st['src1'][0],st['dst1'][1]-st['src1'][1])
        turn=align_turn(st,p) if phase=='dst2' else align_turn(st) if phase=='ask' else 0.
        value=(shift[0],shift[1],turn);guide.append((st['src1'],st['dst1']))
        if phase=='src2':guide.append((st['src1'],p))
        else:guide.append((st['src2'],p if phase=='dst2' else st['dst2']))
    for a,b in guide:c.create_line(*app.to_screen(a),*app.to_screen(b),fill=app.p['accent'],tags=('xform',LIVE),**app.guide_style())
    if value is None:ghost(app,None)
    else:
        if app.scale>DEEP:ghost(app,value)
        else:   # the ghost moves by pixels: the shift on the screen
            ghost(app,(value[0]*app.scale,value[1]*app.scale,value[2]))
    app.draw_crosshair();app.draw_input_bubble()


def apply_align(app,scale,moved_only=False):
    st=app.xform
    a=st['src1'];shift=(st['dst1'][0]-a[0],st['dst1'][1]-a[1])
    turn=0. if moved_only else align_turn(st);factor=align_factor(st) if scale and not moved_only else 1.
    new={i:aligned(app.items[i],a,shift,turn,factor) for i in st['ids'] if i<len(app.items)}
    from geometry import validate
    validate(list(new.values()))
    app.snapshot()
    old={i:app.items[i] for i in new}
    for i,s in new.items():app.items[i]=s
    if factor!=1 and hasattr(app,'refit_stitches'):   # the Piqûres keep their distance (as Échelle)
        from entity_rules import carrier
        import surcoupe
        pairs={}
        for i,s in sorted(new.items(),key=lambda e:surcoupe.is_precut(e[1])):
            if carrier(s) and not s.get('is_notch'):pairs.setdefault(carrier(s),[]).append((old[i],s))
        app.refit_stitches(pairs,old)
    app.xform=None;app.canvas.delete('xform')
    if app.command_value.get():app.command_value.set('')
    if 'command_entry' in app.__dict__:app.command_entry.place_forget()
    app.complete_command('align')
    shown=round(turn,1)+0.   # (never « -0 »)
    words='Aligné : déplacé' if moved_only else 'Aligné : tourné de '+f'{shown:.1f}'.rstrip('0').rstrip('.').replace('.',',').replace('-0','0' if not shown else '-0')+'°'
    if factor!=1:words+=', mis à l’échelle à '+f'{factor*100:.1f}'.rstrip('0').rstrip('.').replace('.',',')+' %'
    app.status.set(words+'.');app.refresh()
    return 'break'
